"""
Problem: Maximum of All Subarrays of Size K

Given an array and integer K, find maximum for each contiguous subarray of size K.

Example:
    Input: arr = [1, 3, -1, -3, 5, 3, 6, 7], K = 3
    Output: [3, 3, 5, 5, 6, 7]
"""

import heapq
from collections import deque


def max_sliding_window_heap(arr, k):
    """
    Using Max-Heap with lazy deletion.

    Approach:
    - Use max-heap to track maximum in window
    - Store (value, index) pairs
    - Lazy delete: remove element only when it's max and out of window

    Time: O(n log n) - each element pushed/popped at most once
    Space: O(n) - heap can grow to n in worst case
    """
    if not arr or k <= 0:
        return []

    n = len(arr)
    if k >= n:
        return [max(arr)]

    # Max-heap using negative values (Python's heapq is min-heap)
    heap = []  # Stores (-value, index)
    result = []

    for i in range(n):
        # Add current element to heap
        heapq.heappush(heap, (-arr[i], i))

        # Window is complete (has K elements)
        if i >= k - 1:
            # Remove elements outside the window (lazy deletion)
            while heap[0][1] <= i - k:
                heapq.heappop(heap)

            # Current maximum is at top of heap
            result.append(-heap[0][0])

    return result


def max_sliding_window_deque(arr, k):
    """
    Using Monotonic Deque - OPTIMAL O(n) solution.

    Approach:
    - Maintain deque of indices in decreasing order of values
    - Front of deque is always the maximum
    - Remove elements outside window from front
    - Remove smaller elements from back (they can never be max)

    Time: O(n) - each element added/removed at most once
    Space: O(k) - deque stores at most k elements
    """
    if not arr or k <= 0:
        return []

    n = len(arr)
    if k >= n:
        return [max(arr)]

    dq = deque()  # Store indices, not values
    result = []

    for i in range(n):
        # Remove elements outside the window from front
        while dq and dq[0] <= i - k:
            dq.popleft()

        # Remove smaller elements from back
        # They can never be maximum while current element exists
        while dq and arr[dq[-1]] < arr[i]:
            dq.pop()

        dq.append(i)

        # Add maximum to result once window is complete
        if i >= k - 1:
            result.append(arr[dq[0]])

    return result


def max_sliding_window_brute(arr, k):
    """
    Brute Force - Check each window.

    Time: O(n * k)
    Space: O(1) excluding output
    """
    if not arr or k <= 0:
        return []

    n = len(arr)
    result = []

    for i in range(n - k + 1):
        window_max = max(arr[i:i + k])
        result.append(window_max)

    return result


def max_sliding_window_visualized(arr, k):
    """
    Heap solution with step-by-step visualization.
    """
    print(f"Array: {arr}")
    print(f"K = {k}")
    print("=" * 50)

    heap = []  # (-value, index)
    result = []

    for i in range(len(arr)):
        print(f"\nStep {i + 1}: Process arr[{i}] = {arr[i]}")

        # Add to heap
        heapq.heappush(heap, (-arr[i], i))
        print(f"  Push ({arr[i]}, {i}) to heap")
        print(f"  Heap (as max-heap): {[(-v, idx) for v, idx in heap]}")

        if i >= k - 1:
            window_start = i - k + 1

            # Lazy deletion
            removed = []
            while heap[0][1] < window_start:
                removed.append(heapq.heappop(heap))

            if removed:
                print(f"  Removed outside window: {[(-v, idx) for v, idx in removed]}")

            max_val = -heap[0][0]
            max_idx = heap[0][1]
            result.append(max_val)

            print(f"  Window [{window_start}:{i}] = {arr[window_start:i+1]}")
            print(f"  Maximum: {max_val} (at index {max_idx})")
            print(f"  Result so far: {result}")

    print("\n" + "=" * 50)
    print(f"Final Result: {result}")
    return result


# ============== Test Cases ==============

def test_max_sliding_window():
    print("=" * 60)
    print("Testing Maximum of Subarrays of Size K")
    print("=" * 60)

    test_cases = [
        # (array, k, expected)
        ([1, 3, -1, -3, 5, 3, 6, 7], 3, [3, 3, 5, 5, 6, 7]),
        ([1, 2, 3, 4, 5], 2, [2, 3, 4, 5]),
        ([5, 4, 3, 2, 1], 3, [5, 4, 3]),
        ([1, 1, 1, 1, 1], 2, [1, 1, 1, 1]),
        ([9, 11], 2, [11]),
        ([7, 2, 4], 2, [7, 4]),
        ([1, -1], 1, [1, -1]),
    ]

    for i, (arr, k, expected) in enumerate(test_cases):
        print(f"\nTest {i + 1}: arr={arr}, k={k}")

        result_heap = max_sliding_window_heap(arr, k)
        result_deque = max_sliding_window_deque(arr, k)
        result_brute = max_sliding_window_brute(arr, k)

        print(f"  Heap solution:  {result_heap}")
        print(f"  Deque solution: {result_deque}")
        print(f"  Brute force:    {result_brute}")
        print(f"  Expected:       {expected}")

        assert result_heap == expected, f"Heap failed"
        assert result_deque == expected, f"Deque failed"
        assert result_brute == expected, f"Brute failed"
        print(f"  PASSED")

    print("\n" + "=" * 60)
    print("All tests passed!")


def demo_visualization():
    print("\n" + "=" * 60)
    print("Step-by-Step Visualization")
    print("=" * 60)

    arr = [1, 3, -1, -3, 5, 3, 6, 7]
    k = 3
    max_sliding_window_visualized(arr, k)


def compare_performance():
    import time

    print("\n" + "=" * 60)
    print("Performance Comparison")
    print("=" * 60)

    # Large array
    arr = list(range(10000, 0, -1))  # Descending order
    k = 100

    # Heap solution
    start = time.time()
    result1 = max_sliding_window_heap(arr, k)
    heap_time = time.time() - start

    # Deque solution
    start = time.time()
    result2 = max_sliding_window_deque(arr, k)
    deque_time = time.time() - start

    # Brute force (smaller array)
    arr_small = arr[:1000]
    k_small = 100
    start = time.time()
    result3 = max_sliding_window_brute(arr_small, k_small)
    brute_time = time.time() - start

    print(f"Array size: {len(arr)}, K: {k}")
    print(f"Heap solution:  {heap_time:.6f}s")
    print(f"Deque solution: {deque_time:.6f}s")
    print(f"Brute force (n=1000): {brute_time:.6f}s")

    assert result1 == result2, "Results don't match!"
    print("\nResults verified to be identical!")


if __name__ == "__main__":
    test_max_sliding_window()
    demo_visualization()
    compare_performance()
