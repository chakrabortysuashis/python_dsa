# Maximum of All Subarrays of Size K

## Problem Statement
Given an array and an integer K, find the maximum for each contiguous subarray of size K.

**Example:**
```
Input: arr = [1, 3, -1, -3, 5, 3, 6, 7], K = 3
Output: [3, 3, 5, 5, 6, 7]

Explanation:
Window [1, 3, -1] -> max = 3
Window [3, -1, -3] -> max = 3
Window [-1, -3, 5] -> max = 5
Window [-3, 5, 3] -> max = 5
Window [5, 3, 6] -> max = 6
Window [3, 6, 7] -> max = 7
```

## Why Heap is Useful Here
- Need to repeatedly find maximum in a sliding window
- Max-heap keeps track of largest element efficiently
- Alternative: Deque (monotonic queue) for O(n) solution

## Heap Operations Used
1. **Insert**: Add new element as window slides
2. **Peek**: Get current maximum
3. **Lazy Deletion**: Remove elements outside window

## Brute Force vs Heap Approach

| Approach | Time | Space |
|----------|------|-------|
| Brute Force | O(n * K) | O(1) |
| **Max-Heap** | **O(n log K)** | **O(K)** |
| Deque (Optimal) | O(n) | O(K) |

## Step-by-Step Heap Operations

```
arr = [1, 3, -1, -3, 5, 3, 6, 7], K = 3

Using Max-Heap (value, index):

Window [0,2]: [1, 3, -1]
Heap: [(-3,1), (-1,0), (1,2)]  # Negated for max-heap
Max = 3 (at index 1)
Result: [3]

Window [1,3]: [3, -1, -3]
Add (-(-3), 3) = (3, 3) but index 0 is out of window
Heap after cleanup: [(-3,1), (-1,2), (3,3)]
Max = 3 (at index 1, still in window)
Result: [3, 3]

Window [2,4]: [-1, -3, 5]
Add (5, 4)
Heap: [(-5,4), (-3,1), ...]
Index 1 is out of window, lazy delete
Max = 5 (at index 4)
Result: [3, 3, 5]

... continue ...
```

## Time and Space Complexity

| Complexity | Value |
|------------|-------|
| Time | O(n log K) - each element pushed/popped once |
| Space | O(K) - heap size |

### Why O(n log K)?
- Each element is inserted once: O(log K)
- Each element is removed once: O(log K)
- Total: O(n log K)

## Algorithm Visualization

```
Array: [1, 3, -1, -3, 5, 3, 6, 7]
        ↑--K=3--↑
        
Step 1: Build initial window
        [1, 3, -1]
        Heap: [(3,1), (1,0), (-1,2)]
        Max: 3

Step 2: Slide window right
        [3, -1, -3]
        Add: (-3, 3)
        Check: heap[0] index >= window_start? Yes (1 >= 1)
        Max: 3

Step 3: Continue sliding...
```

## Key Insights

1. **Lazy Deletion**: Don't remove immediately when element leaves window
   - Only remove when it's the maximum and out of bounds
   - Saves unnecessary heap operations

2. **Store Index**: Store (value, index) pairs to track element positions

3. **Python heapq**: Negate values for max-heap behavior

## Alternative: Monotonic Deque (O(n))

```python
from collections import deque

def max_sliding_window_deque(arr, k):
    dq = deque()  # Store indices
    result = []
    
    for i, num in enumerate(arr):
        # Remove elements outside window
        while dq and dq[0] <= i - k:
            dq.popleft()
        
        # Remove smaller elements (they can't be max)
        while dq and arr[dq[-1]] < num:
            dq.pop()
        
        dq.append(i)
        
        # Add max to result once window is complete
        if i >= k - 1:
            result.append(arr[dq[0]])
    
    return result
```

## Common Mistakes

1. Forgetting to negate values for max-heap in Python
2. Not checking if max element is still in window
3. Off-by-one errors in window boundaries
