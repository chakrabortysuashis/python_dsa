"""
Problem: Merge K Sorted Linked Lists

Merge K sorted linked lists into one sorted list.

Time: O(N log K) where N = total nodes
Space: O(K)
"""

import heapq
from typing import List, Optional


class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

    def __repr__(self):
        vals = []
        node = self
        while node:
            vals.append(str(node.val))
            node = node.next
        return "->".join(vals)


def merge_k_lists(lists: List[Optional[ListNode]]) -> Optional[ListNode]:
    """
    Using Min-Heap.

    Time: O(N log K)
    Space: O(K)
    """
    heap = []

    # Initialize heap with head of each list
    # Store (value, index, node) - index for tie-breaking
    for i, lst in enumerate(lists):
        if lst:
            heapq.heappush(heap, (lst.val, i, lst))

    dummy = ListNode(0)
    current = dummy

    while heap:
        val, i, node = heapq.heappop(heap)
        current.next = node
        current = current.next

        # Push next node from same list
        if node.next:
            heapq.heappush(heap, (node.next.val, i, node.next))

    return dummy.next


def merge_k_lists_divide_conquer(lists: List[Optional[ListNode]]) -> Optional[ListNode]:
    """
    Using Divide and Conquer.

    Time: O(N log K)
    Space: O(log K) recursion stack
    """
    def merge_two(l1, l2):
        dummy = ListNode(0)
        curr = dummy
        while l1 and l2:
            if l1.val <= l2.val:
                curr.next = l1
                l1 = l1.next
            else:
                curr.next = l2
                l2 = l2.next
            curr = curr.next
        curr.next = l1 or l2
        return dummy.next

    if not lists:
        return None
    if len(lists) == 1:
        return lists[0]

    while len(lists) > 1:
        merged = []
        for i in range(0, len(lists), 2):
            if i + 1 < len(lists):
                merged.append(merge_two(lists[i], lists[i + 1]))
            else:
                merged.append(lists[i])
        lists = merged

    return lists[0]


def create_list(arr):
    """Helper to create linked list from array."""
    if not arr:
        return None
    head = ListNode(arr[0])
    curr = head
    for val in arr[1:]:
        curr.next = ListNode(val)
        curr = curr.next
    return head


def list_to_array(head):
    """Helper to convert linked list to array."""
    arr = []
    while head:
        arr.append(head.val)
        head = head.next
    return arr


# ============== Test Cases ==============

def test():
    print("Testing Merge K Sorted Linked Lists")
    print("=" * 50)

    tests = [
        ([[1, 4, 5], [1, 3, 4], [2, 6]], [1, 1, 2, 3, 4, 4, 5, 6]),
        ([[1, 2], [3, 4], [5, 6]], [1, 2, 3, 4, 5, 6]),
        ([[], [1]], [1]),
        ([[]], []),
        ([[1], [2], [3]], [1, 2, 3]),
    ]

    for arrs, expected in tests:
        lists = [create_list(arr) for arr in arrs]
        print(f"Input: {arrs}")

        result = merge_k_lists([create_list(arr) for arr in arrs])
        result_arr = list_to_array(result)
        print(f"Heap method: {result_arr}")

        result_dc = merge_k_lists_divide_conquer([create_list(arr) for arr in arrs])
        result_dc_arr = list_to_array(result_dc)
        print(f"D&C method:  {result_dc_arr}")

        assert result_arr == expected
        assert result_dc_arr == expected
        print("PASSED\n")

    print("All tests passed!")


if __name__ == "__main__":
    test()
