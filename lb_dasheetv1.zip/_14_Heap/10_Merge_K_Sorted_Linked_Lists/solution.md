# Merge K Sorted Linked Lists

## Problem Statement
Merge K sorted linked lists into one sorted linked list.

**Example:**
```
Input: lists = [[1->4->5], [1->3->4], [2->6]]
Output: 1->1->2->3->4->4->5->6
```

## Why Heap is Useful Here
- Same concept as merging K sorted arrays
- Min-heap tracks smallest head among K lists
- Extract min, move to next node in that list

## Algorithm

```
1. Push head of each non-empty list to min-heap
2. While heap not empty:
   - Pop minimum node
   - Add to result list
   - If node has next, push it to heap
3. Return merged list
```

## Time and Space Complexity

| Complexity | Value |
|------------|-------|
| Time | O(N log K) |
| Space | O(K) for heap |

Where N = total nodes, K = number of lists

## Key Implementation

```python
import heapq

def mergeKLists(lists):
    heap = []
    
    # Add first node of each list
    for i, lst in enumerate(lists):
        if lst:
            heapq.heappush(heap, (lst.val, i, lst))
    
    dummy = ListNode(0)
    current = dummy
    
    while heap:
        val, i, node = heapq.heappop(heap)
        current.next = node
        current = current.next
        
        if node.next:
            heapq.heappush(heap, (node.next.val, i, node.next))
    
    return dummy.next
```

## Why Include Index?
- Python's heapq compares tuples element by element
- If two nodes have same value, comparing nodes fails
- Index breaks ties deterministically
