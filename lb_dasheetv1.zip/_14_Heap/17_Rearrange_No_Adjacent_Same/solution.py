"""
Problem: Rearrange Characters (No Two Adjacent Same)

Rearrange string so no two adjacent characters are same.

Time: O(n log k)
Space: O(k)
"""

import heapq
from collections import Counter


def rearrange_string(s):
    """
    Using Max-Heap.

    Greedy: always pick two most frequent characters.
    """
    if not s:
        return ""

    freq = Counter(s)
    n = len(s)

    # Check possibility
    max_freq = max(freq.values())
    if max_freq > (n + 1) // 2:
        return ""

    # Max-heap (negate for max behavior)
    max_heap = [(-count, char) for char, count in freq.items()]
    heapq.heapify(max_heap)

    result = []

    while len(max_heap) >= 2:
        f1, c1 = heapq.heappop(max_heap)
        f2, c2 = heapq.heappop(max_heap)

        result.append(c1)
        result.append(c2)

        if f1 + 1 < 0:
            heapq.heappush(max_heap, (f1 + 1, c1))
        if f2 + 1 < 0:
            heapq.heappush(max_heap, (f2 + 1, c2))

    if max_heap:
        f, c = max_heap[0]
        if f < -1:
            return ""
        result.append(c)

    return "".join(result)


def rearrange_fill_positions(s):
    """
    Alternative: Fill even positions first, then odd.
    """
    if not s:
        return ""

    freq = Counter(s)
    n = len(s)

    # Check possibility
    max_freq = max(freq.values())
    if max_freq > (n + 1) // 2:
        return ""

    # Sort by frequency (descending)
    sorted_chars = sorted(freq.items(), key=lambda x: -x[1])

    result = [''] * n
    idx = 0  # Start at even positions

    for char, count in sorted_chars:
        for _ in range(count):
            if idx >= n:
                idx = 1  # Switch to odd positions
            result[idx] = char
            idx += 2

    return "".join(result)


def is_valid(s):
    """Check if no adjacent characters are same."""
    for i in range(1, len(s)):
        if s[i] == s[i - 1]:
            return False
    return True


# ============== Test Cases ==============

def test():
    print("Testing Rearrange Characters")
    print("=" * 50)

    tests = [
        ("aab", True),
        ("aaab", False),
        ("aabb", True),
        ("aaabbc", True),
        ("abc", True),
        ("aaaabc", False),
        ("a", True),
        ("", True),
    ]

    for s, possible in tests:
        result1 = rearrange_string(s)
        result2 = rearrange_fill_positions(s)

        print(f"Input: '{s}'")
        print(f"  Heap method:     '{result1}' (valid: {is_valid(result1) if result1 else not possible})")
        print(f"  Position method: '{result2}' (valid: {is_valid(result2) if result2 else not possible})")

        if possible:
            assert is_valid(result1) and len(result1) == len(s)
            assert is_valid(result2) and len(result2) == len(s)
        else:
            assert result1 == "" and result2 == ""
        print("  PASSED")

    print("\nAll tests passed!")


if __name__ == "__main__":
    test()
