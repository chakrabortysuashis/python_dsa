# Rearrange Characters (No Two Adjacent Same)

## Problem Statement
Given a string, rearrange characters so no two adjacent characters are the same. Return empty string if not possible.

This is the same as Problem 9 (Reorganize String).

## Why Heap is Useful Here
- Greedy: always pick most frequent character
- Max-heap tracks highest frequency character
- Alternate between top characters

## Key Condition for Possibility
If max frequency > (n+1)/2, impossible.

## Algorithm

```
1. Count character frequencies
2. Check if possible
3. Build max-heap of (frequency, character)
4. While heap >= 2 elements:
   - Pop two most frequent
   - Append both to result
   - Push back if frequency > 0
5. Handle remaining character
```

## Example

```
Input: "aaabbc"
Frequencies: a=3, b=2, c=1

Max-heap: [(3,'a'), (2,'b'), (1,'c')]

Pop (3,'a'), (2,'b'): result = "ab"
Push back: [(2,'a'), (1,'c')]

Pop (2,'a'), (1,'c'): result = "abac"
Push back: [(1,'a')]

Pop (1,'a'): result = "abaca"
Push back: []

One left (b has 1): result = "abacab"

Output: "abacab" (or other valid arrangement)
```

## Time and Space Complexity

| Complexity | Value |
|------------|-------|
| Time | O(n log k), k = unique chars |
| Space | O(k) |

## Alternative: Fill Even/Odd Positions
1. Place most frequent at even indices (0, 2, 4, ...)
2. Place others at remaining positions
