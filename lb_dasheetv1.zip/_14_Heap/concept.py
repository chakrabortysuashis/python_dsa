"""
Heap Data Structure - Complete Implementation from Scratch

This module provides:
1. MaxHeap class - Complete max-heap implementation
2. MinHeap class - Complete min-heap implementation
3. Utility functions for heap operations
4. Demonstration of all heap operations

Author: DSA Learning Course
"""


class MaxHeap:
    """
    Max-Heap Implementation

    Properties:
    - Complete binary tree stored as array
    - Parent >= Children (Max-Heap property)
    - Root is always the maximum element

    Index formulas (0-based):
    - Parent: (i - 1) // 2
    - Left child: 2 * i + 1
    - Right child: 2 * i + 2
    """

    def __init__(self, arr=None):
        """Initialize heap, optionally from an array."""
        self.heap = []
        if arr:
            self.build_heap(arr)

    def __len__(self):
        return len(self.heap)

    def __str__(self):
        return f"MaxHeap({self.heap})"

    def __repr__(self):
        return self.__str__()

    def is_empty(self):
        """Check if heap is empty. O(1)"""
        return len(self.heap) == 0

    def peek(self):
        """Return maximum element without removing. O(1)"""
        if self.is_empty():
            raise IndexError("Heap is empty")
        return self.heap[0]

    def _parent(self, i):
        """Get parent index."""
        return (i - 1) // 2

    def _left_child(self, i):
        """Get left child index."""
        return 2 * i + 1

    def _right_child(self, i):
        """Get right child index."""
        return 2 * i + 2

    def _has_left(self, i):
        """Check if left child exists."""
        return self._left_child(i) < len(self.heap)

    def _has_right(self, i):
        """Check if right child exists."""
        return self._right_child(i) < len(self.heap)

    def _swap(self, i, j):
        """Swap elements at indices i and j."""
        self.heap[i], self.heap[j] = self.heap[j], self.heap[i]

    def _sift_up(self, i):
        """
        Move element at index i UP to restore heap property.
        Used after insertion.

        Time Complexity: O(log n) - at most height of tree swaps
        """
        # While not at root and current > parent
        while i > 0 and self.heap[i] > self.heap[self._parent(i)]:
            parent_idx = self._parent(i)
            self._swap(i, parent_idx)
            i = parent_idx  # Move up

    def _sift_down(self, i):
        """
        Move element at index i DOWN to restore heap property.
        Used after extraction or during heapify.

        Time Complexity: O(log n) - at most height of tree swaps
        """
        while self._has_left(i):
            # Find the larger child
            larger_child_idx = self._left_child(i)

            if self._has_right(i):
                right_idx = self._right_child(i)
                if self.heap[right_idx] > self.heap[larger_child_idx]:
                    larger_child_idx = right_idx

            # If heap property satisfied, stop
            if self.heap[i] >= self.heap[larger_child_idx]:
                break

            # Swap with larger child and continue
            self._swap(i, larger_child_idx)
            i = larger_child_idx

    def insert(self, value):
        """
        Insert a new value into the heap.

        Algorithm:
        1. Add value at the end (maintains complete tree property)
        2. Sift up to restore heap property

        Time Complexity: O(log n)
        Space Complexity: O(1)
        """
        self.heap.append(value)
        self._sift_up(len(self.heap) - 1)

    def extract_max(self):
        """
        Remove and return the maximum element (root).

        Algorithm:
        1. Store root value
        2. Move last element to root
        3. Remove last position
        4. Sift down to restore heap property

        Time Complexity: O(log n)
        Space Complexity: O(1)
        """
        if self.is_empty():
            raise IndexError("Heap is empty")

        max_val = self.heap[0]

        # Move last element to root
        last_val = self.heap.pop()

        if not self.is_empty():
            self.heap[0] = last_val
            self._sift_down(0)

        return max_val

    def build_heap(self, arr):
        """
        Build heap from an array using bottom-up heapify.

        Algorithm:
        1. Copy array to heap
        2. Start from last non-leaf node
        3. Apply sift-down to each node going up to root

        Time Complexity: O(n) - NOT O(n log n)!
        - Most nodes are at bottom levels (need few swaps)
        - Mathematical analysis shows total work = O(n)

        Space Complexity: O(1) auxiliary (O(n) total for heap)
        """
        self.heap = arr.copy()

        # Start from last non-leaf node
        # Leaf nodes (n//2 to n-1) are already valid heaps of size 1
        start_idx = len(self.heap) // 2 - 1

        # Heapify from bottom-up
        for i in range(start_idx, -1, -1):
            self._sift_down(i)

    def heap_sort(self):
        """
        Return sorted array (ascending) using heap sort.
        Note: This destroys the heap.

        Time Complexity: O(n log n)
        Space Complexity: O(n) for output
        """
        sorted_arr = []
        while not self.is_empty():
            sorted_arr.append(self.extract_max())
        return sorted_arr[::-1]  # Reverse for ascending order

    def visualize(self):
        """Print heap as tree structure."""
        if self.is_empty():
            print("Heap is empty")
            return

        print(f"\nMax-Heap Array: {self.heap}")
        print("\nTree visualization:")

        import math
        levels = int(math.log2(len(self.heap))) + 1
        idx = 0

        for level in range(levels):
            nodes_in_level = min(2 ** level, len(self.heap) - idx)
            spacing = 2 ** (levels - level)

            line = " " * (spacing // 2)
            for _ in range(nodes_in_level):
                if idx < len(self.heap):
                    line += f"{self.heap[idx]:^{spacing}}"
                    idx += 1
            print(line)


class MinHeap:
    """
    Min-Heap Implementation

    Properties:
    - Complete binary tree stored as array
    - Parent <= Children (Min-Heap property)
    - Root is always the minimum element
    """

    def __init__(self, arr=None):
        """Initialize heap, optionally from an array."""
        self.heap = []
        if arr:
            self.build_heap(arr)

    def __len__(self):
        return len(self.heap)

    def __str__(self):
        return f"MinHeap({self.heap})"

    def is_empty(self):
        return len(self.heap) == 0

    def peek(self):
        """Return minimum element without removing. O(1)"""
        if self.is_empty():
            raise IndexError("Heap is empty")
        return self.heap[0]

    def _parent(self, i):
        return (i - 1) // 2

    def _left_child(self, i):
        return 2 * i + 1

    def _right_child(self, i):
        return 2 * i + 2

    def _swap(self, i, j):
        self.heap[i], self.heap[j] = self.heap[j], self.heap[i]

    def _sift_up(self, i):
        """Move element up (for min-heap: current < parent)."""
        while i > 0 and self.heap[i] < self.heap[self._parent(i)]:
            self._swap(i, self._parent(i))
            i = self._parent(i)

    def _sift_down(self, i):
        """Move element down (for min-heap: find smaller child)."""
        n = len(self.heap)

        while True:
            smallest = i
            left = self._left_child(i)
            right = self._right_child(i)

            if left < n and self.heap[left] < self.heap[smallest]:
                smallest = left

            if right < n and self.heap[right] < self.heap[smallest]:
                smallest = right

            if smallest == i:
                break

            self._swap(i, smallest)
            i = smallest

    def insert(self, value):
        """Insert value into min-heap. O(log n)"""
        self.heap.append(value)
        self._sift_up(len(self.heap) - 1)

    def extract_min(self):
        """Remove and return minimum element. O(log n)"""
        if self.is_empty():
            raise IndexError("Heap is empty")

        min_val = self.heap[0]
        last_val = self.heap.pop()

        if not self.is_empty():
            self.heap[0] = last_val
            self._sift_down(0)

        return min_val

    def build_heap(self, arr):
        """Build min-heap from array. O(n)"""
        self.heap = arr.copy()
        start_idx = len(self.heap) // 2 - 1

        for i in range(start_idx, -1, -1):
            self._sift_down(i)

    def visualize(self):
        """Print heap as tree structure."""
        if self.is_empty():
            print("Heap is empty")
            return

        print(f"\nMin-Heap Array: {self.heap}")
        print("\nTree visualization:")

        import math
        levels = int(math.log2(len(self.heap))) + 1
        idx = 0

        for level in range(levels):
            nodes_in_level = min(2 ** level, len(self.heap) - idx)
            spacing = 2 ** (levels - level)

            line = " " * (spacing // 2)
            for _ in range(nodes_in_level):
                if idx < len(self.heap):
                    line += f"{self.heap[idx]:^{spacing}}"
                    idx += 1
            print(line)


# ============================================
# Using Python's built-in heapq module
# ============================================

import heapq

def demo_heapq():
    """
    Demonstrate Python's heapq module.

    NOTE: heapq implements MIN-HEAP only!
    For max-heap, negate values.
    """
    print("\n" + "="*50)
    print("Python heapq Module Demo (MIN-HEAP)")
    print("="*50)

    # Create min-heap
    heap = []
    values = [5, 3, 8, 1, 9, 2]

    print(f"\nInserting values: {values}")
    for val in values:
        heapq.heappush(heap, val)
        print(f"  Push {val}: {heap}")

    print(f"\nMin element (peek): {heap[0]}")

    print("\nExtracting all elements:")
    while heap:
        print(f"  Pop: {heapq.heappop(heap)}, remaining: {heap}")

    # Build heap from list - O(n)
    print("\n--- Building heap from list ---")
    arr = [5, 3, 8, 1, 9, 2]
    print(f"Original array: {arr}")
    heapq.heapify(arr)
    print(f"After heapify:  {arr}")

    # Max-heap using negation
    print("\n--- Max-Heap using negation ---")
    max_heap = []
    values = [5, 3, 8, 1, 9, 2]

    for val in values:
        heapq.heappush(max_heap, -val)  # Negate when pushing

    print(f"Max-heap (negated): {max_heap}")
    print("Extracting max values:")
    while max_heap:
        print(f"  Max: {-heapq.heappop(max_heap)}")  # Negate when popping

    # Useful heapq functions
    print("\n--- Other useful functions ---")
    data = [5, 3, 8, 1, 9, 2, 7, 4, 6]
    print(f"Data: {data}")
    print(f"3 largest:  {heapq.nlargest(3, data)}")
    print(f"3 smallest: {heapq.nsmallest(3, data)}")

    # With key function
    items = [('task1', 3), ('task2', 1), ('task3', 2)]
    print(f"\nItems with priority: {items}")
    print(f"Highest priority: {heapq.nsmallest(1, items, key=lambda x: x[1])}")


def demo_custom_heap():
    """Demonstrate custom MaxHeap and MinHeap classes."""
    print("\n" + "="*50)
    print("Custom Heap Implementation Demo")
    print("="*50)

    # Max-Heap demo
    print("\n--- MaxHeap Demo ---")
    max_heap = MaxHeap()
    values = [4, 10, 3, 5, 1, 7, 8, 2]

    print(f"Inserting values: {values}")
    for val in values:
        max_heap.insert(val)
        print(f"  Insert {val}: {max_heap.heap}")

    max_heap.visualize()

    print(f"\nMax element (peek): {max_heap.peek()}")

    print("\nExtracting max elements:")
    while not max_heap.is_empty():
        print(f"  Extract max: {max_heap.extract_max()}, heap: {max_heap.heap}")

    # Build heap from array
    print("\n--- Build Heap from Array (O(n)) ---")
    arr = [4, 10, 3, 5, 1, 7, 8, 2]
    print(f"Original array: {arr}")

    max_heap = MaxHeap(arr)
    print(f"After build_heap: {max_heap.heap}")
    max_heap.visualize()

    # Min-Heap demo
    print("\n--- MinHeap Demo ---")
    min_heap = MinHeap([4, 10, 3, 5, 1, 7, 8, 2])
    print(f"Min-Heap from array: {min_heap.heap}")
    min_heap.visualize()

    print(f"\nMin element (peek): {min_heap.peek()}")

    print("\nExtracting min elements:")
    while not min_heap.is_empty():
        print(f"  Extract min: {min_heap.extract_min()}, heap: {min_heap.heap}")


def demo_heap_sort():
    """Demonstrate heap sort algorithm."""
    print("\n" + "="*50)
    print("Heap Sort Demo")
    print("="*50)

    arr = [64, 34, 25, 12, 22, 11, 90]
    print(f"Original array: {arr}")

    # Using MaxHeap
    heap = MaxHeap(arr.copy())
    sorted_arr = heap.heap_sort()
    print(f"Sorted (ascending): {sorted_arr}")

    # Using heapq
    arr_copy = arr.copy()
    heapq.heapify(arr_copy)
    sorted_heapq = []
    while arr_copy:
        sorted_heapq.append(heapq.heappop(arr_copy))
    print(f"Using heapq:       {sorted_heapq}")


def demo_priority_queue():
    """Demonstrate heap as priority queue."""
    print("\n" + "="*50)
    print("Priority Queue Demo")
    print("="*50)

    # Task scheduling with priorities
    tasks = [
        (3, "Low priority task"),
        (1, "Urgent task"),
        (2, "Medium priority task"),
        (1, "Another urgent task"),
        (4, "Background task"),
    ]

    print("Tasks to schedule (priority, description):")
    for task in tasks:
        print(f"  {task}")

    # Use min-heap (lower number = higher priority)
    pq = []
    for priority, description in tasks:
        heapq.heappush(pq, (priority, description))

    print("\nProcessing tasks by priority:")
    while pq:
        priority, description = heapq.heappop(pq)
        print(f"  Processing: {description} (priority {priority})")


def verify_heap_property(arr, heap_type='max'):
    """Verify if array satisfies heap property."""
    n = len(arr)

    for i in range(n):
        left = 2 * i + 1
        right = 2 * i + 2

        if heap_type == 'max':
            if left < n and arr[i] < arr[left]:
                return False, f"Violation at {i}: {arr[i]} < {arr[left]} (left child)"
            if right < n and arr[i] < arr[right]:
                return False, f"Violation at {i}: {arr[i]} < {arr[right]} (right child)"
        else:  # min
            if left < n and arr[i] > arr[left]:
                return False, f"Violation at {i}: {arr[i]} > {arr[left]} (left child)"
            if right < n and arr[i] > arr[right]:
                return False, f"Violation at {i}: {arr[i]} > {arr[right]} (right child)"

    return True, "Valid heap"


if __name__ == "__main__":
    print("="*60)
    print("       HEAP DATA STRUCTURE - COMPLETE DEMONSTRATION")
    print("="*60)

    demo_custom_heap()
    demo_heapq()
    demo_heap_sort()
    demo_priority_queue()

    # Verification demo
    print("\n" + "="*50)
    print("Heap Property Verification")
    print("="*50)

    valid_max = [100, 50, 70, 30, 40, 60, 65]
    invalid_max = [100, 50, 70, 80, 40, 60, 65]  # 80 > 50, invalid

    print(f"\nArray 1: {valid_max}")
    result, msg = verify_heap_property(valid_max, 'max')
    print(f"Is valid max-heap? {result} - {msg}")

    print(f"\nArray 2: {invalid_max}")
    result, msg = verify_heap_property(invalid_max, 'max')
    print(f"Is valid max-heap? {result} - {msg}")
