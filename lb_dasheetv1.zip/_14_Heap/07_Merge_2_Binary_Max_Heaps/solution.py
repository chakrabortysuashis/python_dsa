"""
Problem: Merge 2 Binary Max Heaps

Merge two binary max-heaps into one max-heap.

Example:
    Input: heap1 = [10, 5, 6, 2], heap2 = [12, 7, 9]
    Output: [12, 10, 9, 2, 5, 7, 6] (or any valid max-heap)
"""


def merge_heaps(heap1, heap2):
    """
    Merge two max-heaps.

    Approach: Concatenate + Build-heap (heapify)

    Time: O(n + m) - build-heap is O(n)
    Space: O(n + m)
    """
    # Concatenate both heaps
    merged = heap1 + heap2
    n = len(merged)

    if n == 0:
        return []

    # Build max-heap using bottom-up heapify
    def sift_down(i):
        while True:
            largest = i
            left = 2 * i + 1
            right = 2 * i + 2

            if left < n and merged[left] > merged[largest]:
                largest = left
            if right < n and merged[right] > merged[largest]:
                largest = right

            if largest != i:
                merged[i], merged[largest] = merged[largest], merged[i]
                i = largest
            else:
                break

    # Start from last non-leaf
    start = n // 2 - 1
    for i in range(start, -1, -1):
        sift_down(i)

    return merged


def merge_heaps_visualized(heap1, heap2):
    """
    Step-by-step visualization.
    """
    print(f"Heap 1: {heap1}")
    print(f"Heap 2: {heap2}")
    print("=" * 50)

    merged = heap1 + heap2
    n = len(merged)
    print(f"Concatenated: {merged}")
    print("\nBuilding max-heap (heapify):")

    def sift_down(i):
        swaps = []
        while True:
            largest = i
            left = 2 * i + 1
            right = 2 * i + 2

            if left < n and merged[left] > merged[largest]:
                largest = left
            if right < n and merged[right] > merged[largest]:
                largest = right

            if largest != i:
                swaps.append((i, largest, merged[i], merged[largest]))
                merged[i], merged[largest] = merged[largest], merged[i]
                i = largest
            else:
                break
        return swaps

    start = n // 2 - 1
    for i in range(start, -1, -1):
        print(f"\nHeapify index {i} (value {merged[i]}):")
        swaps = sift_down(i)
        if swaps:
            for s in swaps:
                print(f"  Swap index {s[0]}({s[2]}) with {s[1]}({s[3]})")
        else:
            print(f"  No swap needed")
        print(f"  Array: {merged}")

    print("\n" + "=" * 50)
    print(f"Merged Max-Heap: {merged}")
    return merged


def is_max_heap(arr):
    """Verify if array is a valid max-heap."""
    n = len(arr)
    for i in range(n):
        left = 2 * i + 1
        right = 2 * i + 2
        if left < n and arr[i] < arr[left]:
            return False
        if right < n and arr[i] < arr[right]:
            return False
    return True


# ============== Test Cases ==============

def test_merge_heaps():
    print("=" * 60)
    print("Testing Merge 2 Binary Max Heaps")
    print("=" * 60)

    test_cases = [
        ([10, 5, 6, 2], [12, 7, 9]),
        ([20, 15, 10], [25, 12]),
        ([5], [10]),
        ([], [1, 2, 3]),
        ([100, 50, 75], [80, 60, 40, 30]),
    ]

    for i, (h1, h2) in enumerate(test_cases):
        print(f"\nTest {i + 1}:")
        print(f"  Heap1: {h1}")
        print(f"  Heap2: {h2}")

        result = merge_heaps(h1.copy(), h2.copy())
        print(f"  Merged: {result}")
        print(f"  Is valid max-heap: {is_max_heap(result)}")

        # Verify
        assert is_max_heap(result), "Result is not a valid max-heap"
        assert len(result) == len(h1) + len(h2), "Wrong size"
        assert sorted(result) == sorted(h1 + h2), "Elements mismatch"
        print(f"  PASSED")

    print("\n" + "=" * 60)
    print("All tests passed!")


def demo():
    print("\n" + "=" * 60)
    print("Visualization Demo")
    print("=" * 60 + "\n")

    heap1 = [10, 5, 6, 2]
    heap2 = [12, 7, 9]
    merge_heaps_visualized(heap1.copy(), heap2.copy())


if __name__ == "__main__":
    test_merge_heaps()
    demo()
