# Merge 2 Binary Max Heaps

## Problem Statement
Given two binary max-heaps as arrays, merge them into a single max-heap.

**Example:**
```
Input:
  Heap1: [10, 5, 6, 2]
  Heap2: [12, 7, 9]
Output: [12, 10, 9, 2, 5, 7, 6]
```

## Why Heap is Useful Here
- Combining two priority queues
- Need to maintain max-heap property after merge
- Build-heap (heapify) is efficient for this

## Approach

### Simple Approach: Concatenate and Heapify
1. Concatenate both arrays
2. Apply build-heap (heapify) - O(n)

This is optimal because build-heap is O(n), not O(n log n)!

## Step-by-Step Operations

```
Heap1: [10, 5, 6, 2]    Heap2: [12, 7, 9]

Step 1: Concatenate
Combined: [10, 5, 6, 2, 12, 7, 9]

Step 2: Build Max-Heap (heapify)
Start from last non-leaf: index = 7//2 - 1 = 2

Index 2 (value 6): children are 12, 7
  6 < 12, swap -> [10, 5, 12, 2, 6, 7, 9]

Index 1 (value 5): children are 2, 6
  5 > 2 and 5 < 6, no swap needed (already heap)

Index 0 (value 10): children are 5, 12
  10 < 12, swap -> [12, 5, 10, 2, 6, 7, 9]
  Continue sift-down: 10 vs 7, 9 -> 10 > 9, stop

Final: [12, 5, 10, 2, 6, 7, 9]

Tree view:
       12
      /  \
     5    10
    / \   / \
   2   6 7   9
```

## Time and Space Complexity

| Complexity | Value |
|------------|-------|
| Time | O(n + m) = O(total elements) |
| Space | O(n + m) for merged array |

### Why O(n), not O(n log n)?
- Build-heap (heapify) is proven to be O(n)
- Most nodes are leaves, need 0 swaps
- Mathematical analysis: sum of all swaps = O(n)

## Alternative Approaches

1. **Insert one by one**: O(m log(n+m)) - worse
2. **Merge then heapify**: O(n+m) - best
3. **Priority queue merge**: O((n+m) log(n+m)) - worse

## Key Insights

1. Don't insert elements one by one - inefficient
2. Concatenate + Heapify is optimal
3. Order in concatenation doesn't matter
4. Both heaps must be same type (both max or both min)
