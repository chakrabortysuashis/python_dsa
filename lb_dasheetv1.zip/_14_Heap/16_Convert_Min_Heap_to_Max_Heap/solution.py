"""
Problem: Convert Min Heap to Max Heap

Convert a min-heap array to max-heap.

Time: O(n)
Space: O(1) - in-place
"""


def convert_min_to_max_heap(arr):
    """
    Convert min-heap to max-heap using build-heap.

    Key insight: Just rebuild as max-heap (ignore existing structure).
    """
    n = len(arr)

    def max_heapify(i):
        """Sift down for max-heap property."""
        while True:
            largest = i
            left = 2 * i + 1
            right = 2 * i + 2

            if left < n and arr[left] > arr[largest]:
                largest = left
            if right < n and arr[right] > arr[largest]:
                largest = right

            if largest != i:
                arr[i], arr[largest] = arr[largest], arr[i]
                i = largest
            else:
                break

    # Build max-heap from last non-leaf to root
    start = n // 2 - 1
    for i in range(start, -1, -1):
        max_heapify(i)

    return arr


def convert_visualized(arr):
    """Step-by-step visualization."""
    print(f"Original (min-heap): {arr}")
    print("=" * 60)

    n = len(arr)
    arr = arr.copy()

    def max_heapify(i):
        swaps = []
        while True:
            largest = i
            left = 2 * i + 1
            right = 2 * i + 2

            if left < n and arr[left] > arr[largest]:
                largest = left
            if right < n and arr[right] > arr[largest]:
                largest = right

            if largest != i:
                swaps.append((i, largest, arr[i], arr[largest]))
                arr[i], arr[largest] = arr[largest], arr[i]
                i = largest
            else:
                break
        return swaps

    start = n // 2 - 1
    for i in range(start, -1, -1):
        print(f"\nHeapify index {i} (value {arr[i]}):")
        swaps = max_heapify(i)
        if swaps:
            for s in swaps:
                print(f"  Swap {s[2]} with {s[3]}")
        else:
            print("  No swap needed")
        print(f"  Array: {arr}")

    print("\n" + "=" * 60)
    print(f"Final (max-heap): {arr}")
    return arr


def is_max_heap(arr):
    """Verify array is valid max-heap."""
    n = len(arr)
    for i in range(n):
        left = 2 * i + 1
        right = 2 * i + 2
        if left < n and arr[i] < arr[left]:
            return False
        if right < n and arr[i] < arr[right]:
            return False
    return True


def is_min_heap(arr):
    """Verify array is valid min-heap."""
    n = len(arr)
    for i in range(n):
        left = 2 * i + 1
        right = 2 * i + 2
        if left < n and arr[i] > arr[left]:
            return False
        if right < n and arr[i] > arr[right]:
            return False
    return True


# ============== Test Cases ==============

def test():
    print("Testing Convert Min Heap to Max Heap")
    print("=" * 50)

    # Test case 1
    min_heap = [3, 5, 9, 6, 8, 20, 10, 12, 18, 9]
    print(f"Input: {min_heap}")
    print(f"Is min-heap: {is_min_heap(min_heap)}")

    result = convert_min_to_max_heap(min_heap.copy())
    print(f"Output: {result}")
    print(f"Is max-heap: {is_max_heap(result)}")

    assert is_max_heap(result), "Not a valid max-heap!"
    print("PASSED\n")

    # Test case 2
    min_heap2 = [1, 2, 3, 4, 5]
    print(f"Input: {min_heap2}")
    result2 = convert_min_to_max_heap(min_heap2.copy())
    print(f"Output: {result2}")
    print(f"Is max-heap: {is_max_heap(result2)}")
    assert is_max_heap(result2)
    print("PASSED")

    print("\nAll tests passed!")


if __name__ == "__main__":
    test()
    print()
    convert_visualized([3, 5, 9, 6, 8, 20, 10])
