# Convert Min Heap to Max Heap

## Problem Statement
Given an array representing a min-heap, convert it to a max-heap.

**Example:**
```
Input:  [3, 5, 9, 6, 8, 20, 10, 12, 18, 9]  (min-heap)
Output: [20, 18, 10, 12, 9, 9, 3, 5, 6, 8]  (max-heap)
```

## Why Heap is Useful Here
- Need to transform heap property
- Build-heap (heapify) is the key operation
- Simple in-place conversion possible

## Approach: Build Max-Heap from Scratch

Since the array contains all elements, we can simply:
1. Ignore the existing min-heap structure
2. Apply max-heapify (build-heap for max-heap)

## Algorithm

```
1. Start from last non-leaf node (n/2 - 1)
2. Apply max-heap sift-down to each node
3. Move towards root

Same as building max-heap from any array!
```

## Step-by-Step

```
Min-heap: [3, 5, 9, 6, 8, 20, 10, 12, 18, 9]

Apply max-heapify:

Start at index 4 (value 8):
  Children: 9 (index 9)
  8 < 9, swap -> [3, 5, 9, 6, 9, 20, 10, 12, 18, 8]

Index 3 (value 6):
  Children: 12, 18
  6 < 18, swap -> [3, 5, 9, 18, 9, 20, 10, 12, 6, 8]

Index 2 (value 9):
  Children: 20, 10
  9 < 20, swap -> [3, 5, 20, 18, 9, 9, 10, 12, 6, 8]

Index 1 (value 5):
  Children: 18, 9
  5 < 18, swap -> [3, 18, 20, 5, 9, 9, 10, 12, 6, 8]
  Continue sift-down at 5: swap with 12
  -> [3, 18, 20, 12, 9, 9, 10, 5, 6, 8]

Index 0 (value 3):
  Children: 18, 20
  3 < 20, swap -> [20, 18, 3, 12, 9, 9, 10, 5, 6, 8]
  Continue sift-down at 3: swap with 10
  -> [20, 18, 10, 12, 9, 9, 3, 5, 6, 8]

Final max-heap: [20, 18, 10, 12, 9, 9, 3, 5, 6, 8]
```

## Time and Space Complexity

| Complexity | Value |
|------------|-------|
| Time | O(n) - build heap is O(n) |
| Space | O(1) - in-place |

## Key Insight
Converting between min-heap and max-heap is simply rebuilding the heap with opposite comparison. The existing heap structure is irrelevant.
