"""
Problem: Minimum Sum of Two Numbers from Array Digits

Form two numbers from array digits such that their sum is minimum.

Time: O(n log n)
Space: O(n)
"""

import heapq


def min_sum_two_numbers_heap(digits):
    """
    Using Min-Heap.

    Extract smallest digits and alternate between two numbers.
    """
    if not digits:
        return 0

    if len(digits) == 1:
        return digits[0]

    # Build min-heap
    heap = digits.copy()
    heapq.heapify(heap)

    num1 = 0
    num2 = 0
    turn = True  # True = num1, False = num2

    while heap:
        digit = heapq.heappop(heap)
        if turn:
            num1 = num1 * 10 + digit
        else:
            num2 = num2 * 10 + digit
        turn = not turn

    return num1 + num2


def min_sum_two_numbers_sort(digits):
    """
    Using Sorting (equivalent approach).
    """
    if not digits:
        return 0

    if len(digits) == 1:
        return digits[0]

    sorted_digits = sorted(digits)

    num1 = 0
    num2 = 0

    for i, d in enumerate(sorted_digits):
        if i % 2 == 0:
            num1 = num1 * 10 + d
        else:
            num2 = num2 * 10 + d

    return num1 + num2


def min_sum_visualized(digits):
    """Step-by-step visualization."""
    print(f"Digits: {digits}")
    print("=" * 50)

    heap = digits.copy()
    heapq.heapify(heap)
    print(f"Min-heap: {sorted(digits)}")

    num1 = 0
    num2 = 0
    turn = True

    step = 1
    while heap:
        digit = heapq.heappop(heap)

        if turn:
            num1 = num1 * 10 + digit
            print(f"Step {step}: Extract {digit} -> num1 = {num1}")
        else:
            num2 = num2 * 10 + digit
            print(f"Step {step}: Extract {digit} -> num2 = {num2}")

        turn = not turn
        step += 1

    print("\n" + "=" * 50)
    print(f"Number 1: {num1}")
    print(f"Number 2: {num2}")
    print(f"Sum: {num1} + {num2} = {num1 + num2}")
    return num1 + num2


# ============== Test Cases ==============

def test():
    print("Testing Min Sum of Two Numbers from Digits")
    print("=" * 50)

    tests = [
        ([6, 8, 4, 5, 2, 3], 604),  # 246 + 358
        ([5, 3, 0, 7, 4], 82),  # 35 + 47 or 30 + 57 etc
        ([1, 2, 3, 4], 37),  # 13 + 24
        ([9, 9, 1, 1], 110),  # 19 + 91
        ([0, 0, 1], 1),  # 0 + 01 = 1
    ]

    for digits, expected in tests:
        result_heap = min_sum_two_numbers_heap(digits)
        result_sort = min_sum_two_numbers_sort(digits)

        print(f"Digits: {digits}")
        print(f"  Heap result: {result_heap}")
        print(f"  Sort result: {result_sort}")
        print(f"  Expected: {expected}")

        assert result_heap == expected
        assert result_sort == expected
        print("  PASSED\n")

    print("All tests passed!")


if __name__ == "__main__":
    test()
    print()
    min_sum_visualized([6, 8, 4, 5, 2, 3])
