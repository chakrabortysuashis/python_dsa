# Minimum Sum of Two Numbers from Array Digits

## Problem Statement
Given an array of digits (0-9), form two numbers using all digits such that their sum is minimum.

**Example:**
```
Input: [6, 8, 4, 5, 2, 3]
Output: 604

Explanation:
Numbers: 358 and 246
Sum: 358 + 246 = 604
```

## Why Heap is Useful Here
- Need to assign smaller digits to higher positions
- Min-heap gives digits in sorted order
- Alternate assignment between two numbers

## Key Insight
- Smaller digits should be at higher place values
- Distribute digits alternately to two numbers
- Both numbers should have similar lengths

## Algorithm

```
1. Build min-heap from all digits
2. Create two numbers (num1, num2)
3. Alternate extracting min and appending to num1 and num2
4. Return num1 + num2
```

## Step-by-Step Example

```
Input: [6, 8, 4, 5, 2, 3]
Min-heap: [2, 3, 4, 5, 6, 8]

Extract 2 -> num1 = 2
Extract 3 -> num2 = 3
Extract 4 -> num1 = 24
Extract 5 -> num2 = 35
Extract 6 -> num1 = 246
Extract 8 -> num2 = 358

Sum = 246 + 358 = 604
```

## Why This Works
- Smallest digits go to leftmost positions (highest place value)
- By alternating, both numbers get similar magnitudes
- This minimizes overall sum

## Time and Space Complexity

| Complexity | Value |
|------------|-------|
| Time | O(n log n) for sorting/heap |
| Space | O(n) for heap |

## Alternative: Sort and Alternate
Same approach but using sort instead of heap.
Heap is useful if digits come in stream.

## Edge Cases
- Handle leading zeros
- Odd number of digits
- All same digits
