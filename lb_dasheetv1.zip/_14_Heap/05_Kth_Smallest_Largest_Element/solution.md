# Kth Smallest and Largest Element

## Problem Statement
Given an array and a number K, find the Kth smallest and Kth largest element.

**Example:**
```
Input: arr = [7, 10, 4, 3, 20, 15], K = 3
Kth Smallest: 7 (sorted: [3, 4, 7, 10, 15, 20])
Kth Largest: 10 (sorted desc: [20, 15, 10, 7, 4, 3])
```

## Why Heap is Useful Here
- Don't need full sorting
- Heap gives us the Kth element efficiently
- Better than sorting when we only need one element

## Heap Operations Used

### For Kth Smallest: Use MAX-HEAP of size K
- Top is largest among K smallest = Kth smallest

### For Kth Largest: Use MIN-HEAP of size K
- Top is smallest among K largest = Kth largest

## Brute Force vs Heap Approach

| Approach | Time | Space |
|----------|------|-------|
| Sort | O(n log n) | O(1) |
| **Heap of size K** | **O(n log K)** | **O(K)** |
| QuickSelect | O(n) average | O(1) |

## Step-by-Step: Finding Kth Largest

```
arr = [7, 10, 4, 3, 20, 15], K = 3
Using MIN-HEAP of size K:

Process 7:  heap = [7]
Process 10: heap = [7, 10]
Process 4:  heap = [4, 7, 10]  (size = K)
Process 3:  3 < 4 (top), skip
Process 20: 20 > 4, replace: heap = [7, 20, 10]
Process 15: 15 > 7, replace: heap = [10, 20, 15]

Kth Largest = heap[0] = 10
```

## Step-by-Step: Finding Kth Smallest

```
arr = [7, 10, 4, 3, 20, 15], K = 3
Using MAX-HEAP of size K:

Process 7:  heap = [-7] -> max = 7
Process 10: heap = [-10, -7] -> max = 10
Process 4:  heap = [-10, -7, -4] -> max = 10 (size = K)
Process 3:  3 < 10 (max), replace: heap = [-7, -3, -4] -> max = 7
Process 20: 20 > 7 (max), skip
Process 15: 15 > 7 (max), skip

Kth Smallest = -heap[0] = 7
```

## Visual Comparison

```
Finding Kth LARGEST (K=3):     Finding Kth SMALLEST (K=3):
Use MIN-heap of size K         Use MAX-heap of size K

       4  <- top (smallest     top ->  10  <- (largest
      / \    of K largest)            /  \     of K smallest)
     7  10                           7    4

After all elements:            After all elements:

      10  <- Kth largest             7  <- Kth smallest
     /  \                           / \
    20  15                         3   4
```

## Time and Space Complexity

| Complexity | Value |
|------------|-------|
| Time | O(n log K) |
| Space | O(K) |

## Key Insight: Why Opposite Heap Types?

### Kth Largest -> MIN-Heap
- Keep K largest elements in heap
- Smallest of these K is at top = Kth largest
- If new element is larger, it kicks out the smallest

### Kth Smallest -> MAX-Heap
- Keep K smallest elements in heap
- Largest of these K is at top = Kth smallest
- If new element is smaller, it kicks out the largest

## Quick Reference

```python
import heapq

# Kth Largest - Min-heap of size K
def kth_largest(arr, k):
    heap = arr[:k]
    heapq.heapify(heap)
    for num in arr[k:]:
        if num > heap[0]:
            heapq.heapreplace(heap, num)
    return heap[0]

# Kth Smallest - Max-heap of size K (negate values)
def kth_smallest(arr, k):
    heap = [-x for x in arr[:k]]
    heapq.heapify(heap)
    for num in arr[k:]:
        if num < -heap[0]:
            heapq.heapreplace(heap, -num)
    return -heap[0]
```

## Common Variations

1. **Stream of numbers**: Maintain heap, return top
2. **Find median**: Two heaps (max + min)
3. **K closest points**: Min-heap with distance
