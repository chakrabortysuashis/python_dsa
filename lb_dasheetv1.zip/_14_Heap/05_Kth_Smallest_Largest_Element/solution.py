"""
Problem: Kth Smallest and Largest Element

Find the Kth smallest and Kth largest element in an array.

Example:
    Input: arr = [7, 10, 4, 3, 20, 15], K = 3
    Kth Smallest: 7
    Kth Largest: 10
"""

import heapq


def kth_largest(arr, k):
    """
    Find Kth largest using MIN-heap of size K.

    Key insight: Top of min-heap = smallest among K largest = Kth largest

    Time: O(n log K)
    Space: O(K)
    """
    if k <= 0 or k > len(arr):
        return None

    min_heap = []

    for num in arr:
        if len(min_heap) < k:
            heapq.heappush(min_heap, num)
        elif num > min_heap[0]:
            heapq.heapreplace(min_heap, num)

    return min_heap[0]


def kth_smallest(arr, k):
    """
    Find Kth smallest using MAX-heap of size K.

    Key insight: Top of max-heap = largest among K smallest = Kth smallest

    Time: O(n log K)
    Space: O(K)
    """
    if k <= 0 or k > len(arr):
        return None

    # Max-heap using negation
    max_heap = []

    for num in arr:
        if len(max_heap) < k:
            heapq.heappush(max_heap, -num)
        elif num < -max_heap[0]:
            heapq.heapreplace(max_heap, -num)

    return -max_heap[0]


def kth_largest_nsmallest(arr, k):
    """
    Using heapq.nlargest (built-in).
    Returns Kth largest element.
    """
    return heapq.nlargest(k, arr)[-1]


def kth_smallest_nsmallest(arr, k):
    """
    Using heapq.nsmallest (built-in).
    Returns Kth smallest element.
    """
    return heapq.nsmallest(k, arr)[-1]


def kth_element_quickselect(arr, k, find_largest=True):
    """
    QuickSelect algorithm - O(n) average time.

    Time: O(n) average, O(n^2) worst
    Space: O(1)
    """
    import random

    arr = arr.copy()

    if find_largest:
        k = len(arr) - k  # Convert to index in sorted order

    def partition(left, right):
        pivot_idx = random.randint(left, right)
        pivot = arr[pivot_idx]
        arr[pivot_idx], arr[right] = arr[right], arr[pivot_idx]
        store_idx = left

        for i in range(left, right):
            if arr[i] < pivot:
                arr[store_idx], arr[i] = arr[i], arr[store_idx]
                store_idx += 1

        arr[store_idx], arr[right] = arr[right], arr[store_idx]
        return store_idx

    left, right = 0, len(arr) - 1

    while left <= right:
        pivot_idx = partition(left, right)

        if pivot_idx == k:
            return arr[pivot_idx]
        elif pivot_idx < k:
            left = pivot_idx + 1
        else:
            right = pivot_idx - 1

    return None


def kth_element_sort(arr, k, find_largest=True):
    """
    Using sorting - O(n log n).
    """
    sorted_arr = sorted(arr, reverse=find_largest)
    return sorted_arr[k - 1]


def find_kth_visualized(arr, k):
    """
    Step-by-step visualization for both Kth largest and smallest.
    """
    print(f"Array: {arr}")
    print(f"K = {k}")
    print("=" * 60)

    # Kth Largest
    print("\n--- Finding Kth LARGEST (using MIN-heap of size K) ---")
    min_heap = []

    for i, num in enumerate(arr):
        print(f"\nStep {i + 1}: Process {num}")

        if len(min_heap) < k:
            heapq.heappush(min_heap, num)
            print(f"  Heap size < K, add {num}")
        elif num > min_heap[0]:
            old = heapq.heapreplace(min_heap, num)
            print(f"  {num} > {old} (top), replace")
        else:
            print(f"  {num} <= {min_heap[0]} (top), skip")

        print(f"  Min-Heap: {min_heap}")

    print(f"\n  >> Kth Largest = {min_heap[0]}")

    # Kth Smallest
    print("\n\n--- Finding Kth SMALLEST (using MAX-heap of size K) ---")
    max_heap = []

    for i, num in enumerate(arr):
        print(f"\nStep {i + 1}: Process {num}")

        if len(max_heap) < k:
            heapq.heappush(max_heap, -num)
            print(f"  Heap size < K, add {num}")
        elif num < -max_heap[0]:
            old = -heapq.heapreplace(max_heap, -num)
            print(f"  {num} < {old} (top), replace")
        else:
            print(f"  {num} >= {-max_heap[0]} (top), skip")

        print(f"  Max-Heap: {[-x for x in max_heap]}")

    print(f"\n  >> Kth Smallest = {-max_heap[0]}")

    return min_heap[0], -max_heap[0]


# ============== Test Cases ==============

def test_kth_element():
    print("=" * 60)
    print("Testing Kth Smallest and Largest Element")
    print("=" * 60)

    test_cases = [
        # (array, k, kth_largest, kth_smallest)
        ([7, 10, 4, 3, 20, 15], 3, 10, 7),
        ([1, 2, 3, 4, 5], 1, 5, 1),
        ([1, 2, 3, 4, 5], 5, 1, 5),
        ([5, 5, 5, 5], 2, 5, 5),
        ([12, 3, 5, 7, 19], 2, 12, 5),
        ([7, 4, 6, 3, 9, 1], 3, 6, 4),
    ]

    for i, (arr, k, exp_largest, exp_smallest) in enumerate(test_cases):
        print(f"\nTest {i + 1}: arr={arr}, k={k}")

        # Test all methods
        result_largest = kth_largest(arr, k)
        result_smallest = kth_smallest(arr, k)
        result_sort_l = kth_element_sort(arr, k, True)
        result_sort_s = kth_element_sort(arr, k, False)
        result_qs_l = kth_element_quickselect(arr, k, True)
        result_qs_s = kth_element_quickselect(arr, k, False)

        print(f"  Kth Largest:  heap={result_largest}, sort={result_sort_l}, qs={result_qs_l}")
        print(f"  Kth Smallest: heap={result_smallest}, sort={result_sort_s}, qs={result_qs_s}")
        print(f"  Expected:     largest={exp_largest}, smallest={exp_smallest}")

        assert result_largest == exp_largest
        assert result_smallest == exp_smallest
        assert result_sort_l == exp_largest
        assert result_sort_s == exp_smallest
        print(f"  PASSED")

    print("\n" + "=" * 60)
    print("All tests passed!")


def demo_visualization():
    print("\n" + "=" * 60)
    print("Step-by-Step Visualization")
    print("=" * 60)

    arr = [7, 10, 4, 3, 20, 15]
    k = 3
    find_kth_visualized(arr, k)


if __name__ == "__main__":
    test_kth_element()
    demo_visualization()
