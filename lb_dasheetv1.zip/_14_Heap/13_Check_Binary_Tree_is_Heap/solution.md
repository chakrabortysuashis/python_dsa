# Check if Binary Tree is Heap

## Problem Statement
Given a binary tree, check if it represents a valid heap (max-heap or min-heap).

## Heap Properties to Check
1. **Complete Binary Tree**: All levels filled except last, last level filled left to right
2. **Heap Property**: Parent >= children (max-heap) or Parent <= children (min-heap)

## Approach

### Check Completeness
- Count total nodes
- For node at index i, left child at 2i+1, right at 2i+2
- All indices should be < total count

### Check Heap Property
- DFS/BFS to verify parent-child relationship
- For max-heap: every node >= its children

## Algorithm

```python
def is_heap(root):
    if not root:
        return True

    # Count nodes
    def count_nodes(node):
        if not node:
            return 0
        return 1 + count_nodes(node.left) + count_nodes(node.right)

    total = count_nodes(root)

    # Check completeness and heap property
    def check(node, index):
        if not node:
            return True

        # Completeness: index should be < total
        if index >= total:
            return False

        # Heap property (max-heap)
        if node.left and node.val < node.left.val:
            return False
        if node.right and node.val < node.right.val:
            return False

        return check(node.left, 2*index + 1) and check(node.right, 2*index + 2)

    return check(root, 0)
```

## Time and Space Complexity

| Complexity | Value |
|------------|-------|
| Time | O(n) |
| Space | O(h) - recursion stack |

## Key Points
1. Both conditions must be satisfied
2. Can use level-order traversal as alternative
3. Empty tree is valid heap
