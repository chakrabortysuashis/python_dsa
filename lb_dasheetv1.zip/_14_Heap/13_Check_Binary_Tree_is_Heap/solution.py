"""
Problem: Check if Binary Tree is Heap

Check if a binary tree satisfies heap properties:
1. Complete binary tree
2. Heap property (max-heap: parent >= children)

Time: O(n)
Space: O(h) for recursion
"""

from collections import deque


class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right


def is_heap(root) -> bool:
    """
    Check if tree is a valid max-heap.
    """
    if not root:
        return True

    # Count total nodes
    def count_nodes(node):
        if not node:
            return 0
        return 1 + count_nodes(node.left) + count_nodes(node.right)

    total = count_nodes(root)

    # Check completeness and max-heap property
    def check(node, index):
        if not node:
            return True

        # Completeness check: index must be < total
        if index >= total:
            return False

        # Max-heap property
        if node.left and node.val < node.left.val:
            return False
        if node.right and node.val < node.right.val:
            return False

        return check(node.left, 2 * index + 1) and check(node.right, 2 * index + 2)

    return check(root, 0)


def is_heap_bfs(root) -> bool:
    """
    BFS approach using level-order traversal.
    """
    if not root:
        return True

    queue = deque([root])
    null_found = False

    while queue:
        node = queue.popleft()

        if node is None:
            null_found = True
        else:
            # After seeing null, should not see non-null (completeness)
            if null_found:
                return False

            # Max-heap property
            if node.left and node.val < node.left.val:
                return False
            if node.right and node.val < node.right.val:
                return False

            queue.append(node.left)
            queue.append(node.right)

    return True


def is_min_heap(root) -> bool:
    """Check if tree is valid min-heap."""
    if not root:
        return True

    def count_nodes(node):
        if not node:
            return 0
        return 1 + count_nodes(node.left) + count_nodes(node.right)

    total = count_nodes(root)

    def check(node, index):
        if not node:
            return True
        if index >= total:
            return False
        if node.left and node.val > node.left.val:
            return False
        if node.right and node.val > node.right.val:
            return False
        return check(node.left, 2 * index + 1) and check(node.right, 2 * index + 2)

    return check(root, 0)


# ============== Test Cases ==============

def test():
    print("Testing Check Binary Tree is Heap")
    print("=" * 50)

    # Valid max-heap
    #       10
    #      /  \
    #     9    8
    #    / \
    #   7   6
    root1 = TreeNode(10)
    root1.left = TreeNode(9)
    root1.right = TreeNode(8)
    root1.left.left = TreeNode(7)
    root1.left.right = TreeNode(6)

    print("Test 1: Valid max-heap")
    assert is_heap(root1) == True
    assert is_heap_bfs(root1) == True
    print("PASSED")

    # Not complete (missing left child before right)
    #       10
    #      /  \
    #     9    8
    #      \
    #       6
    root2 = TreeNode(10)
    root2.left = TreeNode(9)
    root2.right = TreeNode(8)
    root2.left.right = TreeNode(6)  # Wrong: should have left first

    print("\nTest 2: Not complete")
    assert is_heap(root2) == False
    assert is_heap_bfs(root2) == False
    print("PASSED")

    # Violates heap property
    #       5
    #      / \
    #     10  8
    root3 = TreeNode(5)
    root3.left = TreeNode(10)  # 10 > 5, violates max-heap
    root3.right = TreeNode(8)

    print("\nTest 3: Violates heap property")
    assert is_heap(root3) == False
    assert is_heap_bfs(root3) == False
    print("PASSED")

    # Single node
    root4 = TreeNode(1)
    print("\nTest 4: Single node")
    assert is_heap(root4) == True
    print("PASSED")

    # Empty tree
    print("\nTest 5: Empty tree")
    assert is_heap(None) == True
    print("PASSED")

    print("\n" + "=" * 50)
    print("All tests passed!")


if __name__ == "__main__":
    test()
