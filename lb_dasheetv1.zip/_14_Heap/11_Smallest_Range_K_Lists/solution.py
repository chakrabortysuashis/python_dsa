"""
Problem: Smallest Range Covering Elements from K Lists

Find smallest range [a, b] with at least one element from each list.

Time: O(N log K)
Space: O(K)
"""

import heapq
from typing import List


def smallest_range(lists: List[List[int]]) -> List[int]:
    """
    Using Min-Heap.

    Strategy:
    - Keep one element from each list in heap
    - Track current max
    - Range = [heap_min, current_max]
    - Pop min, push next from same list
    """
    heap = []  # (value, list_index, element_index)
    current_max = float('-inf')

    # Initialize with first element of each list
    for i, lst in enumerate(lists):
        if lst:
            heapq.heappush(heap, (lst[0], i, 0))
            current_max = max(current_max, lst[0])

    best_range = [heap[0][0], current_max]

    while True:
        min_val, list_idx, elem_idx = heapq.heappop(heap)

        # Check if this is a better range
        if current_max - min_val < best_range[1] - best_range[0]:
            best_range = [min_val, current_max]

        # Move to next element in the same list
        if elem_idx + 1 < len(lists[list_idx]):
            next_val = lists[list_idx][elem_idx + 1]
            heapq.heappush(heap, (next_val, list_idx, elem_idx + 1))
            current_max = max(current_max, next_val)
        else:
            # One list exhausted, can't improve further
            break

    return best_range


def smallest_range_visualized(lists: List[List[int]]) -> List[int]:
    """Step-by-step visualization."""
    print("Lists:")
    for i, lst in enumerate(lists):
        print(f"  List {i}: {lst}")
    print("=" * 50)

    heap = []
    current_max = float('-inf')

    for i, lst in enumerate(lists):
        if lst:
            heapq.heappush(heap, (lst[0], i, 0))
            current_max = max(current_max, lst[0])

    best_range = [heap[0][0], current_max]
    print(f"Initial: heap={[(v,l,e) for v,l,e in sorted(heap)]}, max={current_max}")
    print(f"Range: {best_range}, size={best_range[1]-best_range[0]}")

    step = 1
    while True:
        min_val, list_idx, elem_idx = heapq.heappop(heap)

        print(f"\nStep {step}:")
        print(f"  Pop: {min_val} from list {list_idx}")

        if current_max - min_val < best_range[1] - best_range[0]:
            best_range = [min_val, current_max]
            print(f"  New best range: {best_range}")

        if elem_idx + 1 < len(lists[list_idx]):
            next_val = lists[list_idx][elem_idx + 1]
            heapq.heappush(heap, (next_val, list_idx, elem_idx + 1))
            current_max = max(current_max, next_val)
            print(f"  Push: {next_val} from list {list_idx}")
            print(f"  Current range: [{heap[0][0]}, {current_max}]")
        else:
            print(f"  List {list_idx} exhausted. Stop.")
            break

        step += 1

    print("\n" + "=" * 50)
    print(f"Smallest Range: {best_range}")
    return best_range


# ============== Test Cases ==============

def test():
    print("Testing Smallest Range")
    print("=" * 50)

    tests = [
        ([[4, 10, 15, 24, 26], [0, 9, 12, 20], [5, 18, 22, 30]], [20, 24]),
        ([[1, 2, 3], [1, 2, 3], [1, 2, 3]], [1, 1]),
        ([[1], [2], [3]], [1, 3]),
    ]

    for lists, expected in tests:
        result = smallest_range(lists)
        print(f"Lists: {lists}")
        print(f"Result: {result}, Expected: {expected}")
        assert result == expected
        print("PASSED\n")

    print("All tests passed!")


if __name__ == "__main__":
    test()
    print()
    smallest_range_visualized([[4, 10, 15], [0, 9, 12], [5, 18, 22]])
