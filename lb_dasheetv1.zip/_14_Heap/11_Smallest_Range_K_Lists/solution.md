# Smallest Range Covering Elements from K Lists

## Problem Statement
Given K sorted lists, find the smallest range [a, b] that includes at least one element from each list.

**Example:**
```
Input: lists = [[4,10,15,24,26], [0,9,12,20], [5,18,22,30]]
Output: [20, 24]
Explanation: 20 from list 1, 24 from list 0, 22 from list 2
```

## Why Heap is Useful Here
- Need to track minimum element while having one from each list
- Min-heap efficiently finds current minimum
- Track maximum separately

## Algorithm

```
1. Initialize heap with first element from each list
2. Track current max among these elements
3. While all lists represented:
   - Current range = [heap_min, current_max]
   - Update best range if smaller
   - Pop minimum, push its next element
   - Update max if needed
4. Stop when any list is exhausted
```

## Step-by-Step

```
Lists: [[4,10,15], [0,9,12], [5,18]]

Initial: heap = [(0,1), (4,0), (5,2)], max = 5
Range: [0, 5], size = 5

Pop 0, push 9: heap = [(4,0), (5,2), (9,1)], max = 9
Range: [4, 9], size = 5

Pop 4, push 10: heap = [(5,2), (9,1), (10,0)], max = 10
Range: [5, 10], size = 5

Pop 5, push 18: heap = [(9,1), (10,0), (18,2)], max = 18
Range: [9, 18], size = 9 (worse)

Continue...
```

## Time and Space Complexity

| Complexity | Value |
|------------|-------|
| Time | O(N log K) |
| Space | O(K) |

## Key Insight
- Heap tracks minimum
- Variable tracks maximum
- When we pop, the new element might be new max
