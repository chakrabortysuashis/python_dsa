# Reorganize String

## Problem Statement
Given a string, rearrange characters so that no two adjacent characters are the same. Return empty string if not possible.

**Example:**
```
Input: "aab"
Output: "aba"

Input: "aaab"
Output: "" (not possible)
```

## Why Heap is Useful Here
- Need to greedily pick most frequent character
- Max-heap efficiently tracks highest frequency
- Ensures we alternate between most common characters

## Key Insight
If any character appears more than (n+1)/2 times, it's impossible.

## Algorithm

```
1. Count frequency of each character
2. Build max-heap of (frequency, character)
3. While heap has >= 2 elements:
   - Pop two most frequent
   - Append both to result
   - Decrease frequencies, push back if > 0
4. If one element remains with freq=1, append it
5. Return result
```

## Step-by-Step Example

```
Input: "aab"
Frequencies: a=2, b=1

Max-Heap: [(2,'a'), (1,'b')]

Step 1: Pop (2,'a') and (1,'b')
Result: "ab"
Push back: (1,'a')
Heap: [(1,'a')]

Step 2: Only one left with freq=1
Result: "aba"

Output: "aba"
```

## Time and Space Complexity

| Complexity | Value |
|------------|-------|
| Time | O(n log k) where k = unique chars |
| Space | O(k) for heap |

## Why This Works
- Always picking two most frequent ensures alternation
- Decreasing count prevents overuse
- Max-heap maintains optimal selection order
