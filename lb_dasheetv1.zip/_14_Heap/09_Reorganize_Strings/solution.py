"""
Problem: Reorganize String

Rearrange characters so no two adjacent are the same.

Example:
    Input: "aab"
    Output: "aba"
"""

import heapq
from collections import Counter


def reorganize_string(s):
    """
    Using Max-Heap.

    Time: O(n log k) where k = unique characters
    Space: O(k)
    """
    freq = Counter(s)
    n = len(s)

    # Check if possible
    max_freq = max(freq.values())
    if max_freq > (n + 1) // 2:
        return ""

    # Max-heap: (-frequency, character)
    max_heap = [(-count, char) for char, count in freq.items()]
    heapq.heapify(max_heap)

    result = []

    while len(max_heap) >= 2:
        # Pop two most frequent
        freq1, char1 = heapq.heappop(max_heap)
        freq2, char2 = heapq.heappop(max_heap)

        result.append(char1)
        result.append(char2)

        # Push back if frequency remains
        if freq1 + 1 < 0:  # freq1 is negative
            heapq.heappush(max_heap, (freq1 + 1, char1))
        if freq2 + 1 < 0:
            heapq.heappush(max_heap, (freq2 + 1, char2))

    # Handle remaining character
    if max_heap:
        freq, char = max_heap[0]
        if freq < -1:  # More than 1 remaining
            return ""
        result.append(char)

    return "".join(result)


def reorganize_string_visualized(s):
    """Step-by-step visualization."""
    print(f"Input: '{s}'")
    freq = Counter(s)
    print(f"Frequencies: {dict(freq)}")
    print("=" * 50)

    n = len(s)
    max_freq = max(freq.values())

    if max_freq > (n + 1) // 2:
        print(f"Impossible! Max freq {max_freq} > (n+1)/2 = {(n+1)//2}")
        return ""

    max_heap = [(-count, char) for char, count in freq.items()]
    heapq.heapify(max_heap)
    print(f"Initial heap: {[(-f, c) for f, c in max_heap]}")

    result = []
    step = 1

    while len(max_heap) >= 2:
        freq1, char1 = heapq.heappop(max_heap)
        freq2, char2 = heapq.heappop(max_heap)

        result.append(char1)
        result.append(char2)

        print(f"\nStep {step}:")
        print(f"  Pop '{char1}'(freq={-freq1}) and '{char2}'(freq={-freq2})")
        print(f"  Result: '{''.join(result)}'")

        if freq1 + 1 < 0:
            heapq.heappush(max_heap, (freq1 + 1, char1))
        if freq2 + 1 < 0:
            heapq.heappush(max_heap, (freq2 + 1, char2))

        print(f"  Heap: {[(-f, c) for f, c in max_heap]}")
        step += 1

    if max_heap:
        _, char = max_heap[0]
        result.append(char)
        print(f"\nAppend remaining: '{char}'")

    ans = "".join(result)
    print("\n" + "=" * 50)
    print(f"Output: '{ans}'")
    return ans


def is_valid(s):
    """Check if string has no adjacent same characters."""
    for i in range(1, len(s)):
        if s[i] == s[i-1]:
            return False
    return True


# ============== Test Cases ==============

def test():
    print("Testing Reorganize String")
    print("=" * 50)

    tests = [
        ("aab", True),
        ("aaab", False),
        ("aabb", True),
        ("abc", True),
        ("aaabbc", True),
        ("a", True),
        ("aa", False),
    ]

    for s, possible in tests:
        result = reorganize_string(s)
        valid = is_valid(result) if result else not possible
        print(f"'{s}' -> '{result}' (valid: {valid})")
        assert valid, f"Failed for {s}"

    print("\nAll tests passed!")


if __name__ == "__main__":
    test()
    print()
    reorganize_string_visualized("aabbc")
