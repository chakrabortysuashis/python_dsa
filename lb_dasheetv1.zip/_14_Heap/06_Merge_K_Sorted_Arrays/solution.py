"""
Problem: Merge K Sorted Arrays

Given K sorted arrays, merge them into one sorted array.

Example:
    Input: [[1, 4, 7], [2, 5, 8], [3, 6, 9]]
    Output: [1, 2, 3, 4, 5, 6, 7, 8, 9]
"""

import heapq


def merge_k_sorted_heap(arrays):
    """
    Using Min-Heap of size K.

    Approach:
    - Initialize heap with first element from each array
    - Extract min, add to result
    - Push next element from same array

    Time: O(N log K) where N = total elements
    Space: O(K) for heap + O(N) for result
    """
    if not arrays:
        return []

    min_heap = []
    result = []

    # Initialize heap with (value, array_index, element_index)
    for i, arr in enumerate(arrays):
        if arr:
            heapq.heappush(min_heap, (arr[0], i, 0))

    while min_heap:
        val, arr_idx, elem_idx = heapq.heappop(min_heap)
        result.append(val)

        # Push next element from same array
        if elem_idx + 1 < len(arrays[arr_idx]):
            next_val = arrays[arr_idx][elem_idx + 1]
            heapq.heappush(min_heap, (next_val, arr_idx, elem_idx + 1))

    return result


def merge_k_sorted_divide_conquer(arrays):
    """
    Using Divide and Conquer (merge pairs).

    Time: O(N log K)
    Space: O(N)
    """
    if not arrays:
        return []

    def merge_two(arr1, arr2):
        result = []
        i = j = 0
        while i < len(arr1) and j < len(arr2):
            if arr1[i] <= arr2[j]:
                result.append(arr1[i])
                i += 1
            else:
                result.append(arr2[j])
                j += 1
        result.extend(arr1[i:])
        result.extend(arr2[j:])
        return result

    while len(arrays) > 1:
        merged = []
        for i in range(0, len(arrays), 2):
            if i + 1 < len(arrays):
                merged.append(merge_two(arrays[i], arrays[i + 1]))
            else:
                merged.append(arrays[i])
        arrays = merged

    return arrays[0] if arrays else []


def merge_k_sorted_brute(arrays):
    """
    Brute force: Concatenate and sort.

    Time: O(N log N)
    Space: O(N)
    """
    result = []
    for arr in arrays:
        result.extend(arr)
    return sorted(result)


def merge_k_sorted_visualized(arrays):
    """
    Step-by-step visualization.
    """
    print("Input Arrays:")
    for i, arr in enumerate(arrays):
        print(f"  Array {i}: {arr}")
    print("\nMerging with Min-Heap:")
    print("=" * 50)

    min_heap = []
    result = []

    # Initialize
    for i, arr in enumerate(arrays):
        if arr:
            heapq.heappush(min_heap, (arr[0], i, 0))

    print(f"Initial heap: {[(v, a, e) for v, a, e in min_heap]}")

    step = 1
    while min_heap:
        val, arr_idx, elem_idx = heapq.heappop(min_heap)
        result.append(val)

        print(f"\nStep {step}:")
        print(f"  Extract: {val} from array {arr_idx}")
        print(f"  Result: {result}")

        if elem_idx + 1 < len(arrays[arr_idx]):
            next_val = arrays[arr_idx][elem_idx + 1]
            heapq.heappush(min_heap, (next_val, arr_idx, elem_idx + 1))
            print(f"  Push: {next_val} from array {arr_idx}")

        print(f"  Heap: {[(v, a, e) for v, a, e in min_heap]}")
        step += 1

    print("\n" + "=" * 50)
    print(f"Final merged array: {result}")
    return result


# ============== Test Cases ==============

def test_merge_k_sorted():
    print("=" * 60)
    print("Testing Merge K Sorted Arrays")
    print("=" * 60)

    test_cases = [
        ([[1, 4, 7], [2, 5, 8], [3, 6, 9]], [1, 2, 3, 4, 5, 6, 7, 8, 9]),
        ([[1, 3, 5], [2, 4, 6]], [1, 2, 3, 4, 5, 6]),
        ([[1], [2], [3]], [1, 2, 3]),
        ([[1, 2, 3]], [1, 2, 3]),
        ([[], [1, 2], []], [1, 2]),
        ([[1, 5, 9], [2, 6], [3, 7, 10, 11]], [1, 2, 3, 5, 6, 7, 9, 10, 11]),
    ]

    for i, (arrays, expected) in enumerate(test_cases):
        print(f"\nTest {i + 1}: {arrays}")

        result_heap = merge_k_sorted_heap([arr.copy() for arr in arrays])
        result_dc = merge_k_sorted_divide_conquer([arr.copy() for arr in arrays])
        result_brute = merge_k_sorted_brute(arrays)

        print(f"  Heap:     {result_heap}")
        print(f"  D&C:      {result_dc}")
        print(f"  Brute:    {result_brute}")
        print(f"  Expected: {expected}")

        assert result_heap == expected
        assert result_dc == expected
        assert result_brute == expected
        print(f"  PASSED")

    print("\n" + "=" * 60)
    print("All tests passed!")


def demo_visualization():
    print("\n" + "=" * 60)
    print("Step-by-Step Visualization")
    print("=" * 60 + "\n")

    arrays = [[1, 4, 7], [2, 5, 8], [3, 6, 9]]
    merge_k_sorted_visualized(arrays)


if __name__ == "__main__":
    test_merge_k_sorted()
    demo_visualization()
