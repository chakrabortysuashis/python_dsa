# Merge K Sorted Arrays

## Problem Statement
Given K sorted arrays, merge them into one sorted array.

**Example:**
```
Input: arrays = [[1, 4, 7], [2, 5, 8], [3, 6, 9]]
Output: [1, 2, 3, 4, 5, 6, 7, 8, 9]
```

## Why Heap is Useful Here
- Need to repeatedly find minimum among K elements
- Min-heap efficiently tracks the smallest element across K arrays
- Classic heap application

## Heap Operations Used
- **Min-Heap** of size K
- Store (value, array_index, element_index) tuples
- Extract-min and push next element from same array

## Brute Force vs Heap Approach

| Approach | Time | Space |
|----------|------|-------|
| Concatenate & Sort | O(N log N) | O(N) |
| **Min-Heap of K** | **O(N log K)** | **O(K)** |

Where N = total elements, K = number of arrays

## Step-by-Step Heap Operations

```
arrays = [[1, 4, 7], [2, 5, 8], [3, 6, 9]]

Initial heap (first element from each):
Heap: [(1,0,0), (2,1,0), (3,2,0)]
       value, arr_idx, elem_idx

Step 1: Extract (1,0,0), push arr[0][1]=4
Result: [1]
Heap: [(2,1,0), (3,2,0), (4,0,1)]

Step 2: Extract (2,1,0), push arr[1][1]=5
Result: [1, 2]
Heap: [(3,2,0), (4,0,1), (5,1,1)]

Step 3: Extract (3,2,0), push arr[2][1]=6
Result: [1, 2, 3]
Heap: [(4,0,1), (5,1,1), (6,2,1)]

... continue until all elements processed ...

Final: [1, 2, 3, 4, 5, 6, 7, 8, 9]
```

## Visual Representation

```
Arrays:    [1, 4, 7]    [2, 5, 8]    [3, 6, 9]
            ^            ^            ^
            |            |            |
            +------------+------------+
                         |
                    Min-Heap
                        1
                       / \
                      2   3

After extracting 1, add 4 from same array:
                        2
                       / \
                      3   4
```

## Time and Space Complexity

| Complexity | Value |
|------------|-------|
| Time | O(N log K) |
| Space | O(K) + O(N) for result |

### Why O(N log K)?
- Each of N elements: one push + one pop
- Heap operations on size-K heap: O(log K)
- Total: O(N log K)

## Algorithm

```python
import heapq

def merge_k_sorted(arrays):
    min_heap = []
    result = []

    # Initialize heap with first element of each array
    for i, arr in enumerate(arrays):
        if arr:
            heapq.heappush(min_heap, (arr[0], i, 0))

    while min_heap:
        val, arr_idx, elem_idx = heapq.heappop(min_heap)
        result.append(val)

        # Push next element from same array
        if elem_idx + 1 < len(arrays[arr_idx]):
            next_val = arrays[arr_idx][elem_idx + 1]
            heapq.heappush(min_heap, (next_val, arr_idx, elem_idx + 1))

    return result
```

## Key Insights

1. **Heap Size**: Always K (one element per array)
2. **What to Store**: (value, array_index, element_index)
3. **When to Push**: After extracting, push next from same array

## Common Variations

1. **Merge K Sorted Lists**: Same concept with linked lists
2. **External Sort**: Merge sorted chunks from disk
3. **Merge with Duplicates**: Track source for stable merge
