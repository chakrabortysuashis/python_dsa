"""
Problem: Connect N Ropes with Minimum Cost

Connect ropes with minimum total cost (cost = sum of lengths being connected).

Time: O(n log n)
Space: O(n)
"""

import heapq


def min_cost_to_connect_ropes(ropes):
    """
    Using Min-Heap with greedy approach.

    Always connect two smallest ropes first.
    """
    if len(ropes) <= 1:
        return 0

    heapq.heapify(ropes)
    total_cost = 0

    while len(ropes) > 1:
        # Extract two smallest
        first = heapq.heappop(ropes)
        second = heapq.heappop(ropes)

        # Combine them
        combined = first + second
        total_cost += combined

        # Push combined rope back
        heapq.heappush(ropes, combined)

    return total_cost


def min_cost_visualized(ropes):
    """Step-by-step visualization."""
    print(f"Ropes: {ropes}")
    print("=" * 50)

    if len(ropes) <= 1:
        print("No cost needed (0 or 1 rope)")
        return 0

    heap = ropes.copy()
    heapq.heapify(heap)
    print(f"Initial heap: {heap}")

    total_cost = 0
    step = 1

    while len(heap) > 1:
        first = heapq.heappop(heap)
        second = heapq.heappop(heap)
        combined = first + second
        total_cost += combined

        print(f"\nStep {step}:")
        print(f"  Connect {first} + {second} = {combined}")
        print(f"  Cost this step: {combined}")
        print(f"  Total cost so far: {total_cost}")

        heapq.heappush(heap, combined)
        print(f"  Heap: {heap}")

        step += 1

    print("\n" + "=" * 50)
    print(f"Minimum Total Cost: {total_cost}")
    return total_cost


# ============== Test Cases ==============

def test():
    print("Testing Connect N Ropes")
    print("=" * 50)

    tests = [
        ([4, 3, 2, 6], 29),
        ([1, 2, 3, 4, 5], 33),
        ([5, 4, 2, 8], 36),
        ([1, 2], 3),
        ([5], 0),
        ([], 0),
    ]

    for ropes, expected in tests:
        result = min_cost_to_connect_ropes(ropes.copy())
        print(f"Ropes: {ropes} -> Cost: {result}, Expected: {expected}")
        assert result == expected

    print("\nAll tests passed!")


if __name__ == "__main__":
    test()
    print()
    min_cost_visualized([4, 3, 2, 6])
