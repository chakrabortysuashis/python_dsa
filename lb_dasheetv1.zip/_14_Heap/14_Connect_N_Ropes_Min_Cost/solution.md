# Connect N Ropes with Minimum Cost

## Problem Statement
Given N ropes of different lengths, connect them into one rope. Cost to connect two ropes = sum of their lengths. Find minimum total cost.

**Example:**
```
Input: [4, 3, 2, 6]
Output: 29

Explanation:
- Connect 2 and 3 = 5, cost = 5
- Connect 4 and 5 = 9, cost = 9
- Connect 6 and 9 = 15, cost = 15
- Total = 5 + 9 + 15 = 29
```

## Why Heap is Useful Here
- Greedy approach: always connect two smallest ropes
- Min-heap efficiently finds two smallest
- Classic Huffman coding problem

## Algorithm

```
1. Build min-heap from all rope lengths
2. While heap has more than 1 element:
   - Extract two minimum lengths
   - Add their sum to total cost
   - Push combined rope back to heap
3. Return total cost
```

## Step-by-Step

```
Ropes: [4, 3, 2, 6]
Heap: [2, 3, 4, 6]

Step 1: Pop 2, 3; combine = 5; cost = 5
Heap: [4, 5, 6]

Step 2: Pop 4, 5; combine = 9; cost = 5 + 9 = 14
Heap: [6, 9]

Step 3: Pop 6, 9; combine = 15; cost = 14 + 15 = 29
Heap: [15]

Total Cost: 29
```

## Why Greedy Works
- Smaller ropes get added multiple times in final sum
- By combining smallest first, they contribute less to total
- This minimizes the overall cost

## Time and Space Complexity

| Complexity | Value |
|------------|-------|
| Time | O(n log n) |
| Space | O(n) for heap |

## Key Insight
This is equivalent to Huffman coding where we build optimal prefix-free codes.
