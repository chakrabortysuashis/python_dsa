"""
Problem: K Largest Elements in Array

Given an array, find the K largest elements.

Example:
    Input: arr = [7, 10, 4, 3, 20, 15], K = 3
    Output: [20, 15, 10]
"""

import heapq


def k_largest_minheap(arr, k):
    """
    Using Min-Heap of size K.

    Approach:
    - Maintain min-heap of size K
    - Top of heap = smallest among K largest
    - If new element > top, replace it

    Time: O(n log K)
    Space: O(K)
    """
    if k <= 0 or not arr:
        return []

    if k >= len(arr):
        return sorted(arr, reverse=True)

    # Min-heap of size K
    min_heap = []

    for num in arr:
        if len(min_heap) < k:
            heapq.heappush(min_heap, num)
        elif num > min_heap[0]:
            heapq.heapreplace(min_heap, num)  # Pop and push in one operation

    # Return in descending order
    return sorted(min_heap, reverse=True)


def k_largest_nlargest(arr, k):
    """
    Using Python's heapq.nlargest (built-in).

    Time: O(n log K)
    Space: O(K)
    """
    return heapq.nlargest(k, arr)


def k_largest_maxheap(arr, k):
    """
    Using Max-Heap - extract K times.

    Approach:
    - Build max-heap from array
    - Extract maximum K times

    Time: O(n + K log n)
    Space: O(n)
    """
    if k <= 0 or not arr:
        return []

    # Max-heap using negation
    max_heap = [-x for x in arr]
    heapq.heapify(max_heap)

    result = []
    for _ in range(min(k, len(arr))):
        result.append(-heapq.heappop(max_heap))

    return result


def k_largest_sort(arr, k):
    """
    Using sorting (brute force).

    Time: O(n log n)
    Space: O(n) for sorted copy
    """
    return sorted(arr, reverse=True)[:k]


def k_largest_quickselect(arr, k):
    """
    Using QuickSelect algorithm.

    Time: O(n) average, O(n^2) worst
    Space: O(1)
    """
    if k <= 0 or not arr:
        return []

    import random

    def partition(left, right, pivot_idx):
        pivot = arr[pivot_idx]
        # Move pivot to end
        arr[pivot_idx], arr[right] = arr[right], arr[pivot_idx]
        store_idx = left

        for i in range(left, right):
            if arr[i] > pivot:  # For K largest, we want descending
                arr[store_idx], arr[i] = arr[i], arr[store_idx]
                store_idx += 1

        arr[store_idx], arr[right] = arr[right], arr[store_idx]
        return store_idx

    def quickselect(left, right, k_smallest):
        if left == right:
            return

        pivot_idx = random.randint(left, right)
        pivot_idx = partition(left, right, pivot_idx)

        if k_smallest == pivot_idx:
            return
        elif k_smallest < pivot_idx:
            quickselect(left, pivot_idx - 1, k_smallest)
        else:
            quickselect(pivot_idx + 1, right, k_smallest)

    arr = arr.copy()
    quickselect(0, len(arr) - 1, k - 1)
    return sorted(arr[:k], reverse=True)


def k_largest_visualized(arr, k):
    """
    Min-Heap solution with step-by-step visualization.
    """
    print(f"Array: {arr}")
    print(f"K = {k}")
    print("=" * 50)
    print("Using MIN-HEAP of size K")
    print("(Smallest of K largest stays at top)")
    print("=" * 50)

    min_heap = []

    for i, num in enumerate(arr):
        print(f"\nStep {i + 1}: Process {num}")

        if len(min_heap) < k:
            heapq.heappush(min_heap, num)
            print(f"  Heap size < K, add {num}")
        elif num > min_heap[0]:
            old_top = min_heap[0]
            heapq.heapreplace(min_heap, num)
            print(f"  {num} > {old_top} (top), replace {old_top} with {num}")
        else:
            print(f"  {num} <= {min_heap[0]} (top), skip")

        print(f"  Heap: {min_heap}")

    result = sorted(min_heap, reverse=True)
    print("\n" + "=" * 50)
    print(f"Final Heap: {min_heap}")
    print(f"K Largest (sorted): {result}")
    return result


# ============== Test Cases ==============

def test_k_largest():
    print("=" * 60)
    print("Testing K Largest Elements")
    print("=" * 60)

    test_cases = [
        ([7, 10, 4, 3, 20, 15], 3, [20, 15, 10]),
        ([1, 23, 12, 9, 30, 2, 50], 3, [50, 30, 23]),
        ([5, 5, 5, 5], 2, [5, 5]),
        ([1, 2, 3, 4, 5], 5, [5, 4, 3, 2, 1]),
        ([10], 1, [10]),
        ([3, 1, 4, 1, 5, 9, 2, 6], 4, [9, 6, 5, 4]),
    ]

    for i, (arr, k, expected) in enumerate(test_cases):
        print(f"\nTest {i + 1}: arr={arr}, k={k}")

        result_minheap = k_largest_minheap(arr, k)
        result_nlargest = k_largest_nlargest(arr, k)
        result_maxheap = k_largest_maxheap(arr, k)
        result_sort = k_largest_sort(arr, k)

        print(f"  Min-heap:  {result_minheap}")
        print(f"  nlargest:  {result_nlargest}")
        print(f"  Max-heap:  {result_maxheap}")
        print(f"  Sort:      {result_sort}")
        print(f"  Expected:  {expected}")

        assert result_minheap == expected
        assert result_nlargest == expected
        assert result_maxheap == expected
        assert result_sort == expected
        print(f"  PASSED")

    print("\n" + "=" * 60)
    print("All tests passed!")


def demo_visualization():
    print("\n" + "=" * 60)
    print("Step-by-Step Visualization")
    print("=" * 60)

    arr = [7, 10, 4, 3, 20, 15]
    k = 3
    k_largest_visualized(arr, k)


def compare_performance():
    import time
    import random

    print("\n" + "=" * 60)
    print("Performance Comparison")
    print("=" * 60)

    arr = [random.randint(1, 100000) for _ in range(100000)]
    k = 100

    methods = [
        ("Min-Heap (O(n log K))", k_largest_minheap),
        ("heapq.nlargest", k_largest_nlargest),
        ("Max-Heap (O(n + K log n))", k_largest_maxheap),
        ("Sort (O(n log n))", k_largest_sort),
        ("QuickSelect (O(n) avg)", k_largest_quickselect),
    ]

    print(f"Array size: {len(arr)}, K = {k}\n")

    for name, func in methods:
        start = time.time()
        result = func(arr, k)
        elapsed = time.time() - start
        print(f"{name:30s}: {elapsed:.6f}s")


if __name__ == "__main__":
    test_k_largest()
    demo_visualization()
    compare_performance()
