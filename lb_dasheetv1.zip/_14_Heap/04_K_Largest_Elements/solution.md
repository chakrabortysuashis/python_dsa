# K Largest Elements in Array

## Problem Statement
Given an array of N positive integers, find the K largest elements in the array.

**Example:**
```
Input: arr = [7, 10, 4, 3, 20, 15], K = 3
Output: [20, 15, 10] (or any order)
```

## Why Heap is Useful Here
- Maintaining K largest elements efficiently
- Min-heap of size K naturally filters out smaller elements
- Better than sorting when K << N

## Heap Operations Used
- **Min-Heap of size K**: Smallest of K largest is at top
- **Push**: Add element if larger than heap top
- **Pop**: Remove smallest when size exceeds K

## Brute Force vs Heap Approach

| Approach | Time | Space |
|----------|------|-------|
| Sort entire array | O(n log n) | O(1) |
| **Min-Heap of size K** | **O(n log K)** | **O(K)** |
| QuickSelect | O(n) average | O(1) |

## Why Min-Heap and Not Max-Heap?

```
Using MIN-HEAP of size K:
- Top element = smallest among K largest
- If new element > top, it deserves to be in K largest
- Replace top with new element

Example: K=3, arr=[7, 10, 4, 3, 20, 15]

Process 7:  heap = [7]
Process 10: heap = [7, 10]
Process 4:  heap = [4, 7, 10]  (size = K)
Process 3:  3 < 4 (top), skip
Process 20: 20 > 4, pop 4, push 20: heap = [7, 10, 20]
Process 15: 15 > 7, pop 7, push 15: heap = [10, 15, 20]

Final K largest: [10, 15, 20]
```

## Step-by-Step Algorithm

```
1. Create empty min-heap
2. For each element in array:
   a. If heap size < K: push element
   b. Else if element > heap top:
      - Pop the top (smallest of current K)
      - Push new element
3. Heap contains K largest elements
```

## Visual Representation

```
Array: [7, 10, 4, 3, 20, 15], K = 3

Step 1: Add 7         Step 2: Add 10        Step 3: Add 4
    [7]                  [7]                    [4]
                         /                     /   \
                       10                     7    10

Step 4: 3 < 4         Step 5: 20 > 4        Step 6: 15 > 7
   Skip!                 [7]                   [10]
                        /   \                 /    \
                      10    20              15     20

Final: [10, 15, 20] = K largest elements
```

## Time and Space Complexity

| Complexity | Value |
|------------|-------|
| Time | O(n log K) |
| Space | O(K) |

### Why O(n log K)?
- Each of n elements may trigger heap operation
- Heap operations on size-K heap: O(log K)
- Total: O(n log K)

### Comparison:
- When K is small: O(n log K) << O(n log n)
- When K = n: Both are O(n log n)

## Key Insights

1. **Min-Heap for K Largest**: Counter-intuitive but efficient
   - Top is the "gatekeeper" - smallest of K largest
   - Easy to compare and replace

2. **Max-Heap for K Smallest**: Same logic reversed
   - Top is largest of K smallest

3. **Early Termination**: Not possible with heap approach
   - QuickSelect can terminate early in O(n) average

## Variations

1. **K Smallest Elements**: Use Max-Heap of size K
2. **Kth Largest Element**: Return heap top after processing
3. **K Most Frequent**: Use heap with frequency counts
