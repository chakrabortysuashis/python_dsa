"""
Problem: Find Median from Data Stream

Design a class to find median from a stream of integers.

Time: O(log n) for add, O(1) for find median
Space: O(n)
"""

import heapq


class MedianFinder:
    """
    Two Heaps Approach:
    - max_heap: lower half (stores negatives for max behavior)
    - min_heap: upper half

    Invariants:
    - len(max_heap) >= len(min_heap)
    - len(max_heap) - len(min_heap) <= 1
    - all elements in max_heap <= all in min_heap
    """

    def __init__(self):
        self.max_heap = []  # Lower half (negated for max-heap)
        self.min_heap = []  # Upper half

    def addNum(self, num: int) -> None:
        """Add a number. O(log n)"""
        # Add to appropriate heap
        if not self.max_heap or num <= -self.max_heap[0]:
            heapq.heappush(self.max_heap, -num)
        else:
            heapq.heappush(self.min_heap, num)

        # Rebalance
        if len(self.max_heap) > len(self.min_heap) + 1:
            val = -heapq.heappop(self.max_heap)
            heapq.heappush(self.min_heap, val)
        elif len(self.min_heap) > len(self.max_heap):
            val = heapq.heappop(self.min_heap)
            heapq.heappush(self.max_heap, -val)

    def findMedian(self) -> float:
        """Find median. O(1)"""
        if len(self.max_heap) == len(self.min_heap):
            return (-self.max_heap[0] + self.min_heap[0]) / 2
        else:
            return -self.max_heap[0]

    def __repr__(self):
        lower = sorted([-x for x in self.max_heap])
        upper = sorted(self.min_heap)
        return f"Lower: {lower}, Upper: {upper}, Median: {self.findMedian()}"


def visualize_median_stream(numbers):
    """Step-by-step visualization."""
    print(f"Input stream: {numbers}")
    print("=" * 60)

    mf = MedianFinder()

    for num in numbers:
        mf.addNum(num)
        lower = sorted([-x for x in mf.max_heap])
        upper = sorted(mf.min_heap)

        print(f"\nAdd {num}:")
        print(f"  Lower half (max-heap): {lower}")
        print(f"  Upper half (min-heap): {upper}")
        print(f"  All elements sorted: {lower + upper}")
        print(f"  Median: {mf.findMedian()}")

    print("\n" + "=" * 60)


# ============== Test Cases ==============

def test():
    print("Testing MedianFinder")
    print("=" * 50)

    mf = MedianFinder()

    mf.addNum(1)
    assert mf.findMedian() == 1.0
    print(f"After [1]: median = {mf.findMedian()}")

    mf.addNum(2)
    assert mf.findMedian() == 1.5
    print(f"After [1,2]: median = {mf.findMedian()}")

    mf.addNum(3)
    assert mf.findMedian() == 2.0
    print(f"After [1,2,3]: median = {mf.findMedian()}")

    mf.addNum(4)
    assert mf.findMedian() == 2.5
    print(f"After [1,2,3,4]: median = {mf.findMedian()}")

    mf.addNum(5)
    assert mf.findMedian() == 3.0
    print(f"After [1,2,3,4,5]: median = {mf.findMedian()}")

    print("\nAll tests passed!")


if __name__ == "__main__":
    test()
    print()
    visualize_median_stream([5, 2, 8, 3, 6, 1])
