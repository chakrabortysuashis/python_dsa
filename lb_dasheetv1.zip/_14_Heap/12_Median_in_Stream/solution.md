# Median in a Stream of Integers

## Problem Statement
Design a data structure that supports adding integers and finding the median efficiently.

**Example:**
```
addNum(1): median = 1
addNum(2): median = 1.5
addNum(3): median = 2
```

## Why Heap is Useful Here
- Need to efficiently find middle element(s)
- Two heaps split data into lower and upper halves
- Max-heap for lower half, min-heap for upper half

## Two Heap Approach

```
Lower Half: MAX-HEAP (top = largest of smaller half)
Upper Half: MIN-HEAP (top = smallest of larger half)

Invariants:
1. Max-heap size >= Min-heap size
2. Size difference <= 1
3. All elements in max-heap <= all elements in min-heap
```

## Visual Representation

```
After adding [5, 2, 8, 3, 6]:

Sorted: [2, 3, 5, 6, 8]
         ^^^^^   ^^^^^
         lower   upper

MAX-HEAP (lower)    MIN-HEAP (upper)
     3                   6
    / \                   \
   2   ?                   8
   ^                       ^
   top=3                   top=6

Median = max_heap.top = 3 (odd count)
```

## Algorithm

### Add Number:
```
1. If empty or num <= max_heap.top:
   - Add to max_heap
2. Else:
   - Add to min_heap
3. Rebalance:
   - If max_heap.size > min_heap.size + 1:
     - Move max_heap.top to min_heap
   - If min_heap.size > max_heap.size:
     - Move min_heap.top to max_heap
```

### Find Median:
```
If sizes equal:
  median = (max_heap.top + min_heap.top) / 2
Else:
  median = max_heap.top
```

## Time and Space Complexity

| Operation | Time |
|-----------|------|
| addNum | O(log n) |
| findMedian | O(1) |

| Complexity | Value |
|------------|-------|
| Space | O(n) |

## Key Insights

1. **Max-heap for lower half**: Quick access to largest of smaller elements
2. **Min-heap for upper half**: Quick access to smallest of larger elements
3. **Balance**: Keep sizes within 1 of each other
4. **Median**: Always accessible from heap tops
