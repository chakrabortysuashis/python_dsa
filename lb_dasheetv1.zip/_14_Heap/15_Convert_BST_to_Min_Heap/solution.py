"""
Problem: Convert BST to Min Heap

Convert a Binary Search Tree to a Min Heap.

Strategy: Inorder gives sorted, Preorder fills tree maintaining heap property.

Time: O(n)
Space: O(n)
"""

from collections import deque


class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right


def bst_to_min_heap(root):
    """
    Convert BST to Min Heap.

    1. Inorder traversal -> sorted array
    2. Preorder fill -> assigns smallest values to top
    """
    if not root:
        return None

    # Step 1: Get sorted elements via inorder
    sorted_vals = []

    def inorder(node):
        if node:
            inorder(node.left)
            sorted_vals.append(node.val)
            inorder(node.right)

    inorder(root)

    # Step 2: Fill tree via preorder
    index = [0]  # Use list to maintain state across recursion

    def preorder_fill(node):
        if node and index[0] < len(sorted_vals):
            node.val = sorted_vals[index[0]]
            index[0] += 1
            preorder_fill(node.left)
            preorder_fill(node.right)

    preorder_fill(root)
    return root


def print_tree(root, level=0, prefix="Root: "):
    """Print tree structure."""
    if root:
        print(" " * (level * 4) + prefix + str(root.val))
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            else:
                print(" " * ((level + 1) * 4) + "L--- None")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")
            else:
                print(" " * ((level + 1) * 4) + "R--- None")


def level_order(root):
    """Get level order traversal."""
    if not root:
        return []
    result = []
    queue = deque([root])
    while queue:
        node = queue.popleft()
        result.append(node.val)
        if node.left:
            queue.append(node.left)
        if node.right:
            queue.append(node.right)
    return result


def is_min_heap(root):
    """Check if tree is valid min-heap."""
    if not root:
        return True

    queue = deque([root])
    while queue:
        node = queue.popleft()
        if node.left:
            if node.val > node.left.val:
                return False
            queue.append(node.left)
        if node.right:
            if node.val > node.right.val:
                return False
            queue.append(node.right)
    return True


# ============== Test Cases ==============

def test():
    print("Testing Convert BST to Min Heap")
    print("=" * 50)

    # Build BST
    #       4
    #      / \
    #     2   6
    #    / \ / \
    #   1  3 5  7
    root = TreeNode(4)
    root.left = TreeNode(2)
    root.right = TreeNode(6)
    root.left.left = TreeNode(1)
    root.left.right = TreeNode(3)
    root.right.left = TreeNode(5)
    root.right.right = TreeNode(7)

    print("Original BST:")
    print_tree(root)
    print(f"Level order: {level_order(root)}")

    bst_to_min_heap(root)

    print("\nAfter conversion to Min-Heap:")
    print_tree(root)
    print(f"Level order: {level_order(root)}")
    print(f"Is valid min-heap: {is_min_heap(root)}")

    assert is_min_heap(root), "Not a valid min-heap!"
    print("\nTest passed!")


if __name__ == "__main__":
    test()
