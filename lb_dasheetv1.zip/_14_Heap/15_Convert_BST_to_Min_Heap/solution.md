# Convert BST to Min Heap

## Problem Statement
Given a BST (Binary Search Tree), convert it to a Min Heap containing the same elements.

## Key Insight
- BST inorder traversal gives sorted elements
- Min-heap level order = sorted order (for complete tree)
- Strategy: Get sorted elements, fill level by level

## Algorithm

```
1. Perform inorder traversal of BST -> sorted array
2. Perform preorder traversal of tree
3. Replace each node's value with next element from sorted array
```

## Why This Works
- Inorder of BST = sorted sequence
- Preorder traversal fills nodes level by level (root, left subtree, right subtree)
- Each node gets smallest available value that maintains completeness

## Step-by-Step Example

```
BST:
        4
       / \
      2   6
     / \ / \
    1  3 5  7

Inorder (sorted): [1, 2, 3, 4, 5, 6, 7]

Fill via preorder:
- Visit root (4): assign 1
- Visit left subtree root (2): assign 2
- Visit 2's left (1): assign 3
- Visit 2's right (3): assign 4
- Visit right subtree root (6): assign 5
- ... and so on

Result Min-Heap:
        1
       / \
      2   5
     / \ / \
    3  4 6  7
```

## Time and Space Complexity

| Complexity | Value |
|------------|-------|
| Time | O(n) |
| Space | O(n) for sorted array |

## Important Notes
1. Tree structure remains same (same shape)
2. Only values are rearranged
3. Works because BST is already complete (or we make it complete)
