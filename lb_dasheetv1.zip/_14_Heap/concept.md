# Heap Data Structure - Complete Guide

## Table of Contents
1. [What is a Heap?](#what-is-a-heap)
2. [Types of Heaps](#types-of-heaps)
3. [Complete Binary Tree Structure](#complete-binary-tree-structure)
4. [Array Representation](#array-representation)
5. [Heapify Operations](#heapify-operations)
6. [Insert Operation](#insert-operation)
7. [Extract Operation](#extract-operation)
8. [Building Heap from Array](#building-heap-from-array)
9. [Priority Queue Concept](#priority-queue-concept)
10. [Time Complexity Summary](#time-complexity-summary)

---

## What is a Heap?

A **Heap** is a specialized tree-based data structure that satisfies the **heap property**. It is a complete binary tree where every level is completely filled except possibly the last level, which is filled from left to right.

### Key Characteristics:
- Complete Binary Tree structure
- Satisfies heap property (min or max)
- Efficiently supports priority-based operations
- Can be efficiently represented using arrays

---

## Types of Heaps

### 1. Max-Heap
In a **Max-Heap**, for every node `i`:
```
Parent(i) >= Children(i)
```
- The **maximum element** is always at the **root**
- Every parent is greater than or equal to its children

```
        100          (Max at root)
       /    \
      90     80
     /  \   /  \
    70  60 50  40
```

### 2. Min-Heap
In a **Min-Heap**, for every node `i`:
```
Parent(i) <= Children(i)
```
- The **minimum element** is always at the **root**
- Every parent is less than or equal to its children

```
        10          (Min at root)
       /    \
      20     30
     /  \   /  \
    40  50 60  70
```

### Visual Comparison

| Property | Max-Heap | Min-Heap |
|----------|----------|----------|
| Root | Maximum element | Minimum element |
| Parent-Child | Parent >= Child | Parent <= Child |
| Use Case | Extract max | Extract min |
| Priority Queue | Higher value = Higher priority | Lower value = Higher priority |

---

## Complete Binary Tree Structure

A **Complete Binary Tree** is a binary tree where:
1. All levels are completely filled **except possibly the last level**
2. The last level has nodes filled **from left to right**

### Valid Complete Binary Trees:
```
    1           1           1
   / \         / \         / \
  2   3       2   3       2   3
             /           / \
            4           4   5
```

### Invalid (Not Complete):
```
    1           1
   / \         / \
  2   3       2   3
   \         / \   \
    4       4   5   6
```

### Properties:
- Height of tree with `n` nodes: `h = floor(log2(n))`
- Number of nodes at level `i`: `2^i` (except possibly last level)
- Total nodes in complete tree of height `h`: Between `2^h` and `2^(h+1) - 1`

---

## Array Representation

Heaps are most efficiently stored in **arrays** (not as linked structures).

### Index Relationships (0-based indexing):

For a node at index `i`:
- **Parent index**: `(i - 1) // 2`
- **Left child index**: `2 * i + 1`
- **Right child index**: `2 * i + 2`

### Index Relationships (1-based indexing):

For a node at index `i`:
- **Parent index**: `i // 2`
- **Left child index**: `2 * i`
- **Right child index**: `2 * i + 1`

### Example (0-based):

```
Tree Representation:
        100(0)
       /      \
     90(1)    80(2)
    /    \    /    \
  70(3) 60(4) 50(5) 40(6)

Array Representation:
Index:  0    1    2    3    4    5    6
Value: [100, 90,  80,  70,  60,  50,  40]
```

### Why Array?
| Advantage | Explanation |
|-----------|-------------|
| Space Efficient | No need for pointers (left, right, parent) |
| Cache Friendly | Contiguous memory access |
| Easy Navigation | Simple index arithmetic |
| Fast Access | O(1) access to any element |

---

## Heapify Operations

### Sift-Up (Bubble Up / Percolate Up)

Used when: **A node is larger (max-heap) or smaller (min-heap) than its parent**

Typically used after: **Insertion**

```
Algorithm (Max-Heap):
1. Compare node with its parent
2. If node > parent, swap them
3. Repeat until heap property is restored or root is reached
```

#### Example - Sift-Up in Max-Heap:
```
Insert 95:
        100                    100                    100
       /    \                 /    \                 /    \
      80     70    -->       80     70    -->       95     70
     /  \   /               /  \   /  \            /  \   /  \
    60  50 30              60  50 30  95          60  50 30  80
                                  ^                        ^
                           Insert here              After sift-up
```

### Sift-Down (Bubble Down / Percolate Down)

Used when: **A node is smaller (max-heap) or larger (min-heap) than its children**

Typically used after: **Extraction** or during **Heapify**

```
Algorithm (Max-Heap):
1. Compare node with its children
2. Find the larger child
3. If node < larger child, swap them
4. Repeat until heap property is restored or leaf is reached
```

#### Example - Sift-Down in Max-Heap:
```
After removing 100, move 30 to root:
        30                     90                     90
       /    \                 /    \                 /    \
      90     80    -->       30     80    -->       60     80
     /  \                   /  \                   /  \
    60  50                 60  50                 30  50
    ^                          ^
Root is wrong           After sift-down
```

---

## Insert Operation

### Algorithm:
1. Add the new element at the **end of the array** (maintains complete tree property)
2. **Sift-up** the new element to restore heap property

### Time Complexity: O(log n)

### Step-by-Step Example (Max-Heap):

```
Initial heap: [100, 80, 70, 60, 50]

Insert 95:

Step 1: Add at end
Array: [100, 80, 70, 60, 50, 95]
        100
       /    \
      80     70
     /  \   /
    60  50 95  <-- New element

Step 2: Sift-up (95 > 70, swap)
Array: [100, 80, 95, 60, 50, 70]
        100
       /    \
      80     95  <-- Moved up
     /  \   /
    60  50 70

Step 3: Check parent (95 < 100, stop)
Final: [100, 80, 95, 60, 50, 70]
```

---

## Extract Operation

### Extract Max (Max-Heap) / Extract Min (Min-Heap)

### Algorithm:
1. Store the root element (maximum/minimum)
2. Replace root with the **last element** in the array
3. Remove the last element (reduce size)
4. **Sift-down** the new root to restore heap property
5. Return the stored element

### Time Complexity: O(log n)

### Step-by-Step Example (Extract Max):

```
Initial heap: [100, 80, 95, 60, 50, 70]
        100  <-- Extract this
       /    \
      80     95
     /  \   /
    60  50 70

Step 1: Store 100, move last element (70) to root
Array: [70, 80, 95, 60, 50]
        70  <-- Needs sift-down
       /    \
      80     95
     /  \
    60  50

Step 2: Sift-down (95 > 80, swap with 95)
Array: [95, 80, 70, 60, 50]
        95
       /    \
      80     70  <-- Moved down
     /  \
    60  50

Step 3: Check children (70 is at leaf level, stop)
Final: [95, 80, 70, 60, 50]
Returned: 100
```

---

## Building Heap from Array

### Method 1: Repeated Insertion - O(n log n)
```python
# Insert elements one by one
heap = []
for element in array:
    insert(heap, element)  # O(log n) each
```

### Method 2: Heapify (Bottom-Up) - O(n) [OPTIMAL]

```
Algorithm:
1. Start from the LAST NON-LEAF node (index: n//2 - 1)
2. Apply sift-down to each node from this position to root
3. Process nodes from right to left, bottom to top
```

### Why O(n)?
- Nodes at bottom levels require fewer swaps
- Most nodes are at bottom levels
- Mathematical analysis shows total swaps = O(n)

### Example:

```
Convert array [4, 10, 3, 5, 1] to Max-Heap:

Tree view:
        4(0)
       /    \
     10(1)   3(2)
     /  \
   5(3)  1(4)

Last non-leaf index = 5//2 - 1 = 1

Step 1: Process index 1 (value 10)
- Children: 5, 1 (both < 10)
- No swap needed

Step 2: Process index 0 (value 4)
- Children: 10, 3 (10 is largest)
- Swap 4 with 10

        10(0)
       /    \
      4(1)   3(2)
     /  \
   5(3)  1(4)

- Continue sift-down at index 1
- Children: 5, 1 (5 is largest)
- Swap 4 with 5

        10(0)
       /    \
      5(1)   3(2)
     /  \
   4(3)  1(4)

Final Max-Heap: [10, 5, 3, 4, 1]
```

---

## Priority Queue Concept

A **Priority Queue** is an abstract data type where each element has a priority:
- **Dequeue** always returns the element with highest priority
- **Enqueue** adds element with its priority

### Heap as Priority Queue

Heaps are the most efficient implementation of Priority Queues:

| Operation | Array | Sorted Array | Heap |
|-----------|-------|--------------|------|
| Insert | O(1) | O(n) | O(log n) |
| Extract Max/Min | O(n) | O(1) | O(log n) |
| Peek Max/Min | O(n) | O(1) | O(1) |

### Use Cases:
1. **Task Scheduling** - Execute highest priority task first
2. **Dijkstra's Algorithm** - Always process nearest unvisited vertex
3. **Huffman Coding** - Build optimal prefix-free codes
4. **Event Simulation** - Process events in chronological order
5. **K Largest/Smallest Elements** - Maintain running top-K
6. **Merge K Sorted Lists** - Always pick smallest head

### Python's heapq Module

```python
import heapq

# Min-heap operations
heap = []
heapq.heappush(heap, 3)    # Insert
heapq.heappush(heap, 1)
heapq.heappush(heap, 2)
min_val = heapq.heappop(heap)  # Extract min (returns 1)

# Build heap from list - O(n)
arr = [3, 1, 4, 1, 5, 9]
heapq.heapify(arr)  # Transforms arr into min-heap in-place

# For max-heap, negate values
max_heap = []
heapq.heappush(max_heap, -5)  # Push negated
heapq.heappush(max_heap, -3)
max_val = -heapq.heappop(max_heap)  # Negate back (returns 5)

# K largest/smallest
k_largest = heapq.nlargest(3, arr)
k_smallest = heapq.nsmallest(3, arr)
```

---

## Time Complexity Summary

| Operation | Time Complexity | Space Complexity |
|-----------|----------------|------------------|
| **Build Heap (Heapify)** | O(n) | O(1) |
| **Insert (Push)** | O(log n) | O(1) |
| **Extract Max/Min (Pop)** | O(log n) | O(1) |
| **Peek (Get Max/Min)** | O(1) | O(1) |
| **Delete Arbitrary** | O(log n) | O(1) |
| **Search** | O(n) | O(1) |
| **Increase/Decrease Key** | O(log n) | O(1) |

### Detailed Breakdown:

| Operation | Worst Case | Average Case | Best Case |
|-----------|-----------|--------------|-----------|
| Sift-Up | O(log n) | O(log n) | O(1) |
| Sift-Down | O(log n) | O(log n) | O(1) |
| Build Heap | O(n) | O(n) | O(n) |
| Heap Sort | O(n log n) | O(n log n) | O(n log n) |

### Space Complexity:
- **In-place heap**: O(1) auxiliary space
- **Separate heap array**: O(n) total space

---

## Common Patterns & Interview Tips

### Pattern 1: K Elements Problems
```
"Find K largest" -> Use Min-Heap of size K
"Find K smallest" -> Use Max-Heap of size K
```

### Pattern 2: Stream Problems
```
"Running median" -> Two heaps (max-heap + min-heap)
"Top K in stream" -> Maintain heap of size K
```

### Pattern 3: Merge Problems
```
"Merge K sorted X" -> Min-Heap of K elements
```

### Pattern 4: Greedy + Heap
```
"Minimum cost to X" -> Often involves heap for greedy selection
```

### Interview Checklist:
- [ ] Can you identify if problem needs heap?
- [ ] Min-heap or Max-heap?
- [ ] What elements go in the heap?
- [ ] What's the heap size constraint?
- [ ] Are you using Python's heapq correctly (min-heap by default)?

---

## Quick Reference

```python
import heapq

# Min-Heap
heapq.heappush(heap, val)     # Insert
heapq.heappop(heap)            # Extract min
heap[0]                        # Peek min

# Max-Heap (negate values)
heapq.heappush(heap, -val)     # Insert
-heapq.heappop(heap)           # Extract max
-heap[0]                       # Peek max

# Build heap in O(n)
heapq.heapify(arr)

# Push and pop in one operation
heapq.heappushpop(heap, val)   # Push then pop
heapq.heapreplace(heap, val)   # Pop then push

# K largest/smallest
heapq.nlargest(k, arr)
heapq.nsmallest(k, arr)
```

---

## Summary

1. **Heap = Complete Binary Tree + Heap Property**
2. **Array representation** is space and time efficient
3. **Max-Heap**: Parent >= Children, root is maximum
4. **Min-Heap**: Parent <= Children, root is minimum
5. **Sift-Up**: Fix violation when child > parent (after insert)
6. **Sift-Down**: Fix violation when parent < child (after extract)
7. **Build Heap**: Bottom-up heapify in O(n)
8. **Priority Queue**: Heap is the best implementation
9. **Python**: Use `heapq` module (min-heap by default)
