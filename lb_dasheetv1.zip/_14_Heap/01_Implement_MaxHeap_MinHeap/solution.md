# Implement MaxHeap/MinHeap Using Arrays

## Problem Statement
Implement a MaxHeap and MinHeap data structure using arrays with the following operations:
1. **insert(value)**: Insert a new element into the heap
2. **extractMax()/extractMin()**: Remove and return the maximum/minimum element
3. **peek()**: Return the top element without removing it
4. **heapify(array)**: Build a heap from an array

## Why Heap is Useful Here
This is the fundamental heap problem that teaches:
- Understanding of complete binary tree structure
- Array representation of binary trees
- Heap property maintenance
- Foundation for all other heap problems

## Heap Property
- **Max-Heap**: Parent >= Children (root is maximum)
- **Min-Heap**: Parent <= Children (root is minimum)

## Array Index Relationships (0-based)
```
Parent of i     : (i - 1) // 2
Left child of i : 2 * i + 1
Right child of i: 2 * i + 2
```

## Brute Force vs Heap Approach

### Brute Force (Using Sorted Array)
| Operation | Sorted Array | Heap |
|-----------|-------------|------|
| Insert | O(n) - shift elements | O(log n) - sift up |
| Extract Max/Min | O(1) - end/start | O(log n) - sift down |
| Peek | O(1) | O(1) |
| Build from array | O(n log n) | O(n) |

## Step-by-Step Heap Operations

### 1. Insert Operation (Sift-Up)
```
Insert 50 into Max-Heap [100, 40, 30, 20, 10]:

Step 1: Add at end
Array: [100, 40, 30, 20, 10, 50]
          100
         /    \
       40      30
      /  \    /
    20   10  50  <-- New element

Step 2: Compare with parent (index 2, value 30)
50 > 30, so swap

Array: [100, 40, 50, 20, 10, 30]
          100
         /    \
       40      50  <-- Moved up
      /  \    /
    20   10  30

Step 3: Compare with parent (index 0, value 100)
50 < 100, stop

Final: [100, 40, 50, 20, 10, 30]
```

### 2. Extract Max Operation (Sift-Down)
```
Extract from Max-Heap [100, 40, 50, 20, 10, 30]:

Step 1: Store root (100), move last element to root
Array: [30, 40, 50, 20, 10]
          30  <-- Needs to move down
         /  \
       40    50
      /  \
    20   10

Step 2: Compare 30 with children (40, 50)
Larger child is 50, swap

Array: [50, 40, 30, 20, 10]
          50
         /  \
       40    30  <-- Moved down
      /  \
    20   10

Step 3: No children for 30 (at index 2)
Stop

Extracted: 100
Final heap: [50, 40, 30, 20, 10]
```

### 3. Build Heap (Bottom-Up Heapify)
```
Build Max-Heap from [4, 10, 3, 5, 1]:

Initial tree:
        4(0)
       /    \
     10(1)   3(2)
     /  \
   5(3)  1(4)

Last non-leaf: index = n//2 - 1 = 1

Process index 1 (value 10):
Children: 5, 1 (both < 10) - No swap

Process index 0 (value 4):
Children: 10, 3 (10 is largest)
Swap 4 with 10

        10(0)
       /    \
      4(1)   3(2)
     /  \
   5(3)  1(4)

Continue sift-down at index 1:
Children: 5, 1 (5 > 4)
Swap 4 with 5

        10(0)
       /    \
      5(1)   3(2)
     /  \
   4(3)  1(4)

Final Max-Heap: [10, 5, 3, 4, 1]
```

## Time and Space Complexity

| Operation | Time Complexity | Space Complexity |
|-----------|----------------|------------------|
| Insert | O(log n) | O(1) |
| Extract Max/Min | O(log n) | O(1) |
| Peek | O(1) | O(1) |
| Build Heap | O(n) | O(1) |

### Why is Build Heap O(n)?
- Nodes at level h have 0 swaps
- Nodes at level h-1 have at most 1 swap
- Nodes at level 0 have at most h swaps
- Sum: n/2 * 0 + n/4 * 1 + n/8 * 2 + ... = O(n)

## Key Implementation Details

1. **Array vs Linked Structure**
   - Arrays are more cache-friendly
   - No pointer overhead
   - Simple index arithmetic for navigation

2. **0-based vs 1-based Indexing**
   - 0-based: parent = (i-1)//2, left = 2i+1, right = 2i+2
   - 1-based: parent = i//2, left = 2i, right = 2i+1

3. **Sift-Up vs Sift-Down**
   - Sift-Up: After insertion (move new element up)
   - Sift-Down: After extraction (move root replacement down)

## Common Mistakes to Avoid

1. Off-by-one errors in index calculations
2. Forgetting to check bounds before accessing children
3. Using wrong comparison operator for min-heap vs max-heap
4. Not handling empty heap edge case
