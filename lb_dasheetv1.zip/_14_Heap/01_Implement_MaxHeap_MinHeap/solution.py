"""
Problem: Implement MaxHeap/MinHeap Using Arrays

Complete implementation of both MaxHeap and MinHeap with all operations.
"""


class MaxHeap:
    """
    Max-Heap: Parent >= Children
    Root is always the maximum element
    """

    def __init__(self):
        self.heap = []

    def __len__(self):
        return len(self.heap)

    def __str__(self):
        return f"MaxHeap: {self.heap}"

    # ============== Index Calculations ==============
    def _parent(self, i):
        """Parent index: (i - 1) // 2"""
        return (i - 1) // 2

    def _left_child(self, i):
        """Left child index: 2 * i + 1"""
        return 2 * i + 1

    def _right_child(self, i):
        """Right child index: 2 * i + 2"""
        return 2 * i + 2

    def _swap(self, i, j):
        """Swap elements at indices i and j"""
        self.heap[i], self.heap[j] = self.heap[j], self.heap[i]

    # ============== Core Operations ==============

    def _sift_up(self, index):
        """
        Move element UP to restore heap property after insertion.
        Compare with parent, swap if current > parent.

        Time: O(log n)
        """
        while index > 0:
            parent_idx = self._parent(index)
            # In max-heap: if current > parent, swap
            if self.heap[index] > self.heap[parent_idx]:
                self._swap(index, parent_idx)
                index = parent_idx
            else:
                break  # Heap property satisfied

    def _sift_down(self, index):
        """
        Move element DOWN to restore heap property after extraction.
        Compare with children, swap with larger child if needed.

        Time: O(log n)
        """
        n = len(self.heap)

        while True:
            largest = index
            left = self._left_child(index)
            right = self._right_child(index)

            # Check if left child exists and is larger
            if left < n and self.heap[left] > self.heap[largest]:
                largest = left

            # Check if right child exists and is larger
            if right < n and self.heap[right] > self.heap[largest]:
                largest = right

            # If largest is not current, swap and continue
            if largest != index:
                self._swap(index, largest)
                index = largest
            else:
                break  # Heap property satisfied

    def insert(self, value):
        """
        Insert new value into the heap.

        Algorithm:
        1. Add at end (maintain complete tree)
        2. Sift up (restore heap property)

        Time: O(log n)
        Space: O(1)
        """
        self.heap.append(value)
        self._sift_up(len(self.heap) - 1)

    def extract_max(self):
        """
        Remove and return maximum element (root).

        Algorithm:
        1. Store root value
        2. Move last element to root
        3. Remove last position
        4. Sift down (restore heap property)

        Time: O(log n)
        Space: O(1)
        """
        if len(self.heap) == 0:
            raise IndexError("Heap is empty")

        if len(self.heap) == 1:
            return self.heap.pop()

        max_val = self.heap[0]
        # Move last element to root
        self.heap[0] = self.heap.pop()
        # Sift down to restore heap property
        self._sift_down(0)

        return max_val

    def peek(self):
        """Return maximum without removing. O(1)"""
        if len(self.heap) == 0:
            raise IndexError("Heap is empty")
        return self.heap[0]

    def build_heap(self, arr):
        """
        Build heap from array using bottom-up heapify.

        Algorithm:
        1. Copy array to heap
        2. Start from last non-leaf (n//2 - 1)
        3. Sift down each node from bottom to top

        Time: O(n) - NOT O(n log n)!
        Space: O(1) auxiliary
        """
        self.heap = arr.copy()
        n = len(self.heap)

        # Start from last non-leaf node
        # Leaves (indices n//2 to n-1) are already valid heaps
        start_idx = n // 2 - 1

        for i in range(start_idx, -1, -1):
            self._sift_down(i)


class MinHeap:
    """
    Min-Heap: Parent <= Children
    Root is always the minimum element
    """

    def __init__(self):
        self.heap = []

    def __len__(self):
        return len(self.heap)

    def __str__(self):
        return f"MinHeap: {self.heap}"

    def _parent(self, i):
        return (i - 1) // 2

    def _left_child(self, i):
        return 2 * i + 1

    def _right_child(self, i):
        return 2 * i + 2

    def _swap(self, i, j):
        self.heap[i], self.heap[j] = self.heap[j], self.heap[i]

    def _sift_up(self, index):
        """For min-heap: swap if current < parent"""
        while index > 0:
            parent_idx = self._parent(index)
            if self.heap[index] < self.heap[parent_idx]:
                self._swap(index, parent_idx)
                index = parent_idx
            else:
                break

    def _sift_down(self, index):
        """For min-heap: swap with smaller child"""
        n = len(self.heap)

        while True:
            smallest = index
            left = self._left_child(index)
            right = self._right_child(index)

            if left < n and self.heap[left] < self.heap[smallest]:
                smallest = left

            if right < n and self.heap[right] < self.heap[smallest]:
                smallest = right

            if smallest != index:
                self._swap(index, smallest)
                index = smallest
            else:
                break

    def insert(self, value):
        """Insert value. O(log n)"""
        self.heap.append(value)
        self._sift_up(len(self.heap) - 1)

    def extract_min(self):
        """Remove and return minimum. O(log n)"""
        if len(self.heap) == 0:
            raise IndexError("Heap is empty")

        if len(self.heap) == 1:
            return self.heap.pop()

        min_val = self.heap[0]
        self.heap[0] = self.heap.pop()
        self._sift_down(0)

        return min_val

    def peek(self):
        """Return minimum without removing. O(1)"""
        if len(self.heap) == 0:
            raise IndexError("Heap is empty")
        return self.heap[0]

    def build_heap(self, arr):
        """Build min-heap from array. O(n)"""
        self.heap = arr.copy()
        n = len(self.heap)
        start_idx = n // 2 - 1

        for i in range(start_idx, -1, -1):
            self._sift_down(i)


# ============== Test Cases ==============

def test_max_heap():
    print("=" * 50)
    print("Testing MaxHeap")
    print("=" * 50)

    heap = MaxHeap()

    # Test insert
    values = [4, 10, 3, 5, 1, 7, 8]
    print(f"\nInserting values: {values}")
    for val in values:
        heap.insert(val)
        print(f"  Insert {val}: {heap.heap}")

    # Test peek
    print(f"\nPeek (max): {heap.peek()}")

    # Test extract_max
    print("\nExtracting all elements:")
    while len(heap) > 0:
        print(f"  Extract max: {heap.extract_max()}, heap: {heap.heap}")

    # Test build_heap
    print("\n--- Build Heap from Array ---")
    arr = [4, 10, 3, 5, 1, 7, 8]
    print(f"Original array: {arr}")
    heap.build_heap(arr)
    print(f"After build_heap: {heap.heap}")


def test_min_heap():
    print("\n" + "=" * 50)
    print("Testing MinHeap")
    print("=" * 50)

    heap = MinHeap()

    # Test insert
    values = [4, 10, 3, 5, 1, 7, 8]
    print(f"\nInserting values: {values}")
    for val in values:
        heap.insert(val)
        print(f"  Insert {val}: {heap.heap}")

    # Test peek
    print(f"\nPeek (min): {heap.peek()}")

    # Test extract_min
    print("\nExtracting all elements:")
    while len(heap) > 0:
        print(f"  Extract min: {heap.extract_min()}, heap: {heap.heap}")

    # Test build_heap
    print("\n--- Build Heap from Array ---")
    arr = [4, 10, 3, 5, 1, 7, 8]
    print(f"Original array: {arr}")
    heap.build_heap(arr)
    print(f"After build_heap: {heap.heap}")


def test_edge_cases():
    print("\n" + "=" * 50)
    print("Testing Edge Cases")
    print("=" * 50)

    # Empty heap
    heap = MaxHeap()
    print(f"\nEmpty heap length: {len(heap)}")

    # Single element
    heap.insert(5)
    print(f"Single element: {heap.heap}")
    print(f"Extract: {heap.extract_max()}")
    print(f"After extract: {heap.heap}")

    # Duplicates
    heap = MaxHeap()
    for val in [5, 5, 5, 3, 3]:
        heap.insert(val)
    print(f"\nWith duplicates: {heap.heap}")

    # Already sorted (ascending)
    heap = MaxHeap()
    heap.build_heap([1, 2, 3, 4, 5])
    print(f"From sorted ascending: {heap.heap}")

    # Already sorted (descending - already a max-heap)
    heap = MaxHeap()
    heap.build_heap([5, 4, 3, 2, 1])
    print(f"From sorted descending: {heap.heap}")


if __name__ == "__main__":
    test_max_heap()
    test_min_heap()
    test_edge_cases()
