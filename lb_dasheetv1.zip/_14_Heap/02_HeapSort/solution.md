# HeapSort

## Problem Statement
Implement the HeapSort algorithm to sort an array in ascending order using a max-heap.

## Why Heap is Useful Here
- HeapSort leverages the max-heap property where the root is always the maximum
- By repeatedly extracting the maximum and placing it at the end, we get a sorted array
- In-place sorting with O(1) extra space
- Guaranteed O(n log n) worst-case (unlike QuickSort)

## Heap Operations Used
1. **Build Heap (Heapify)**: Convert array to max-heap
2. **Sift-Down**: Restore heap property after extraction

## Brute Force vs Heap Approach

| Approach | Time | Space | Stable? |
|----------|------|-------|---------|
| Selection Sort | O(n^2) | O(1) | No |
| Bubble Sort | O(n^2) | O(1) | Yes |
| **HeapSort** | **O(n log n)** | **O(1)** | **No** |
| Merge Sort | O(n log n) | O(n) | Yes |
| QuickSort | O(n log n) avg | O(log n) | No |

## HeapSort Algorithm

```
1. Build a max-heap from the array (O(n))
2. Repeat n-1 times:
   a. Swap root (maximum) with last element
   b. Reduce heap size by 1
   c. Sift-down the new root to restore heap property
3. Array is now sorted in ascending order
```

## Step-by-Step Example

```
Sort array: [4, 10, 3, 5, 1]

Step 1: Build Max-Heap
Initial:    [4, 10, 3, 5, 1]
After heapify: [10, 5, 3, 4, 1]

Tree view:
       10
      /  \
     5    3
    / \
   4   1

Step 2: Extract and Sort

Iteration 1:
- Swap root(10) with last(1): [1, 5, 3, 4, 10]
- Heap size = 4, sorted region = [10]
- Sift-down 1: [5, 4, 3, 1, | 10]
       5
      / \
     4   3
    /
   1

Iteration 2:
- Swap root(5) with last(1): [1, 4, 3, 5, | 10]
- Heap size = 3, sorted region = [5, 10]
- Sift-down 1: [4, 1, 3, | 5, 10]
       4
      / \
     1   3

Iteration 3:
- Swap root(4) with last(3): [3, 1, 4, | 5, 10]
- Heap size = 2, sorted region = [4, 5, 10]
- Sift-down 3: [3, 1, | 4, 5, 10]
       3
      /
     1

Iteration 4:
- Swap root(3) with last(1): [1, 3, | 4, 5, 10]
- Heap size = 1, sorted region = [3, 4, 5, 10]
- Sift-down not needed (single element)

Final: [1, 3, 4, 5, 10] - SORTED!
```

## Visual Representation

```
Original:     [4, 10, 3, 5, 1]
                    |
                    v
Build Heap:   [10, 5, 3, 4, 1]   <- Max at root
                    |
                    v
Extract 10:   [5, 4, 3, 1, |10]
                    |
Extract 5:    [4, 1, 3, |5, 10]
                    |
Extract 4:    [3, 1, |4, 5, 10]
                    |
Extract 3:    [1, |3, 4, 5, 10]
                    |
                    v
Sorted:       [1, 3, 4, 5, 10]
```

## Time and Space Complexity

| Phase | Time Complexity |
|-------|----------------|
| Build Heap | O(n) |
| Extract n times | n * O(log n) = O(n log n) |
| **Total** | **O(n log n)** |

| Complexity | Value |
|------------|-------|
| Best Case | O(n log n) |
| Average Case | O(n log n) |
| Worst Case | O(n log n) |
| Space | O(1) - in-place |

## Key Properties of HeapSort

1. **In-place**: Only O(1) extra space needed
2. **Not Stable**: Equal elements may change relative order
3. **Guaranteed Performance**: Always O(n log n), no worst case degradation
4. **Cache Unfriendly**: Poor cache performance compared to QuickSort

## When to Use HeapSort

Use HeapSort when:
- Memory is limited (needs only O(1) extra space)
- Guaranteed O(n log n) is required
- Data is too large for recursive QuickSort stack

Avoid HeapSort when:
- Stability is required
- Data fits in cache (QuickSort is faster in practice)
- Already nearly sorted (Insertion sort is better)

## Comparison with Other Sorts

| Property | HeapSort | QuickSort | MergeSort |
|----------|----------|-----------|-----------|
| Time (avg) | O(n log n) | O(n log n) | O(n log n) |
| Time (worst) | O(n log n) | O(n^2) | O(n log n) |
| Space | O(1) | O(log n) | O(n) |
| Stable | No | No | Yes |
| In-place | Yes | Yes | No |
| Cache | Poor | Good | Good |
