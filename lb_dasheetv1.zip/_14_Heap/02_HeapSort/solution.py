"""
Problem: HeapSort

Sort an array using heap data structure.
Time Complexity: O(n log n)
Space Complexity: O(1) - in-place
"""


def heapsort(arr):
    """
    HeapSort Algorithm - In-place sorting using max-heap.

    Algorithm:
    1. Build max-heap from array (O(n))
    2. Repeatedly extract max and place at end (O(n log n))

    Time: O(n log n)
    Space: O(1)
    """
    n = len(arr)

    def sift_down(heap_size, i):
        """
        Sift down element at index i to restore max-heap property.
        Only considers elements within heap_size.
        """
        while True:
            largest = i
            left = 2 * i + 1
            right = 2 * i + 2

            # Check if left child is larger
            if left < heap_size and arr[left] > arr[largest]:
                largest = left

            # Check if right child is larger
            if right < heap_size and arr[right] > arr[largest]:
                largest = right

            # If largest is not current, swap and continue
            if largest != i:
                arr[i], arr[largest] = arr[largest], arr[i]
                i = largest
            else:
                break

    # Phase 1: Build max-heap
    # Start from last non-leaf node
    for i in range(n // 2 - 1, -1, -1):
        sift_down(n, i)

    # Phase 2: Extract elements one by one
    for i in range(n - 1, 0, -1):
        # Move current root (maximum) to end
        arr[0], arr[i] = arr[i], arr[0]
        # Sift down on reduced heap
        sift_down(i, 0)

    return arr


def heapsort_with_visualization(arr):
    """
    HeapSort with step-by-step visualization.
    """
    n = len(arr)
    steps = []

    def sift_down(heap_size, i):
        while True:
            largest = i
            left = 2 * i + 1
            right = 2 * i + 2

            if left < heap_size and arr[left] > arr[largest]:
                largest = left
            if right < heap_size and arr[right] > arr[largest]:
                largest = right

            if largest != i:
                steps.append(f"  Swap arr[{i}]={arr[i]} with arr[{largest}]={arr[largest]}")
                arr[i], arr[largest] = arr[largest], arr[i]
                i = largest
            else:
                break

    print(f"Original array: {arr}")
    print("\n--- Phase 1: Build Max-Heap ---")

    for i in range(n // 2 - 1, -1, -1):
        print(f"Heapify at index {i} (value {arr[i]})")
        sift_down(n, i)
        for step in steps:
            print(step)
        steps.clear()
        print(f"  Array: {arr}")

    print(f"\nMax-heap built: {arr}")
    print("\n--- Phase 2: Extract and Sort ---")

    for i in range(n - 1, 0, -1):
        print(f"\nIteration {n - i}:")
        print(f"  Swap root {arr[0]} with position {i} (value {arr[i]})")
        arr[0], arr[i] = arr[i], arr[0]
        print(f"  Array: {arr}")
        print(f"  Sorted region: {arr[i:]}")
        print(f"  Heap region: {arr[:i]}")

        if i > 1:
            print(f"  Sift down new root ({arr[0]}):")
            sift_down(i, 0)
            for step in steps:
                print(step)
            steps.clear()
            print(f"  Array: {arr}")

    print(f"\nFinal sorted array: {arr}")
    return arr


def heapsort_descending(arr):
    """
    Sort in descending order using min-heap.
    """
    n = len(arr)

    def sift_down_min(heap_size, i):
        while True:
            smallest = i
            left = 2 * i + 1
            right = 2 * i + 2

            if left < heap_size and arr[left] < arr[smallest]:
                smallest = left
            if right < heap_size and arr[right] < arr[smallest]:
                smallest = right

            if smallest != i:
                arr[i], arr[smallest] = arr[smallest], arr[i]
                i = smallest
            else:
                break

    # Build min-heap
    for i in range(n // 2 - 1, -1, -1):
        sift_down_min(n, i)

    # Extract minimum elements
    for i in range(n - 1, 0, -1):
        arr[0], arr[i] = arr[i], arr[0]
        sift_down_min(i, 0)

    return arr


# Using Python's heapq for heapsort
import heapq


def heapsort_using_heapq(arr):
    """
    HeapSort using Python's heapq module.
    Note: This uses O(n) extra space.
    """
    heap = arr.copy()
    heapq.heapify(heap)  # Min-heap

    result = []
    while heap:
        result.append(heapq.heappop(heap))

    return result


# ============== Test Cases ==============

def test_heapsort():
    print("=" * 60)
    print("Testing HeapSort")
    print("=" * 60)

    # Test case 1: Random array
    arr = [64, 34, 25, 12, 22, 11, 90]
    print(f"\nTest 1 - Random: {arr}")
    result = heapsort(arr.copy())
    print(f"Sorted: {result}")
    assert result == sorted(arr), "Test 1 failed"

    # Test case 2: Already sorted
    arr = [1, 2, 3, 4, 5]
    print(f"\nTest 2 - Already sorted: {arr}")
    result = heapsort(arr.copy())
    print(f"Sorted: {result}")
    assert result == sorted(arr), "Test 2 failed"

    # Test case 3: Reverse sorted
    arr = [5, 4, 3, 2, 1]
    print(f"\nTest 3 - Reverse sorted: {arr}")
    result = heapsort(arr.copy())
    print(f"Sorted: {result}")
    assert result == sorted(arr), "Test 3 failed"

    # Test case 4: With duplicates
    arr = [5, 2, 8, 2, 9, 1, 5]
    print(f"\nTest 4 - With duplicates: {arr}")
    result = heapsort(arr.copy())
    print(f"Sorted: {result}")
    assert result == sorted(arr), "Test 4 failed"

    # Test case 5: Single element
    arr = [42]
    print(f"\nTest 5 - Single element: {arr}")
    result = heapsort(arr.copy())
    print(f"Sorted: {result}")
    assert result == [42], "Test 5 failed"

    # Test case 6: Empty array
    arr = []
    print(f"\nTest 6 - Empty: {arr}")
    result = heapsort(arr.copy())
    print(f"Sorted: {result}")
    assert result == [], "Test 6 failed"

    print("\n" + "=" * 60)
    print("All tests passed!")
    print("=" * 60)


def demo_visualization():
    print("\n" + "=" * 60)
    print("HeapSort Step-by-Step Visualization")
    print("=" * 60)

    arr = [4, 10, 3, 5, 1]
    heapsort_with_visualization(arr.copy())


def compare_sorts():
    print("\n" + "=" * 60)
    print("Comparing Different HeapSort Implementations")
    print("=" * 60)

    import time

    arr = list(range(1000, 0, -1))  # Worst case for some sorts

    # In-place heapsort
    start = time.time()
    heapsort(arr.copy())
    print(f"In-place heapsort: {time.time() - start:.6f}s")

    # Using heapq
    start = time.time()
    heapsort_using_heapq(arr.copy())
    print(f"Using heapq:       {time.time() - start:.6f}s")

    # Descending sort
    start = time.time()
    result = heapsort_descending(arr.copy())
    print(f"Descending sort:   {time.time() - start:.6f}s")
    print(f"First 5 elements (descending): {result[:5]}")


if __name__ == "__main__":
    test_heapsort()
    demo_visualization()
    compare_sorts()
