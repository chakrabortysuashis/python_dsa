"""
Problem: Kth Largest Sum of Continuous Subarrays

Find the Kth largest sum among all contiguous subarrays.

Example:
    Input: arr = [3, 2, 1], K = 2
    Output: 5
"""

import heapq


def kth_largest_subarray_sum(arr, k):
    """
    Using Min-Heap of size K.

    Time: O(n^2 log K)
    Space: O(K)
    """
    n = len(arr)
    min_heap = []

    for i in range(n):
        curr_sum = 0
        for j in range(i, n):
            curr_sum += arr[j]

            if len(min_heap) < k:
                heapq.heappush(min_heap, curr_sum)
            elif curr_sum > min_heap[0]:
                heapq.heapreplace(min_heap, curr_sum)

    return min_heap[0] if min_heap else None


def kth_largest_subarray_sum_brute(arr, k):
    """
    Brute force: Generate all sums, sort.

    Time: O(n^2 log n^2) = O(n^2 log n)
    Space: O(n^2)
    """
    sums = []
    n = len(arr)

    for i in range(n):
        curr_sum = 0
        for j in range(i, n):
            curr_sum += arr[j]
            sums.append(curr_sum)

    sums.sort(reverse=True)
    return sums[k - 1] if k <= len(sums) else None


def kth_largest_visualized(arr, k):
    """Step-by-step visualization."""
    print(f"Array: {arr}, K = {k}")
    print("=" * 50)

    n = len(arr)
    all_sums = []
    min_heap = []

    for i in range(n):
        curr_sum = 0
        for j in range(i, n):
            curr_sum += arr[j]
            subarray = arr[i:j + 1]
            all_sums.append((curr_sum, subarray))

            print(f"Subarray {subarray} = {curr_sum}")

            if len(min_heap) < k:
                heapq.heappush(min_heap, curr_sum)
                print(f"  Add to heap: {list(min_heap)}")
            elif curr_sum > min_heap[0]:
                old = heapq.heapreplace(min_heap, curr_sum)
                print(f"  Replace {old} with {curr_sum}: {list(min_heap)}")
            else:
                print(f"  Skip ({curr_sum} <= {min_heap[0]})")

    print("\n" + "=" * 50)
    print(f"All sums sorted: {sorted([s for s, _ in all_sums], reverse=True)}")
    print(f"Kth largest (K={k}): {min_heap[0]}")
    return min_heap[0]


# ============== Test Cases ==============

def test():
    print("Testing Kth Largest Subarray Sum")
    print("=" * 50)

    tests = [
        ([3, 2, 1], 2, 5),
        ([3, 2, 1], 4, 3),
        ([1, 2, 3], 3, 5),
        ([5, -1, 3], 2, 7),
        ([10, -10, 20], 1, 20),
    ]

    for arr, k, expected in tests:
        result = kth_largest_subarray_sum(arr, k)
        brute = kth_largest_subarray_sum_brute(arr, k)
        print(f"arr={arr}, k={k}: heap={result}, brute={brute}, expected={expected}")
        assert result == expected
        assert brute == expected

    print("\nAll tests passed!")


if __name__ == "__main__":
    test()
    print()
    kth_largest_visualized([3, 2, 1], 2)
