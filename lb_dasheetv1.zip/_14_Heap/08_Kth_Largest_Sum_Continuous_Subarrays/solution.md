# Kth Largest Sum of Continuous Subarrays

## Problem Statement
Given an array, find the Kth largest sum among all contiguous subarrays.

**Example:**
```
Input: arr = [3, 2, 1], K = 2
All subarray sums: [3], [2], [1], [3,2]=5, [2,1]=3, [3,2,1]=6
Sorted: [6, 5, 3, 3, 2, 1]
Output: 5 (2nd largest)
```

## Why Heap is Useful Here
- Need to find Kth largest among many sums
- Min-heap of size K efficiently tracks K largest
- Better than sorting all sums

## Approach

### 1. Generate All Subarray Sums
- Total subarrays: n*(n+1)/2
- Use prefix sum for O(1) subarray sum

### 2. Use Min-Heap of Size K
- Maintain K largest sums
- Top of heap = Kth largest

## Step-by-Step

```
arr = [3, 2, 1], K = 2

Generate sums:
  [3] = 3
  [3,2] = 5
  [3,2,1] = 6
  [2] = 2
  [2,1] = 3
  [1] = 1

Using min-heap of size 2:
  Add 3: heap = [3]
  Add 5: heap = [3, 5]
  Add 6: 6 > 3, replace: heap = [5, 6]
  Add 2: 2 < 5, skip
  Add 3: 3 < 5, skip
  Add 1: 1 < 5, skip

Result: heap[0] = 5 (Kth largest)
```

## Time and Space Complexity

| Complexity | Value |
|------------|-------|
| Time | O(n^2 log K) |
| Space | O(K) for heap |

## Optimization
- Use prefix sums for O(1) subarray sum calculation
- Avoid storing all sums

## Key Code Pattern

```python
import heapq

def kth_largest_subarray_sum(arr, k):
    n = len(arr)
    min_heap = []
    
    for i in range(n):
        curr_sum = 0
        for j in range(i, n):
            curr_sum += arr[j]
            
            if len(min_heap) < k:
                heapq.heappush(min_heap, curr_sum)
            elif curr_sum > min_heap[0]:
                heapq.heapreplace(min_heap, curr_sum)
    
    return min_heap[0]
```
