# Minimum Platforms Problem

## Problem Statement

Given arrival and departure times of all trains at a railway station, find the minimum number of platforms required so that no train has to wait.

**Input:**
- `arrival[]`: Array of arrival times
- `departure[]`: Array of departure times

**Output:**
- Minimum number of platforms needed

**Example:**
```
Arrival:   [9:00, 9:40, 9:50, 11:00, 15:00, 18:00]
Departure: [9:10, 12:00, 11:20, 11:30, 19:00, 20:00]

Output: 3 platforms

At 11:00:
- Train 2 (arrived 9:40, departs 12:00) - still present
- Train 3 (arrived 9:50, departs 11:20) - still present
- Train 4 (arrives 11:00) - arriving
= 3 trains at station simultaneously
```

---

## Why Greedy Works Here

### The Key Insight

We need to track how many trains are present at the station at any given moment. The maximum concurrent trains = minimum platforms needed.

**Greedy Strategy:** Process events (arrivals and departures) in chronological order and track the current count.

### Event-Based Approach

1. Treat arrivals and departures as separate events
2. Sort all events by time
3. Arrival = +1 train, Departure = -1 train
4. Maximum count at any point = answer

### Why This Works

- **Arrivals increase demand:** Each arriving train needs a platform
- **Departures free capacity:** Each departing train frees a platform
- **Ordering matters:** Process events in time order to track exact state
- **Peak detection:** Maximum concurrent trains is the bottleneck

### Greedy Choice Property

At each event:
- We must handle the event (no choice in accepting trains)
- The greedy insight is that we only need to track counts
- We don't need to track which specific platform each train uses

---

## Greedy Choice Property Explanation

### Why Not Track Individual Platforms?

You might think we need to:
1. Assign each train to a specific platform
2. Track which platforms are free
3. Find an assignment that minimizes platforms

But this is unnecessary! The maximum overlap determines the answer regardless of how we assign trains to platforms.

### The Overlap Principle

```
Time:    9:00  9:40  9:50  11:00  11:20  11:30  12:00
         |     |     |      |      |      |      |
Train 1: [====]
Train 2:       [==========================]
Train 3:             [=============]
Train 4:                    [=======]

At time 11:00: Trains 2, 3, 4 are all present = 3 platforms needed
```

No matter how we assign platforms, we need at least 3 when there's a moment with 3 overlapping trains.

---

## Step-by-Step Algorithm

### Method 1: Two Pointer Approach

```
1. SORT arrival times
2. SORT departure times (separately)
3. Use two pointers: i for arrivals, j for departures
4. WHILE i < n:
   a. IF arrival[i] <= departure[j]:
      - Train arriving: platforms_needed++
      - Update max_platforms
      - i++
   b. ELSE:
      - Train departing: platforms_needed--
      - j++
5. RETURN max_platforms
```

### Method 2: Event-Based Approach

```
1. CREATE events list: (time, type) where type = +1 for arrival, -1 for departure
2. SORT events by time (departures before arrivals at same time)
3. FOR each event:
   - current_count += event.type
   - max_count = max(max_count, current_count)
4. RETURN max_count
```

---

## Brute Force Comparison

### Brute Force: Check Every Time Point

```python
def brute_force(arrivals, departures):
    all_times = sorted(set(arrivals + departures))
    max_platforms = 0
    
    for t in all_times:
        count = 0
        for i in range(len(arrivals)):
            if arrivals[i] <= t <= departures[i]:
                count += 1
        max_platforms = max(max_platforms, count)
    
    return max_platforms
```

**Time: O(n^2)** - For each time point, check all trains

### Comparison

| Approach | Time | Space |
|----------|------|-------|
| Brute Force | O(n^2) | O(n) |
| Two Pointers | O(n log n) | O(1) extra |
| Event-Based | O(n log n) | O(n) |

---

## Optimal Implementation

```python
def min_platforms_two_pointer(arrivals, departures):
    """
    Find minimum platforms using two-pointer technique.
    
    Time: O(n log n)
    Space: O(1) extra (sorting may use O(n))
    """
    n = len(arrivals)
    
    # Sort both arrays
    arrivals = sorted(arrivals)
    departures = sorted(departures)
    
    platforms_needed = 0
    max_platforms = 0
    i, j = 0, 0
    
    while i < n:
        # If next event is arrival
        if arrivals[i] <= departures[j]:
            platforms_needed += 1
            max_platforms = max(max_platforms, platforms_needed)
            i += 1
        else:
            # Next event is departure
            platforms_needed -= 1
            j += 1
    
    return max_platforms
```

---

## Dry Run with Selection Visualization

**Input:**
```
Arrivals:   [900, 940, 950, 1100, 1500, 1800]
Departures: [910, 1200, 1120, 1130, 1900, 2000]
```

### Step-by-Step Execution

```
Sorted Arrivals:   [900, 940, 950, 1100, 1500, 1800]
Sorted Departures: [910, 1120, 1130, 1200, 1900, 2000]

i=0, j=0, platforms=0, max=0

Step 1: arr[0]=900 <= dep[0]=910
        Arrival! platforms = 1, max = 1, i = 1
        
        Timeline: T1 arrives
        Platforms: [T1]

Step 2: arr[1]=940 <= dep[0]=910? NO
        Departure! platforms = 0, j = 1
        
        Timeline: T1 departs
        Platforms: []

Step 3: arr[1]=940 <= dep[1]=1120? YES
        Arrival! platforms = 1, max = 1, i = 2
        
        Timeline: T2 arrives
        Platforms: [T2]

Step 4: arr[2]=950 <= dep[1]=1120? YES
        Arrival! platforms = 2, max = 2, i = 3
        
        Timeline: T3 arrives
        Platforms: [T2, T3]

Step 5: arr[3]=1100 <= dep[1]=1120? YES
        Arrival! platforms = 3, max = 3, i = 4
        
        Timeline: T4 arrives
        Platforms: [T2, T3, T4]  <-- PEAK!

Step 6: arr[4]=1500 <= dep[1]=1120? NO
        Departure! platforms = 2, j = 2
        
        Timeline: A train departs
        Platforms: [T2, T4] (T3 departed)

Step 7: arr[4]=1500 <= dep[2]=1130? NO
        Departure! platforms = 1, j = 3

Step 8: arr[4]=1500 <= dep[3]=1200? NO
        Departure! platforms = 0, j = 4

Step 9: arr[4]=1500 <= dep[4]=1900? YES
        Arrival! platforms = 1, max = 3, i = 5

Step 10: arr[5]=1800 <= dep[4]=1900? YES
         Arrival! platforms = 2, max = 3, i = 6

Done! i >= n

Result: max_platforms = 3
```

### Visual Timeline

```
Time:   9:00  9:10  9:40  9:50  11:00  11:20  11:30  12:00  15:00  18:00  19:00  20:00
        |     |     |     |      |      |      |      |      |      |      |      |
T1:     [=====]
T2:                 [===============================================]
T3:                       [==============]
T4:                              [================]
T5:                                                        [================]
T6:                                                               [================]

Platforms at each point:
  9:00  -> 1 (T1)
  9:10  -> 0 
  9:40  -> 1 (T2)
  9:50  -> 2 (T2, T3)
  11:00 -> 3 (T2, T3, T4)  <-- MAXIMUM
  11:20 -> 2 (T2, T4)
  11:30 -> 1 (T2)
  12:00 -> 0
  15:00 -> 1 (T5)
  18:00 -> 2 (T5, T6)
  19:00 -> 1 (T6)
  20:00 -> 0

Minimum platforms needed: 3
```

---

## Time and Space Complexity

### Two Pointer Approach

| Operation | Complexity |
|-----------|------------|
| Sort arrivals | O(n log n) |
| Sort departures | O(n log n) |
| Two pointer scan | O(n) |
| **Total Time** | **O(n log n)** |
| **Space** | **O(1) extra** |

### Event-Based Approach

| Operation | Complexity |
|-----------|------------|
| Create events | O(n) |
| Sort events | O(n log n) |
| Process events | O(n) |
| **Total Time** | **O(n log n)** |
| **Space** | **O(n)** |

---

## Variations and Extensions

### 1. Handling Same-Time Events

If arrival and departure happen at same time, departure should be processed first (train leaves, making room for arriving train).

```python
# In event-based approach:
events.sort(key=lambda x: (x[0], x[1]))  # Sort by time, then type (-1 before +1)
```

### 2. Finding Peak Time

Return not just the count but also when the peak occurs.

### 3. Platform Assignment

If you need to actually assign platforms to trains, use a min-heap of available platforms.

### 4. Maximum Gap Between Trains

Find the longest time period when no trains are at the station.

### 5. Real-World Considerations

- Buffer time for platform preparation
- Through trains vs. terminating trains
- Peak hour patterns
- Platform capacity limits
