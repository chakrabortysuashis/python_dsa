"""
Minimum Platforms Problem - Greedy Algorithm
============================================

Problem: Given arrival and departure times of trains, find the minimum
number of platforms required so no train has to wait.

WHY GREEDY WORKS:
----------------
1. Event Processing: We process arrivals and departures as events.
   Arrivals increase platform demand, departures decrease it.

2. Chronological Order: Processing events in time order gives us the
   exact state of the station at each moment.

3. Peak Detection: The maximum concurrent trains at any point is the
   answer - we don't need to track specific platform assignments.

4. No Trade-offs: Every train must be accommodated; there's no choice
   in accepting/rejecting trains. We simply count.

GREEDY STRATEGY:
- Create events from arrivals (+1) and departures (-1)
- Sort events by time
- Process events, tracking current count
- Maximum count = minimum platforms needed
"""

from typing import List, Tuple


def min_platforms_two_pointer(
    arrivals: List[int],
    departures: List[int]
) -> int:
    """
    Find minimum platforms using two-pointer technique.

    Strategy:
    1. Sort arrivals and departures separately
    2. Use two pointers to process events in order
    3. Track current and maximum platform count

    Args:
        arrivals: List of arrival times
        departures: List of departure times

    Returns:
        Minimum platforms needed

    Time: O(n log n)
    Space: O(1) extra (sorting may use O(n))

    Example:
    >>> min_platforms_two_pointer([900, 940, 950, 1100], [910, 1200, 1120, 1130])
    3
    """
    n = len(arrivals)
    if n == 0:
        return 0

    # Sort both arrays
    arr = sorted(arrivals)
    dep = sorted(departures)

    platforms_needed = 0
    max_platforms = 0
    i, j = 0, 0

    # Process all arrivals
    while i < n:
        # Compare next arrival with next departure
        if arr[i] <= dep[j]:
            # Arrival event: need one more platform
            platforms_needed += 1
            max_platforms = max(max_platforms, platforms_needed)
            i += 1
        else:
            # Departure event: free one platform
            platforms_needed -= 1
            j += 1

    return max_platforms


def min_platforms_events(
    arrivals: List[int],
    departures: List[int]
) -> int:
    """
    Find minimum platforms using event-based approach.

    Strategy:
    1. Create events: (time, type) where type = +1 (arrival) or -1 (departure)
    2. Sort by time, departures before arrivals at same time
    3. Process events and track maximum count

    Time: O(n log n)
    Space: O(n) for events list
    """
    n = len(arrivals)
    if n == 0:
        return 0

    # Create events: (time, type)
    # Use type = 1 for arrival, -1 for departure
    # Departure has lower value so it's processed first at same time
    events = []

    for i in range(n):
        events.append((arrivals[i], 1))    # Arrival
        events.append((departures[i], -1))  # Departure

    # Sort by time, departures first at same time
    events.sort(key=lambda x: (x[0], x[1]))

    current = 0
    max_platforms = 0

    for time, event_type in events:
        current += event_type
        max_platforms = max(max_platforms, current)

    return max_platforms


def min_platforms_detailed(
    trains: List[Tuple[str, int, int]]
) -> Tuple[int, int, List[str]]:
    """
    Detailed solution showing when peak occurs and which trains are present.

    Args:
        trains: List of (train_name, arrival, departure)

    Returns:
        (min_platforms, peak_time, list of train names present at peak)
    """
    if not trains:
        return 0, 0, []

    # Create events with train info
    events = []
    for name, arr, dep in trains:
        events.append((arr, 1, name))   # Arrival
        events.append((dep, -1, name))  # Departure

    events.sort(key=lambda x: (x[0], x[1]))

    current = 0
    max_platforms = 0
    peak_time = 0
    active_trains = set()
    peak_trains = []

    for time, event_type, name in events:
        if event_type == 1:
            active_trains.add(name)
            current += 1
        else:
            active_trains.discard(name)
            current -= 1

        if current > max_platforms:
            max_platforms = current
            peak_time = time
            peak_trains = list(active_trains)

    return max_platforms, peak_time, peak_trains


def count_platforms_at_time(
    arrivals: List[int],
    departures: List[int],
    time: int
) -> int:
    """
    Count how many platforms are needed at a specific time.

    Useful for debugging and verification.
    """
    count = 0
    for arr, dep in zip(arrivals, departures):
        if arr <= time <= dep:
            count += 1
    return count


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Comprehensive test cases with explanations."""

    print("=" * 60)
    print("MINIMUM PLATFORMS - TEST CASES")
    print("=" * 60)

    # Test 1: Classic example
    print("\nTest 1: Classic Example")
    print("-" * 40)
    arrivals = [900, 940, 950, 1100, 1500, 1800]
    departures = [910, 1200, 1120, 1130, 1900, 2000]

    result1 = min_platforms_two_pointer(arrivals, departures)
    result2 = min_platforms_events(arrivals, departures)

    print(f"Arrivals:   {arrivals}")
    print(f"Departures: {departures}")
    print(f"Two-pointer result: {result1}")
    print(f"Event-based result: {result2}")
    assert result1 == result2 == 3

    # Test 2: Detailed analysis
    print("\nTest 2: Detailed Analysis")
    print("-" * 40)
    trains = [
        ('T1', 900, 910),
        ('T2', 940, 1200),
        ('T3', 950, 1120),
        ('T4', 1100, 1130),
        ('T5', 1500, 1900),
        ('T6', 1800, 2000)
    ]

    platforms, peak_time, peak_trains = min_platforms_detailed(trains)
    print(f"Minimum platforms: {platforms}")
    print(f"Peak time: {peak_time}")
    print(f"Trains at peak: {peak_trains}")

    # Test 3: No overlap
    print("\nTest 3: No Overlap")
    print("-" * 40)
    arrivals = [900, 1000, 1100]
    departures = [930, 1030, 1130]

    result = min_platforms_two_pointer(arrivals, departures)
    print(f"Non-overlapping trains")
    print(f"Result: {result}")
    assert result == 1

    # Test 4: Complete overlap
    print("\nTest 4: Complete Overlap")
    print("-" * 40)
    arrivals = [900, 900, 900]
    departures = [1000, 1000, 1000]

    result = min_platforms_two_pointer(arrivals, departures)
    print(f"All trains arrive and depart together")
    print(f"Result: {result}")
    assert result == 3

    # Test 5: Same arrival and departure time
    print("\nTest 5: Same Time Events")
    print("-" * 40)
    arrivals = [900, 910]
    departures = [910, 920]

    result = min_platforms_events(arrivals, departures)
    print(f"Train 1: 900-910, Train 2: 910-920")
    print(f"Result: {result}")
    # At 910: T1 departs, T2 arrives. Same platform can be reused.
    assert result == 1

    # Test 6: Empty input
    print("\nTest 6: Empty Input")
    print("-" * 40)
    result = min_platforms_two_pointer([], [])
    print(f"Empty input: {result}")
    assert result == 0

    # Test 7: Single train
    print("\nTest 7: Single Train")
    print("-" * 40)
    result = min_platforms_two_pointer([900], [1000])
    print(f"Single train: {result}")
    assert result == 1

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_greedy_choice():
    """Step-by-step demonstration of the algorithm."""

    print("\n" + "=" * 60)
    print("DEMONSTRATION: GREEDY PLATFORM COUNTING")
    print("=" * 60)

    trains = [
        ('T1', 900, 910),
        ('T2', 940, 1200),
        ('T3', 950, 1120),
        ('T4', 1100, 1130)
    ]

    print("\nTrains:")
    for name, arr, dep in trains:
        print(f"  {name}: {arr} - {dep}")

    # Create events
    events = []
    for name, arr, dep in trains:
        events.append((arr, 1, name))
        events.append((dep, -1, name))

    events.sort(key=lambda x: (x[0], x[1]))

    print("\n" + "-" * 40)
    print("EVENTS IN ORDER:")
    print("-" * 40)

    for time, etype, name in events:
        event_str = "ARRIVAL" if etype == 1 else "DEPARTURE"
        print(f"  {time}: {name} {event_str}")

    print("\n" + "-" * 40)
    print("PROCESSING EVENTS:")
    print("-" * 40)

    current = 0
    max_platforms = 0
    active = set()

    for time, etype, name in events:
        if etype == 1:
            active.add(name)
            current += 1
            action = "+"
        else:
            active.discard(name)
            current -= 1
            action = "-"

        max_platforms = max(max_platforms, current)

        print(f"\n{time}: {name} {'arrives' if etype == 1 else 'departs'}")
        print(f"  Platforms: {current} ({action}1)")
        print(f"  Active: {active}")
        print(f"  Max so far: {max_platforms}")

    print("\n" + "-" * 40)
    print(f"ANSWER: {max_platforms} platforms needed")
    print("-" * 40)

    print("\nWHY THIS WORKS:")
    print("1. We don't track WHICH platform each train uses")
    print("2. We only count HOW MANY trains are present")
    print("3. Peak count = minimum platforms needed")
    print("4. Any platform assignment will need this many platforms")


if __name__ == "__main__":
    run_tests()
    demonstrate_greedy_choice()
