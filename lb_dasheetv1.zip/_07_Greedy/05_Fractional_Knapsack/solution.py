"""
Fractional Knapsack Problem - Greedy Algorithm
===============================================

Problem: Given items with values and weights, fill a knapsack of capacity W
to maximize total value. Unlike 0/1 knapsack, fractions of items can be taken.

WHY GREEDY WORKS:
----------------
1. Divisibility: Since we can take fractions, we never "waste" capacity.

2. Ratio Optimization: Value-to-weight ratio measures "bang for buck".
   Taking highest ratio items first maximizes value per unit weight.

3. No Trade-offs: In 0/1 knapsack, taking one item might prevent taking
   a better combination. With fractions, there's no such trade-off.

4. Exchange Argument: If optimal solution takes lower-ratio item before
   higher-ratio item, swapping improves or maintains value.

GREEDY STRATEGY:
- Calculate value/weight ratio for each item
- Sort by ratio descending
- Take items greedily: full items when possible, fraction when needed
"""

from typing import List, Tuple, Optional
from dataclasses import dataclass


@dataclass
class Item:
    """Item with value, weight, and optional identifier."""
    value: float
    weight: float
    name: str = ""

    @property
    def ratio(self) -> float:
        """Value-to-weight ratio."""
        return self.value / self.weight if self.weight > 0 else float('inf')


def fractional_knapsack(
    values: List[float],
    weights: List[float],
    capacity: float
) -> float:
    """
    Solve fractional knapsack problem.

    Greedy Strategy:
    1. Sort items by value/weight ratio (descending)
    2. Take items in order: full if fits, fraction otherwise
    3. Stop when capacity is exhausted

    Args:
        values: List of item values
        weights: List of item weights
        capacity: Maximum weight capacity

    Returns:
        Maximum achievable value

    Time: O(n log n) for sorting
    Space: O(n) for items array

    Example:
    >>> fractional_knapsack([60, 100, 120], [10, 20, 30], 50)
    240.0
    """
    if not values or capacity <= 0:
        return 0.0

    n = len(values)

    # Create items with ratios and sort by ratio (descending)
    items = [(values[i], weights[i], values[i]/weights[i]) for i in range(n)]
    items.sort(key=lambda x: x[2], reverse=True)

    total_value = 0.0
    remaining = capacity

    for value, weight, ratio in items:
        if remaining <= 0:
            break

        if weight <= remaining:
            # Take entire item
            total_value += value
            remaining -= weight
        else:
            # Take fraction of item
            fraction = remaining / weight
            total_value += fraction * value
            remaining = 0

    return total_value


def fractional_knapsack_detailed(
    items: List[Item],
    capacity: float
) -> Tuple[float, List[Tuple[str, float, float]]]:
    """
    Detailed fractional knapsack with selection information.

    Args:
        items: List of Item objects
        capacity: Maximum weight capacity

    Returns:
        (total_value, list of (item_name, fraction_taken, value_added))

    Example:
    >>> items = [Item(60, 10, 'A'), Item(100, 20, 'B'), Item(120, 30, 'C')]
    >>> value, taken = fractional_knapsack_detailed(items, 50)
    >>> value
    240.0
    """
    if not items or capacity <= 0:
        return 0.0, []

    # Sort by ratio descending
    sorted_items = sorted(items, key=lambda x: x.ratio, reverse=True)

    total_value = 0.0
    remaining = capacity
    taken = []

    for item in sorted_items:
        if remaining <= 0:
            break

        if item.weight <= remaining:
            # Take full item
            total_value += item.value
            remaining -= item.weight
            taken.append((item.name, 1.0, item.value))
        else:
            # Take fraction
            fraction = remaining / item.weight
            value_added = fraction * item.value
            total_value += value_added
            remaining = 0
            taken.append((item.name, fraction, value_added))

    return total_value, taken


def knapsack_comparison(
    values: List[float],
    weights: List[float],
    capacity: float
) -> dict:
    """
    Compare fractional knapsack with 0/1 knapsack (DP).

    Shows why greedy works for fractional but not 0/1.
    """
    n = len(values)

    # Fractional (Greedy)
    fractional_value = fractional_knapsack(values, weights, capacity)

    # 0/1 (Dynamic Programming)
    W = int(capacity)
    dp = [[0] * (W + 1) for _ in range(n + 1)]

    for i in range(1, n + 1):
        for w in range(W + 1):
            dp[i][w] = dp[i-1][w]  # Don't take item i
            if weights[i-1] <= w:
                # Take item i if it fits
                dp[i][w] = max(dp[i][w], dp[i-1][w-int(weights[i-1])] + values[i-1])

    zero_one_value = dp[n][W]

    # Greedy 0/1 (by ratio - often suboptimal)
    items = [(values[i], weights[i], values[i]/weights[i], i) for i in range(n)]
    items.sort(key=lambda x: x[2], reverse=True)

    greedy_01_value = 0
    greedy_01_weight = 0

    for value, weight, ratio, idx in items:
        if greedy_01_weight + weight <= capacity:
            greedy_01_value += value
            greedy_01_weight += weight

    return {
        'fractional_greedy': fractional_value,
        'zero_one_dp': zero_one_value,
        'zero_one_greedy': greedy_01_value,
        'greedy_optimal_for_fractional': True,
        'greedy_optimal_for_01': greedy_01_value == zero_one_value
    }


# =============================================================================
# VARIATIONS
# =============================================================================

def fractional_knapsack_with_limits(
    values: List[float],
    weights: List[float],
    limits: List[float],
    capacity: float
) -> float:
    """
    Fractional knapsack where each item has a maximum available quantity.

    Args:
        values: Value per unit weight
        weights: Weight per unit
        limits: Maximum units available for each item
        capacity: Knapsack capacity
    """
    n = len(values)

    # (value_per_unit, weight_per_unit, available_weight, ratio)
    items = []
    for i in range(n):
        available_weight = weights[i] * limits[i]
        items.append((values[i], weights[i], available_weight, values[i]/weights[i]))

    items.sort(key=lambda x: x[3], reverse=True)

    total_value = 0.0
    remaining = capacity

    for value_per_unit, weight_per_unit, available_weight, ratio in items:
        if remaining <= 0:
            break

        take_weight = min(available_weight, remaining)
        total_value += (take_weight / weight_per_unit) * value_per_unit
        remaining -= take_weight

    return total_value


def multiple_knapsacks(
    values: List[float],
    weights: List[float],
    capacities: List[float]
) -> float:
    """
    Fill multiple knapsacks optimally (fractional items).

    For divisible items, this is still greedy-optimal:
    sort by ratio, fill knapsacks in any order.
    """
    total_capacity = sum(capacities)
    return fractional_knapsack(values, weights, total_capacity)


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Comprehensive test cases with explanations."""

    print("=" * 60)
    print("FRACTIONAL KNAPSACK - TEST CASES")
    print("=" * 60)

    # Test 1: Classic example
    print("\nTest 1: Classic Example")
    print("-" * 40)
    values = [60, 100, 120]
    weights = [10, 20, 30]
    capacity = 50

    result = fractional_knapsack(values, weights, capacity)
    print(f"Items: {list(zip(values, weights))}")
    print(f"Capacity: {capacity}")
    print(f"Ratios: {[v/w for v, w in zip(values, weights)]}")
    print(f"Maximum value: {result}")
    assert result == 240.0, f"Expected 240.0, got {result}"

    # Test 2: Detailed selection
    print("\nTest 2: Detailed Selection")
    print("-" * 40)
    items = [
        Item(60, 10, 'A'),
        Item(100, 20, 'B'),
        Item(120, 30, 'C')
    ]

    value, taken = fractional_knapsack_detailed(items, 50)
    print(f"Items: {[(i.name, i.value, i.weight, i.ratio) for i in items]}")
    print(f"\nSelection:")
    for name, fraction, val in taken:
        print(f"  {name}: {fraction*100:.1f}% taken, value = {val:.1f}")
    print(f"Total value: {value}")

    # Test 3: All items fit
    print("\nTest 3: All Items Fit")
    print("-" * 40)
    values = [10, 20, 30]
    weights = [1, 2, 3]
    capacity = 100

    result = fractional_knapsack(values, weights, capacity)
    print(f"Large capacity, all items fit")
    print(f"Total value: {result}")
    assert result == 60.0

    # Test 4: Fractional vs 0/1 comparison
    print("\nTest 4: Fractional vs 0/1 Knapsack Comparison")
    print("-" * 40)
    values = [60, 100, 120]
    weights = [10, 20, 30]
    capacity = 50

    comparison = knapsack_comparison(values, weights, capacity)
    print(f"Fractional (Greedy): {comparison['fractional_greedy']}")
    print(f"0/1 (DP): {comparison['zero_one_dp']}")
    print(f"0/1 (Greedy by ratio): {comparison['zero_one_greedy']}")
    print(f"Greedy optimal for fractional: {comparison['greedy_optimal_for_fractional']}")
    print(f"Greedy optimal for 0/1: {comparison['greedy_optimal_for_01']}")

    # Test 5: Edge case - zero capacity
    print("\nTest 5: Zero Capacity")
    print("-" * 40)
    result = fractional_knapsack([10, 20], [1, 2], 0)
    print(f"Zero capacity: {result}")
    assert result == 0.0

    # Test 6: Single item
    print("\nTest 6: Single Item (Partial)")
    print("-" * 40)
    result = fractional_knapsack([100], [50], 25)
    print(f"Item: value=100, weight=50")
    print(f"Capacity: 25 (half of item weight)")
    print(f"Value obtained: {result}")
    assert result == 50.0  # Take half the item

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_greedy_choice():
    """Step-by-step demonstration of greedy approach."""

    print("\n" + "=" * 60)
    print("DEMONSTRATION: WHY GREEDY WORKS")
    print("=" * 60)

    items = [
        Item(60, 10, 'A'),
        Item(100, 20, 'B'),
        Item(120, 30, 'C')
    ]
    capacity = 50

    print("\nOriginal items:")
    for item in items:
        print(f"  {item.name}: value={item.value}, weight={item.weight}, ratio={item.ratio:.2f}")

    # Sort by ratio
    sorted_items = sorted(items, key=lambda x: x.ratio, reverse=True)

    print("\nAfter sorting by RATIO (value/weight) descending:")
    for item in sorted_items:
        print(f"  {item.name}: ratio={item.ratio:.2f}")

    print("\n" + "-" * 40)
    print("GREEDY SELECTION:")
    print("-" * 40)

    total_value = 0.0
    remaining = capacity

    for item in sorted_items:
        print(f"\nConsidering {item.name}:")
        print(f"  Ratio: {item.ratio:.2f} (${item.ratio:.2f} value per unit weight)")
        print(f"  Item weight: {item.weight}, Remaining capacity: {remaining}")

        if remaining <= 0:
            print(f"  Knapsack full, skip")
            continue

        if item.weight <= remaining:
            total_value += item.value
            remaining -= item.weight
            print(f"  -> Take ENTIRE item")
            print(f"  -> Value added: {item.value}, New total: {total_value}")
        else:
            fraction = remaining / item.weight
            value_added = fraction * item.value
            total_value += value_added
            remaining = 0
            print(f"  -> Take {fraction*100:.1f}% of item (only {remaining:.1f} capacity left)")
            print(f"  -> Value added: {value_added:.1f}, New total: {total_value}")

    print("\n" + "-" * 40)
    print(f"FINAL VALUE: ${total_value}")
    print("-" * 40)

    print("\nWHY RATIO-BASED GREEDY IS OPTIMAL:")
    print("1. Higher ratio = more value per unit weight")
    print("2. Since we can take fractions, we fill capacity exactly")
    print("3. No capacity is wasted, no better arrangement possible")
    print("4. Taking any lower-ratio item first would mean less value per weight")


if __name__ == "__main__":
    run_tests()
    demonstrate_greedy_choice()
