# Fractional Knapsack Problem

## Problem Statement

Given weights and values of `n` items, put these items in a knapsack of capacity `W` to get the maximum total value. Unlike the 0/1 knapsack problem, you can take fractions of items.

**Input:**
- `n`: Number of items
- `W`: Knapsack capacity
- `values[]`: Value of each item
- `weights[]`: Weight of each item

**Output:**
- Maximum total value that can be achieved

**Example:**
```
Items: [(value=60, weight=10), (value=100, weight=20), (value=120, weight=30)]
Capacity: 50

Output: 240
Explanation:
- Take full item 1: value=60, weight=10
- Take full item 2: value=100, weight=20
- Take 2/3 of item 3: value=80, weight=20
- Total: 60 + 100 + 80 = 240
```

---

## Why Greedy Works Here

### The Key Insight: Value-to-Weight Ratio

**Greedy Strategy:** Always take items with the highest value-to-weight ratio first.

### Why This Works for Fractional Knapsack

1. **Divisibility:** Since we can take fractions, we never "waste" capacity
2. **No Trade-offs:** Taking the best ratio item is always optimal
3. **Continuous Optimization:** Each unit of weight gets maximum value

### Exchange Argument Proof

**Claim:** Taking items in order of decreasing value/weight ratio is optimal.

**Proof:**
1. Suppose optimal solution OPT takes item `j` with ratio `r_j` before item `i` with ratio `r_i` where `r_i > r_j`
2. We can swap some of item `j` with the same weight of item `i`
3. New value = old value + (weight swapped) * (`r_i - r_j`)
4. Since `r_i > r_j`, this increases the value
5. Contradiction! So OPT must follow ratio order.

### Why Greedy Fails for 0/1 Knapsack

```
Items: [(value=60, weight=10), (value=100, weight=20), (value=120, weight=30)]
Capacity: 30

Greedy by ratio: Item 1 (ratio 6) -> weight 10, value 60
                 Need 20 more capacity, can't fit item 2 or 3 fully
                 Result: 60 (WRONG!)

0/1 Optimal:     Item 2 (value 100, weight 20)
                 Item 1 (value 60, weight 10)
                 Result: 160 (or Item 3 alone = 120, or Item 2+1 = 160)

The difference: In 0/1, taking item 1 first might prevent taking better combinations.
In fractional, we can always take partial items to fill exactly.
```

---

## Greedy Choice Property Explanation

### The Ratio Analysis

For each item `i`:
```
Ratio_i = Value_i / Weight_i
```

This ratio tells us: "How much value do we get per unit weight?"

### The Greedy Decision

At each step:
1. Look at all remaining items
2. Pick the one with highest ratio
3. Take as much of it as possible
4. Repeat until knapsack is full

### Why No Regret?

```
Suppose we have remaining capacity C and two items:
  Item A: ratio 5, weight available = 10
  Item B: ratio 3, weight available = 20

Taking weight W of item A gives value: 5 * W
Taking weight W of item B gives value: 3 * W

For any weight W, taking A gives more value.
Therefore, we should always prefer A until it's exhausted.
```

---

## Step-by-Step Algorithm

```
1. CALCULATE ratio (value/weight) for each item
2. SORT items by ratio in descending order
3. INITIALIZE: total_value = 0, remaining_capacity = W
4. FOR each item in sorted order:
   a. IF item.weight <= remaining_capacity:
      - Take entire item
      - total_value += item.value
      - remaining_capacity -= item.weight
   b. ELSE:
      - Take fraction of item
      - fraction = remaining_capacity / item.weight
      - total_value += fraction * item.value
      - remaining_capacity = 0
      - BREAK (knapsack is full)
5. RETURN total_value
```

---

## Brute Force Comparison

### Brute Force for 0/1 Knapsack (Reference)

```python
def knapsack_01_brute(values, weights, capacity):
    n = len(values)
    max_value = 0
    
    for mask in range(1 << n):  # 2^n subsets
        total_weight = 0
        total_value = 0
        
        for i in range(n):
            if mask & (1 << i):
                total_weight += weights[i]
                total_value += values[i]
        
        if total_weight <= capacity:
            max_value = max(max_value, total_value)
    
    return max_value
```

**Time: O(2^n)**

### For Fractional Knapsack

Brute force doesn't make sense because:
- There are infinite ways to divide items
- The ratio-based greedy is provably optimal

**Greedy Time: O(n log n)**

---

## Optimal Greedy Implementation

```python
def fractional_knapsack(values, weights, capacity):
    """
    Solve fractional knapsack using greedy approach.
    
    Args:
        values: List of item values
        weights: List of item weights
        capacity: Knapsack capacity
    
    Returns:
        Maximum achievable value
    """
    n = len(values)
    
    # Create items with ratios
    items = [(values[i], weights[i], values[i]/weights[i], i) 
             for i in range(n)]
    
    # Sort by ratio (descending)
    items.sort(key=lambda x: x[2], reverse=True)
    
    total_value = 0.0
    remaining = capacity
    
    for value, weight, ratio, idx in items:
        if remaining <= 0:
            break
            
        if weight <= remaining:
            # Take entire item
            total_value += value
            remaining -= weight
        else:
            # Take fraction
            fraction = remaining / weight
            total_value += fraction * value
            remaining = 0
    
    return total_value
```

**Time Complexity:** O(n log n)
**Space Complexity:** O(n)

---

## Dry Run with Selection Visualization

**Input:**
```
Items: A(v=60, w=10), B(v=100, w=20), C(v=120, w=30)
Capacity: 50
```

### Step 1: Calculate Ratios

```
Item A: ratio = 60/10 = 6.0
Item B: ratio = 100/20 = 5.0
Item C: ratio = 120/30 = 4.0

Sorted by ratio: A(6.0) > B(5.0) > C(4.0)
```

### Step 2: Greedy Selection

```
Initial State:
  Knapsack: [                    ] capacity = 50
  Total Value: 0

========================================
Processing Item A (ratio=6.0, value=60, weight=10)
========================================
  Remaining capacity: 50
  Item weight: 10
  10 <= 50? YES - Take entire item!
  
  Knapsack: [AAAAAAAAAA          ] capacity = 40
  Value added: 60
  Total Value: 60

========================================
Processing Item B (ratio=5.0, value=100, weight=20)
========================================
  Remaining capacity: 40
  Item weight: 20
  20 <= 40? YES - Take entire item!
  
  Knapsack: [AAAAAAAAAABBBBBBBBBB] capacity = 20
  Value added: 100
  Total Value: 160

========================================
Processing Item C (ratio=4.0, value=120, weight=30)
========================================
  Remaining capacity: 20
  Item weight: 30
  30 <= 20? NO - Take fraction!
  
  Fraction = 20/30 = 2/3 = 0.667
  Value = 0.667 * 120 = 80
  
  Knapsack: [AAAAAAAAAABBBBBBBBBBCCCCCCCCCC] capacity = 0
  Value added: 80
  Total Value: 240
```

### Final Result

```
Selection Summary:
  Item A: 100% taken (10 units) -> value 60
  Item B: 100% taken (20 units) -> value 100
  Item C: 66.7% taken (20 units) -> value 80
  
Total Weight: 50 (exactly full)
Total Value: 240

Visual:
  Knapsack [================50 units================]
           |---A(10)---|------B(20)------|--C(20)--|
           |----60-----|------100--------|---80----|
```

---

## Time and Space Complexity

### Time Complexity: O(n log n)

| Operation | Complexity |
|-----------|------------|
| Calculate ratios | O(n) |
| Sort by ratio | O(n log n) |
| Greedy selection | O(n) |
| **Total** | **O(n log n)** |

### Space Complexity: O(n)

| Storage | Complexity |
|---------|------------|
| Items array with ratios | O(n) |
| Sorting auxiliary space | O(n) or O(log n) |
| **Total** | **O(n)** |

### If Already Sorted

Time reduces to O(n) - just one pass through items.

---

## Variations and Extensions

### 1. Fractional Knapsack with Item Limits

Each item has a maximum quantity available.

```python
# items: [(value, weight, max_quantity), ...]
for v, w, max_qty in sorted_items:
    can_take = min(max_qty, remaining // w)
    # Handle fractional part...
```

### 2. Multiple Knapsacks

Fill multiple knapsacks optimally. Greedy still works if items are divisible.

### 3. 0/1 vs Fractional - Key Differences

| Aspect | 0/1 Knapsack | Fractional Knapsack |
|--------|--------------|---------------------|
| Item divisibility | No | Yes |
| Optimal approach | DP | Greedy |
| Time complexity | O(nW) | O(n log n) |
| Greedy works? | No | Yes |

### 4. Real-World Applications

- **Resource allocation:** Distributing budget among projects
- **Portfolio optimization:** Allocating funds to investments
- **Cargo loading:** Loading ships/trucks with divisible goods
- **Task scheduling:** Allocating time to tasks with rewards

### 5. When Greedy Fails (0/1 Case)

```
Items: [(v=6, w=1), (v=10, w=2), (v=12, w=3)]
Capacity: 5

Ratios: 6.0, 5.0, 4.0

Greedy 0/1: Take item 1 (w=1, v=6), item 2 (w=2, v=10), can't fit item 3
            Total: weight=3, value=16
            Remaining capacity: 2 (wasted!)

Optimal 0/1: Take item 2 (w=2, v=10), item 3 (w=3, v=12)
             Total: weight=5, value=22

In fractional: We could take 2/3 of remaining capacity worth of items.
In 0/1: We can't, so greedy by ratio fails.
```
