"""
Minimize Cash Flow Among Friends - Greedy Algorithm
===================================================

Problem: Given debts between n friends, minimize the number of transactions
(or total cash flow) needed to settle all debts.

WHY GREEDY WORKS:
----------------
1. Net Amounts: Only net amounts matter, not individual transactions.
   If A owes B $100 and B owes A $60, the net is A owes B $40.

2. Pairing Extremes: By pairing max creditor with max debtor, we settle
   at least one person per transaction (either credit or debt becomes 0).

3. Exchange Argument: Any other pairing would require additional transactions
   to eventually settle the extremes, so pairing them directly is optimal.

4. Upper Bound: At most n-1 transactions needed (n-1 people get settled,
   the last automatically balances to 0).

GREEDY STRATEGY:
- Compute net amount for each person
- Repeatedly pair max creditor with max debtor
- Transfer min of their absolute amounts
- Continue until all nets are 0
"""

from typing import List, Tuple, Dict
import heapq


def minimize_cash_flow(graph: List[List[int]]) -> List[Tuple[int, int, int]]:
    """
    Minimize transactions to settle all debts.

    Greedy Strategy:
    1. Compute net amounts (positive = creditor, negative = debtor)
    2. Pair max creditor with max debtor
    3. Transfer minimum of their amounts
    4. Repeat until all settled

    Args:
        graph: n x n matrix where graph[i][j] = amount i owes j

    Returns:
        List of (from_person, to_person, amount) transactions

    Time: O(n^2)
    Space: O(n)

    Example:
    >>> graph = [[0, 100, 30], [0, 0, 50], [0, 0, 0]]
    >>> transactions = minimize_cash_flow(graph)
    >>> len(transactions)
    2
    """
    n = len(graph)
    if n == 0:
        return []

    # Compute net amounts
    # Positive = person is owed money (creditor)
    # Negative = person owes money (debtor)
    net = [0] * n
    for i in range(n):
        for j in range(n):
            net[i] += graph[j][i]  # What i receives
            net[i] -= graph[i][j]  # What i pays

    transactions = []

    while True:
        # Find max creditor and max debtor
        max_credit_idx = max(range(n), key=lambda i: net[i])
        max_debt_idx = min(range(n), key=lambda i: net[i])

        # If both are 0 (or negligible), we're done
        if net[max_credit_idx] <= 0.001 and net[max_debt_idx] >= -0.001:
            break

        # Transfer the minimum of the two amounts
        amount = min(net[max_credit_idx], -net[max_debt_idx])

        transactions.append((max_debt_idx, max_credit_idx, amount))

        # Update net amounts
        net[max_credit_idx] -= amount
        net[max_debt_idx] += amount

    return transactions


def minimize_cash_flow_with_names(
    names: List[str],
    debts: List[Tuple[str, str, int]]
) -> Tuple[List[Tuple[str, str, int]], Dict[str, int]]:
    """
    User-friendly version with names instead of indices.

    Args:
        names: List of person names
        debts: List of (from_name, to_name, amount) tuples

    Returns:
        (list of transactions with names, dict of net amounts)
    """
    n = len(names)
    name_to_idx = {name: i for i, name in enumerate(names)}

    # Build graph
    graph = [[0] * n for _ in range(n)]
    for from_name, to_name, amount in debts:
        i = name_to_idx[from_name]
        j = name_to_idx[to_name]
        graph[i][j] += amount

    # Compute net amounts
    net = [0] * n
    for i in range(n):
        for j in range(n):
            net[i] += graph[j][i] - graph[i][j]

    net_amounts = {names[i]: net[i] for i in range(n)}

    # Get optimized transactions
    transactions = minimize_cash_flow(graph)

    # Convert to names
    named_transactions = [
        (names[from_idx], names[to_idx], amount)
        for from_idx, to_idx, amount in transactions
    ]

    return named_transactions, net_amounts


def minimize_cash_flow_heaps(graph: List[List[int]]) -> List[Tuple[int, int, int]]:
    """
    Heap-based implementation for better efficiency on large inputs.

    Uses max-heap for creditors and min-heap for debtors.

    Time: O(n log n) for heap operations
    """
    n = len(graph)
    if n == 0:
        return []

    # Compute net amounts
    net = [0] * n
    for i in range(n):
        for j in range(n):
            net[i] += graph[j][i] - graph[i][j]

    # Separate into creditors (positive) and debtors (negative)
    # Max-heap for creditors: (-amount, index)
    # Min-heap for debtors: (amount, index)  # amount is negative
    creditors = []
    debtors = []

    for i in range(n):
        if net[i] > 0:
            heapq.heappush(creditors, (-net[i], i))
        elif net[i] < 0:
            heapq.heappush(debtors, (net[i], i))

    transactions = []

    while creditors and debtors:
        credit_amt, credit_idx = heapq.heappop(creditors)
        debt_amt, debt_idx = heapq.heappop(debtors)

        credit_amt = -credit_amt  # Convert back to positive
        debt_amt = -debt_amt       # Convert to positive (amount owed)

        transfer = min(credit_amt, debt_amt)
        transactions.append((debt_idx, credit_idx, transfer))

        # Update and re-add if not settled
        remaining_credit = credit_amt - transfer
        remaining_debt = debt_amt - transfer

        if remaining_credit > 0.001:
            heapq.heappush(creditors, (-remaining_credit, credit_idx))
        if remaining_debt > 0.001:
            heapq.heappush(debtors, (-remaining_debt, debt_idx))

    return transactions


def count_original_transactions(graph: List[List[int]]) -> int:
    """Count original non-zero transactions in the debt graph."""
    count = 0
    for i in range(len(graph)):
        for j in range(len(graph[i])):
            if graph[i][j] > 0:
                count += 1
    return count


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Comprehensive test cases with explanations."""

    print("=" * 60)
    print("MINIMIZE CASH FLOW - TEST CASES")
    print("=" * 60)

    # Test 1: Basic example
    print("\nTest 1: Basic Example (3 friends)")
    print("-" * 40)
    # A owes B $100, A owes C $30, B owes C $50
    graph = [
        [0, 100, 30],
        [0, 0, 50],
        [0, 0, 0]
    ]

    original = count_original_transactions(graph)
    transactions = minimize_cash_flow(graph)

    print("Original debts:")
    print("  A owes B: $100")
    print("  A owes C: $30")
    print("  B owes C: $50")
    print(f"\nOriginal transactions: {original}")
    print(f"Optimized transactions: {len(transactions)}")
    print("\nOptimized settlement:")
    names = ['A', 'B', 'C']
    for from_idx, to_idx, amount in transactions:
        print(f"  {names[from_idx]} pays {names[to_idx]}: ${amount}")

    # Test 2: With names
    print("\nTest 2: User-Friendly API")
    print("-" * 40)
    names = ['Alice', 'Bob', 'Charlie']
    debts = [
        ('Alice', 'Bob', 100),
        ('Alice', 'Charlie', 30),
        ('Bob', 'Charlie', 50)
    ]

    transactions, net_amounts = minimize_cash_flow_with_names(names, debts)
    print("Net amounts:", net_amounts)
    print("Transactions:")
    for from_name, to_name, amount in transactions:
        print(f"  {from_name} -> {to_name}: ${amount}")

    # Test 3: Circular debt
    print("\nTest 3: Circular Debt")
    print("-" * 40)
    # A owes B $100, B owes C $100, C owes A $100
    graph = [
        [0, 100, 0],
        [0, 0, 100],
        [100, 0, 0]
    ]

    transactions = minimize_cash_flow(graph)
    print("Circular: A->B->C->A ($100 each)")
    print(f"Net amounts: all zero!")
    print(f"Transactions needed: {len(transactions)}")
    assert len(transactions) == 0  # Circular cancels out

    # Test 4: All owe one person
    print("\nTest 4: All Owe One Person")
    print("-" * 40)
    # A, B, C all owe D $50
    graph = [
        [0, 0, 0, 50],
        [0, 0, 0, 50],
        [0, 0, 0, 50],
        [0, 0, 0, 0]
    ]

    transactions = minimize_cash_flow(graph)
    print("A, B, C each owe D $50")
    print(f"Transactions: {len(transactions)}")
    # Each person pays D directly - can't be simplified
    assert len(transactions) == 3

    # Test 5: Compare with heap version
    print("\nTest 5: Compare Implementations")
    print("-" * 40)
    graph = [
        [0, 100, 30],
        [0, 0, 50],
        [0, 0, 0]
    ]

    trans1 = minimize_cash_flow(graph)
    trans2 = minimize_cash_flow_heaps(graph)

    print(f"Basic implementation: {len(trans1)} transactions")
    print(f"Heap implementation: {len(trans2)} transactions")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_greedy_choice():
    """Step-by-step demonstration of the algorithm."""

    print("\n" + "=" * 60)
    print("DEMONSTRATION: MINIMIZING CASH FLOW")
    print("=" * 60)

    names = ['Alice', 'Bob', 'Charlie']
    graph = [
        [0, 100, 30],  # Alice owes Bob 100, Alice owes Charlie 30
        [0, 0, 50],    # Bob owes Charlie 50
        [0, 0, 0]
    ]

    print("\nOriginal debts:")
    print("  Alice -> Bob: $100")
    print("  Alice -> Charlie: $30")
    print("  Bob -> Charlie: $50")

    # Compute net amounts
    net = [0] * 3
    for i in range(3):
        for j in range(3):
            net[i] += graph[j][i] - graph[i][j]

    print("\n" + "-" * 40)
    print("NET AMOUNTS:")
    print("-" * 40)
    for i, name in enumerate(names):
        status = "owes" if net[i] < 0 else "is owed"
        print(f"  {name}: {status} ${abs(net[i])}")

    print("\n" + "-" * 40)
    print("GREEDY SETTLEMENT:")
    print("-" * 40)

    round_num = 1
    transactions = []

    while True:
        max_credit_idx = max(range(3), key=lambda i: net[i])
        max_debt_idx = min(range(3), key=lambda i: net[i])

        if net[max_credit_idx] <= 0:
            break

        print(f"\nRound {round_num}:")
        print(f"  Max creditor: {names[max_credit_idx]} (+${net[max_credit_idx]})")
        print(f"  Max debtor: {names[max_debt_idx]} (-${abs(net[max_debt_idx])})")

        amount = min(net[max_credit_idx], -net[max_debt_idx])
        print(f"  Transfer: ${amount}")

        transactions.append((max_debt_idx, max_credit_idx, amount))

        net[max_credit_idx] -= amount
        net[max_debt_idx] += amount

        print(f"  New balances: {[f'{names[i]}: ${net[i]}' for i in range(3)]}")

        round_num += 1

    print("\n" + "-" * 40)
    print("FINAL TRANSACTIONS:")
    print("-" * 40)
    for from_idx, to_idx, amount in transactions:
        print(f"  {names[from_idx]} -> {names[to_idx]}: ${amount}")

    print(f"\nOriginal: 3 transactions")
    print(f"Optimized: {len(transactions)} transactions")
    print(f"Savings: {3 - len(transactions)} transaction(s)")


if __name__ == "__main__":
    run_tests()
    demonstrate_greedy_choice()
