# Minimize Cash Flow Among Friends

## Problem Statement

Given a group of friends who have borrowed money from each other, minimize the total number of transactions (or total cash flow) needed to settle all debts.

**Input:**
- `n`: Number of friends
- `graph[i][j]`: Amount person i owes person j

**Output:**
- Minimum set of transactions to settle all debts

**Example:**
```
3 friends: A, B, C
Debts:
  A owes B: $100
  B owes C: $50
  A owes C: $30

Net amounts:
  A: -130 (owes 130 total)
  B: +50 (owed 100, owes 50)
  C: +80 (owed 80 total)

Naive: 3 transactions
Optimal: A pays B $50, A pays C $80 = 2 transactions
```

---

## Why Greedy Works Here

### The Key Insight

What matters is the **net amount** each person owes or is owed, not the individual transactions.

**Greedy Strategy:** Pair the person who owes the most with the person who is owed the most, settling one of them completely.

### Why Net Amounts Matter

Consider: A owes B $100, B owes C $100
- Individual transactions: A->B ($100), B->C ($100) = 2 transactions
- Net amounts: A: -100, B: 0, C: +100
- Optimal: A->C ($100) = 1 transaction

The intermediate person B has net 0, so can be bypassed!

### Greedy Choice Property

**At each step:**
1. Find person with max credit (owed the most)
2. Find person with max debt (owes the most)
3. Have debtor pay creditor the minimum of their amounts
4. This settles at least one person (credit or debt becomes 0)

**Why this works:**
- Each transaction settles at least one person
- Maximum n-1 transactions needed (at most n-1 people need settling)
- Pairing extremes minimizes intermediate transactions

---

## Greedy Choice Property Explanation

### The Settlement Process

```
Net amounts: [-130, +50, +80]
            (A)   (B)   (C)

Step 1: Pair max debt (-130) with max credit (+80)
        A pays C $80
        New amounts: [-50, +50, 0]
        C is settled!

Step 2: Pair max debt (-50) with max credit (+50)
        A pays B $50
        New amounts: [0, 0, 0]
        All settled!

Transactions: A->C ($80), A->B ($50)
Total: 2 transactions
```

### Why Pair Extremes?

1. **Efficiency:** Settling the largest credit/debt first removes them from consideration
2. **Minimization:** One transaction can eliminate at least one party's involvement
3. **No waste:** Money flows directly from debtor to creditor

---

## Step-by-Step Algorithm

### Algorithm:

```
1. COMPUTE net amount for each person
   net[i] = sum of (graph[j][i]) - sum of (graph[i][j])
   
2. SEPARATE into creditors (net > 0) and debtors (net < 0)

3. WHILE there are unsettled people:
   a. FIND max_creditor (person with highest positive net)
   b. FIND max_debtor (person with most negative net)
   c. amount = min(abs(net[debtor]), net[creditor])
   d. RECORD transaction: debtor pays creditor 'amount'
   e. UPDATE net amounts
   f. REMOVE settled people (net == 0)

4. RETURN list of transactions
```

### Using Min-Heap and Max-Heap:

For efficiency, use heaps to quickly find max creditor and debtor.

---

## Brute Force Comparison

### Brute Force Approach

Try all possible orderings of settlements and find minimum transactions.

```python
def brute_force(net_amounts):
    from itertools import permutations
    
    n = len(net_amounts)
    # Filter to non-zero amounts
    non_zero = [(i, amt) for i, amt in enumerate(net_amounts) if amt != 0]
    
    min_transactions = float('inf')
    
    # Try all orderings of settling
    for perm in permutations(non_zero):
        # Simulate settlements in this order
        # Count transactions
        pass
    
    return min_transactions
```

**Complexity:** Factorial - impractical!

### Comparison

| Approach | Time | Space |
|----------|------|-------|
| Brute Force | O(n!) | O(n) |
| Greedy | O(n^2) or O(n log n) with heaps | O(n) |

---

## Optimal Greedy Implementation

```python
def minimize_cash_flow(graph):
    """
    Minimize transactions to settle all debts.
    
    Args:
        graph: n x n matrix where graph[i][j] = amount i owes j
    
    Returns:
        List of (from, to, amount) transactions
    """
    n = len(graph)
    
    # Compute net amounts
    net = [0] * n
    for i in range(n):
        for j in range(n):
            net[i] += graph[j][i]  # What i is owed
            net[i] -= graph[i][j]  # What i owes
    
    transactions = []
    
    while True:
        # Find max creditor and max debtor
        max_credit = max(range(n), key=lambda i: net[i])
        max_debt = min(range(n), key=lambda i: net[i])
        
        # If both are 0 (or very close), we're done
        if net[max_credit] <= 0 and net[max_debt] >= 0:
            break
        
        # Settle the smaller of the two amounts
        amount = min(net[max_credit], -net[max_debt])
        
        transactions.append((max_debt, max_credit, amount))
        
        net[max_credit] -= amount
        net[max_debt] += amount
    
    return transactions
```

**Time: O(n^2) in worst case**
**Space: O(n)**

---

## Dry Run with Selection Visualization

**Input:**
```
graph:
     A    B    C
A [  0,  100,  30]  <- A owes B $100, A owes C $30
B [  0,    0,  50]  <- B owes C $50
C [  0,    0,   0]
```

### Step 1: Compute Net Amounts

```
A: received 0, paid (100 + 30) = -130
B: received 100, paid 50 = +50
C: received (30 + 50), paid 0 = +80

Net amounts: A=-130, B=+50, C=+80
```

### Step 2: Greedy Settlements

```
Round 1:
  Max creditor: C (+80)
  Max debtor: A (-130)
  Amount: min(80, 130) = 80
  
  Transaction: A -> C: $80
  
  Updated: A=-50, B=+50, C=0
  C is settled!

Round 2:
  Max creditor: B (+50)
  Max debtor: A (-50)
  Amount: min(50, 50) = 50
  
  Transaction: A -> B: $50
  
  Updated: A=0, B=0, C=0
  All settled!
```

### Final Result

```
Original transactions: 3
  A -> B: $100
  A -> C: $30
  B -> C: $50

Optimized transactions: 2
  A -> C: $80
  A -> B: $50

Savings: 1 transaction (33% reduction)
```

### Visual Representation

```
BEFORE:
   A ----$100----> B
   |               |
   |               |
   $30            $50
   |               |
   v               v
   +-------> C <---+

AFTER (Net Flow):
   A ----$50-----> B
   |
   $80
   |
   v
   C
```

---

## Time and Space Complexity

### Time Complexity: O(n^2)

| Operation | Complexity |
|-----------|------------|
| Compute net amounts | O(n^2) |
| Find max creditor/debtor | O(n) per round |
| Number of rounds | O(n) |
| **Total** | **O(n^2)** |

### With Heaps: O(n log n)

| Operation | Complexity |
|-----------|------------|
| Compute net amounts | O(n^2) |
| Heap operations | O(n log n) |
| **Total** | **O(n^2)** (dominated by net computation) |

### Space Complexity: O(n)

| Storage | Complexity |
|---------|------------|
| Net amounts | O(n) |
| Transactions list | O(n) |
| **Total** | **O(n)** |

---

## Variations and Extensions

### 1. Minimize Total Amount Transferred

Instead of minimizing transaction count, minimize total money moved.
Same algorithm works - net amounts determine minimum flow.

### 2. Currency Conversion

If different currencies are involved, need to consider exchange rates.

### 3. Partial Settlements

Allow partial settlements with thresholds (ignore small amounts).

### 4. Transaction Fees

If each transaction has a fee, this becomes an optimization problem.

### 5. Group Constraints

Some people prefer not to transact directly - requires graph constraints.

### 6. Real-World Applications

- Splitwise app for group expenses
- Interbank settlements
- Supply chain payments
- Corporate expense reconciliation
