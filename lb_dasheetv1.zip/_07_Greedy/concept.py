"""
Greedy Algorithms - Common Templates and Patterns
================================================

This module provides reusable greedy algorithm templates that can be
adapted for various problems. Each template demonstrates a fundamental
greedy pattern with detailed explanations.

Key Greedy Patterns:
1. Sort and Select
2. Interval Scheduling
3. Ratio-based Selection
4. Priority Queue (Heap) Greedy
5. Two Pointer Greedy
6. Deadline Scheduling
"""

import heapq
from typing import List, Tuple, Callable, Any, Optional
from dataclasses import dataclass


# =============================================================================
# PATTERN 1: Sort and Select Template
# =============================================================================

def sort_and_select(
    items: List[Any],
    key_func: Callable[[Any], Any],
    can_select: Callable[[Any, List[Any]], bool],
    reverse: bool = False
) -> List[Any]:
    """
    Generic sort-and-select greedy template.

    Algorithm:
    1. Sort items by key_func
    2. Iterate through sorted items
    3. Select item if can_select() returns True

    Args:
        items: List of items to select from
        key_func: Function to extract sort key from item
        can_select: Function(item, selected_so_far) -> bool
        reverse: Sort in descending order if True

    Returns:
        List of selected items

    Time: O(n log n) for sorting + O(n) for selection
    Space: O(n) for result list

    Example - Activity Selection:
        activities = [(1, 4), (3, 5), (0, 6), (5, 7)]  # (start, end)
        result = sort_and_select(
            activities,
            key_func=lambda x: x[1],  # Sort by end time
            can_select=lambda x, sel: len(sel) == 0 or x[0] >= sel[-1][1]
        )
    """
    sorted_items = sorted(items, key=key_func, reverse=reverse)
    selected = []

    for item in sorted_items:
        if can_select(item, selected):
            selected.append(item)

    return selected


# =============================================================================
# PATTERN 2: Interval Scheduling Template
# =============================================================================

def max_non_overlapping_intervals(intervals: List[Tuple[int, int]]) -> List[Tuple[int, int]]:
    """
    Select maximum number of non-overlapping intervals.

    Greedy Strategy: Always pick the interval with earliest END time.

    WHY THIS WORKS:
    - By finishing earliest, we leave maximum room for future intervals
    - Exchange argument: If we pick a later-finishing interval, we can
      always swap it with the earlier one without losing any selections

    Args:
        intervals: List of (start, end) tuples

    Returns:
        Maximum set of non-overlapping intervals

    Time: O(n log n)
    Space: O(n)
    """
    if not intervals:
        return []

    # Sort by end time (the greedy criterion)
    sorted_intervals = sorted(intervals, key=lambda x: x[1])

    selected = [sorted_intervals[0]]
    last_end = sorted_intervals[0][1]

    for start, end in sorted_intervals[1:]:
        # Greedy choice: take if doesn't overlap with last selected
        if start >= last_end:
            selected.append((start, end))
            last_end = end

    return selected


def min_intervals_to_cover(intervals: List[Tuple[int, int]], target: Tuple[int, int]) -> List[Tuple[int, int]]:
    """
    Select minimum intervals to cover a target range.

    Greedy Strategy: Always pick the interval that extends coverage the most.

    Args:
        intervals: List of (start, end) tuples
        target: (start, end) tuple representing range to cover

    Returns:
        Minimum intervals needed, or empty list if impossible
    """
    target_start, target_end = target
    sorted_intervals = sorted(intervals, key=lambda x: x[0])

    selected = []
    current_end = target_start
    i = 0
    n = len(sorted_intervals)

    while current_end < target_end:
        # Find interval that starts <= current_end and extends furthest
        best_end = current_end
        best_interval = None

        while i < n and sorted_intervals[i][0] <= current_end:
            if sorted_intervals[i][1] > best_end:
                best_end = sorted_intervals[i][1]
                best_interval = sorted_intervals[i]
            i += 1

        if best_interval is None:
            return []  # Cannot cover

        selected.append(best_interval)
        current_end = best_end

    return selected


# =============================================================================
# PATTERN 3: Ratio-based Selection (Fractional Knapsack)
# =============================================================================

@dataclass
class Item:
    """Item with weight and value for knapsack problems."""
    id: str
    weight: float
    value: float

    @property
    def ratio(self) -> float:
        return self.value / self.weight if self.weight > 0 else float('inf')


def fractional_knapsack(items: List[Item], capacity: float) -> Tuple[float, List[Tuple[str, float]]]:
    """
    Fractional Knapsack - maximize value with weight constraint.

    Greedy Strategy: Always take the item with highest value/weight ratio.

    WHY THIS WORKS:
    - We're maximizing value per unit weight
    - Since we can take fractions, we never "waste" capacity
    - Taking highest ratio first is always optimal (no trade-off)

    Args:
        items: List of Item objects
        capacity: Maximum weight capacity

    Returns:
        (total_value, [(item_id, fraction_taken), ...])

    Time: O(n log n)
    Space: O(n)
    """
    # Sort by value/weight ratio in descending order
    sorted_items = sorted(items, key=lambda x: x.ratio, reverse=True)

    total_value = 0.0
    taken = []
    remaining_capacity = capacity

    for item in sorted_items:
        if remaining_capacity <= 0:
            break

        # Greedy choice: take as much as possible of highest ratio item
        take_weight = min(item.weight, remaining_capacity)
        fraction = take_weight / item.weight
        value_gained = item.value * fraction

        total_value += value_gained
        taken.append((item.id, fraction))
        remaining_capacity -= take_weight

    return total_value, taken


# =============================================================================
# PATTERN 4: Priority Queue (Heap) Greedy
# =============================================================================

def huffman_encoding_cost(frequencies: List[int]) -> int:
    """
    Calculate minimum cost for Huffman encoding.

    Greedy Strategy: Always merge the two nodes with smallest frequencies.

    WHY THIS WORKS:
    - Merging smallest first puts them deepest in tree (longest codes)
    - Frequent characters stay near root (shorter codes)
    - This minimizes total weighted path length

    Args:
        frequencies: List of character frequencies

    Returns:
        Total cost (sum of all merge costs)

    Time: O(n log n)
    Space: O(n)
    """
    if len(frequencies) <= 1:
        return 0

    # Min-heap for efficient smallest element extraction
    heap = frequencies[:]
    heapq.heapify(heap)

    total_cost = 0

    while len(heap) > 1:
        # Greedy choice: merge two smallest
        first = heapq.heappop(heap)
        second = heapq.heappop(heap)

        merge_cost = first + second
        total_cost += merge_cost

        heapq.heappush(heap, merge_cost)

    return total_cost


def connect_ropes_min_cost(rope_lengths: List[int]) -> int:
    """
    Connect all ropes with minimum cost.
    Cost of connecting two ropes = sum of their lengths.

    Greedy Strategy: Always connect the two shortest ropes.
    (Same as Huffman - minimize accumulated cost)
    """
    return huffman_encoding_cost(rope_lengths)


def merge_k_sorted_lists_min_comparisons(list_sizes: List[int]) -> int:
    """
    Merge k sorted lists with minimum comparisons.
    Cost of merging two lists = sum of their sizes.

    Greedy Strategy: Always merge the two smallest lists.
    """
    return huffman_encoding_cost(list_sizes)


# =============================================================================
# PATTERN 5: Two Pointer Greedy
# =============================================================================

def min_boats_to_save_people(weights: List[int], limit: int) -> int:
    """
    Minimum boats needed where each boat holds at most 2 people with weight <= limit.

    Greedy Strategy: Pair heaviest person with lightest if possible.

    WHY THIS WORKS:
    - Heaviest person must go in some boat
    - If heaviest can pair with lightest, it's best to do so (saves a boat)
    - If heaviest can't pair with lightest, heaviest can't pair with anyone

    Time: O(n log n)
    Space: O(1)
    """
    weights.sort()
    left, right = 0, len(weights) - 1
    boats = 0

    while left <= right:
        # Greedy: try to pair heaviest (right) with lightest (left)
        if weights[left] + weights[right] <= limit:
            left += 1  # Lightest can pair
        right -= 1  # Heaviest always goes
        boats += 1

    return boats


def two_sum_closest_to_target(arr: List[int], target: int) -> Tuple[int, int]:
    """
    Find pair with sum closest to target.

    Greedy Strategy: Move pointer that gets us closer to target.
    """
    arr.sort()
    left, right = 0, len(arr) - 1
    closest_sum = float('inf')
    result = (arr[left], arr[right])

    while left < right:
        current_sum = arr[left] + arr[right]

        if abs(current_sum - target) < abs(closest_sum - target):
            closest_sum = current_sum
            result = (arr[left], arr[right])

        # Greedy: move pointer to get closer to target
        if current_sum < target:
            left += 1
        elif current_sum > target:
            right -= 1
        else:
            return result

    return result


# =============================================================================
# PATTERN 6: Deadline Scheduling
# =============================================================================

@dataclass
class Job:
    """Job with deadline and profit."""
    id: str
    deadline: int
    profit: int


def job_sequencing(jobs: List[Job]) -> Tuple[int, List[str]]:
    """
    Schedule jobs to maximize profit. Each job takes 1 unit of time.

    Greedy Strategy:
    1. Sort jobs by profit (descending)
    2. For each job, schedule it in the latest available slot before deadline

    WHY THIS WORKS:
    - Higher profit jobs should be prioritized
    - Scheduling at latest possible slot leaves earlier slots for other jobs
    - This maximizes flexibility while ensuring high-profit jobs are done

    Time: O(n^2) basic, O(n log n) with Union-Find
    Space: O(max_deadline)
    """
    if not jobs:
        return 0, []

    # Sort by profit descending
    sorted_jobs = sorted(jobs, key=lambda x: x.profit, reverse=True)

    max_deadline = max(job.deadline for job in jobs)
    slots = [None] * (max_deadline + 1)  # 1-indexed

    total_profit = 0
    scheduled = []

    for job in sorted_jobs:
        # Greedy: find latest available slot <= deadline
        for slot in range(job.deadline, 0, -1):
            if slots[slot] is None:
                slots[slot] = job.id
                total_profit += job.profit
                scheduled.append(job.id)
                break

    return total_profit, scheduled


# =============================================================================
# PATTERN 7: Greedy with Sorting by Multiple Criteria
# =============================================================================

def minimum_platforms(arrivals: List[int], departures: List[int]) -> int:
    """
    Minimum platforms needed at railway station.

    Greedy Strategy: Process events (arrivals and departures) in order.

    WHY THIS WORKS:
    - We need to track concurrent trains at any point
    - Processing events in time order gives us exact count
    - Maximum concurrent count = minimum platforms needed

    Time: O(n log n)
    Space: O(n)
    """
    events = []

    # Create events: arrival (+1) and departure (-1)
    for arr in arrivals:
        events.append((arr, 1))  # Arrival
    for dep in departures:
        events.append((dep + 0.5, -1))  # Departure (process after same-time arrival)

    events.sort()

    current_platforms = 0
    max_platforms = 0

    for _, event_type in events:
        current_platforms += event_type
        max_platforms = max(max_platforms, current_platforms)

    return max_platforms


# =============================================================================
# UTILITY: Greedy Proof Helper
# =============================================================================

def verify_greedy_optimality(
    problem_input: Any,
    greedy_solution: Any,
    cost_function: Callable[[Any], float],
    generate_neighbors: Callable[[Any], List[Any]]
) -> bool:
    """
    Verify greedy solution by checking if any local modification improves it.

    This is a helper to test if a greedy solution is locally optimal.
    For true optimality, formal proof (exchange argument) is needed.

    Args:
        problem_input: The original problem input
        greedy_solution: Solution produced by greedy algorithm
        cost_function: Function to evaluate solution quality
        generate_neighbors: Function to generate neighboring solutions

    Returns:
        True if no neighbor is better (locally optimal)
    """
    greedy_cost = cost_function(greedy_solution)

    for neighbor in generate_neighbors(greedy_solution):
        if cost_function(neighbor) < greedy_cost:
            return False

    return True


# =============================================================================
# DEMONSTRATION AND TESTING
# =============================================================================

def demo_greedy_patterns():
    """Demonstrate all greedy patterns with examples."""

    print("=" * 60)
    print("GREEDY ALGORITHMS - PATTERN DEMONSTRATIONS")
    print("=" * 60)

    # 1. Activity Selection
    print("\n1. ACTIVITY SELECTION (Interval Scheduling)")
    print("-" * 40)
    activities = [(1, 4), (3, 5), (0, 6), (5, 7), (3, 9), (5, 9), (6, 10), (8, 11)]
    selected = max_non_overlapping_intervals(activities)
    print(f"Activities (start, end): {activities}")
    print(f"Selected (by earliest end): {selected}")
    print(f"Maximum count: {len(selected)}")

    # 2. Fractional Knapsack
    print("\n2. FRACTIONAL KNAPSACK (Ratio-based)")
    print("-" * 40)
    items = [
        Item('A', 10, 60),
        Item('B', 20, 100),
        Item('C', 30, 120)
    ]
    capacity = 50
    value, taken = fractional_knapsack(items, capacity)
    print(f"Items: {[(i.id, f'w={i.weight}', f'v={i.value}', f'ratio={i.ratio:.2f}') for i in items]}")
    print(f"Capacity: {capacity}")
    print(f"Taken: {taken}")
    print(f"Total value: {value}")

    # 3. Huffman Coding
    print("\n3. HUFFMAN CODING (Heap Greedy)")
    print("-" * 40)
    frequencies = [5, 9, 12, 13, 16, 45]
    cost = huffman_encoding_cost(frequencies)
    print(f"Character frequencies: {frequencies}")
    print(f"Minimum encoding cost: {cost}")

    # 4. Job Sequencing
    print("\n4. JOB SEQUENCING (Deadline Scheduling)")
    print("-" * 40)
    jobs = [
        Job('J1', 2, 100),
        Job('J2', 1, 50),
        Job('J3', 2, 10),
        Job('J4', 1, 20),
        Job('J5', 3, 30)
    ]
    profit, scheduled = job_sequencing(jobs)
    print(f"Jobs: {[(j.id, f'd={j.deadline}', f'p={j.profit}') for j in jobs]}")
    print(f"Scheduled: {scheduled}")
    print(f"Total profit: {profit}")

    # 5. Minimum Platforms
    print("\n5. MINIMUM PLATFORMS (Event Processing)")
    print("-" * 40)
    arrivals = [900, 940, 950, 1100, 1500, 1800]
    departures = [910, 1200, 1120, 1130, 1900, 2000]
    platforms = minimum_platforms(arrivals, departures)
    print(f"Arrivals: {arrivals}")
    print(f"Departures: {departures}")
    print(f"Minimum platforms needed: {platforms}")

    # 6. Boats to Save People
    print("\n6. BOATS TO SAVE PEOPLE (Two Pointer)")
    print("-" * 40)
    weights = [3, 5, 3, 4]
    limit = 5
    boats = min_boats_to_save_people(weights, limit)
    print(f"People weights: {weights}")
    print(f"Boat weight limit: {limit}")
    print(f"Minimum boats needed: {boats}")


if __name__ == "__main__":
    demo_greedy_patterns()
