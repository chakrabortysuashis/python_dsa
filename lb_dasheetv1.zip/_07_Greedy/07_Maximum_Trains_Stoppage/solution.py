"""
Maximum Trains for Stoppage - Greedy Algorithm
==============================================

Problem: Given n trains with arrival/departure times and assigned platforms,
find the maximum number of trains that can stop at the station. Each platform
can hold only one train at a time.

WHY GREEDY WORKS:
----------------
1. Platform Independence: Trains on different platforms don't affect each other.
   We can solve each platform independently.

2. Activity Selection: For each platform, this is exactly the activity selection
   problem. Select maximum non-overlapping intervals.

3. Earliest Departure: Sorting by departure time and picking earliest ensures
   we leave the platform free as soon as possible for future trains.

4. Exchange Argument: If optimal picks later-departing train over earlier one
   (both compatible), we can swap without losing any selections.

GREEDY STRATEGY:
- Group trains by platform
- For each platform: sort by departure, select greedily
- Sum up selections across all platforms
"""

from typing import List, Tuple, Dict
from collections import defaultdict


def max_trains_stoppage(
    trains: List[Tuple[int, int, int]],
    m: int
) -> int:
    """
    Find maximum trains that can stop at the station.

    Greedy Strategy (Activity Selection per platform):
    1. Group trains by their assigned platform
    2. For each platform, sort trains by departure time
    3. Apply activity selection: pick earliest departing non-conflicting train
    4. Sum up all selections

    Args:
        trains: List of (arrival_time, departure_time, platform_number)
        m: Number of platforms

    Returns:
        Maximum number of trains that can stop

    Time: O(n log n)
    Space: O(n)

    Example:
    >>> trains = [(100, 130, 1), (115, 145, 1), (100, 130, 2), (200, 230, 1)]
    >>> max_trains_stoppage(trains, 2)
    4
    """
    if not trains:
        return 0

    # Group trains by platform
    platform_trains: Dict[int, List[Tuple[int, int]]] = defaultdict(list)

    for arrival, departure, platform in trains:
        platform_trains[platform].append((arrival, departure))

    total_count = 0

    # Solve activity selection for each platform independently
    for platform in range(1, m + 1):
        if platform not in platform_trains:
            continue

        # Sort by departure time (greedy criterion)
        sorted_trains = sorted(platform_trains[platform], key=lambda x: x[1])

        # Select first train (earliest departure)
        count = 1
        last_departure = sorted_trains[0][1]

        # Greedily select non-overlapping trains
        for arrival, departure in sorted_trains[1:]:
            if arrival >= last_departure:
                count += 1
                last_departure = departure

        total_count += count

    return total_count


def max_trains_detailed(
    trains: List[Tuple[str, int, int, int]],
    m: int
) -> Tuple[int, Dict[int, List[str]]]:
    """
    Detailed solution showing which trains are selected per platform.

    Args:
        trains: List of (train_name, arrival, departure, platform)
        m: Number of platforms

    Returns:
        (total_count, dict mapping platform -> list of selected train names)
    """
    if not trains:
        return 0, {}

    # Group by platform with names
    platform_trains: Dict[int, List[Tuple[str, int, int]]] = defaultdict(list)

    for name, arrival, departure, platform in trains:
        platform_trains[platform].append((name, arrival, departure))

    selected: Dict[int, List[str]] = {}
    total_count = 0

    for platform in range(1, m + 1):
        if platform not in platform_trains:
            selected[platform] = []
            continue

        # Sort by departure time
        sorted_trains = sorted(platform_trains[platform], key=lambda x: x[2])

        # Activity selection
        platform_selected = [sorted_trains[0][0]]
        last_departure = sorted_trains[0][2]

        for name, arrival, departure in sorted_trains[1:]:
            if arrival >= last_departure:
                platform_selected.append(name)
                last_departure = departure

        selected[platform] = platform_selected
        total_count += len(platform_selected)

    return total_count, selected


def max_trains_no_fixed_platform(trains: List[Tuple[int, int]], m: int) -> int:
    """
    Variation: Trains can use ANY platform.

    This becomes: minimum platforms needed = maximum overlap at any point.
    With m platforms, we can handle up to m overlapping trains.

    Strategy: Sort all events, track current count, reject when count > m.

    Note: This is related to the Minimum Platforms problem.
    """
    if not trains:
        return 0

    events = []
    for i, (arrival, departure) in enumerate(trains):
        events.append((arrival, 1, i))  # 1 = arrival
        events.append((departure, -1, i))  # -1 = departure

    # Sort by time, departures before arrivals at same time
    events.sort(key=lambda x: (x[0], x[1]))

    current_count = 0
    selected_trains = set()
    rejected = set()

    for time, event_type, train_idx in events:
        if event_type == 1:  # Arrival
            if current_count < m and train_idx not in rejected:
                current_count += 1
                selected_trains.add(train_idx)
            else:
                rejected.add(train_idx)
        else:  # Departure
            if train_idx in selected_trains:
                current_count -= 1

    return len(selected_trains)


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Comprehensive test cases with explanations."""

    print("=" * 60)
    print("MAXIMUM TRAINS FOR STOPPAGE - TEST CASES")
    print("=" * 60)

    # Test 1: Basic example
    print("\nTest 1: Basic Example")
    print("-" * 40)
    trains = [
        (100, 130, 1),  # T1: 10:00-10:30, Platform 1
        (115, 145, 1),  # T2: 10:15-10:45, Platform 1
        (100, 130, 2),  # T3: 10:00-10:30, Platform 2
        (200, 230, 1)   # T4: 11:00-11:30, Platform 1
    ]
    m = 2

    result = max_trains_stoppage(trains, m)
    print(f"Trains: {trains}")
    print(f"Platforms: {m}")
    print(f"Maximum trains that can stop: {result}")

    # Test 2: Detailed solution
    print("\nTest 2: Detailed Solution")
    print("-" * 40)
    trains_named = [
        ('T1', 100, 130, 1),
        ('T2', 115, 145, 1),
        ('T3', 100, 130, 2),
        ('T4', 200, 230, 1),
        ('T5', 120, 150, 2),
        ('T6', 140, 170, 2)
    ]

    count, selected = max_trains_detailed(trains_named, 2)
    print(f"Total selected: {count}")
    for platform, names in selected.items():
        print(f"  Platform {platform}: {names}")

    # Test 3: All trains on same platform
    print("\nTest 3: All Trains on Same Platform")
    print("-" * 40)
    trains = [
        (0, 30, 1),
        (15, 45, 1),
        (35, 65, 1),
        (60, 90, 1)
    ]

    result = max_trains_stoppage(trains, 1)
    print(f"All trains on Platform 1")
    print(f"Maximum non-overlapping: {result}")

    # Test 4: No overlaps
    print("\nTest 4: No Overlaps")
    print("-" * 40)
    trains = [
        (0, 30, 1),
        (40, 70, 1),
        (80, 110, 1)
    ]

    result = max_trains_stoppage(trains, 1)
    print(f"Non-overlapping trains: {result}")
    assert result == 3

    # Test 5: Heavy overlap
    print("\nTest 5: Heavy Overlap")
    print("-" * 40)
    trains = [
        (0, 100, 1),
        (10, 110, 1),
        (20, 120, 1),
        (30, 130, 1)
    ]

    result = max_trains_stoppage(trains, 1)
    print(f"All overlapping trains: {result}")
    assert result == 1  # Can only select one

    # Test 6: Empty platform
    print("\nTest 6: Multiple Platforms, Some Empty")
    print("-" * 40)
    trains = [
        (0, 30, 1),
        (40, 70, 1)
    ]

    result = max_trains_stoppage(trains, 3)  # 3 platforms, only 1 used
    print(f"Trains only on Platform 1, 3 platforms available")
    print(f"Result: {result}")
    assert result == 2

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_greedy_choice():
    """Step-by-step demonstration of the algorithm."""

    print("\n" + "=" * 60)
    print("DEMONSTRATION: GREEDY TRAIN SELECTION")
    print("=" * 60)

    trains = [
        ('T1', 100, 130, 1),  # Platform 1
        ('T2', 115, 145, 1),  # Platform 1
        ('T3', 200, 230, 1),  # Platform 1
        ('T4', 100, 130, 2),  # Platform 2
        ('T5', 120, 150, 2),  # Platform 2
        ('T6', 160, 190, 2)   # Platform 2
    ]

    print("\nInput trains:")
    for name, arr, dep, plat in trains:
        print(f"  {name}: {arr//100}:{arr%100:02d} - {dep//100}:{dep%100:02d}, Platform {plat}")

    # Group by platform
    from collections import defaultdict
    platforms = defaultdict(list)
    for t in trains:
        platforms[t[3]].append(t)

    print("\n" + "-" * 40)
    print("PROCESSING EACH PLATFORM:")
    print("-" * 40)

    total = 0

    for p in sorted(platforms.keys()):
        print(f"\n=== Platform {p} ===")

        # Sort by departure
        sorted_trains = sorted(platforms[p], key=lambda x: x[2])
        print(f"Sorted by departure: {[t[0] for t in sorted_trains]}")

        selected = [sorted_trains[0][0]]
        last_dep = sorted_trains[0][2]
        print(f"\nSelect {sorted_trains[0][0]} (first train, departs {last_dep})")

        for name, arr, dep, _ in sorted_trains[1:]:
            print(f"\nConsider {name}: arrives {arr}, departs {dep}")
            print(f"  Last departure: {last_dep}")

            if arr >= last_dep:
                print(f"  {arr} >= {last_dep}? YES - SELECT!")
                selected.append(name)
                last_dep = dep
            else:
                print(f"  {arr} >= {last_dep}? NO - CONFLICT, skip")

        print(f"\nPlatform {p} selected: {selected}")
        total += len(selected)

    print("\n" + "-" * 40)
    print(f"TOTAL TRAINS SELECTED: {total}")
    print("-" * 40)


if __name__ == "__main__":
    run_tests()
    demonstrate_greedy_choice()
