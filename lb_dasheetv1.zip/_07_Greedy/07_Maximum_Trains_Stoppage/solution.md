# Maximum Trains for Stoppage

## Problem Statement

Given `n` train timings (arrival and departure) for a station with `m` platforms, find the maximum number of trains that can be given a stoppage at the station. Each platform can host only one train at a time.

**Input:**
- `n`: Number of trains
- `m`: Number of platforms
- For each train: `(arrival_time, departure_time, platform_number)`

**Output:**
- Maximum number of trains that can stop at the station

**Constraints:**
- A platform can hold at most one train at any given time
- Trains can only stop at their designated platform
- If two trains need the same platform at overlapping times, only one can stop

**Example:**
```
Trains:
  Train 1: arr=10:00, dep=10:30, platform=1
  Train 2: arr=10:15, dep=10:45, platform=1
  Train 3: arr=10:00, dep=10:30, platform=2
  Train 4: arr=11:00, dep=11:30, platform=1

Platforms = 2

Output: 3 trains (Train 1, 3, and 4)
```

---

## Why Greedy Works Here

### The Key Insight

This is the **Activity Selection Problem** applied to each platform separately!

For each platform:
- We have a set of trains (activities) that want to use it
- Only one train can occupy the platform at a time
- We want to maximize the number of trains that can stop

### Greedy Strategy

**For each platform:**
1. Get all trains assigned to that platform
2. Sort by departure time (earliest first)
3. Apply activity selection: pick train with earliest departure that doesn't conflict

### Why Earliest Departure Time?

Same reasoning as activity selection:
- A train that departs earlier leaves the platform free sooner
- This maximizes opportunity for future trains
- No benefit in keeping a train longer than necessary

### Exchange Argument

For each platform independently:
- If optimal solution picks train A before train B (both compatible)
- But train B departs earlier
- We can swap them without losing any trains
- Therefore, always picking earliest departure is safe

---

## Greedy Choice Property Explanation

### Platform Independence

The key observation is that platforms don't interfere with each other:
- Train on platform 1 doesn't affect platform 2
- We can solve each platform independently
- Total = sum of trains selected on each platform

### Per-Platform Activity Selection

For platform `p`:
```
1. Filter trains assigned to platform p
2. Sort by departure time
3. Greedily select non-overlapping trains
4. Count selected trains
```

---

## Step-by-Step Algorithm

```
1. GROUP trains by platform number
2. FOR each platform:
   a. SORT its trains by departure time
   b. SELECT first train (earliest departure)
   c. FOR each subsequent train:
      - IF arrival >= last_selected_departure:
        - SELECT this train
        - UPDATE last_selected_departure
3. RETURN total count of selected trains
```

---

## Brute Force Comparison

### Brute Force Approach

Try all possible subsets of trains, check validity, maximize count.

```python
def brute_force(trains, m):
    n = len(trains)
    max_count = 0
    
    for mask in range(1 << n):
        subset = [trains[i] for i in range(n) if mask & (1 << i)]
        
        # Check validity: no overlaps on any platform
        valid = True
        for p in range(1, m + 1):
            platform_trains = [(arr, dep) for arr, dep, plat in subset if plat == p]
            platform_trains.sort(key=lambda x: x[1])
            
            for i in range(1, len(platform_trains)):
                if platform_trains[i][0] < platform_trains[i-1][1]:
                    valid = False
                    break
            if not valid:
                break
        
        if valid:
            max_count = max(max_count, len(subset))
    
    return max_count
```

**Time: O(2^n * n * m)**

### Greedy Advantage

| Approach | Time | Space |
|----------|------|-------|
| Brute Force | O(2^n * n * m) | O(n) |
| Greedy | O(n log n) | O(n) |

---

## Optimal Greedy Implementation

```python
from collections import defaultdict

def max_trains_stoppage(trains, m):
    """
    Find maximum trains that can stop at station.
    
    Args:
        trains: List of (arrival, departure, platform) tuples
        m: Number of platforms
    
    Returns:
        Maximum number of trains that can stop
    """
    # Group trains by platform
    platform_trains = defaultdict(list)
    for arr, dep, platform in trains:
        platform_trains[platform].append((arr, dep))
    
    total_count = 0
    
    # Solve activity selection for each platform
    for platform in range(1, m + 1):
        if platform not in platform_trains:
            continue
        
        # Sort by departure time
        platform_trains[platform].sort(key=lambda x: x[1])
        
        count = 1
        last_dep = platform_trains[platform][0][1]
        
        for arr, dep in platform_trains[platform][1:]:
            if arr >= last_dep:
                count += 1
                last_dep = dep
        
        total_count += count
    
    return total_count
```

**Time: O(n log n)**
**Space: O(n)**

---

## Dry Run with Selection Visualization

**Input:**
```
Platforms: 2
Trains:
  T1: (10:00, 10:30, P1)
  T2: (10:15, 10:45, P1)
  T3: (10:00, 10:30, P2)
  T4: (11:00, 11:30, P1)
  T5: (10:20, 10:50, P2)
  T6: (10:40, 11:10, P2)
```

### Step 1: Group by Platform

```
Platform 1: [T1(10:00-10:30), T2(10:15-10:45), T4(11:00-11:30)]
Platform 2: [T3(10:00-10:30), T5(10:20-10:50), T6(10:40-11:10)]
```

### Step 2: Process Platform 1

```
Sorted by departure: T1(10:30), T2(10:45), T4(11:30)

Timeline: 10:00    10:15    10:30    10:45    11:00    11:15    11:30
          |-----T1-----|
                |-------T2-------|
                                        |------T4------|

Processing:
- T1: Select (first train)
  Last departure = 10:30
  Selected: [T1]

- T2: Arrival 10:15 < 10:30? YES - CONFLICT
  Skip T2

- T4: Arrival 11:00 >= 10:30? YES - No conflict
  Select T4
  Last departure = 11:30
  Selected: [T1, T4]

Platform 1 count: 2
```

### Step 3: Process Platform 2

```
Sorted by departure: T3(10:30), T5(10:50), T6(11:10)

Timeline: 10:00    10:20    10:30    10:40    10:50    11:00    11:10
          |-----T3-----|
                  |--------T5--------|
                            |--------T6--------|

Processing:
- T3: Select (first train)
  Last departure = 10:30
  Selected: [T3]

- T5: Arrival 10:20 < 10:30? YES - CONFLICT
  Skip T5

- T6: Arrival 10:40 >= 10:30? YES - No conflict
  Select T6
  Last departure = 11:10
  Selected: [T3, T6]

Platform 2 count: 2
```

### Final Result

```
Platform 1: T1, T4 (2 trains)
Platform 2: T3, T6 (2 trains)
Total: 4 trains

Visual Schedule:
Time:     10:00    10:30    11:00    11:30
P1:       [===T1===]        [===T4===]
P2:       [===T3===]  [===T6===]
```

---

## Time and Space Complexity

### Time Complexity: O(n log n)

| Operation | Complexity |
|-----------|------------|
| Group trains by platform | O(n) |
| Sort each platform's trains | O(n log n) total |
| Greedy selection | O(n) total |
| **Total** | **O(n log n)** |

### Space Complexity: O(n)

| Storage | Complexity |
|---------|------------|
| Platform grouping | O(n) |
| Sorted lists | O(n) |
| **Total** | **O(n)** |

---

## Variations and Extensions

### 1. Trains with Profit

If each train has a profit and we want to maximize total profit:
- This becomes Weighted Activity Selection
- Use Dynamic Programming instead of greedy

### 2. No Fixed Platform Assignment

If trains can go to any platform:
- This becomes a graph coloring / interval partitioning problem
- Greedy by sorting all trains works differently

### 3. Platform Capacity > 1

If each platform can hold multiple trains:
- Adjust the selection logic
- Track number of trains currently on each platform

### 4. Real-World Considerations

- Buffer time between trains
- Priority trains
- Through trains vs stopping trains
- Platform preferences
