# Maximum Meetings in One Room Problem

## Problem Statement

Given `n` meetings with their start and end times, find the maximum number of meetings that can be accommodated in a single meeting room. A meeting room can only host one meeting at a time.

**Input:**
- `start[]` - Array of start times for each meeting
- `end[]` - Array of end times for each meeting

**Output:** Maximum number of non-overlapping meetings

**Example:**
```
Input:
  start[] = [1, 3, 0, 5, 8, 5]
  end[]   = [2, 4, 6, 7, 9, 9]

Output: 4
Selected meetings: Meeting 1 (1-2), Meeting 2 (3-4), Meeting 4 (5-7), Meeting 5 (8-9)
```

---

## Why Greedy Works Here

### The Greedy Choice Property

**Claim:** There exists an optimal solution that includes the meeting with the earliest end time.

**Intuition:**
- The meeting that ends earliest frees up the room the soonest
- An early finish leaves maximum room for subsequent meetings
- We're not "blocking" potential meetings by finishing early

### Exchange Argument Proof

1. Let `OPT` be any optimal solution with meetings sorted by end time: `{m1, m2, ..., mk}`
2. Let `g` be the meeting with the globally earliest end time
3. **Case 1:** `g = m1` - We're done, optimal includes our greedy choice
4. **Case 2:** `g != m1` - Then `end(g) <= end(m1)`
   - Create `OPT' = {g, m2, ..., mk}`
   - Since `end(g) <= end(m1)` and `m2` didn't conflict with `m1`:
     - `start(m2) >= end(m1) >= end(g)`
   - So `m2` doesn't conflict with `g` either
   - `OPT'` is valid and has same size as `OPT`
5. Therefore, greedy choice is always safe!

### Why Other Strategies Fail

| Strategy | Why It Fails |
|----------|--------------|
| Earliest start time | Long meeting starting early blocks many short ones |
| Shortest duration | Short meeting in middle may block two meetings |
| Fewest conflicts | Expensive to compute, and still not optimal |

**Counterexample for Shortest Duration:**
```
Meetings: A=[0,4], B=[3,5], C=[4,8]
         |===A===|
              |B|
             |===C===|

Shortest first: B (duration 2) blocks both A and C
Optimal: A, C (2 meetings vs 1)
```

---

## Step-by-Step Algorithm

### Algorithm:

```
1. CREATE meeting list with (start, end, index) tuples
2. SORT meetings by end time (ascending)
3. SELECT first meeting (always safe - earliest end)
4. FOR each remaining meeting:
   - IF start_time >= last_selected_end_time:
     - SELECT this meeting
     - UPDATE last_selected_end_time
5. RETURN selected meetings and count
```

### Key Implementation Details

- Store original indices to report which meetings were selected
- Handle edge cases: empty input, single meeting
- Sorting is the critical step - O(n log n)

---

## Brute Force Comparison

### Brute Force Approach
Generate all possible subsets of meetings, check each for validity, find maximum.

```python
def brute_force(start, end):
    n = len(start)
    max_count = 0
    best_selection = []
    
    for mask in range(1 << n):  # 2^n subsets
        subset = [(start[i], end[i], i) for i in range(n) if mask & (1 << i)]
        
        # Sort by end time for overlap checking
        subset.sort(key=lambda x: x[1])
        
        # Check validity (no overlaps)
        valid = True
        for i in range(1, len(subset)):
            if subset[i][0] < subset[i-1][1]:
                valid = False
                break
        
        if valid and len(subset) > max_count:
            max_count = len(subset)
            best_selection = [m[2] for m in subset]
    
    return max_count, best_selection
```

**Time Complexity:** O(2^n * n log n)
**Space Complexity:** O(n)

### Why Brute Force is Impractical
- For n=20: Over 1 million subsets to check
- For n=30: Over 1 billion subsets
- Exponential growth is infeasible for real-world meeting scheduling

---

## Optimal Greedy Approach

```python
def max_meetings(start, end):
    n = len(start)
    if n == 0:
        return 0, []
    
    # Create meetings with original indices
    meetings = [(start[i], end[i], i) for i in range(n)]
    
    # Sort by end time - THE KEY GREEDY INSIGHT
    meetings.sort(key=lambda x: x[1])
    
    # Greedy selection
    selected = [meetings[0][2]]  # First meeting always selected
    last_end = meetings[0][1]
    
    for i in range(1, n):
        if meetings[i][0] >= last_end:  # No overlap
            selected.append(meetings[i][2])
            last_end = meetings[i][1]
    
    return len(selected), selected
```

**Time Complexity:** O(n log n) for sorting
**Space Complexity:** O(n) for storing meetings

---

## Dry Run with Selection Visualization

**Input:**
```
Meetings with (start, end):
M0: (1, 2)   M1: (3, 4)   M2: (0, 6)
M3: (5, 7)   M4: (8, 9)   M5: (5, 9)
```

**Step 1: Sort by End Time**
```
After sorting: M0(1,2), M1(3,4), M2(0,6), M3(5,7), M4(8,9), M5(5,9)
```

**Step 2: Greedy Selection Process**

```
Timeline: 0----1----2----3----4----5----6----7----8----9
          
Step 1: Consider M0 (1-2)
        [====]                                          
        First meeting - SELECT!
        last_end = 2
        Selected: [M0]

Step 2: Consider M1 (3-4)
                  [====]                                
        Start=3 >= last_end=2? YES
        SELECT M1!
        last_end = 4
        Selected: [M0, M1]

Step 3: Consider M2 (0-6)
        [================]                              
        Start=0 >= last_end=4? NO
        SKIP M2 (overlaps with M1)

Step 4: Consider M3 (5-7)
                       [======]                         
        Start=5 >= last_end=4? YES
        SELECT M3!
        last_end = 7
        Selected: [M0, M1, M3]

Step 5: Consider M4 (8-9)
                                 [====]                 
        Start=8 >= last_end=7? YES
        SELECT M4!
        last_end = 9
        Selected: [M0, M1, M3, M4]

Step 6: Consider M5 (5-9)
                       [============]                   
        Start=5 >= last_end=9? NO
        SKIP M5 (overlaps with M3 and M4)
```

**Final Result:**
```
Selected Meetings: M0(1-2), M1(3-4), M3(5-7), M4(8-9)
Maximum Count: 4

Visual Timeline:
0----1----2----3----4----5----6----7----8----9
     [M0]    [M1]    [==M3==]    [M4]
```

---

## Time and Space Complexity

| Aspect | Complexity | Explanation |
|--------|------------|-------------|
| **Time** | O(n log n) | Dominated by sorting; selection is O(n) |
| **Space** | O(n) | Storing meeting tuples with indices |

### Breakdown:
- **Creating tuples:** O(n)
- **Sorting by end time:** O(n log n)
- **Single pass selection:** O(n)
- **Total:** O(n log n)

### If Already Sorted:
- Time reduces to O(n)
- Just one pass through meetings

---

## Variations and Extensions

### 1. Maximum Meetings with Meeting Details
Return not just count but full meeting information for selected meetings.

### 2. K-Room Meeting Scheduling
Schedule meetings across K rooms to maximize total meetings.
- Use K separate "last_end" trackers
- Assign each meeting to room that finished earliest

### 3. Weighted Meeting Selection
Meetings have importance scores - maximize total importance.
- Greedy fails! Use Dynamic Programming
- Classic "Weighted Job Scheduling" problem

### 4. Minimum Rooms Required
Find minimum number of rooms needed to host ALL meetings.
- Different problem - process events (start/end) in order
- Track concurrent meetings at each point

### 5. Meeting Room with Mandatory Meetings
Some meetings MUST be scheduled - maximize additional meetings.
- First place mandatory meetings
- Then greedily add optional ones in gaps

---

## Relationship to Activity Selection

This problem is **identical** to the Activity Selection problem:
- Activities = Meetings
- Activity duration = Meeting duration
- Non-overlapping activities = Non-conflicting meetings

The greedy insight (sort by end time) applies to both!

### Common Applications:
1. Conference room scheduling
2. CPU task scheduling
3. Event planning
4. Resource allocation
5. Classroom assignment
