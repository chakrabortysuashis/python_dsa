"""
Maximum Meetings in One Room - Greedy Algorithm
================================================

Problem: Given n meetings with start and end times, find the maximum number
of meetings that can be held in a single meeting room (no overlaps).

WHY GREEDY WORKS:
----------------
1. Greedy Choice Property: The meeting with earliest end time is always
   part of some optimal solution.

2. Exchange Argument: If optimal solution OPT doesn't include the earliest
   ending meeting 'g', we can replace OPT's first meeting with 'g'
   without reducing the count (g ends earlier, won't conflict with rest).

3. Optimal Substructure: After selecting a meeting, the remaining problem
   is a smaller instance of the same problem.

GREEDY STRATEGY: Sort by end time, always pick the earliest ending
meeting that doesn't conflict with previously selected meetings.

This problem is IDENTICAL to Activity Selection!
"""

from typing import List, Tuple


def max_meetings_basic(start: List[int], end: List[int]) -> int:
    """
    Basic implementation - returns count of maximum meetings.

    Greedy Strategy:
    1. Sort meetings by end time
    2. Select first meeting (earliest end)
    3. For each remaining, select if start >= last end

    Time: O(n log n) for sorting
    Space: O(n) for paired meetings

    Example:
    >>> max_meetings_basic([1, 3, 0, 5, 8, 5], [2, 4, 6, 7, 9, 9])
    4
    """
    n = len(start)
    if n == 0:
        return 0

    # Pair meetings and sort by end time
    meetings = sorted(zip(start, end), key=lambda x: x[1])

    count = 1  # First meeting always selected
    last_end = meetings[0][1]

    for s, e in meetings[1:]:
        if s >= last_end:  # No overlap
            count += 1
            last_end = e

    return count


def max_meetings_with_details(
    start: List[int],
    end: List[int]
) -> Tuple[int, List[int], List[Tuple[int, int]]]:
    """
    Returns count, indices of selected meetings, and their time ranges.

    Returns:
        (count, selected_indices, selected_meetings)

    Example:
    >>> count, indices, meetings = max_meetings_with_details([1, 3, 0, 5, 8, 5], [2, 4, 6, 7, 9, 9])
    >>> count
    4
    """
    n = len(start)
    if n == 0:
        return 0, [], []

    # Include original index
    meetings = [(start[i], end[i], i) for i in range(n)]
    meetings.sort(key=lambda x: x[1])  # Sort by end time

    selected_indices = [meetings[0][2]]
    selected_meetings = [(meetings[0][0], meetings[0][1])]
    last_end = meetings[0][1]

    for s, e, idx in meetings[1:]:
        if s >= last_end:
            selected_indices.append(idx)
            selected_meetings.append((s, e))
            last_end = e

    return len(selected_indices), selected_indices, selected_meetings


def max_meetings_with_names(
    meetings: List[Tuple[str, int, int]]
) -> Tuple[int, List[str]]:
    """
    Maximum meetings with named meetings for clarity.

    Args:
        meetings: List of (name, start, end) tuples

    Returns:
        (count, list of selected meeting names)

    Example:
    >>> meetings = [('Standup', 9, 10), ('Design', 10, 12), ('Lunch', 11, 13)]
    >>> max_meetings_with_names(meetings)
    (2, ['Standup', 'Design'])
    """
    if not meetings:
        return 0, []

    # Sort by end time
    sorted_meetings = sorted(meetings, key=lambda x: x[2])

    selected = [sorted_meetings[0][0]]
    last_end = sorted_meetings[0][2]

    for name, start, end in sorted_meetings[1:]:
        if start >= last_end:
            selected.append(name)
            last_end = end

    return len(selected), selected


def max_meetings_return_order(start: List[int], end: List[int]) -> List[int]:
    """
    Return meeting indices in the ORDER they were selected (by end time).

    This is useful when you need to know the schedule sequence.

    Example:
    >>> max_meetings_return_order([1, 3, 0, 5, 8, 5], [2, 4, 6, 7, 9, 9])
    [0, 1, 3, 4]  # Meeting indices in selection order
    """
    n = len(start)
    if n == 0:
        return []

    meetings = [(start[i], end[i], i) for i in range(n)]
    meetings.sort(key=lambda x: x[1])

    result = [meetings[0][2]]
    last_end = meetings[0][1]

    for s, e, idx in meetings[1:]:
        if s >= last_end:
            result.append(idx)
            last_end = e

    return result


# =============================================================================
# COMPARISON: Greedy vs Brute Force
# =============================================================================

def max_meetings_brute_force(start: List[int], end: List[int]) -> int:
    """
    Brute force: Try all 2^n subsets.

    Time: O(2^n * n log n) - Exponential!
    Space: O(n)

    Only for verification on small inputs.
    """
    n = len(start)
    max_count = 0

    for mask in range(1 << n):
        subset = []
        for i in range(n):
            if mask & (1 << i):
                subset.append((start[i], end[i]))

        # Sort by end time for overlap check
        subset.sort(key=lambda x: x[1])

        # Check validity
        valid = True
        for i in range(1, len(subset)):
            if subset[i][0] < subset[i-1][1]:
                valid = False
                break

        if valid:
            max_count = max(max_count, len(subset))

    return max_count


# =============================================================================
# VARIATIONS
# =============================================================================

def max_meetings_k_rooms(
    start: List[int],
    end: List[int],
    k: int
) -> int:
    """
    Extension: Maximum meetings with K rooms available.

    Strategy: Use a min-heap to track when each room becomes free.
    Assign each meeting (sorted by end) to the room that frees earliest.

    Time: O(n log n + n log k)
    Space: O(k)

    Example:
    >>> max_meetings_k_rooms([1, 2, 3, 4], [10, 10, 10, 10], 2)
    2  # Can fit 2 meetings in 2 rooms
    """
    import heapq

    n = len(start)
    if n == 0 or k == 0:
        return 0

    meetings = sorted(zip(start, end), key=lambda x: x[1])

    # Min-heap of room end times
    rooms = [0] * k
    heapq.heapify(rooms)

    count = 0
    for s, e in meetings:
        # Get room that frees earliest
        earliest_free = rooms[0]

        if s >= earliest_free:
            # Can use this room
            heapq.heappop(rooms)
            heapq.heappush(rooms, e)
            count += 1

    return count


def min_rooms_needed(start: List[int], end: List[int]) -> int:
    """
    Related problem: Find MINIMUM rooms needed to host ALL meetings.

    Different from max meetings! Here we must schedule everything.

    Strategy: Process events (start/end) in time order.
    Track concurrent meetings at each point.

    Time: O(n log n)
    Space: O(n)

    Example:
    >>> min_rooms_needed([0, 5, 15], [30, 10, 20])
    2  # Meeting 1 overlaps with meeting 2
    """
    events = []
    for s, e in zip(start, end):
        events.append((s, 1))   # Start event
        events.append((e, -1))  # End event

    # Sort by time; end events before start events at same time
    events.sort(key=lambda x: (x[0], x[1]))

    current = 0
    max_rooms = 0

    for _, delta in events:
        current += delta
        max_rooms = max(max_rooms, current)

    return max_rooms


def meetings_to_remove_for_non_overlap(start: List[int], end: List[int]) -> int:
    """
    Find minimum meetings to remove so remaining don't overlap.

    Answer = n - max_non_overlapping

    This is max_meetings in disguise!

    Example:
    >>> meetings_to_remove_for_non_overlap([1, 2, 3], [2, 3, 4])
    0  # All can be scheduled
    >>> meetings_to_remove_for_non_overlap([1, 1, 1], [2, 2, 2])
    2  # Remove 2, keep 1
    """
    n = len(start)
    max_kept = max_meetings_basic(start, end)
    return n - max_kept


def max_meetings_with_mandatory(
    all_meetings: List[Tuple[int, int]],
    mandatory_indices: List[int]
) -> Tuple[int, List[int]]:
    """
    Some meetings MUST be scheduled. Maximize additional meetings.

    Strategy:
    1. Schedule mandatory meetings first
    2. Find gaps between mandatory meetings
    3. Greedily fill gaps with optional meetings

    Example:
    >>> all_meetings = [(0, 3), (2, 5), (4, 6), (7, 9)]
    >>> mandatory = [0, 3]  # Meetings at index 0 and 3 are mandatory
    >>> max_meetings_with_mandatory(all_meetings, mandatory)
    (3, [0, 2, 3])  # Can add meeting 2 in the gap
    """
    n = len(all_meetings)
    mandatory_set = set(mandatory_indices)

    # Get mandatory meetings sorted by end time
    mandatory_meetings = sorted(
        [(all_meetings[i][0], all_meetings[i][1], i) for i in mandatory_indices],
        key=lambda x: x[1]
    )

    # Check if mandatory meetings are compatible
    for i in range(1, len(mandatory_meetings)):
        if mandatory_meetings[i][0] < mandatory_meetings[i-1][1]:
            return -1, []  # Mandatory meetings conflict!

    # Find optional meetings
    optional = [(all_meetings[i][0], all_meetings[i][1], i)
                for i in range(n) if i not in mandatory_set]
    optional.sort(key=lambda x: x[1])

    # Build result with mandatory meetings
    selected = [m[2] for m in mandatory_meetings]

    # Try to add optional meetings in gaps
    all_selected = sorted(
        [(all_meetings[i][0], all_meetings[i][1], i) for i in selected],
        key=lambda x: x[1]
    )

    for s, e, idx in optional:
        # Check if this meeting fits in any gap
        can_add = True
        for ms, me, _ in all_selected:
            # Check overlap
            if not (e <= ms or s >= me):
                can_add = False
                break

        if can_add:
            selected.append(idx)
            all_selected.append((s, e, idx))
            all_selected.sort(key=lambda x: x[1])

    return len(selected), sorted(selected)


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Comprehensive test cases with explanations."""

    print("=" * 60)
    print("MAXIMUM MEETINGS IN ONE ROOM - TEST CASES")
    print("=" * 60)

    # Test 1: Basic example
    print("\nTest 1: Basic Example")
    print("-" * 40)
    start = [1, 3, 0, 5, 8, 5]
    end = [2, 4, 6, 7, 9, 9]

    result = max_meetings_basic(start, end)
    print(f"Meetings (start, end):")
    for i in range(len(start)):
        print(f"  Meeting {i}: ({start[i]}, {end[i]})")
    print(f"Maximum meetings: {result}")
    assert result == 4, f"Expected 4, got {result}"

    # Test 2: With details
    print("\nTest 2: With Selected Meeting Details")
    print("-" * 40)
    count, indices, meetings = max_meetings_with_details(start, end)
    print(f"Count: {count}")
    print(f"Selected indices: {indices}")
    print(f"Selected meetings: {meetings}")

    # Test 3: Named meetings
    print("\nTest 3: Named Meetings")
    print("-" * 40)
    named_meetings = [
        ('Morning Standup', 9, 10),
        ('Design Review', 10, 12),
        ('Lunch Meeting', 11, 13),
        ('Sprint Planning', 14, 16),
        ('Customer Call', 15, 17)
    ]
    count, selected = max_meetings_with_names(named_meetings)
    print(f"Meetings: {[m[0] for m in named_meetings]}")
    print(f"Selected: {selected}")
    print(f"Count: {count}")

    # Test 4: All overlapping
    print("\nTest 4: All Overlapping")
    print("-" * 40)
    start = [1, 2, 3, 4]
    end = [10, 10, 10, 10]
    result = max_meetings_basic(start, end)
    print(f"All meetings overlap heavily")
    print(f"Maximum: {result}")
    assert result == 1

    # Test 5: No overlapping
    print("\nTest 5: No Overlapping")
    print("-" * 40)
    start = [1, 3, 5, 7]
    end = [2, 4, 6, 8]
    result = max_meetings_basic(start, end)
    print(f"Sequential meetings")
    print(f"Maximum: {result}")
    assert result == 4

    # Test 6: Compare with brute force
    print("\nTest 6: Greedy vs Brute Force")
    print("-" * 40)
    start = [1, 3, 0, 5, 3, 5, 6, 8]
    end = [2, 4, 6, 7, 9, 9, 10, 11]

    greedy = max_meetings_basic(start, end)
    brute = max_meetings_brute_force(start, end)
    print(f"Greedy: {greedy}")
    print(f"Brute force: {brute}")
    assert greedy == brute, "Should match!"

    # Test 7: K rooms
    print("\nTest 7: K Rooms Available")
    print("-" * 40)
    start = [1, 2, 3, 4]
    end = [10, 10, 10, 10]
    for k in [1, 2, 3, 4]:
        result = max_meetings_k_rooms(start, end, k)
        print(f"With {k} room(s): {result} meetings")

    # Test 8: Minimum rooms needed
    print("\nTest 8: Minimum Rooms Needed")
    print("-" * 40)
    start = [0, 5, 15]
    end = [30, 10, 20]
    rooms = min_rooms_needed(start, end)
    print(f"Meetings: {list(zip(start, end))}")
    print(f"Minimum rooms: {rooms}")
    assert rooms == 2

    # Test 9: Meetings to remove
    print("\nTest 9: Meetings to Remove for Non-Overlap")
    print("-" * 40)
    start = [1, 1, 1]
    end = [2, 2, 2]
    remove = meetings_to_remove_for_non_overlap(start, end)
    print(f"Three identical meetings: remove {remove}")
    assert remove == 2

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_greedy_choice():
    """Step-by-step demonstration of greedy selection."""

    print("\n" + "=" * 60)
    print("DEMONSTRATION: GREEDY MEETING SELECTION")
    print("=" * 60)

    meetings = [
        ('M1', 1, 2), ('M2', 3, 4), ('M3', 0, 6),
        ('M4', 5, 7), ('M5', 8, 9), ('M6', 5, 9)
    ]

    print("\nOriginal meetings:")
    for name, start, end in meetings:
        print(f"  {name}: [{start}, {end}]")

    # Sort by end time
    sorted_meetings = sorted(meetings, key=lambda x: x[2])

    print("\nAfter sorting by END TIME (key insight!):")
    for name, start, end in sorted_meetings:
        print(f"  {name}: [{start}, {end}] - ends at {end}")

    print("\nGreedy Selection Process:")
    print("-" * 50)

    selected = []
    last_end = 0

    for name, start, end in sorted_meetings:
        print(f"\nConsidering {name} ({start}-{end}):")
        print(f"  Room free at: {last_end}")
        print(f"  Meeting starts: {start}")

        if start >= last_end:
            print(f"  {start} >= {last_end}? YES!")
            print(f"  -> SELECT {name}")
            selected.append(name)
            last_end = end
        else:
            print(f"  {start} >= {last_end}? NO - room busy!")
            print(f"  -> SKIP {name}")

    print("\n" + "-" * 50)
    print(f"Final Selection: {' -> '.join(selected)}")
    print(f"Total meetings: {len(selected)}")

    print("\nWHY THIS IS OPTIMAL:")
    print("By always picking the meeting that ends earliest, we free")
    print("the room as soon as possible, maximizing opportunity for")
    print("subsequent meetings.")


if __name__ == "__main__":
    run_tests()
    demonstrate_greedy_choice()
