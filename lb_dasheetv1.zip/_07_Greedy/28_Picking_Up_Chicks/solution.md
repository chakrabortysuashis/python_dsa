# Picking Up Chicks (Google Code Jam)

## Problem Statement

N chickens are on a road, each at position X[i] moving with velocity V[i] toward a barn at position B. You need at least K chickens to reach the barn by time T. You can swap any two adjacent chickens (costs 1 swap). Find minimum swaps needed, or "IMPOSSIBLE".

**Input:** 
- N chickens at positions X[i] with velocities V[i]
- Barn at position B, deadline T
- Need K chickens

**Output:** Minimum swaps or "IMPOSSIBLE"

---

## Why Greedy Works Here

### Key Insight

A chicken can reach the barn if: `X[i] + V[i] * T >= B`

### Greedy Observation

1. First, identify which chickens CAN reach in time (call them "good")
2. Among good chickens, we want the K rightmost (closest to barn)
3. Count chickens that are ahead of each good chicken but CAN'T reach (blocking)
4. Swap count = sum of blockers for the K best good chickens

### Why Rightmost Good Chickens?

Chickens closer to the barn have fewer chickens ahead of them, meaning fewer potential swaps needed.

---

## Algorithm

```python
def picking_up_chicks(N, K, B, T, X, V):
    # Check which can reach
    can_reach = [X[i] + V[i] * T >= B for i in range(N)]
    
    good_count = sum(can_reach)
    if good_count < K:
        return "IMPOSSIBLE"
    
    # Count from right, track swaps needed
    swaps = 0
    selected = 0
    blockers = 0  # chickens that can't reach but are to the right
    
    for i in range(N - 1, -1, -1):
        if can_reach[i]:
            swaps += blockers
            selected += 1
            if selected == K:
                return swaps
        else:
            blockers += 1
    
    return "IMPOSSIBLE"
```

---

## Dry Run

**Input:** N=5, K=3, B=10, T=2
- Positions: [0, 2, 5, 6, 7]
- Velocities: [1, 1, 4, 2, 2]

**Step 1: Check reachability**
```
Chicken 0: 0 + 1*2 = 2 < 10 (NO)
Chicken 1: 2 + 1*2 = 4 < 10 (NO)
Chicken 2: 5 + 4*2 = 13 >= 10 (YES)
Chicken 3: 6 + 2*2 = 10 >= 10 (YES)
Chicken 4: 7 + 2*2 = 11 >= 10 (YES)

Good chickens: 3 (indices 2, 3, 4)
Need 3, have 3 - possible!
```

**Step 2: Count swaps (right to left)**
```
i=4: can_reach=YES, blockers=0, swaps=0, selected=1
i=3: can_reach=YES, blockers=0, swaps=0, selected=2
i=2: can_reach=YES, blockers=0, swaps=0, selected=3

Selected K=3, total swaps = 0
```

---

## Time and Space Complexity

| Aspect | Complexity |
|--------|------------|
| **Time** | O(N) |
| **Space** | O(N) for can_reach array |
