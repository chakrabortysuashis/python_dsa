"""
Picking Up Chicks (Google Code Jam) - Greedy Algorithm
=======================================================

Problem: N chickens at positions X[i] with velocities V[i] moving toward
barn at B. Need K chickens to reach by time T. Can swap adjacent chickens.
Find minimum swaps.

WHY GREEDY WORKS:
-----------------
1. Key Insight: A chicken can reach iff X[i] + V[i]*T >= B

2. Greedy Choice: Pick the K rightmost "good" chickens (those that can reach).
   Rightmost means fewer potential blockers.

3. Counting Swaps: For each selected good chicken, count how many "bad"
   chickens are to its right (these must be swapped past).

GREEDY STRATEGY: Scan right to left, select good chickens, count bad
chickens passed as swaps.
"""

from typing import List, Union


def picking_up_chicks(
    N: int,
    K: int,
    B: int,
    T: int,
    X: List[int],
    V: List[int]
) -> Union[int, str]:
    """
    Find minimum swaps to get K chickens to barn by time T.

    Time: O(N)
    Space: O(N)

    Example:
    >>> picking_up_chicks(5, 3, 10, 2, [0, 2, 5, 6, 7], [1, 1, 4, 2, 2])
    0
    """
    # Determine which chickens can reach the barn
    can_reach = [X[i] + V[i] * T >= B for i in range(N)]

    good_count = sum(can_reach)
    if good_count < K:
        return "IMPOSSIBLE"

    # Scan right to left
    swaps = 0
    selected = 0
    blockers = 0  # Bad chickens to the right of current position

    for i in range(N - 1, -1, -1):
        if can_reach[i]:
            # This good chicken needs to swap past all blockers
            swaps += blockers
            selected += 1
            if selected == K:
                return swaps
        else:
            blockers += 1

    return "IMPOSSIBLE"


def picking_up_chicks_detailed(
    N: int,
    K: int,
    B: int,
    T: int,
    X: List[int],
    V: List[int]
) -> tuple:
    """
    Return swaps and which chickens are selected.
    """
    can_reach = [X[i] + V[i] * T >= B for i in range(N)]

    good_count = sum(can_reach)
    if good_count < K:
        return "IMPOSSIBLE", [], can_reach

    swaps = 0
    selected = []
    blockers = 0

    for i in range(N - 1, -1, -1):
        if can_reach[i]:
            swaps += blockers
            selected.append(i)
            if len(selected) == K:
                return swaps, selected[::-1], can_reach
        else:
            blockers += 1

    return "IMPOSSIBLE", [], can_reach


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Test cases for Picking Up Chicks."""

    print("=" * 60)
    print("PICKING UP CHICKS - TEST CASES")
    print("=" * 60)

    # Test 1: No swaps needed
    print("\nTest 1: No Swaps Needed")
    print("-" * 40)
    N, K, B, T = 5, 3, 10, 2
    X = [0, 2, 5, 6, 7]
    V = [1, 1, 4, 2, 2]

    result, selected, can_reach = picking_up_chicks_detailed(N, K, B, T, X, V)
    print(f"Positions: {X}")
    print(f"Velocities: {V}")
    print(f"Can reach: {can_reach}")
    print(f"Selected: {selected}")
    print(f"Swaps: {result}")
    print("PASS")

    # Test 2: Some swaps needed
    print("\nTest 2: Swaps Needed")
    print("-" * 40)
    N, K, B, T = 5, 2, 10, 2
    X = [0, 2, 3, 6, 7]
    V = [6, 1, 4, 2, 2]  # Chicken 0 can reach!

    result = picking_up_chicks(N, K, B, T, X, V)
    print(f"Swaps: {result}")
    print("PASS")

    # Test 3: Impossible
    print("\nTest 3: Impossible")
    print("-" * 40)
    N, K, B, T = 5, 4, 100, 1
    X = [0, 1, 2, 3, 4]
    V = [1, 1, 1, 1, 1]

    result = picking_up_chicks(N, K, B, T, X, V)
    print(f"Result: {result}")
    assert result == "IMPOSSIBLE"
    print("PASS")

    # Test 4: All can reach
    print("\nTest 4: All Can Reach")
    print("-" * 40)
    N, K, B, T = 3, 2, 5, 10
    X = [0, 1, 2]
    V = [1, 1, 1]

    result = picking_up_chicks(N, K, B, T, X, V)
    print(f"Swaps: {result}")
    assert result == 0
    print("PASS")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


if __name__ == "__main__":
    run_tests()
