# Buy Maximum Stocks

## Problem Statement

In a stock market, there is a product with its price given for `n` days. On the `i-th` day, the price of the product is `price[i]` and you can buy at most `limit[i]` units of that product on that day. Given a total budget `K`, find the maximum number of products you can buy.

**Input:**
- `price[]`: Price of product on each day
- `limit[]`: Maximum units that can be bought on each day (sometimes limit[i] = i+1)
- `K`: Total budget

**Output:**
- Maximum number of products that can be bought

**Example:**
```
n = 3
price = [10, 7, 19]
limit = [3, 2, 5]  (or limit[i] = i+1 in some variants)
K = 45

Day 1: price=10, can buy up to 3
Day 2: price=7, can buy up to 2
Day 3: price=19, can buy up to 5

Strategy: Buy on cheaper days first
- Day 2: Buy 2 units at 7 each = 14, remaining = 31
- Day 1: Buy 3 units at 10 each = 30, remaining = 1
- Day 3: Can't afford (19 > 1)

Total bought: 5 units
```

---

## Why Greedy Works Here

### The Key Insight

**Buy from the cheapest days first!**

Each product is identical regardless of which day it's bought. The only difference is the price. To maximize quantity within budget, we should prioritize buying from cheaper days.

### Greedy Strategy

1. Sort days by price (ascending)
2. For each day (cheapest first):
   - Buy as many as possible (limited by daily limit and remaining budget)
3. Sum up total units bought

### Why This Works

**Exchange Argument:**
- Suppose we have two days: Day A (price 5) and Day B (price 10)
- If we buy 1 unit from Day B instead of Day A:
  - We spend 10 instead of 5
  - Same quantity (1 unit)
  - We could have bought MORE from Day A with the extra 5

**Conclusion:** Always prioritize cheaper days to maximize quantity.

### Mathematical Proof

Let `p_i` = price on day i, `q_i` = quantity bought on day i

Total spent = Sum of `p_i * q_i`
Total bought = Sum of `q_i`

To maximize Sum(q_i) subject to Sum(p_i * q_i) <= K:
- Each unit from cheaper day costs less
- More units can be bought with same budget
- Therefore, buying from cheapest days first is optimal

---

## Greedy Choice Property Explanation

### The Decision at Each Step

When we have remaining budget B:
1. Look at the cheapest day we haven't fully utilized
2. Buy as many units as possible from that day
3. Move to the next cheapest day

### Why "As Many As Possible"?

If we don't buy all we can from the cheapest day:
- We leave cheap units "on the table"
- Later we might buy more expensive units
- This is suboptimal

---

## Step-by-Step Algorithm

```
1. CREATE list of (price, limit, day_index) tuples
2. SORT by price (ascending)
3. INITIALIZE: total_bought = 0, remaining_budget = K
4. FOR each day in sorted order:
   a. max_affordable = remaining_budget // price
   b. can_buy = min(limit, max_affordable)
   c. total_bought += can_buy
   d. remaining_budget -= can_buy * price
5. RETURN total_bought
```

---

## Brute Force Comparison

### Brute Force Approach

Try all possible combinations of quantities for each day.

```python
def brute_force(prices, limits, K):
    n = len(prices)
    max_bought = 0
    
    def backtrack(day, budget, bought):
        nonlocal max_bought
        
        if day == n or budget <= 0:
            max_bought = max(max_bought, bought)
            return
        
        # Try buying 0 to min(limit, affordable) units
        max_units = min(limits[day], budget // prices[day])
        for units in range(max_units + 1):
            backtrack(day + 1, budget - units * prices[day], bought + units)
    
    backtrack(0, K, 0)
    return max_bought
```

**Time: O(product of all limits)** - potentially exponential!

### Comparison

| Approach | Time | Space |
|----------|------|-------|
| Brute Force | O(L1 * L2 * ... * Ln) | O(n) stack |
| Greedy | O(n log n) | O(n) |

---

## Optimal Greedy Implementation

```python
def buy_max_stocks(prices, limits, K):
    """
    Find maximum stocks that can be bought within budget.
    
    Args:
        prices: Price on each day
        limits: Max units available on each day
        K: Total budget
    
    Returns:
        Maximum units that can be bought
    """
    n = len(prices)
    
    # Pair each day with its price, limit, and index
    days = [(prices[i], limits[i]) for i in range(n)]
    
    # Sort by price (ascending)
    days.sort(key=lambda x: x[0])
    
    total_bought = 0
    remaining = K
    
    for price, limit in days:
        if remaining <= 0:
            break
        
        # Buy as many as possible from this day
        max_affordable = remaining // price
        can_buy = min(limit, max_affordable)
        
        total_bought += can_buy
        remaining -= can_buy * price
    
    return total_bought
```

**Time: O(n log n)**
**Space: O(n)**

---

## Dry Run with Selection Visualization

**Input:**
```
prices = [10, 7, 19, 5, 12]
limits = [3, 2, 5, 4, 2]
K = 60
```

### Step 1: Sort by Price

```
Original:
  Day 1: price=10, limit=3
  Day 2: price=7,  limit=2
  Day 3: price=19, limit=5
  Day 4: price=5,  limit=4
  Day 5: price=12, limit=2

Sorted by price:
  Day 4: price=5,  limit=4  <-- cheapest
  Day 2: price=7,  limit=2
  Day 1: price=10, limit=3
  Day 5: price=12, limit=2
  Day 3: price=19, limit=5  <-- most expensive
```

### Step 2: Greedy Selection

```
Initial: budget=60, bought=0

========================================
Day 4 (price=5, limit=4)
========================================
  Budget: 60
  Max affordable: 60 // 5 = 12
  Can buy: min(4, 12) = 4
  
  BUY 4 units at $5 each = $20
  
  Budget remaining: 60 - 20 = 40
  Total bought: 4

========================================
Day 2 (price=7, limit=2)
========================================
  Budget: 40
  Max affordable: 40 // 7 = 5
  Can buy: min(2, 5) = 2
  
  BUY 2 units at $7 each = $14
  
  Budget remaining: 40 - 14 = 26
  Total bought: 6

========================================
Day 1 (price=10, limit=3)
========================================
  Budget: 26
  Max affordable: 26 // 10 = 2
  Can buy: min(3, 2) = 2
  
  BUY 2 units at $10 each = $20
  
  Budget remaining: 26 - 20 = 6
  Total bought: 8

========================================
Day 5 (price=12, limit=2)
========================================
  Budget: 6
  Max affordable: 6 // 12 = 0
  Can buy: min(2, 0) = 0
  
  Cannot afford any units
  
  Budget remaining: 6
  Total bought: 8

========================================
Day 3 (price=19, limit=5)
========================================
  Budget: 6
  Max affordable: 6 // 19 = 0
  Can buy: min(5, 0) = 0
  
  Cannot afford any units
  
  Budget remaining: 6
  Total bought: 8
```

### Final Result

```
Total units bought: 8
Budget used: 60 - 6 = 54
Budget remaining: 6

Breakdown:
  Day 4: 4 units x $5  = $20
  Day 2: 2 units x $7  = $14
  Day 1: 2 units x $10 = $20
  Day 5: 0 units
  Day 3: 0 units
  -------------------------
  Total: 8 units for $54
```

---

## Time and Space Complexity

### Time Complexity: O(n log n)

| Operation | Complexity |
|-----------|------------|
| Create day tuples | O(n) |
| Sort by price | O(n log n) |
| Greedy selection | O(n) |
| **Total** | **O(n log n)** |

### Space Complexity: O(n)

| Storage | Complexity |
|---------|------------|
| Days array | O(n) |
| Sorting space | O(n) or O(log n) |
| **Total** | **O(n)** |

---

## Variations and Extensions

### 1. Common Variant: limit[i] = i + 1

On day i, you can buy at most (i+1) units.

```python
def buy_max_stocks_variant(prices, K):
    n = len(prices)
    days = [(prices[i], i + 1) for i in range(n)]  # limit = i + 1
    days.sort(key=lambda x: x[0])
    
    # ... same greedy logic
```

### 2. With Transaction Fees

If there's a fee per transaction, might need to consider minimum purchase amounts.

### 3. Maximize Value (Different Products)

If products have different values, this becomes a knapsack variant.

### 4. Multi-Day Holding

If products must be held for certain periods, scheduling constraints apply.
