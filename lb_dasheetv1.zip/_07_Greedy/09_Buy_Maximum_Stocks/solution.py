"""
Buy Maximum Stocks - Greedy Algorithm
=====================================

Problem: Given stock prices for n days, where on day i you can buy at most
limit[i] units at price[i], find the maximum units you can buy with budget K.

WHY GREEDY WORKS:
----------------
1. Identical Products: Each unit of stock is the same regardless of which
   day it's bought. Only the price differs.

2. Maximize Quantity: With a fixed budget, buying cheaper units first
   leaves more budget for additional units.

3. Exchange Argument: If we buy an expensive unit instead of a cheaper one,
   we could have bought the cheaper one and potentially more with savings.

GREEDY STRATEGY:
- Sort days by price (ascending)
- For each day (cheapest first), buy as many as possible
- Continue until budget exhausted or all days processed
"""

from typing import List, Tuple


def buy_max_stocks(prices: List[int], limits: List[int], K: int) -> int:
    """
    Find maximum stocks that can be bought within budget.

    Greedy Strategy:
    1. Sort days by price (cheapest first)
    2. Buy as many as possible from each day
    3. Track remaining budget

    Args:
        prices: Price on each day
        limits: Maximum units available on each day
        K: Total budget

    Returns:
        Maximum units that can be bought

    Time: O(n log n)
    Space: O(n)

    Example:
    >>> buy_max_stocks([10, 7, 19, 5], [3, 2, 5, 4], 45)
    7
    """
    n = len(prices)
    if n == 0 or K <= 0:
        return 0

    # Pair price with limit
    days = [(prices[i], limits[i]) for i in range(n)]

    # Sort by price (ascending) - cheapest first
    days.sort(key=lambda x: x[0])

    total_bought = 0
    remaining = K

    for price, limit in days:
        if remaining <= 0:
            break

        # Buy as many as possible
        max_affordable = remaining // price
        can_buy = min(limit, max_affordable)

        total_bought += can_buy
        remaining -= can_buy * price

    return total_bought


def buy_max_stocks_variant(prices: List[int], K: int) -> int:
    """
    Variant where limit on day i is (i+1).

    Common in competitive programming problems.

    Example:
    >>> buy_max_stocks_variant([10, 7, 19], 45)
    4
    """
    n = len(prices)
    if n == 0 or K <= 0:
        return 0

    # On day i (0-indexed), can buy (i+1) units
    days = [(prices[i], i + 1) for i in range(n)]
    days.sort(key=lambda x: x[0])

    total_bought = 0
    remaining = K

    for price, limit in days:
        if remaining <= 0:
            break

        max_affordable = remaining // price
        can_buy = min(limit, max_affordable)

        total_bought += can_buy
        remaining -= can_buy * price

    return total_bought


def buy_max_stocks_detailed(
    prices: List[int],
    limits: List[int],
    K: int
) -> Tuple[int, List[Tuple[int, int, int]], int]:
    """
    Detailed solution with purchase breakdown.

    Returns:
        (total_bought, list of (day, units, cost), remaining_budget)
    """
    n = len(prices)
    if n == 0 or K <= 0:
        return 0, [], K

    # Include day index
    days = [(prices[i], limits[i], i) for i in range(n)]
    days.sort(key=lambda x: x[0])

    total_bought = 0
    remaining = K
    purchases = []

    for price, limit, day_idx in days:
        if remaining <= 0:
            break

        max_affordable = remaining // price
        can_buy = min(limit, max_affordable)

        if can_buy > 0:
            cost = can_buy * price
            purchases.append((day_idx, can_buy, cost))
            total_bought += can_buy
            remaining -= cost

    return total_bought, purchases, remaining


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Comprehensive test cases with explanations."""

    print("=" * 60)
    print("BUY MAXIMUM STOCKS - TEST CASES")
    print("=" * 60)

    # Test 1: Basic example
    print("\nTest 1: Basic Example")
    print("-" * 40)
    prices = [10, 7, 19, 5, 12]
    limits = [3, 2, 5, 4, 2]
    K = 60

    result = buy_max_stocks(prices, limits, K)
    total, purchases, remaining = buy_max_stocks_detailed(prices, limits, K)

    print(f"Prices: {prices}")
    print(f"Limits: {limits}")
    print(f"Budget: {K}")
    print(f"\nMaximum stocks: {result}")
    print(f"Purchases:")
    for day, units, cost in purchases:
        print(f"  Day {day+1}: {units} units at ${prices[day]} = ${cost}")
    print(f"Remaining budget: ${remaining}")

    # Test 2: Variant with limit = i+1
    print("\nTest 2: Variant (limit = day number)")
    print("-" * 40)
    prices = [10, 7, 19]
    K = 45

    result = buy_max_stocks_variant(prices, K)
    print(f"Prices: {prices}")
    print(f"Limits: [1, 2, 3] (day number)")
    print(f"Budget: {K}")
    print(f"Maximum stocks: {result}")

    # Test 3: Budget smaller than cheapest item
    print("\nTest 3: Insufficient Budget")
    print("-" * 40)
    prices = [100, 200, 300]
    limits = [5, 5, 5]
    K = 50

    result = buy_max_stocks(prices, limits, K)
    print(f"Prices: {prices}")
    print(f"Budget: {K}")
    print(f"Result: {result}")
    assert result == 0

    # Test 4: Can buy everything
    print("\nTest 4: Unlimited Budget")
    print("-" * 40)
    prices = [10, 20, 30]
    limits = [2, 3, 1]
    K = 1000

    result = buy_max_stocks(prices, limits, K)
    print(f"Budget enough for all")
    print(f"Maximum: {result}")
    assert result == 6  # 2 + 3 + 1

    # Test 5: Single day
    print("\nTest 5: Single Day")
    print("-" * 40)
    prices = [10]
    limits = [100]
    K = 55

    result = buy_max_stocks(prices, limits, K)
    print(f"Price: 10, Limit: 100, Budget: 55")
    print(f"Result: {result}")
    assert result == 5  # 55 // 10 = 5

    # Test 6: Empty input
    print("\nTest 6: Empty Input")
    print("-" * 40)
    result = buy_max_stocks([], [], 100)
    print(f"Empty input: {result}")
    assert result == 0

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_greedy_choice():
    """Step-by-step demonstration of the greedy approach."""

    print("\n" + "=" * 60)
    print("DEMONSTRATION: WHY BUY CHEAPEST FIRST")
    print("=" * 60)

    prices = [10, 7, 19, 5, 12]
    limits = [3, 2, 5, 4, 2]
    K = 60

    print(f"\nOriginal days:")
    for i, (p, l) in enumerate(zip(prices, limits)):
        print(f"  Day {i+1}: price=${p}, limit={l}")

    # Sort
    days = [(prices[i], limits[i], i+1) for i in range(len(prices))]
    days.sort(key=lambda x: x[0])

    print(f"\nSorted by price (cheapest first):")
    for p, l, d in days:
        print(f"  Day {d}: price=${p}, limit={l}")

    print("\n" + "-" * 40)
    print("GREEDY BUYING:")
    print("-" * 40)

    remaining = K
    total = 0

    for price, limit, day in days:
        print(f"\nDay {day} (price=${price}, limit={limit}):")
        print(f"  Budget: ${remaining}")

        max_affordable = remaining // price
        can_buy = min(limit, max_affordable)

        if can_buy > 0:
            cost = can_buy * price
            print(f"  Can afford: {max_affordable}")
            print(f"  Can buy (with limit): {can_buy}")
            print(f"  BUY {can_buy} units for ${cost}")
            remaining -= cost
            total += can_buy
        else:
            print(f"  Cannot afford any (need ${price}, have ${remaining})")

        print(f"  Total so far: {total} units")

    print("\n" + "-" * 40)
    print(f"FINAL: {total} units bought")
    print(f"Remaining budget: ${remaining}")
    print("-" * 40)

    print("\nWHY THIS IS OPTIMAL:")
    print("- Each stock unit is identical")
    print("- Cheaper units stretch budget further")
    print("- Buying expensive first would waste budget")
    print("- No benefit to saving budget (no future value)")


if __name__ == "__main__":
    run_tests()
    demonstrate_greedy_choice()
