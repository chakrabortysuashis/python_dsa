# CHOCOLA - Chocolate Breaking (SPOJ)

## Problem Statement

Break a M x N chocolate bar into 1x1 pieces with minimum cost. Each cut has a cost depending on the row/column being cut. Cost is multiplied by number of pieces being cut.

**Input:** 
- M x N chocolate bar
- Horizontal cut costs: h[1..M-1]
- Vertical cut costs: v[1..N-1]

**Output:** Minimum total cost to break into unit pieces

---

## Why Greedy Works Here

### Key Insight

When we make a cut, its cost is multiplied by the number of pieces that cut goes through.

**Greedy Observation:** Make expensive cuts first, when there are fewer pieces.

### Exchange Argument

If we delay an expensive cut, more pieces form, increasing total cost for that cut. Therefore, always make the most expensive available cut next.

---

## Algorithm

```python
def chocola(M, N, h_costs, v_costs):
    # Sort costs descending
    h_costs.sort(reverse=True)
    v_costs.sort(reverse=True)
    
    h_pieces = 1  # Horizontal pieces
    v_pieces = 1  # Vertical pieces
    
    total_cost = 0
    h_idx, v_idx = 0, 0
    
    while h_idx < len(h_costs) or v_idx < len(v_costs):
        h_cost = h_costs[h_idx] if h_idx < len(h_costs) else -1
        v_cost = v_costs[v_idx] if v_idx < len(v_costs) else -1
        
        if h_cost >= v_cost:
            # Make horizontal cut - goes through v_pieces
            total_cost += h_cost * v_pieces
            h_pieces += 1
            h_idx += 1
        else:
            # Make vertical cut - goes through h_pieces
            total_cost += v_cost * h_pieces
            v_pieces += 1
            v_idx += 1
    
    return total_cost
```

---

## Time Complexity

O((M + N) log(M + N)) for sorting

---

## Dry Run

**Example:** 2 x 2 bar, h_cost = [2], v_cost = [1]

- Sort: h = [2], v = [1]
- Cut horizontal (cost 2): 2 * 1 = 2, now have 2 horizontal pieces
- Cut vertical (cost 1): 1 * 2 = 2
- Total: 4

If we did vertical first: 1 * 1 + 2 * 2 = 1 + 4 = 5 (worse!)
