"""
CHOCOLA - Chocolate Breaking (SPOJ) - Greedy Algorithm
=======================================================

Problem: Break M x N chocolate into 1x1 pieces. Each cut has a cost,
multiplied by pieces it cuts through. Minimize total cost.

WHY GREEDY WORKS:
-----------------
1. Greedy Choice: Make expensive cuts first when fewer pieces exist.

2. Exchange Argument: Delaying expensive cuts means more pieces,
   higher multiplier, higher cost.

GREEDY STRATEGY: Sort cuts by cost descending, always make the most
expensive available cut.
"""

from typing import List


def chocola(M: int, N: int, h_costs: List[int], v_costs: List[int]) -> int:
    """
    Calculate minimum cost to break chocolate into unit pieces.

    Time: O((M+N) log(M+N))
    Space: O(1) extra (sorting in place)

    Example:
    >>> chocola(2, 2, [2], [1])
    4
    """
    h_costs = sorted(h_costs, reverse=True)
    v_costs = sorted(v_costs, reverse=True)

    h_pieces = 1  # Current horizontal segments
    v_pieces = 1  # Current vertical segments

    total_cost = 0
    h_idx, v_idx = 0, 0

    while h_idx < len(h_costs) or v_idx < len(v_costs):
        h_cost = h_costs[h_idx] if h_idx < len(h_costs) else -1
        v_cost = v_costs[v_idx] if v_idx < len(v_costs) else -1

        if h_cost >= v_cost:
            total_cost += h_cost * v_pieces
            h_pieces += 1
            h_idx += 1
        else:
            total_cost += v_cost * h_pieces
            v_pieces += 1
            v_idx += 1

    return total_cost


def run_tests():
    print("=" * 50)
    print("CHOCOLA - TEST CASES")
    print("=" * 50)

    # Test 1
    print("\nTest 1: 2x2 bar")
    result = chocola(2, 2, [2], [1])
    print(f"Result: {result}")
    assert result == 4

    # Test 2: Larger example
    print("\nTest 2: 6x4 bar")
    h = [2, 1, 3, 1, 4]  # 5 horizontal cuts
    v = [4, 1, 2]        # 3 vertical cuts
    result = chocola(6, 4, h, v)
    print(f"Result: {result}")

    print("\nALL TESTS PASSED!")


if __name__ == "__main__":
    run_tests()
