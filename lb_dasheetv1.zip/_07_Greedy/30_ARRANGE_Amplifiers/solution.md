# ARRANGE - Amplifiers (SPOJ)

## Problem Statement

Arrange N amplifiers to maximize the final signal. Each amplifier multiplies the signal by its gain. However, gains can be fractional. Find optimal arrangement.

**Key Insight:** For amplifiers with gains > 1, order doesn't matter (multiplication commutes). But with gains < 1, we need special handling.

**Example:**
```
Gains: [2, 3, 0.5]
Any order of [2, 3, 0.5] gives same result: 2 * 3 * 0.5 = 3
```

---

## Why Greedy Works

### For Standard Multiplication

Since multiplication is commutative (a * b = b * a), order doesn't affect the product. However, the SPOJ problem has a twist where amplifiers work as A^B, not A * B.

### For A^B Style (SPOJ Version)

If amplifier i followed by j gives: (signal^Ai)^Aj = signal^(Ai*Aj)

We want to maximize the exponent chain. Greedy: compare A^B vs B^A.

---

## Algorithm (A^B Version)

```python
def arrange_amplifiers(gains):
    from functools import cmp_to_key
    
    def compare(a, b):
        # Compare a^b vs b^a
        # Equivalent to b*log(a) vs a*log(b)
        # Or a^(1/a) vs b^(1/b) for positive values
        if a ** b > b ** a:
            return -1  # a should come first
        elif a ** b < b ** a:
            return 1
        return 0
    
    return sorted(gains, key=cmp_to_key(compare))
```

---

## Time Complexity

O(N log N) for sorting

---

## Special Cases

- All gains equal: any order works
- Gains include 1: 1s can go anywhere
- Gains include 0: 0 destroys signal regardless of position
