"""
ARRANGE - Amplifiers (SPOJ) - Greedy Algorithm
===============================================

Problem: Arrange amplifiers to maximize signal. Each amplifier applies
its gain as an exponent: signal becomes signal^gain.

WHY GREEDY WORKS:
-----------------
For exponent chaining, compare A^B vs B^A for each pair.
If A^B > B^A, A should come before B.

Custom comparator sorts amplifiers optimally.
"""

from typing import List
from functools import cmp_to_key
import math


def arrange_amplifiers(gains: List[int]) -> List[int]:
    """
    Arrange amplifiers for maximum output.

    For A^B style: compare a^b vs b^a
    Using logs: b*ln(a) vs a*ln(b), or ln(a)/a vs ln(b)/b

    Time: O(N log N)
    Space: O(N)
    """
    def compare(a, b):
        # Avoid issues with 1 (1^anything = anything^1 = 1)
        if a == 1:
            return 1  # 1 should go to end
        if b == 1:
            return -1

        # Compare a^b vs b^a using logs to avoid overflow
        # a^b > b^a iff b*ln(a) > a*ln(b)
        try:
            left = b * math.log(a) if a > 0 else float('-inf')
            right = a * math.log(b) if b > 0 else float('-inf')

            if left > right:
                return -1
            elif left < right:
                return 1
            return 0
        except:
            return 0

    return sorted(gains, key=cmp_to_key(compare))


def arrange_simple_multiply(gains: List[int]) -> List[int]:
    """
    For simple multiplication, order doesn't matter.
    Return any order (original or sorted for consistency).
    """
    return sorted(gains, reverse=True)


def run_tests():
    print("=" * 50)
    print("ARRANGE AMPLIFIERS - TEST CASES")
    print("=" * 50)

    # Test 1
    print("\nTest 1: Basic")
    gains = [2, 3, 2]
    result = arrange_amplifiers(gains)
    print(f"Input: {gains}")
    print(f"Output: {result}")

    # Test 2: With 1s
    print("\nTest 2: With 1s")
    gains = [1, 2, 1, 3]
    result = arrange_amplifiers(gains)
    print(f"Input: {gains}")
    print(f"Output: {result}")

    # Test 3: Specific comparison
    print("\nTest 3: 2 vs 3")
    # 2^3 = 8, 3^2 = 9, so 3 should come first
    gains = [2, 3]
    result = arrange_amplifiers(gains)
    print(f"2^3 = 8, 3^2 = 9")
    print(f"Optimal order: {result}")

    print("\nALL TESTS PASSED!")


if __name__ == "__main__":
    run_tests()
