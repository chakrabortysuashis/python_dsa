# Minimum Cost to Cut a Board into Squares

## Problem Statement

Given a wooden board of dimensions `M x N`, cut it into `M * N` unit squares (1x1). The cost of a cut depends on the length of the board being cut. Find the minimum total cost to cut the board into unit squares.

**Input:**
- `M`: Number of rows
- `N`: Number of columns  
- `X[]`: Cost of horizontal cuts (M-1 values)
- `Y[]`: Cost of vertical cuts (N-1 values)

**Output:**
- Minimum total cost to cut board into unit squares

**Constraints:**
- Horizontal cut i costs `X[i]` multiplied by the number of pieces it cuts through
- Vertical cut j costs `Y[j]` multiplied by the number of pieces it cuts through

**Example:**
```
M = 4, N = 6
X = [2, 1, 3, 1, 4]  (5 horizontal cuts)
Y = [4, 1, 2]        (3 vertical cuts)

Optimal strategy: Make expensive cuts first while pieces are fewer
```

---

## Why Greedy Works Here

### The Key Insight

The cost of each cut is **multiplied** by the number of pieces it goes through.

**Greedy Strategy:** Make the most expensive cuts first, when there are fewer pieces!

### Why Make Expensive Cuts First?

Consider two cuts with costs A (expensive) and B (cheap):

**Order 1: A first, then B**
- Cut A goes through 1 piece: cost = A * 1
- Cut B goes through 2 pieces: cost = B * 2
- Total = A + 2B

**Order 2: B first, then A**
- Cut B goes through 1 piece: cost = B * 1
- Cut A goes through 2 pieces: cost = A * 2
- Total = B + 2A

Since A > B, we have A + 2B < B + 2A, so Order 1 is better!

### The Multiplier Effect

- Horizontal cuts are multiplied by (current number of vertical pieces)
- Vertical cuts are multiplied by (current number of horizontal pieces)

By making expensive cuts early, we minimize the multiplier effect.

---

## Greedy Choice Property Explanation

### Why Sort All Cuts Together?

We need to consider both horizontal and vertical cuts together, sorted by cost (descending).

```
Example: X = [3, 1], Y = [4, 2]

Sorted (descending): 4(V), 3(H), 2(V), 1(H)

Process in order:
1. Vertical cut cost 4: 1 horizontal piece exists
   Cost = 4 * 1 = 4, now 2 vertical pieces

2. Horizontal cut cost 3: 2 vertical pieces exist
   Cost = 3 * 2 = 6, now 2 horizontal pieces

3. Vertical cut cost 2: 2 horizontal pieces exist
   Cost = 2 * 2 = 4, now 3 vertical pieces

4. Horizontal cut cost 1: 3 vertical pieces exist
   Cost = 1 * 3 = 3, now 3 horizontal pieces

Total = 4 + 6 + 4 + 3 = 17
```

### Exchange Argument

If we swap an expensive cut with a cheaper one:
- The expensive cut now goes through more pieces (higher multiplier)
- Total cost increases
- Therefore, expensive-first is optimal

---

## Step-by-Step Algorithm

```
1. CREATE list of cuts: (cost, type) where type = 'H' or 'V'
2. SORT cuts by cost in descending order
3. INITIALIZE: horizontal_pieces = 1, vertical_pieces = 1
4. INITIALIZE: total_cost = 0
5. FOR each cut in sorted order:
   a. IF cut is horizontal:
      - total_cost += cost * vertical_pieces
      - horizontal_pieces += 1
   b. ELSE (vertical):
      - total_cost += cost * horizontal_pieces
      - vertical_pieces += 1
6. RETURN total_cost
```

---

## Brute Force Comparison

### Brute Force Approach

Try all possible orderings of cuts and find minimum cost.

```python
from itertools import permutations

def brute_force(X, Y):
    cuts = [('H', x) for x in X] + [('V', y) for y in Y]
    min_cost = float('inf')
    
    for perm in permutations(cuts):
        h_pieces, v_pieces = 1, 1
        cost = 0
        
        for cut_type, cut_cost in perm:
            if cut_type == 'H':
                cost += cut_cost * v_pieces
                h_pieces += 1
            else:
                cost += cut_cost * h_pieces
                v_pieces += 1
        
        min_cost = min(min_cost, cost)
    
    return min_cost
```

**Complexity:** O((m+n)! * (m+n)) - factorial!

### Comparison

| Approach | Time | Space |
|----------|------|-------|
| Brute Force | O((m+n)!) | O(m+n) |
| Greedy | O((m+n) log(m+n)) | O(m+n) |

---

## Optimal Greedy Implementation

```python
def min_cost_to_cut_board(M, N, X, Y):
    """
    Find minimum cost to cut M x N board into unit squares.
    
    Args:
        M: Number of rows
        N: Number of columns
        X: Costs of horizontal cuts (len = M-1)
        Y: Costs of vertical cuts (len = N-1)
    
    Returns:
        Minimum total cost
    """
    # Sort both arrays in descending order
    X_sorted = sorted(X, reverse=True)
    Y_sorted = sorted(Y, reverse=True)
    
    total_cost = 0
    horizontal_pieces = 1  # Number of pieces horizontally
    vertical_pieces = 1    # Number of pieces vertically
    
    i, j = 0, 0
    
    # Merge and process in descending order of cost
    while i < len(X_sorted) and j < len(Y_sorted):
        if X_sorted[i] >= Y_sorted[j]:
            # Make horizontal cut
            total_cost += X_sorted[i] * vertical_pieces
            horizontal_pieces += 1
            i += 1
        else:
            # Make vertical cut
            total_cost += Y_sorted[j] * horizontal_pieces
            vertical_pieces += 1
            j += 1
    
    # Process remaining horizontal cuts
    while i < len(X_sorted):
        total_cost += X_sorted[i] * vertical_pieces
        i += 1
    
    # Process remaining vertical cuts
    while j < len(Y_sorted):
        total_cost += Y_sorted[j] * horizontal_pieces
        j += 1
    
    return total_cost
```

**Time: O((m+n) log(m+n))**
**Space: O(m+n) or O(1) if sorting in-place**

---

## Dry Run with Selection Visualization

**Input:**
```
M = 4 (3 horizontal cuts)
N = 4 (3 vertical cuts)
X = [2, 1, 3]
Y = [4, 1, 2]
```

### Step 1: Sort Cuts

```
Horizontal cuts X: [2, 1, 3] -> sorted: [3, 2, 1]
Vertical cuts Y: [4, 1, 2] -> sorted: [4, 2, 1]
```

### Step 2: Merge and Process

```
Initial board:
+---+---+---+---+
|               |
+               +
|     4 x 4     |
+               +
|               |
+---+---+---+---+

h_pieces = 1, v_pieces = 1, total = 0

Compare: X[0]=3 vs Y[0]=4
Y[0]=4 is larger -> Vertical cut first

========================================
Cut 1: Vertical (cost 4)
========================================
Cost = 4 * h_pieces = 4 * 1 = 4
v_pieces = 2
Total = 4

+---+---+|+---+---+
|       ||       |
+       |+       +
| 2x4   || 2x4   |
+       |+       +
|       ||       |
+---+---+|+---+---+

Compare: X[0]=3 vs Y[1]=2
X[0]=3 is larger -> Horizontal cut

========================================
Cut 2: Horizontal (cost 3)
========================================
Cost = 3 * v_pieces = 3 * 2 = 6
h_pieces = 2
Total = 4 + 6 = 10

+---+---+|+---+---+
|       ||       |
+---+---+|+---+---+
|       ||       |
+       |+       +
|       ||       |
+---+---+|+---+---+

Compare: X[1]=2 vs Y[1]=2
Equal, choose either (say X)

========================================
Cut 3: Horizontal (cost 2)
========================================
Cost = 2 * v_pieces = 2 * 2 = 4
h_pieces = 3
Total = 10 + 4 = 14

========================================
Cut 4: Vertical (cost 2)
========================================
Cost = 2 * h_pieces = 2 * 3 = 6
v_pieces = 3
Total = 14 + 6 = 20

========================================
Cut 5: Horizontal (cost 1)
========================================
Cost = 1 * v_pieces = 1 * 3 = 3
h_pieces = 4
Total = 20 + 3 = 23

========================================
Cut 6: Vertical (cost 1)
========================================
Cost = 1 * h_pieces = 1 * 4 = 4
v_pieces = 4
Total = 23 + 4 = 27
```

### Final Result

```
Total cost: 27

All cuts made in order: V(4), H(3), H(2), V(2), H(1), V(1)

Final state: 4 x 4 = 16 unit squares
```

---

## Time and Space Complexity

### Time Complexity: O((m+n) log(m+n))

| Operation | Complexity |
|-----------|------------|
| Sort horizontal cuts | O(m log m) |
| Sort vertical cuts | O(n log n) |
| Merge and process | O(m + n) |
| **Total** | **O((m+n) log(m+n))** |

### Space Complexity: O(m + n)

| Storage | Complexity |
|---------|------------|
| Sorted cuts arrays | O(m + n) |
| **Total** | **O(m + n)** |

---

## Variations and Extensions

### 1. Cuts with Different Dimensions

If cuts don't go all the way across, the problem becomes more complex.

### 2. Fixed Cut Order

If certain cuts must be made before others, use topological sorting combined with greedy.

### 3. Maximizing Cost

Reverse the strategy: make cheapest cuts first to maximize cost.

### 4. Real-World Applications

- Wood cutting in carpentry
- Material optimization in manufacturing
- Paper cutting for printing
- Circuit board partitioning

### 5. Related Problems

- Matrix Chain Multiplication (uses DP, not greedy)
- Rod Cutting Problem (related but different structure)
