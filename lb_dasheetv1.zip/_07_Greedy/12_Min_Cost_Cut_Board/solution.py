"""
Minimum Cost to Cut a Board into Squares - Greedy Algorithm
===========================================================

Problem: Given an M x N board, cut it into M*N unit squares. The cost of
each cut is multiplied by the number of pieces it goes through.

WHY GREEDY WORKS:
----------------
1. Multiplier Effect: Each cut cost is multiplied by current pieces count.
   Making expensive cuts early (fewer pieces) minimizes total cost.

2. Independence: The order of cuts within the same type doesn't matter,
   but the interleaving of horizontal and vertical cuts does.

3. Exchange Argument: If we swap an expensive cut with a cheaper one:
   - Expensive cut now has higher multiplier
   - Cheaper cut has lower multiplier
   - Net increase in total cost (since expensive > cheap)
   - Therefore, expensive-first is optimal

GREEDY STRATEGY:
- Combine all cuts with their types
- Sort by cost (descending)
- Process in order, tracking piece counts
- Each horizontal cut multiplied by vertical_pieces and vice versa
"""

from typing import List, Tuple


def min_cost_cut_board(M: int, N: int, X: List[int], Y: List[int]) -> int:
    """
    Find minimum cost to cut M x N board into unit squares.

    Greedy Strategy:
    1. Sort horizontal (X) and vertical (Y) cuts by cost (descending)
    2. Use merge-like process to take highest cost cut at each step
    3. Multiply cut cost by number of perpendicular pieces

    Args:
        M: Number of rows
        N: Number of columns
        X: Costs of horizontal cuts (len = M-1)
        Y: Costs of vertical cuts (len = N-1)

    Returns:
        Minimum total cost

    Time: O((m+n) log(m+n))
    Space: O(m+n)

    Example:
    >>> min_cost_cut_board(4, 4, [2, 1, 3], [4, 1, 2])
    27
    """
    # Sort both arrays in descending order
    X_sorted = sorted(X, reverse=True)
    Y_sorted = sorted(Y, reverse=True)

    total_cost = 0
    horizontal_pieces = 1  # Number of horizontal pieces
    vertical_pieces = 1    # Number of vertical pieces

    i, j = 0, 0

    # Merge process: always take the more expensive cut
    while i < len(X_sorted) and j < len(Y_sorted):
        if X_sorted[i] >= Y_sorted[j]:
            # Make horizontal cut
            # Goes through all vertical pieces
            total_cost += X_sorted[i] * vertical_pieces
            horizontal_pieces += 1
            i += 1
        else:
            # Make vertical cut
            # Goes through all horizontal pieces
            total_cost += Y_sorted[j] * horizontal_pieces
            vertical_pieces += 1
            j += 1

    # Process remaining horizontal cuts
    while i < len(X_sorted):
        total_cost += X_sorted[i] * vertical_pieces
        i += 1

    # Process remaining vertical cuts
    while j < len(Y_sorted):
        total_cost += Y_sorted[j] * horizontal_pieces
        j += 1

    return total_cost


def min_cost_cut_board_detailed(
    M: int,
    N: int,
    X: List[int],
    Y: List[int]
) -> Tuple[int, List[Tuple[str, int, int, int]]]:
    """
    Detailed solution with cut sequence.

    Returns:
        (total_cost, list of (type, cost, multiplier, subtotal) tuples)
    """
    # Create cuts with types
    cuts = []
    for cost in X:
        cuts.append(('H', cost))
    for cost in Y:
        cuts.append(('V', cost))

    # Sort by cost descending
    cuts.sort(key=lambda x: x[1], reverse=True)

    total_cost = 0
    h_pieces = 1
    v_pieces = 1
    sequence = []

    for cut_type, cost in cuts:
        if cut_type == 'H':
            multiplier = v_pieces
            subtotal = cost * multiplier
            total_cost += subtotal
            h_pieces += 1
        else:
            multiplier = h_pieces
            subtotal = cost * multiplier
            total_cost += subtotal
            v_pieces += 1

        sequence.append((cut_type, cost, multiplier, subtotal))

    return total_cost, sequence


def min_cost_alternative_order(M: int, N: int, X: List[int], Y: List[int]) -> int:
    """
    Calculate cost if cuts are made in the REVERSE order (cheapest first).
    Used to demonstrate why greedy (expensive first) is optimal.
    """
    X_sorted = sorted(X)  # Ascending (cheapest first)
    Y_sorted = sorted(Y)

    total_cost = 0
    h_pieces = 1
    v_pieces = 1

    i, j = 0, 0

    while i < len(X_sorted) and j < len(Y_sorted):
        if X_sorted[i] <= Y_sorted[j]:
            total_cost += X_sorted[i] * v_pieces
            h_pieces += 1
            i += 1
        else:
            total_cost += Y_sorted[j] * h_pieces
            v_pieces += 1
            j += 1

    while i < len(X_sorted):
        total_cost += X_sorted[i] * v_pieces
        i += 1

    while j < len(Y_sorted):
        total_cost += Y_sorted[j] * h_pieces
        j += 1

    return total_cost


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Comprehensive test cases with explanations."""

    print("=" * 60)
    print("MINIMUM COST TO CUT BOARD - TEST CASES")
    print("=" * 60)

    # Test 1: Basic example
    print("\nTest 1: Basic Example (4x4 board)")
    print("-" * 40)
    M, N = 4, 4
    X = [2, 1, 3]  # Horizontal cut costs
    Y = [4, 1, 2]  # Vertical cut costs

    min_cost = min_cost_cut_board(M, N, X, Y)
    worst_cost = min_cost_alternative_order(M, N, X, Y)

    print(f"Board: {M} x {N}")
    print(f"Horizontal cut costs: {X}")
    print(f"Vertical cut costs: {Y}")
    print(f"\nMinimum cost (expensive first): {min_cost}")
    print(f"Cost if cheap first: {worst_cost}")
    print(f"Savings: {worst_cost - min_cost}")

    # Test 2: Detailed breakdown
    print("\nTest 2: Detailed Breakdown")
    print("-" * 40)
    total, sequence = min_cost_cut_board_detailed(M, N, X, Y)
    print("Cut sequence:")
    for cut_type, cost, mult, subtotal in sequence:
        type_name = "Horizontal" if cut_type == 'H' else "Vertical"
        print(f"  {type_name} (${cost}) x {mult} pieces = ${subtotal}")
    print(f"Total: ${total}")

    # Test 3: 2x2 board
    print("\nTest 3: Small Board (2x2)")
    print("-" * 40)
    X = [5]
    Y = [3]
    cost = min_cost_cut_board(2, 2, X, Y)
    print(f"H cut: $5, V cut: $3")
    print(f"Minimum cost: {cost}")
    # Expensive first: H($5) x 1 + V($3) x 2 = 5 + 6 = 11
    assert cost == 11

    # Test 4: Only horizontal cuts
    print("\nTest 4: Only Horizontal Cuts (3x1 board)")
    print("-" * 40)
    X = [3, 1]
    Y = []
    cost = min_cost_cut_board(3, 1, X, Y)
    print(f"Cuts: {X}")
    print(f"Cost: {cost}")
    # Just 3 + 1 = 4 (no multiplier effect)
    assert cost == 4

    # Test 5: Large costs
    print("\nTest 5: Large Differences in Costs")
    print("-" * 40)
    X = [100, 1]
    Y = [50, 1]

    min_cost = min_cost_cut_board(3, 3, X, Y)
    worst_cost = min_cost_alternative_order(3, 3, X, Y)

    print(f"H cuts: {X}, V cuts: {Y}")
    print(f"Minimum: {min_cost}")
    print(f"Worst: {worst_cost}")
    print(f"Difference: {worst_cost - min_cost}")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_greedy_choice():
    """Step-by-step demonstration of the algorithm."""

    print("\n" + "=" * 60)
    print("DEMONSTRATION: WHY EXPENSIVE CUTS FIRST")
    print("=" * 60)

    M, N = 4, 4
    X = [2, 1, 3]
    Y = [4, 1, 2]

    print(f"\nBoard: {M} x {N}")
    print(f"Horizontal cuts: {X}")
    print(f"Vertical cuts: {Y}")

    # Create and sort cuts
    cuts = [('H', c) for c in X] + [('V', c) for c in Y]
    cuts.sort(key=lambda x: x[1], reverse=True)

    print(f"\nSorted cuts (expensive first):")
    for t, c in cuts:
        print(f"  {t}: ${c}")

    print("\n" + "-" * 40)
    print("PROCESSING CUTS:")
    print("-" * 40)

    h_pieces, v_pieces = 1, 1
    total = 0

    for i, (cut_type, cost) in enumerate(cuts):
        print(f"\nCut {i+1}: {cut_type} (cost ${cost})")
        print(f"  Current pieces: H={h_pieces}, V={v_pieces}")

        if cut_type == 'H':
            multiplier = v_pieces
            subtotal = cost * multiplier
            h_pieces += 1
        else:
            multiplier = h_pieces
            subtotal = cost * multiplier
            v_pieces += 1

        total += subtotal
        print(f"  Multiplier: {multiplier}")
        print(f"  Cost: ${cost} x {multiplier} = ${subtotal}")
        print(f"  Running total: ${total}")

    print(f"\n" + "-" * 40)
    print(f"MINIMUM TOTAL COST: ${total}")
    print("-" * 40)

    # Compare with worst case
    worst = min_cost_alternative_order(M, N, X, Y)
    print(f"\nIf we used cheapest first: ${worst}")
    print(f"Savings from greedy: ${worst - total} ({(worst-total)/worst*100:.1f}%)")

    print("\nWHY EXPENSIVE FIRST WORKS:")
    print("- Expensive cuts are made when fewer pieces exist")
    print("- Lower multiplier for high-cost cuts")
    print("- Higher multiplier only for low-cost cuts")
    print("- Net effect: minimized total cost")


if __name__ == "__main__":
    run_tests()
    demonstrate_greedy_choice()
