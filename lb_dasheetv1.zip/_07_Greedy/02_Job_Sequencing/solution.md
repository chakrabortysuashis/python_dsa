# Job Sequencing Problem

## Problem Statement

Given an array of jobs where every job has a deadline and associated profit, find the maximum profit that can be earned by scheduling jobs. Each job takes exactly 1 unit of time, and only one job can be scheduled at a time. A job can only be scheduled before its deadline.

**Input:**
- Array of jobs: `[(job_id, deadline, profit), ...]`
- Each job takes 1 unit of time

**Output:**
- Maximum total profit
- Sequence of jobs to execute

**Constraints:**
- A job must be completed before or on its deadline
- Only one job can be done at a time

**Example:**
```
Jobs: [(J1, 2, 100), (J2, 1, 19), (J3, 2, 27), (J4, 1, 25), (J5, 3, 15)]
       (id, deadline, profit)

Output: Maximum Profit = 142
Scheduled: J1 (slot 2), J3 (slot 1), J5 (slot 3)
```

---

## Why Greedy Works Here

### The Greedy Insight

**Key Observation:** Higher profit jobs should be prioritized, but we also need to ensure we don't miss deadlines.

**Greedy Strategy:**
1. Sort jobs by profit in descending order
2. For each job, assign it to the latest available slot before its deadline
3. This leaves earlier slots free for other jobs that might have earlier deadlines

### Why Latest Available Slot?

Consider this scenario:
- Job A: deadline 3, profit 100
- Job B: deadline 1, profit 50

If we put A in slot 1:
- A in slot 1
- B cannot be scheduled (deadline 1, slot 1 taken)
- Total: 100

If we put A in slot 3 (latest available before deadline 3):
- A in slot 3
- B in slot 1
- Total: 150

**Conclusion:** Always schedule high-profit jobs as late as possible (before deadline) to leave room for other jobs.

### Exchange Argument Proof

**Claim:** The greedy algorithm produces an optimal schedule.

**Proof:**
1. Suppose OPT is an optimal solution different from GREEDY
2. Let job `j` be the first job where they differ (by profit order)
3. In GREEDY, `j` is scheduled; in OPT, either:
   - `j` is not scheduled, or
   - `j` is in a different slot

4. **Case: j not in OPT**
   - GREEDY schedules `j` because a slot was available
   - We can add `j` to OPT (since slot is available)
   - This improves OPT, contradicting optimality

5. **Case: j in different slot in OPT**
   - We can swap `j` to the greedy position without conflict
   - OPT remains valid with same profit

Therefore, GREEDY is optimal.

---

## Greedy Choice Property Explanation

### The Two-Level Greedy Decision:

**Level 1 - Which job to consider next:**
- Process jobs in decreasing order of profit
- High-profit jobs get first chance at slots

**Level 2 - Which slot to assign:**
- Assign to the LATEST available slot <= deadline
- This maximizes flexibility for remaining jobs

### Visual Intuition:

```
Timeline: |  1  |  2  |  3  |  4  |
          
Job with deadline 3 and high profit:
  - DON'T put in slot 1 (wastes early slots)
  - PUT in slot 3 (latest valid slot)
  
This leaves slots 1, 2 open for jobs with earlier deadlines!
```

---

## Step-by-Step Greedy Selection

### Algorithm:

```
1. SORT jobs by profit (descending)
2. FIND maximum deadline (determines number of time slots)
3. CREATE slot array of size max_deadline (all empty)
4. FOR each job in sorted order:
   a. FOR slot from min(deadline, max_deadline) down to 1:
      - IF slot is empty:
        - ASSIGN job to this slot
        - ADD profit to total
        - BREAK
5. RETURN total profit and scheduled jobs
```

### Optimization with Union-Find:

Instead of linear search for empty slot, use Union-Find:
- `find(d)` returns the latest available slot <= d
- After filling slot `s`, union it with `s-1`

This reduces time from O(n^2) to O(n * alpha(n)) ~ O(n)

---

## Brute Force Comparison

### Brute Force Approach:

Try all permutations of jobs and check which valid schedule gives maximum profit.

```python
def brute_force(jobs):
    from itertools import permutations
    
    max_profit = 0
    best_schedule = []
    
    for perm in permutations(jobs):
        slots = {}
        profit = 0
        schedule = []
        
        for job_id, deadline, job_profit in perm:
            # Try to schedule in any slot <= deadline
            for slot in range(deadline, 0, -1):
                if slot not in slots:
                    slots[slot] = job_id
                    profit += job_profit
                    schedule.append(job_id)
                    break
        
        if profit > max_profit:
            max_profit = profit
            best_schedule = schedule
    
    return max_profit, best_schedule
```

**Time Complexity:** O(n! * n * d) - Factorial!
**Space Complexity:** O(n)

### Comparison:

| Approach | Time | Space | n=10 operations |
|----------|------|-------|-----------------|
| Brute Force | O(n! * n * d) | O(n) | ~36 million |
| Greedy | O(n log n + n * d) | O(d) | ~100 |
| Greedy + Union-Find | O(n log n) | O(d) | ~30 |

---

## Optimal Greedy Approach

```python
def job_sequencing(jobs):
    """
    jobs: List of (id, deadline, profit) tuples
    Returns: (max_profit, list of scheduled job ids)
    """
    # Sort by profit descending
    sorted_jobs = sorted(jobs, key=lambda x: x[2], reverse=True)
    
    # Find maximum deadline
    max_deadline = max(job[1] for job in jobs)
    
    # Slots array (1-indexed for convenience)
    slots = [None] * (max_deadline + 1)
    
    total_profit = 0
    scheduled = []
    
    for job_id, deadline, profit in sorted_jobs:
        # Find latest available slot <= deadline
        for slot in range(deadline, 0, -1):
            if slots[slot] is None:
                slots[slot] = job_id
                total_profit += profit
                scheduled.append(job_id)
                break
    
    return total_profit, scheduled
```

**Time Complexity:** O(n log n) + O(n * d) where d = max deadline
**Space Complexity:** O(d)

---

## Dry Run with Selection Visualization

**Input:**
```
Jobs: J1(d=2, p=100), J2(d=1, p=19), J3(d=2, p=27), J4(d=1, p=25), J5(d=3, p=15)
```

**Step 1: Sort by Profit (Descending)**
```
Sorted: J1(100) > J3(27) > J4(25) > J2(19) > J5(15)
```

**Step 2: Initialize Slots**
```
Max deadline = 3
Slots: [ _ | _ | _ ]
        1   2   3
```

**Step 3: Schedule Jobs**

```
Processing J1 (deadline=2, profit=100):
  Try slot 2: EMPTY -> ASSIGN
  Slots: [ _ | J1 | _ ]
          1    2    3
  Total profit: 100
  Scheduled: [J1]

Processing J3 (deadline=2, profit=27):
  Try slot 2: TAKEN (J1)
  Try slot 1: EMPTY -> ASSIGN
  Slots: [ J3 | J1 | _ ]
          1     2    3
  Total profit: 127
  Scheduled: [J1, J3]

Processing J4 (deadline=1, profit=25):
  Try slot 1: TAKEN (J3)
  No slot available!
  Slots: [ J3 | J1 | _ ]  (unchanged)
          1     2    3
  Total profit: 127
  Scheduled: [J1, J3]

Processing J2 (deadline=1, profit=19):
  Try slot 1: TAKEN (J3)
  No slot available!
  Slots: [ J3 | J1 | _ ]  (unchanged)
          1     2    3
  Total profit: 127
  Scheduled: [J1, J3]

Processing J5 (deadline=3, profit=15):
  Try slot 3: EMPTY -> ASSIGN
  Slots: [ J3 | J1 | J5 ]
          1     2    3
  Total profit: 142
  Scheduled: [J1, J3, J5]
```

**Final Result:**
```
Schedule:
  Slot 1: J3 (profit 27)
  Slot 2: J1 (profit 100)
  Slot 3: J5 (profit 15)

Total Profit: 142
Jobs Scheduled: 3 out of 5
```

**Why J4 and J2 were not scheduled:**
- Both have deadline 1
- Only one slot available at time 1
- J3 has higher profit (27 > 25 > 19), so it gets the slot
- J4 and J2 are sacrificed for higher overall profit

---

## Time and Space Complexity

### Basic Greedy:

| Operation | Complexity |
|-----------|------------|
| Sorting | O(n log n) |
| Slot assignment | O(n * d) |
| **Total Time** | O(n log n + n * d) |
| **Space** | O(d) for slots |

Where d = maximum deadline

### Optimized with Union-Find:

| Operation | Complexity |
|-----------|------------|
| Sorting | O(n log n) |
| Slot assignment | O(n * alpha(n)) |
| **Total Time** | O(n log n) |
| **Space** | O(d) |

Where alpha(n) is the inverse Ackermann function (practically constant).

---

## Variations and Extensions

### 1. All Jobs Have Same Profit
If all profits are equal, any valid schedule with maximum jobs is optimal.
Use activity selection approach instead.

### 2. Jobs with Processing Time > 1
This becomes a variant of the "Weighted Job Scheduling" problem.
Requires Dynamic Programming.

### 3. Multiple Machines
Schedule jobs on k machines to maximize profit.
Use k separate slot arrays or priority queue approach.

### 4. Job Sequencing with Penalties
Instead of missing profit, there's a penalty for missing deadline.
Minimize penalty instead of maximizing profit.

```python
def minimize_penalty(jobs):
    # Sort by penalty descending
    # Try to schedule; if can't, add penalty to total
    total_penalty = 0
    for job in sorted(jobs, key=lambda x: x.penalty, reverse=True):
        if cannot_schedule(job):
            total_penalty += job.penalty
    return total_penalty
```
