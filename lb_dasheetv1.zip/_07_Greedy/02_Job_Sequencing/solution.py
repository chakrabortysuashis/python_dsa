"""
Job Sequencing Problem - Greedy Algorithm
=========================================

Problem: Given jobs with deadlines and profits, schedule jobs to maximize
total profit. Each job takes 1 unit of time, and only one job can run at a time.
A job must complete before or on its deadline.

WHY GREEDY WORKS:
----------------
1. Greedy Choice: Process jobs by profit (descending). High-profit jobs
   deserve first chance at available slots.

2. Slot Assignment: For each job, assign to the LATEST available slot
   before its deadline. This leaves earlier slots free for jobs with
   earlier deadlines.

3. Exchange Argument: If optimal solution OPT differs from GREEDY in job j,
   we can swap j's position without reducing profit, showing GREEDY is optimal.

GREEDY STRATEGY:
- Sort by profit (descending)
- For each job, find latest slot <= deadline
- If found, schedule; else, skip this job
"""

from typing import List, Tuple, Optional
from dataclasses import dataclass


@dataclass
class Job:
    """Job with ID, deadline, and profit."""
    id: str
    deadline: int
    profit: int


def job_sequencing_basic(jobs: List[Tuple[str, int, int]]) -> Tuple[int, List[str]]:
    """
    Basic job sequencing - O(n * d) time complexity.

    Greedy Strategy:
    1. Sort jobs by profit descending
    2. For each job, try to schedule in latest slot <= deadline
    3. If slot found, add profit; else skip

    Args:
        jobs: List of (job_id, deadline, profit) tuples

    Returns:
        (total_profit, list of scheduled job IDs)

    Time: O(n log n) + O(n * d) where d = max deadline
    Space: O(d)

    Example:
    >>> jobs = [('J1', 2, 100), ('J2', 1, 19), ('J3', 2, 27), ('J4', 1, 25), ('J5', 3, 15)]
    >>> profit, scheduled = job_sequencing_basic(jobs)
    >>> profit
    142
    """
    if not jobs:
        return 0, []

    # Sort by profit descending - this is the key greedy insight
    sorted_jobs = sorted(jobs, key=lambda x: x[2], reverse=True)

    # Find maximum deadline
    max_deadline = max(job[1] for job in jobs)

    # Slots array (1-indexed, 0 unused)
    # slots[i] = job_id if slot i is filled, None otherwise
    slots = [None] * (max_deadline + 1)

    total_profit = 0
    scheduled = []

    for job_id, deadline, profit in sorted_jobs:
        # Greedy: find LATEST available slot <= deadline
        # This leaves earlier slots for jobs with earlier deadlines
        for slot in range(deadline, 0, -1):
            if slots[slot] is None:
                slots[slot] = job_id
                total_profit += profit
                scheduled.append(job_id)
                break

    return total_profit, scheduled


def job_sequencing_with_schedule(
    jobs: List[Tuple[str, int, int]]
) -> Tuple[int, List[Tuple[int, str, int]]]:
    """
    Job sequencing returning complete schedule with slot assignments.

    Returns:
        (total_profit, list of (slot, job_id, profit) tuples)
    """
    if not jobs:
        return 0, []

    sorted_jobs = sorted(jobs, key=lambda x: x[2], reverse=True)
    max_deadline = max(job[1] for job in jobs)
    slots = [None] * (max_deadline + 1)
    slot_profits = [0] * (max_deadline + 1)

    total_profit = 0

    for job_id, deadline, profit in sorted_jobs:
        for slot in range(deadline, 0, -1):
            if slots[slot] is None:
                slots[slot] = job_id
                slot_profits[slot] = profit
                total_profit += profit
                break

    # Build schedule
    schedule = []
    for slot in range(1, max_deadline + 1):
        if slots[slot] is not None:
            schedule.append((slot, slots[slot], slot_profits[slot]))

    return total_profit, schedule


class UnionFind:
    """
    Union-Find for optimized job sequencing.

    parent[i] = latest available slot <= i
    After filling slot s, union(s, s-1) makes find(s) return s-1
    """
    def __init__(self, n: int):
        self.parent = list(range(n + 1))

    def find(self, x: int) -> int:
        """Find latest available slot <= x."""
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])  # Path compression
        return self.parent[x]

    def union(self, x: int) -> None:
        """Mark slot x as filled by pointing to x-1."""
        if x > 0:
            self.parent[x] = x - 1


def job_sequencing_optimized(jobs: List[Tuple[str, int, int]]) -> Tuple[int, List[str]]:
    """
    Optimized job sequencing using Union-Find.

    Instead of linear search for empty slot, use Union-Find:
    - find(d) returns latest available slot <= d
    - After filling slot s, union(s) points s to s-1

    Time: O(n log n) for sorting + O(n * alpha(n)) for scheduling
          where alpha is inverse Ackermann (practically constant)
    Space: O(d)

    Example:
    >>> jobs = [('J1', 4, 20), ('J2', 1, 10), ('J3', 1, 40), ('J4', 1, 30)]
    >>> profit, scheduled = job_sequencing_optimized(jobs)
    >>> profit
    60
    """
    if not jobs:
        return 0, []

    sorted_jobs = sorted(jobs, key=lambda x: x[2], reverse=True)
    max_deadline = max(job[1] for job in jobs)

    uf = UnionFind(max_deadline)
    slots = [None] * (max_deadline + 1)

    total_profit = 0
    scheduled = []

    for job_id, deadline, profit in sorted_jobs:
        # Find latest available slot
        slot = uf.find(deadline)

        if slot > 0:  # Valid slot found
            slots[slot] = job_id
            uf.union(slot)  # Mark as used
            total_profit += profit
            scheduled.append(job_id)

    return total_profit, scheduled


def job_sequencing_with_penalty(
    jobs: List[Tuple[str, int, int]]
) -> Tuple[int, List[str], int]:
    """
    Variation: Minimize penalty for missed deadlines.

    Instead of maximizing profit, minimize penalty for jobs not completed.

    Strategy: Same as maximizing profit!
    - Sort by penalty descending
    - Schedule high-penalty jobs first
    - Total penalty = sum of penalties for unscheduled jobs

    Returns:
        (total_penalty, scheduled_jobs, missed_penalty)
    """
    if not jobs:
        return 0, [], 0

    sorted_jobs = sorted(jobs, key=lambda x: x[2], reverse=True)
    max_deadline = max(job[1] for job in jobs)
    slots = [None] * (max_deadline + 1)

    scheduled = []
    missed_penalty = 0

    for job_id, deadline, penalty in sorted_jobs:
        scheduled_job = False
        for slot in range(deadline, 0, -1):
            if slots[slot] is None:
                slots[slot] = job_id
                scheduled.append(job_id)
                scheduled_job = True
                break

        if not scheduled_job:
            missed_penalty += penalty

    return missed_penalty, scheduled, missed_penalty


# =============================================================================
# COMPARISON: Greedy vs Brute Force
# =============================================================================

def job_sequencing_brute_force(jobs: List[Tuple[str, int, int]]) -> Tuple[int, List[str]]:
    """
    Brute force - try all permutations.

    Time: O(n! * n * d) - Factorial!

    Only use for verification on small inputs.
    """
    from itertools import permutations

    if not jobs:
        return 0, []

    max_profit = 0
    best_schedule = []
    max_deadline = max(job[1] for job in jobs)

    for perm in permutations(jobs):
        slots = [None] * (max_deadline + 1)
        profit = 0
        schedule = []

        for job_id, deadline, job_profit in perm:
            for slot in range(deadline, 0, -1):
                if slots[slot] is None:
                    slots[slot] = job_id
                    profit += job_profit
                    schedule.append(job_id)
                    break

        if profit > max_profit:
            max_profit = profit
            best_schedule = schedule

    return max_profit, best_schedule


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Comprehensive test cases with explanations."""

    print("=" * 60)
    print("JOB SEQUENCING PROBLEM - TEST CASES")
    print("=" * 60)

    # Test 1: Classic example
    print("\nTest 1: Classic Example")
    print("-" * 40)
    jobs = [('J1', 2, 100), ('J2', 1, 19), ('J3', 2, 27), ('J4', 1, 25), ('J5', 3, 15)]

    profit, scheduled = job_sequencing_basic(jobs)
    print(f"Jobs: {jobs}")
    print(f"Scheduled: {scheduled}")
    print(f"Total Profit: ${profit}")

    # Verify with brute force
    bf_profit, bf_scheduled = job_sequencing_brute_force(jobs)
    print(f"Brute force profit: ${bf_profit}")
    assert profit == bf_profit, f"Mismatch: greedy={profit}, brute={bf_profit}"
    print("Greedy matches brute force!")

    # Test 2: All same deadline
    print("\nTest 2: All Same Deadline")
    print("-" * 40)
    jobs = [('A', 2, 50), ('B', 2, 40), ('C', 2, 30), ('D', 2, 20)]

    profit, scheduled = job_sequencing_basic(jobs)
    print(f"Jobs (all deadline 2): {jobs}")
    print(f"Scheduled: {scheduled}")
    print(f"Total Profit: ${profit}")
    assert profit == 90, f"Expected 90 (A+B), got {profit}"

    # Test 3: Single job
    print("\nTest 3: Single Job")
    print("-" * 40)
    jobs = [('Only', 5, 100)]

    profit, scheduled = job_sequencing_basic(jobs)
    print(f"Single job: {jobs}")
    print(f"Profit: ${profit}")
    assert profit == 100

    # Test 4: Test optimized version
    print("\nTest 4: Optimized (Union-Find) vs Basic")
    print("-" * 40)
    jobs = [
        ('J1', 4, 20), ('J2', 1, 10), ('J3', 4, 40),
        ('J4', 1, 30), ('J5', 3, 50), ('J6', 2, 15)
    ]

    basic_profit, basic_sched = job_sequencing_basic(jobs)
    opt_profit, opt_sched = job_sequencing_optimized(jobs)

    print(f"Jobs: {jobs}")
    print(f"Basic: profit=${basic_profit}, jobs={basic_sched}")
    print(f"Optimized: profit=${opt_profit}, jobs={opt_sched}")
    assert basic_profit == opt_profit, "Basic and optimized should match!"

    # Test 5: Complete schedule
    print("\nTest 5: Complete Schedule with Slots")
    print("-" * 40)
    jobs = [('J1', 2, 100), ('J2', 1, 50), ('J3', 2, 10), ('J4', 1, 20), ('J5', 3, 30)]

    profit, schedule = job_sequencing_with_schedule(jobs)
    print(f"Jobs: {jobs}")
    print(f"Schedule:")
    for slot, job_id, job_profit in schedule:
        print(f"  Slot {slot}: {job_id} (${job_profit})")
    print(f"Total Profit: ${profit}")

    # Test 6: Empty input
    print("\nTest 6: Empty Input")
    print("-" * 40)
    profit, scheduled = job_sequencing_basic([])
    print(f"Empty jobs list")
    print(f"Profit: ${profit}, Scheduled: {scheduled}")
    assert profit == 0 and scheduled == []

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_greedy_choice():
    """Step-by-step demonstration of the greedy algorithm."""

    print("\n" + "=" * 60)
    print("DEMONSTRATION: WHY GREEDY WORKS")
    print("=" * 60)

    jobs = [
        ('J1', 2, 100),  # High profit, deadline 2
        ('J2', 1, 19),   # Low profit, deadline 1
        ('J3', 2, 27),   # Medium profit, deadline 2
        ('J4', 1, 25),   # Medium profit, deadline 1
        ('J5', 3, 15)    # Low profit, deadline 3
    ]

    print("\nOriginal jobs:")
    for job_id, deadline, profit in jobs:
        print(f"  {job_id}: deadline={deadline}, profit=${profit}")

    # Sort by profit
    sorted_jobs = sorted(jobs, key=lambda x: x[2], reverse=True)

    print("\nAfter sorting by PROFIT (descending):")
    for job_id, deadline, profit in sorted_jobs:
        print(f"  {job_id}: profit=${profit}, deadline={deadline}")

    print("\n" + "-" * 40)
    print("GREEDY SCHEDULING PROCESS:")
    print("-" * 40)

    max_deadline = max(job[1] for job in jobs)
    slots = [None] * (max_deadline + 1)
    total_profit = 0

    for job_id, deadline, profit in sorted_jobs:
        print(f"\nProcessing {job_id} (profit=${profit}, deadline={deadline}):")
        print(f"  Current slots: {slots[1:]}")

        assigned = False
        for slot in range(deadline, 0, -1):
            print(f"  Trying slot {slot}...", end=" ")
            if slots[slot] is None:
                slots[slot] = job_id
                total_profit += profit
                assigned = True
                print(f"AVAILABLE! Assigned {job_id}")
                break
            else:
                print(f"TAKEN by {slots[slot]}")

        if not assigned:
            print(f"  No slot available - {job_id} REJECTED")

        print(f"  Slots after: {slots[1:]}")
        print(f"  Running profit: ${total_profit}")

    print("\n" + "-" * 40)
    print(f"FINAL SCHEDULE: {[s for s in slots[1:] if s]}")
    print(f"TOTAL PROFIT: ${total_profit}")

    print("\nWHY LATEST SLOT FIRST?")
    print("-" * 40)
    print("Consider J1 (deadline=2, profit=$100):")
    print("  - If we put J1 in slot 1: slot 2 is free, but J4/J2 can't use it")
    print("  - If we put J1 in slot 2: slot 1 stays free for J4/J2")
    print("By always using the latest valid slot, we maximize flexibility!")


if __name__ == "__main__":
    run_tests()
    demonstrate_greedy_choice()
