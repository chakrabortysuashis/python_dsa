"""
Smallest Number with Given Digit Sum and Digits - Greedy Algorithm
===================================================================

Problem: Find smallest M-digit number with digit sum S.

WHY GREEDY WORKS:
-----------------
1. To minimize number, put smallest digits on the left
2. Fill positions from right with 9s first (use up sum)
3. Remainder goes to leftmost positions

GREEDY STRATEGY: Build from right with 9s, adjust left for remainder.
"""

from typing import Union


def smallest_number(S: int, M: int) -> Union[str, int]:
    """
    Find smallest M-digit number with digit sum S.

    Time: O(M)
    Space: O(M)

    Example:
    >>> smallest_number(9, 2)
    '18'
    >>> smallest_number(20, 3)
    '299'
    """
    # Impossible cases
    if S > 9 * M:
        return "impossible"
    if M > 1 and S == 0:
        return "impossible"
    if M == 1 and S == 0:
        return "0"
    if S < 1:
        return "impossible"

    result = [0] * M

    # Fill from right with 9s
    remaining = S
    for i in range(M - 1, -1, -1):
        if remaining > 9:
            result[i] = 9
            remaining -= 9
        else:
            result[i] = remaining
            remaining = 0

    # Handle leading zero
    if result[0] == 0:
        result[0] = 1
        # Find rightmost non-9 and decrement
        for i in range(M - 1, 0, -1):
            if result[i] > 0:
                result[i] -= 1
                break

    return ''.join(map(str, result))


def largest_number(S: int, M: int) -> Union[str, int]:
    """
    Find largest M-digit number with digit sum S.

    Strategy: Put largest digits on the left.
    """
    if S > 9 * M:
        return "impossible"
    if M > 1 and S == 0:
        return "impossible"

    result = []
    remaining = S

    for _ in range(M):
        digit = min(9, remaining)
        result.append(digit)
        remaining -= digit

    return ''.join(map(str, result))


def run_tests():
    print("=" * 50)
    print("SMALLEST NUMBER DIGITS SUM - TEST CASES")
    print("=" * 50)

    # Test 1
    print("\nTest 1: S=9, M=2")
    result = smallest_number(9, 2)
    print(f"Result: {result}")
    assert result == "18"

    # Test 2
    print("\nTest 2: S=20, M=3")
    result = smallest_number(20, 3)
    print(f"Result: {result}")
    assert result == "299"

    # Test 3
    print("\nTest 3: S=5, M=3")
    result = smallest_number(5, 3)
    print(f"Result: {result}")
    assert result == "104"

    # Test 4: Impossible
    print("\nTest 4: S=100, M=2 (impossible)")
    result = smallest_number(100, 2)
    print(f"Result: {result}")
    assert result == "impossible"

    # Test 5: Single digit
    print("\nTest 5: S=7, M=1")
    result = smallest_number(7, 1)
    print(f"Result: {result}")
    assert result == "7"

    # Test 6: Compare with largest
    print("\nTest 6: Smallest vs Largest (S=15, M=3)")
    small = smallest_number(15, 3)
    large = largest_number(15, 3)
    print(f"Smallest: {small}")
    print(f"Largest: {large}")

    print("\nALL TESTS PASSED!")


if __name__ == "__main__":
    run_tests()
