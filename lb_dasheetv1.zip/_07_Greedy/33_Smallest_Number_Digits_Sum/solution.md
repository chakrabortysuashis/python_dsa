# Smallest Number with Given Digit Sum and Number of Digits

## Problem Statement

Find the smallest number with exactly M digits whose digits sum to S.

**Input:** 
- S: Required digit sum
- M: Number of digits

**Output:** Smallest such number, or "impossible"

**Example:**
```
Input: S=9, M=2
Output: 18 (1+8=9, smallest 2-digit number with sum 9)

Input: S=20, M=3
Output: 299 (2+9+9=20)
```

---

## Why Greedy Works Here

### The Greedy Choice Property

**Claim:** To get the smallest number:
1. Put the smallest possible digit at each position from left to right
2. Fill remaining positions with 9s from right

### Algorithm

1. Start with all 9s from the right
2. Adjust the leftmost digits to make sum = S
3. Ensure no leading zeros

---

## Algorithm

```python
def smallest_number(S, M):
    # Check impossible cases
    if S > 9 * M:  # Can't reach sum
        return "impossible"
    if S < 1 and M > 1:  # Leading zero issue
        return "impossible"
    if S == 0 and M == 1:
        return "0"
    
    result = [0] * M
    
    # Fill from right with 9s
    for i in range(M - 1, -1, -1):
        if S > 9:
            result[i] = 9
            S -= 9
        else:
            result[i] = S
            S = 0
    
    # Ensure no leading zero
    if result[0] == 0:
        # Borrow from next position
        for i in range(1, M):
            if result[i] > 0:
                result[0] = 1
                result[i] -= 1
                break
    
    return ''.join(map(str, result))
```

---

## Time Complexity

O(M) - single pass through digits
