"""
Maximize Sum of arr[i] * i - Greedy Algorithm
==============================================

Problem: Given an array of n integers, rearrange the elements to maximize
the sum of arr[i] * i for all i from 0 to n-1.

WHY GREEDY WORKS:
----------------
This is a direct application of the Rearrangement Inequality:
- We have two sequences: values (arr) and multipliers (indices 0,1,2,...,n-1)
- To maximize sum of products, pair them in the same sorted order
- Sort arr ascending so larger values get larger indices (larger multipliers)

EXCHANGE ARGUMENT:
If arr[i] > arr[j] but i < j, swapping them gives:
- Change = (arr[i] - arr[j]) * (j - i) > 0 (both factors positive)
- So swapping increases the sum, meaning optimal has larger values later

GREEDY STRATEGY: Simply sort the array in ascending order!
"""

from typing import List, Tuple
from itertools import permutations


def maximize_sum_product(arr: List[int]) -> int:
    """
    Maximize sum of arr[i] * i by rearranging elements.

    Greedy insight: Sort ascending so larger values get higher indices.

    Time: O(n log n) for sorting
    Space: O(n) for sorted copy

    Example:
    >>> maximize_sum_product([1, 2, 3, 4])
    20
    >>> maximize_sum_product([4, 3, 2, 1])
    20
    >>> maximize_sum_product([5, 3, 2, 4, 1])
    40
    """
    # Sort in ascending order
    sorted_arr = sorted(arr)

    # Calculate weighted sum
    total = sum(sorted_arr[i] * i for i in range(len(sorted_arr)))

    return total


def maximize_sum_product_in_place(arr: List[int]) -> int:
    """
    In-place version (modifies original array).

    Time: O(n log n)
    Space: O(1) for the sort (depends on implementation)

    Example:
    >>> arr = [4, 3, 2, 1]
    >>> maximize_sum_product_in_place(arr)
    20
    >>> arr
    [1, 2, 3, 4]
    """
    arr.sort()
    return sum(arr[i] * i for i in range(len(arr)))


def maximize_sum_product_with_arrangement(
    arr: List[int]
) -> Tuple[int, List[int], int]:
    """
    Returns (max_sum, optimal_arrangement, original_sum).

    Example:
    >>> max_sum, arrangement, orig_sum = maximize_sum_product_with_arrangement([5, 3, 2, 4, 1])
    >>> max_sum
    40
    >>> arrangement
    [1, 2, 3, 4, 5]
    """
    original_sum = sum(arr[i] * i for i in range(len(arr)))
    sorted_arr = sorted(arr)
    max_sum = sum(sorted_arr[i] * i for i in range(len(sorted_arr)))

    return max_sum, sorted_arr, original_sum


def maximize_sum_product_detailed(arr: List[int]) -> dict:
    """
    Detailed analysis showing contribution of each element.

    Returns dict with:
    - original_sum: sum with original arrangement
    - optimal_sum: sum with sorted arrangement
    - improvement: difference
    - original_contributions: list of (value, index, product) for original
    - optimal_contributions: list of (value, index, product) for sorted
    """
    n = len(arr)
    sorted_arr = sorted(arr)

    original_contributions = [(arr[i], i, arr[i] * i) for i in range(n)]
    optimal_contributions = [(sorted_arr[i], i, sorted_arr[i] * i) for i in range(n)]

    original_sum = sum(c[2] for c in original_contributions)
    optimal_sum = sum(c[2] for c in optimal_contributions)

    return {
        'original_array': arr,
        'sorted_array': sorted_arr,
        'original_sum': original_sum,
        'optimal_sum': optimal_sum,
        'improvement': optimal_sum - original_sum,
        'original_contributions': original_contributions,
        'optimal_contributions': optimal_contributions
    }


def maximize_sum_product_mod(arr: List[int], mod: int) -> int:
    """
    Maximize sum modulo M (for handling large numbers).

    Time: O(n log n)
    Space: O(n)

    Example:
    >>> maximize_sum_product_mod([1, 2, 3, 4], 10)
    0  # 20 % 10 = 0
    """
    sorted_arr = sorted(arr)
    total = 0
    for i in range(len(sorted_arr)):
        total = (total + (sorted_arr[i] * i) % mod) % mod
    return total


# =============================================================================
# BRUTE FORCE COMPARISON
# =============================================================================

def maximize_sum_product_brute(arr: List[int]) -> int:
    """
    Brute force: Try all n! permutations.

    Time: O(n! * n)
    Space: O(n)

    Only for verification on small inputs (n <= 8).
    """
    max_sum = float('-inf')

    for perm in permutations(arr):
        current_sum = sum(perm[i] * i for i in range(len(perm)))
        max_sum = max(max_sum, current_sum)

    return max_sum


# =============================================================================
# VARIATIONS
# =============================================================================

def minimize_sum_product(arr: List[int]) -> int:
    """
    MINIMIZE sum of arr[i] * i.

    Opposite strategy: Sort in descending order!
    Pair largest values with smallest indices.

    Example:
    >>> minimize_sum_product([1, 2, 3, 4])
    10
    """
    sorted_arr = sorted(arr, reverse=True)
    return sum(sorted_arr[i] * i for i in range(len(sorted_arr)))


def maximize_sum_product_two_arrays(a: List[int], b: List[int]) -> int:
    """
    Given two arrays of same length, pair elements to maximize sum of products.

    Strategy: Sort both in same order (both ascending or both descending).

    Example:
    >>> maximize_sum_product_two_arrays([1, 2, 3], [4, 5, 6])
    32  # 3*6 + 2*5 + 1*4 = 18+10+4 = 32
    """
    a_sorted = sorted(a)
    b_sorted = sorted(b)
    return sum(a_sorted[i] * b_sorted[i] for i in range(len(a)))


def minimize_sum_product_two_arrays(a: List[int], b: List[int]) -> int:
    """
    Pair elements to MINIMIZE sum of products.

    Strategy: Sort one ascending, other descending.

    Example:
    >>> minimize_sum_product_two_arrays([1, 2, 3], [4, 5, 6])
    28  # 1*6 + 2*5 + 3*4 = 6+10+12 = 28
    """
    a_sorted = sorted(a)
    b_sorted = sorted(b, reverse=True)
    return sum(a_sorted[i] * b_sorted[i] for i in range(len(a)))


def maximize_with_weighted_indices(arr: List[int], weights: List[int]) -> int:
    """
    Maximize sum of arr[i] * weights[i] where weights are arbitrary.

    Strategy: Sort by weights, pair largest arr values with largest weights.

    Example:
    >>> arr = [1, 2, 3]
    >>> weights = [10, 1, 5]  # Indices by weight: 0 (w=10), 2 (w=5), 1 (w=1)
    >>> maximize_with_weighted_indices(arr, weights)
    38  # 3*10 + 2*5 + 1*1 = 30+10+1-3 = 38? Let me recalculate...
    # Actually: pair 3 with 10, 2 with 5, 1 with 1 = 30+10+1 = 41
    41
    """
    n = len(arr)
    # Sort arr descending, weights descending, pair them
    sorted_arr = sorted(arr, reverse=True)
    sorted_weights = sorted(weights, reverse=True)

    return sum(sorted_arr[i] * sorted_weights[i] for i in range(n))


def maximize_sum_squared_indices(arr: List[int]) -> int:
    """
    Maximize sum of arr[i] * i^2 (quadratic weights).

    Same principle: larger values should get larger multipliers.
    Multipliers are 0, 1, 4, 9, 16, ... (squares)

    Example:
    >>> maximize_sum_squared_indices([1, 2, 3, 4])
    50  # 1*0 + 2*1 + 3*4 + 4*9 = 0+2+12+36 = 50
    """
    sorted_arr = sorted(arr)
    return sum(sorted_arr[i] * (i ** 2) for i in range(len(sorted_arr)))


def count_optimal_arrangements(arr: List[int]) -> int:
    """
    Count number of arrangements that achieve maximum sum.

    Multiple arrangements can be optimal when there are duplicate values.

    Example:
    >>> count_optimal_arrangements([1, 1, 2, 3])
    2  # [1,1,2,3] and [1,1,2,3] (the two 1s can swap)
    """
    from math import factorial
    from collections import Counter

    # Count duplicates
    counts = Counter(arr)

    # Number of ways = product of factorials of counts
    ways = 1
    for count in counts.values():
        ways *= factorial(count)

    return ways


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Comprehensive test cases with explanations."""

    print("=" * 60)
    print("MAXIMIZE SUM OF arr[i] * i - TEST CASES")
    print("=" * 60)

    # Test 1: Basic example
    print("\nTest 1: Basic Example")
    print("-" * 40)
    arr = [1, 2, 3, 4]
    result = maximize_sum_product(arr)
    print(f"Array: {arr}")
    print(f"Maximum sum: {result}")
    print(f"Calculation: 1*0 + 2*1 + 3*2 + 4*3 = 0+2+6+12 = 20")
    assert result == 20, f"Expected 20, got {result}"

    # Test 2: Unsorted input
    print("\nTest 2: Unsorted Input")
    print("-" * 40)
    arr = [4, 3, 2, 1]
    result = maximize_sum_product(arr)
    print(f"Array: {arr}")
    print(f"Maximum sum: {result}")
    print(f"After sorting: [1, 2, 3, 4] gives same result")
    assert result == 20, f"Expected 20, got {result}"

    # Test 3: Mixed values
    print("\nTest 3: Mixed Values")
    print("-" * 40)
    arr = [5, 3, 2, 4, 1]
    result = maximize_sum_product(arr)
    max_sum, sorted_arr, orig_sum = maximize_sum_product_with_arrangement(arr)
    print(f"Original array: {arr}")
    print(f"Sorted array: {sorted_arr}")
    print(f"Original sum: {orig_sum}")
    print(f"Maximum sum: {max_sum}")
    print(f"Improvement: {max_sum - orig_sum}")

    # Test 4: With negative values
    print("\nTest 4: With Negative Values")
    print("-" * 40)
    arr = [-5, -1, 0, 2, 3]
    result = maximize_sum_product(arr)
    print(f"Array: {arr}")
    print(f"Maximum sum: {result}")
    print(f"Note: Negatives at low indices minimize their impact")

    # Test 5: All same values
    print("\nTest 5: All Same Values")
    print("-" * 40)
    arr = [3, 3, 3, 3]
    result = maximize_sum_product(arr)
    print(f"Array: {arr}")
    print(f"Maximum sum: {result}")
    print(f"Any arrangement gives same result: 3*(0+1+2+3) = 18")
    assert result == 18

    # Test 6: Single element
    print("\nTest 6: Single Element")
    print("-" * 40)
    arr = [5]
    result = maximize_sum_product(arr)
    print(f"Array: {arr}")
    print(f"Maximum sum: {result}")
    print(f"5 * 0 = 0")
    assert result == 0

    # Test 7: Compare with brute force
    print("\nTest 7: Greedy vs Brute Force")
    print("-" * 40)
    arr = [5, 2, 8, 1, 4]
    greedy = maximize_sum_product(arr)
    brute = maximize_sum_product_brute(arr)
    print(f"Array: {arr}")
    print(f"Greedy: {greedy}")
    print(f"Brute force: {brute}")
    assert greedy == brute, "Should match!"

    # Test 8: Detailed analysis
    print("\nTest 8: Detailed Analysis")
    print("-" * 40)
    arr = [5, 3, 2, 4, 1]
    details = maximize_sum_product_detailed(arr)
    print(f"Original: {details['original_array']}")
    print(f"Sorted: {details['sorted_array']}")
    print(f"Original sum: {details['original_sum']}")
    print(f"Optimal sum: {details['optimal_sum']}")
    print(f"Improvement: +{details['improvement']}")
    print("\nContributions (value, index, product):")
    print(f"  Original: {details['original_contributions']}")
    print(f"  Optimal:  {details['optimal_contributions']}")

    # Test 9: Minimize sum
    print("\nTest 9: Minimize Sum (Variation)")
    print("-" * 40)
    arr = [1, 2, 3, 4]
    max_result = maximize_sum_product(arr)
    min_result = minimize_sum_product(arr)
    print(f"Array: {arr}")
    print(f"Maximum sum: {max_result}")
    print(f"Minimum sum: {min_result}")
    print(f"Range: {max_result - min_result}")

    # Test 10: Two arrays
    print("\nTest 10: Two Arrays Pairing")
    print("-" * 40)
    a = [1, 2, 3]
    b = [4, 5, 6]
    max_prod = maximize_sum_product_two_arrays(a, b)
    min_prod = minimize_sum_product_two_arrays(a, b)
    print(f"Array A: {a}")
    print(f"Array B: {b}")
    print(f"Max sum of products: {max_prod}")
    print(f"Min sum of products: {min_prod}")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_greedy_choice():
    """Visual demonstration of why sorting works."""

    print("\n" + "=" * 60)
    print("DEMONSTRATION: WHY SORTING MAXIMIZES THE SUM")
    print("=" * 60)

    arr = [5, 3, 2, 4, 1]

    print(f"\nOriginal array: {arr}")

    # Show original calculation
    print("\n1. Original Arrangement:")
    print("-" * 50)
    print("Index:   ", end="")
    for i in range(len(arr)):
        print(f"{i:6}", end="")
    print()
    print("Value:   ", end="")
    for v in arr:
        print(f"{v:6}", end="")
    print()
    print("Product: ", end="")
    for i, v in enumerate(arr):
        print(f"{v*i:6}", end="")
    print()

    original_sum = sum(arr[i] * i for i in range(len(arr)))
    print(f"\nSum = {' + '.join(f'{arr[i]}*{i}' for i in range(len(arr)))} = {original_sum}")

    # Sort and show new calculation
    sorted_arr = sorted(arr)

    print("\n2. After Sorting (Optimal):")
    print("-" * 50)
    print("Index:   ", end="")
    for i in range(len(sorted_arr)):
        print(f"{i:6}", end="")
    print()
    print("Value:   ", end="")
    for v in sorted_arr:
        print(f"{v:6}", end="")
    print()
    print("Product: ", end="")
    for i, v in enumerate(sorted_arr):
        print(f"{v*i:6}", end="")
    print()

    optimal_sum = sum(sorted_arr[i] * i for i in range(len(sorted_arr)))
    print(f"\nSum = {' + '.join(f'{sorted_arr[i]}*{i}' for i in range(len(sorted_arr)))} = {optimal_sum}")

    print("\n3. Why This is Optimal:")
    print("-" * 50)
    print(f"Improvement: {original_sum} -> {optimal_sum} (+{optimal_sum - original_sum})")
    print()
    print("Key insight:")
    print("- Smallest value (1) gets index 0 (contributes 0)")
    print("- Largest value (5) gets index 4 (contributes 20)")
    print("- Each value is multiplied by the best possible multiplier!")

    print("\n4. Exchange Argument:")
    print("-" * 50)
    print("If we had 5 at index 0 and 1 at index 4:")
    print("  5*0 + 1*4 = 0 + 4 = 4")
    print("With optimal (1 at 0, 5 at 4):")
    print("  1*0 + 5*4 = 0 + 20 = 20")
    print("Difference: +16 (by swapping)")


if __name__ == "__main__":
    run_tests()
    demonstrate_greedy_choice()
