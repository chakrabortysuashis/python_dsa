# Maximize Sum of arr[i] * i

## Problem Statement

Given an array of `n` integers, rearrange the elements to maximize the sum of `arr[i] * i` for all `i` from `0` to `n-1`.

**Input:**
- `arr[]` - Array of n integers

**Output:** Maximum possible value of sum(arr[i] * i)

**Example:**
```
Input: arr = [1, 2, 3, 4]
Output: 20

Explanation:
- Optimal arrangement: [1, 2, 3, 4] (already sorted)
- Sum = 1*0 + 2*1 + 3*2 + 4*3 = 0 + 2 + 6 + 12 = 20
```

---

## Why Greedy Works Here

### The Greedy Choice Property

**Claim:** To maximize sum(arr[i] * i), place larger elements at higher indices.

**Intuition:**
- Index i acts as a "multiplier" for the element placed there
- Higher indices have larger multipliers
- To maximize total, pair larger elements with larger multipliers
- This is the "rearrangement inequality" in action

### Mathematical Proof (Rearrangement Inequality)

For two sequences `a1 <= a2 <= ... <= an` and `b1 <= b2 <= ... <= bn`:
- Maximum sum of products: pair in same order (largest with largest)
- Minimum sum of products: pair in reverse order (largest with smallest)

Here:
- Elements: arr values (can be sorted)
- Multipliers: indices 0, 1, 2, ..., n-1 (already sorted)

### Exchange Argument Proof

1. Suppose optimal arrangement has `arr[i] > arr[j]` where `i < j`
2. Consider swapping: new sum differs by:
   - Old contribution: `arr[i] * i + arr[j] * j`
   - New contribution: `arr[j] * i + arr[i] * j`
   - Difference: `arr[i] * j + arr[j] * i - (arr[i] * i + arr[j] * j)`
   - = `arr[i] * (j - i) + arr[j] * (i - j)`
   - = `(arr[i] - arr[j]) * (j - i)`
3. Since `arr[i] > arr[j]` and `i < j`:
   - `(arr[i] - arr[j]) > 0` and `(j - i) > 0`
   - Product is positive, meaning new sum is LARGER
4. Contradiction! So optimal must have larger values at higher indices.

---

## Step-by-Step Algorithm

### Algorithm:

```
1. SORT array in ascending order
2. CALCULATE sum = arr[0]*0 + arr[1]*1 + ... + arr[n-1]*(n-1)
3. RETURN sum
```

### That's it!

The entire algorithm is just sorting and computing the weighted sum. The greedy insight tells us that sorting gives the optimal arrangement.

---

## Brute Force Comparison

### Brute Force Approach
Try all n! permutations, calculate sum for each, return maximum.

```python
from itertools import permutations

def brute_force(arr):
    max_sum = float('-inf')
    
    for perm in permutations(arr):
        current_sum = sum(perm[i] * i for i in range(len(perm)))
        max_sum = max(max_sum, current_sum)
    
    return max_sum
```

**Time Complexity:** O(n! * n)
**Space Complexity:** O(n) for permutation

### Why Brute Force is Impractical
- For n=10: 10! = 3,628,800 permutations
- For n=15: 15! = 1.3 trillion permutations
- Factorial growth is even worse than exponential!

---

## Optimal Greedy Approach

```python
def maximize_sum_product(arr):
    """
    Maximize sum of arr[i] * i by rearranging elements.
    
    Greedy insight: Sort ascending so larger values get higher indices.
    
    Time: O(n log n) for sorting
    Space: O(1) if sorting in place
    
    Example:
    >>> maximize_sum_product([1, 2, 3, 4])
    20
    >>> maximize_sum_product([4, 3, 2, 1])
    20
    """
    # Sort in ascending order
    arr_sorted = sorted(arr)
    
    # Calculate weighted sum
    total = sum(arr_sorted[i] * i for i in range(len(arr_sorted)))
    
    return total
```

**Time Complexity:** O(n log n)
**Space Complexity:** O(n) for sorted copy (or O(1) if in-place)

---

## Dry Run with Selection Visualization

**Input:**
```
arr = [5, 3, 2, 4, 1]
```

**Step 1: Analyze Original Array**
```
Index:    0   1   2   3   4
Value:    5   3   2   4   1
Product:  0   3   4  12   4
Sum = 0 + 3 + 4 + 12 + 4 = 23
```

**Step 2: Sort Array**
```
Sorted: [1, 2, 3, 4, 5]
```

**Step 3: Calculate Optimal Sum**
```
Index:    0   1   2   3   4
Value:    1   2   3   4   5
Product:  0   2   6  12  20

Sum = 0 + 2 + 6 + 12 + 20 = 40
```

**Visualization:**
```
Original arrangement:
Index:   0    1    2    3    4
Value:   5    3    2    4    1
         |    |    |    |    |
         x0   x1   x2   x3   x4
         =0   =3   =4   =12  =4
                            Total: 23

Optimal arrangement (sorted):
Index:   0    1    2    3    4
Value:   1    2    3    4    5
         |    |    |    |    |
         x0   x1   x2   x3   x4
         =0   =2   =6   =12  =20
                            Total: 40
```

**Why is this optimal?**
```
- Largest value (5) is at index 4 -> contributes 5*4 = 20
- Second largest (4) is at index 3 -> contributes 4*3 = 12
- Third largest (3) is at index 2 -> contributes 3*2 = 6
- Fourth largest (2) is at index 1 -> contributes 2*1 = 2
- Smallest (1) is at index 0 -> contributes 1*0 = 0

The smallest value "wasting" index 0 (multiplier 0) is optimal!
```

---

## Time and Space Complexity

| Aspect | Complexity | Explanation |
|--------|------------|-------------|
| **Time** | O(n log n) | Dominated by sorting |
| **Space** | O(1) or O(n) | Depends on sorting implementation |

### Breakdown:
- **Sorting:** O(n log n)
- **Sum calculation:** O(n)
- **Total:** O(n log n)

---

## Edge Cases

| Case | Result |
|------|--------|
| Single element | arr[0] * 0 = 0 |
| All same values | n * value * (n-1)/2 type sum |
| All zeros | 0 |
| Negative values | Still sort ascending! |
| Mix of positive/negative | Negative at low indices, positive at high |

### Handling Negatives:
```
arr = [-5, -1, 0, 2, 3]
Sorted (ascending): [-5, -1, 0, 2, 3]

Index:    0    1    2   3    4
Value:   -5   -1    0   2    3
Product:  0   -1    0   6   12

Sum = 0 + (-1) + 0 + 6 + 12 = 17

Why this is optimal:
- Most negative value (-5) gets index 0 (contributes 0)
- Second most negative (-1) gets index 1 (contributes -1)
- Larger positive values get higher indices (maximized contribution)
```

---

## Variations and Extensions

### 1. Minimize Sum of arr[i] * i
Sort in descending order instead!
```python
def minimize_sum_product(arr):
    arr_sorted = sorted(arr, reverse=True)
    return sum(arr_sorted[i] * i for i in range(len(arr_sorted)))
```

### 2. Maximize with Fixed Positions
Some positions are fixed, optimize the rest.

### 3. Maximize with Constraints
Can only swap adjacent elements, limited swaps.

### 4. Two Arrays Pairing
Given two arrays A and B, pair elements to maximize sum of products.
- Sort A ascending, B ascending, pair in same order

### 5. Weighted Index Problem
Indices have arbitrary weights w[i] instead of i.
- Sort by weight, place largest elements at highest weight positions

### 6. Modular Arithmetic
Compute sum modulo M to handle large numbers.
```python
def maximize_sum_product_mod(arr, mod):
    arr_sorted = sorted(arr)
    total = 0
    for i in range(len(arr_sorted)):
        total = (total + arr_sorted[i] * i) % mod
    return total
```
