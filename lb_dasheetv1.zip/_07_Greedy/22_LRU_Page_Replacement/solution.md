# LRU Page Replacement Algorithm

## Problem Statement

Given a sequence of page requests and a fixed number of page frames (cache size), simulate the LRU (Least Recently Used) page replacement algorithm and count the number of page faults.

**Input:** 
- `pages[]` - Sequence of page requests
- `capacity` - Number of page frames available

**Output:** Number of page faults (cache misses)

**Example:**
```
Input: pages = [7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0, 1]
       capacity = 3
Output: 12 page faults
```

---

## Why Greedy Works Here

### The Greedy Choice Property

**Claim:** When cache is full and we need to evict a page, evicting the Least Recently Used page minimizes future misses (in many practical workloads).

**Intuition:**
- Temporal locality: recently used pages are likely to be used again soon
- Pages not used recently are less likely to be needed soon
- LRU exploits this pattern greedily

### Note on Optimality

LRU is NOT always optimal! The optimal algorithm (Belady's MIN) looks into the future and evicts the page that won't be needed for the longest time. However:
- LRU is a practical greedy heuristic
- Works well with temporal locality
- Doesn't require knowledge of future requests

### Exchange Argument (Heuristic Justification)

1. Consider evicting page A (recently used) vs page B (least recently used)
2. Temporal locality suggests A is more likely to be needed soon
3. Evicting A would likely cause an immediate page fault
4. Evicting B (LRU) delays the next fault as long as possible
5. Therefore, LRU is a good greedy choice

---

## Step-by-Step Algorithm

### Algorithm:

```
1. INITIALIZE empty cache (set of pages) and access order tracking
2. FOR each page request:
   a. IF page in cache:
      - UPDATE its "last used" time (move to front)
   b. ELSE (page fault):
      - IF cache is full:
        - FIND least recently used page
        - EVICT it
      - ADD new page to cache
      - INCREMENT fault count
3. RETURN fault count
```

### Data Structures:

1. **OrderedDict:** Maintains insertion order, can move to end on access
2. **Doubly Linked List + HashMap:** O(1) operations
3. **Simple List:** Track order, O(n) removal

---

## Implementation Approaches

### 1. Using OrderedDict (Python)
```python
from collections import OrderedDict

def lru_page_faults(pages, capacity):
    cache = OrderedDict()
    faults = 0
    
    for page in pages:
        if page in cache:
            cache.move_to_end(page)  # Mark as recently used
        else:
            faults += 1
            if len(cache) >= capacity:
                cache.popitem(last=False)  # Remove LRU (first item)
            cache[page] = True
    
    return faults
```

### 2. Using HashMap + Doubly Linked List
```python
class LRUCache:
    def __init__(self, capacity):
        self.capacity = capacity
        self.cache = {}  # page -> node
        self.head = Node(0)  # Dummy head (most recent)
        self.tail = Node(0)  # Dummy tail (least recent)
        self.head.next = self.tail
        self.tail.prev = self.head
```

---

## Dry Run with Visualization

**Input:** `pages = [7, 0, 1, 2, 0, 3], capacity = 3`

```
Request 7: Cache = []
           FAULT! Add 7
           Cache = [7]

Request 0: Cache = [7]
           FAULT! Add 0
           Cache = [7, 0]

Request 1: Cache = [7, 0]
           FAULT! Add 1
           Cache = [7, 0, 1]

Request 2: Cache = [7, 0, 1] (full)
           FAULT! Evict LRU (7), Add 2
           Cache = [0, 1, 2]

Request 0: Cache = [0, 1, 2]
           HIT! Move 0 to end
           Cache = [1, 2, 0]

Request 3: Cache = [1, 2, 0] (full)
           FAULT! Evict LRU (1), Add 3
           Cache = [2, 0, 3]

Total faults: 5
```

---

## Time and Space Complexity

| Approach | Access | Eviction | Space |
|----------|--------|----------|-------|
| OrderedDict | O(1) | O(1) | O(capacity) |
| List-based | O(n) | O(n) | O(capacity) |
| DLL + HashMap | O(1) | O(1) | O(capacity) |

---

## Comparison with Other Algorithms

| Algorithm | Strategy | Optimal? | Future Knowledge? |
|-----------|----------|----------|-------------------|
| **LRU** | Evict least recently used | No | No |
| **FIFO** | Evict oldest page | No | No |
| **OPT/MIN** | Evict page used farthest in future | Yes | Yes |
| **MRU** | Evict most recently used | No | No |
| **LFU** | Evict least frequently used | No | No |

---

## Variations

### 1. LRU-K
Consider the K-th most recent access instead of just the last one.

### 2. Segmented LRU
Divide cache into segments with different policies.

### 3. Pseudo-LRU
Approximate LRU with less overhead (used in hardware).

### 4. Clock Algorithm
Circular buffer approximation of LRU.

---

## Real-World Applications

1. **CPU Cache:** Hardware LRU approximations
2. **Operating Systems:** Page replacement in virtual memory
3. **Databases:** Buffer pool management
4. **Web Browsers:** Page cache
5. **CDNs:** Content caching
