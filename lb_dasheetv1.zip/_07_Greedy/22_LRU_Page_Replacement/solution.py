"""
LRU Page Replacement Algorithm - Greedy Heuristic
==================================================

Problem: Given a sequence of page requests and cache capacity, simulate
LRU page replacement and count page faults.

WHY GREEDY (LRU) WORKS:
-----------------------
1. Greedy Choice: When evicting, choose the Least Recently Used page.
   This exploits temporal locality - recently used pages are likely
   to be used again soon.

2. Heuristic Nature: LRU is NOT optimal (Belady's MIN is), but it's
   a practical greedy heuristic that works well for most workloads.

3. Trade-off: LRU approximates optimal by using past access patterns
   to predict future accesses. Works well when access patterns show
   temporal locality.

GREEDY STRATEGY: Always evict the page that hasn't been used for the
longest time, betting that temporal locality makes it unlikely to be
needed soon.
"""

from typing import List, Tuple
from collections import OrderedDict


def lru_page_faults(pages: List[int], capacity: int) -> int:
    """
    Count page faults using LRU replacement policy.

    Uses OrderedDict for O(1) operations:
    - Access moves item to end (most recent)
    - Eviction pops from front (least recent)

    Time: O(n) where n = number of page requests
    Space: O(capacity) for the cache

    Example:
    >>> lru_page_faults([7, 0, 1, 2, 0, 3, 0, 4], 3)
    6
    >>> lru_page_faults([1, 2, 3, 4, 1, 2, 5, 1, 2, 3, 4, 5], 3)
    10
    """
    if capacity <= 0:
        return len(pages)

    cache = OrderedDict()
    faults = 0

    for page in pages:
        if page in cache:
            # Hit: move to end (most recently used)
            cache.move_to_end(page)
        else:
            # Fault: need to load page
            faults += 1

            if len(cache) >= capacity:
                # Evict LRU (first item in OrderedDict)
                cache.popitem(last=False)

            # Add new page
            cache[page] = True

    return faults


def lru_detailed(
    pages: List[int],
    capacity: int
) -> Tuple[int, List[Tuple[int, str, List[int]]]]:
    """
    LRU with detailed step-by-step trace.

    Returns:
        Tuple of (fault_count, list of (page, action, cache_state))

    Example:
    >>> faults, trace = lru_detailed([7, 0, 1, 2, 0, 3], 3)
    >>> faults
    5
    """
    if capacity <= 0:
        return len(pages), [(p, 'FAULT', []) for p in pages]

    cache = OrderedDict()
    faults = 0
    trace = []

    for page in pages:
        if page in cache:
            cache.move_to_end(page)
            action = 'HIT'
        else:
            faults += 1
            action = 'FAULT'

            if len(cache) >= capacity:
                evicted = cache.popitem(last=False)[0]
                action = f'FAULT (evict {evicted})'

            cache[page] = True

        trace.append((page, action, list(cache.keys())))

    return faults, trace


class LRUCache:
    """
    LRU Cache implementation using doubly linked list + hashmap.

    This is the classic O(1) implementation used in production systems.
    """

    class Node:
        def __init__(self, key, val=None):
            self.key = key
            self.val = val
            self.prev = None
            self.next = None

    def __init__(self, capacity: int):
        self.capacity = capacity
        self.cache = {}  # key -> Node

        # Dummy head and tail
        self.head = self.Node(0)  # Most recent
        self.tail = self.Node(0)  # Least recent
        self.head.next = self.tail
        self.tail.prev = self.head

    def _remove(self, node):
        """Remove node from linked list."""
        node.prev.next = node.next
        node.next.prev = node.prev

    def _add_to_front(self, node):
        """Add node right after head (most recent)."""
        node.next = self.head.next
        node.prev = self.head
        self.head.next.prev = node
        self.head.next = node

    def access(self, key) -> bool:
        """
        Access a page. Returns True if hit, False if fault.
        """
        if key in self.cache:
            # Hit: move to front
            node = self.cache[key]
            self._remove(node)
            self._add_to_front(node)
            return True
        else:
            # Fault
            if len(self.cache) >= self.capacity:
                # Evict LRU (node before tail)
                lru = self.tail.prev
                self._remove(lru)
                del self.cache[lru.key]

            # Add new page
            new_node = self.Node(key)
            self._add_to_front(new_node)
            self.cache[key] = new_node
            return False

    def get_cache_state(self) -> List[int]:
        """Return current cache contents in MRU to LRU order."""
        result = []
        node = self.head.next
        while node != self.tail:
            result.append(node.key)
            node = node.next
        return result


def lru_with_class(pages: List[int], capacity: int) -> int:
    """LRU using the class-based implementation."""
    cache = LRUCache(capacity)
    faults = 0

    for page in pages:
        if not cache.access(page):
            faults += 1

    return faults


# =============================================================================
# OTHER PAGE REPLACEMENT ALGORITHMS FOR COMPARISON
# =============================================================================

def fifo_page_faults(pages: List[int], capacity: int) -> int:
    """
    FIFO (First In First Out) page replacement.

    Evicts the oldest page regardless of access pattern.
    Simpler but often worse than LRU.
    """
    if capacity <= 0:
        return len(pages)

    from collections import deque

    cache = set()
    queue = deque()  # Order of insertion
    faults = 0

    for page in pages:
        if page not in cache:
            faults += 1

            if len(cache) >= capacity:
                # Evict oldest (front of queue)
                oldest = queue.popleft()
                cache.remove(oldest)

            cache.add(page)
            queue.append(page)

    return faults


def optimal_page_faults(pages: List[int], capacity: int) -> int:
    """
    Optimal (Belady's MIN) page replacement.

    Evicts the page that won't be needed for the longest time.
    Requires knowledge of future requests - not practical but optimal.
    """
    if capacity <= 0:
        return len(pages)

    cache = set()
    faults = 0
    n = len(pages)

    for i, page in enumerate(pages):
        if page not in cache:
            faults += 1

            if len(cache) >= capacity:
                # Find page used farthest in future
                farthest = -1
                evict_page = None

                for cached_page in cache:
                    # Find next use of this page
                    try:
                        next_use = pages[i+1:].index(cached_page) + i + 1
                    except ValueError:
                        # Page never used again - evict it
                        evict_page = cached_page
                        break

                    if next_use > farthest:
                        farthest = next_use
                        evict_page = cached_page

                cache.remove(evict_page)

            cache.add(page)

    return faults


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Comprehensive test cases with explanations."""

    print("=" * 60)
    print("LRU PAGE REPLACEMENT - TEST CASES")
    print("=" * 60)

    # Test 1: Classic example
    print("\nTest 1: Classic Example")
    print("-" * 40)
    pages = [7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0, 1]
    capacity = 3
    result = lru_page_faults(pages, capacity)
    print(f"Pages: {pages[:10]}... (length {len(pages)})")
    print(f"Capacity: {capacity}")
    print(f"LRU faults: {result}")
    assert result == 12, f"Expected 12, got {result}"
    print("PASS")

    # Test 2: All hits
    print("\nTest 2: All Hits (pages fit in cache)")
    print("-" * 40)
    pages = [1, 2, 3, 1, 2, 3, 1, 2, 3]
    capacity = 3
    result = lru_page_faults(pages, capacity)
    print(f"Pages: {pages}")
    print(f"Capacity: {capacity}")
    print(f"LRU faults: {result}")
    assert result == 3, f"Expected 3, got {result}"  # Only initial loads
    print("PASS")

    # Test 3: All misses
    print("\nTest 3: All Misses (sequential unique)")
    print("-" * 40)
    pages = [1, 2, 3, 4, 5, 6, 7, 8]
    capacity = 3
    result = lru_page_faults(pages, capacity)
    print(f"Pages: {pages}")
    print(f"Capacity: {capacity}")
    print(f"LRU faults: {result}")
    assert result == 8  # All unique, all miss
    print("PASS")

    # Test 4: Detailed trace
    print("\nTest 4: Detailed Trace")
    print("-" * 40)
    pages = [7, 0, 1, 2, 0, 3]
    capacity = 3
    faults, trace = lru_detailed(pages, capacity)

    print(f"Pages: {pages}")
    print("Trace:")
    for page, action, state in trace:
        print(f"  Request {page}: {action:20} Cache: {state}")
    print(f"Total faults: {faults}")
    print("PASS")

    # Test 5: Compare implementations
    print("\nTest 5: Compare Implementations")
    print("-" * 40)
    pages = [1, 2, 3, 4, 1, 2, 5, 1, 2, 3, 4, 5]
    capacity = 4

    result1 = lru_page_faults(pages, capacity)
    result2 = lru_with_class(pages, capacity)

    print(f"Pages: {pages}")
    print(f"OrderedDict method: {result1}")
    print(f"DLL+HashMap method: {result2}")
    assert result1 == result2
    print("PASS")

    # Test 6: Compare algorithms
    print("\nTest 6: LRU vs FIFO vs Optimal")
    print("-" * 40)
    pages = [7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0, 1]
    capacity = 3

    lru = lru_page_faults(pages, capacity)
    fifo = fifo_page_faults(pages, capacity)
    opt = optimal_page_faults(pages, capacity)

    print(f"Pages: {pages[:10]}... ({len(pages)} total)")
    print(f"Capacity: {capacity}")
    print(f"LRU faults: {lru}")
    print(f"FIFO faults: {fifo}")
    print(f"Optimal faults: {opt}")
    print(f"LRU is {lru - opt} more than optimal")
    print("PASS")

    # Test 7: Single page
    print("\nTest 7: Single Page Repeated")
    print("-" * 40)
    pages = [1, 1, 1, 1, 1]
    capacity = 1
    result = lru_page_faults(pages, capacity)
    print(f"Pages: {pages}")
    print(f"Capacity: {capacity}")
    print(f"Faults: {result}")
    assert result == 1  # Only first access faults
    print("PASS")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_lru_vs_optimal():
    """Show case where LRU is suboptimal."""

    print("\n" + "=" * 60)
    print("LRU vs OPTIMAL: Where LRU Falls Short")
    print("=" * 60)

    # Belady's anomaly doesn't apply to LRU, but it's not optimal
    pages = [1, 2, 3, 4, 1, 2, 5, 1, 2, 3, 4, 5]
    capacity = 4

    print(f"\nPages: {pages}")
    print(f"Capacity: {capacity}")

    lru = lru_page_faults(pages, capacity)
    opt = optimal_page_faults(pages, capacity)

    print(f"\nLRU faults: {lru}")
    print(f"Optimal faults: {opt}")

    print("\nLRU uses past to predict future.")
    print("Optimal knows the future - not practical but gives lower bound.")


if __name__ == "__main__":
    run_tests()
    demonstrate_lru_vs_optimal()
