"""
Smallest Subset with Sum Greater than Remaining - Greedy Algorithm
===================================================================

Problem: Find minimum number of elements whose sum is greater than
the sum of remaining elements.

WHY GREEDY WORKS:
-----------------
1. Greedy Choice Property: Always take the largest available element.
   Larger elements contribute more to the sum with fewer elements.

2. Exchange Argument: If optimal uses smaller element 'a' instead of
   larger 'b', swapping doesn't increase count but maintains/improves sum.

3. Goal: Need subset_sum > total_sum / 2
   Taking largest first reaches this threshold fastest.

GREEDY STRATEGY: Sort descending, greedily add elements until
subset sum exceeds half of total sum.
"""

from typing import List, Tuple


def min_subset_greater(arr: List[int]) -> int:
    """
    Find minimum elements whose sum > remaining elements' sum.

    Greedy Strategy:
    1. Sort in descending order
    2. Add elements until sum > total/2
    3. Return count

    Time: O(n log n) for sorting
    Space: O(n) for sorted copy

    Example:
    >>> min_subset_greater([3, 1, 7, 1])
    1
    >>> min_subset_greater([2, 1, 2])
    2
    """
    if not arr:
        return 0

    total = sum(arr)
    if total == 0:
        return 0

    target = total // 2  # Need sum > target (i.e., sum > total/2)

    arr_sorted = sorted(arr, reverse=True)

    current_sum = 0
    count = 0

    for num in arr_sorted:
        current_sum += num
        count += 1
        if current_sum > target:
            return count

    return count


def min_subset_greater_detailed(
    arr: List[int]
) -> Tuple[int, List[int], int]:
    """
    Return count, the elements selected, and their sum.

    Returns:
        Tuple of (count, selected_elements, selected_sum)

    Example:
    >>> count, elements, s = min_subset_greater_detailed([3, 1, 7, 1])
    >>> count
    1
    >>> elements
    [7]
    """
    if not arr:
        return 0, [], 0

    total = sum(arr)
    if total == 0:
        return 0, [], 0

    target = total // 2

    arr_sorted = sorted(arr, reverse=True)
    selected = []
    current_sum = 0

    for num in arr_sorted:
        current_sum += num
        selected.append(num)
        if current_sum > target:
            break

    return len(selected), selected, current_sum


def min_subset_greater_equal(arr: List[int]) -> int:
    """
    Variation: sum >= remaining (instead of strictly greater).

    Example:
    >>> min_subset_greater_equal([2, 2, 2, 2])
    2
    """
    if not arr:
        return 0

    total = sum(arr)
    if total == 0:
        return 0

    # Need sum >= total/2, so target is ceil(total/2) - 1 or total - target < sum
    target = (total + 1) // 2  # Need sum >= this

    arr_sorted = sorted(arr, reverse=True)
    current_sum = 0
    count = 0

    for num in arr_sorted:
        current_sum += num
        count += 1
        if current_sum >= target:
            return count

    return count


# =============================================================================
# BRUTE FORCE
# =============================================================================

def brute_force_min_subset(arr: List[int]) -> int:
    """
    Brute force: try all subsets.

    Time: O(2^n * n)
    Space: O(1)
    """
    n = len(arr)
    if n == 0:
        return 0

    total = sum(arr)
    min_count = n

    for mask in range(1, 1 << n):
        subset_sum = sum(arr[i] for i in range(n) if mask & (1 << i))
        remaining = total - subset_sum

        if subset_sum > remaining:
            count = bin(mask).count('1')
            min_count = min(min_count, count)

    return min_count


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Comprehensive test cases."""

    print("=" * 60)
    print("SMALLEST SUBSET SUM GREATER - TEST CASES")
    print("=" * 60)

    # Test 1: Basic example
    print("\nTest 1: Basic Example")
    print("-" * 40)
    arr = [3, 1, 7, 1]
    result = min_subset_greater(arr)
    brute = brute_force_min_subset(arr)
    count, elements, s = min_subset_greater_detailed(arr)

    print(f"Array: {arr}")
    print(f"Total: {sum(arr)}, Need > {sum(arr)//2}")
    print(f"Selected: {elements} (sum={s})")
    print(f"Greedy: {result}, Brute: {brute}")
    assert result == brute
    print("PASS")

    # Test 2: Need multiple elements
    print("\nTest 2: Need Multiple Elements")
    print("-" * 40)
    arr = [2, 1, 2]
    result = min_subset_greater(arr)
    brute = brute_force_min_subset(arr)
    count, elements, s = min_subset_greater_detailed(arr)

    print(f"Array: {arr}")
    print(f"Total: {sum(arr)}, Need > {sum(arr)//2}")
    print(f"Selected: {elements} (sum={s})")
    print(f"Greedy: {result}, Brute: {brute}")
    assert result == brute
    print("PASS")

    # Test 3: All equal elements
    print("\nTest 3: All Equal")
    print("-" * 40)
    arr = [5, 5, 5, 5]
    result = min_subset_greater(arr)
    print(f"Array: {arr}")
    print(f"Result: {result}")
    assert result == 3  # Need 15 > 5, so 3 elements
    print("PASS")

    # Test 4: Single element
    print("\nTest 4: Single Element")
    print("-" * 40)
    arr = [10]
    result = min_subset_greater(arr)
    print(f"Array: {arr}")
    print(f"Result: {result}")
    assert result == 1
    print("PASS")

    # Test 5: Two elements
    print("\nTest 5: Two Elements")
    print("-" * 40)
    arr = [3, 7]
    result = min_subset_greater(arr)
    print(f"Array: {arr}")
    print(f"Result: {result}")
    assert result == 1  # 7 > 3
    print("PASS")

    # Test 6: Larger example
    print("\nTest 6: Larger Example")
    print("-" * 40)
    arr = [1, 2, 3, 4, 5, 6, 7, 8]
    result = min_subset_greater(arr)
    brute = brute_force_min_subset(arr)
    count, elements, s = min_subset_greater_detailed(arr)

    print(f"Array: {arr}")
    print(f"Total: {sum(arr)}, Need > {sum(arr)//2}")
    print(f"Selected: {elements} (sum={s})")
    print(f"Greedy: {result}, Brute: {brute}")
    assert result == brute
    print("PASS")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_greedy():
    """Demonstrate why greedy works."""

    print("\n" + "=" * 60)
    print("WHY GREEDY WORKS")
    print("=" * 60)

    arr = [1, 2, 3, 4, 5, 6]
    total = sum(arr)
    target = total // 2

    print(f"\nArray: {arr}")
    print(f"Total sum: {total}")
    print(f"Need subset sum > {target}")

    print("\nGreedy approach (take largest first):")
    sorted_arr = sorted(arr, reverse=True)
    current_sum = 0

    for i, num in enumerate(sorted_arr):
        current_sum += num
        print(f"  Add {num}: sum = {current_sum}", end="")
        if current_sum > target:
            print(f" > {target} - DONE! Need {i+1} elements")
            break
        print(f" <= {target} - continue")


if __name__ == "__main__":
    run_tests()
    demonstrate_greedy()
