# Smallest Subset with Sum Greater than Remaining

## Problem Statement

Given an array of non-negative integers, find the minimum number of elements such that their sum is greater than the sum of the remaining elements.

**Input:** Array `arr[]` of n non-negative integers

**Output:** Minimum number of elements needed

**Example:**
```
Input: arr[] = [3, 1, 7, 1]
Total sum = 12, Half = 6
Output: 1 (just take 7, sum = 7 > 5)

Input: arr[] = [2, 1, 2]
Total sum = 5, Half = 2.5
Output: 2 (take 2 + 2 = 4 > 1)
```

---

## Why Greedy Works Here

### The Greedy Choice Property

**Claim:** Always include the largest remaining element in the subset.

**Intuition:**
- We need subset sum > remaining sum
- Equivalently: subset sum > total_sum / 2
- Taking largest elements minimizes the count needed

### Exchange Argument Proof

1. Suppose optimal solution includes element `a` but not larger element `b`
2. If we replace `a` with `b`:
   - Subset sum increases (or stays same if a = b)
   - We still satisfy the constraint
   - We haven't increased the count
3. Therefore, always taking largest first is safe

### Mathematical Condition

If `S` = total sum, we need subset sum > S/2

Equivalently: subset sum >= floor(S/2) + 1

---

## Step-by-Step Greedy Selection

### Algorithm:

```
1. CALCULATE total sum
2. SORT array in descending order
3. GREEDILY add elements until sum > total/2:
   - Add largest remaining element
   - Check if current_sum > total - current_sum
4. RETURN count of elements added
```

---

## Brute Force Comparison

### Brute Force Approach
Try all subsets, find minimum size with sum > remaining.

```python
def brute_force(arr):
    n = len(arr)
    total = sum(arr)
    min_count = n
    
    for mask in range(1, 1 << n):
        subset_sum = sum(arr[i] for i in range(n) if mask & (1 << i))
        remaining = total - subset_sum
        
        if subset_sum > remaining:
            count = bin(mask).count('1')
            min_count = min(min_count, count)
    
    return min_count
```

**Time Complexity:** O(2^n * n)
**Space Complexity:** O(1)

---

## Optimal Greedy Approach

```python
def min_subset_greater(arr):
    total = sum(arr)
    target = total // 2  # Need sum > target
    
    arr_sorted = sorted(arr, reverse=True)
    
    current_sum = 0
    count = 0
    
    for num in arr_sorted:
        current_sum += num
        count += 1
        if current_sum > target:
            return count
    
    return count  # All elements needed
```

**Time Complexity:** O(n log n) for sorting
**Space Complexity:** O(n) for sorted copy

---

## Dry Run

**Input:** `arr = [3, 1, 7, 1]`

**Step 1: Calculate Total**
```
Total = 3 + 1 + 7 + 1 = 12
Target = 12 // 2 = 6
Need subset sum > 6
```

**Step 2: Sort Descending**
```
Sorted: [7, 3, 1, 1]
```

**Step 3: Greedy Selection**
```
Take 7: sum = 7 > 6? YES!
Count = 1
```

**Result:** Minimum 1 element needed (just take 7)

---

## Time and Space Complexity

| Aspect | Complexity | Explanation |
|--------|------------|-------------|
| **Time** | O(n log n) | Sorting dominates |
| **Space** | O(n) | Sorted copy |

---

## Variations

### 1. Sum Greater Than or Equal
Adjust condition to `>=` instead of `>`

### 2. Minimize Sum Instead of Count
Different problem - may need DP

### 3. With Constraints on Which Elements
May need different approach
