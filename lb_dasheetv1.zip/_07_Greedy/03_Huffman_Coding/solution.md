# Huffman Coding

## Problem Statement

Given a set of characters with their frequencies, build a Huffman tree and generate optimal prefix-free codes that minimize the total encoding length.

**Input:**
- Characters with their frequencies: `[(char, frequency), ...]`

**Output:**
- Huffman codes for each character
- Total encoding cost (weighted path length)

**Example:**
```
Characters: a(5), b(9), c(12), d(13), e(16), f(45)
Huffman Codes:
  f: 0        (45 * 1 = 45)
  c: 100      (12 * 3 = 36)
  d: 101      (13 * 3 = 39)
  a: 1100     (5 * 4 = 20)
  b: 1101     (9 * 4 = 36)
  e: 111      (16 * 3 = 48)
Total Cost: 224 bits
```

---

## Why Greedy Works Here

### The Greedy Insight

**Key Observation:** Characters with higher frequencies should have shorter codes.

**Greedy Strategy:** Always merge the two nodes with the **smallest frequencies** first.

### Why Merge Smallest First?

When we merge two nodes:
1. They become children of a new internal node
2. Their depth in the tree increases by 1
3. Their codes get one more bit

**Logic:**
- Characters deep in the tree have long codes
- Low-frequency characters should be deep (long codes are okay for rare characters)
- High-frequency characters should be shallow (short codes for common characters)
- Merging smallest first pushes rare characters deeper

### Mathematical Proof

Let `f(c)` = frequency of character `c`
Let `d(c)` = depth of character `c` in tree

**Total cost** = Sum of `f(c) * d(c)` for all characters

When we merge nodes A and B:
- Their depths increase by 1
- Cost increase = `f(A) + f(B)`

**To minimize total cost:** Always merge pairs with smallest combined frequency increase, which means merging the two smallest nodes!

### Exchange Argument

**Claim:** There exists an optimal tree where the two least frequent characters are siblings at maximum depth.

**Proof:**
1. Let `x` and `y` be the two least frequent characters
2. In any optimal tree, swap `x` with the deepest node (if needed)
3. Swap `y` with the other node at same level
4. Cost cannot increase (we're moving low-frequency nodes deeper)
5. Therefore, putting `x` and `y` at max depth is optimal

---

## Greedy Choice Property Explanation

### Building the Huffman Tree

```
Initial: Nodes with frequencies
         5(a)  9(b)  12(c)  13(d)  16(e)  45(f)

Step 1: Merge two smallest (5 and 9)
         14(ab)  12(c)  13(d)  16(e)  45(f)
              /\
             a  b

Step 2: Merge two smallest (12 and 13)
         14(ab)  25(cd)  16(e)  45(f)
              /\      /\
             a  b    c  d

Step 3: Merge two smallest (14 and 16)
         30(abe)  25(cd)  45(f)
             /\       /\
           14  e     c  d
          /\
         a  b

Step 4: Merge two smallest (25 and 30)
         55(abcde)  45(f)
             /\
           30  25
          /\   /\
        14 e  c  d
       /\
      a  b

Step 5: Final merge
              100
             /   \
           55     f(45)
          /  \
        30    25
       /\    /\
     14  e  c  d
    /\
   a  b
```

### Code Assignment

- Traverse left: add '0'
- Traverse right: add '1'

```
f: 0 (one right)
e: 111 (left, right, right)
c: 100 (left, left, left)
d: 101 (left, left, right)
a: 1100 (left, left, right, left)
b: 1101 (left, left, right, right)
```

---

## Step-by-Step Algorithm

### Algorithm (Using Min-Heap):

```
1. CREATE a min-heap of all characters with frequencies
2. WHILE heap has more than one node:
   a. EXTRACT two nodes with minimum frequency
   b. CREATE new internal node with:
      - Frequency = sum of extracted nodes
      - Left child = first extracted node
      - Right child = second extracted node
   c. INSERT new node into heap
3. REMAINING node is the root of Huffman tree
4. TRAVERSE tree to assign codes:
   - Left edge = '0'
   - Right edge = '1'
```

### Why Min-Heap?

- Need to repeatedly find minimum element: O(log n)
- Need to insert new merged node: O(log n)
- Total: O(n log n)

Without heap (linear search): O(n^2)

---

## Brute Force Comparison

### Brute Force Approach

Try all possible binary tree structures and find the one with minimum cost.

```python
def brute_force_huffman(frequencies):
    # Number of possible tree structures is Catalan number
    # C(n) = (2n)! / ((n+1)! * n!)
    # For n=5: C(5) = 42 different trees
    
    # Generate all possible trees
    # For each tree, calculate weighted path length
    # Return minimum
    pass
```

**Catalan Numbers:**
- n=1: 1 tree
- n=2: 2 trees
- n=3: 5 trees
- n=4: 14 trees
- n=5: 42 trees
- n=10: 16,796 trees
- n=20: ~6 billion trees

**Complexity:** Exponential - completely impractical!

### Greedy Advantage

| n | Brute Force Trees | Greedy Operations |
|---|-------------------|-------------------|
| 5 | 42 | ~25 |
| 10 | 16,796 | ~90 |
| 20 | ~6 billion | ~380 |

---

## Optimal Greedy Implementation

```python
import heapq

def huffman_coding(char_freq):
    """
    Build Huffman tree and return codes.
    
    Args:
        char_freq: List of (character, frequency) tuples
    
    Returns:
        Dictionary mapping character to Huffman code
    """
    # Edge case
    if len(char_freq) == 1:
        return {char_freq[0][0]: '0'}
    
    # Create min heap: (frequency, id, char_or_node)
    # id is to break ties (avoid comparing nodes)
    heap = []
    for i, (char, freq) in enumerate(char_freq):
        heapq.heappush(heap, (freq, i, char))
    
    node_id = len(char_freq)
    
    # Build Huffman tree
    while len(heap) > 1:
        # Extract two minimum
        freq1, _, node1 = heapq.heappop(heap)
        freq2, _, node2 = heapq.heappop(heap)
        
        # Merge into new node
        merged = (node1, node2)  # (left, right)
        heapq.heappush(heap, (freq1 + freq2, node_id, merged))
        node_id += 1
    
    # Generate codes by traversing tree
    codes = {}
    root = heap[0][2]
    
    def generate_codes(node, code=""):
        if isinstance(node, str):  # Leaf node (character)
            codes[node] = code if code else '0'
        else:  # Internal node
            generate_codes(node[0], code + '0')  # Left
            generate_codes(node[1], code + '1')  # Right
    
    generate_codes(root)
    return codes
```

**Time Complexity:** O(n log n)
**Space Complexity:** O(n)

---

## Dry Run with Selection Visualization

**Input:** Characters with frequencies: a(5), b(9), c(12), d(13), e(16), f(45)

### Step-by-Step Execution

```
Initial Heap (min-heap by frequency):
[5(a), 9(b), 12(c), 13(d), 16(e), 45(f)]

========================================
STEP 1: Merge two smallest
========================================
Extract: 5(a) and 9(b)
Merge cost: 5 + 9 = 14

    14
   /  \
  a    b
  5    9

Heap: [12(c), 13(d), 14(ab), 16(e), 45(f)]
Running cost: 14

========================================
STEP 2: Merge two smallest
========================================
Extract: 12(c) and 13(d)
Merge cost: 12 + 13 = 25

    25
   /  \
  c    d
  12   13

Heap: [14(ab), 16(e), 25(cd), 45(f)]
Running cost: 14 + 25 = 39

========================================
STEP 3: Merge two smallest
========================================
Extract: 14(ab) and 16(e)
Merge cost: 14 + 16 = 30

      30
     /  \
   14    e
   /\    16
  a  b
  5  9

Heap: [25(cd), 30(abe), 45(f)]
Running cost: 39 + 30 = 69

========================================
STEP 4: Merge two smallest
========================================
Extract: 25(cd) and 30(abe)
Merge cost: 25 + 30 = 55

         55
        /  \
      30    25
     /  \   /\
   14   e  c  d
   /\
  a  b

Heap: [45(f), 55(abcde)]
Running cost: 69 + 55 = 124

========================================
STEP 5: Final merge
========================================
Extract: 45(f) and 55(abcde)
Merge cost: 45 + 55 = 100

            100
           /   \
          f    55
         45   /  \
            30    25
           /  \   /\
         14   e  c  d
         /\   16
        a  b
        5  9

Final cost: 124 + 100 = 224
```

### Final Huffman Codes

```
Traversal (left=0, right=1):

Character | Path          | Code | Frequency | Bits Used
----------|---------------|------|-----------|----------
f         | right         | 1    | 45        | 45
e         | left,right,right | 011 | 16      | 48
c         | left,left,left | 000 | 12        | 36
d         | left,left,right| 001 | 13        | 39
a         | left,right,left,left | 0100 | 5  | 20
b         | left,right,left,right| 0101 | 9  | 36

Total bits: 45 + 48 + 36 + 39 + 20 + 36 = 224 bits
```

**Comparison with Fixed-Length Encoding:**
- 6 characters need 3 bits each (2^3 = 8 >= 6)
- Fixed-length: (5+9+12+13+16+45) * 3 = 300 bits
- Huffman: 224 bits
- **Savings: 25.3%**

---

## Time and Space Complexity

### Time Complexity: O(n log n)

| Operation | Count | Each | Total |
|-----------|-------|------|-------|
| Build initial heap | 1 | O(n) | O(n) |
| Extract min | 2(n-1) | O(log n) | O(n log n) |
| Insert merged | n-1 | O(log n) | O(n log n) |
| Generate codes | 1 | O(n) | O(n) |
| **Total** | | | **O(n log n)** |

### Space Complexity: O(n)

- Heap storage: O(n) nodes
- Tree storage: O(n) nodes (n leaves, n-1 internal)
- Code storage: O(n) codes, total length O(n log n) in worst case

---

## Variations and Applications

### 1. Adaptive Huffman Coding
- Build tree dynamically as data arrives
- Useful for streaming data

### 2. Canonical Huffman Codes
- Codes with same length are sequential
- Easier to store and decode

### 3. Applications
- **File compression**: ZIP, GZIP
- **Image compression**: JPEG (for coefficients)
- **Network protocols**: HTTP/2 header compression (HPACK)
- **Data transmission**: Minimize bandwidth

### 4. Related Problems
- **Connect Ropes**: Same algorithm! Minimize total cost of connecting ropes
- **Merge K Sorted Lists**: Similar heap-based approach
- **Optimal Merge Pattern**: Same greedy strategy
