"""
Huffman Coding - Greedy Algorithm
=================================

Problem: Build optimal prefix-free codes for characters based on frequencies.
Characters with higher frequencies get shorter codes to minimize total encoding length.

WHY GREEDY WORKS:
----------------
1. Greedy Choice: Merge the two nodes with SMALLEST frequencies first.

2. Intuition: When nodes merge, they go one level deeper (code gets one bit longer).
   By merging smallest first, we push infrequent characters deeper (longer codes),
   while frequent characters stay shallow (shorter codes).

3. Exchange Argument: In any optimal tree, the two least frequent characters must
   be siblings at maximum depth. If not, we can swap them with the deepest nodes
   without increasing cost.

GREEDY STRATEGY:
- Use min-heap to always get two smallest frequency nodes
- Merge them into a new internal node
- Repeat until one node (root) remains
- Traverse tree to assign codes (left=0, right=1)
"""

import heapq
from typing import List, Tuple, Dict, Optional
from dataclasses import dataclass, field


@dataclass(order=True)
class HuffmanNode:
    """Node in Huffman tree. Comparable by frequency for heap operations."""
    freq: int
    char: str = field(compare=False)
    left: Optional['HuffmanNode'] = field(default=None, compare=False)
    right: Optional['HuffmanNode'] = field(default=None, compare=False)

    def is_leaf(self) -> bool:
        return self.left is None and self.right is None


def huffman_coding(char_freq: List[Tuple[str, int]]) -> Dict[str, str]:
    """
    Build Huffman tree and return codes for each character.

    Greedy Strategy:
    1. Build min-heap of all character nodes
    2. Repeatedly extract two smallest, merge, and reinsert
    3. Traverse final tree to generate codes

    Args:
        char_freq: List of (character, frequency) tuples

    Returns:
        Dictionary mapping character to its Huffman code

    Time: O(n log n) - heap operations dominate
    Space: O(n) - for tree and codes storage

    Example:
    >>> codes = huffman_coding([('a', 5), ('b', 9), ('c', 12), ('d', 13), ('e', 16), ('f', 45)])
    >>> codes['f']  # Most frequent -> shortest code
    '0'
    >>> len(codes['a']) > len(codes['f'])  # Least frequent -> longest code
    True
    """
    if not char_freq:
        return {}

    if len(char_freq) == 1:
        return {char_freq[0][0]: '0'}

    # Create initial heap of leaf nodes
    heap: List[HuffmanNode] = []
    for char, freq in char_freq:
        heapq.heappush(heap, HuffmanNode(freq, char))

    # Build Huffman tree by merging smallest nodes
    while len(heap) > 1:
        # Greedy choice: extract two smallest frequency nodes
        left = heapq.heappop(heap)
        right = heapq.heappop(heap)

        # Merge into new internal node
        merged = HuffmanNode(
            freq=left.freq + right.freq,
            char=f'({left.char}+{right.char})',
            left=left,
            right=right
        )

        heapq.heappush(heap, merged)

    # Generate codes by traversing tree
    root = heap[0]
    codes: Dict[str, str] = {}

    def generate_codes(node: HuffmanNode, code: str = ""):
        if node.is_leaf():
            codes[node.char] = code if code else '0'
            return

        if node.left:
            generate_codes(node.left, code + '0')
        if node.right:
            generate_codes(node.right, code + '1')

    generate_codes(root)
    return codes


def huffman_encoding_cost(frequencies: List[int]) -> int:
    """
    Calculate total cost of Huffman encoding.

    This is equivalent to the "Connect Ropes" problem:
    - Cost of connecting two ropes = sum of their lengths
    - Minimize total cost to connect all ropes

    Args:
        frequencies: List of character frequencies

    Returns:
        Total encoding cost (sum of all merge costs)

    Time: O(n log n)
    Space: O(n)

    Example:
    >>> huffman_encoding_cost([5, 9, 12, 13, 16, 45])
    224
    """
    if len(frequencies) <= 1:
        return 0

    # Min-heap of frequencies
    heap = frequencies[:]
    heapq.heapify(heap)

    total_cost = 0

    while len(heap) > 1:
        # Greedy: merge two smallest
        first = heapq.heappop(heap)
        second = heapq.heappop(heap)

        merge_cost = first + second
        total_cost += merge_cost

        heapq.heappush(heap, merge_cost)

    return total_cost


def huffman_decode(encoded: str, codes: Dict[str, str]) -> str:
    """
    Decode a Huffman encoded string.

    Since Huffman codes are prefix-free, we can decode by matching
    the longest prefix at each step.

    Args:
        encoded: Binary string (e.g., "110100111")
        codes: Character to code mapping

    Returns:
        Decoded string
    """
    # Invert codes for decoding
    decode_map = {code: char for char, code in codes.items()}

    decoded = []
    current = ""

    for bit in encoded:
        current += bit
        if current in decode_map:
            decoded.append(decode_map[current])
            current = ""

    if current:
        raise ValueError(f"Invalid encoding: leftover bits '{current}'")

    return ''.join(decoded)


def huffman_encode(text: str, codes: Dict[str, str]) -> str:
    """
    Encode text using Huffman codes.

    Args:
        text: String to encode
        codes: Character to code mapping

    Returns:
        Binary string representation
    """
    return ''.join(codes[char] for char in text)


def compare_with_fixed_length(char_freq: List[Tuple[str, int]]) -> Dict[str, any]:
    """
    Compare Huffman encoding with fixed-length encoding.

    Returns comparison statistics.
    """
    n_chars = len(char_freq)
    total_freq = sum(freq for _, freq in char_freq)

    # Fixed-length encoding
    import math
    fixed_bits = math.ceil(math.log2(n_chars)) if n_chars > 1 else 1
    fixed_total = total_freq * fixed_bits

    # Huffman encoding
    codes = huffman_coding(char_freq)
    huffman_total = sum(
        len(codes[char]) * freq for char, freq in char_freq
    )

    savings = (fixed_total - huffman_total) / fixed_total * 100

    return {
        'characters': n_chars,
        'fixed_bits_per_char': fixed_bits,
        'fixed_total_bits': fixed_total,
        'huffman_total_bits': huffman_total,
        'savings_percent': round(savings, 2),
        'codes': codes
    }


def print_huffman_tree(node: HuffmanNode, prefix: str = "", is_left: bool = True):
    """Pretty print the Huffman tree."""
    if node is None:
        return

    connector = "|-- " if is_left else "`-- "
    print(prefix + connector + f"{node.char}({node.freq})")

    if not node.is_leaf():
        new_prefix = prefix + ("|   " if is_left else "    ")
        print_huffman_tree(node.left, new_prefix, True)
        print_huffman_tree(node.right, new_prefix, False)


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Comprehensive test cases with explanations."""

    print("=" * 60)
    print("HUFFMAN CODING - TEST CASES")
    print("=" * 60)

    # Test 1: Classic example
    print("\nTest 1: Classic Example")
    print("-" * 40)
    char_freq = [('a', 5), ('b', 9), ('c', 12), ('d', 13), ('e', 16), ('f', 45)]

    codes = huffman_coding(char_freq)
    print(f"Characters and frequencies: {char_freq}")
    print(f"Huffman codes:")
    for char, freq in sorted(char_freq, key=lambda x: -x[1]):
        print(f"  '{char}' (freq={freq}): {codes[char]}")

    # Verify prefix-free property
    code_list = list(codes.values())
    for i, c1 in enumerate(code_list):
        for c2 in code_list[i+1:]:
            assert not c1.startswith(c2) and not c2.startswith(c1), \
                f"Prefix collision: {c1} and {c2}"
    print("Prefix-free property verified!")

    # Test encoding cost
    cost = huffman_encoding_cost([freq for _, freq in char_freq])
    print(f"Total encoding cost: {cost}")

    # Test 2: Compare with fixed-length
    print("\nTest 2: Huffman vs Fixed-Length Comparison")
    print("-" * 40)
    comparison = compare_with_fixed_length(char_freq)
    print(f"Fixed-length bits per char: {comparison['fixed_bits_per_char']}")
    print(f"Fixed-length total bits: {comparison['fixed_total_bits']}")
    print(f"Huffman total bits: {comparison['huffman_total_bits']}")
    print(f"Space savings: {comparison['savings_percent']}%")

    # Test 3: Encode and decode
    print("\nTest 3: Encode and Decode")
    print("-" * 40)
    text = "abcdef"
    encoded = huffman_encode(text, codes)
    decoded = huffman_decode(encoded, codes)
    print(f"Original: {text}")
    print(f"Encoded: {encoded}")
    print(f"Decoded: {decoded}")
    assert text == decoded, "Decode should return original!"
    print("Encode/Decode verified!")

    # Test 4: Single character
    print("\nTest 4: Single Character")
    print("-" * 40)
    single_codes = huffman_coding([('x', 100)])
    print(f"Single char codes: {single_codes}")
    assert single_codes == {'x': '0'}

    # Test 5: Two characters
    print("\nTest 5: Two Characters")
    print("-" * 40)
    two_codes = huffman_coding([('a', 10), ('b', 20)])
    print(f"Two char codes: {two_codes}")
    # One should be '0', other should be '1'
    assert set(two_codes.values()) == {'0', '1'}

    # Test 6: Verify greedy property
    print("\nTest 6: Verify Greedy Property")
    print("-" * 40)
    print("Most frequent character should have shortest code:")
    char_freq_sorted = sorted(char_freq, key=lambda x: -x[1])
    prev_len = 0
    for char, freq in char_freq_sorted:
        code_len = len(codes[char])
        print(f"  '{char}' (freq={freq}): code length = {code_len}")
        assert code_len >= prev_len or freq == char_freq_sorted[0][1], \
            "Higher frequency should have shorter or equal length code"

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_greedy_choice():
    """Step-by-step demonstration of Huffman tree construction."""

    print("\n" + "=" * 60)
    print("DEMONSTRATION: WHY GREEDY WORKS")
    print("=" * 60)

    char_freq = [('a', 5), ('b', 9), ('c', 12), ('d', 13), ('e', 16), ('f', 45)]

    print("\nInitial characters with frequencies:")
    for char, freq in char_freq:
        print(f"  '{char}': {freq}")

    print("\n" + "-" * 40)
    print("BUILDING HUFFMAN TREE:")
    print("-" * 40)

    # Simulate the algorithm step by step
    heap = [(freq, char, char) for char, freq in char_freq]
    heapq.heapify(heap)

    step = 1
    total_cost = 0

    while len(heap) > 1:
        # Show current heap
        print(f"\nStep {step}: Current heap (sorted by frequency):")
        for freq, label, _ in sorted(heap):
            print(f"  {label}: {freq}")

        # Extract two smallest
        freq1, label1, _ = heapq.heappop(heap)
        freq2, label2, _ = heapq.heappop(heap)

        print(f"\n  GREEDY CHOICE: Merge two smallest:")
        print(f"    {label1}({freq1}) + {label2}({freq2})")

        # Merge
        new_freq = freq1 + freq2
        new_label = f"({label1}+{label2})"
        total_cost += new_freq

        print(f"    = {new_label}({new_freq})")
        print(f"    Merge cost: {new_freq}, Running total: {total_cost}")

        heapq.heappush(heap, (new_freq, new_label, new_label))
        step += 1

    print(f"\n" + "-" * 40)
    print(f"FINAL TREE ROOT: {heap[0][1]} with frequency {heap[0][0]}")
    print(f"TOTAL ENCODING COST: {total_cost}")

    print("\nWHY THIS IS OPTIMAL:")
    print("-" * 40)
    print("1. By merging smallest first, we push rare characters deeper")
    print("2. 'f' (freq=45) stays near root -> short code")
    print("3. 'a' (freq=5) goes deep -> long code")
    print("4. This minimizes: sum(frequency * code_length)")

    # Calculate actual bits
    codes = huffman_coding(char_freq)
    print("\nFinal codes and bit usage:")
    total_bits = 0
    for char, freq in sorted(char_freq, key=lambda x: -x[1]):
        bits = len(codes[char]) * freq
        total_bits += bits
        print(f"  '{char}': {codes[char]:6s} -> {len(codes[char])} bits x {freq} = {bits} bits")
    print(f"\nTotal bits: {total_bits}")


if __name__ == "__main__":
    run_tests()
    demonstrate_greedy_choice()
