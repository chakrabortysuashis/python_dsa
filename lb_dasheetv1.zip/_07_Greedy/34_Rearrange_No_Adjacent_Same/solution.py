"""
Rearrange Characters So No Two Adjacent Are Same - Greedy Algorithm
====================================================================

Problem: Rearrange string so no two adjacent characters are the same.

WHY GREEDY WORKS:
-----------------
1. Greedy Choice: Always use the most frequent character that differs
   from the last placed character.

2. Feasibility: Possible iff max_frequency <= (n+1)/2

3. Max-heap ensures we always have the "most needed" character available.

GREEDY STRATEGY: Use max-heap, place most frequent non-conflicting char.
"""

from typing import Union
from collections import Counter
import heapq


def rearrange(s: str) -> Union[str, None]:
    """
    Rearrange string so no adjacent characters are same.

    Time: O(N log K) where K = alphabet size
    Space: O(N)

    Example:
    >>> rearrange("aab")
    'aba'
    >>> rearrange("aaab")
    """
    if not s:
        return ""

    counts = Counter(s)
    n = len(s)

    # Feasibility check
    max_freq = max(counts.values())
    if max_freq > (n + 1) // 2:
        return None

    # Max-heap (negate frequencies)
    heap = [(-freq, char) for char, freq in counts.items()]
    heapq.heapify(heap)

    result = []

    while heap:
        freq1, char1 = heapq.heappop(heap)

        if result and result[-1] == char1:
            if not heap:
                return None

            freq2, char2 = heapq.heappop(heap)
            result.append(char2)
            freq2 += 1
            if freq2 < 0:
                heapq.heappush(heap, (freq2, char2))
            heapq.heappush(heap, (freq1, char1))
        else:
            result.append(char1)
            freq1 += 1
            if freq1 < 0:
                heapq.heappush(heap, (freq1, char1))

    return ''.join(result)


def rearrange_interleave(s: str) -> Union[str, None]:
    """
    Alternative: Fill even indices first, then odd.

    Time: O(N log N)
    """
    counts = Counter(s)
    n = len(s)

    max_freq = max(counts.values())
    if max_freq > (n + 1) // 2:
        return None

    sorted_chars = sorted(counts.items(), key=lambda x: -x[1])

    result = [''] * n
    idx = 0  # Start with even indices

    for char, freq in sorted_chars:
        for _ in range(freq):
            result[idx] = char
            idx += 2
            if idx >= n:
                idx = 1  # Switch to odd indices

    return ''.join(result)


def run_tests():
    print("=" * 50)
    print("REARRANGE NO ADJACENT SAME - TEST CASES")
    print("=" * 50)

    # Test 1
    print("\nTest 1: 'aab'")
    result = rearrange("aab")
    print(f"Result: {result}")
    assert result and all(result[i] != result[i+1] for i in range(len(result)-1))

    # Test 2
    print("\nTest 2: 'aaab' (impossible)")
    result = rearrange("aaab")
    print(f"Result: {result}")
    assert result is None

    # Test 3
    print("\nTest 3: 'aabb'")
    result = rearrange("aabb")
    print(f"Result: {result}")
    assert result and all(result[i] != result[i+1] for i in range(len(result)-1))

    # Test 4
    print("\nTest 4: 'programming'")
    result = rearrange("programming")
    print(f"Result: {result}")
    assert result and all(result[i] != result[i+1] for i in range(len(result)-1))

    # Test 5: Compare methods
    print("\nTest 5: Compare methods")
    s = "aaabbbcc"
    r1 = rearrange(s)
    r2 = rearrange_interleave(s)
    print(f"Heap method: {r1}")
    print(f"Interleave: {r2}")

    print("\nALL TESTS PASSED!")


if __name__ == "__main__":
    run_tests()
