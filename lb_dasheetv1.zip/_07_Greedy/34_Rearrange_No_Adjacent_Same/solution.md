# Rearrange Characters So No Two Adjacent Are Same

## Problem Statement

Given a string, rearrange its characters so that no two adjacent characters are the same. Return any valid arrangement or indicate if impossible.

**Input:** String S

**Output:** Rearranged string or "impossible"

**Example:**
```
Input: "aab"
Output: "aba"

Input: "aaab"
Output: "impossible" (too many a's)
```

---

## Why Greedy Works Here

### The Greedy Choice Property

**Claim:** Always place the character with highest remaining frequency that differs from the last placed character.

### Feasibility Condition

Rearrangement is possible if and only if:
```
max_frequency <= (n + 1) / 2
```

### Algorithm

1. Use a max-heap of (frequency, character) pairs
2. At each position:
   - Pop the most frequent character
   - If it equals last placed, pop second most frequent, place it, push first back
   - Place the character and push back if frequency > 0
3. Continue until heap is empty or impossible

---

## Algorithm

```python
import heapq
from collections import Counter

def rearrange(s):
    counts = Counter(s)
    n = len(s)
    
    # Check feasibility
    max_freq = max(counts.values())
    if max_freq > (n + 1) // 2:
        return "impossible"
    
    # Max-heap (negate for max behavior)
    heap = [(-freq, char) for char, freq in counts.items()]
    heapq.heapify(heap)
    
    result = []
    
    while heap:
        freq1, char1 = heapq.heappop(heap)
        
        if result and result[-1] == char1:
            # Can't use char1, try next
            if not heap:
                return "impossible"
            freq2, char2 = heapq.heappop(heap)
            result.append(char2)
            freq2 += 1  # Used one (negated)
            if freq2 < 0:
                heapq.heappush(heap, (freq2, char2))
            heapq.heappush(heap, (freq1, char1))  # Put char1 back
        else:
            result.append(char1)
            freq1 += 1
            if freq1 < 0:
                heapq.heappush(heap, (freq1, char1))
    
    return ''.join(result)
```

---

## Time Complexity

O(N log K) where K is alphabet size (typically 26)
