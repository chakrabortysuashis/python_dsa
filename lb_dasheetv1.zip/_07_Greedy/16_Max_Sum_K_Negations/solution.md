# Maximize Sum After K Negations

## Problem Statement

Given an array of integers and an integer `K`, maximize the sum of the array after performing exactly `K` negations. In one negation operation, you can negate (flip the sign of) any element of the array.

**Input:**
- `arr[]` - Array of integers
- `K` - Number of negations to perform (must perform exactly K)

**Output:** Maximum sum after exactly K negations

**Example:**
```
Input: arr = [3, -1, 0, 2], K = 3
Output: 6

Explanation:
- Negate -1: [3, 1, 0, 2], sum = 6
- Negate 0: [3, 1, 0, 2], sum = 6 (0 stays 0)
- Negate 0: [3, 1, 0, 2], sum = 6
Final sum = 3 + 1 + 0 + 2 = 6
```

---

## Why Greedy Works Here

### The Greedy Choice Property

**Claim:** To maximize sum, always negate the smallest element (most negative first).

**Intuition:**
- Negating a negative number increases sum by `2 * |number|`
- Negating a positive number decreases sum by `2 * |number|`
- When forced to negate positives, pick the smallest one
- If 0 exists and extra negations remain, use it as a "sink"

### Greedy Strategy

1. **Sort the array**
2. **Negate negatives** (from most negative to least negative)
3. **If K negations remain:**
   - If 0 exists: use remaining K on 0 (no effect)
   - If K is even: negate any element twice (net zero effect)
   - If K is odd: negate smallest absolute value element once

### Exchange Argument Proof

1. Let `OPT` be an optimal solution
2. If `OPT` doesn't negate the most negative element first, swap:
   - Original: skip most negative `a`, negate less negative `b`
   - Better: negate `a` instead of `b`
   - Gain: `2*|a| - 2*|b| > 0` (since `|a| > |b|`)
3. Therefore, negating most negative first is always optimal

---

## Step-by-Step Algorithm

### Algorithm:

```
1. SORT array in ascending order
2. FOR i from 0 to n-1 while K > 0:
   - IF arr[i] < 0:
     - Negate arr[i] (make positive)
     - K -= 1
   - ELSE: break (no more negatives)
3. IF K > 0 and K is odd:
   - Sort again to find new minimum
   - Negate the smallest absolute value element
4. RETURN sum of array
```

### Optimization with Min-Heap

For large K with many small negatives:
```
1. Build min-heap from array
2. FOR i from 1 to K:
   - Pop minimum element
   - Negate it
   - Push back
3. Return sum of heap
```

---

## Brute Force Comparison

### Brute Force Approach
Try all possible combinations of K elements to negate.

```python
def brute_force(arr, k):
    from itertools import combinations
    n = len(arr)
    max_sum = float('-inf')
    
    # Generate all ways to choose k positions (with repetition)
    # This is actually more complex - need to handle repeated negations
    
    # Simplified: try all 2^n states of negation
    for mask in range(1 << n):
        if bin(mask).count('1') % 2 == k % 2:  # Same parity
            temp_sum = 0
            for i in range(n):
                if mask & (1 << i):
                    temp_sum -= arr[i]
                else:
                    temp_sum += arr[i]
            max_sum = max(max_sum, temp_sum)
    
    return max_sum
```

**Time Complexity:** O(2^n)
**Space Complexity:** O(1)

### Why Brute Force is Impractical
- Exponential in n
- Doesn't properly handle K negations (can negate same element multiple times)

---

## Optimal Greedy Approach

```python
import heapq

def max_sum_k_negations(arr, k):
    """
    Maximize array sum with exactly K negations.
    
    Greedy: Always negate the minimum element.
    Use min-heap for efficient minimum finding.
    
    Time: O(K log n + n)
    Space: O(n) for heap
    """
    # Build min-heap
    heapq.heapify(arr)
    
    # Perform K negations
    for _ in range(k):
        # Pop minimum, negate, push back
        min_val = heapq.heappop(arr)
        heapq.heappush(arr, -min_val)
    
    return sum(arr)
```

**Time Complexity:** O(K log n + n)
**Space Complexity:** O(1) if modifying in place

### Optimized Version (O(n log n)):

```python
def max_sum_k_negations_optimized(arr, k):
    """
    Optimized: Only need at most n+1 negations to reach stable state.
    
    After flipping all negatives, if K remains:
    - Even K: no effect (flip smallest twice)
    - Odd K: flip smallest once
    """
    arr.sort()
    
    # Flip negatives from most negative
    i = 0
    while i < len(arr) and k > 0 and arr[i] < 0:
        arr[i] = -arr[i]
        k -= 1
        i += 1
    
    # If K remaining and odd, flip smallest absolute value
    if k % 2 == 1:
        arr.sort()  # Re-sort to find new minimum
        arr[0] = -arr[0]
    
    return sum(arr)
```

**Time Complexity:** O(n log n)
**Space Complexity:** O(1)

---

## Dry Run with Selection Visualization

**Input:**
```
arr = [4, -3, 2, -5, 1], K = 4
```

**Step 1: Sort Array**
```
Sorted: [-5, -3, 1, 2, 4]
K = 4
```

**Step 2: Negate Negatives**
```
Iteration 1:
  Min = -5 (negative)
  Negate: -5 -> 5
  Array: [5, -3, 1, 2, 4] (unsorted internally)
  K = 3

Iteration 2:
  Min = -3 (negative)
  Negate: -3 -> 3
  Array: [5, 3, 1, 2, 4]
  K = 2

Iteration 3:
  Min = 1 (positive!)
  Negate: 1 -> -1
  Array: [5, 3, -1, 2, 4]
  K = 1

Iteration 4:
  Min = -1 (negative)
  Negate: -1 -> 1
  Array: [5, 3, 1, 2, 4]
  K = 0
```

**Step 3: Calculate Sum**
```
Sum = 5 + 3 + 1 + 2 + 4 = 15
```

**Visualization:**
```
Initial:    [4, -3, 2, -5, 1]  K=4  Sum=4-3+2-5+1=-1

After sort: [-5, -3, 1, 2, 4]

K=4: Negate -5 -> 5    [5, -3, 1, 2, 4]   Sum=9
K=3: Negate -3 -> 3    [5, 3, 1, 2, 4]    Sum=15
K=2: Negate 1 -> -1    [5, 3, -1, 2, 4]   Sum=13
K=1: Negate -1 -> 1    [5, 3, 1, 2, 4]    Sum=15

Final: K=0, Sum=15
```

---

## Time and Space Complexity

| Approach | Time | Space | Notes |
|----------|------|-------|-------|
| Brute Force | O(2^n) | O(1) | Exponential, impractical |
| Heap-based | O(K log n) | O(n) | Good for small K |
| Optimized | O(n log n) | O(1) | Best for large K |

### Breakdown of Optimized Approach:
- **Sort:** O(n log n)
- **Flip negatives:** O(n)
- **Re-sort (if needed):** O(n log n)
- **Sum:** O(n)
- **Total:** O(n log n)

---

## Edge Cases

| Case | Handling |
|------|----------|
| K = 0 | Return original sum |
| All positives | Flip smallest K times (or just once if K odd) |
| All negatives | Flip all, then handle remaining K |
| Contains 0 | Use 0 as a "sink" for remaining K |
| K > n | Some elements flipped multiple times |

---

## Variations and Extensions

### 1. Maximize Sum with At Most K Negations
Can perform 0 to K negations (not exactly K).
- Simpler: just flip negatives, stop when beneficial

### 2. Minimize Sum with K Negations
Opposite strategy: flip positives from largest.

### 3. K Negations with Limited Flips per Element
Each element can be flipped at most once.

### 4. Maximize Product After K Negations
Different problem - need to handle signs carefully.

### 5. Maximize Sum with K Increments
Instead of negation, can add 1 to any element K times.
