"""
Maximize Sum After K Negations - Greedy Algorithm
==================================================

Problem: Given an array of integers and K, maximize the sum of the array
after performing exactly K negations. A negation flips the sign of an element.

WHY GREEDY WORKS:
----------------
1. Negating a negative number: increases sum by 2*|num|
2. Negating a positive number: decreases sum by 2*|num|
3. Negating zero: no change (use as a "sink" for extra K)

GREEDY STRATEGY: Always negate the minimum element.
- If minimum is negative: negating increases sum (best choice)
- If minimum is zero: negating has no effect (perfect for remaining K)
- If minimum is positive: negating decreases sum minimally (least damage)

This greedy choice is optimal because:
- Exchange argument: swapping to negate a larger element never helps
- Each negation step is locally optimal and leads to global optimum
"""

from typing import List, Tuple
import heapq


def max_sum_k_negations_heap(arr: List[int], k: int) -> int:
    """
    Maximize sum with exactly K negations using min-heap.

    Greedy: Pop minimum, negate, push back. Repeat K times.

    Time: O(K log n + n)
    Space: O(n) for heap

    Example:
    >>> max_sum_k_negations_heap([4, -3, 2, -5, 1], 4)
    15
    >>> max_sum_k_negations_heap([3, -1, 0, 2], 3)
    6
    """
    # Build min-heap (heapify is O(n))
    heap = arr.copy()
    heapq.heapify(heap)

    # Perform K negations
    for _ in range(k):
        # Pop minimum, negate, push back
        min_val = heapq.heappop(heap)
        heapq.heappush(heap, -min_val)

    return sum(heap)


def max_sum_k_negations_optimized(arr: List[int], k: int) -> int:
    """
    Optimized version using sorting (better for large K).

    Key insight: After all negatives become positive, remaining K only
    affects the smallest element. If K is even, no net change. If odd,
    one final negation of smallest.

    Time: O(n log n)
    Space: O(1) if we modify in place

    Example:
    >>> max_sum_k_negations_optimized([4, -3, 2, -5, 1], 4)
    15
    """
    arr = arr.copy()  # Don't modify original
    arr.sort()

    # Phase 1: Negate negatives from most negative to least
    i = 0
    while i < len(arr) and k > 0 and arr[i] < 0:
        arr[i] = -arr[i]
        k -= 1
        i += 1

    # Phase 2: Handle remaining K
    if k > 0 and k % 2 == 1:
        # Odd K remaining: must negate smallest absolute value once
        arr.sort()  # Re-sort to find new minimum
        arr[0] = -arr[0]

    return sum(arr)


def max_sum_k_negations_with_details(
    arr: List[int],
    k: int
) -> Tuple[int, List[int], List[Tuple[int, int, int]]]:
    """
    Returns max sum, final array, and negation history.

    History format: [(step, old_value, new_value), ...]

    Example:
    >>> max_sum, final, history = max_sum_k_negations_with_details([4, -3, 2, -5, 1], 4)
    >>> max_sum
    15
    """
    heap = arr.copy()
    heapq.heapify(heap)
    history = []

    for step in range(1, k + 1):
        min_val = heapq.heappop(heap)
        new_val = -min_val
        history.append((step, min_val, new_val))
        heapq.heappush(heap, new_val)

    final_arr = sorted(heap)  # Return sorted for clarity
    return sum(heap), final_arr, history


def max_sum_k_negations_no_sort(arr: List[int], k: int) -> int:
    """
    Version without sorting - pure heap operations.

    This is actually more general but same complexity.
    """
    import heapq

    heap = arr.copy()
    heapq.heapify(heap)

    for _ in range(k):
        min_val = heapq.heappop(heap)
        heapq.heappush(heap, -min_val)

    return sum(heap)


# =============================================================================
# BRUTE FORCE COMPARISON
# =============================================================================

def max_sum_k_negations_brute(arr: List[int], k: int) -> int:
    """
    Brute force: Try all possible sequences of K negations.

    Note: This explores all n^k possibilities (with repetition).
    Very expensive!

    Time: O(n^k)
    Space: O(k) for recursion
    """
    def backtrack(arr, remaining_k):
        if remaining_k == 0:
            return sum(arr)

        max_sum = float('-inf')
        for i in range(len(arr)):
            # Negate element i
            arr[i] = -arr[i]
            max_sum = max(max_sum, backtrack(arr, remaining_k - 1))
            # Backtrack
            arr[i] = -arr[i]

        return max_sum

    return backtrack(arr.copy(), k)


def max_sum_k_negations_brute_optimized(arr: List[int], k: int) -> int:
    """
    Slightly optimized brute force using memoization.

    State: (tuple of array, remaining k)
    """
    from functools import lru_cache

    @lru_cache(maxsize=None)
    def solve(arr_tuple, remaining):
        if remaining == 0:
            return sum(arr_tuple)

        arr = list(arr_tuple)
        max_sum = float('-inf')

        for i in range(len(arr)):
            arr[i] = -arr[i]
            max_sum = max(max_sum, solve(tuple(arr), remaining - 1))
            arr[i] = -arr[i]

        return max_sum

    return solve(tuple(arr), k)


# =============================================================================
# VARIATIONS
# =============================================================================

def max_sum_at_most_k_negations(arr: List[int], k: int) -> int:
    """
    Maximize sum with AT MOST K negations (not exactly K).

    Strategy: Only negate negatives, stop when all positive.

    Example:
    >>> max_sum_at_most_k_negations([-1, 2, 3], 5)
    6  # Just negate -1, ignore remaining 4 negations
    """
    arr = arr.copy()
    arr.sort()

    for i in range(len(arr)):
        if k <= 0 or arr[i] >= 0:
            break
        arr[i] = -arr[i]
        k -= 1

    return sum(arr)


def min_sum_k_negations(arr: List[int], k: int) -> int:
    """
    MINIMIZE sum with exactly K negations.

    Opposite strategy: negate the MAXIMUM element each time.

    Example:
    >>> min_sum_k_negations([4, -3, 2, -5, 1], 4)
    -15
    """
    # Use max-heap (negate values for min-heap)
    heap = [-x for x in arr]
    heapq.heapify(heap)

    for _ in range(k):
        max_val = -heapq.heappop(heap)
        heapq.heappush(heap, max_val)  # Push negated (which is -(-max_val))

    return sum(-x for x in heap)


def max_sum_k_negations_limited(arr: List[int], k: int) -> int:
    """
    Maximize sum with K negations, each element can be negated at most once.

    Different problem! Greedy still works but with constraint.

    Example:
    >>> max_sum_k_negations_limited([-1, -2, -3], 2)
    4  # Negate -3 and -2, keep -1
    """
    arr = sorted(arr)  # Sort ascending
    negated = [False] * len(arr)

    for _ in range(k):
        # Find minimum that hasn't been negated
        min_idx = -1
        min_val = float('inf')

        for i in range(len(arr)):
            val = -arr[i] if negated[i] else arr[i]
            if val < min_val:
                min_val = val
                min_idx = i

        if min_idx != -1:
            negated[min_idx] = not negated[min_idx]

    total = 0
    for i in range(len(arr)):
        total += -arr[i] if negated[i] else arr[i]

    return total


def count_ways_to_max_sum(arr: List[int], k: int) -> int:
    """
    Count number of different ways to achieve maximum sum.

    This is more complex - need to track equivalent sequences.
    """
    # Simplified version - just count if zeros exist
    max_sum = max_sum_k_negations_heap(arr, k)

    zero_count = arr.count(0)
    if zero_count > 0:
        # Multiple ways using zeros
        return -1  # Infinite ways if we can keep toggling zero

    return 1  # Usually unique way


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Comprehensive test cases with explanations."""

    print("=" * 60)
    print("MAXIMIZE SUM AFTER K NEGATIONS - TEST CASES")
    print("=" * 60)

    # Test 1: Basic mixed array
    print("\nTest 1: Basic Mixed Array")
    print("-" * 40)
    arr = [4, -3, 2, -5, 1]
    k = 4
    result = max_sum_k_negations_heap(arr, k)
    print(f"Array: {arr}")
    print(f"K: {k}")
    print(f"Maximum sum: {result}")
    print(f"Explanation: Negate -5, -3, then toggle smallest twice")
    assert result == 15, f"Expected 15, got {result}"

    # Test 2: With zero
    print("\nTest 2: Array with Zero")
    print("-" * 40)
    arr = [3, -1, 0, 2]
    k = 3
    result = max_sum_k_negations_heap(arr, k)
    print(f"Array: {arr}")
    print(f"K: {k}")
    print(f"Maximum sum: {result}")
    print(f"Explanation: Negate -1, then use 0 for remaining 2 negations")
    assert result == 6, f"Expected 6, got {result}"

    # Test 3: All positive
    print("\nTest 3: All Positive")
    print("-" * 40)
    arr = [1, 2, 3, 4]
    k = 3
    result = max_sum_k_negations_heap(arr, k)
    print(f"Array: {arr}")
    print(f"K: {k}")
    print(f"Maximum sum: {result}")
    # K=3 (odd): must negate smallest (1) once, net effect
    # Actually: negate 1 three times = -1
    # Sum = -1 + 2 + 3 + 4 = 8

    # Test 4: All negative
    print("\nTest 4: All Negative")
    print("-" * 40)
    arr = [-1, -2, -3, -4]
    k = 2
    result = max_sum_k_negations_heap(arr, k)
    print(f"Array: {arr}")
    print(f"K: {k}")
    print(f"Maximum sum: {result}")
    print(f"Explanation: Negate -4 and -3, sum = -1 + -2 + 3 + 4 = 4")
    assert result == 4, f"Expected 4, got {result}"

    # Test 5: Single element
    print("\nTest 5: Single Element")
    print("-" * 40)
    arr = [-5]
    k = 3
    result = max_sum_k_negations_heap(arr, k)
    print(f"Array: {arr}")
    print(f"K: {k}")
    print(f"Maximum sum: {result}")
    # K=3 (odd): final value is 5
    assert result == 5, f"Expected 5, got {result}"

    # Test 6: K = 0
    print("\nTest 6: K = 0")
    print("-" * 40)
    arr = [-1, 2, -3, 4]
    k = 0
    result = max_sum_k_negations_heap(arr, k)
    print(f"Array: {arr}")
    print(f"K: {k}")
    print(f"Maximum sum: {result}")
    assert result == sum(arr), f"Expected {sum(arr)}, got {result}"

    # Test 7: Compare heap vs optimized
    print("\nTest 7: Heap vs Optimized Solution")
    print("-" * 40)
    arr = [-4, -3, -2, 1, 5]
    k = 5
    heap_result = max_sum_k_negations_heap(arr, k)
    opt_result = max_sum_k_negations_optimized(arr, k)
    print(f"Array: {arr}")
    print(f"K: {k}")
    print(f"Heap result: {heap_result}")
    print(f"Optimized result: {opt_result}")
    assert heap_result == opt_result, "Results should match!"

    # Test 8: Compare with brute force (small input)
    print("\nTest 8: Greedy vs Brute Force")
    print("-" * 40)
    arr = [-2, 1, 3]
    k = 2
    greedy = max_sum_k_negations_heap(arr, k)
    brute = max_sum_k_negations_brute(arr, k)
    print(f"Array: {arr}")
    print(f"K: {k}")
    print(f"Greedy: {greedy}")
    print(f"Brute force: {brute}")
    assert greedy == brute, "Should match!"

    # Test 9: Detailed output
    print("\nTest 9: Detailed Solution")
    print("-" * 40)
    arr = [4, -3, 2, -5, 1, -1]
    k = 4
    max_sum, final_arr, history = max_sum_k_negations_with_details(arr, k)
    print(f"Array: {arr}")
    print(f"K: {k}")
    print(f"History:")
    for step, old, new in history:
        print(f"  Step {step}: {old} -> {new}")
    print(f"Final array: {final_arr}")
    print(f"Maximum sum: {max_sum}")

    # Test 10: Large K
    print("\nTest 10: Large K")
    print("-" * 40)
    arr = [-1, 2, 3]
    k = 100
    result = max_sum_k_negations_heap(arr, k)
    print(f"Array: {arr}")
    print(f"K: {k}")
    print(f"Maximum sum: {result}")
    # After negating -1 once, remaining 99 negations on 1 (smallest positive)
    # 99 is odd, so final state has 1 negated
    # Sum = 1 + 2 + 3 - 2 = 4 (if 1 was negated) OR
    # Actually: -1 -> 1, then 1 gets toggled 99 times
    # 99 is odd, so 1 -> -1
    # Sum = -1 + 2 + 3 = 4

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_greedy_choice():
    """Step-by-step demonstration of greedy negation."""

    print("\n" + "=" * 60)
    print("DEMONSTRATION: GREEDY K NEGATIONS")
    print("=" * 60)

    arr = [4, -3, 2, -5, 1]
    k = 4

    print(f"\nInitial array: {arr}")
    print(f"Initial sum: {sum(arr)}")
    print(f"K negations: {k}")

    heap = arr.copy()
    heapq.heapify(heap)

    print("\nGreedy Negation Process:")
    print("-" * 50)

    for i in range(k):
        min_val = heapq.heappop(heap)
        new_val = -min_val

        print(f"\nStep {i + 1}:")
        print(f"  Minimum element: {min_val}")

        if min_val < 0:
            gain = -2 * min_val
            print(f"  Negating negative -> gain +{gain}")
        elif min_val == 0:
            print(f"  Negating zero -> no change (using as sink)")
        else:
            loss = 2 * min_val
            print(f"  Negating positive -> loss -{loss}")

        heapq.heappush(heap, new_val)
        current_sum = sum(heap)
        print(f"  {min_val} -> {new_val}")
        print(f"  Current array (heap): {sorted(heap)}")
        print(f"  Current sum: {current_sum}")

    print("\n" + "-" * 50)
    print(f"Final array: {sorted(heap)}")
    print(f"Maximum sum: {sum(heap)}")

    print("\nWHY THIS IS OPTIMAL:")
    print("At each step, negating the minimum is the best choice:")
    print("- If negative: maximum gain (largest increase to sum)")
    print("- If zero: no loss (perfect sink for extra K)")
    print("- If positive: minimum loss (smallest decrease to sum)")


if __name__ == "__main__":
    run_tests()
    demonstrate_greedy_choice()
