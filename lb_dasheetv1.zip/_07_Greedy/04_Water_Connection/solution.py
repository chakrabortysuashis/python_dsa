"""
Water Connection Problem - Greedy Algorithm
===========================================

Problem: Given houses connected by pipes, find the minimum tank configurations
needed to supply water to all sinks. Each path from source to sink has a
bottleneck (minimum diameter pipe) that determines required tank capacity.

WHY GREEDY WORKS:
----------------
1. Graph Structure: Each house has at most one incoming and one outgoing pipe.
   This creates simple linear chains, not complex graphs.

2. Unique Paths: There's exactly one path from each source to its sink.
   No need to consider alternative routes.

3. Bottleneck Principle: The minimum diameter pipe in a path determines the
   maximum flow. We greedily track this minimum along each path.

4. Component Independence: Each connected component can be solved independently.
   Local optimal = Global optimal.

GREEDY STRATEGY:
- Find all sources (in-degree = 0, out-degree > 0)
- Trace path from each source to its sink
- Track minimum diameter (bottleneck) along the way
"""

from typing import List, Tuple, Dict
from collections import defaultdict


def water_connection(n: int, pipes: List[Tuple[int, int, int]]) -> List[Tuple[int, int, int]]:
    """
    Find minimum tank configurations for water distribution.

    Greedy Strategy:
    1. Build graph and compute in-degrees
    2. Find all sources (in-degree = 0)
    3. For each source, trace path to sink tracking minimum diameter

    Args:
        n: Number of houses
        pipes: List of (from_house, to_house, diameter) tuples

    Returns:
        List of (source, sink, min_diameter) tuples

    Time: O(n + p) where p = number of pipes
    Space: O(n + p)

    Example:
    >>> pipes = [(7,4,98), (5,9,72), (4,6,10), (2,8,22), (9,7,17), (3,1,66)]
    >>> result = water_connection(9, pipes)
    >>> len(result)
    3
    """
    if not pipes:
        return []

    # Build adjacency list and track in-degrees
    adj: Dict[int, Tuple[int, int]] = {}  # adj[a] = (b, diameter)
    in_degree: Dict[int, int] = defaultdict(int)

    for from_house, to_house, diameter in pipes:
        adj[from_house] = (to_house, diameter)
        in_degree[to_house] += 1

    # Find all sources: houses with outgoing edges but no incoming edges
    sources = [house for house in adj if in_degree[house] == 0]

    results = []

    for source in sources:
        # Traverse path from source to sink
        current = source
        min_diameter = float('inf')

        # Follow the chain until we reach a sink (no outgoing edge)
        while current in adj:
            next_house, diameter = adj[current]
            min_diameter = min(min_diameter, diameter)
            current = next_house

        # current is now the sink
        sink = current
        results.append((source, sink, min_diameter))

    return results


def water_connection_detailed(
    n: int,
    pipes: List[Tuple[int, int, int]]
) -> Tuple[int, List[Dict]]:
    """
    Detailed water connection analysis with path information.

    Returns:
        (number_of_tanks, list of detailed tank info dicts)
    """
    if not pipes:
        return 0, []

    adj = {}
    in_degree = defaultdict(int)

    for from_house, to_house, diameter in pipes:
        adj[from_house] = (to_house, diameter)
        in_degree[to_house] += 1

    sources = [house for house in adj if in_degree[house] == 0]

    tank_info = []

    for source in sources:
        path = [source]
        diameters = []
        current = source
        min_diameter = float('inf')
        bottleneck_position = -1

        while current in adj:
            next_house, diameter = adj[current]
            diameters.append(diameter)
            path.append(next_house)

            if diameter < min_diameter:
                min_diameter = diameter
                bottleneck_position = len(diameters) - 1

            current = next_house

        sink = current

        tank_info.append({
            'source': source,
            'sink': sink,
            'min_diameter': min_diameter,
            'path': path,
            'diameters': diameters,
            'bottleneck_position': bottleneck_position,
            'path_length': len(path) - 1
        })

    return len(tank_info), tank_info


def verify_water_distribution(
    n: int,
    pipes: List[Tuple[int, int, int]],
    tanks: List[Tuple[int, int, int]]
) -> bool:
    """
    Verify that the tank configuration correctly supplies all sinks.

    Args:
        n: Number of houses
        pipes: List of pipe connections
        tanks: Proposed tank configuration

    Returns:
        True if configuration is valid and complete
    """
    adj = {}
    all_houses = set()
    sinks = set()

    for from_house, to_house, _ in pipes:
        adj[from_house] = to_house
        all_houses.add(from_house)
        all_houses.add(to_house)

    # Find actual sinks (houses with no outgoing pipe)
    for house in all_houses:
        if house not in adj:
            sinks.add(house)

    # Check if each sink is covered by a tank
    covered_sinks = set()
    for source, sink, diameter in tanks:
        # Verify path exists
        current = source
        path_exists = False
        min_d = float('inf')

        while current in adj:
            next_house = adj[current]
            # Find diameter of this pipe
            for a, b, d in pipes:
                if a == current and b == next_house:
                    min_d = min(min_d, d)
                    break
            current = next_house

        if current == sink:
            path_exists = True
            covered_sinks.add(sink)

            # Verify diameter is correct
            if min_d != diameter:
                return False

    return covered_sinks == sinks


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Comprehensive test cases with explanations."""

    print("=" * 60)
    print("WATER CONNECTION PROBLEM - TEST CASES")
    print("=" * 60)

    # Test 1: Classic example
    print("\nTest 1: Classic Example")
    print("-" * 40)
    pipes = [(7, 4, 98), (5, 9, 72), (4, 6, 10), (2, 8, 22), (9, 7, 17), (3, 1, 66)]

    result = water_connection(9, pipes)
    print(f"Pipes: {pipes}")
    print(f"\nResults (source, sink, min_diameter):")
    for source, sink, diameter in sorted(result):
        print(f"  Tank at {source} -> Sink at {sink}, diameter: {diameter}")

    assert len(result) == 3
    # Verify the results include expected configurations
    result_set = {(s, t, d) for s, t, d in result}
    assert (2, 8, 22) in result_set
    assert (3, 1, 66) in result_set
    assert (5, 6, 10) in result_set

    # Test 2: Detailed analysis
    print("\nTest 2: Detailed Path Analysis")
    print("-" * 40)
    n_tanks, details = water_connection_detailed(9, pipes)
    print(f"Number of tanks needed: {n_tanks}")
    for info in details:
        print(f"\n  Source: {info['source']}")
        print(f"  Sink: {info['sink']}")
        print(f"  Path: {' -> '.join(map(str, info['path']))}")
        print(f"  Diameters: {info['diameters']}")
        print(f"  Bottleneck at position {info['bottleneck_position']}: {info['min_diameter']}")

    # Test 3: Single pipe
    print("\nTest 3: Single Pipe")
    print("-" * 40)
    pipes = [(1, 2, 50)]
    result = water_connection(2, pipes)
    print(f"Single pipe: {pipes}")
    print(f"Result: {result}")
    assert result == [(1, 2, 50)]

    # Test 4: Multiple independent chains
    print("\nTest 4: Multiple Independent Chains")
    print("-" * 40)
    pipes = [
        (1, 2, 100),
        (2, 3, 50),
        (4, 5, 75),
        (5, 6, 75)
    ]
    result = water_connection(6, pipes)
    print(f"Two chains: {pipes}")
    print(f"Results: {result}")
    assert len(result) == 2

    # Test 5: Empty input
    print("\nTest 5: Empty Input")
    print("-" * 40)
    result = water_connection(0, [])
    print(f"Empty input result: {result}")
    assert result == []

    # Test 6: Verification
    print("\nTest 6: Result Verification")
    print("-" * 40)
    pipes = [(7, 4, 98), (5, 9, 72), (4, 6, 10), (2, 8, 22), (9, 7, 17), (3, 1, 66)]
    result = water_connection(9, pipes)
    is_valid = verify_water_distribution(9, pipes, result)
    print(f"Verification result: {is_valid}")
    assert is_valid

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_greedy_choice():
    """Step-by-step demonstration of the algorithm."""

    print("\n" + "=" * 60)
    print("DEMONSTRATION: WHY GREEDY WORKS")
    print("=" * 60)

    pipes = [(7, 4, 98), (5, 9, 72), (4, 6, 10), (2, 8, 22), (9, 7, 17), (3, 1, 66)]

    print("\nInput pipes:")
    for from_h, to_h, d in pipes:
        print(f"  {from_h} --[{d}]--> {to_h}")

    # Build graph
    adj = {}
    in_degree = defaultdict(int)

    for from_h, to_h, d in pipes:
        adj[from_h] = (to_h, d)
        in_degree[to_h] += 1

    print("\n" + "-" * 40)
    print("STEP 1: Find Sources (in-degree = 0)")
    print("-" * 40)

    print("Houses with outgoing pipes:", list(adj.keys()))
    print("In-degrees:", dict(in_degree))

    sources = [h for h in adj if in_degree[h] == 0]
    print(f"Sources found: {sources}")

    print("\n" + "-" * 40)
    print("STEP 2: Trace Paths and Find Bottlenecks")
    print("-" * 40)

    for source in sources:
        print(f"\nStarting from source {source}:")
        current = source
        min_d = float('inf')
        path_str = str(source)

        while current in adj:
            next_h, d = adj[current]
            path_str += f" --[{d}]--> {next_h}"

            print(f"  {current} -> {next_h}, diameter = {d}")

            if d < min_d:
                print(f"    NEW MINIMUM! {d} < {min_d}")
                min_d = d
            else:
                print(f"    Current min {min_d} still holds")

            current = next_h

        print(f"\n  Complete path: {path_str}")
        print(f"  Sink reached: {current}")
        print(f"  BOTTLENECK (min diameter): {min_d}")
        print(f"  Tank config: ({source}, {current}, {min_d})")

    print("\n" + "-" * 40)
    print("WHY THIS IS GREEDY:")
    print("-" * 40)
    print("1. We process each source independently (greedy decomposition)")
    print("2. We track minimum diameter greedily along the path")
    print("3. No backtracking needed - unique path from source to sink")
    print("4. Local solution for each component = global optimal")


if __name__ == "__main__":
    run_tests()
    demonstrate_greedy_choice()
