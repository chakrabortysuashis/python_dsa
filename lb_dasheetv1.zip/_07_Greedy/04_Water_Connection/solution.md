# Water Connection Problem

## Problem Statement

Every house in a colony has a pipeline that can carry water. Some pipelines are water sources which can provide water, and some pipelines are water sinks which can receive water. Given `n` houses and `p` pipeline connections between them, find the minimum diameter of pipes to install so that each sink receives water from some source.

**Input:**
- `n`: Number of houses
- `p`: Number of pipe connections
- Each connection: `(house_a, house_b, diameter)` - pipe from a to b with given diameter

**Output:**
- Number of tanks (sources) needed
- For each tank: `(source_house, sink_house, min_diameter_in_path)`

**Constraints:**
- A house is a source if it has outgoing pipes but no incoming pipes
- A house is a sink if it has incoming pipes but no outgoing pipes
- Water flows from source to sink through the path

**Example:**
```
n = 9, p = 6
Connections:
  7 -> 4 (diameter 98)
  5 -> 9 (diameter 72)
  4 -> 6 (diameter 10)
  2 -> 8 (diameter 22)
  9 -> 7 (diameter 17)
  3 -> 1 (diameter 66)

Output:
3 tanks needed
  3 -> 1 (min diameter: 66)
  2 -> 8 (min diameter: 22)
  5 -> 6 (min diameter: 10)  [path: 5->9->7->4->6]
```

---

## Why Greedy Works Here

### The Greedy Insight

This problem is essentially about **finding connected components** in a directed graph where:
- Each component has exactly one source (in-degree 0) and one sink (out-degree 0)
- The minimum diameter in the path from source to sink determines the tank size needed

**Greedy Strategy:**
1. Find all sources (no incoming edges)
2. From each source, follow the path to sink
3. Track minimum diameter along the path (bottleneck)

### Why This Is Greedy

The "greedy" aspect here is:
- **We don't need to consider alternative paths** - there's only one path from source to sink in each component
- **The bottleneck determines tank capacity** - we greedily minimize based on the weakest link
- **Process components independently** - solving locally gives global solution

### Graph Structure Insight

The problem guarantees:
- Each house has at most one outgoing pipe
- Each house has at most one incoming pipe
- This forms simple chains (not trees or complex graphs)

---

## Greedy Choice Property Explanation

### Finding Sources and Sinks

```
Source: in_degree[house] = 0 AND out_degree[house] > 0
Sink:   out_degree[house] = 0 AND in_degree[house] > 0
```

### Path Traversal

For each source:
1. Follow the unique outgoing edge
2. Track minimum diameter seen so far
3. Continue until reaching a sink
4. This minimum diameter is the required tank size

### Why Minimum Diameter?

```
Source --[100]--> A --[50]--> B --[80]--> Sink

The effective flow capacity = min(100, 50, 80) = 50
We need a tank that can supply 50 units of flow.
```

---

## Step-by-Step Algorithm

```
1. BUILD adjacency list and track in-degrees
   - adj[a] = (b, diameter) for pipe a -> b
   - in_degree[b]++ for each connection

2. FIND all sources
   - Houses with in_degree = 0 AND have outgoing edges

3. FOR each source:
   a. TRAVERSE path using DFS/iteration
   b. TRACK minimum diameter along path
   c. STOP when reaching sink (no outgoing edge)
   d. STORE (source, sink, min_diameter)

4. RETURN list of (source, sink, min_diameter) tuples
```

---

## Brute Force Comparison

### Alternative Approaches

Since the graph structure is simple (linear chains), there's no real "brute force" that's substantially different. However, without recognizing the structure:

**Approach 1: General Graph Traversal**
- Run BFS/DFS from every node
- Find all paths between all pairs
- Inefficient: O(n^2) paths possible in general graphs

**Approach 2: Flow Network**
- Model as max-flow problem
- Use Ford-Fulkerson or similar
- Overkill for this simple structure

### Why Simple Traversal Works

The constraint "each house has at most one pipe going in and one going out" guarantees:
- No branching: exactly one path from source to sink
- No cycles within a component
- Linear time traversal

---

## Optimal Greedy Approach

```python
def water_connection(n, pipes):
    """
    Find minimum tank configurations for water distribution.
    
    Args:
        n: Number of houses
        pipes: List of (from_house, to_house, diameter)
    
    Returns:
        List of (source, sink, min_diameter) tuples
    """
    from collections import defaultdict
    
    # Build graph
    adj = {}  # adj[a] = (b, diameter)
    in_degree = defaultdict(int)
    
    for a, b, diameter in pipes:
        adj[a] = (b, diameter)
        in_degree[b] += 1
    
    # Find sources (in_degree = 0 and has outgoing edge)
    sources = [house for house in adj if in_degree[house] == 0]
    
    result = []
    
    for source in sources:
        # Traverse from source to sink
        current = source
        min_diameter = float('inf')
        
        while current in adj:
            next_house, diameter = adj[current]
            min_diameter = min(min_diameter, diameter)
            current = next_house
        
        # current is now the sink
        sink = current
        result.append((source, sink, min_diameter))
    
    return result
```

**Time Complexity:** O(n + p)
**Space Complexity:** O(n + p)

---

## Dry Run with Selection Visualization

**Input:**
```
n = 9 houses
Connections:
  7 -> 4 (98)
  5 -> 9 (72)
  4 -> 6 (10)
  2 -> 8 (22)
  9 -> 7 (17)
  3 -> 1 (66)
```

### Step 1: Build Graph

```
Adjacency List:
  7 -> (4, 98)
  5 -> (9, 72)
  4 -> (6, 10)
  2 -> (8, 22)
  9 -> (7, 17)
  3 -> (1, 66)

In-degrees:
  1: 1 (from 3)
  4: 1 (from 7)
  6: 1 (from 4)
  7: 1 (from 9)
  8: 1 (from 2)
  9: 1 (from 5)
```

### Step 2: Find Sources

```
Houses with out-degree > 0: 2, 3, 4, 5, 7, 9
Houses with in-degree = 0:  2, 3, 5

Sources: [2, 3, 5]
```

### Step 3: Traverse Each Source

```
========================================
SOURCE 2:
========================================
Path: 2 -> 8
  2 --[22]--> 8 (8 has no outgoing edge = SINK)
  
Min diameter: 22
Result: (2, 8, 22)

========================================
SOURCE 3:
========================================
Path: 3 -> 1
  3 --[66]--> 1 (1 has no outgoing edge = SINK)
  
Min diameter: 66
Result: (3, 1, 66)

========================================
SOURCE 5:
========================================
Path: 5 -> 9 -> 7 -> 4 -> 6
  5 --[72]--> 9, min_d = 72
  9 --[17]--> 7, min_d = min(72, 17) = 17
  7 --[98]--> 4, min_d = min(17, 98) = 17
  4 --[10]--> 6, min_d = min(17, 10) = 10
  6 has no outgoing edge = SINK
  
Min diameter: 10
Result: (5, 6, 10)
```

### Final Output

```
3 tanks needed:
  Tank 1: Source=2, Sink=8, Diameter=22
  Tank 2: Source=3, Sink=1, Diameter=66
  Tank 3: Source=5, Sink=6, Diameter=10

Visual:
  2 --[22]--> 8

  3 --[66]--> 1

  5 --[72]--> 9 --[17]--> 7 --[98]--> 4 --[10]--> 6
                                         ^
                                     bottleneck!
```

---

## Time and Space Complexity

### Time Complexity: O(n + p)

| Operation | Complexity |
|-----------|------------|
| Build adjacency list | O(p) |
| Compute in-degrees | O(p) |
| Find sources | O(n) |
| Traverse all paths | O(n) total |
| **Total** | **O(n + p)** |

### Space Complexity: O(n + p)

| Storage | Complexity |
|---------|------------|
| Adjacency list | O(p) |
| In-degree array | O(n) |
| Result list | O(k) where k = # components |
| **Total** | **O(n + p)** |

---

## Variations and Extensions

### 1. Bidirectional Pipes
If pipes can flow both ways, the problem becomes finding minimum spanning tree for each component.

### 2. Multiple Paths
If multiple paths exist between source and sink, use max-flow algorithms to find optimal distribution.

### 3. Weighted Tanks
If installing tanks has different costs, this becomes an optimization problem requiring more complex algorithms.

### 4. Dynamic Pipes
If pipe diameters can be upgraded with costs, this becomes a graph optimization problem.

### Key Insight for Interviews
This problem tests:
1. Graph representation skills
2. Understanding of in-degree/out-degree
3. Linear chain traversal
4. Bottleneck detection in paths
