"""
Minimum Number of Coins - Greedy Algorithm
==========================================

Problem: Given a target amount V and coin denominations, find the minimum
number of coins needed to make change for V.

WHY GREEDY WORKS (for canonical coin systems):
---------------------------------------------
1. Canonical Systems: Standard currencies (1,5,10,25) are designed so that
   greedy always gives optimal results.

2. Efficient Design: Each coin value efficiently covers gaps between larger
   denominations without overlap that would make greedy suboptimal.

3. No Trade-offs: Using larger coins is always beneficial - you can't make
   the same amount with fewer coins using smaller denominations.

WHEN GREEDY FAILS:
-----------------
For non-canonical systems like [1, 3, 4], greedy may fail:
- V = 6: Greedy gives 4+1+1 = 3 coins
- Optimal: 3+3 = 2 coins

For general coins, use Dynamic Programming.

GREEDY STRATEGY (canonical systems only):
- Sort coins descending
- Use as many of each coin as possible, largest first
"""

from typing import List, Tuple, Optional


def min_coins_greedy(coins: List[int], V: int) -> int:
    """
    Minimum coins using greedy (ONLY for canonical coin systems).

    Greedy Strategy:
    1. Sort coins descending
    2. For each coin, use as many as possible
    3. Move to smaller coins

    Args:
        coins: List of coin denominations
        V: Target amount

    Returns:
        Minimum number of coins, or -1 if impossible

    Time: O(n) where n = number of coin types
    Space: O(1)

    WARNING: Only optimal for canonical coin systems!

    Example:
    >>> min_coins_greedy([1, 5, 10, 25, 50], 93)
    7
    """
    if V == 0:
        return 0
    if not coins:
        return -1

    sorted_coins = sorted(coins, reverse=True)
    count = 0
    remaining = V

    for coin in sorted_coins:
        if remaining == 0:
            break

        # Use as many of this coin as possible
        num_coins = remaining // coin
        count += num_coins
        remaining -= num_coins * coin

    return count if remaining == 0 else -1


def min_coins_greedy_detailed(
    coins: List[int],
    V: int
) -> Tuple[int, List[Tuple[int, int]]]:
    """
    Greedy minimum coins with coin breakdown.

    Returns:
        (total_count, list of (coin_value, count) tuples)

    Example:
    >>> count, breakdown = min_coins_greedy_detailed([1, 5, 10, 25, 50], 93)
    >>> count
    7
    >>> breakdown
    [(50, 1), (25, 1), (10, 1), (5, 1), (1, 3)]
    """
    if V == 0:
        return 0, []

    sorted_coins = sorted(coins, reverse=True)
    total_count = 0
    remaining = V
    breakdown = []

    for coin in sorted_coins:
        if remaining == 0:
            break

        num_coins = remaining // coin
        if num_coins > 0:
            breakdown.append((coin, num_coins))
            total_count += num_coins
            remaining -= num_coins * coin

    if remaining == 0:
        return total_count, breakdown
    return -1, []


def min_coins_dp(coins: List[int], V: int) -> int:
    """
    Minimum coins using Dynamic Programming (works for ALL coin systems).

    DP Recurrence:
    dp[i] = minimum coins to make amount i
    dp[i] = min(dp[i - coin] + 1) for all coins where coin <= i

    Args:
        coins: List of coin denominations
        V: Target amount

    Returns:
        Minimum number of coins, or -1 if impossible

    Time: O(V * n)
    Space: O(V)
    """
    if V == 0:
        return 0
    if not coins:
        return -1

    # dp[i] = min coins to make amount i
    dp = [float('inf')] * (V + 1)
    dp[0] = 0

    for i in range(1, V + 1):
        for coin in coins:
            if coin <= i and dp[i - coin] + 1 < dp[i]:
                dp[i] = dp[i - coin] + 1

    return dp[V] if dp[V] != float('inf') else -1


def compare_greedy_vs_dp(coins: List[int], V: int) -> dict:
    """
    Compare greedy and DP solutions to check if greedy is optimal.

    Returns dict with both solutions and whether they match.
    """
    greedy_result = min_coins_greedy(coins, V)
    dp_result = min_coins_dp(coins, V)

    return {
        'coins': coins,
        'amount': V,
        'greedy_result': greedy_result,
        'dp_result': dp_result,
        'greedy_is_optimal': greedy_result == dp_result,
        'coin_system_canonical': greedy_result == dp_result
    }


def find_greedy_failures(coins: List[int], max_amount: int) -> List[int]:
    """
    Find all amounts where greedy gives suboptimal result.

    Useful for verifying if a coin system is canonical.
    """
    failures = []

    for V in range(1, max_amount + 1):
        greedy = min_coins_greedy(coins, V)
        dp = min_coins_dp(coins, V)

        if greedy != dp:
            failures.append(V)

    return failures


def is_canonical_coin_system(coins: List[int]) -> bool:
    """
    Check if a coin system is canonical (greedy always optimal).

    A coin system is canonical if greedy works for all amounts.
    We only need to check up to the largest coin squared.
    """
    if not coins or 1 not in coins:
        return False

    max_check = max(coins) ** 2
    failures = find_greedy_failures(coins, max_check)
    return len(failures) == 0


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Comprehensive test cases with explanations."""

    print("=" * 60)
    print("MINIMUM COINS - TEST CASES")
    print("=" * 60)

    # Test 1: Standard US coins
    print("\nTest 1: Standard US Coins (Canonical)")
    print("-" * 40)
    coins = [1, 5, 10, 25, 50]
    V = 93

    result = min_coins_greedy(coins, V)
    count, breakdown = min_coins_greedy_detailed(coins, V)
    print(f"Coins: {coins}")
    print(f"Amount: {V} cents")
    print(f"Minimum coins (Greedy): {result}")
    print(f"Breakdown: {breakdown}")

    # Verify with DP
    dp_result = min_coins_dp(coins, V)
    print(f"Minimum coins (DP): {dp_result}")
    print(f"Greedy is optimal: {result == dp_result}")

    # Test 2: Non-canonical system
    print("\nTest 2: Non-Canonical System [1, 3, 4]")
    print("-" * 40)
    coins = [1, 3, 4]
    V = 6

    comparison = compare_greedy_vs_dp(coins, V)
    print(f"Coins: {coins}")
    print(f"Amount: {V}")
    print(f"Greedy result: {comparison['greedy_result']} coins")
    print(f"DP result (optimal): {comparison['dp_result']} coins")
    print(f"Greedy is optimal: {comparison['greedy_is_optimal']}")

    if not comparison['greedy_is_optimal']:
        print("GREEDY FAILS HERE!")
        greedy_count, greedy_breakdown = min_coins_greedy_detailed(coins, V)
        print(f"  Greedy would use: {greedy_breakdown}")
        print(f"  Optimal: 3 + 3 = 2 coins")

    # Test 3: Check canonical systems
    print("\nTest 3: Verify Canonical Systems")
    print("-" * 40)

    test_systems = [
        [1, 5, 10, 25],      # US coins (canonical)
        [1, 2, 5, 10, 20, 50],  # Euro coins (canonical)
        [1, 3, 4],           # Non-canonical
        [1, 7, 10],          # Non-canonical
    ]

    for sys in test_systems:
        is_canonical = is_canonical_coin_system(sys)
        print(f"  {sys}: {'Canonical' if is_canonical else 'NOT canonical'}")

    # Test 4: Edge cases
    print("\nTest 4: Edge Cases")
    print("-" * 40)

    # Zero amount
    result = min_coins_greedy([1, 5, 10], 0)
    print(f"Amount 0: {result} coins")
    assert result == 0

    # Amount equals single coin
    result = min_coins_greedy([1, 5, 10], 10)
    print(f"Amount 10 with coins [1,5,10]: {result} coins")
    assert result == 1

    # Large amount
    result = min_coins_greedy([1, 5, 10, 25, 50, 100], 999)
    print(f"Amount 999 with US coins: {result} coins")

    # Test 5: Find failures in non-canonical system
    print("\nTest 5: Find All Greedy Failures for [1, 3, 4]")
    print("-" * 40)
    coins = [1, 3, 4]
    failures = find_greedy_failures(coins, 20)
    print(f"Amounts where greedy fails: {failures}")

    for f in failures[:5]:  # Show first 5
        greedy = min_coins_greedy(coins, f)
        dp = min_coins_dp(coins, f)
        print(f"  V={f}: Greedy={greedy}, Optimal={dp}")

    print("\n" + "=" * 60)
    print("ALL TESTS COMPLETED!")
    print("=" * 60)


def demonstrate_greedy_choice():
    """Step-by-step demonstration of greedy approach."""

    print("\n" + "=" * 60)
    print("DEMONSTRATION: GREEDY COIN SELECTION")
    print("=" * 60)

    coins = [1, 5, 10, 25, 50]
    V = 93

    print(f"\nTarget: {V} cents")
    print(f"Coins available: {coins}")

    sorted_coins = sorted(coins, reverse=True)
    print(f"Sorted (descending): {sorted_coins}")

    print("\n" + "-" * 40)
    print("GREEDY SELECTION:")
    print("-" * 40)

    remaining = V
    total_count = 0
    selection = []

    for coin in sorted_coins:
        if remaining == 0:
            break

        num = remaining // coin
        if num > 0:
            print(f"\nCoin {coin}c:")
            print(f"  Remaining: {remaining}c")
            print(f"  {remaining} // {coin} = {num} coin(s)")
            remaining -= num * coin
            total_count += num
            selection.extend([coin] * num)
            print(f"  After: {remaining}c remaining")
            print(f"  Selection so far: {selection}")
        else:
            print(f"\nCoin {coin}c: too large for {remaining}c, skip")

    print("\n" + "-" * 40)
    print(f"FINAL RESULT: {total_count} coins")
    print(f"Selection: {selection}")
    print(f"Verification: {sum(selection)} = {V}c")

    print("\n" + "-" * 40)
    print("WHY GREEDY WORKS FOR US COINS:")
    print("-" * 40)
    print("1. No need for >1 of 50c (2x50 = 100, use $1)")
    print("2. No need for >1 of 25c (2x25 = 50c coin)")
    print("3. No need for >2 of 10c (3x10 = 25+5)")
    print("4. No need for >1 of 5c (2x5 = 10c coin)")
    print("5. No need for >4 of 1c (5x1 = 5c coin)")
    print("\nThese constraints make greedy optimal!")


if __name__ == "__main__":
    run_tests()
    demonstrate_greedy_choice()
