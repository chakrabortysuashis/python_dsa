# Minimum Number of Coins

## Problem Statement

Given a value `V` and infinite supply of coins with denominations `{C1, C2, ..., Cm}`, find the minimum number of coins needed to make change for `V`.

**Input:**
- `V`: Target amount
- `coins[]`: Available coin denominations

**Output:**
- Minimum number of coins needed (or -1 if impossible)

**Example:**
```
V = 93
Coins = [1, 5, 10, 25, 50]

Greedy solution:
  50 + 25 + 10 + 5 + 1 + 1 + 1 = 93
  Count: 1 + 1 + 1 + 1 + 3 = 7 coins

Output: 7 coins
```

---

## Why Greedy Works Here (Canonical Coin Systems)

### What is a Canonical Coin System?

A coin system is **canonical** if the greedy algorithm always produces the optimal (minimum coins) solution. 

**Standard currency systems are canonical:**
- US: {1, 5, 10, 25, 50, 100} cents
- Indian: {1, 2, 5, 10, 20, 50, 100} rupees
- Euro: {1, 2, 5, 10, 20, 50, 100, 200} cents

### Why Greedy Works for Canonical Systems

For canonical systems, taking the largest coin that fits is always safe because:

1. **Efficient Coverage:** Each coin value is designed to efficiently cover the gaps between larger denominations.

2. **No Better Alternatives:** You can't make the same amount with fewer coins using smaller denominations.

3. **Mathematical Property:** For US coins, using fewer large coins would require more small coins to make up the difference.

### Proof for US Coins {1, 5, 10, 25}

**Key observations:**
- To make 5 cents: Need 5 pennies OR 1 nickel (nickel is better)
- To make 10 cents: Need 2 nickels OR 1 dime (dime is better)
- To make 25 cents: Need 2 dimes + 1 nickel OR 1 quarter (quarter is better)

**Constraints that make greedy optimal:**
- Never need more than 4 pennies (5 pennies = 1 nickel)
- Never need more than 1 nickel (2 nickels = 1 dime)
- Never need more than 2 dimes (3 dimes > quarter in most cases)

---

## When Greedy FAILS (Non-Canonical Systems)

### Classic Counterexample

```
Coins = [1, 3, 4]
V = 6

Greedy: 4 + 1 + 1 = 6 (3 coins)
Optimal: 3 + 3 = 6 (2 coins)

Greedy gives 3 coins, optimal is 2 coins!
```

### Why Greedy Fails Here

The greedy algorithm picks 4 first because it's the largest coin <= 6. But this leaves 2, which can only be made with two 1s.

The optimal solution skips 4 entirely and uses two 3s.

### Another Example

```
Coins = [1, 7, 10]
V = 14

Greedy: 10 + 1 + 1 + 1 + 1 = 14 (5 coins)
Optimal: 7 + 7 = 14 (2 coins)
```

### Rule of Thumb

Greedy is NOT guaranteed optimal unless you can prove the coin system is canonical. For general coin systems, use Dynamic Programming.

---

## Greedy Choice Property (For Canonical Systems)

### The Greedy Decision

At each step:
1. Find the largest coin that doesn't exceed the remaining amount
2. Use as many of that coin as possible
3. Move to the next smaller denomination

### Why "Largest First" Works

For canonical systems, large coins are designed to be "worth" their value in terms of smaller coins:
- Using 1 quarter (25c) is always better than 2 dimes + 5 pennies (25c)
- Using 1 dime (10c) is always better than 2 nickels (10c) in terms of count

---

## Step-by-Step Algorithm

### Greedy Algorithm (for canonical systems):

```
1. SORT coins in descending order
2. INITIALIZE count = 0
3. FOR each coin in sorted order:
   a. While remaining >= coin:
      - remaining -= coin
      - count += 1
4. IF remaining == 0: RETURN count
5. ELSE: RETURN -1 (not possible)
```

### Optimized (without loop):

```
1. SORT coins in descending order  
2. INITIALIZE count = 0
3. FOR each coin in sorted order:
   a. coins_used = remaining // coin
   b. count += coins_used
   c. remaining -= coins_used * coin
   d. IF remaining == 0: BREAK
4. RETURN count if remaining == 0 else -1
```

---

## Brute Force / DP Comparison

### Dynamic Programming Solution (General Case)

```python
def min_coins_dp(coins, V):
    dp = [float('inf')] * (V + 1)
    dp[0] = 0
    
    for i in range(1, V + 1):
        for coin in coins:
            if coin <= i and dp[i - coin] + 1 < dp[i]:
                dp[i] = dp[i - coin] + 1
    
    return dp[V] if dp[V] != float('inf') else -1
```

**Time: O(V * n) where n = number of coin types**
**Space: O(V)**

### Comparison

| Aspect | Greedy | DP |
|--------|--------|-----|
| Time | O(n) or O(n log n) | O(V * n) |
| Space | O(1) | O(V) |
| Works for all coins? | No (only canonical) | Yes |
| Optimal guarantee? | Only if canonical | Always |

---

## Optimal Greedy Implementation

```python
def min_coins_greedy(coins, V):
    """
    Greedy minimum coins (ONLY for canonical coin systems).
    
    Args:
        coins: List of coin denominations
        V: Target value
    
    Returns:
        Minimum coins needed, or -1 if impossible
    """
    # Sort descending
    sorted_coins = sorted(coins, reverse=True)
    
    count = 0
    remaining = V
    
    for coin in sorted_coins:
        if remaining == 0:
            break
        
        # Use as many of this coin as possible
        num_coins = remaining // coin
        count += num_coins
        remaining -= num_coins * coin
    
    return count if remaining == 0 else -1
```

---

## Dry Run with Selection Visualization

**Input:**
```
V = 93
Coins = [1, 5, 10, 25, 50]
```

### Greedy Execution

```
Sorted coins (descending): [50, 25, 10, 5, 1]
Initial: remaining = 93, count = 0

========================================
Processing coin: 50
========================================
  93 // 50 = 1 coin(s)
  Remaining: 93 - 50 = 43
  Count: 1
  
  Selection: [50]

========================================
Processing coin: 25
========================================
  43 // 25 = 1 coin(s)
  Remaining: 43 - 25 = 18
  Count: 2
  
  Selection: [50, 25]

========================================
Processing coin: 10
========================================
  18 // 10 = 1 coin(s)
  Remaining: 18 - 10 = 8
  Count: 3
  
  Selection: [50, 25, 10]

========================================
Processing coin: 5
========================================
  8 // 5 = 1 coin(s)
  Remaining: 8 - 5 = 3
  Count: 4
  
  Selection: [50, 25, 10, 5]

========================================
Processing coin: 1
========================================
  3 // 1 = 3 coin(s)
  Remaining: 3 - 3 = 0
  Count: 7
  
  Selection: [50, 25, 10, 5, 1, 1, 1]

========================================
RESULT
========================================
Total coins: 7
Breakdown: 1x50 + 1x25 + 1x10 + 1x5 + 3x1 = 93
```

### Visual Representation

```
Amount: 93 cents

|=====50=====|===25===|==10==|=5=|1|1|1|
|     50     |   25   |  10  | 5 |1|1|1|

Total: 7 coins
```

---

## Time and Space Complexity

### Greedy Approach

| Operation | Complexity |
|-----------|------------|
| Sort coins | O(n log n) |
| Process each coin | O(n) |
| **Total Time** | O(n log n) |
| **Space** | O(1) extra |

Note: If coins are already sorted, time is O(n).

### DP Approach (for comparison)

| Aspect | Complexity |
|--------|------------|
| **Time** | O(V * n) |
| **Space** | O(V) |

---

## Variations and Extensions

### 1. Counting Coins Used

Return not just the count but which coins were used.

```python
def min_coins_with_selection(coins, V):
    sorted_coins = sorted(coins, reverse=True)
    selection = []
    remaining = V
    
    for coin in sorted_coins:
        while remaining >= coin:
            selection.append(coin)
            remaining -= coin
    
    return len(selection), selection
```

### 2. Checking if Canonical

A coin system can be verified as canonical by checking all amounts up to the largest coin squared.

### 3. Limited Coin Supply

If each coin has limited quantity, greedy may not work even for canonical systems. Use DP with coin counts.

### 4. Coin Change (Count Ways)

Different problem: Count the NUMBER of ways to make change. Always requires DP.

```python
def count_ways(coins, V):
    dp = [0] * (V + 1)
    dp[0] = 1
    
    for coin in coins:
        for i in range(coin, V + 1):
            dp[i] += dp[i - coin]
    
    return dp[V]
```

### 5. Real-World Application

ATM machines use greedy for dispensing cash because currency denominations are designed to be canonical.
