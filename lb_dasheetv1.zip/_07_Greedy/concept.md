# Greedy Algorithms - Complete Guide

## What is the Greedy Approach?

A **greedy algorithm** makes the locally optimal choice at each step with the hope that these local choices will lead to a globally optimal solution. Unlike Dynamic Programming which considers all possibilities, greedy algorithms make irrevocable decisions at each step based on current information.

### Key Characteristics:
1. **Greedy Choice Property**: A global optimum can be reached by making locally optimal choices
2. **Optimal Substructure**: An optimal solution contains optimal solutions to subproblems
3. **No Backtracking**: Once a choice is made, it's never reconsidered

### The Greedy Paradigm:
```
1. Cast the optimization problem as one where we make a choice and are left with one subproblem
2. Prove that there's always an optimal solution that makes the greedy choice
3. Show that greedy choice + optimal solution to subproblem = optimal solution to original problem
```

---

## Greedy vs Dynamic Programming vs Backtracking

| Aspect | Greedy | Dynamic Programming | Backtracking |
|--------|--------|---------------------|--------------|
| **Approach** | Make best local choice | Consider all choices, memoize | Try all possibilities, prune |
| **Optimality** | May not be optimal | Always optimal (if applicable) | Always optimal |
| **Time Complexity** | Usually O(n log n) or O(n) | Usually O(n^2) or O(n*W) | Exponential (worst case) |
| **Space Complexity** | Usually O(1) or O(n) | O(n) to O(n^2) | O(n) recursion stack |
| **Revisits Decisions** | Never | Yes (through memoization) | Yes (through backtracking) |
| **When to Use** | Greedy choice property holds | Overlapping subproblems | All solutions needed |

### Comparison Example: Coin Change Problem

**Problem**: Make change for amount N using minimum coins [1, 5, 10, 25]

**Greedy Approach** (Works for standard denominations):
```python
def greedy_coins(amount, coins=[25, 10, 5, 1]):
    count = 0
    for coin in coins:  # coins sorted descending
        count += amount // coin
        amount %= coin
    return count
# For amount=41: 25+10+5+1 = 4 coins (OPTIMAL for this coin set)
```

**When Greedy FAILS** (coins = [1, 3, 4], amount = 6):
- Greedy: 4 + 1 + 1 = 3 coins
- Optimal (DP): 3 + 3 = 2 coins

**DP Approach** (Always optimal):
```python
def dp_coins(amount, coins):
    dp = [float('inf')] * (amount + 1)
    dp[0] = 0
    for i in range(1, amount + 1):
        for coin in coins:
            if coin <= i:
                dp[i] = min(dp[i], dp[i-coin] + 1)
    return dp[amount]
```

---

## How to Identify Greedy Problems

### Signs a Problem Might Be Greedy:

1. **Optimization keywords**: "minimum", "maximum", "largest", "smallest", "optimal"
2. **Selection problems**: "select items", "choose activities", "pick elements"
3. **Scheduling problems**: "schedule jobs", "assign resources", "minimize time"
4. **Interval problems**: "non-overlapping intervals", "cover all points"
5. **Fractional/Divisible**: Can take fractions (often greedy works)

### Questions to Ask:

1. **Can I sort the input by some criteria?**
   - Most greedy problems involve sorting first
   
2. **Is there a natural ordering?**
   - By deadline, by profit, by ratio, by end time, etc.
   
3. **Does making the locally best choice ever hurt us?**
   - If yes, greedy won't work
   
4. **Can I prove the greedy choice is always safe?**
   - Exchange argument, staying ahead argument

### Problem Categories Suited for Greedy:

| Category | Examples | Sorting Criteria |
|----------|----------|------------------|
| Activity Selection | Meetings, intervals | End time (ascending) |
| Job Scheduling | Jobs with deadlines | Profit (descending) |
| Huffman Coding | Data compression | Frequency (ascending) |
| Fractional Knapsack | Items with values | Value/weight ratio |
| Minimum Spanning Tree | Network design | Edge weight (ascending) |
| Shortest Path (Dijkstra) | Route finding | Distance (ascending) |

---

## Proving Greedy Works: The Exchange Argument

The **Exchange Argument** is the most common technique to prove a greedy algorithm's correctness.

### The Method:

1. **Assume** there exists an optimal solution OPT that differs from greedy solution GREEDY
2. **Find** the first point where they differ
3. **Show** that we can "exchange" OPT's choice with GREEDY's choice without worsening the solution
4. **Conclude** that GREEDY is also optimal

### Example: Activity Selection Problem

**Claim**: Selecting the activity with earliest finish time is optimal.

**Proof**:
1. Let OPT = {a1, a2, ..., ak} be an optimal solution sorted by finish time
2. Let GREEDY start with activity g (earliest finish time)
3. If a1 != g, then finish(g) <= finish(a1)
4. We can replace a1 with g in OPT:
   - g doesn't conflict with a2, a3, ... (since finish(g) <= finish(a1))
   - The new solution is still valid and has same size
5. Therefore, there's an optimal solution that includes g
6. After selecting g, we recursively apply the same argument

### Other Proof Techniques:

**Staying Ahead Argument**:
- Show that at each step, greedy is "at least as good as" any other solution
- Greedy "stays ahead" or ties with optimal

**Structural Argument**:
- Show the greedy solution has some structural property that optimal must have

---

## Common Greedy Patterns

### Pattern 1: Sort and Select
```python
def sort_and_select(items, key_func, selection_condition):
    items.sort(key=key_func)
    selected = []
    for item in items:
        if selection_condition(item, selected):
            selected.append(item)
    return selected
```
**Used in**: Activity Selection, Job Sequencing, Meeting Rooms

### Pattern 2: Sort by Ratio
```python
def sort_by_ratio(items):
    # Sort by value/cost ratio (descending)
    items.sort(key=lambda x: x.value / x.cost, reverse=True)
    result = 0
    for item in items:
        # Take as much as possible
        take = min(capacity, item.amount)
        result += take * (item.value / item.amount)
        capacity -= take
    return result
```
**Used in**: Fractional Knapsack, Task Scheduling

### Pattern 3: Two Pointers After Sorting
```python
def two_pointer_greedy(arr):
    arr.sort()
    left, right = 0, len(arr) - 1
    result = 0
    while left < right:
        # Make greedy choice based on both ends
        if condition:
            # Use left element
            left += 1
        else:
            # Use right element
            right -= 1
        result += 1
    return result
```
**Used in**: Boats to Save People, Minimize Cash Flow

### Pattern 4: Priority Queue (Heap) Greedy
```python
import heapq

def heap_greedy(items):
    heap = []
    for item in items:
        heapq.heappush(heap, item)
    
    result = 0
    while len(heap) >= 2:
        # Always combine smallest elements
        first = heapq.heappop(heap)
        second = heapq.heappop(heap)
        combined = first + second
        result += combined
        heapq.heappush(heap, combined)
    return result
```
**Used in**: Huffman Coding, Connect Ropes, Merge Stones

### Pattern 5: Interval Scheduling
```python
def interval_greedy(intervals):
    # Sort by end time for maximum non-overlapping
    intervals.sort(key=lambda x: x[1])
    count = 0
    last_end = float('-inf')
    
    for start, end in intervals:
        if start >= last_end:
            count += 1
            last_end = end
    return count
```
**Used in**: Activity Selection, Minimum Platforms, Meeting Rooms

### Pattern 6: Deadline Scheduling
```python
def deadline_scheduling(jobs):
    # Sort by profit (descending)
    jobs.sort(key=lambda x: x.profit, reverse=True)
    
    max_deadline = max(job.deadline for job in jobs)
    slots = [False] * (max_deadline + 1)
    
    result = 0
    for job in jobs:
        # Find latest available slot before deadline
        for slot in range(job.deadline, 0, -1):
            if not slots[slot]:
                slots[slot] = True
                result += job.profit
                break
    return result
```
**Used in**: Job Sequencing, Task Scheduler

---

## Classic Greedy Problems Summary

| Problem | Greedy Strategy | Why It Works |
|---------|-----------------|--------------|
| Activity Selection | Pick earliest finish time | Leaves maximum room for future activities |
| Fractional Knapsack | Pick highest value/weight ratio | Maximizes value per unit weight |
| Huffman Coding | Merge two lowest frequencies | Minimizes weighted path length |
| Job Sequencing | Pick highest profit, latest slot | Maximizes profit while meeting deadlines |
| Minimum Platforms | Process arrivals/departures in order | Tracks exact platform usage |
| Coin Change (canonical) | Pick largest coin first | Works for standard denominations |
| Minimum Spanning Tree | Pick minimum weight edge | Grows optimal tree (cut property) |

---

## When Greedy Fails

### Common Pitfalls:

1. **0/1 Knapsack**: Can't take fractions - DP required
2. **Longest Path in Graph**: Greedy doesn't find global maximum
3. **Traveling Salesman**: Nearest neighbor is not optimal
4. **Non-canonical Coin Systems**: [1, 3, 4] for amount 6

### Red Flags:

- "All items must be taken completely" (no fractions)
- Choices have cascading effects on future options
- Multiple constraints that interact
- "Count all possible ways" (usually DP or backtracking)

---

## Tips for Solving Greedy Problems

1. **Start with sorting**: 90% of greedy problems require sorting
2. **Identify what to optimize**: Minimize? Maximize?
3. **Find the greedy criterion**: What makes one choice better than another?
4. **Verify with counterexamples**: Try to break your greedy approach
5. **Prove correctness**: Use exchange argument or staying ahead
6. **Consider edge cases**: Empty input, single element, all same values
