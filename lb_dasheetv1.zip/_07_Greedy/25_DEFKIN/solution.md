# DEFKIN - Defense of a Kingdom (SPOJ)

## Problem Statement

A kingdom has a rectangular grid of size W x H. There are N defense towers at various positions. Find the largest undefended rectangular area (area without any tower).

**Input:** 
- `W`, `H` - Width and height of kingdom
- `N` - Number of towers
- Tower positions (x, y)

**Output:** Largest rectangular area without any tower

**Example:**
```
Input: W=15, H=8, N=3
Towers: (3,8), (11,2), (8,6)
Output: 24
```

---

## Why Greedy Works Here

### Key Insight

The largest rectangle without towers is bounded by:
- The borders of the kingdom (x=0, x=W, y=0, y=H)
- The tower positions

### Greedy Observation

**Claim:** The largest empty rectangle has its sides aligned with tower positions or borders.

**Why:**
- Any rectangle not aligned can be extended to the nearest tower/border
- Therefore, we only need to check gaps between sorted positions

### Algorithm

1. Sort tower x-coordinates (add borders 0 and W)
2. Sort tower y-coordinates (add borders 0 and H)
3. Find maximum gap in x-direction
4. Find maximum gap in y-direction
5. Answer = max_gap_x * max_gap_y

---

## Step-by-Step Algorithm

```
1. COLLECT all x-coordinates: [0, x1, x2, ..., xn, W]
2. COLLECT all y-coordinates: [0, y1, y2, ..., yn, H]
3. SORT both lists
4. FIND max_gap_x = max(x[i+1] - x[i] - 1) for all i
   Note: subtract 1 because towers occupy cells
5. FIND max_gap_y = max(y[i+1] - y[i] - 1)
6. RETURN max_gap_x * max_gap_y
```

---

## Implementation

```python
def defkin(W, H, towers):
    # Collect coordinates with borders
    x_coords = sorted(set([0] + [t[0] for t in towers] + [W + 1]))
    y_coords = sorted(set([0] + [t[1] for t in towers] + [H + 1]))
    
    # Find max gaps
    max_gap_x = max(x_coords[i+1] - x_coords[i] - 1 
                    for i in range(len(x_coords) - 1))
    max_gap_y = max(y_coords[i+1] - y_coords[i] - 1 
                    for i in range(len(y_coords) - 1))
    
    return max_gap_x * max_gap_y
```

---

## Dry Run

**Input:** W=15, H=8, Towers: (3,8), (11,2), (8,6)

**Step 1: Collect Coordinates**
```
x_coords: [0, 3, 8, 11, 16]  (16 = W+1)
y_coords: [0, 2, 6, 8, 9]    (9 = H+1)
```

**Step 2: Find Gaps**
```
x_gaps: 3-0-1=2, 8-3-1=4, 11-8-1=2, 16-11-1=4
max_gap_x = 4

y_gaps: 2-0-1=1, 6-2-1=3, 8-6-1=1, 9-8-1=0
max_gap_y = 3
```

**Step 3: Calculate Area**
```
Area = 4 * 3 = 12
```

---

## Time and Space Complexity

| Aspect | Complexity | Explanation |
|--------|------------|-------------|
| **Time** | O(N log N) | Sorting tower coordinates |
| **Space** | O(N) | Storing coordinates |

---

## Why This Works (Geometric Argument)

The key insight is that any maximal empty rectangle must have its boundaries at either:
1. A tower position, or
2. The kingdom border

This is because if a boundary isn't at a tower/border, we can extend the rectangle.

Therefore, we decompose the 2D problem into two independent 1D problems:
- Find largest gap in x-direction
- Find largest gap in y-direction

The product gives the largest rectangle.
