"""
Maximum Product Subset - Greedy Algorithm
==========================================

Problem: Given an array of integers (positive, negative, zero), find the
maximum product obtainable from any non-empty subset.

WHY GREEDY WORKS:
----------------
1. Positive numbers: Always increase product, include all of them
2. Negative numbers: Two negatives make positive, include in pairs
3. Zeros: Reset product to 0, usually exclude
4. Odd negatives: Exclude the one with smallest absolute value

GREEDY STRATEGY:
- Include all positive numbers
- Include pairs of negative numbers (sorted by absolute value)
- Exclude zeros (unless all elements are zero)
- If odd negatives, exclude the one closest to zero

This is greedy because at each decision point, we make the locally
optimal choice that also turns out to be globally optimal.
"""

from typing import List, Tuple


def max_product_subset(arr: List[int]) -> int:
    """
    Find maximum product of any non-empty subset.

    Greedy Strategy:
    1. Include all positives
    2. Include pairs of negatives
    3. Exclude zeros and leftover negative

    Time: O(n)
    Space: O(1)

    Example:
    >>> max_product_subset([-1, -1, -2, 4, 3])
    24
    >>> max_product_subset([0, 0, 0])
    0
    >>> max_product_subset([-1])
    -1
    """
    n = len(arr)

    # Edge case: single element
    if n == 1:
        return arr[0]

    # Track counts and values
    max_negative = float('-inf')  # Negative closest to zero (for exclusion)
    product = 1
    neg_count = 0
    zero_count = 0
    has_positive = False

    for x in arr:
        if x == 0:
            zero_count += 1
            continue

        product *= x

        if x > 0:
            has_positive = True

        if x < 0:
            neg_count += 1
            max_negative = max(max_negative, x)  # Closest to zero

    # Edge case: all zeros
    if zero_count == n:
        return 0

    # Edge case: one negative, rest zeros
    if neg_count == 1 and zero_count == n - 1:
        return 0

    # Edge case: only one negative and no positives
    if neg_count == 1 and not has_positive and zero_count == 0:
        return arr[0] if n == 1 else 0

    # If product is negative (odd negatives), exclude the smallest absolute
    if product < 0:
        product //= max_negative

    return product


def max_product_subset_detailed(arr: List[int]) -> Tuple[int, List[int]]:
    """
    Returns maximum product and the elements used.

    Example:
    >>> product, elements = max_product_subset_detailed([-1, -1, -2, 4, 3])
    >>> product
    24
    >>> sorted(elements)
    [-2, -1, 3, 4]
    """
    n = len(arr)

    # Edge case: single element
    if n == 1:
        return arr[0], [arr[0]]

    positives = [x for x in arr if x > 0]
    negatives = sorted([x for x in arr if x < 0])  # Most negative first
    zeros = [x for x in arr if x == 0]

    # Edge case: all zeros
    if len(zeros) == n:
        return 0, [0]

    # Edge case: one negative, rest zeros
    if len(negatives) == 1 and len(positives) == 0:
        return 0, [0] if zeros else [negatives[0]]

    # Build subset
    subset = []

    # Include all positives
    subset.extend(positives)

    # Include pairs of negatives
    if len(negatives) % 2 == 1:
        # Odd negatives: exclude the smallest absolute (last after sorting)
        subset.extend(negatives[:-1])
    else:
        subset.extend(negatives)

    # Calculate product
    if not subset:
        return 0, [0]

    product = 1
    for x in subset:
        product *= x

    return product, subset


def max_product_subset_sorted(arr: List[int]) -> int:
    """
    Version using sorting for clarity (slightly less efficient).

    This version explicitly sorts negatives to show the pairing logic.

    Time: O(n log n)
    Space: O(n)
    """
    n = len(arr)
    if n == 1:
        return arr[0]

    positives = [x for x in arr if x > 0]
    negatives = sorted([x for x in arr if x < 0], reverse=True)  # Closest to 0 first
    zeros = sum(1 for x in arr if x == 0)

    # Edge cases
    if zeros == n:
        return 0
    if len(negatives) == 1 and len(positives) == 0:
        return 0 if zeros else negatives[0]

    product = 1

    # Include all positives
    for p in positives:
        product *= p

    # Include pairs of negatives (exclude last if odd count)
    neg_to_use = len(negatives) - (len(negatives) % 2)
    for i in range(neg_to_use):
        product *= negatives[i]

    # If nothing was included, return 0
    if len(positives) == 0 and neg_to_use == 0:
        return 0

    return product


# =============================================================================
# BRUTE FORCE COMPARISON
# =============================================================================

def max_product_brute_force(arr: List[int]) -> int:
    """
    Brute force: Try all 2^n - 1 non-empty subsets.

    Time: O(2^n * n)
    Space: O(1)

    Only for verification on small inputs.
    """
    n = len(arr)
    max_product = float('-inf')

    for mask in range(1, 1 << n):  # Skip empty subset (mask = 0)
        product = 1
        for i in range(n):
            if mask & (1 << i):
                product *= arr[i]
        max_product = max(max_product, product)

    return max_product


# =============================================================================
# VARIATIONS
# =============================================================================

def min_product_subset(arr: List[int]) -> int:
    """
    Find MINIMUM product (most negative).

    Strategy (opposite of maximum):
    - Include odd number of negatives (to make negative)
    - Include zeros only if no negative product possible
    - May need to exclude positives

    Example:
    >>> min_product_subset([-1, -1, -2, 4, 3])
    -24
    """
    n = len(arr)
    if n == 1:
        return arr[0]

    positives = [x for x in arr if x > 0]
    negatives = sorted([x for x in arr if x < 0])  # Most negative first
    zero_count = sum(1 for x in arr if x == 0)

    # If we have zeros and no way to make negative, return 0
    if zero_count > 0 and len(negatives) == 0:
        return 0

    # Calculate most negative product
    # Include all negatives if odd count, or exclude smallest absolute if even
    product = 1

    if len(negatives) % 2 == 0 and len(negatives) > 0:
        # Even negatives would give positive, exclude one to make negative
        negatives = negatives[:-1]  # Remove smallest absolute

    # If no negatives left, we need to return something
    if len(negatives) == 0:
        if positives:
            return min(positives)  # Smallest positive
        return 0

    for neg in negatives:
        product *= neg

    # Multiply by all positives (they make the magnitude larger, which is more negative)
    for pos in positives:
        product *= pos

    return product


def max_product_subarray(arr: List[int]) -> int:
    """
    Maximum product SUBARRAY (contiguous) - different problem!

    Uses Kadane's-like approach tracking both max and min products.

    Example:
    >>> max_product_subarray([2, 3, -2, 4])
    6
    >>> max_product_subarray([-2, 0, -1])
    0
    """
    if not arr:
        return 0

    max_so_far = arr[0]
    max_ending = arr[0]
    min_ending = arr[0]  # Track min for negative flips

    for i in range(1, len(arr)):
        x = arr[i]

        # Current element could start new subarray or extend
        candidates = [x, max_ending * x, min_ending * x]
        max_ending = max(candidates)
        min_ending = min(candidates)

        max_so_far = max(max_so_far, max_ending)

    return max_so_far


def max_product_k_elements(arr: List[int], k: int) -> int:
    """
    Maximum product of exactly K elements.

    This requires more careful handling - not always greedy!
    Uses DP for general case.

    Example:
    >>> max_product_k_elements([1, 2, 3, 4], 2)
    12
    """
    n = len(arr)
    if k > n:
        return 0

    # Sort by absolute value descending
    sorted_arr = sorted(arr, key=lambda x: abs(x), reverse=True)

    # Greedy attempt: take k largest absolute values
    # Then adjust for sign

    # This is actually a complex problem - simplified greedy here
    # Full solution would use DP

    # Take largest k by absolute value
    subset = sorted_arr[:k]
    product = 1
    neg_count = 0

    for x in subset:
        product *= x
        if x < 0:
            neg_count += 1

    # If product is negative, try to improve
    if product < 0 and k < n:
        # Find best swap to make positive
        # This is simplified - full solution needs DP
        pass

    return product


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Comprehensive test cases with explanations."""

    print("=" * 60)
    print("MAXIMUM PRODUCT SUBSET - TEST CASES")
    print("=" * 60)

    # Test 1: Mixed positive, negative
    print("\nTest 1: Mixed Array")
    print("-" * 40)
    arr = [-1, -1, -2, 4, 3]
    result = max_product_subset(arr)
    print(f"Array: {arr}")
    print(f"Maximum product: {result}")
    print(f"Explanation: (-2) * (-1) * 4 * 3 = 24")
    assert result == 24, f"Expected 24, got {result}"

    # Test 2: All positive
    print("\nTest 2: All Positive")
    print("-" * 40)
    arr = [1, 2, 3, 4]
    result = max_product_subset(arr)
    print(f"Array: {arr}")
    print(f"Maximum product: {result}")
    assert result == 24, f"Expected 24, got {result}"

    # Test 3: All negative (even count)
    print("\nTest 3: All Negative (Even Count)")
    print("-" * 40)
    arr = [-2, -3, -4, -5]
    result = max_product_subset(arr)
    print(f"Array: {arr}")
    print(f"Maximum product: {result}")
    print(f"Explanation: (-2)*(-3)*(-4)*(-5) = 120")
    assert result == 120, f"Expected 120, got {result}"

    # Test 4: All negative (odd count)
    print("\nTest 4: All Negative (Odd Count)")
    print("-" * 40)
    arr = [-2, -3, -5]
    result = max_product_subset(arr)
    print(f"Array: {arr}")
    print(f"Maximum product: {result}")
    print(f"Explanation: (-2)*(-3) = 6 or (-3)*(-5) = 15")
    assert result == 15, f"Expected 15, got {result}"

    # Test 5: With zeros
    print("\nTest 5: With Zeros")
    print("-" * 40)
    arr = [-1, 0, 2, 3]
    result = max_product_subset(arr)
    print(f"Array: {arr}")
    print(f"Maximum product: {result}")
    print(f"Explanation: 2 * 3 = 6 (ignore -1 and 0)")
    assert result == 6, f"Expected 6, got {result}"

    # Test 6: All zeros
    print("\nTest 6: All Zeros")
    print("-" * 40)
    arr = [0, 0, 0]
    result = max_product_subset(arr)
    print(f"Array: {arr}")
    print(f"Maximum product: {result}")
    assert result == 0

    # Test 7: Single negative
    print("\nTest 7: Single Negative")
    print("-" * 40)
    arr = [-5]
    result = max_product_subset(arr)
    print(f"Array: {arr}")
    print(f"Maximum product: {result}")
    assert result == -5

    # Test 8: Single negative with zeros
    print("\nTest 8: Single Negative with Zeros")
    print("-" * 40)
    arr = [-3, 0, 0]
    result = max_product_subset(arr)
    print(f"Array: {arr}")
    print(f"Maximum product: {result}")
    print(f"Explanation: 0 is better than -3")
    assert result == 0

    # Test 9: Compare with brute force
    print("\nTest 9: Greedy vs Brute Force")
    print("-" * 40)
    arr = [-2, -3, 1, 4, -1, 2]
    greedy = max_product_subset(arr)
    brute = max_product_brute_force(arr)
    print(f"Array: {arr}")
    print(f"Greedy: {greedy}")
    print(f"Brute force: {brute}")
    assert greedy == brute, "Should match!"

    # Test 10: Detailed output
    print("\nTest 10: Detailed Output")
    print("-" * 40)
    arr = [-1, -1, -2, 4, 3, 0]
    product, elements = max_product_subset_detailed(arr)
    print(f"Array: {arr}")
    print(f"Maximum product: {product}")
    print(f"Elements used: {elements}")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_greedy_choice():
    """Step-by-step demonstration of greedy decisions."""

    print("\n" + "=" * 60)
    print("DEMONSTRATION: GREEDY PRODUCT MAXIMIZATION")
    print("=" * 60)

    arr = [-3, -2, -1, 0, 2, 4]

    print(f"\nArray: {arr}")

    # Categorize
    positives = [x for x in arr if x > 0]
    negatives = sorted([x for x in arr if x < 0])
    zeros = [x for x in arr if x == 0]

    print(f"\nCategorization:")
    print(f"  Positives: {positives}")
    print(f"  Negatives: {negatives} (sorted)")
    print(f"  Zeros: {zeros}")

    print("\nGreedy Decisions:")
    print("-" * 50)

    included = []

    # Decision 1: Positives
    print("\n1. POSITIVES (Always include):")
    for p in positives:
        print(f"   Include {p} (increases product)")
        included.append(p)

    # Decision 2: Negatives
    print("\n2. NEGATIVES (Include pairs):")
    neg_count = len(negatives)
    pairs = neg_count // 2
    print(f"   {neg_count} negatives -> {pairs} pair(s)")

    if neg_count % 2 == 1:
        to_use = negatives[:-1]
        excluded_neg = negatives[-1]
        print(f"   Include pairs: {to_use}")
        print(f"   Exclude: {excluded_neg} (odd one out, closest to 0)")
    else:
        to_use = negatives
        print(f"   Include all: {to_use}")

    included.extend(to_use)

    # Decision 3: Zeros
    print("\n3. ZEROS (Always exclude):")
    print(f"   Exclude {zeros} (would reset product to 0)")

    # Calculate
    product = 1
    for x in included:
        product *= x

    print("\n" + "-" * 50)
    print(f"Final subset: {included}")
    print(f"Product: {' * '.join(map(str, included))} = {product}")

    print("\nWHY THIS IS OPTIMAL:")
    print("- All positives increase the magnitude")
    print("- Paired negatives become positive multipliers")
    print("- Zeros would destroy any positive product")
    print("- Odd negative would flip sign to negative")


if __name__ == "__main__":
    run_tests()
    demonstrate_greedy_choice()
