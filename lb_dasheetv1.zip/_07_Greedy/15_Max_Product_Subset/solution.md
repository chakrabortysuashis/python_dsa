# Maximum Product Subset Problem

## Problem Statement

Given an array of integers (positive, negative, and zero), find the maximum product that can be obtained from any non-empty subset of the array.

**Input:**
- `arr[]` - Array of integers (can include positive, negative, and zero values)

**Output:** Maximum product obtainable from any subset

**Example:**
```
Input: arr = [-1, -1, -2, 4, 3]
Output: 24

Explanation: Subset {-2, -1, 4, 3} gives product = (-2) * (-1) * 4 * 3 = 24
(Two negatives make positive, multiply with all positives)
```

---

## Why Greedy Works Here

### The Greedy Choice Property

**Claim:** To maximize product, we should:
1. Include ALL positive numbers (each increases product)
2. Include PAIRS of negative numbers (two negatives make positive)
3. Handle zeros carefully (only include if no positive product possible)

**Intuition:**
- Multiplying by a positive number > 1 always increases magnitude
- Two negative numbers multiply to give positive
- Including an odd number of negatives makes product negative
- Zero resets product to 0 (usually bad, but better than negative!)

### Greedy Strategy

1. **Count negatives and find minimum absolute value negative**
2. **Separate positives, negatives, and zeros**
3. **Include all positives** (they only help)
4. **Include pairs of negatives** (sorted by absolute value, descending)
5. **If product is negative** (odd negatives), exclude the least absolute negative
6. **Handle edge cases**: all zeros, single element, etc.

### Exchange Argument Proof

1. Let `OPT` be an optimal solution
2. If `OPT` excludes a positive number `p`, including `p` gives `OPT * p > OPT` (contradiction)
3. If `OPT` includes odd negatives, removing smallest absolute negative improves product
4. Therefore, greedy choices are always safe

---

## Step-by-Step Algorithm

### Algorithm:

```
1. HANDLE edge case: single element -> return that element
2. COUNT zeros, positives, negatives
3. IF all zeros: return 0
4. IF one negative and rest zeros: return 0
5. CALCULATE product of all positives and all negatives
6. IF product is negative (odd count of negatives):
   - Find negative with smallest absolute value
   - Divide product by that negative
7. RETURN final product
```

### Key Edge Cases

| Case | Handling |
|------|----------|
| Single element | Return that element |
| All zeros | Return 0 |
| One negative, rest zeros | Return 0 |
| All negatives (odd count) | Exclude smallest absolute |
| Mix with zeros | Ignore zeros unless needed |

---

## Brute Force Comparison

### Brute Force Approach
Try all 2^n - 1 non-empty subsets, calculate product of each, return maximum.

```python
def brute_force(arr):
    n = len(arr)
    max_product = float('-inf')
    
    for mask in range(1, 1 << n):  # Skip empty subset
        product = 1
        for i in range(n):
            if mask & (1 << i):
                product *= arr[i]
        max_product = max(max_product, product)
    
    return max_product
```

**Time Complexity:** O(2^n * n)
**Space Complexity:** O(1)

### Why Brute Force is Impractical
- For n=30: Over 1 billion subsets
- Product calculation for each subset adds O(n)
- Exponential is infeasible

---

## Optimal Greedy Approach

```python
def max_product_subset(arr):
    n = len(arr)
    
    # Edge case: single element
    if n == 1:
        return arr[0]
    
    # Separate and count
    positives = [x for x in arr if x > 0]
    negatives = sorted([x for x in arr if x < 0], key=lambda x: x)  # Most negative first
    zeros = [x for x in arr if x == 0]
    
    # Edge case: all zeros
    if len(zeros) == n:
        return 0
    
    # Edge case: single negative with zeros
    if len(negatives) == 1 and len(positives) == 0:
        return 0 if zeros else negatives[0]
    
    # Calculate product
    product = 1
    
    # Include all positives
    for p in positives:
        product *= p
    
    # Include pairs of negatives (from most negative)
    neg_count = len(negatives)
    pairs = neg_count // 2
    
    # If odd negatives, exclude the one with smallest absolute value (last in sorted)
    negatives_to_use = negatives[:pairs * 2] if neg_count % 2 == 1 else negatives
    
    for neg in negatives_to_use:
        product *= neg
    
    # Handle case: no positives, even negatives result in product = 1
    if not positives and not negatives_to_use:
        return 0
    
    return product
```

**Time Complexity:** O(n log n) for sorting negatives
**Space Complexity:** O(n) for separate lists

---

## Dry Run with Selection Visualization

**Input:**
```
arr = [-1, -1, -2, 4, 3, 0]
```

**Step 1: Categorize Elements**
```
Positives: [4, 3]
Negatives: [-1, -1, -2] (sorted: [-2, -1, -1])
Zeros: [0]
```

**Step 2: Determine Strategy**
```
Positive count: 2
Negative count: 3 (odd!)
Zero count: 1

Strategy:
- Include all positives: 4, 3
- Include pairs of negatives: 3 negatives -> 1 pair + 1 leftover
- Exclude leftover (smallest absolute = -1)
```

**Step 3: Calculate Product**
```
Start with product = 1

Add positives:
  1 * 4 = 4
  4 * 3 = 12

Add negative pairs (use 2 from 3):
  Sorted negatives: [-2, -1, -1]
  Use first 2 (most negative): [-2, -1]
  12 * (-2) = -24
  -24 * (-1) = 24

Exclude: -1 (smallest absolute, would make product negative)
```

**Final Result:**
```
Maximum Product: 24
Subset used: {4, 3, -2, -1}

Verification:
4 * 3 * (-2) * (-1) = 12 * 2 = 24
```

**Alternative Analysis:**
```
Why not include all three negatives?
4 * 3 * (-2) * (-1) * (-1) = 24 * (-1) = -24
This is worse than 24!

Why not include zero?
Including 0 makes product = 0
This is worse than 24!
```

---

## Time and Space Complexity

| Aspect | Complexity | Explanation |
|--------|------------|-------------|
| **Time** | O(n log n) | Sorting negatives is bottleneck |
| **Space** | O(n) | Storing categorized elements |

### Optimized Version (O(n) time):
- Don't sort, just find max negative (for exclusion if odd count)
- Track product directly

```python
def max_product_optimized(arr):
    # O(n) solution without sorting
    max_negative = float('-inf')  # Closest to zero
    product = 1
    neg_count = 0
    has_non_zero = False
    
    for x in arr:
        if x == 0:
            continue
        has_non_zero = True
        product *= x
        if x < 0:
            neg_count += 1
            max_negative = max(max_negative, x)
    
    if not has_non_zero:
        return 0
    
    if product < 0:  # Odd negatives
        product //= max_negative  # Remove least absolute negative
    
    return product
```

---

## Variations and Extensions

### 1. Maximum Product Subarray (Contiguous)
Different problem! Use Kadane's-like DP approach.

### 2. Maximum Product with Size Constraint
Find maximum product subset of exactly K elements.

### 3. Maximum Product Modulo M
Handle overflow using modular arithmetic.

### 4. Count Subsets with Maximum Product
Count how many subsets achieve the maximum product.

### 5. Minimum Product Subset
Similar logic but reverse strategy:
- Include odd number of negatives
- Exclude positives if possible
