# Min and Max Amount to Buy All N Candies

## Problem Statement

A shop sells candies where the cost of each candy is given in array `cost[]`. If you buy candy at position `i`, you can take `K` candies for free from the end of the array. Find the minimum and maximum amount to buy all N candies.

**Input:**
- `cost[]`: Cost of each candy
- `K`: Number of free candies you get with each purchase

**Output:**
- Minimum amount to buy all candies
- Maximum amount to buy all candies

**Constraints:**
- If you buy candy i, you get K free candies (take from remaining)
- You must acquire all candies (buy or get free)

**Example:**
```
cost = [3, 2, 1, 4]
K = 2

For Minimum:
- Buy candy 1 (cost 1), get 2 free (costs 3, 4)
- Buy candy 2 (cost 2)
- Total: 1 + 2 = 3

For Maximum:
- Buy candy 4 (cost 4), get 2 free (costs 1, 2)
- Buy candy 3 (cost 3)
- Total: 4 + 3 = 7
```

---

## Why Greedy Works Here

### The Key Insight

**For Minimum:** Buy cheap candies, get expensive ones free
**For Maximum:** Buy expensive candies, get cheap ones free

### Greedy Strategy

**Minimum Cost:**
1. Sort candies by cost (ascending)
2. Buy from the cheap end
3. Mark K candies from expensive end as "free" for each purchase

**Maximum Cost:**
1. Sort candies by cost (ascending)
2. Buy from the expensive end
3. Mark K candies from cheap end as "free" for each purchase

### Why This Works

**Exchange Argument (Minimum):**
- If we buy expensive candy X instead of cheap candy Y
- We pay more for X
- We could have bought Y and gotten X free
- Therefore, buying cheap first is optimal

**Exchange Argument (Maximum):**
- Similar logic reversed
- Buying expensive first maximizes spending
- Cheap candies become free

---

## Greedy Choice Property Explanation

### For Minimum Cost

```
Sorted: [1, 2, 3, 4, 5, 6] with K=2

Round 1: Buy 1, get 5,6 free
  Bought: [1]
  Free: [5, 6]
  Remaining: [2, 3, 4]

Round 2: Buy 2, get 3,4 free
  Bought: [1, 2]
  Free: [5, 6, 3, 4]
  Done!

Minimum = 1 + 2 = 3
```

### For Maximum Cost

```
Sorted: [1, 2, 3, 4, 5, 6] with K=2

Round 1: Buy 6, get 1,2 free
  Bought: [6]
  Free: [1, 2]
  Remaining: [3, 4, 5]

Round 2: Buy 5, get 3,4 free
  Bought: [6, 5]
  Free: [1, 2, 3, 4]
  Done!

Maximum = 6 + 5 = 11
```

---

## Step-by-Step Algorithm

### For Minimum Cost:

```
1. SORT costs in ascending order
2. INITIALIZE: left = 0, right = n-1, min_cost = 0
3. WHILE left <= right:
   a. Buy candy at left: min_cost += cost[left]
   b. left++
   c. Mark K candies free from right: right -= K
4. RETURN min_cost
```

### For Maximum Cost:

```
1. SORT costs in ascending order
2. INITIALIZE: left = 0, right = n-1, max_cost = 0
3. WHILE left <= right:
   a. Buy candy at right: max_cost += cost[right]
   b. right--
   c. Mark K candies free from left: left += K
4. RETURN max_cost
```

---

## Brute Force Comparison

### Brute Force Approach

Try all possible orderings of buying candies and compute cost.

```python
def brute_force_min(costs, K):
    from itertools import permutations
    
    n = len(costs)
    min_cost = float('inf')
    
    for perm in permutations(range(n)):
        remaining = set(range(n))
        cost = 0
        free_count = 0
        
        for idx in perm:
            if idx not in remaining:
                continue
            
            if free_count > 0:
                free_count -= 1
                remaining.remove(idx)
            else:
                cost += costs[idx]
                remaining.remove(idx)
                free_count += K
        
        min_cost = min(min_cost, cost)
    
    return min_cost
```

**Time: O(n! * n)** - factorial, completely impractical!

### Comparison

| Approach | Time | Space |
|----------|------|-------|
| Brute Force | O(n!) | O(n) |
| Greedy | O(n log n) | O(n) |

---

## Optimal Greedy Implementation

```python
def min_max_candies(costs, K):
    """
    Find minimum and maximum cost to buy all candies.
    
    Args:
        costs: List of candy costs
        K: Number of free candies per purchase
    
    Returns:
        (minimum_cost, maximum_cost)
    """
    n = len(costs)
    if n == 0:
        return 0, 0
    
    # Sort costs
    sorted_costs = sorted(costs)
    
    # For minimum: buy cheap, get expensive free
    min_cost = 0
    left, right = 0, n - 1
    
    while left <= right:
        min_cost += sorted_costs[left]
        left += 1
        right -= K
    
    # For maximum: buy expensive, get cheap free
    max_cost = 0
    left, right = 0, n - 1
    
    while left <= right:
        max_cost += sorted_costs[right]
        right -= 1
        left += K
    
    return min_cost, max_cost
```

**Time: O(n log n)**
**Space: O(n)**

---

## Dry Run with Selection Visualization

**Input:**
```
costs = [3, 2, 1, 4, 6, 5]
K = 2
```

### Step 1: Sort Costs

```
Sorted: [1, 2, 3, 4, 5, 6]
         ^              ^
        low           high
```

### Finding Minimum Cost

```
Initial: left=0, right=5, min_cost=0

Step 1: Buy cost[0]=1
        Get free: cost[4]=5, cost[5]=6 (K=2 from right)
        min_cost = 1
        left=1, right=3

        [1, 2, 3, 4, 5, 6]
         B              F  F
            ^     ^

Step 2: Buy cost[1]=2
        Get free: cost[2]=3, cost[3]=4 (K=2 from right)
        min_cost = 1 + 2 = 3
        left=2, right=1

        [1, 2, 3, 4, 5, 6]
         B  B  F  F  F  F

left > right, DONE!

Minimum Cost = 3
Bought: [1, 2]
Free: [3, 4, 5, 6]
```

### Finding Maximum Cost

```
Initial: left=0, right=5, max_cost=0

Step 1: Buy cost[5]=6
        Get free: cost[0]=1, cost[1]=2 (K=2 from left)
        max_cost = 6
        left=2, right=4

        [1, 2, 3, 4, 5, 6]
         F  F           B
               ^  ^

Step 2: Buy cost[4]=5
        Get free: cost[2]=3, cost[3]=4 (K=2 from left)
        max_cost = 6 + 5 = 11
        left=4, right=3

        [1, 2, 3, 4, 5, 6]
         F  F  F  F  B  B

left > right, DONE!

Maximum Cost = 11
Bought: [5, 6]
Free: [1, 2, 3, 4]
```

### Summary

```
Sorted costs: [1, 2, 3, 4, 5, 6]

For MINIMUM (buy cheap, free expensive):
  Buy:  1 + 2 = 3
  Free: 3, 4, 5, 6

For MAXIMUM (buy expensive, free cheap):
  Buy:  6 + 5 = 11
  Free: 1, 2, 3, 4
```

---

## Time and Space Complexity

### Time Complexity: O(n log n)

| Operation | Complexity |
|-----------|------------|
| Sort costs | O(n log n) |
| Two-pointer for min | O(n) |
| Two-pointer for max | O(n) |
| **Total** | **O(n log n)** |

### Space Complexity: O(n)

| Storage | Complexity |
|---------|------------|
| Sorted array | O(n) |
| **Total** | **O(n)** |

---

## Variations and Extensions

### 1. K = 1 (Buy One Get One)

Simplest case: for every candy bought, one free.
- Minimum: buy all odd-indexed candies (after sorting)
- Maximum: buy all even-indexed candies (after sorting)

### 2. Different Free Counts

If buying candy i gives different number of free candies based on i.

### 3. With Constraints on Free Selection

If free candies must satisfy certain conditions (e.g., adjacent only).

### 4. Multiple Shops

If there are multiple shops with different K values.
