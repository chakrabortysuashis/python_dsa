"""
Min and Max Amount to Buy All N Candies - Greedy Algorithm
==========================================================

Problem: A shop sells candies. When you buy candy i, you can take K candies
for free. Find minimum and maximum cost to acquire all N candies.

WHY GREEDY WORKS:
----------------
1. For Minimum: Buy cheap candies, get expensive ones free
   - Buying cheap saves money on what we pay
   - Getting expensive free maximizes our "free value"

2. For Maximum: Buy expensive candies, get cheap ones free
   - Buying expensive maximizes our spending
   - Getting cheap free minimizes what we save

3. Exchange Argument:
   - For minimum: if we buy expensive X and free cheap Y
   - We could swap to buy Y (cheaper) and free X (more expensive)
   - Same candies acquired, less money spent
   - Therefore, buy cheap first is optimal

GREEDY STRATEGY:
- Sort candies by cost
- For minimum: buy from left (cheap), free from right (expensive)
- For maximum: buy from right (expensive), free from left (cheap)
- Use two pointers until all candies are acquired
"""

from typing import List, Tuple


def min_max_candies(costs: List[int], K: int) -> Tuple[int, int]:
    """
    Find minimum and maximum cost to buy all candies.

    Greedy Strategy:
    - Minimum: buy cheapest, get most expensive K free
    - Maximum: buy most expensive, get cheapest K free

    Args:
        costs: Cost of each candy
        K: Number of free candies per purchase

    Returns:
        (minimum_cost, maximum_cost)

    Time: O(n log n)
    Space: O(n)

    Example:
    >>> min_max_candies([3, 2, 1, 4], 2)
    (3, 7)
    """
    n = len(costs)
    if n == 0:
        return 0, 0

    sorted_costs = sorted(costs)

    # For minimum: buy from left (cheap), free from right (expensive)
    min_cost = 0
    left, right = 0, n - 1

    while left <= right:
        min_cost += sorted_costs[left]
        left += 1
        right -= K  # Take K free from right

    # For maximum: buy from right (expensive), free from left (cheap)
    max_cost = 0
    left, right = 0, n - 1

    while left <= right:
        max_cost += sorted_costs[right]
        right -= 1
        left += K  # Take K free from left

    return min_cost, max_cost


def min_candies_detailed(
    costs: List[int],
    K: int
) -> Tuple[int, List[int], List[int]]:
    """
    Detailed minimum cost solution.

    Returns:
        (min_cost, list of bought candy costs, list of free candy costs)
    """
    n = len(costs)
    if n == 0:
        return 0, [], []

    sorted_costs = sorted(costs)
    bought = []
    free = []

    left, right = 0, n - 1

    while left <= right:
        # Buy from left (cheap)
        bought.append(sorted_costs[left])
        left += 1

        # Take K free from right (expensive)
        for _ in range(K):
            if right >= left:
                free.append(sorted_costs[right])
                right -= 1

    min_cost = sum(bought)
    return min_cost, bought, free


def max_candies_detailed(
    costs: List[int],
    K: int
) -> Tuple[int, List[int], List[int]]:
    """
    Detailed maximum cost solution.

    Returns:
        (max_cost, list of bought candy costs, list of free candy costs)
    """
    n = len(costs)
    if n == 0:
        return 0, [], []

    sorted_costs = sorted(costs)
    bought = []
    free = []

    left, right = 0, n - 1

    while left <= right:
        # Buy from right (expensive)
        bought.append(sorted_costs[right])
        right -= 1

        # Take K free from left (cheap)
        for _ in range(K):
            if left <= right:
                free.append(sorted_costs[left])
                left += 1

    max_cost = sum(bought)
    return max_cost, bought, free


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Comprehensive test cases with explanations."""

    print("=" * 60)
    print("MIN AND MAX CANDIES - TEST CASES")
    print("=" * 60)

    # Test 1: Basic example
    print("\nTest 1: Basic Example")
    print("-" * 40)
    costs = [3, 2, 1, 4]
    K = 2

    min_cost, max_cost = min_max_candies(costs, K)
    print(f"Costs: {costs}")
    print(f"K (free candies): {K}")
    print(f"Minimum cost: {min_cost}")
    print(f"Maximum cost: {max_cost}")

    # Detailed breakdown
    min_c, min_bought, min_free = min_candies_detailed(costs, K)
    max_c, max_bought, max_free = max_candies_detailed(costs, K)

    print(f"\nMinimum breakdown:")
    print(f"  Bought: {min_bought} = {min_c}")
    print(f"  Free: {min_free}")

    print(f"\nMaximum breakdown:")
    print(f"  Bought: {max_bought} = {max_c}")
    print(f"  Free: {max_free}")

    # Test 2: K = 1 (buy one get one)
    print("\nTest 2: K = 1 (Buy One Get One)")
    print("-" * 40)
    costs = [1, 2, 3, 4, 5, 6]
    K = 1

    min_cost, max_cost = min_max_candies(costs, K)
    print(f"Costs: {costs}")
    print(f"K: {K}")
    print(f"Minimum: {min_cost}")
    print(f"Maximum: {max_cost}")

    # Test 3: Large K (more free than bought)
    print("\nTest 3: Large K")
    print("-" * 40)
    costs = [1, 2, 3, 4, 5]
    K = 10  # Can get all others free with one purchase

    min_cost, max_cost = min_max_candies(costs, K)
    print(f"Costs: {costs}")
    print(f"K: {K}")
    print(f"Minimum: {min_cost}")  # Just buy cheapest
    print(f"Maximum: {max_cost}")  # Just buy most expensive

    # Test 4: K = 0 (no free candies)
    print("\nTest 4: K = 0 (No Free)")
    print("-" * 40)
    costs = [1, 2, 3, 4]
    K = 0

    min_cost, max_cost = min_max_candies(costs, K)
    print(f"Costs: {costs}")
    print(f"K: {K}")
    print(f"Min = Max = Sum: {min_cost}")
    assert min_cost == max_cost == sum(costs)

    # Test 5: Single candy
    print("\nTest 5: Single Candy")
    print("-" * 40)
    costs = [10]
    K = 5

    min_cost, max_cost = min_max_candies(costs, K)
    print(f"Single candy cost 10")
    print(f"Min = Max: {min_cost}")
    assert min_cost == max_cost == 10

    # Test 6: Empty
    print("\nTest 6: Empty Input")
    print("-" * 40)
    min_cost, max_cost = min_max_candies([], 2)
    print(f"Empty: min={min_cost}, max={max_cost}")
    assert min_cost == 0 and max_cost == 0

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_greedy_choice():
    """Step-by-step demonstration of the algorithm."""

    print("\n" + "=" * 60)
    print("DEMONSTRATION: MIN AND MAX CANDY BUYING")
    print("=" * 60)

    costs = [3, 2, 1, 4, 6, 5]
    K = 2

    print(f"\nOriginal costs: {costs}")
    print(f"K (free per purchase): {K}")

    sorted_costs = sorted(costs)
    print(f"Sorted costs: {sorted_costs}")

    # Minimum
    print("\n" + "-" * 40)
    print("FINDING MINIMUM COST:")
    print("-" * 40)
    print("Strategy: Buy cheap (left), free expensive (right)")

    left, right = 0, len(sorted_costs) - 1
    min_total = 0

    round_num = 1
    while left <= right:
        print(f"\nRound {round_num}:")
        print(f"  Pointers: left={left}, right={right}")
        print(f"  Buy: {sorted_costs[left]}")
        min_total += sorted_costs[left]
        left += 1

        free_items = []
        for _ in range(K):
            if right >= left:
                free_items.append(sorted_costs[right])
                right -= 1

        if free_items:
            print(f"  Free: {free_items}")

        print(f"  Running total: {min_total}")
        round_num += 1

    print(f"\nMINIMUM COST: {min_total}")

    # Maximum
    print("\n" + "-" * 40)
    print("FINDING MAXIMUM COST:")
    print("-" * 40)
    print("Strategy: Buy expensive (right), free cheap (left)")

    left, right = 0, len(sorted_costs) - 1
    max_total = 0

    round_num = 1
    while left <= right:
        print(f"\nRound {round_num}:")
        print(f"  Pointers: left={left}, right={right}")
        print(f"  Buy: {sorted_costs[right]}")
        max_total += sorted_costs[right]
        right -= 1

        free_items = []
        for _ in range(K):
            if left <= right:
                free_items.append(sorted_costs[left])
                left += 1

        if free_items:
            print(f"  Free: {free_items}")

        print(f"  Running total: {max_total}")
        round_num += 1

    print(f"\nMAXIMUM COST: {max_total}")

    print("\n" + "-" * 40)
    print("SUMMARY:")
    print(f"  Minimum: {min_total}")
    print(f"  Maximum: {max_total}")
    print(f"  Difference: {max_total - min_total}")


if __name__ == "__main__":
    run_tests()
    demonstrate_greedy_choice()
