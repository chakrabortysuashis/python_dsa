"""
Maximum Sum of Equal Sum in Three Stacks - Greedy Algorithm
============================================================

Problem: Given three stacks, find maximum sum achievable when all three
have equal sum (can only remove from top).

WHY GREEDY WORKS:
-----------------
1. Greedy Choice: Remove from the stack with largest sum.

2. Exchange Argument: If sums differ, only reducing the largest can help.
   Reducing smaller stacks moves us away from equality.

3. Convergence: Process terminates when sums equal or a stack empties.

GREEDY STRATEGY: Repeatedly pop from largest-sum stack until all equal.
"""

from typing import List


def max_equal_sum(stack1: List[int], stack2: List[int], stack3: List[int]) -> int:
    """
    Find maximum equal sum achievable from three stacks.

    Stacks given as arrays where index 0 is the top.

    Time: O(n1 + n2 + n3)
    Space: O(1)

    Example:
    >>> max_equal_sum([1, 1, 1, 2, 3], [2, 3, 4], [1, 4, 1, 1])
    5
    """
    sum1 = sum(stack1)
    sum2 = sum(stack2)
    sum3 = sum(stack3)

    top1, top2, top3 = 0, 0, 0

    while True:
        # Check if any stack exhausted
        if top1 >= len(stack1) or top2 >= len(stack2) or top3 >= len(stack3):
            return 0

        # Check if equal
        if sum1 == sum2 == sum3:
            return sum1

        # Remove from largest
        if sum1 >= sum2 and sum1 >= sum3:
            sum1 -= stack1[top1]
            top1 += 1
        elif sum2 >= sum1 and sum2 >= sum3:
            sum2 -= stack2[top2]
            top2 += 1
        else:
            sum3 -= stack3[top3]
            top3 += 1


def max_equal_sum_detailed(
    stack1: List[int],
    stack2: List[int],
    stack3: List[int]
) -> tuple:
    """
    Return max sum and removed elements from each stack.
    """
    sum1, sum2, sum3 = sum(stack1), sum(stack2), sum(stack3)
    top1, top2, top3 = 0, 0, 0
    removed1, removed2, removed3 = [], [], []

    while True:
        if top1 >= len(stack1) or top2 >= len(stack2) or top3 >= len(stack3):
            return 0, removed1, removed2, removed3

        if sum1 == sum2 == sum3:
            return sum1, removed1, removed2, removed3

        if sum1 >= sum2 and sum1 >= sum3:
            removed1.append(stack1[top1])
            sum1 -= stack1[top1]
            top1 += 1
        elif sum2 >= sum1 and sum2 >= sum3:
            removed2.append(stack2[top2])
            sum2 -= stack2[top2]
            top2 += 1
        else:
            removed3.append(stack3[top3])
            sum3 -= stack3[top3]
            top3 += 1


def run_tests():
    print("=" * 50)
    print("MAX EQUAL SUM THREE STACKS - TEST CASES")
    print("=" * 50)

    # Test 1
    print("\nTest 1: Basic")
    s1 = [1, 1, 1, 2, 3]  # top to bottom
    s2 = [2, 3, 4]
    s3 = [1, 4, 1, 1]

    result, r1, r2, r3 = max_equal_sum_detailed(s1, s2, s3)
    print(f"Stack 1: {s1}, removed: {r1}")
    print(f"Stack 2: {s2}, removed: {r2}")
    print(f"Stack 3: {s3}, removed: {r3}")
    print(f"Max equal sum: {result}")

    # Test 2: No solution
    print("\nTest 2: Different elements")
    s1 = [1, 1, 1]
    s2 = [2, 2]
    s3 = [3]

    result = max_equal_sum(s1, s2, s3)
    print(f"Result: {result}")

    # Test 3: All same
    print("\nTest 3: All same initial sum")
    s1 = [3]
    s2 = [1, 2]
    s3 = [1, 1, 1]

    result = max_equal_sum(s1, s2, s3)
    print(f"Result: {result}")
    assert result == 3

    print("\nALL TESTS PASSED!")


if __name__ == "__main__":
    run_tests()
