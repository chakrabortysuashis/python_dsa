# Maximum Sum of Equal Sum in Three Stacks

## Problem Statement

Given three stacks of positive integers, find the maximum possible sum such that all three stacks have equal sum. You can only remove elements from the top of stacks.

**Input:** Three stacks (as arrays where first element is bottom)

**Output:** Maximum equal sum achievable

**Example:**
```
Input: 
Stack 1: [3, 2, 1, 1, 1]
Stack 2: [4, 3, 2]
Stack 3: [1, 1, 4, 1]

Output: 5

Explanation:
Stack 1: Remove 1,1,1 -> [3,2] sum=5
Stack 2: Remove 2 -> [4,3] wait... 
Actually: Stack 2 remove 2 -> sum becomes 7-2=5? Let me recalculate.
```

---

## Why Greedy Works Here

### The Greedy Choice Property

**Claim:** Repeatedly remove from the stack with the largest current sum until all sums are equal.

**Intuition:**
- If sums differ, the stack with largest sum must have elements removed
- Removing from smaller stacks can never help
- Greedy reduction converges to maximum equal sum

### Algorithm

1. Calculate initial sums of all three stacks
2. While sums are not equal:
   - Find the stack with maximum sum
   - Remove its top element
3. Return the common sum (or 0 if stacks empty)

---

## Algorithm

```python
def max_equal_sum(stack1, stack2, stack3):
    sum1 = sum(stack1)
    sum2 = sum(stack2)
    sum3 = sum(stack3)
    
    top1, top2, top3 = 0, 0, 0  # Index of current top
    
    while True:
        # If any stack is exhausted
        if top1 >= len(stack1) or top2 >= len(stack2) or top3 >= len(stack3):
            return 0
        
        # If all equal, we found our answer
        if sum1 == sum2 == sum3:
            return sum1
        
        # Remove from largest
        if sum1 >= sum2 and sum1 >= sum3:
            sum1 -= stack1[top1]
            top1 += 1
        elif sum2 >= sum1 and sum2 >= sum3:
            sum2 -= stack2[top2]
            top2 += 1
        else:
            sum3 -= stack3[top3]
            top3 += 1
    
    return 0
```

---

## Time Complexity

O(n1 + n2 + n3) - each element removed at most once
