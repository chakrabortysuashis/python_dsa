"""
Minimum Cost to Connect Ropes - Greedy Algorithm
=================================================

Problem: Connect N ropes into one. Cost of connecting two ropes = sum of lengths.
Find minimum total cost.

WHY GREEDY WORKS:
-----------------
1. Greedy Choice: Always connect the two shortest ropes.

2. Exchange Argument: Shorter ropes should be "deeper" in the merge tree,
   as they contribute their length more times.

3. This is equivalent to building a Huffman tree!

GREEDY STRATEGY: Use min-heap, repeatedly extract two smallest, merge, insert back.
"""

from typing import List
import heapq


def min_cost_ropes(lengths: List[int]) -> int:
    """
    Calculate minimum cost to connect all ropes.

    Uses min-heap to always connect two shortest ropes.

    Time: O(N log N)
    Space: O(N)

    Example:
    >>> min_cost_ropes([4, 3, 2, 6])
    29
    >>> min_cost_ropes([1, 2, 3])
    9
    """
    if len(lengths) <= 1:
        return 0

    heap = lengths[:]
    heapq.heapify(heap)

    total_cost = 0

    while len(heap) > 1:
        first = heapq.heappop(heap)
        second = heapq.heappop(heap)

        cost = first + second
        total_cost += cost

        heapq.heappush(heap, cost)

    return total_cost


def min_cost_ropes_detailed(lengths: List[int]) -> tuple:
    """
    Return cost and sequence of connections.
    """
    if len(lengths) <= 1:
        return 0, []

    heap = lengths[:]
    heapq.heapify(heap)

    total_cost = 0
    connections = []

    while len(heap) > 1:
        first = heapq.heappop(heap)
        second = heapq.heappop(heap)

        cost = first + second
        total_cost += cost
        connections.append((first, second, cost))

        heapq.heappush(heap, cost)

    return total_cost, connections


def run_tests():
    print("=" * 50)
    print("MIN COST ROPES - TEST CASES")
    print("=" * 50)

    # Test 1
    print("\nTest 1: [4, 3, 2, 6]")
    result, connections = min_cost_ropes_detailed([4, 3, 2, 6])
    print("Connections:")
    for a, b, c in connections:
        print(f"  {a} + {b} = {c}")
    print(f"Total: {result}")
    assert result == 29

    # Test 2
    print("\nTest 2: [1, 2, 3]")
    result = min_cost_ropes([1, 2, 3])
    print(f"Result: {result}")
    # 1+2=3 (cost 3), 3+3=6 (cost 6), total = 9
    assert result == 9

    # Test 3: Single rope
    print("\nTest 3: Single rope")
    result = min_cost_ropes([5])
    print(f"Result: {result}")
    assert result == 0

    # Test 4: Two ropes
    print("\nTest 4: Two ropes")
    result = min_cost_ropes([5, 3])
    print(f"Result: {result}")
    assert result == 8

    print("\nALL TESTS PASSED!")


if __name__ == "__main__":
    run_tests()
