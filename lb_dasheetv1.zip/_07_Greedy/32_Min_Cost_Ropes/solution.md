# Minimum Cost to Connect Ropes

## Problem Statement

Given N ropes with different lengths, connect them into one rope with minimum cost. The cost of connecting two ropes equals the sum of their lengths.

**Input:** Array of rope lengths

**Output:** Minimum total cost to connect all ropes

**Example:**
```
Input: [4, 3, 2, 6]
Output: 29

Explanation:
Connect 2+3 = 5, cost = 5, ropes = [4, 5, 6]
Connect 4+5 = 9, cost = 5+9 = 14, ropes = [9, 6]
Connect 6+9 = 15, cost = 14+15 = 29, ropes = [15]
```

---

## Why Greedy Works Here

### The Greedy Choice Property

**Claim:** Always connect the two shortest ropes first.

**Intuition:**
- Each rope's length is added to the cost every time it participates in a connection
- Shorter ropes should participate in more connections
- Therefore, connect short ropes early (they'll be in merged rope for later connections)

### Exchange Argument Proof

1. Suppose optimal solution connects ropes differently
2. If it connects long rope `L` before short rope `S`
3. Swapping their order: S participates more times but is shorter
4. Total cost decreases or stays same
5. Therefore, always connecting shortest first is optimal

---

## Algorithm

```python
import heapq

def min_cost_ropes(lengths):
    if len(lengths) <= 1:
        return 0
    
    heapq.heapify(lengths)  # Min-heap
    total_cost = 0
    
    while len(lengths) > 1:
        # Extract two smallest
        first = heapq.heappop(lengths)
        second = heapq.heappop(lengths)
        
        # Cost of connecting
        cost = first + second
        total_cost += cost
        
        # Put merged rope back
        heapq.heappush(lengths, cost)
    
    return total_cost
```

---

## Time Complexity

O(N log N) - N heap operations, each O(log N)

---

## Connection to Huffman Coding

This problem is equivalent to building a Huffman tree where rope lengths are frequencies. The minimum cost equals the weighted path length.
