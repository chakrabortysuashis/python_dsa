"""
Activity Selection Problem - Greedy Algorithm
=============================================

Problem: Given n activities with start and finish times, select the maximum
number of activities that can be performed by a single person (no overlap).

WHY GREEDY WORKS:
----------------
1. Greedy Choice Property: The activity with earliest finish time is always
   part of some optimal solution.

2. Exchange Argument: If optimal solution OPT doesn't include the earliest
   finishing activity 'g', we can replace OPT's first activity with 'g'
   without reducing the count (since g finishes earlier, it won't conflict
   with subsequent activities in OPT).

3. Optimal Substructure: After selecting an activity, the remaining problem
   is a smaller instance of the same problem.

GREEDY STRATEGY: Sort by finish time, always pick the earliest finishing
activity that doesn't conflict with previously selected activities.
"""

from typing import List, Tuple


def activity_selection_basic(start: List[int], finish: List[int]) -> int:
    """
    Basic activity selection - returns count of maximum activities.

    Greedy Strategy:
    1. Sort activities by finish time (ascending)
    2. Select first activity
    3. For each remaining, select if start >= last selected's finish

    Time: O(n log n) for sorting
    Space: O(n) for storing paired activities

    Example:
    >>> activity_selection_basic([1, 3, 0, 5, 8, 5], [2, 4, 6, 7, 9, 9])
    4
    """
    n = len(start)
    if n == 0:
        return 0

    # Pair activities with their indices and sort by finish time
    # Sorting by finish time is THE key greedy insight
    activities = sorted(zip(start, finish), key=lambda x: x[1])

    count = 1  # First activity always selected
    last_finish = activities[0][1]

    # Greedy selection: pick if doesn't overlap
    for s, f in activities[1:]:
        if s >= last_finish:  # No overlap condition
            count += 1
            last_finish = f

    return count


def activity_selection_with_indices(
    start: List[int],
    finish: List[int]
) -> Tuple[int, List[int]]:
    """
    Activity selection returning both count and selected activity indices.

    Returns:
        Tuple of (count, list of original indices of selected activities)

    Example:
    >>> count, indices = activity_selection_with_indices([1, 3, 0, 5, 8, 5], [2, 4, 6, 7, 9, 9])
    >>> count
    4
    >>> indices  # Original indices of selected activities
    [0, 3, 4, ...]
    """
    n = len(start)
    if n == 0:
        return 0, []

    # Include original index for tracking
    activities = [(start[i], finish[i], i) for i in range(n)]
    activities.sort(key=lambda x: x[1])  # Sort by finish time

    selected_indices = [activities[0][2]]
    last_finish = activities[0][1]

    for s, f, idx in activities[1:]:
        if s >= last_finish:
            selected_indices.append(idx)
            last_finish = f

    return len(selected_indices), selected_indices


def activity_selection_recursive(
    activities: List[Tuple[int, int]],
    last_finish: int = 0
) -> List[Tuple[int, int]]:
    """
    Recursive implementation demonstrating the greedy choice at each step.

    This version explicitly shows the greedy choice property:
    - At each step, we pick the compatible activity with earliest finish
    - Then recursively solve for remaining activities

    Time: O(n log n) initially, O(n) for recursion
    Space: O(n) recursion stack
    """
    # Base case
    if not activities:
        return []

    # Sort by finish time (do once, pass sorted list in recursion)
    sorted_acts = sorted(activities, key=lambda x: x[1])

    # Greedy choice: find first compatible activity
    for i, (start, finish) in enumerate(sorted_acts):
        if start >= last_finish:
            # This is our greedy choice - earliest finishing compatible activity
            return [(start, finish)] + activity_selection_recursive(
                sorted_acts[i+1:],
                finish
            )

    # No compatible activity found
    return []


def activity_selection_with_names(
    activities: List[Tuple[str, int, int]]
) -> Tuple[int, List[str]]:
    """
    Activity selection with named activities for better understanding.

    Args:
        activities: List of (name, start, finish) tuples

    Returns:
        (count, list of selected activity names)

    Example:
    >>> activities = [('Meeting A', 1, 4), ('Meeting B', 3, 5), ('Meeting C', 5, 7)]
    >>> activity_selection_with_names(activities)
    (2, ['Meeting A', 'Meeting C'])
    """
    if not activities:
        return 0, []

    # Sort by finish time
    sorted_acts = sorted(activities, key=lambda x: x[2])

    selected = [sorted_acts[0][0]]  # Name of first activity
    last_finish = sorted_acts[0][2]

    for name, start, finish in sorted_acts[1:]:
        if start >= last_finish:
            selected.append(name)
            last_finish = finish

    return len(selected), selected


def activity_selection_weighted(
    activities: List[Tuple[int, int, int]]
) -> int:
    """
    NOTE: This is NOT solvable by greedy!
    Included to show when greedy fails.

    When activities have weights/profits, greedy by finish time fails.
    Must use Dynamic Programming (Weighted Job Scheduling).

    Example where greedy fails:
    Activities: [(0, 3, 50), (1, 4, 10), (3, 6, 40), (5, 7, 70)]
                (start, end, profit)

    Greedy (by finish time): (0,3,50), (3,6,40) = profit 90
    Optimal (DP): (0,3,50), (5,7,70) = profit 120

    For weighted version, use DP with binary search.
    """
    print("WARNING: Weighted activity selection requires DP, not greedy!")
    print("Greedy approach will give suboptimal results.")
    return -1


# =============================================================================
# COMPARISON: Greedy vs Brute Force
# =============================================================================

def activity_selection_brute_force(start: List[int], finish: List[int]) -> int:
    """
    Brute force approach - try all subsets.

    Time: O(2^n * n) - Exponential!
    Space: O(n)

    This demonstrates why greedy is so valuable - O(n log n) vs O(2^n)
    """
    n = len(start)
    max_count = 0

    # Try all 2^n subsets
    for mask in range(1 << n):
        subset = []
        for i in range(n):
            if mask & (1 << i):
                subset.append((start[i], finish[i]))

        # Check if valid (no overlaps)
        subset.sort(key=lambda x: x[1])
        valid = True
        for i in range(1, len(subset)):
            if subset[i][0] < subset[i-1][1]:
                valid = False
                break

        if valid:
            max_count = max(max_count, len(subset))

    return max_count


# =============================================================================
# VARIATIONS
# =============================================================================

def minimum_meeting_rooms(intervals: List[Tuple[int, int]]) -> int:
    """
    Related problem: Minimum meeting rooms needed.

    This is different from activity selection!
    Here we need to schedule ALL meetings, using minimum rooms.

    Approach: Process events (arrivals and departures) in order.

    Time: O(n log n)
    Space: O(n)
    """
    if not intervals:
        return 0

    events = []
    for start, end in intervals:
        events.append((start, 1))   # Arrival
        events.append((end, -1))    # Departure

    # Sort by time, with departures before arrivals at same time
    events.sort(key=lambda x: (x[0], x[1]))

    current_rooms = 0
    max_rooms = 0

    for _, event_type in events:
        current_rooms += event_type
        max_rooms = max(max_rooms, current_rooms)

    return max_rooms


def minimum_removals_for_non_overlapping(intervals: List[Tuple[int, int]]) -> int:
    """
    Minimum intervals to remove to make remaining non-overlapping.

    Answer = total - maximum non-overlapping

    This is activity selection in disguise!
    """
    n = len(intervals)
    if n == 0:
        return 0

    # Sort by end time
    sorted_intervals = sorted(intervals, key=lambda x: x[1])

    # Count maximum non-overlapping (activity selection)
    count = 1
    last_end = sorted_intervals[0][1]

    for start, end in sorted_intervals[1:]:
        if start >= last_end:
            count += 1
            last_end = end

    return n - count


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Comprehensive test cases with explanations."""

    print("=" * 60)
    print("ACTIVITY SELECTION PROBLEM - TEST CASES")
    print("=" * 60)

    # Test 1: Basic example
    print("\nTest 1: Basic Example")
    print("-" * 40)
    start = [1, 3, 0, 5, 8, 5]
    finish = [2, 4, 6, 7, 9, 9]

    result = activity_selection_basic(start, finish)
    print(f"Activities (start, finish):")
    for i in range(len(start)):
        print(f"  Activity {i}: ({start[i]}, {finish[i]})")
    print(f"Maximum activities: {result}")
    assert result == 4, f"Expected 4, got {result}"

    # Test 2: Classic example with named activities
    print("\nTest 2: Named Activities")
    print("-" * 40)
    activities = [
        ('A', 1, 4), ('B', 3, 5), ('C', 0, 6), ('D', 5, 7),
        ('E', 3, 9), ('F', 5, 9), ('G', 6, 10), ('H', 8, 11),
        ('I', 8, 12), ('J', 2, 14), ('K', 12, 16)
    ]

    count, selected = activity_selection_with_names(activities)
    print(f"Activities: {[(a[0], a[1], a[2]) for a in activities]}")
    print(f"Selected: {selected}")
    print(f"Count: {count}")
    assert count == 4, f"Expected 4, got {count}"

    # Test 3: All overlapping
    print("\nTest 3: All Overlapping")
    print("-" * 40)
    start = [1, 2, 3, 4]
    finish = [10, 10, 10, 10]
    result = activity_selection_basic(start, finish)
    print(f"Activities: {list(zip(start, finish))}")
    print(f"Maximum activities: {result}")
    assert result == 1, f"Expected 1, got {result}"

    # Test 4: No overlapping
    print("\nTest 4: No Overlapping")
    print("-" * 40)
    start = [1, 3, 5, 7]
    finish = [2, 4, 6, 8]
    result = activity_selection_basic(start, finish)
    print(f"Activities: {list(zip(start, finish))}")
    print(f"Maximum activities: {result}")
    assert result == 4, f"Expected 4, got {result}"

    # Test 5: Single activity
    print("\nTest 5: Single Activity")
    print("-" * 40)
    result = activity_selection_basic([5], [10])
    print(f"Single activity: (5, 10)")
    print(f"Maximum activities: {result}")
    assert result == 1, f"Expected 1, got {result}"

    # Test 6: Empty input
    print("\nTest 6: Empty Input")
    print("-" * 40)
    result = activity_selection_basic([], [])
    print(f"Empty input")
    print(f"Maximum activities: {result}")
    assert result == 0, f"Expected 0, got {result}"

    # Test 7: Compare with brute force (small input)
    print("\nTest 7: Greedy vs Brute Force Comparison")
    print("-" * 40)
    start = [1, 3, 0, 5, 3, 5, 6, 8]
    finish = [2, 4, 6, 7, 9, 9, 10, 11]

    greedy_result = activity_selection_basic(start, finish)
    brute_result = activity_selection_brute_force(start, finish)

    print(f"Greedy result: {greedy_result}")
    print(f"Brute force result: {brute_result}")
    print(f"Match: {greedy_result == brute_result}")
    assert greedy_result == brute_result, "Greedy should match brute force!"

    # Test 8: Related problem - Minimum Rooms
    print("\nTest 8: Minimum Meeting Rooms (Related Problem)")
    print("-" * 40)
    intervals = [(0, 30), (5, 10), (15, 20)]
    rooms = minimum_meeting_rooms(intervals)
    print(f"Meetings: {intervals}")
    print(f"Minimum rooms needed: {rooms}")
    assert rooms == 2, f"Expected 2, got {rooms}"

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_greedy_choice():
    """
    Step-by-step demonstration of why greedy works.
    """
    print("\n" + "=" * 60)
    print("DEMONSTRATION: WHY GREEDY WORKS")
    print("=" * 60)

    activities = [
        ('A', 1, 4), ('B', 3, 5), ('C', 0, 6), ('D', 5, 7),
        ('E', 3, 9), ('F', 5, 9), ('G', 6, 10), ('H', 8, 11)
    ]

    print("\nOriginal activities:")
    for name, start, finish in activities:
        print(f"  {name}: [{start}, {finish}]")

    # Sort by finish time
    sorted_acts = sorted(activities, key=lambda x: x[2])

    print("\nAfter sorting by FINISH TIME (key insight!):")
    for name, start, finish in sorted_acts:
        print(f"  {name}: [{start}, {finish}] - finishes at {finish}")

    print("\nGreedy Selection Process:")
    print("-" * 40)

    selected = []
    last_finish = 0

    for name, start, finish in sorted_acts:
        print(f"\nConsidering {name} ({start}-{finish}):")
        print(f"  Last finish time: {last_finish}")
        print(f"  Start time: {start}")

        if start >= last_finish:
            print(f"  {start} >= {last_finish}? YES!")
            print(f"  -> SELECT {name}")
            selected.append(name)
            last_finish = finish
        else:
            print(f"  {start} >= {last_finish}? NO - overlaps!")
            print(f"  -> SKIP {name}")

    print("\n" + "-" * 40)
    print(f"Final Selection: {' -> '.join(selected)}")
    print(f"Total: {len(selected)} activities")

    print("\nWHY THIS IS OPTIMAL:")
    print("By always picking the earliest finishing activity, we leave")
    print("maximum room for future activities. Any other choice would")
    print("finish later and potentially block more activities.")


if __name__ == "__main__":
    run_tests()
    demonstrate_greedy_choice()
