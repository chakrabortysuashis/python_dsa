# Activity Selection Problem

## Problem Statement

Given `n` activities with their start and finish times, select the maximum number of activities that can be performed by a single person, assuming that a person can only work on a single activity at a time.

**Input:** 
- `start[]` - Array of start times
- `finish[]` - Array of finish times

**Output:** Maximum number of non-overlapping activities

**Example:**
```
Activities: [(1,4), (3,5), (0,6), (5,7), (3,9), (5,9), (6,10), (8,11), (8,12), (2,14), (12,16)]
Output: 4
Selected Activities: (1,4), (5,7), (8,11), (12,16)
```

---

## Why Greedy Works Here

### The Greedy Choice Property

**Claim:** There exists an optimal solution that includes the activity with the earliest finish time.

**Intuition:** 
- By choosing the activity that finishes earliest, we leave as much room as possible for remaining activities
- Finishing early = more time available for future selections
- We're not "wasting" potential time by extending unnecessarily

### Exchange Argument Proof

1. Let `OPT` be any optimal solution with activities sorted by finish time: `{a1, a2, ..., ak}`
2. Let `g` be the activity with the globally earliest finish time
3. **Case 1:** `g = a1` - We're done, optimal includes our greedy choice
4. **Case 2:** `g != a1` - Then `finish(g) <= finish(a1)`
   - Create `OPT' = {g, a2, ..., ak}`
   - Since `finish(g) <= finish(a1)` and `a2` didn't conflict with `a1`:
     - `start(a2) >= finish(a1) >= finish(g)`
   - So `a2` doesn't conflict with `g` either
   - `OPT'` is valid and has same size as `OPT`
5. Therefore, greedy choice is safe!

### Why Other Greedy Strategies Fail

| Strategy | Why It Fails |
|----------|--------------|
| Earliest start time | Long activity might block many short ones |
| Shortest duration | Short activity might be in the middle, blocking two |
| Fewest conflicts | Computationally expensive, and still not optimal |

**Counterexample for "Earliest Start":**
```
A: [0, 10]  <-- Starts earliest
B: [1, 3]
C: [4, 6]
D: [7, 9]

Earliest start picks A (1 activity)
Optimal: B, C, D (3 activities)
```

---

## Step-by-Step Greedy Selection

### Algorithm:

```
1. SORT activities by finish time (ascending)
2. SELECT first activity (always safe)
3. FOR each remaining activity:
   - IF start_time >= last_selected_finish_time:
     - SELECT this activity
     - UPDATE last_selected_finish_time
4. RETURN count of selected activities
```

### Why Sort by Finish Time?

Sorting brings activities that "get out of the way" earliest to the front. This ensures:
- We always have maximum remaining time after each selection
- We never regret our greedy choice

---

## Brute Force Comparison

### Brute Force Approach
Generate all possible subsets of activities, check each for validity (no overlaps), and find the maximum valid subset.

```python
def brute_force(activities):
    n = len(activities)
    max_count = 0
    
    for mask in range(1 << n):  # 2^n subsets
        subset = [activities[i] for i in range(n) if mask & (1 << i)]
        
        # Check if valid (no overlaps)
        subset.sort(key=lambda x: x[1])
        valid = True
        for i in range(1, len(subset)):
            if subset[i][0] < subset[i-1][1]:
                valid = False
                break
        
        if valid:
            max_count = max(max_count, len(subset))
    
    return max_count
```

**Time Complexity:** O(2^n * n log n)
**Space Complexity:** O(n)

### Why Brute Force is Impractical
- For n=20: 2^20 = 1,048,576 subsets
- For n=30: 2^30 = 1,073,741,824 subsets
- Exponential growth makes it infeasible

---

## Optimal Greedy Approach

```python
def activity_selection(start, finish):
    n = len(start)
    
    # Create activities with indices
    activities = [(start[i], finish[i], i) for i in range(n)]
    
    # Sort by finish time
    activities.sort(key=lambda x: x[1])
    
    # Greedy selection
    selected = [activities[0][2]]  # First activity always selected
    last_finish = activities[0][1]
    
    for i in range(1, n):
        if activities[i][0] >= last_finish:
            selected.append(activities[i][2])
            last_finish = activities[i][1]
    
    return len(selected), selected
```

**Time Complexity:** O(n log n) for sorting
**Space Complexity:** O(n) for storing activities

---

## Dry Run with Selection Visualization

**Input:**
```
Activities: A(1,4), B(3,5), C(0,6), D(5,7), E(3,9), F(5,9), G(6,10), H(8,11), I(8,12), J(2,14), K(12,16)
```

**Step 1: Sort by Finish Time**
```
Sorted: A(1,4), B(3,5), C(0,6), D(5,7), E(3,9), F(5,9), G(6,10), H(8,11), I(8,12), J(2,14), K(12,16)
```

**Step 2: Greedy Selection**

```
Timeline: 0----1----2----3----4----5----6----7----8----9----10---11---12---13---14---15---16
          
Step 1: Consider A(1,4)
        ████████████                                                                    
        Selected! (first activity)
        Last finish = 4
        Selected: [A]

Step 2: Consider B(3,5)
        Start=3 < Last_finish=4? YES - SKIP (overlaps)
        
Step 3: Consider C(0,6)
        Start=0 < Last_finish=4? YES - SKIP (overlaps)
        
Step 4: Consider D(5,7)
        Start=5 >= Last_finish=4? YES - SELECT!
                    ████████                                                            
        Last finish = 7
        Selected: [A, D]

Step 5: Consider E(3,9)
        Start=3 < Last_finish=7? YES - SKIP (overlaps)

Step 6: Consider F(5,9)
        Start=5 < Last_finish=7? YES - SKIP (overlaps)

Step 7: Consider G(6,10)
        Start=6 < Last_finish=7? YES - SKIP (overlaps)

Step 8: Consider H(8,11)
        Start=8 >= Last_finish=7? YES - SELECT!
                            ████████████                                                
        Last finish = 11
        Selected: [A, D, H]

Step 9: Consider I(8,12)
        Start=8 < Last_finish=11? YES - SKIP (overlaps)

Step 10: Consider J(2,14)
         Start=2 < Last_finish=11? YES - SKIP (overlaps)

Step 11: Consider K(12,16)
         Start=12 >= Last_finish=11? YES - SELECT!
                                    ████████████████                                    
         Last finish = 16
         Selected: [A, D, H, K]
```

**Final Result:**
```
Selected Activities: A(1,4), D(5,7), H(8,11), K(12,16)
Maximum Count: 4

Visual:
0----1----2----3----4----5----6----7----8----9----10---11---12---13---14---15---16
     [===A===]   [==D==]       [===H===]     [====K====]
```

---

## Time and Space Complexity

| Aspect | Complexity | Explanation |
|--------|------------|-------------|
| **Time** | O(n log n) | Dominated by sorting; selection is O(n) |
| **Space** | O(n) | Storing sorted activities |

### Breakdown:
- **Sorting:** O(n log n)
- **Single pass selection:** O(n)
- **Total:** O(n log n) + O(n) = O(n log n)

### If Already Sorted:
- Time reduces to O(n)
- Just one pass through activities

---

## Variations and Extensions

### 1. Weighted Activity Selection
When activities have profits, greedy doesn't work. Use DP instead.

### 2. K-Person Activity Selection
Schedule activities among K people to maximize total activities.

### 3. Minimum Meetings to Remove
Find minimum activities to remove so remaining don't overlap.
- Answer: n - (maximum non-overlapping)

### 4. Activity Selection with Overlap Allowed
If activities can overlap by at most T units, adjust the comparison:
```python
if activities[i][0] >= last_finish - T:
```
