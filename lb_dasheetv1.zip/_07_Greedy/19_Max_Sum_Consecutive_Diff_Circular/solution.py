"""
Maximum Sum of Consecutive Differences (Circular Array) - Greedy Algorithm
===========================================================================

Problem: Given a circular array of n integers, rearrange elements to maximize
the sum of absolute differences of consecutive elements, where the array wraps
around (last element adjacent to first).

WHY GREEDY WORKS:
-----------------
1. Greedy Choice Property: In a circular array, every element contributes to
   exactly TWO differences. Placing extreme values (min/max) adjacent maximizes
   each element's contribution.

2. Exchange Argument: If an element is not adjacent to extreme values, swapping
   positions increases the total sum because extremes create larger differences.

3. Mathematical Insight: Optimal arrangement pairs smallest with largest elements.
   Formula: 2 * sum(arr[n-1-i] - arr[i]) for i in range(n//2)

GREEDY STRATEGY: Sort array and pair elements from opposite ends. Each pair
contributes its difference twice to the circular sum.
"""

from typing import List, Tuple
from itertools import permutations


def max_circular_diff(arr: List[int]) -> int:
    """
    Calculate maximum circular sum of absolute differences.

    Greedy Strategy:
    1. Sort the array
    2. Pair elements from extremes: (a[0], a[n-1]), (a[1], a[n-2]), ...
    3. Each pair's difference counts twice in circular arrangement
    4. Return 2 * sum of all pair differences

    Time: O(n log n) for sorting
    Space: O(1) extra (if sorting in place)

    Example:
    >>> max_circular_diff([4, 2, 1, 8])
    18
    >>> max_circular_diff([1, 2, 3, 4])
    8
    """
    n = len(arr)
    if n <= 1:
        return 0

    arr = sorted(arr)

    # Calculate sum of pair differences
    total = 0
    for i in range(n // 2):
        total += arr[n - 1 - i] - arr[i]

    # Multiply by 2 for circular arrangement
    return 2 * total


def max_circular_diff_with_arrangement(arr: List[int]) -> Tuple[int, List[int]]:
    """
    Return both maximum sum and an optimal arrangement.

    The arrangement alternates between smallest and largest remaining elements,
    creating a zigzag pattern that maximizes differences.

    Returns:
        Tuple of (maximum_sum, optimal_arrangement)

    Example:
    >>> sum_val, arrangement = max_circular_diff_with_arrangement([4, 2, 1, 8])
    >>> sum_val
    18
    """
    n = len(arr)
    if n <= 1:
        return 0, arr[:]

    sorted_arr = sorted(arr)

    # Build zigzag arrangement
    result = []
    left, right = 0, n - 1

    while left <= right:
        if left <= right:
            result.append(sorted_arr[left])
            left += 1
        if left <= right:
            result.append(sorted_arr[right])
            right -= 1

    # Calculate circular sum
    total = sum(abs(result[i] - result[(i + 1) % n]) for i in range(n))

    return total, result


def max_circular_diff_formula(arr: List[int]) -> int:
    """
    Direct formula computation (most efficient).

    For sorted array, maximum circular sum = 2 * (sum of larger half - sum of smaller half)

    Time: O(n log n) for sorting
    Space: O(n) for sorted copy

    Example:
    >>> max_circular_diff_formula([4, 2, 1, 8])
    18
    """
    n = len(arr)
    if n <= 1:
        return 0

    arr = sorted(arr)

    # Sum of smaller half
    small_sum = sum(arr[:n // 2])

    # Sum of larger half (handles odd n correctly)
    large_sum = sum(arr[(n + 1) // 2:])

    # For odd n, middle element doesn't pair, but formula still works
    # because middle element contributes to both halves conceptually

    return 2 * (large_sum - small_sum)


# =============================================================================
# BRUTE FORCE - For comparison and verification
# =============================================================================

def brute_force_circular(arr: List[int]) -> int:
    """
    Brute force: try all permutations, calculate circular sum for each.

    Time: O(n! * n)
    Space: O(n)

    Only use for small inputs (n <= 8)
    """
    if len(arr) <= 1:
        return 0

    n = len(arr)
    max_sum = 0

    for perm in permutations(arr):
        # Calculate circular sum
        curr_sum = sum(abs(perm[i] - perm[(i + 1) % n]) for i in range(n))
        max_sum = max(max_sum, curr_sum)

    return max_sum


def calculate_circular_sum(arr: List[int]) -> int:
    """
    Calculate circular sum of absolute differences for a given arrangement.

    Example:
    >>> calculate_circular_sum([1, 8, 2, 4])
    18
    """
    n = len(arr)
    if n <= 1:
        return 0
    return sum(abs(arr[i] - arr[(i + 1) % n]) for i in range(n))


# =============================================================================
# RELATED PROBLEMS
# =============================================================================

def min_circular_diff(arr: List[int]) -> int:
    """
    Minimize circular sum of absolute differences.

    Solution: Keep array sorted! Adjacent sorted elements minimize differences.
    For circular, the wrap-around difference (max - min) is unavoidable.

    Time: O(n log n)
    Space: O(1)

    Example:
    >>> min_circular_diff([4, 2, 1, 8])
    10
    """
    if len(arr) <= 1:
        return 0

    arr = sorted(arr)
    n = len(arr)

    # Sum of adjacent differences in sorted array
    regular_sum = sum(arr[i + 1] - arr[i] for i in range(n - 1))

    # Add circular wrap-around
    circular_diff = arr[n - 1] - arr[0]

    return regular_sum + circular_diff


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Comprehensive test cases with explanations."""

    print("=" * 60)
    print("MAX CIRCULAR SUM OF DIFFERENCES - TEST CASES")
    print("=" * 60)

    # Test 1: Basic example
    print("\nTest 1: Basic Example")
    print("-" * 40)
    arr = [4, 2, 1, 8]
    result = max_circular_diff(arr)
    brute = brute_force_circular(arr)
    sum_val, arrangement = max_circular_diff_with_arrangement(arr)

    print(f"Input: {arr}")
    print(f"Optimal arrangement: {arrangement}")
    print(f"Greedy result: {result}")
    print(f"Brute force result: {brute}")
    assert result == brute, f"Mismatch! Greedy: {result}, Brute: {brute}"
    print("PASS")

    # Test 2: Sequential array
    print("\nTest 2: Sequential Array")
    print("-" * 40)
    arr = [1, 2, 3, 4]
    result = max_circular_diff(arr)
    brute = brute_force_circular(arr)
    print(f"Input: {arr}")
    print(f"Greedy: {result}, Brute: {brute}")
    assert result == brute
    print("PASS")

    # Test 3: All same elements
    print("\nTest 3: All Same Elements")
    print("-" * 40)
    arr = [5, 5, 5, 5]
    result = max_circular_diff(arr)
    print(f"Input: {arr}")
    print(f"Result: {result}")
    assert result == 0
    print("PASS")

    # Test 4: Two elements
    print("\nTest 4: Two Elements")
    print("-" * 40)
    arr = [1, 10]
    result = max_circular_diff(arr)
    # Circular: |1-10| + |10-1| = 9 + 9 = 18
    print(f"Input: {arr}")
    print(f"Result: {result}")
    assert result == 18, f"Expected 18, got {result}"
    print("PASS")

    # Test 5: Odd length array
    print("\nTest 5: Odd Length Array")
    print("-" * 40)
    arr = [1, 2, 3, 4, 5]
    result = max_circular_diff(arr)
    brute = brute_force_circular(arr)
    print(f"Input: {arr}")
    print(f"Greedy: {result}, Brute: {brute}")
    assert result == brute
    print("PASS")

    # Test 6: Negative numbers
    print("\nTest 6: Negative Numbers")
    print("-" * 40)
    arr = [-5, -2, 3, 8]
    result = max_circular_diff(arr)
    brute = brute_force_circular(arr)
    print(f"Input: {arr}")
    print(f"Greedy: {result}, Brute: {brute}")
    assert result == brute
    print("PASS")

    # Test 7: Formula method comparison
    print("\nTest 7: Compare Methods")
    print("-" * 40)
    arr = [3, 7, 2, 9, 1, 5]

    result1 = max_circular_diff(arr)
    result2 = max_circular_diff_formula(arr)
    brute = brute_force_circular(arr)

    print(f"Input: {arr}")
    print(f"Greedy: {result1}")
    print(f"Formula: {result2}")
    print(f"Brute: {brute}")

    assert result1 == brute, "Greedy method failed"
    print("PASS")

    # Test 8: Verify arrangement
    print("\nTest 8: Verify Arrangement")
    print("-" * 40)
    arr = [1, 4, 8, 2]
    sum_val, arrangement = max_circular_diff_with_arrangement(arr)
    calculated = calculate_circular_sum(arrangement)

    print(f"Input: {arr}")
    print(f"Arrangement: {arrangement}")
    print(f"Reported sum: {sum_val}")
    print(f"Calculated sum: {calculated}")
    assert sum_val == calculated
    print("PASS")

    # Test 9: Min vs Max comparison
    print("\nTest 9: Minimize vs Maximize")
    print("-" * 40)
    arr = [4, 2, 1, 8]
    max_result = max_circular_diff(arr)
    min_result = min_circular_diff(arr)
    print(f"Input: {arr}")
    print(f"Maximum circular sum: {max_result}")
    print(f"Minimum circular sum: {min_result}")
    print("PASS")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_circular_property():
    """Demonstrate why circular arrangement changes the problem."""

    print("\n" + "=" * 60)
    print("CIRCULAR VS NON-CIRCULAR COMPARISON")
    print("=" * 60)

    arr = [1, 3, 5, 9]
    print(f"\nArray: {arr}")

    # Non-circular
    sorted_arr = sorted(arr)
    result = []
    left, right = 0, len(arr) - 1
    while left <= right:
        result.append(sorted_arr[right])
        right -= 1
        if left <= right:
            result.append(sorted_arr[left])
            left += 1

    non_circular_sum = sum(abs(result[i] - result[i+1]) for i in range(len(result)-1))

    print(f"\nNon-circular arrangement: {result}")
    print(f"Non-circular sum: {non_circular_sum}")

    # Circular
    circular_sum = max_circular_diff(arr)
    print(f"\nCircular maximum sum: {circular_sum}")

    print("\nDifference:")
    print(f"  Circular adds wrap-around: |{result[-1]} - {result[0]}| = {abs(result[-1] - result[0])}")
    print(f"  Extra contribution in circular case")


if __name__ == "__main__":
    run_tests()
    demonstrate_circular_property()
