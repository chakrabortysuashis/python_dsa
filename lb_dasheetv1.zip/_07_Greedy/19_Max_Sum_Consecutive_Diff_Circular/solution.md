# Maximum Sum of Consecutive Differences (Circular Array)

## Problem Statement

Given a circular array of `n` integers, rearrange the elements to maximize the sum of absolute differences of consecutive elements, where the last element is also adjacent to the first element.

**Input:** Circular array `arr[]` of n integers

**Output:** Maximum possible sum of `|arr[0] - arr[1]| + |arr[1] - arr[2]| + ... + |arr[n-1] - arr[0]|`

**Example:**
```
Input: arr[] = [4, 2, 1, 8]
Output: 18
Optimal: [1, 8, 2, 4] gives |1-8| + |8-2| + |2-4| + |4-1| = 7 + 6 + 2 + 3 = 18
```

---

## Why Greedy Works Here

### The Greedy Choice Property

**Claim:** In a circular arrangement, every element contributes to exactly TWO differences. To maximize the sum, each element should be adjacent to elements as far from it as possible.

**Intuition:**
- In a circular array, there are n differences (not n-1)
- Every element is counted twice in the total sum
- Pairing smallest with largest maximizes contribution

### Exchange Argument Proof

1. Consider any arrangement. Each element `a[i]` appears in exactly two differences
2. If element `x` (not extreme) is adjacent to extreme values, swapping `x` with a more extreme value increases the sum
3. Therefore, optimal arrangement alternates small-large-small-large
4. In circular case: pair up elements from sorted array's extremes

### Mathematical Formula

For sorted array `[a1, a2, ..., an]`:
- Each element contributes to 2 differences
- Optimal pairing: (a1, an), (a2, an-1), ...
- **Formula:** `2 * [(an - a1) + (an-1 - a2) + ...]`
- Simplified: `2 * [sum of second half - sum of first half]`

---

## Step-by-Step Greedy Selection

### Algorithm:

```
1. SORT array in ascending order
2. DIVIDE into two halves: smaller and larger
3. CALCULATE: 2 * (sum of larger half - sum of smaller half)
4. RETURN result
```

### Why Multiply by 2?

In circular arrangement:
- Each element appears in exactly 2 adjacent pairs
- Element `a` adjacent to elements `b` and `c`
- Contributes: `|a-b| + |a-c|`
- When `a` is between extreme values, this is maximized

---

## Brute Force Comparison

### Brute Force Approach
Generate all cyclic permutations and calculate circular sum.

```python
from itertools import permutations

def brute_force_circular(arr):
    n = len(arr)
    max_sum = 0
    
    for perm in permutations(arr):
        curr_sum = sum(abs(perm[i] - perm[(i+1) % n]) for i in range(n))
        max_sum = max(max_sum, curr_sum)
    
    return max_sum
```

**Time Complexity:** O(n! * n)
**Space Complexity:** O(n)

---

## Optimal Greedy Approach

```python
def max_circular_diff(arr):
    n = len(arr)
    if n <= 1:
        return 0
    
    arr.sort()
    
    # Sum of differences between paired elements
    total = 0
    for i in range(n // 2):
        total += arr[n - 1 - i] - arr[i]
    
    # Each pair contributes twice in circular arrangement
    return 2 * total
```

**Time Complexity:** O(n log n) for sorting
**Space Complexity:** O(1) extra space

---

## Dry Run with Selection Visualization

**Input:** `arr = [4, 2, 1, 8]`

**Step 1: Sort Array**
```
Sorted: [1, 2, 4, 8]
```

**Step 2: Identify Pairs**
```
Pair 1: (1, 8) - difference = 7
Pair 2: (2, 4) - difference = 2

Sum of differences = 7 + 2 = 9
```

**Step 3: Multiply by 2**
```
Circular sum = 2 * 9 = 18
```

**Verification with Arrangement:**
```
Arrangement: [1, 8, 2, 4] (zigzag)

Differences:
|1 - 8| = 7
|8 - 2| = 6
|2 - 4| = 2
|4 - 1| = 3 (circular wrap)

Total = 7 + 6 + 2 + 3 = 18 ✓
```

---

## Time and Space Complexity

| Aspect | Complexity | Explanation |
|--------|------------|-------------|
| **Time** | O(n log n) | Dominated by sorting |
| **Space** | O(1) | Only need to compute sum |

### Comparison with Non-Circular:
- Non-circular: Formula slightly different (endpoints contribute once)
- Circular: Clean formula since every element contributes twice

---

## Key Difference from Non-Circular Version

| Aspect | Non-Circular | Circular |
|--------|--------------|----------|
| Differences | n - 1 | n |
| Endpoint contribution | Once | Twice |
| Formula | More complex | 2 * sum(large - small pairs) |

---

## Variations and Extensions

### 1. Minimize Circular Sum
Keep array sorted - adjacent sorted elements minimize differences.

### 2. K Rotations
After K rotations, find arrangement maximizing sum.

### 3. Weighted Circular
If positions have weights, problem becomes more complex.
