"""
GERGOVIA - Wine Trading (SPOJ) - Greedy Algorithm
==================================================

Problem: N houses in a row, each with demand (buy > 0, sell < 0).
Find minimum work (units * distance) to satisfy all demands.

WHY GREEDY WORKS:
-----------------
1. Key Insight: At each boundary between adjacent houses, some amount of
   wine must cross. The total work is sum of all boundary crossings.

2. Running Sum: The prefix sum at position i represents net flow across
   the boundary between houses i and i+1.

3. Greedy Choice: We don't need to optimize which seller supplies which
   buyer - just track total flow at each boundary.

GREEDY STRATEGY: Sum of absolute values of prefix sums gives minimum work.
"""

from typing import List, Tuple


def gergovia(demands: List[int]) -> int:
    """
    Calculate minimum work for wine trading.

    At each boundary, |running_sum| wine must cross.
    Total work = sum of |prefix_sum[i]| for i in 0..n-2

    Time: O(n)
    Space: O(1)

    Example:
    >>> gergovia([5, -4, 1, -3, 1])
    9
    >>> gergovia([1, -1])
    1
    """
    work = 0
    flow = 0

    for demand in demands[:-1]:  # Last house doesn't have a boundary after it
        flow += demand
        work += abs(flow)

    return work


def gergovia_detailed(demands: List[int]) -> Tuple[int, List[int]]:
    """
    Return work and flow at each boundary.

    Returns:
        Tuple of (total_work, list of flows at each boundary)
    """
    work = 0
    flow = 0
    flows = []

    for demand in demands[:-1]:
        flow += demand
        flows.append(flow)
        work += abs(flow)

    return work, flows


def gergovia_alternative(demands: List[int]) -> int:
    """
    Alternative formulation using prefix sums explicitly.
    """
    n = len(demands)
    if n <= 1:
        return 0

    prefix_sum = 0
    total_work = 0

    for i in range(n - 1):
        prefix_sum += demands[i]
        total_work += abs(prefix_sum)

    return total_work


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Test cases for GERGOVIA."""

    print("=" * 60)
    print("GERGOVIA - TEST CASES")
    print("=" * 60)

    # Test 1: SPOJ example
    print("\nTest 1: SPOJ Example")
    print("-" * 40)
    demands = [5, -4, 1, -3, 1]
    result, flows = gergovia_detailed(demands)

    print(f"Demands: {demands}")
    print(f"Flows at boundaries: {flows}")
    print(f"Work at each boundary: {[abs(f) for f in flows]}")
    print(f"Total work: {result}")
    print("PASS")

    # Test 2: Simple exchange
    print("\nTest 2: Simple Two Houses")
    print("-" * 40)
    demands = [1, -1]
    result = gergovia(demands)

    print(f"Demands: {demands}")
    print(f"Work: {result}")
    assert result == 1
    print("PASS")

    # Test 3: Three houses
    print("\nTest 3: Three Houses")
    print("-" * 40)
    demands = [1, -2, 1]
    result, flows = gergovia_detailed(demands)

    print(f"Demands: {demands}")
    print(f"Flows: {flows}")
    print(f"Work: {result}")
    # Flow after 0: 1, Flow after 1: -1
    # Work = 1 + 1 = 2
    assert result == 2
    print("PASS")

    # Test 4: All zeros
    print("\nTest 4: No Trading Needed")
    print("-" * 40)
    demands = [0, 0, 0, 0]
    result = gergovia(demands)

    print(f"Demands: {demands}")
    print(f"Work: {result}")
    assert result == 0
    print("PASS")

    # Test 5: Long chain
    print("\nTest 5: Long Chain")
    print("-" * 40)
    demands = [5, -5, 3, -3, 2, -2]
    result, flows = gergovia_detailed(demands)

    print(f"Demands: {demands}")
    print(f"Flows: {flows}")
    print(f"Work: {result}")
    print("PASS")

    # Test 6: Compare methods
    print("\nTest 6: Compare Methods")
    print("-" * 40)
    demands = [10, -5, -5, 3, -3]

    r1 = gergovia(demands)
    r2 = gergovia_alternative(demands)

    print(f"Method 1: {r1}")
    print(f"Method 2: {r2}")
    assert r1 == r2
    print("PASS")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_flow():
    """Visual demonstration of wine flow."""

    print("\n" + "=" * 60)
    print("WINE FLOW DEMONSTRATION")
    print("=" * 60)

    demands = [5, -4, 1, -3, 1]
    print(f"\nDemands: {demands}")
    print("(Positive = buy, Negative = sell)")

    print("\nBoundary Analysis:")
    flow = 0
    for i in range(len(demands) - 1):
        flow += demands[i]
        direction = "right" if flow > 0 else "left" if flow < 0 else "none"
        print(f"  Between house {i} and {i+1}: {abs(flow)} units flow {direction}")
        print(f"    Work at this boundary: {abs(flow)}")

    print(f"\nTotal work: {gergovia(demands)}")


if __name__ == "__main__":
    run_tests()
    demonstrate_flow()
