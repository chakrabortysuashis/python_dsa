# GERGOVIA - Wine Trading (SPOJ)

## Problem Statement

A village has N houses in a row. Each house either wants to buy wine (positive demand) or sell wine (negative demand). The total demand is always zero. Find the minimum total work (units transported * distance) to satisfy all demands.

**Input:** Array where positive = buy, negative = sell

**Output:** Minimum work units

**Example:**
```
Input: [5, -4, 1, -3, 1]
Output: 9
```

---

## Why Greedy Works Here

### Key Insight

Wine flows from sellers to buyers. The work done is the sum of units transported times distance traveled. 

**Greedy Observation:** At each position, calculate the net flow that must cross from left to right (or right to left).

### Exchange Argument

If we have sellers on the left and buyers on the right:
- Wine must flow right
- The minimum work is achieved by having each unit travel the minimum necessary distance
- Process houses left to right, tracking cumulative surplus/deficit

---

## Algorithm

The key insight is to track the running sum of demands:
- At position i, `prefix_sum[i]` = demand[0] + demand[1] + ... + demand[i-1]
- The absolute value of each prefix sum represents wine crossing that boundary
- Total work = sum of |prefix_sum[i]| for all i

```python
def gergovia(demands):
    work = 0
    running_sum = 0
    
    for demand in demands:
        running_sum += demand
        work += abs(running_sum)
    
    return work
```

Wait, this isn't quite right. Let me reconsider.

### Correct Algorithm

Actually, the work between houses i and i+1 is |prefix_sum up to i|.

```python
def gergovia(demands):
    work = 0
    flow = 0  # Net flow from left
    
    for demand in demands[:-1]:  # Don't need last
        flow += demand
        work += abs(flow)
    
    return work
```

---

## Dry Run

**Input:** [5, -4, 1, -3, 1]

```
Position 0: demand = 5 (buy)
  flow = 5 (need 5 from right)
  
Position 1: demand = -4 (sell)
  flow = 5 - 4 = 1 (1 more needed)
  Work so far: |5| = 5 (between 0-1)
  
Position 2: demand = 1 (buy)
  flow = 1 + 1 = 2
  Work: 5 + |1| = 6 (between 1-2)
  
Position 3: demand = -3 (sell)
  flow = 2 - 3 = -1
  Work: 6 + |2| = 8 (between 2-3)
  
Position 4: demand = 1
  Work: 8 + |-1| = 9 (between 3-4)

Total work: 9
```

---

## Time and Space Complexity

| Aspect | Complexity |
|--------|------------|
| **Time** | O(N) |
| **Space** | O(1) |

---

## Why This Works

The running sum at position i represents the net wine that must cross the boundary between house i and i+1:
- Positive sum: wine flows left to right
- Negative sum: wine flows right to left
- Magnitude: amount crossing

Total work sums up these boundary crossings.
