"""
Survive on Island Problem - Greedy Algorithm
=============================================

Problem: Given initial food S, daily need N, buying overhead M, and days D,
determine if survival is possible and find minimum buying days needed.

On a buying day: Consume M + N, receive 2*N food
On a normal day: Consume N food

WHY GREEDY WORKS:
----------------
1. Each buying day has a fixed net gain of (N - M) food
2. If N <= M: Buying never helps (or hurts), survival depends on initial food
3. If N > M: Calculate minimum buys to cover deficit

GREEDY STRATEGY:
- Calculate total food deficit: D*N - S
- Each buy gives net (N-M) gain
- Minimum buys = ceil(deficit / (N-M))

The timing of buys matters for simulation but NOT for the minimum count.
"""

from typing import List, Tuple
import math


def survive_island_basic(S: int, N: int, M: int, D: int) -> int:
    """
    Calculate minimum buying days to survive D days.

    Args:
        S: Initial food supply
        N: Food needed per day (also amount gained: 2*N per buy)
        M: Additional food consumed when buying (overhead)
        D: Days to survive

    Returns:
        Minimum buying days needed, or -1 if survival is impossible

    Time: O(1)
    Space: O(1)

    Example:
    >>> survive_island_basic(16, 4, 2, 10)
    4
    >>> survive_island_basic(10, 5, 6, 10)  # N <= M, impossible
    -1
    """
    # Total food needed for D days
    total_need = D * N

    # Case 1: Already have enough food
    if S >= total_need:
        return 0

    # Case 2: Buying doesn't provide net gain
    if N <= M:
        return -1

    # Calculate deficit
    deficit = total_need - S

    # Net gain per buying day: get 2*N, spend M+N, net = N-M
    net_gain = N - M

    # Minimum buying days needed (ceiling division)
    min_buys = math.ceil(deficit / net_gain)

    # Check if we have enough days for all buys
    # (We can't buy every single day in some variants)
    if min_buys > D:
        return -1

    return min_buys


def survive_island_with_sunday(S: int, N: int, M: int, D: int) -> int:
    """
    Variant where you cannot buy on Sundays (every 7th day).

    Additional constraint: Every 7th day is a "rest day" where you can't buy.
    This limits the number of possible buying days.

    Time: O(1)
    Space: O(1)

    Example:
    >>> survive_island_with_sunday(10, 4, 2, 14)  # 2 Sundays in 14 days
    6
    """
    total_need = D * N

    if S >= total_need:
        return 0

    if N <= M:
        return -1

    # Calculate available buying days (exclude Sundays)
    sundays = D // 7
    available_buy_days = D - sundays

    deficit = total_need - S
    net_gain = N - M
    min_buys = math.ceil(deficit / net_gain)

    if min_buys > available_buy_days:
        return -1

    return min_buys


def survive_island_simulation(S: int, N: int, M: int, D: int) -> Tuple[int, List[int], List[int]]:
    """
    Simulate survival with optimal buying days.

    Returns:
        (min_buys, list_of_buy_days, daily_food_levels)

    This version shows WHEN to buy, not just how many times.

    Example:
    >>> min_buys, buy_days, food_levels = survive_island_simulation(16, 4, 2, 10)
    >>> min_buys
    4
    """
    min_buys = survive_island_basic(S, N, M, D)

    if min_buys == -1:
        return -1, [], []

    # Determine optimal buying days
    # Strategy: Buy when food would go below daily need
    buy_days = []
    food_levels = [S]  # Start with initial food
    food = S
    buys_remaining = min_buys

    for day in range(1, D + 1):
        days_remaining = D - day + 1

        # Decide whether to buy today
        should_buy = False

        # Buy if we would run out of food soon
        if buys_remaining > 0:
            # Check if we need to buy to survive
            if food < N:
                should_buy = True
            # Or if we have remaining buys and would run out
            elif food < days_remaining * N - buys_remaining * (N - M):
                should_buy = True

        if should_buy:
            # Buying day: consume M+N, get 2*N
            food = food - M - N + 2 * N
            buy_days.append(day)
            buys_remaining -= 1
        else:
            # Normal day: consume N
            food -= N

        food_levels.append(food)

    return min_buys, buy_days, food_levels


def survive_island_detailed(S: int, N: int, M: int, D: int) -> dict:
    """
    Detailed analysis of survival strategy.

    Returns a dictionary with:
    - possible: whether survival is possible
    - min_buys: minimum buying days needed
    - buy_days: list of days to buy
    - daily_log: day-by-day food changes
    - final_food: remaining food after D days
    """
    result = {
        'possible': False,
        'min_buys': -1,
        'buy_days': [],
        'daily_log': [],
        'final_food': 0,
        'analysis': {}
    }

    # Analysis
    total_need = D * N
    deficit = max(0, total_need - S)
    net_gain = N - M

    result['analysis'] = {
        'total_need': total_need,
        'initial_food': S,
        'deficit': deficit,
        'net_gain_per_buy': net_gain
    }

    # Check possibility
    if S >= total_need:
        result['possible'] = True
        result['min_buys'] = 0
        result['final_food'] = S - total_need

        # Generate daily log
        food = S
        for day in range(1, D + 1):
            food -= N
            result['daily_log'].append({
                'day': day,
                'action': 'normal',
                'food_change': -N,
                'food_after': food
            })

        return result

    if N <= M:
        result['analysis']['reason'] = 'Buying does not help (N <= M)'
        return result

    min_buys = math.ceil(deficit / net_gain)

    if min_buys > D:
        result['analysis']['reason'] = f'Need {min_buys} buy days but only {D} days available'
        return result

    # Survival is possible
    result['possible'] = True
    result['min_buys'] = min_buys

    # Simulate with evenly distributed buying days
    buy_days = []
    food = S
    buys_used = 0

    for day in range(1, D + 1):
        days_remaining = D - day + 1
        buys_remaining = min_buys - buys_used

        # Check if we must buy today
        must_buy = False
        if buys_remaining > 0:
            # Would we survive without buying?
            if food < N:
                must_buy = True
            # Check future sustainability
            elif food - N * days_remaining + buys_remaining * net_gain < 0:
                must_buy = True

        if must_buy:
            buy_days.append(day)
            change = net_gain
            food = food + net_gain
            buys_used += 1
            action = 'buy'
        else:
            change = -N
            food -= N
            action = 'normal'

        result['daily_log'].append({
            'day': day,
            'action': action,
            'food_change': change,
            'food_after': food
        })

    result['buy_days'] = buy_days
    result['final_food'] = food

    return result


# =============================================================================
# BRUTE FORCE COMPARISON
# =============================================================================

def survive_island_brute_force(S: int, N: int, M: int, D: int) -> int:
    """
    Brute force: Try all possible combinations of buying days.

    Time: O(2^D * D)
    Space: O(D)

    This demonstrates why greedy O(1) is far superior.
    """
    from itertools import combinations

    min_buys = float('inf')

    # Try all possible numbers of buying days
    for num_buys in range(D + 1):
        # Try all combinations of which days to buy
        for buy_days in combinations(range(1, D + 1), num_buys):
            food = S
            survived = True

            for day in range(1, D + 1):
                if day in buy_days:
                    food = food - M - N + 2 * N  # Buy food
                else:
                    food -= N  # Normal day

                if food < 0:
                    survived = False
                    break

            if survived:
                min_buys = min(min_buys, num_buys)
                # Once we find a solution with num_buys, we can skip larger numbers
                break

        if min_buys == num_buys:
            break  # Found minimum

    return min_buys if min_buys != float('inf') else -1


# =============================================================================
# VARIATIONS
# =============================================================================

def survive_with_max_storage(S: int, N: int, M: int, D: int, max_storage: int) -> int:
    """
    Variant: You can only store up to max_storage food.

    This adds complexity - you can't just buy early, might waste food.

    Greedy approach: Buy only when needed, don't exceed storage.
    """
    if S >= D * N:
        return 0

    if N <= M:
        return -1

    food = S
    buy_count = 0

    for day in range(1, D + 1):
        # Check if we need to buy
        if food < N:
            # Must buy or die
            new_food = food - M - N + 2 * N
            if new_food > max_storage:
                # Would exceed storage, but we must survive
                food = min(new_food, max_storage)
            else:
                food = new_food
            buy_count += 1
        else:
            food -= N

        if food < 0:
            return -1

    return buy_count


def survive_variable_needs(daily_needs: List[int], S: int, M: int, buy_amount: int) -> int:
    """
    Variant: Food needed varies by day.

    Args:
        daily_needs: List of food needed for each day
        S: Initial food
        M: Overhead when buying
        buy_amount: Fixed amount received when buying

    Returns:
        Minimum buying days or -1 if impossible
    """
    D = len(daily_needs)
    food = S
    buy_count = 0

    for day in range(D):
        need = daily_needs[day]

        # Check if we need to buy
        if food < need:
            # Try to buy
            gained = buy_amount - M - need
            food += gained
            buy_count += 1

            if food < 0:
                return -1
        else:
            food -= need

    return buy_count


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Comprehensive test cases with explanations."""

    print("=" * 60)
    print("SURVIVE ON ISLAND PROBLEM - TEST CASES")
    print("=" * 60)

    # Test 1: Basic survival
    print("\nTest 1: Basic Survival Possible")
    print("-" * 40)
    S, N, M, D = 16, 4, 2, 10
    result = survive_island_basic(S, N, M, D)
    print(f"Initial food: {S}, Daily need: {N}, Buy overhead: {M}, Days: {D}")
    print(f"Minimum buying days: {result}")
    print(f"Explanation: Deficit = {D*N - S} = {D*N - S}, Net gain/buy = {N - M}")
    assert result >= 0, "Should be possible"

    # Test 2: Already enough food
    print("\nTest 2: Already Enough Food")
    print("-" * 40)
    S, N, M, D = 100, 5, 3, 10
    result = survive_island_basic(S, N, M, D)
    print(f"Initial food: {S}, Daily need: {N}, Days: {D}")
    print(f"Total needed: {D * N}")
    print(f"Minimum buying days: {result}")
    assert result == 0, f"Expected 0, got {result}"

    # Test 3: Impossible - buying doesn't help
    print("\nTest 3: Impossible - N <= M")
    print("-" * 40)
    S, N, M, D = 10, 4, 5, 10
    result = survive_island_basic(S, N, M, D)
    print(f"Initial food: {S}, Daily need: {N}, Buy overhead: {M}, Days: {D}")
    print(f"Net gain per buy: {N - M} (negative!)")
    print(f"Result: {result}")
    assert result == -1, "Should be impossible"

    # Test 4: Edge case - exactly enough with buying
    print("\nTest 4: Exactly Enough with Optimal Buying")
    print("-" * 40)
    S, N, M, D = 8, 4, 2, 6
    result = survive_island_basic(S, N, M, D)
    print(f"Initial food: {S}, Daily need: {N}, Buy overhead: {M}, Days: {D}")
    print(f"Total needed: {D * N} = {D * N}")
    print(f"Deficit: {D * N - S}")
    print(f"Net gain per buy: {N - M}")
    print(f"Minimum buying days: {result}")

    # Test 5: Simulation with buy days
    print("\nTest 5: Detailed Simulation")
    print("-" * 40)
    S, N, M, D = 12, 4, 2, 8
    min_buys, buy_days, food_levels = survive_island_simulation(S, N, M, D)
    print(f"Initial food: {S}, Daily need: {N}, Buy overhead: {M}, Days: {D}")
    print(f"Minimum buys needed: {min_buys}")
    print(f"Buying days: {buy_days}")
    print(f"Food levels: {food_levels}")

    # Test 6: Compare with brute force (small input)
    print("\nTest 6: Greedy vs Brute Force")
    print("-" * 40)
    S, N, M, D = 10, 4, 2, 8
    greedy_result = survive_island_basic(S, N, M, D)
    brute_result = survive_island_brute_force(S, N, M, D)
    print(f"Greedy result: {greedy_result}")
    print(f"Brute force result: {brute_result}")
    print(f"Match: {greedy_result == brute_result}")
    assert greedy_result == brute_result, "Results should match!"

    # Test 7: Sunday variant
    print("\nTest 7: Sunday Rest Variant")
    print("-" * 40)
    S, N, M, D = 10, 4, 2, 14
    result = survive_island_with_sunday(S, N, M, D)
    available = D - D // 7
    print(f"Days: {D}, Sundays: {D // 7}, Available buy days: {available}")
    print(f"Minimum buying days: {result}")

    # Test 8: Detailed analysis
    print("\nTest 8: Detailed Analysis")
    print("-" * 40)
    S, N, M, D = 14, 3, 1, 10
    analysis = survive_island_detailed(S, N, M, D)
    print(f"Possible: {analysis['possible']}")
    print(f"Min buys: {analysis['min_buys']}")
    print(f"Buy days: {analysis['buy_days']}")
    print(f"Final food: {analysis['final_food']}")
    print(f"Analysis: {analysis['analysis']}")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_greedy_choice():
    """Step-by-step demonstration of the greedy strategy."""

    print("\n" + "=" * 60)
    print("DEMONSTRATION: GREEDY SURVIVAL STRATEGY")
    print("=" * 60)

    S, N, M, D = 12, 4, 2, 8

    print(f"\nProblem Setup:")
    print(f"  Initial food (S): {S}")
    print(f"  Daily need (N): {N}")
    print(f"  Buy overhead (M): {M}")
    print(f"  Days to survive (D): {D}")

    print(f"\nAnalysis:")
    print(f"  Total food needed: {D * N}")
    print(f"  Deficit: {D * N - S}")
    print(f"  Net gain per buy: {N - M}")
    print(f"  Min buys needed: ceil({D * N - S} / {N - M}) = {math.ceil((D * N - S) / (N - M))}")

    min_buys, buy_days, food_levels = survive_island_simulation(S, N, M, D)

    print(f"\nOptimal Strategy:")
    print(f"  Buy on days: {buy_days}")

    print(f"\nDay-by-Day Simulation:")
    print("-" * 50)

    food = S
    for day in range(1, D + 1):
        action = "BUY" if day in buy_days else "Normal"
        food_before = food

        if day in buy_days:
            food = food - M - N + 2 * N
            change = f"+{2*N} - {M+N} = +{N - M}"
        else:
            food -= N
            change = f"-{N}"

        status = "OK" if food >= 0 else "DEAD"
        print(f"  Day {day}: [{action:6}] Food: {food_before:3} -> {food:3} ({change}) [{status}]")

    print(f"\nFinal Result:")
    print(f"  Survived: {food >= 0}")
    print(f"  Remaining food: {food}")
    print(f"  Total buying days used: {len(buy_days)}")


if __name__ == "__main__":
    run_tests()
    demonstrate_greedy_choice()
