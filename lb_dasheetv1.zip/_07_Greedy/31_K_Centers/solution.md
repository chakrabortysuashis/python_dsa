# K-Centers Problem

## Problem Statement

Given N cities and distances between them, select K cities as centers to minimize the maximum distance from any city to its nearest center. This is the facility location problem.

**Input:** 
- N cities with pairwise distances
- K centers to place

**Output:** Minimum possible "maximum distance to nearest center"

---

## Why Greedy Works (Approximation)

The K-centers problem is NP-hard. However, a greedy approach gives a 2-approximation.

### Greedy Algorithm

1. Choose an arbitrary city as the first center
2. Repeat K-1 times:
   - Find the city farthest from all current centers
   - Add it as a new center
3. The answer is the distance to the farthest city after K centers

### Why 2-Approximation?

The greedy choice ensures we're always adding the "most needed" center. The approximation factor comes from the triangle inequality.

---

## Algorithm

```python
def k_centers(distances, K):
    N = len(distances)
    centers = [0]  # Start with city 0
    
    for _ in range(K - 1):
        # Find city farthest from all centers
        max_dist = -1
        farthest = -1
        
        for city in range(N):
            if city in centers:
                continue
            
            # Distance to nearest center
            min_to_center = min(distances[city][c] for c in centers)
            
            if min_to_center > max_dist:
                max_dist = min_to_center
                farthest = city
        
        centers.append(farthest)
    
    # Calculate final maximum distance
    result = 0
    for city in range(N):
        min_dist = min(distances[city][c] for c in centers)
        result = max(result, min_dist)
    
    return result, centers
```

---

## Time Complexity

O(N^2 * K) for the greedy approach

---

## Applications

- Facility location
- Server placement
- Emergency services positioning
- Warehouse location
