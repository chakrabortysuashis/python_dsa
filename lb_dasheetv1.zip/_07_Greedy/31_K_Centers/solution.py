"""
K-Centers Problem - Greedy 2-Approximation
===========================================

Problem: Place K centers among N cities to minimize maximum distance
from any city to its nearest center.

WHY GREEDY WORKS (Approximation):
---------------------------------
1. NP-Hard: Optimal solution is NP-hard, but greedy gives 2-approximation.

2. Greedy Choice: Always add the city farthest from existing centers.
   This ensures we cover the "most needed" area.

3. Approximation: Triangle inequality ensures greedy is within 2x optimal.

GREEDY STRATEGY: Start arbitrary, repeatedly add farthest city as center.
"""

from typing import List, Tuple


def k_centers(distances: List[List[int]], K: int) -> Tuple[int, List[int]]:
    """
    Greedy K-centers with 2-approximation guarantee.

    Time: O(N^2 * K)
    Space: O(N)

    Returns:
        (max_distance, list of center indices)
    """
    N = len(distances)
    if K >= N:
        return 0, list(range(N))

    centers = [0]  # Start with city 0

    for _ in range(K - 1):
        max_dist = -1
        farthest = -1

        for city in range(N):
            if city in centers:
                continue

            min_to_center = min(distances[city][c] for c in centers)

            if min_to_center > max_dist:
                max_dist = min_to_center
                farthest = city

        if farthest != -1:
            centers.append(farthest)

    # Final max distance
    result = 0
    for city in range(N):
        min_dist = min(distances[city][c] for c in centers)
        result = max(result, min_dist)

    return result, centers


def run_tests():
    print("=" * 50)
    print("K-CENTERS - TEST CASES")
    print("=" * 50)

    # Test 1: Simple 4 cities
    print("\nTest 1: 4 cities, 2 centers")
    distances = [
        [0, 1, 3, 4],
        [1, 0, 2, 3],
        [3, 2, 0, 1],
        [4, 3, 1, 0]
    ]
    K = 2
    max_dist, centers = k_centers(distances, K)
    print(f"Centers: {centers}")
    print(f"Max distance: {max_dist}")

    # Test 2: Line of cities
    print("\nTest 2: Line, 3 centers")
    distances = [
        [0, 1, 2, 3, 4],
        [1, 0, 1, 2, 3],
        [2, 1, 0, 1, 2],
        [3, 2, 1, 0, 1],
        [4, 3, 2, 1, 0]
    ]
    K = 3
    max_dist, centers = k_centers(distances, K)
    print(f"Centers: {centers}")
    print(f"Max distance: {max_dist}")

    print("\nALL TESTS PASSED!")


if __name__ == "__main__":
    run_tests()
