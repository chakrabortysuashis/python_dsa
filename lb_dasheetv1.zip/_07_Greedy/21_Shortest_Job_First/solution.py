"""
Shortest Job First (SJF) Scheduling - Greedy Algorithm
=======================================================

Problem: Given n processes with burst times, schedule them to minimize
the average waiting time.

WHY GREEDY WORKS:
-----------------
1. Greedy Choice Property: The shortest job should be executed first.
   This minimizes the waiting time for all subsequent jobs.

2. Exchange Argument: If job L (longer) is before job S (shorter),
   swapping them reduces total waiting time:
   - Before swap: S waits for L (l time units)
   - After swap: L waits for S (s time units)
   - Since l > s, total waiting decreases

3. Mathematical Proof: Job at position i makes (n-i) jobs wait.
   To minimize total wait, smallest burst times should be first.

GREEDY STRATEGY: Sort by burst time, execute in ascending order.
"""

from typing import List, Tuple
from itertools import permutations


def sjf_average_waiting(burst_times: List[int]) -> float:
    """
    Calculate minimum average waiting time using SJF scheduling.

    Greedy Strategy:
    1. Sort processes by burst time
    2. Execute shortest first
    3. Waiting time for each = sum of all previous burst times

    Time: O(n log n) for sorting
    Space: O(n) for sorted copy

    Example:
    >>> sjf_average_waiting([6, 8, 7, 3])
    7.0
    >>> sjf_average_waiting([3, 1, 2])
    1.0
    """
    n = len(burst_times)
    if n == 0:
        return 0.0

    sorted_bt = sorted(burst_times)

    total_waiting = 0
    current_time = 0

    for bt in sorted_bt:
        total_waiting += current_time
        current_time += bt

    return total_waiting / n


def sjf_detailed(
    burst_times: List[int]
) -> Tuple[float, List[int], List[int], List[int]]:
    """
    SJF with detailed information about each process.

    Returns:
        Tuple of (avg_waiting_time, execution_order, waiting_times, completion_times)

    Example:
    >>> avg, order, waits, completions = sjf_detailed([6, 8, 7, 3])
    >>> avg
    7.0
    >>> order  # Execution order by burst time
    [3, 6, 7, 8]
    """
    n = len(burst_times)
    if n == 0:
        return 0.0, [], [], []

    sorted_bt = sorted(burst_times)

    waiting_times = []
    completion_times = []
    current_time = 0

    for bt in sorted_bt:
        waiting_times.append(current_time)
        current_time += bt
        completion_times.append(current_time)

    avg_waiting = sum(waiting_times) / n

    return avg_waiting, sorted_bt, waiting_times, completion_times


def sjf_with_process_ids(
    burst_times: List[int]
) -> Tuple[float, List[Tuple[int, int, int, int]]]:
    """
    SJF tracking original process IDs.

    Returns:
        Tuple of (avg_waiting_time, list of (process_id, burst_time, wait_time, completion_time))

    Example:
    >>> avg, details = sjf_with_process_ids([6, 8, 7, 3])
    >>> avg
    7.0
    """
    n = len(burst_times)
    if n == 0:
        return 0.0, []

    # Track original indices
    indexed_bt = [(bt, i) for i, bt in enumerate(burst_times)]
    indexed_bt.sort()  # Sort by burst time

    details = []
    current_time = 0
    total_waiting = 0

    for bt, pid in indexed_bt:
        wait_time = current_time
        total_waiting += wait_time
        current_time += bt
        completion_time = current_time

        details.append((pid, bt, wait_time, completion_time))

    return total_waiting / n, details


def sjf_total_metrics(burst_times: List[int]) -> dict:
    """
    Calculate all scheduling metrics.

    Returns:
        Dictionary with avg_waiting, avg_turnaround, avg_completion, throughput
    """
    n = len(burst_times)
    if n == 0:
        return {'avg_waiting': 0, 'avg_turnaround': 0, 'throughput': 0}

    sorted_bt = sorted(burst_times)

    total_waiting = 0
    total_turnaround = 0
    current_time = 0

    for bt in sorted_bt:
        waiting = current_time
        total_waiting += waiting

        current_time += bt
        turnaround = current_time  # Assuming arrival time = 0
        total_turnaround += turnaround

    total_time = current_time

    return {
        'avg_waiting': total_waiting / n,
        'avg_turnaround': total_turnaround / n,
        'total_time': total_time,
        'throughput': n / total_time if total_time > 0 else 0
    }


# =============================================================================
# BRUTE FORCE - For comparison
# =============================================================================

def brute_force_sjf(burst_times: List[int]) -> float:
    """
    Brute force: try all permutations.

    Time: O(n! * n)
    Space: O(n)
    """
    n = len(burst_times)
    if n == 0:
        return 0.0

    min_avg = float('inf')

    for perm in permutations(burst_times):
        total_wait = 0
        current_time = 0

        for bt in perm:
            total_wait += current_time
            current_time += bt

        avg = total_wait / n
        min_avg = min(min_avg, avg)

    return min_avg


# =============================================================================
# VARIATIONS
# =============================================================================

def sjf_with_arrival_times(
    processes: List[Tuple[int, int, int]]
) -> float:
    """
    Non-preemptive SJF with different arrival times.

    Args:
        processes: List of (process_id, arrival_time, burst_time)

    Returns:
        Average waiting time

    Strategy: At each moment, among available processes, pick shortest.
    """
    if not processes:
        return 0.0

    n = len(processes)
    # Sort by arrival time, then burst time
    remaining = sorted(processes, key=lambda x: (x[1], x[2]))

    current_time = 0
    total_waiting = 0
    completed = []

    while remaining:
        # Find available processes
        available = [p for p in remaining if p[1] <= current_time]

        if not available:
            # Jump to next arrival
            current_time = remaining[0][1]
            continue

        # Pick shortest job among available
        available.sort(key=lambda x: x[2])
        chosen = available[0]
        remaining.remove(chosen)

        pid, arrival, burst = chosen
        waiting = current_time - arrival
        total_waiting += waiting
        current_time += burst
        completed.append((pid, waiting))

    return total_waiting / n


def srtf_scheduling(
    processes: List[Tuple[int, int, int]]
) -> float:
    """
    Shortest Remaining Time First (Preemptive SJF).

    More complex - can interrupt running process if shorter one arrives.

    This is a placeholder - full implementation would track remaining times.
    """
    print("SRTF is preemptive SJF - more complex implementation needed")
    return -1


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Comprehensive test cases with explanations."""

    print("=" * 60)
    print("SHORTEST JOB FIRST SCHEDULING - TEST CASES")
    print("=" * 60)

    # Test 1: Basic example
    print("\nTest 1: Basic Example")
    print("-" * 40)
    burst_times = [6, 8, 7, 3]
    result = sjf_average_waiting(burst_times)
    brute = brute_force_sjf(burst_times)

    print(f"Burst times: {burst_times}")
    print(f"SJF average waiting: {result}")
    print(f"Brute force: {brute}")
    assert abs(result - brute) < 0.001, f"Mismatch!"
    print("PASS")

    # Test 2: Already sorted
    print("\nTest 2: Already Sorted")
    print("-" * 40)
    burst_times = [1, 2, 3, 4]
    result = sjf_average_waiting(burst_times)
    print(f"Burst times: {burst_times}")
    print(f"Average waiting: {result}")
    # Waiting: 0, 1, 3, 6 -> avg = 10/4 = 2.5
    assert abs(result - 2.5) < 0.001
    print("PASS")

    # Test 3: Reverse sorted
    print("\nTest 3: Reverse Sorted (Worst Input for FCFS)")
    print("-" * 40)
    burst_times = [4, 3, 2, 1]
    result = sjf_average_waiting(burst_times)
    print(f"Burst times: {burst_times}")
    print(f"SJF average waiting: {result}")
    # After sorting [1,2,3,4], waiting: 0, 1, 3, 6 -> avg = 2.5
    assert abs(result - 2.5) < 0.001
    print("PASS")

    # Test 4: Single process
    print("\nTest 4: Single Process")
    print("-" * 40)
    burst_times = [5]
    result = sjf_average_waiting(burst_times)
    print(f"Burst times: {burst_times}")
    print(f"Average waiting: {result}")
    assert result == 0
    print("PASS")

    # Test 5: Detailed output
    print("\nTest 5: Detailed SJF Output")
    print("-" * 40)
    burst_times = [6, 8, 7, 3]
    avg, order, waits, completions = sjf_detailed(burst_times)

    print(f"Burst times: {burst_times}")
    print(f"Execution order: {order}")
    print(f"Waiting times: {waits}")
    print(f"Completion times: {completions}")
    print(f"Average waiting: {avg}")
    print("PASS")

    # Test 6: With process IDs
    print("\nTest 6: SJF with Process IDs")
    print("-" * 40)
    burst_times = [6, 8, 7, 3]
    avg, details = sjf_with_process_ids(burst_times)

    print(f"Burst times: {burst_times}")
    print("Execution details:")
    for pid, bt, wait, completion in details:
        print(f"  Process {pid}: BT={bt}, Wait={wait}, Complete={completion}")
    print(f"Average waiting: {avg}")
    print("PASS")

    # Test 7: All metrics
    print("\nTest 7: All Scheduling Metrics")
    print("-" * 40)
    burst_times = [6, 8, 7, 3]
    metrics = sjf_total_metrics(burst_times)

    print(f"Burst times: {burst_times}")
    for key, value in metrics.items():
        print(f"  {key}: {value}")
    print("PASS")

    # Test 8: Equal burst times
    print("\nTest 8: Equal Burst Times")
    print("-" * 40)
    burst_times = [5, 5, 5, 5]
    result = sjf_average_waiting(burst_times)
    print(f"Burst times: {burst_times}")
    print(f"Average waiting: {result}")
    # Waiting: 0, 5, 10, 15 -> avg = 7.5
    assert abs(result - 7.5) < 0.001
    print("PASS")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_why_sjf_works():
    """Visual demonstration of why SJF minimizes waiting."""

    print("\n" + "=" * 60)
    print("DEMONSTRATION: WHY SJF MINIMIZES WAITING TIME")
    print("=" * 60)

    burst_times = [6, 2, 8]

    print(f"\nBurst times: {burst_times}")

    # FCFS order
    print("\nFCFS (First Come First Serve) - Original Order [6, 2, 8]:")
    print("  Process with BT=6: waits 0")
    print("  Process with BT=2: waits 6")
    print("  Process with BT=8: waits 8")
    print("  Total waiting = 0 + 6 + 8 = 14")
    print("  Average = 14/3 = 4.67")

    # SJF order
    print("\nSJF (Shortest Job First) - Sorted Order [2, 6, 8]:")
    print("  Process with BT=2: waits 0")
    print("  Process with BT=6: waits 2")
    print("  Process with BT=8: waits 8")
    print("  Total waiting = 0 + 2 + 8 = 10")
    print("  Average = 10/3 = 3.33")

    print("\nWhy SJF is better:")
    print("  - Short job (BT=2) makes others wait only 2 units")
    print("  - Long job (BT=6) would make others wait 6 units")
    print("  - Doing short jobs first minimizes cumulative waiting")

    print("\nGantt Charts:")
    print("  FCFS: |---6---|--2--|----8----|")
    print("         0      6    8        16")
    print("  SJF:  |--2--|---6---|----8----|")
    print("         0    2      8        16")


if __name__ == "__main__":
    run_tests()
    demonstrate_why_sjf_works()
