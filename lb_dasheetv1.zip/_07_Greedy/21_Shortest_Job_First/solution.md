# Shortest Job First (SJF) Scheduling

## Problem Statement

Given `n` processes with their burst times (execution times), schedule them to minimize the average waiting time. In SJF, processes with shorter burst times are executed first.

**Input:** Array `burst_times[]` of n process burst times

**Output:** Minimum average waiting time

**Example:**
```
Input: burst_times = [6, 8, 7, 3]
Output: Average waiting time = 7.0

Execution Order: [3, 6, 7, 8] (sorted by burst time)
Waiting times: 0, 3, 9, 16
Average = (0 + 3 + 9 + 16) / 4 = 28 / 4 = 7.0
```

---

## Why Greedy Works Here

### The Greedy Choice Property

**Claim:** Executing the shortest remaining job first minimizes total (and average) waiting time.

**Intuition:**
- A short job makes fewer processes wait
- A long job delays all subsequent processes
- Executing short jobs first minimizes cumulative delay

### Exchange Argument Proof

1. Consider any schedule where a longer job `L` comes before shorter job `S`
2. Let `L` have burst time `l` and `S` have burst time `s`, where `l > s`
3. Jobs after both `L` and `S` wait the same total time either way
4. Compare the two orderings for just L and S:
   - **Order L, S:** S waits `l` time units
   - **Order S, L:** L waits `s` time units
5. Since `l > s`, order S, L has less total waiting
6. Therefore, shorter jobs should always come first

### Mathematical Proof

Total waiting time = Σ (n - i) * burst_time[i] for sorted order

Where job at position i makes (n - i) jobs wait for it.
To minimize, put smallest burst times at earliest positions.

---

## Step-by-Step Greedy Selection

### Algorithm:

```
1. SORT processes by burst time (ascending)
2. EXECUTE in sorted order
3. CALCULATE waiting times:
   - First process waits 0
   - Each subsequent process waits sum of all previous burst times
4. COMPUTE average waiting time
```

### Calculating Waiting Time:

```
For sorted burst times [b1, b2, b3, ..., bn]:

waiting[0] = 0
waiting[1] = b1
waiting[2] = b1 + b2
...
waiting[i] = b1 + b2 + ... + b[i-1]

Total = Σ waiting[i] = (n-1)*b1 + (n-2)*b2 + ... + 1*b[n-1]
```

---

## Brute Force Comparison

### Brute Force Approach
Try all permutations of process order.

```python
from itertools import permutations

def brute_force_sjf(burst_times):
    n = len(burst_times)
    min_avg = float('inf')
    
    for perm in permutations(burst_times):
        total_wait = 0
        current_wait = 0
        
        for bt in perm:
            total_wait += current_wait
            current_wait += bt
        
        avg = total_wait / n
        min_avg = min(min_avg, avg)
    
    return min_avg
```

**Time Complexity:** O(n! * n)
**Space Complexity:** O(n)

---

## Optimal Greedy Approach

```python
def sjf_scheduling(burst_times):
    n = len(burst_times)
    if n == 0:
        return 0
    
    # Sort by burst time (key greedy insight)
    sorted_bt = sorted(burst_times)
    
    # Calculate waiting times
    total_waiting = 0
    current_time = 0
    
    for bt in sorted_bt:
        total_waiting += current_time
        current_time += bt
    
    return total_waiting / n
```

**Time Complexity:** O(n log n) for sorting
**Space Complexity:** O(n) for sorted copy

---

## Dry Run with Selection Visualization

**Input:** `burst_times = [6, 8, 7, 3]`

**Step 1: Sort by Burst Time**
```
Original: [6, 8, 7, 3]
Sorted:   [3, 6, 7, 8]
```

**Step 2: Execute in Order**
```
Process with BT=3:
  Arrives at time 0
  Waits: 0
  Executes: 0 -> 3
  
Process with BT=6:
  Arrives at time 0
  Waits: 3 (for first process)
  Executes: 3 -> 9
  
Process with BT=7:
  Arrives at time 0
  Waits: 9 (for first two)
  Executes: 9 -> 16
  
Process with BT=8:
  Arrives at time 0
  Waits: 16 (for first three)
  Executes: 16 -> 24
```

**Step 3: Calculate Average**
```
Waiting times: [0, 3, 9, 16]
Total waiting = 0 + 3 + 9 + 16 = 28
Average = 28 / 4 = 7.0
```

**Gantt Chart:**
```
|---3---|---6---|---7---|---8---|
0       3       9      16      24
```

---

## Time and Space Complexity

| Aspect | Complexity | Explanation |
|--------|------------|-------------|
| **Time** | O(n log n) | Dominated by sorting |
| **Space** | O(n) | For sorted copy |

---

## Variations

### 1. With Arrival Times (Non-preemptive SJF)
Processes arrive at different times - pick shortest among available.

### 2. Shortest Remaining Time First (SRTF) - Preemptive
Can interrupt running process if shorter one arrives.

### 3. With Process IDs
Track which process executes when.

### 4. Weighted SJF
Each process has priority/weight - balance with burst time.

---

## SJF vs Other Algorithms

| Algorithm | Avg Wait | Starvation | Preemptive |
|-----------|----------|------------|------------|
| **SJF** | Minimum | Yes (long jobs) | No |
| **SRTF** | Minimum | Yes (long jobs) | Yes |
| **FCFS** | Higher | No | No |
| **Round Robin** | Medium | No | Yes |

---

## Limitations of SJF

1. **Starvation:** Long processes may never execute if short ones keep arriving
2. **Burst Time Unknown:** In practice, we don't know exact burst times in advance
3. **No Preemption:** Basic SJF doesn't handle arrivals during execution

### Solutions:
- **Aging:** Gradually increase priority of waiting processes
- **Prediction:** Estimate burst time from past behavior
