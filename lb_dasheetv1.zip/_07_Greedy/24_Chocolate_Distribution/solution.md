# Chocolate Distribution Problem

## Problem Statement

Given an array of `n` packets where each packet contains some chocolates, distribute these packets to `m` children such that the difference between maximum and minimum chocolates received by any child is minimized.

**Input:** 
- `arr[]` - Array of n packets with chocolate counts
- `m` - Number of children

**Output:** Minimum possible difference between max and min chocolates

**Example:**
```
Input: arr[] = [7, 3, 2, 4, 9, 12, 56], m = 3
Output: 2
Explanation: Choose packets [3, 4, 2] -> sorted: [2, 3, 4]
Difference = 4 - 2 = 2
```

---

## Why Greedy Works Here

### The Greedy Choice Property

**Claim:** The optimal selection must be m consecutive elements in the sorted array.

**Intuition:**
- After sorting, adjacent elements have minimal differences
- Any gap in selection would unnecessarily increase the range
- Consecutive elements minimize max - min

### Exchange Argument Proof

1. Suppose optimal uses non-consecutive elements from sorted array
2. Let there be a "gap" - element `x` not chosen but smaller element `a` and larger element `b` are chosen
3. Replacing either `a` or `b` with `x` would:
   - Either decrease max or increase min
   - Thus reducing the difference
4. Contradiction! So optimal must use consecutive elements

---

## Step-by-Step Greedy Selection

### Algorithm:

```
1. SORT the array
2. SLIDE a window of size m across sorted array
3. FOR each window position:
   - Calculate difference = arr[i+m-1] - arr[i]
4. RETURN minimum difference found
```

---

## Implementation

```python
def chocolate_distribution(arr, m):
    n = len(arr)
    if m > n or m == 0:
        return -1  # Invalid
    
    arr.sort()
    
    min_diff = float('inf')
    
    for i in range(n - m + 1):
        diff = arr[i + m - 1] - arr[i]
        min_diff = min(min_diff, diff)
    
    return min_diff
```

**Time Complexity:** O(n log n) for sorting
**Space Complexity:** O(1) extra space

---

## Dry Run

**Input:** `arr = [7, 3, 2, 4, 9, 12, 56], m = 3`

**Step 1: Sort**
```
Sorted: [2, 3, 4, 7, 9, 12, 56]
```

**Step 2: Slide Window (size 3)**
```
Window [2, 3, 4]:  diff = 4 - 2 = 2
Window [3, 4, 7]:  diff = 7 - 3 = 4
Window [4, 7, 9]:  diff = 9 - 4 = 5
Window [7, 9, 12]: diff = 12 - 7 = 5
Window [9, 12, 56]: diff = 56 - 9 = 47
```

**Result:** Minimum difference = 2 (window [2, 3, 4])

---

## Time and Space Complexity

| Aspect | Complexity | Explanation |
|--------|------------|-------------|
| **Time** | O(n log n) | Sorting dominates; window sliding is O(n) |
| **Space** | O(1) | In-place sorting possible |

---

## Variations

### 1. Return the Actual Selection
Track which window gives minimum difference.

### 2. Multiple Groups
Distribute to k groups of m children each.

### 3. Weighted Distribution
If some children should get more, problem changes.
