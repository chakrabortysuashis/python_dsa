"""
Chocolate Distribution Problem - Greedy Algorithm
==================================================

Problem: Distribute m packets from n available such that difference
between max and min chocolates received is minimized.

WHY GREEDY WORKS:
-----------------
1. Greedy Choice Property: Optimal selection is always m consecutive
   elements in the sorted array.

2. Exchange Argument: If selection has gaps in sorted array, filling
   the gap by swapping an extreme element reduces the difference.

3. Sliding Window: After sorting, slide a window of size m and find
   minimum (window_max - window_min).

GREEDY STRATEGY: Sort, then find consecutive m elements with minimum
difference between first and last.
"""

from typing import List, Tuple


def chocolate_distribution(arr: List[int], m: int) -> int:
    """
    Find minimum difference in chocolate distribution.

    Greedy Strategy:
    1. Sort the packets
    2. Slide window of size m
    3. Return minimum (arr[i+m-1] - arr[i])

    Time: O(n log n)
    Space: O(1) extra

    Example:
    >>> chocolate_distribution([7, 3, 2, 4, 9, 12, 56], 3)
    2
    >>> chocolate_distribution([3, 4, 1, 9, 56, 7, 9, 12], 5)
    6
    """
    n = len(arr)

    if m == 0 or m > n:
        return -1

    if m == 1:
        return 0

    arr.sort()

    min_diff = float('inf')

    for i in range(n - m + 1):
        diff = arr[i + m - 1] - arr[i]
        min_diff = min(min_diff, diff)

    return min_diff


def chocolate_distribution_detailed(
    arr: List[int],
    m: int
) -> Tuple[int, List[int]]:
    """
    Return both minimum difference and the selected packets.

    Returns:
        Tuple of (min_difference, selected_packets)

    Example:
    >>> diff, packets = chocolate_distribution_detailed([7, 3, 2, 4, 9, 12, 56], 3)
    >>> diff
    2
    >>> sorted(packets)
    [2, 3, 4]
    """
    n = len(arr)

    if m == 0 or m > n:
        return -1, []

    if m == 1:
        return 0, [min(arr)]

    sorted_arr = sorted(arr)

    min_diff = float('inf')
    best_start = 0

    for i in range(n - m + 1):
        diff = sorted_arr[i + m - 1] - sorted_arr[i]
        if diff < min_diff:
            min_diff = diff
            best_start = i

    selected = sorted_arr[best_start:best_start + m]

    return min_diff, selected


def chocolate_distribution_all_windows(
    arr: List[int],
    m: int
) -> List[Tuple[List[int], int]]:
    """
    Return all possible windows with their differences.

    Useful for understanding why sorting and consecutive selection works.
    """
    n = len(arr)

    if m == 0 or m > n:
        return []

    sorted_arr = sorted(arr)
    windows = []

    for i in range(n - m + 1):
        window = sorted_arr[i:i + m]
        diff = window[-1] - window[0]
        windows.append((window, diff))

    return windows


# =============================================================================
# BRUTE FORCE
# =============================================================================

def brute_force_chocolate(arr: List[int], m: int) -> int:
    """
    Brute force: try all combinations of size m.

    Time: O(C(n,m) * m) = O(n! / (m!(n-m)!) * m)
    """
    from itertools import combinations

    n = len(arr)
    if m == 0 or m > n:
        return -1

    min_diff = float('inf')

    for combo in combinations(arr, m):
        diff = max(combo) - min(combo)
        min_diff = min(min_diff, diff)

    return min_diff


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Comprehensive test cases."""

    print("=" * 60)
    print("CHOCOLATE DISTRIBUTION - TEST CASES")
    print("=" * 60)

    # Test 1: Basic example
    print("\nTest 1: Basic Example")
    print("-" * 40)
    arr = [7, 3, 2, 4, 9, 12, 56]
    m = 3
    result = chocolate_distribution(arr, m)
    brute = brute_force_chocolate(arr, m)
    diff, packets = chocolate_distribution_detailed(arr, m)

    print(f"Packets: {arr}")
    print(f"Children: {m}")
    print(f"Selected: {packets}, Diff: {diff}")
    print(f"Greedy: {result}, Brute: {brute}")
    assert result == brute
    print("PASS")

    # Test 2: Larger m
    print("\nTest 2: Larger m")
    print("-" * 40)
    arr = [3, 4, 1, 9, 56, 7, 9, 12]
    m = 5
    result = chocolate_distribution(arr, m)
    brute = brute_force_chocolate(arr, m)

    print(f"Packets: {arr}")
    print(f"Children: {m}")
    print(f"Greedy: {result}, Brute: {brute}")
    assert result == brute
    print("PASS")

    # Test 3: m = 1
    print("\nTest 3: Single Child")
    print("-" * 40)
    arr = [7, 3, 2, 4, 9, 12, 56]
    m = 1
    result = chocolate_distribution(arr, m)

    print(f"Packets: {arr}")
    print(f"Children: {m}")
    print(f"Result: {result}")
    assert result == 0
    print("PASS")

    # Test 4: m = n
    print("\nTest 4: All Children")
    print("-" * 40)
    arr = [7, 3, 2, 4]
    m = 4
    result = chocolate_distribution(arr, m)

    print(f"Packets: {arr}")
    print(f"Children: {m}")
    print(f"Result: {result}")  # max - min of all
    assert result == 7 - 2
    print("PASS")

    # Test 5: All equal
    print("\nTest 5: All Equal Packets")
    print("-" * 40)
    arr = [5, 5, 5, 5, 5]
    m = 3
    result = chocolate_distribution(arr, m)

    print(f"Packets: {arr}")
    print(f"Children: {m}")
    print(f"Result: {result}")
    assert result == 0
    print("PASS")

    # Test 6: Show all windows
    print("\nTest 6: All Windows")
    print("-" * 40)
    arr = [1, 5, 9, 2, 6]
    m = 3
    windows = chocolate_distribution_all_windows(arr, m)

    print(f"Packets: {arr}")
    print(f"Sorted: {sorted(arr)}")
    print("All windows:")
    for window, diff in windows:
        print(f"  {window} -> diff = {diff}")
    print("PASS")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


if __name__ == "__main__":
    run_tests()
