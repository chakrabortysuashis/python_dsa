# Minimum Sum of Absolute Difference of Pairs

## Problem Statement

Given two arrays `A[]` and `B[]` of equal length `n`, pair up elements from A with elements from B such that each element is used exactly once, minimizing the sum of absolute differences of pairs.

**Input:** 
- Array `A[]` of n integers
- Array `B[]` of n integers

**Output:** Minimum possible sum of `|A[i] - B[j]|` for all pairs

**Example:**
```
Input: A[] = [4, 1, 8, 7], B[] = [2, 3, 6, 5]
Output: 6
Optimal Pairing: (1,2), (4,3), (7,6), (8,5) OR after sorting both: (1,2), (4,3), (7,5), (8,6)
Sum = |1-2| + |4-3| + |7-5| + |8-6| = 1 + 1 + 2 + 2 = 6
```

---

## Why Greedy Works Here

### The Greedy Choice Property

**Claim:** Sorting both arrays and pairing corresponding elements (A[i] with B[i]) minimizes the total sum.

**Intuition:**
- Smallest elements should be paired with smallest
- Crossing pairings always increases total sum
- Keeping "close" elements together minimizes differences

### Exchange Argument Proof

1. Suppose we have a pairing where A[i] pairs with B[j] and A[k] pairs with B[l], where i < k but j > l
2. This is a "crossing" - smaller A paired with larger B and vice versa
3. Compare costs:
   - Crossing: `|A[i] - B[j]| + |A[k] - B[l]|`
   - Uncrossing: `|A[i] - B[l]| + |A[k] - B[j]|`
4. By the triangle inequality property:
   - Uncrossing is always <= Crossing
5. Therefore, optimal solution has no crossings = sorted pairing

### Why No Crossings?

```
Consider A = [1, 5] and B = [2, 4]

Crossing (1↔4, 5↔2):
|1-4| + |5-2| = 3 + 3 = 6

Uncrossing (1↔2, 5↔4):
|1-2| + |5-4| = 1 + 1 = 2

Uncrossing wins by 4!
```

---

## Step-by-Step Greedy Selection

### Algorithm:

```
1. SORT array A in ascending order
2. SORT array B in ascending order
3. PAIR corresponding elements: (A[0], B[0]), (A[1], B[1]), ...
4. CALCULATE sum of absolute differences
5. RETURN total sum
```

### Visual Proof:

```
Sorted A: [1, 4, 7, 8]
Sorted B: [2, 3, 5, 6]

Pairing: 1↔2, 4↔3, 7↔5, 8↔6

No lines cross - this is optimal!

If we tried crossing:
         1   4   7   8
         ╲ ╱ ╲ ╱ ╲ ╱
         2   3   5   6

Crossed lines always increase sum.
```

---

## Brute Force Comparison

### Brute Force Approach
Try all possible permutations of B and pair with A.

```python
from itertools import permutations

def brute_force(A, B):
    min_sum = float('inf')
    
    for perm in permutations(B):
        curr_sum = sum(abs(A[i] - perm[i]) for i in range(len(A)))
        min_sum = min(min_sum, curr_sum)
    
    return min_sum
```

**Time Complexity:** O(n! * n)
**Space Complexity:** O(n)

---

## Optimal Greedy Approach

```python
def min_sum_pairs(A, B):
    A_sorted = sorted(A)
    B_sorted = sorted(B)
    
    return sum(abs(A_sorted[i] - B_sorted[i]) for i in range(len(A)))
```

**Time Complexity:** O(n log n) for sorting
**Space Complexity:** O(n) for sorted copies

---

## Dry Run with Selection Visualization

**Input:** `A = [4, 1, 8, 7], B = [2, 3, 6, 5]`

**Step 1: Sort Both Arrays**
```
A sorted: [1, 4, 7, 8]
B sorted: [2, 3, 5, 6]
```

**Step 2: Pair Corresponding Elements**
```
Pair 1: (1, 2) → |1 - 2| = 1
Pair 2: (4, 3) → |4 - 3| = 1
Pair 3: (7, 5) → |7 - 5| = 2
Pair 4: (8, 6) → |8 - 6| = 2
```

**Step 3: Calculate Total**
```
Total = 1 + 1 + 2 + 2 = 6
```

**Why Alternative Pairings Are Worse:**
```
Try pairing (1, 6) and (8, 2):
|1 - 6| + |8 - 2| = 5 + 6 = 11 (vs our 1 + 2 = 3)
Crossing costs more!
```

---

## Time and Space Complexity

| Aspect | Complexity | Explanation |
|--------|------------|-------------|
| **Time** | O(n log n) | Dominated by sorting both arrays |
| **Space** | O(n) | For sorted copies (can be O(1) if in-place) |

### If Arrays Already Sorted:
- Time reduces to O(n)
- Just one pass to calculate sum

---

## Mathematical Proof Using Rearrangement Inequality

The **Rearrangement Inequality** states:
- For sorted sequences a1 ≤ a2 ≤ ... ≤ an and b1 ≤ b2 ≤ ... ≤ bn
- The sum Σ ai*bi is MAXIMIZED when both are sorted same way
- The sum Σ ai*bi is MINIMIZED when sorted opposite ways

For our problem:
- We want to MINIMIZE Σ |ai - bi|
- This is achieved when both sorted the same way

---

## Variations and Extensions

### 1. Maximum Sum Instead of Minimum
Sort one array ascending, other descending - pair extremes together.

### 2. Weighted Pairs
If pairs have weights, problem becomes assignment problem (Hungarian algorithm).

### 3. Unequal Array Sizes
Choose n elements from larger array - more complex, may need DP.

### 4. Three or More Arrays
Generalization requires more sophisticated algorithms.
