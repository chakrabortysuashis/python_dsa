"""
Minimum Sum of Absolute Difference of Pairs - Greedy Algorithm
================================================================

Problem: Given two arrays A[] and B[] of equal length n, pair up elements
such that the sum of absolute differences of all pairs is minimized.

WHY GREEDY WORKS:
-----------------
1. Greedy Choice Property: The smallest element in A should be paired with
   the smallest element in B. This minimizes the "wasted" difference.

2. Exchange Argument: If we have a "crossing" pairing (smaller A with larger B
   and larger A with smaller B), uncrossing always reduces total cost.

   Proof: For a < b and x < y:
   |a-y| + |b-x| >= |a-x| + |b-y| (uncrossing is never worse)

3. Rearrangement Inequality: For minimizing sum of |ai - bi|, sort both
   arrays the same way and pair corresponding elements.

GREEDY STRATEGY: Sort both arrays and pair corresponding indices.
"""

from typing import List, Tuple
from itertools import permutations


def min_sum_pairs(A: List[int], B: List[int]) -> int:
    """
    Calculate minimum sum of absolute differences by sorting and pairing.

    Greedy Strategy:
    1. Sort both arrays in ascending order
    2. Pair A[i] with B[i] for all i
    3. Sum of |A[i] - B[i]| is minimized

    Time: O(n log n) for sorting
    Space: O(n) for sorted copies

    Example:
    >>> min_sum_pairs([4, 1, 8, 7], [2, 3, 6, 5])
    6
    >>> min_sum_pairs([1, 2, 3], [4, 5, 6])
    9
    """
    A_sorted = sorted(A)
    B_sorted = sorted(B)

    return sum(abs(A_sorted[i] - B_sorted[i]) for i in range(len(A)))


def min_sum_pairs_with_pairing(
    A: List[int],
    B: List[int]
) -> Tuple[int, List[Tuple[int, int]]]:
    """
    Return both minimum sum and the optimal pairing.

    Returns:
        Tuple of (minimum_sum, list of (a, b) pairs)

    Example:
    >>> sum_val, pairs = min_sum_pairs_with_pairing([4, 1, 8, 7], [2, 3, 6, 5])
    >>> sum_val
    6
    >>> pairs
    [(1, 2), (4, 3), (7, 5), (8, 6)]
    """
    A_sorted = sorted(A)
    B_sorted = sorted(B)

    pairs = list(zip(A_sorted, B_sorted))
    total = sum(abs(a - b) for a, b in pairs)

    return total, pairs


def min_sum_pairs_inplace(A: List[int], B: List[int]) -> int:
    """
    In-place version (modifies input arrays).

    Time: O(n log n)
    Space: O(1) extra (sorting may use O(log n) stack)

    Example:
    >>> min_sum_pairs_inplace([4, 1, 8, 7], [2, 3, 6, 5])
    6
    """
    A.sort()
    B.sort()

    return sum(abs(A[i] - B[i]) for i in range(len(A)))


# =============================================================================
# BRUTE FORCE - For comparison and verification
# =============================================================================

def brute_force_min_sum(A: List[int], B: List[int]) -> int:
    """
    Brute force: try all permutations of B.

    Time: O(n! * n)
    Space: O(n)

    Only use for small inputs (n <= 8)
    """
    min_sum = float('inf')

    for perm in permutations(B):
        curr_sum = sum(abs(A[i] - perm[i]) for i in range(len(A)))
        min_sum = min(min_sum, curr_sum)

    return min_sum


def brute_force_with_pairing(
    A: List[int],
    B: List[int]
) -> Tuple[int, List[Tuple[int, int]]]:
    """
    Brute force returning the optimal pairing as well.
    """
    min_sum = float('inf')
    best_pairing = []

    for perm in permutations(B):
        curr_sum = sum(abs(A[i] - perm[i]) for i in range(len(A)))
        if curr_sum < min_sum:
            min_sum = curr_sum
            best_pairing = list(zip(A, perm))

    return min_sum, best_pairing


# =============================================================================
# RELATED PROBLEMS
# =============================================================================

def max_sum_pairs(A: List[int], B: List[int]) -> int:
    """
    MAXIMIZE sum of absolute differences.

    Strategy: Sort A ascending, B descending (or vice versa).
    Pair extremes together to maximize differences.

    Time: O(n log n)
    Space: O(n)

    Example:
    >>> max_sum_pairs([4, 1, 8, 7], [2, 3, 6, 5])
    18
    """
    A_sorted = sorted(A)
    B_sorted = sorted(B, reverse=True)

    return sum(abs(A_sorted[i] - B_sorted[i]) for i in range(len(A)))


def min_sum_pairs_weighted(
    A: List[int],
    B: List[int],
    weights: List[List[int]]
) -> int:
    """
    Weighted pairing problem (General Assignment Problem).

    weights[i][j] = cost of pairing A[i] with B[j]

    This requires Hungarian Algorithm for optimal solution.
    Greedy doesn't work for general weights!

    Returns -1 to indicate this needs different approach.
    """
    print("WARNING: Weighted pairing requires Hungarian Algorithm!")
    print("Simple greedy doesn't work for arbitrary weights.")
    return -1


# =============================================================================
# EXCHANGE ARGUMENT DEMONSTRATION
# =============================================================================

def demonstrate_exchange_argument(A: List[int], B: List[int]):
    """
    Visually demonstrate why crossing pairs are suboptimal.
    """
    print("\n" + "=" * 60)
    print("EXCHANGE ARGUMENT DEMONSTRATION")
    print("=" * 60)

    A_sorted = sorted(A)
    B_sorted = sorted(B)

    print(f"\nSorted A: {A_sorted}")
    print(f"Sorted B: {B_sorted}")

    # Optimal (no crossing)
    opt_sum = sum(abs(A_sorted[i] - B_sorted[i]) for i in range(len(A)))
    print(f"\nOptimal pairing (no crossings):")
    for i in range(len(A)):
        print(f"  {A_sorted[i]} <-> {B_sorted[i]} : diff = {abs(A_sorted[i] - B_sorted[i])}")
    print(f"Total: {opt_sum}")

    # Try a crossing
    if len(A) >= 2:
        print(f"\nCrossing pairing (swap first two B elements):")
        B_crossed = B_sorted.copy()
        B_crossed[0], B_crossed[1] = B_crossed[1], B_crossed[0]

        cross_sum = sum(abs(A_sorted[i] - B_crossed[i]) for i in range(len(A)))
        for i in range(len(A)):
            print(f"  {A_sorted[i]} <-> {B_crossed[i]} : diff = {abs(A_sorted[i] - B_crossed[i])}")
        print(f"Total: {cross_sum}")

        print(f"\nCrossing cost MORE by: {cross_sum - opt_sum}")


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Comprehensive test cases with explanations."""

    print("=" * 60)
    print("MIN SUM OF ABSOLUTE DIFFERENCE PAIRS - TEST CASES")
    print("=" * 60)

    # Test 1: Basic example
    print("\nTest 1: Basic Example")
    print("-" * 40)
    A = [4, 1, 8, 7]
    B = [2, 3, 6, 5]
    result = min_sum_pairs(A, B)
    brute = brute_force_min_sum(A, B)
    sum_val, pairs = min_sum_pairs_with_pairing(A, B)

    print(f"A: {A}")
    print(f"B: {B}")
    print(f"Optimal pairs: {pairs}")
    print(f"Greedy result: {result}")
    print(f"Brute force: {brute}")
    assert result == brute, f"Mismatch!"
    print("PASS")

    # Test 2: Already optimal
    print("\nTest 2: Already Sorted")
    print("-" * 40)
    A = [1, 2, 3]
    B = [4, 5, 6]
    result = min_sum_pairs(A, B)
    print(f"A: {A}, B: {B}")
    print(f"Result: {result}")
    assert result == 9  # |1-4| + |2-5| + |3-6| = 3 + 3 + 3
    print("PASS")

    # Test 3: Identical arrays
    print("\nTest 3: Identical Arrays")
    print("-" * 40)
    A = [1, 2, 3, 4]
    B = [1, 2, 3, 4]
    result = min_sum_pairs(A, B)
    print(f"A: {A}, B: {B}")
    print(f"Result: {result}")
    assert result == 0
    print("PASS")

    # Test 4: Negative numbers
    print("\nTest 4: Negative Numbers")
    print("-" * 40)
    A = [-3, -1, 2, 4]
    B = [-4, -2, 1, 3]
    result = min_sum_pairs(A, B)
    brute = brute_force_min_sum(A, B)
    print(f"A: {A}, B: {B}")
    print(f"Greedy: {result}, Brute: {brute}")
    assert result == brute
    print("PASS")

    # Test 5: Single element
    print("\nTest 5: Single Element")
    print("-" * 40)
    A = [5]
    B = [3]
    result = min_sum_pairs(A, B)
    print(f"A: {A}, B: {B}")
    print(f"Result: {result}")
    assert result == 2
    print("PASS")

    # Test 6: Max sum comparison
    print("\nTest 6: Min vs Max Sum")
    print("-" * 40)
    A = [1, 2, 3, 4]
    B = [5, 6, 7, 8]
    min_result = min_sum_pairs(A, B)
    max_result = max_sum_pairs(A, B)
    print(f"A: {A}, B: {B}")
    print(f"Minimum sum: {min_result}")
    print(f"Maximum sum: {max_result}")
    print("PASS")

    # Test 7: Random case verification
    print("\nTest 7: Random Case")
    print("-" * 40)
    A = [10, 3, 7, 2, 9]
    B = [1, 8, 4, 6, 5]
    result = min_sum_pairs(A, B)
    brute = brute_force_min_sum(A, B)
    print(f"A: {A}, B: {B}")
    print(f"Greedy: {result}, Brute: {brute}")
    assert result == brute
    print("PASS")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


if __name__ == "__main__":
    run_tests()
    demonstrate_exchange_argument([4, 1, 8, 7], [2, 3, 6, 5])
