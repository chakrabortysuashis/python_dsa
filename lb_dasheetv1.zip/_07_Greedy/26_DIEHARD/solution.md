# DIEHARD - Game Survival (SPOJ)

## Problem Statement

A game character starts with given health (H) and armor (A). The character must survive by visiting one of three places in each turn:
- **Fire:** -20 health, +3 armor
- **Water:** -5 health, -10 armor  
- **Air:** +3 health, +2 armor

Rules:
- Cannot visit same place twice in a row
- Health and armor must stay > 0 at all times
- Maximize number of turns survived

**Input:** Initial health H, initial armor A

**Output:** Maximum turns the character can survive

---

## Why Greedy Works Here

### Greedy Observation

**Claim:** To maximize survival, alternate between Air and Water (avoiding Fire unless necessary).

**Intuition:**
- Air gives +3 health, +2 armor (always beneficial)
- Water costs -5 health, -10 armor (necessary to switch from Air)
- Air-Water alternation: net +3-5 = -2 health, +2-10 = -8 armor per 2 turns
- Fire is too costly (-20 health)

### Optimal Strategy

The best strategy is:
1. Go to Air (gain health and armor)
2. Go to Water (lose some, but allows returning to Air)
3. Repeat Air-Water until resources run out

### When Air-Water Cycle Works

After Air: H+3, A+2
After Water: H-2 (net), A-8 (net)

Continue while: H > 5 and A > 10 (enough for Water visit)

---

## Step-by-Step Algorithm

```
1. INITIALIZE turns = 0
2. WHILE can continue:
   a. TRY Air if not last place and would survive
   b. TRY Water if not last place and would survive
   c. IF neither works, STOP
3. RETURN turns
```

### Simplified Formula

For Air-Water alternation:
- Each Air-Water cycle costs: 2 health, 8 armor
- Count cycles possible, multiply by 2

---

## Implementation

```python
def diehard(H, A):
    turns = 0
    last = None
    
    while True:
        # Try Air first (most beneficial)
        if last != 'air':
            new_H, new_A = H + 3, A + 2
            if new_H > 0 and new_A > 0:
                H, A = new_H, new_A
                last = 'air'
                turns += 1
                continue
        
        # Try Water
        if last != 'water':
            new_H, new_A = H - 5, A - 10
            if new_H > 0 and new_A > 0:
                H, A = new_H, new_A
                last = 'water'
                turns += 1
                continue
        
        # Fire is rarely useful due to -20 health
        if last != 'fire':
            new_H, new_A = H - 20, A + 3
            if new_H > 0 and new_A > 0:
                H, A = new_H, new_A
                last = 'fire'
                turns += 1
                continue
        
        break
    
    return turns
```

---

## Dry Run

**Input:** H = 20, A = 8

```
Turn 1: Go to Air
  H = 20 + 3 = 23
  A = 8 + 2 = 10
  
Turn 2: Go to Water
  H = 23 - 5 = 18
  A = 10 - 10 = 0? NO! A must be > 0
  
Actually, A would become 0, so can't go to Water.
Try Fire? H = 23 - 20 = 3, A = 10 + 3 = 13
That works!

Turn 2: Go to Fire
  H = 3, A = 13
  
Turn 3: Go to Air
  H = 6, A = 15
  
Turn 4: Go to Water
  H = 1, A = 5
  
Turn 5: Go to Air
  H = 4, A = 7
  
...continue until can't proceed
```

---

## Time and Space Complexity

| Aspect | Complexity | Explanation |
|--------|------------|-------------|
| **Time** | O(H + A) | Proportional to turns survived |
| **Space** | O(1) | Only track current state |

---

## Key Insights

1. **Fire is rarely useful:** -20 health is too costly
2. **Air-Water alternation:** Optimal for most cases
3. **Greedy works:** At each step, pick the move that leaves best state
