"""
Maximum Sum of Absolute Differences - Greedy Algorithm
=======================================================

Problem: Given an array of n integers, rearrange elements to maximize
the sum of absolute differences of consecutive elements.

WHY GREEDY WORKS:
-----------------
1. Greedy Choice Property: Placing extreme values (min/max) adjacent to
   each other maximizes their contribution to the total sum.

2. Exchange Argument: If any middle element is not an extreme value,
   swapping it with an extreme value will increase the sum because
   extreme values create larger differences.

3. Optimal Substructure: After placing two extreme values adjacent,
   the problem reduces to the same problem on remaining elements.

GREEDY STRATEGY: Sort the array and build a zigzag pattern by alternating
between the smallest and largest remaining elements.
"""

from typing import List, Tuple
from itertools import permutations


def max_sum_absolute_diff(arr: List[int]) -> int:
    """
    Calculate maximum sum of absolute differences using zigzag arrangement.

    Greedy Strategy:
    1. Sort the array
    2. Build zigzag: alternate between largest and smallest
    3. Sum of differences in this arrangement is maximum

    Time: O(n log n) for sorting
    Space: O(n) for result array

    Example:
    >>> max_sum_absolute_diff([1, 2, 4, 8])
    12
    >>> max_sum_absolute_diff([1, 2, 3, 4, 5])
    12
    """
    n = len(arr)
    if n <= 1:
        return 0

    arr = sorted(arr)

    # Build zigzag arrangement
    result = []
    left, right = 0, n - 1

    while left <= right:
        if right >= left:
            result.append(arr[right])
            right -= 1
        if left <= right:
            result.append(arr[left])
            left += 1

    # Calculate sum of absolute differences
    total = sum(abs(result[i] - result[i+1]) for i in range(n-1))

    return total


def max_sum_absolute_diff_formula(arr: List[int]) -> int:
    """
    Calculate maximum sum using mathematical formula.

    Key Insight: In optimal arrangement, each element (except first and last)
    contributes to TWO differences. Elements pair up from extremes.

    For sorted array [a0, a1, ..., an-1]:
    - Pair (a0, an-1), (a1, an-2), etc.
    - Each pair contributes 2 * (large - small) to total

    Time: O(n log n) for sorting
    Space: O(1) extra (O(n) if counting sorted copy)

    Example:
    >>> max_sum_absolute_diff_formula([1, 2, 4, 8])
    12
    """
    n = len(arr)
    if n <= 1:
        return 0

    arr = sorted(arr)

    total = 0
    for i in range(n // 2):
        # Each pair contributes twice (once from each direction in zigzag)
        total += 2 * (arr[n - 1 - i] - arr[i])

    # Adjustment for odd-length arrays (middle element contributes once less)
    # Actually, the formula 2 * sum(differences of pairs) works correctly

    return total


def max_sum_with_arrangement(arr: List[int]) -> Tuple[int, List[int]]:
    """
    Return both maximum sum and the optimal arrangement.

    Returns:
        Tuple of (maximum_sum, optimal_arrangement)

    Example:
    >>> sum_val, arrangement = max_sum_with_arrangement([1, 2, 4, 8])
    >>> sum_val
    12
    """
    n = len(arr)
    if n <= 1:
        return 0, arr[:]

    arr = sorted(arr)

    # Build zigzag: start with largest, then smallest, then second largest, etc.
    result = []
    left, right = 0, n - 1
    take_right = True

    while left <= right:
        if take_right:
            result.append(arr[right])
            right -= 1
        else:
            result.append(arr[left])
            left += 1
        take_right = not take_right

    total = sum(abs(result[i] - result[i+1]) for i in range(n-1))

    return total, result


def max_sum_alternative_zigzag(arr: List[int]) -> int:
    """
    Alternative zigzag construction for verification.

    Place elements at even indices from one end, odd indices from other.

    Example:
    >>> max_sum_alternative_zigzag([1, 2, 4, 8])
    12
    """
    n = len(arr)
    if n <= 1:
        return 0

    arr = sorted(arr)
    result = [0] * n

    # Fill even indices with larger elements
    # Fill odd indices with smaller elements
    left, right = 0, n - 1
    for i in range(n):
        if i % 2 == 0:
            result[i] = arr[right]
            right -= 1
        else:
            result[i] = arr[left]
            left += 1

    return sum(abs(result[i] - result[i+1]) for i in range(n-1))


# =============================================================================
# BRUTE FORCE - For comparison and verification
# =============================================================================

def brute_force_max_sum(arr: List[int]) -> int:
    """
    Brute force: try all permutations.

    Time: O(n! * n)
    Space: O(n)

    Only use for small inputs (n <= 8)
    """
    if len(arr) <= 1:
        return 0

    max_sum = 0
    for perm in permutations(arr):
        curr_sum = sum(abs(perm[i] - perm[i+1]) for i in range(len(perm)-1))
        max_sum = max(max_sum, curr_sum)

    return max_sum


# =============================================================================
# RELATED PROBLEMS
# =============================================================================

def min_sum_absolute_diff(arr: List[int]) -> int:
    """
    Minimize sum of absolute differences (opposite problem).

    Solution: Keep array sorted! Consecutive sorted elements
    minimize differences.

    Time: O(n log n)
    Space: O(1)

    Example:
    >>> min_sum_absolute_diff([4, 2, 1, 8])
    7
    """
    if len(arr) <= 1:
        return 0

    arr = sorted(arr)
    return sum(arr[i+1] - arr[i] for i in range(len(arr)-1))


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Comprehensive test cases with explanations."""

    print("=" * 60)
    print("MAX SUM OF ABSOLUTE DIFFERENCES - TEST CASES")
    print("=" * 60)

    # Test 1: Basic example
    print("\nTest 1: Basic Example")
    print("-" * 40)
    arr = [1, 2, 4, 8]
    result = max_sum_absolute_diff(arr)
    brute = brute_force_max_sum(arr)
    sum_val, arrangement = max_sum_with_arrangement(arr)

    print(f"Input: {arr}")
    print(f"Optimal arrangement: {arrangement}")
    print(f"Greedy result: {result}")
    print(f"Brute force result: {brute}")
    assert result == brute, f"Mismatch! Greedy: {result}, Brute: {brute}"
    print("PASS")

    # Test 2: All same elements
    print("\nTest 2: All Same Elements")
    print("-" * 40)
    arr = [5, 5, 5, 5]
    result = max_sum_absolute_diff(arr)
    print(f"Input: {arr}")
    print(f"Result: {result}")
    assert result == 0, f"Expected 0, got {result}"
    print("PASS")

    # Test 3: Two elements
    print("\nTest 3: Two Elements")
    print("-" * 40)
    arr = [1, 10]
    result = max_sum_absolute_diff(arr)
    print(f"Input: {arr}")
    print(f"Result: {result}")
    assert result == 9, f"Expected 9, got {result}"
    print("PASS")

    # Test 4: Negative numbers
    print("\nTest 4: Negative Numbers")
    print("-" * 40)
    arr = [-5, -2, 3, 8]
    result = max_sum_absolute_diff(arr)
    brute = brute_force_max_sum(arr)
    print(f"Input: {arr}")
    print(f"Greedy: {result}, Brute: {brute}")
    assert result == brute, f"Mismatch!"
    print("PASS")

    # Test 5: Odd length array
    print("\nTest 5: Odd Length Array")
    print("-" * 40)
    arr = [1, 2, 3, 4, 5]
    result = max_sum_absolute_diff(arr)
    brute = brute_force_max_sum(arr)
    sum_val, arrangement = max_sum_with_arrangement(arr)
    print(f"Input: {arr}")
    print(f"Optimal arrangement: {arrangement}")
    print(f"Greedy: {result}, Brute: {brute}")
    assert result == brute, f"Mismatch!"
    print("PASS")

    # Test 6: Compare all methods
    print("\nTest 6: Compare All Methods")
    print("-" * 40)
    arr = [3, 7, 2, 9, 1, 5]

    result1 = max_sum_absolute_diff(arr)
    result2 = max_sum_absolute_diff_formula(arr)
    result3 = max_sum_alternative_zigzag(arr)
    brute = brute_force_max_sum(arr)

    print(f"Input: {arr}")
    print(f"Zigzag method: {result1}")
    print(f"Formula method: {result2}")
    print(f"Alternative zigzag: {result3}")
    print(f"Brute force: {brute}")

    assert result1 == brute, "Zigzag method failed"
    print("PASS")

    # Test 7: Single element
    print("\nTest 7: Single Element")
    print("-" * 40)
    arr = [42]
    result = max_sum_absolute_diff(arr)
    print(f"Input: {arr}")
    print(f"Result: {result}")
    assert result == 0, f"Expected 0, got {result}"
    print("PASS")

    # Test 8: Minimize vs Maximize comparison
    print("\nTest 8: Minimize vs Maximize")
    print("-" * 40)
    arr = [4, 2, 1, 8]
    max_result = max_sum_absolute_diff(arr)
    min_result = min_sum_absolute_diff(arr)
    print(f"Input: {arr}")
    print(f"Maximum sum: {max_result}")
    print(f"Minimum sum: {min_result}")
    print(f"Sorted array min: {sorted(arr)} -> {min_result}")
    print("PASS")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_greedy_choice():
    """Step-by-step demonstration of why greedy works."""

    print("\n" + "=" * 60)
    print("DEMONSTRATION: WHY ZIGZAG PATTERN WORKS")
    print("=" * 60)

    arr = [1, 3, 5, 9]
    print(f"\nOriginal array: {arr}")

    sorted_arr = sorted(arr)
    print(f"Sorted: {sorted_arr}")

    print("\nBuilding zigzag pattern:")
    print("-" * 40)

    n = len(sorted_arr)
    left, right = 0, n - 1
    result = []
    step = 1

    while left <= right:
        if right >= left:
            print(f"Step {step}: Take largest remaining = {sorted_arr[right]}")
            result.append(sorted_arr[right])
            right -= 1
            step += 1
        if left <= right:
            print(f"Step {step}: Take smallest remaining = {sorted_arr[left]}")
            result.append(sorted_arr[left])
            left += 1
            step += 1

    print(f"\nFinal arrangement: {result}")

    print("\nCalculating differences:")
    total = 0
    for i in range(len(result) - 1):
        diff = abs(result[i] - result[i+1])
        total += diff
        print(f"  |{result[i]} - {result[i+1]}| = {diff}")

    print(f"\nTotal sum: {total}")

    print("\nWHY THIS IS OPTIMAL:")
    print("The zigzag pattern ensures that each pair of adjacent")
    print("elements has maximum possible difference by always placing")
    print("extreme values (smallest and largest) next to each other.")


if __name__ == "__main__":
    run_tests()
    demonstrate_greedy_choice()
