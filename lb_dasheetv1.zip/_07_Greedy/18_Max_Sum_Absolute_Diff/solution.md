# Maximum Sum of Absolute Differences

## Problem Statement

Given an array of `n` integers, rearrange the elements to maximize the sum of absolute differences of consecutive elements.

**Input:** Array `arr[]` of n integers

**Output:** Maximum possible sum of `|arr[0] - arr[1]| + |arr[1] - arr[2]| + ... + |arr[n-2] - arr[n-1]|`

**Example:**
```
Input: arr[] = [1, 2, 4, 8]
Output: 18
Arrangement: [1, 8, 2, 4] gives |1-8| + |8-2| + |2-4| = 7 + 6 + 2 = 15
Better: [2, 8, 1, 4] gives |2-8| + |8-1| + |1-4| = 6 + 7 + 3 = 16
Optimal: [1, 8, 2, 4] or similar zigzag patterns
```

---

## Why Greedy Works Here

### The Greedy Choice Property

**Claim:** To maximize sum of absolute differences, arrange elements in a "zigzag" pattern alternating between smallest and largest remaining elements.

**Intuition:**
- Each element (except endpoints) contributes to TWO differences
- To maximize contribution, place extreme values (min/max) next to each other
- Alternating small-large-small-large maximizes each difference

### Exchange Argument Proof

1. Let `OPT` be any optimal arrangement
2. Consider any three consecutive elements `a, b, c` where `b` is not an extreme value
3. If we swap `b` with an extreme value `e`:
   - Original contribution: `|a-b| + |b-c|`
   - New contribution: `|a-e| + |e-c|`
4. Since `e` is more extreme (farther from median), the sum of differences increases
5. Therefore, placing extreme values alternately is optimal

### The Zigzag Pattern

The optimal arrangement follows this pattern:
```
Sort array: [a1, a2, a3, ..., an] (ascending)

Arrange as: [a1, an, a2, an-1, a3, an-2, ...]
         or [an, a1, an-1, a2, an-2, a3, ...]

Both achieve the same maximum sum.
```

---

## Step-by-Step Greedy Selection

### Algorithm:

```
1. SORT array in ascending order
2. CREATE two pointers: left = 0, right = n-1
3. BUILD result by alternating:
   - Take from left (smallest remaining)
   - Take from right (largest remaining)
4. CALCULATE sum of absolute differences
5. RETURN maximum sum
```

### Mathematical Formula (After Sorting):

For sorted array `[a1, a2, ..., an]`:
- Each element in the middle contributes TWICE
- Elements at extremes contribute ONCE

**Formula:** `2 * (sum of larger half) - 2 * (sum of smaller half)`

This simplifies to: `2 * (a_n + a_{n-1} + ... + a_{(n+1)/2}) - 2 * (a_1 + a_2 + ... + a_{n/2})`

---

## Brute Force Comparison

### Brute Force Approach
Generate all permutations and calculate sum of absolute differences for each.

```python
from itertools import permutations

def brute_force(arr):
    max_sum = 0
    
    for perm in permutations(arr):
        curr_sum = sum(abs(perm[i] - perm[i+1]) for i in range(len(perm)-1))
        max_sum = max(max_sum, curr_sum)
    
    return max_sum
```

**Time Complexity:** O(n! * n)
**Space Complexity:** O(n)

---

## Optimal Greedy Approach

```python
def max_sum_absolute_diff(arr):
    n = len(arr)
    if n <= 1:
        return 0
    
    arr.sort()
    
    # Build zigzag arrangement
    result = []
    left, right = 0, n - 1
    
    while left <= right:
        if left <= right:
            result.append(arr[right])
            right -= 1
        if left <= right:
            result.append(arr[left])
            left += 1
    
    # Calculate sum of absolute differences
    total = sum(abs(result[i] - result[i+1]) for i in range(n-1))
    
    return total
```

**Time Complexity:** O(n log n) for sorting
**Space Complexity:** O(n) for result array

### Optimized Formula-Based Solution

```python
def max_sum_absolute_diff_optimized(arr):
    n = len(arr)
    if n <= 1:
        return 0
    
    arr.sort()
    
    # Each middle element contributes twice
    # Elements are used in pairs from extremes
    total = 0
    for i in range(n // 2):
        total += 2 * (arr[n-1-i] - arr[i])
    
    return total
```

---

## Dry Run with Selection Visualization

**Input:** `arr = [1, 2, 4, 8]`

**Step 1: Sort Array**
```
Sorted: [1, 2, 4, 8]
```

**Step 2: Build Zigzag Arrangement**
```
Pointers: left=0 (value=1), right=3 (value=8)

Round 1:
  Take from right: 8
  Take from left: 1
  Result: [8, 1]
  
Round 2:
  Take from right: 4
  Take from left: 2
  Result: [8, 1, 4, 2]

Final Arrangement: [8, 1, 4, 2]
```

**Step 3: Calculate Sum**
```
|8 - 1| + |1 - 4| + |4 - 2|
= 7 + 3 + 2
= 12
```

**Alternative Verification (Formula):**
```
Sorted: [1, 2, 4, 8]
Pairs: (1, 8) and (2, 4)
Sum = 2 * (8 - 1) + 2 * (4 - 2) = 14 + 4 = 18? 

Wait - for non-circular case:
The formula is: 2 * sum(arr[n//2:]) - 2 * sum(arr[:n//2])
But endpoints only contribute once, so adjust.
```

---

## Time and Space Complexity

| Aspect | Complexity | Explanation |
|--------|------------|-------------|
| **Time** | O(n log n) | Dominated by sorting |
| **Space** | O(n) | For result arrangement (can be O(1) with formula) |

### Breakdown:
- **Sorting:** O(n log n)
- **Building result:** O(n)
- **Sum calculation:** O(n)
- **Total:** O(n log n)

---

## Variations and Extensions

### 1. Circular Array
If array is circular (last element adjacent to first), use a different approach - see Problem 19.

### 2. Minimize Sum of Absolute Differences
Sort array and keep as is - consecutive sorted elements minimize differences.

### 3. K-Swaps Constraint
Maximize sum with at most K swaps - requires different approach (greedy swaps).

### 4. Weighted Differences
If each position has a weight, problem becomes more complex.
