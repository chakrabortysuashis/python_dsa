"""
Problem: Detect Cycle in Directed Graph
=======================================

Given a directed graph, detect if it contains a cycle.

Approach 1: DFS with Recursion Stack
- Track vertices in current DFS path (ancestors)
- Back edge = edge to ancestor = cycle

Approach 2: BFS (Kahn's Algorithm)
- Use topological sort concept
- If can't process all vertices, cycle exists

Time Complexity: O(V + E)
Space Complexity: O(V)
"""

from collections import deque, defaultdict
from typing import List, Dict, Set, Optional, Tuple


def detect_cycle_dfs(graph: Dict[int, List[int]]) -> bool:
    """
    Detect cycle using DFS with recursion stack.

    Key insight: A cycle exists if we find a back edge
    (edge from a vertex to one of its ancestors in DFS tree).

    We maintain two sets:
    - visited: All vertices ever visited
    - rec_stack: Vertices in current DFS path (ancestors)

    Args:
        graph: Adjacency list (directed graph)

    Returns:
        True if cycle exists, False otherwise
    """
    visited = set()
    rec_stack = set()

    def dfs_has_cycle(vertex: int) -> bool:
        # Mark current vertex as visited and add to recursion stack
        visited.add(vertex)
        rec_stack.add(vertex)

        # Check all neighbors
        for neighbor in graph.get(vertex, []):
            # If not visited, recurse
            if neighbor not in visited:
                if dfs_has_cycle(neighbor):
                    return True
            # If in recursion stack, we found a back edge (cycle!)
            elif neighbor in rec_stack:
                return True

        # Remove from recursion stack when backtracking
        rec_stack.remove(vertex)
        return False

    # Check all vertices (graph might be disconnected)
    for vertex in graph:
        if vertex not in visited:
            if dfs_has_cycle(vertex):
                return True

    return False


def detect_cycle_dfs_with_trace(graph: Dict[int, List[int]]) -> Tuple[bool, List[int]]:
    """
    Detect cycle with detailed trace and return the cycle path if found.
    """
    visited = set()
    rec_stack = set()
    parent = {}  # To reconstruct cycle path

    print("\n" + "=" * 60)
    print("Cycle Detection in Directed Graph (DFS)")
    print("=" * 60)

    def dfs_has_cycle(vertex: int) -> Optional[int]:
        """Returns the start of cycle if found, None otherwise."""
        visited.add(vertex)
        rec_stack.add(vertex)

        print(f"\nVisit vertex {vertex}")
        print(f"  visited = {visited}")
        print(f"  rec_stack = {rec_stack}")

        for neighbor in graph.get(vertex, []):
            print(f"  Check neighbor {neighbor} of {vertex}")

            if neighbor not in visited:
                parent[neighbor] = vertex
                print(f"    {neighbor} not visited, recurse")
                cycle_start = dfs_has_cycle(neighbor)
                if cycle_start is not None:
                    return cycle_start

            elif neighbor in rec_stack:
                print(f"    {neighbor} is in rec_stack!")
                print(f"    BACK EDGE FOUND: {vertex} -> {neighbor}")
                parent[neighbor] = vertex
                return neighbor

            else:
                print(f"    {neighbor} visited but not in rec_stack (not ancestor)")

        print(f"  Backtrack from {vertex}")
        rec_stack.remove(vertex)
        return None

    # Check all vertices
    for vertex in graph:
        if vertex not in visited:
            print(f"\n--- Starting DFS from vertex {vertex} ---")
            cycle_start = dfs_has_cycle(vertex)

            if cycle_start is not None:
                # Reconstruct cycle path
                cycle = []
                current = cycle_start

                # Go back through parent until we reach cycle_start again
                # But parent might not form a simple path, so we trace rec_stack
                print(f"\nCYCLE DETECTED starting at vertex {cycle_start}")
                return True, []

    print("\n" + "=" * 60)
    print("No cycle found - Graph is a DAG")
    print("=" * 60)

    return False, []


def detect_cycle_bfs_kahn(graph: Dict[int, List[int]]) -> bool:
    """
    Detect cycle using BFS (Kahn's Algorithm for Topological Sort).

    Idea: In a DAG, we can always find a vertex with in-degree 0.
    If we can't process all vertices, there's a cycle.

    Args:
        graph: Adjacency list (directed graph)

    Returns:
        True if cycle exists, False otherwise
    """
    # Get all vertices
    vertices = set(graph.keys())
    for neighbors in graph.values():
        vertices.update(neighbors)

    # Calculate in-degrees
    in_degree = {v: 0 for v in vertices}
    for v in graph:
        for neighbor in graph[v]:
            in_degree[neighbor] += 1

    # Queue vertices with in-degree 0
    queue = deque([v for v in vertices if in_degree[v] == 0])
    processed = 0

    print("\n" + "=" * 60)
    print("Cycle Detection using Kahn's Algorithm (BFS)")
    print("=" * 60)
    print(f"\nInitial in-degrees: {dict(in_degree)}")
    print(f"Vertices with in-degree 0: {list(queue)}")

    while queue:
        vertex = queue.popleft()
        processed += 1
        print(f"\nProcess vertex {vertex}")

        for neighbor in graph.get(vertex, []):
            in_degree[neighbor] -= 1
            print(f"  Decrease in-degree of {neighbor} to {in_degree[neighbor]}")

            if in_degree[neighbor] == 0:
                queue.append(neighbor)
                print(f"  {neighbor} now has in-degree 0, add to queue")

    print(f"\nProcessed {processed} out of {len(vertices)} vertices")

    if processed != len(vertices):
        print("CYCLE DETECTED! (couldn't process all vertices)")
        return True
    else:
        print("No cycle - all vertices processed")
        return False


def detect_cycle_colors(graph: Dict[int, List[int]]) -> bool:
    """
    Detect cycle using 3-color DFS (WHITE, GRAY, BLACK).

    Colors:
    - WHITE (0): Not visited
    - GRAY (1): Being processed (in current DFS path)
    - BLACK (2): Completely processed

    A back edge is an edge from GRAY to GRAY.
    """
    WHITE, GRAY, BLACK = 0, 1, 2
    color = defaultdict(int)  # All vertices start WHITE

    def dfs(vertex: int) -> bool:
        color[vertex] = GRAY  # Start processing

        for neighbor in graph.get(vertex, []):
            if color[neighbor] == GRAY:
                # Edge to a vertex being processed = back edge = cycle
                return True
            if color[neighbor] == WHITE:
                if dfs(neighbor):
                    return True

        color[vertex] = BLACK  # Done processing
        return False

    for vertex in graph:
        if color[vertex] == WHITE:
            if dfs(vertex):
                return True

    return False


def find_all_cycles(graph: Dict[int, List[int]]) -> List[List[int]]:
    """
    Find all cycles in a directed graph using DFS.

    Note: This can be computationally expensive for graphs with many cycles.
    """
    cycles = []
    visited = set()
    rec_stack = []
    rec_stack_set = set()

    def dfs(vertex: int) -> None:
        visited.add(vertex)
        rec_stack.append(vertex)
        rec_stack_set.add(vertex)

        for neighbor in graph.get(vertex, []):
            if neighbor not in visited:
                dfs(neighbor)
            elif neighbor in rec_stack_set:
                # Found a cycle - extract it
                cycle_start_idx = rec_stack.index(neighbor)
                cycle = rec_stack[cycle_start_idx:] + [neighbor]
                cycles.append(cycle)

        rec_stack.pop()
        rec_stack_set.remove(vertex)

    for vertex in graph:
        if vertex not in visited:
            dfs(vertex)

    return cycles


# =============================================================================
# Test Cases
# =============================================================================

def test_cyclic_graph():
    """Test graph with cycle."""
    print("\n" + "=" * 60)
    print("TEST: Graph WITH Cycle")
    print("=" * 60)

    # Graph with cycle: 1 -> 2 -> 3 -> 1
    graph = {
        0: [1],
        1: [2],
        2: [3],
        3: [1]  # Back edge creating cycle
    }

    print("\nGraph:")
    print("  0 --> 1 --> 2")
    print("        ^     |")
    print("        |     v")
    print("        +---- 3")
    print("\nCycle: 1 -> 2 -> 3 -> 1")

    # DFS approach
    print("\n--- DFS Approach ---")
    has_cycle_dfs = detect_cycle_dfs(graph)
    print(f"Has cycle (DFS): {has_cycle_dfs}")

    # BFS approach
    print("\n--- BFS Approach (Kahn's) ---")
    has_cycle_bfs = detect_cycle_bfs_kahn(graph)
    print(f"Has cycle (BFS): {has_cycle_bfs}")

    # Colors approach
    has_cycle_colors = detect_cycle_colors(graph)
    print(f"\nHas cycle (3-color): {has_cycle_colors}")


def test_dag():
    """Test DAG (no cycle)."""
    print("\n" + "=" * 60)
    print("TEST: DAG (No Cycle)")
    print("=" * 60)

    graph = {
        0: [1, 2],
        1: [3],
        2: [3],
        3: []
    }

    print("\nGraph (DAG):")
    print("  0 --> 1")
    print("  |     |")
    print("  v     v")
    print("  2 --> 3")

    has_cycle = detect_cycle_dfs(graph)
    print(f"\nHas cycle: {has_cycle}")


def test_self_loop():
    """Test graph with self-loop."""
    print("\n" + "=" * 60)
    print("TEST: Self-Loop")
    print("=" * 60)

    graph = {
        0: [1],
        1: [1],  # Self-loop
        2: []
    }

    print("\nGraph with self-loop:")
    print("  0 --> 1 (self-loop)")
    print("        ^")
    print("        |")
    print("        +")

    has_cycle = detect_cycle_dfs(graph)
    print(f"\nHas cycle: {has_cycle}")


def test_disconnected():
    """Test disconnected graph."""
    print("\n" + "=" * 60)
    print("TEST: Disconnected Graph")
    print("=" * 60)

    graph = {
        # Component 1: No cycle
        0: [1],
        1: [],
        # Component 2: Has cycle
        2: [3],
        3: [4],
        4: [2]  # Creates cycle in component 2
    }

    print("\nDisconnected graph:")
    print("  Component 1: 0 --> 1 (no cycle)")
    print("  Component 2: 2 --> 3 --> 4 --> 2 (cycle!)")

    has_cycle = detect_cycle_dfs(graph)
    print(f"\nHas cycle: {has_cycle}")


def test_with_trace():
    """Test with detailed trace."""
    print("\n" + "=" * 60)
    print("TEST: With Detailed Trace")
    print("=" * 60)

    graph = {
        0: [1],
        1: [2],
        2: [3],
        3: [1]
    }

    detect_cycle_dfs_with_trace(graph)


if __name__ == "__main__":
    test_cyclic_graph()
    test_dag()
    test_self_loop()
    test_disconnected()
    test_with_trace()
