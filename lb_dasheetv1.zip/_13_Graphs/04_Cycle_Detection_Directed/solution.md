# Detect Cycle in Directed Graph

## Problem Statement

Given a directed graph, detect if it contains a cycle. A cycle exists if there's a path from a vertex back to itself following directed edges.

## Graph Visualization

### Graph with Cycle:
```
    0 --> 1 --> 2
          ^     |
          |     v
          +---- 3

Cycle: 1 -> 2 -> 3 -> 1
```

### Graph without Cycle (DAG):
```
    0 --> 1 --> 3
    |     |
    v     v
    2 --> 4

No cycle - This is a DAG (Directed Acyclic Graph)
```

## Approach: DFS with Recursion Stack

The key insight is that a cycle exists in a directed graph if we find a **back edge** - an edge from a vertex to one of its ancestors in the DFS tree.

We track two things:
1. **visited**: All vertices we've ever visited
2. **recursion_stack**: Vertices in the current DFS path (ancestors)

```
A back edge exists if we find a neighbor that is:
- Already in the current recursion stack (ancestor)
```

## Algorithm

```
detect_cycle_dfs(graph):
    visited = empty set
    rec_stack = empty set

    for each vertex v in graph:
        if v not in visited:
            if dfs_has_cycle(v, visited, rec_stack):
                return True
    return False

dfs_has_cycle(vertex, visited, rec_stack):
    visited.add(vertex)
    rec_stack.add(vertex)  # Add to current path

    for neighbor in graph[vertex]:
        if neighbor not in visited:
            if dfs_has_cycle(neighbor, visited, rec_stack):
                return True
        elif neighbor in rec_stack:  # Back edge found!
            return True

    rec_stack.remove(vertex)  # Backtrack
    return False
```

## Step-by-Step Dry Run

### Graph with Cycle:
```
0 -> [1]
1 -> [2]
2 -> [3]
3 -> [1]  <- Creates cycle back to 1
```

### DFS Traversal:

```
STEP 1: Start DFS from vertex 0
        visited = {0}
        rec_stack = {0}
        Check neighbors of 0: [1]

STEP 2: Visit vertex 1
        visited = {0, 1}
        rec_stack = {0, 1}
        Check neighbors of 1: [2]

STEP 3: Visit vertex 2
        visited = {0, 1, 2}
        rec_stack = {0, 1, 2}
        Check neighbors of 2: [3]

STEP 4: Visit vertex 3
        visited = {0, 1, 2, 3}
        rec_stack = {0, 1, 2, 3}
        Check neighbors of 3: [1]

STEP 5: Check neighbor 1 of vertex 3
        1 is in visited? YES
        1 is in rec_stack? YES!
        
        BACK EDGE FOUND: 3 -> 1
        CYCLE DETECTED!

Cycle path: 1 -> 2 -> 3 -> 1
```

### Recursion Stack Visualization:

```
DFS Call Stack:          rec_stack at each step:

dfs(0)                   {0}
  |
  +-> dfs(1)             {0, 1}
        |
        +-> dfs(2)       {0, 1, 2}
              |
              +-> dfs(3) {0, 1, 2, 3}
                    |
                    +-> neighbor 1 in rec_stack!
                        CYCLE FOUND!
```

## Graph Without Cycle (DAG):

```
0 -> [1, 2]
1 -> [3]
2 -> [3]
3 -> []
```

### DFS Traversal:

```
STEP 1: DFS(0)
        rec_stack = {0}
        Neighbors: [1, 2]

STEP 2: DFS(1)
        rec_stack = {0, 1}
        Neighbors: [3]

STEP 3: DFS(3)
        rec_stack = {0, 1, 3}
        Neighbors: [] (empty)
        Backtrack: rec_stack = {0, 1}

STEP 4: Backtrack from 1
        rec_stack = {0}

STEP 5: DFS(2)
        rec_stack = {0, 2}
        Neighbors: [3]
        3 is visited but NOT in rec_stack
        (3 was visited from different path)
        No cycle here!

STEP 6: Backtrack from 2
        rec_stack = {0}

STEP 7: Backtrack from 0
        rec_stack = {}

NO CYCLE FOUND - This is a DAG!
```

## Why Two Sets?

```
visited vs rec_stack:

visited: Tracks ALL vertices we've ever seen
         Purpose: Don't start a new DFS from already explored vertices

rec_stack: Tracks vertices in CURRENT DFS path (ancestors)
           Purpose: Detect back edges

Example where this matters:

    0 --> 1 --> 3
    |           ^
    v           |
    2 ----------+

DFS from 0:
- Visit 0, 1, 3 (no cycle)
- Backtrack, visit 2
- 2's neighbor is 3
- 3 is in visited but NOT in rec_stack
- This is NOT a cycle! (3 is not an ancestor of 2)
```

## Alternative: BFS with Kahn's Algorithm

Use topological sort concept - if we can't process all vertices, there's a cycle.

```
detect_cycle_bfs(graph):
    1. Calculate in-degree of all vertices
    2. Add all vertices with in-degree 0 to queue
    3. While queue not empty:
        - Dequeue vertex v
        - For each neighbor of v:
            - Decrease in-degree by 1
            - If in-degree becomes 0, enqueue
        - Increment processed count
    4. If processed count != total vertices:
        Cycle exists!
```

## Time & Space Complexity

| Approach | Time | Space |
|----------|------|-------|
| DFS | O(V + E) | O(V) |
| BFS (Kahn's) | O(V + E) | O(V) |

## When to Use Which?

| Approach | Best For |
|----------|----------|
| DFS | Finding the actual cycle, simpler to implement |
| BFS | When you also need topological order |

## Key Points

1. **Back edge** indicates a cycle in directed graph
2. Use **recursion stack** (not just visited) to track ancestors
3. Remove vertex from rec_stack when backtracking
4. Must check ALL vertices (graph might be disconnected)
5. BFS alternative uses in-degree concept

## Common Mistakes

1. Using only visited set (won't work - see "Why Two Sets?" above)
2. Not removing from rec_stack when backtracking
3. Not handling disconnected graphs
4. Confusing with undirected graph cycle detection

## Related Problems

- Detect Cycle in Undirected Graph (different approach)
- Topological Sort (only possible for DAGs)
- Course Schedule (application of cycle detection)
