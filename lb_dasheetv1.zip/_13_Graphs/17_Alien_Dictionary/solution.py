"""
Problem: Alien Dictionary
=========================

Given a sorted list of words in an alien language, determine the order of characters.

Approach:
1. Build directed graph from word comparisons
2. Topological sort to get character ordering

Time Complexity: O(C) where C = total characters in all words
Space Complexity: O(1) or O(U) where U = unique characters
"""

from collections import defaultdict, deque
from typing import List, Dict, Set, Tuple


def alien_order_bfs(words: List[str]) -> str:
    """
    Find alien dictionary order using BFS (Kahn's algorithm).

    Steps:
    1. Build graph by comparing adjacent words
    2. Calculate in-degrees
    3. BFS topological sort

    Example:
        >>> alien_order_bfs(["wrt", "wrf", "er", "ett", "rftt"])
        'wertf'
    """
    if not words:
        return ""

    # Initialize graph and in-degrees for all unique characters
    graph = defaultdict(set)
    in_degree = {c: 0 for word in words for c in word}

    # Build graph by comparing adjacent words
    for i in range(len(words) - 1):
        w1, w2 = words[i], words[i + 1]
        min_len = min(len(w1), len(w2))

        # Invalid case: w1 is prefix of w2 but longer
        if len(w1) > len(w2) and w1[:min_len] == w2[:min_len]:
            return ""

        # Find first different character
        for j in range(min_len):
            if w1[j] != w2[j]:
                # w1[j] comes before w2[j]
                if w2[j] not in graph[w1[j]]:
                    graph[w1[j]].add(w2[j])
                    in_degree[w2[j]] += 1
                break

    # BFS Topological Sort
    queue = deque([c for c in in_degree if in_degree[c] == 0])
    result = []

    while queue:
        char = queue.popleft()
        result.append(char)

        for neighbor in graph[char]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)

    # Check for cycle (not all characters processed)
    if len(result) != len(in_degree):
        return ""

    return "".join(result)


def alien_order_dfs(words: List[str]) -> str:
    """
    Find alien dictionary order using DFS with cycle detection.

    Uses three-color marking:
    - WHITE (0): Not visited
    - GRAY (1): Being processed (in current DFS path)
    - BLACK (2): Completely processed
    """
    if not words:
        return ""

    # Build graph
    graph = defaultdict(set)
    all_chars = set()

    for word in words:
        for c in word:
            all_chars.add(c)

    # Compare adjacent words
    for i in range(len(words) - 1):
        w1, w2 = words[i], words[i + 1]
        min_len = min(len(w1), len(w2))

        # Invalid prefix case
        if len(w1) > len(w2) and w1[:min_len] == w2[:min_len]:
            return ""

        for j in range(min_len):
            if w1[j] != w2[j]:
                graph[w1[j]].add(w2[j])
                break

    # DFS with cycle detection
    WHITE, GRAY, BLACK = 0, 1, 2
    color = {c: WHITE for c in all_chars}
    result = []

    def dfs(node: str) -> bool:
        """Returns False if cycle detected."""
        color[node] = GRAY

        for neighbor in graph[node]:
            if color[neighbor] == GRAY:
                return False  # Cycle detected
            if color[neighbor] == WHITE:
                if not dfs(neighbor):
                    return False

        color[node] = BLACK
        result.append(node)
        return True

    # Process all characters
    for c in all_chars:
        if color[c] == WHITE:
            if not dfs(c):
                return ""

    # Reverse because DFS adds in reverse topological order
    return "".join(reversed(result))


def alien_order_with_trace(words: List[str]) -> str:
    """BFS solution with detailed trace."""
    print("\n" + "=" * 60)
    print("Alien Dictionary - BFS Trace")
    print("=" * 60)
    print(f"\nInput words: {words}")

    if not words:
        return ""

    # Initialize
    graph = defaultdict(set)
    in_degree = {c: 0 for word in words for c in word}

    print(f"\nUnique characters: {set(in_degree.keys())}")
    print("\n--- Building Graph ---")

    # Build graph
    for i in range(len(words) - 1):
        w1, w2 = words[i], words[i + 1]
        print(f"\nComparing '{w1}' vs '{w2}':")

        min_len = min(len(w1), len(w2))

        # Check invalid case
        if len(w1) > len(w2) and w1[:min_len] == w2[:min_len]:
            print(f"  INVALID: '{w1}' is longer but prefix matches")
            return ""

        found_diff = False
        for j in range(min_len):
            if w1[j] != w2[j]:
                print(f"  Position {j}: '{w1[j]}' != '{w2[j]}'")
                print(f"  -> Edge: {w1[j]} -> {w2[j]}")

                if w2[j] not in graph[w1[j]]:
                    graph[w1[j]].add(w2[j])
                    in_degree[w2[j]] += 1
                else:
                    print(f"  -> Edge already exists")
                found_diff = True
                break
            else:
                print(f"  Position {j}: '{w1[j]}' == '{w2[j]}' -> continue")

        if not found_diff:
            print(f"  No difference found (one is prefix of other)")

    print("\n--- Graph Built ---")
    print("Adjacency list:")
    for node in sorted(graph.keys()):
        print(f"  {node} -> {sorted(graph[node])}")

    print("\nIn-degrees:")
    for node in sorted(in_degree.keys()):
        print(f"  {node}: {in_degree[node]}")

    # BFS
    print("\n--- BFS Topological Sort ---")
    queue = deque([c for c in in_degree if in_degree[c] == 0])
    result = []

    print(f"\nInitial queue (in-degree 0): {list(queue)}")

    step = 0
    while queue:
        step += 1
        char = queue.popleft()
        result.append(char)

        print(f"\nStep {step}:")
        print(f"  Dequeue: '{char}'")
        print(f"  Result so far: {''.join(result)}")

        for neighbor in sorted(graph[char]):
            in_degree[neighbor] -= 1
            print(f"  Decrement in-degree[{neighbor}]: {in_degree[neighbor] + 1} -> {in_degree[neighbor]}")

            if in_degree[neighbor] == 0:
                queue.append(neighbor)
                print(f"  Enqueue: '{neighbor}'")

        print(f"  Queue: {list(queue)}")

    print(f"\n--- Result ---")
    if len(result) != len(in_degree):
        print(f"CYCLE DETECTED! Only processed {len(result)} of {len(in_degree)} characters")
        return ""

    answer = "".join(result)
    print(f"Alien alphabet order: {answer}")
    return answer


def verify_order(words: List[str], order: str) -> bool:
    """Verify if the order is valid for given words."""
    if not order:
        return False

    char_rank = {c: i for i, c in enumerate(order)}

    for i in range(len(words) - 1):
        w1, w2 = words[i], words[i + 1]

        for j in range(min(len(w1), len(w2))):
            if w1[j] != w2[j]:
                if char_rank.get(w1[j], float('inf')) > char_rank.get(w2[j], float('inf')):
                    return False
                break
        else:
            if len(w1) > len(w2):
                return False

    return True


# =============================================================================
# Test Cases
# =============================================================================

def test_alien_dictionary():
    """Test alien dictionary implementations."""
    print("\n" + "=" * 60)
    print("Alien Dictionary - Test Cases")
    print("=" * 60)

    # Test 1: Standard case
    words1 = ["wrt", "wrf", "er", "ett", "rftt"]
    print(f"\nTest 1: {words1}")
    result_bfs = alien_order_bfs(words1)
    result_dfs = alien_order_dfs(words1)
    print(f"  BFS: '{result_bfs}'")
    print(f"  DFS: '{result_dfs}'")
    print(f"  Valid: {verify_order(words1, result_bfs)}")

    # Test 2: Simple two words
    words2 = ["z", "x"]
    print(f"\nTest 2: {words2}")
    result = alien_order_bfs(words2)
    print(f"  Result: '{result}'")
    # z comes before x

    # Test 3: Invalid - prefix longer
    words3 = ["abc", "ab"]
    print(f"\nTest 3: {words3} (invalid - prefix case)")
    result = alien_order_bfs(words3)
    print(f"  Result: '{result}' (empty = invalid)")

    # Test 4: Cycle detection
    words4 = ["z", "x", "z"]
    print(f"\nTest 4: {words4} (cycle)")
    result = alien_order_bfs(words4)
    print(f"  Result: '{result}' (empty = cycle detected)")

    # Test 5: Single word
    words5 = ["abc"]
    print(f"\nTest 5: {words5}")
    result = alien_order_bfs(words5)
    print(f"  Result: '{result}'")

    # Test 6: Multiple valid orderings
    words6 = ["z", "z"]
    print(f"\nTest 6: {words6}")
    result = alien_order_bfs(words6)
    print(f"  Result: '{result}'")

    print("\nAll tests completed!")


def test_with_trace():
    """Test with detailed trace."""
    words = ["wrt", "wrf", "er", "ett", "rftt"]
    alien_order_with_trace(words)


if __name__ == "__main__":
    test_alien_dictionary()
    test_with_trace()
