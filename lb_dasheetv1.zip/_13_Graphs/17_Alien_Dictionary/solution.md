# Alien Dictionary

## Problem Statement

There is a new alien language which uses the latin alphabet. However, the order among letters are unknown to you. You receive a list of words from the dictionary, where words are sorted lexicographically by the rules of this new language. Derive the order of letters in this language.

## Graph Visualization

```
Input: ["wrt", "wrf", "er", "ett", "rftt"]

Step 1: Compare adjacent words to find ordering rules

"wrt" vs "wrf": t comes before f (t -> f)
"wrf" vs "er":  w comes before e (w -> e)
"er" vs "ett":  r comes before t (r -> t)
"ett" vs "rftt": e comes before r (e -> r)

Step 2: Build directed graph

    w -----> e -----> r -----> t -----> f
    
Adjacency List:
w: [e]
e: [r]
r: [t]
t: [f]
f: []

Step 3: Topological Sort

Result: "wertf"
```

## Why Graph + Topological Sort?

```
Character ordering = Directed edges
a -> b means 'a' comes before 'b'

If we have valid ordering, the graph has no cycles
Topological sort gives us the linear ordering

+----------------+     +-----------------+
| Compare words  | --> | Build directed  |
| to find edges  |     | graph           |
+----------------+     +-----------------+
                              |
                              v
                       +----------------+
                       | Topological    |
                       | Sort (BFS/DFS) |
                       +----------------+
```

## Algorithm (BFS - Kahn's)

```
1. Build graph and calculate in-degrees:
   - For each pair of adjacent words:
     - Find first different character
     - Add edge: char1 -> char2
     - Increment in-degree of char2

2. Topological Sort (BFS):
   - Add all nodes with in-degree 0 to queue
   - While queue not empty:
     - Dequeue node, add to result
     - For each neighbor:
       - Decrement in-degree
       - If in-degree becomes 0, enqueue

3. Check for cycle:
   - If result length != number of unique chars
   - Return "" (invalid)
```

## Step-by-Step Dry Run

### Input: ["wrt", "wrf", "er", "ett", "rftt"]

```
STEP 1: Find all unique characters
Unique: {w, r, t, f, e}

STEP 2: Compare adjacent words

Words[0] vs Words[1]: "wrt" vs "wrf"
  Compare char by char:
    'w' == 'w' -> continue
    'r' == 'r' -> continue
    't' != 'f' -> Found! Add edge: t -> f
  
Words[1] vs Words[2]: "wrf" vs "er"
  Compare:
    'w' != 'e' -> Found! Add edge: w -> e

Words[2] vs Words[3]: "er" vs "ett"
  Compare:
    'e' == 'e' -> continue
    'r' != 't' -> Found! Add edge: r -> t

Words[3] vs Words[4]: "ett" vs "rftt"
  Compare:
    'e' != 'r' -> Found! Add edge: e -> r

STEP 3: Build Graph
Graph:
  t -> [f]
  w -> [e]
  r -> [t]
  e -> [r]

In-degrees:
  w: 0
  e: 1 (from w)
  r: 1 (from e)
  t: 1 (from r)
  f: 1 (from t)

STEP 4: BFS Topological Sort

Initial Queue: [w] (only node with in-degree 0)
Result: []

Iteration 1:
  Dequeue: w
  Result: [w]
  Neighbors of w: [e]
    Decrement in-degree[e]: 1 -> 0
    e has in-degree 0, enqueue
  Queue: [e]

Iteration 2:
  Dequeue: e
  Result: [w, e]
  Neighbors of e: [r]
    Decrement in-degree[r]: 1 -> 0
    Enqueue r
  Queue: [r]

Iteration 3:
  Dequeue: r
  Result: [w, e, r]
  Neighbors of r: [t]
    Decrement in-degree[t]: 1 -> 0
    Enqueue t
  Queue: [t]

Iteration 4:
  Dequeue: t
  Result: [w, e, r, t]
  Neighbors of t: [f]
    Decrement in-degree[f]: 1 -> 0
    Enqueue f
  Queue: [f]

Iteration 5:
  Dequeue: f
  Result: [w, e, r, t, f]
  Neighbors of f: []
  Queue: []

FINAL: "wertf"
```

## Edge Cases

```
1. Prefix is longer (Invalid):
   ["abc", "ab"] -> "" 
   "abc" should come after "ab" in any language

2. Single word:
   ["abc"] -> "abc" or any permutation
   
3. Cycle detected:
   ["a", "b", "a"] -> ""
   a -> b -> a creates cycle

4. Multiple valid orderings:
   ["z", "x"] -> could be "zx..." with other chars anywhere
```

## Code Template

```python
from collections import defaultdict, deque

def alienOrder(words):
    # Build graph
    graph = defaultdict(set)
    in_degree = {c: 0 for word in words for c in word}
    
    for i in range(len(words) - 1):
        w1, w2 = words[i], words[i + 1]
        min_len = min(len(w1), len(w2))
        
        # Check invalid case: prefix
        if len(w1) > len(w2) and w1[:min_len] == w2[:min_len]:
            return ""
        
        for j in range(min_len):
            if w1[j] != w2[j]:
                if w2[j] not in graph[w1[j]]:
                    graph[w1[j]].add(w2[j])
                    in_degree[w2[j]] += 1
                break
    
    # BFS Topological Sort
    queue = deque([c for c in in_degree if in_degree[c] == 0])
    result = []
    
    while queue:
        c = queue.popleft()
        result.append(c)
        
        for neighbor in graph[c]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)
    
    if len(result) != len(in_degree):
        return ""  # Cycle detected
    
    return "".join(result)
```

## Time & Space Complexity

| Metric | Complexity | Explanation |
|--------|------------|-------------|
| Time | O(C) | C = total characters in all words |
| Space | O(1) or O(U) | U = unique characters (max 26) |

## DFS Alternative

```python
def alienOrder_dfs(words):
    graph = defaultdict(set)
    # ... build graph same as above ...
    
    # DFS with cycle detection
    # WHITE = 0, GRAY = 1, BLACK = 2
    color = {c: 0 for word in words for c in word}
    result = []
    
    def dfs(node):
        color[node] = 1  # Visiting
        
        for neighbor in graph[node]:
            if color[neighbor] == 1:  # Cycle!
                return False
            if color[neighbor] == 0:
                if not dfs(neighbor):
                    return False
        
        color[node] = 2  # Visited
        result.append(node)
        return True
    
    for c in color:
        if color[c] == 0:
            if not dfs(c):
                return ""
    
    return "".join(reversed(result))
```

## Key Points

1. **Graph construction**: First different character gives edge
2. **Topological sort**: Gives valid ordering
3. **Cycle detection**: Invalid dictionary if cycle exists
4. **Prefix rule**: Longer prefix word must come after
5. Works for any alphabet size (not just English)
