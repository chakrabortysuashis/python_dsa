"""
Problem: Dijkstra's Algorithm
=============================

Shortest path from source to all vertices in weighted graph.
Requires non-negative edge weights.

Time: O((V+E) log V) with binary heap
Space: O(V)
"""

import heapq
from collections import defaultdict
from typing import Dict, List, Tuple


def dijkstra(graph: Dict[str, List[Tuple[str, int]]], source: str) -> Dict[str, int]:
    """
    Dijkstra using min-heap (priority queue).

    Args:
        graph: Adjacency list with weights {vertex: [(neighbor, weight), ...]}
        source: Starting vertex

    Returns:
        Dictionary of shortest distances from source to each vertex
    """
    distances = {v: float('inf') for v in graph}
    distances[source] = 0

    # Min-heap: (distance, vertex)
    heap = [(0, source)]
    visited = set()

    while heap:
        dist, u = heapq.heappop(heap)

        if u in visited:
            continue
        visited.add(u)

        for neighbor, weight in graph[u]:
            if neighbor not in visited:
                new_dist = dist + weight
                if new_dist < distances[neighbor]:
                    distances[neighbor] = new_dist
                    heapq.heappush(heap, (new_dist, neighbor))

    return distances


def dijkstra_with_path(graph: Dict[str, List[Tuple[str, int]]],
                       source: str, target: str) -> Tuple[int, List[str]]:
    """Dijkstra with path reconstruction."""
    distances = {v: float('inf') for v in graph}
    distances[source] = 0
    parent = {source: None}

    heap = [(0, source)]
    visited = set()

    while heap:
        dist, u = heapq.heappop(heap)

        if u in visited:
            continue
        visited.add(u)

        if u == target:
            break

        for neighbor, weight in graph[u]:
            if neighbor not in visited:
                new_dist = dist + weight
                if new_dist < distances[neighbor]:
                    distances[neighbor] = new_dist
                    parent[neighbor] = u
                    heapq.heappush(heap, (new_dist, neighbor))

    # Reconstruct path
    path = []
    current = target
    while current is not None:
        path.append(current)
        current = parent.get(current)
    path.reverse()

    return distances[target], path


def dijkstra_trace(graph: Dict[str, List[Tuple[str, int]]], source: str) -> Dict[str, int]:
    """Dijkstra with detailed trace."""
    distances = {v: float('inf') for v in graph}
    distances[source] = 0

    print(f"\n{'='*60}")
    print(f"Dijkstra's Algorithm from '{source}'")
    print(f"{'='*60}")
    print(f"\nInitial distances: {distances}")

    heap = [(0, source)]
    visited = set()
    step = 0

    while heap:
        step += 1
        print(f"\n{'─'*40}")
        print(f"Step {step}: Heap = {heap}")

        dist, u = heapq.heappop(heap)
        print(f"  Pop: ({dist}, {u})")

        if u in visited:
            print(f"  {u} already visited, skip")
            continue

        visited.add(u)
        print(f"  Process vertex: {u}")

        for neighbor, weight in graph[u]:
            if neighbor not in visited:
                new_dist = dist + weight
                print(f"    Check {u}->{neighbor} (weight={weight}): {dist}+{weight}={new_dist}", end="")

                if new_dist < distances[neighbor]:
                    distances[neighbor] = new_dist
                    heapq.heappush(heap, (new_dist, neighbor))
                    print(f" < {distances[neighbor] if distances[neighbor] != new_dist else 'inf'} -> UPDATE")
                else:
                    print(f" >= {distances[neighbor]} -> no update")

        print(f"  Current distances: {distances}")

    print(f"\n{'='*60}")
    print(f"Final distances: {distances}")
    return distances


# Test
if __name__ == "__main__":
    # Graph: A->B(1), A->C(4), B->D(2), D->C(3)
    graph = {
        'A': [('B', 1), ('C', 4)],
        'B': [('D', 2)],
        'C': [],
        'D': [('C', 3)]
    }

    # With trace
    dijkstra_trace(graph, 'A')

    # With path
    dist, path = dijkstra_with_path(graph, 'A', 'C')
    print(f"\nShortest path A->C: distance={dist}, path={' -> '.join(path)}")

    # Larger example
    graph2 = {
        0: [(1, 4), (2, 1)],
        1: [(3, 1)],
        2: [(1, 2), (3, 5)],
        3: []
    }
    print(f"\nGraph2 distances from 0: {dijkstra(graph2, 0)}")
