# Dijkstra's Algorithm

## Problem Statement

Find the shortest path from a source vertex to all other vertices in a weighted graph with non-negative edge weights.

## Algorithm Concept

Dijkstra uses a **greedy approach** with a **min-heap (priority queue)**:
1. Start with distance to source = 0, all others = infinity
2. Always pick the unprocessed vertex with minimum distance
3. Update distances to neighbors if shorter path found

## Graph Visualization

```
Weighted Graph:
        1
    A -----> B
    |        |
   4|        |2
    |        v
    C <----- D
        3

Edges: (A,B,1), (A,C,4), (B,D,2), (D,C,3)
```

## Algorithm

```python
def dijkstra(graph, source):
    distances = {v: float('inf') for v in graph}
    distances[source] = 0
    
    # Min-heap: (distance, vertex)
    heap = [(0, source)]
    visited = set()
    
    while heap:
        dist, u = heappop(heap)
        
        if u in visited:
            continue
        visited.add(u)
        
        for neighbor, weight in graph[u]:
            if neighbor not in visited:
                new_dist = dist + weight
                if new_dist < distances[neighbor]:
                    distances[neighbor] = new_dist
                    heappush(heap, (new_dist, neighbor))
    
    return distances
```

## Step-by-Step Dry Run

```
Graph: A->(B,1), A->(C,4), B->(D,2), D->(C,3)
Source: A

INITIALIZATION:
distances = {A:0, B:inf, C:inf, D:inf}
heap = [(0, A)]

STEP 1: Pop (0, A)
  Process A
  Update B: 0 + 1 = 1 < inf -> distances[B] = 1
  Update C: 0 + 4 = 4 < inf -> distances[C] = 4
  heap = [(1, B), (4, C)]
  distances = {A:0, B:1, C:4, D:inf}

STEP 2: Pop (1, B)
  Process B
  Update D: 1 + 2 = 3 < inf -> distances[D] = 3
  heap = [(3, D), (4, C)]
  distances = {A:0, B:1, C:4, D:3}

STEP 3: Pop (3, D)
  Process D
  Update C: 3 + 3 = 6 > 4 -> No update (current path better)
  heap = [(4, C)]
  distances = {A:0, B:1, C:4, D:3}

STEP 4: Pop (4, C)
  Process C
  No outgoing edges
  heap = []

FINAL: distances = {A:0, B:1, C:4, D:3}
```

## Priority Queue (Min-Heap) States

```
Step | Pop        | Heap After           | distances
-----|------------|----------------------|------------------
  1  | (0, A)     | [(1,B), (4,C)]       | A:0, B:1, C:4, D:inf
  2  | (1, B)     | [(3,D), (4,C)]       | A:0, B:1, C:4, D:3
  3  | (3, D)     | [(4,C)]              | A:0, B:1, C:4, D:3
  4  | (4, C)     | []                   | A:0, B:1, C:4, D:3
```

## Time & Space Complexity

| With | Time | Space |
|------|------|-------|
| Binary Heap | O((V+E) log V) | O(V) |
| Fibonacci Heap | O(V log V + E) | O(V) |

## Key Points

1. **Non-negative weights only** (use Bellman-Ford for negative)
2. **Greedy**: Always process closest unvisited vertex
3. **Min-heap** for efficient minimum extraction
4. **Relaxation**: Update distance if shorter path found
5. Can track **parent** to reconstruct path

## When to Use

| Dijkstra | Not Dijkstra |
|----------|--------------|
| Non-negative weights | Negative weights |
| Sparse graphs | Unweighted (use BFS) |
| Single source shortest path | All pairs (use Floyd-Warshall) |
