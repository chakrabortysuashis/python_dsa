"""
Problem: Prim's Algorithm - Minimum Spanning Tree
=================================================

Find MST by growing tree from starting vertex, always adding minimum edge.

Algorithm:
1. Start from any vertex
2. Add all its edges to min-heap
3. Extract min edge, if destination unvisited, add to MST
4. Repeat until all vertices included

Time Complexity: O(E log V)
Space Complexity: O(V + E)
"""

import heapq
from collections import defaultdict
from typing import List, Tuple, Dict, Set


def prim(n: int, edges: List[Tuple[int, int, int]], start: int = 0) -> Tuple[List[Tuple[int, int, int]], int]:
    """
    Prim's Algorithm for MST using min-heap.

    Args:
        n: Number of vertices (0 to n-1)
        edges: List of (u, v, weight) tuples
        start: Starting vertex

    Returns:
        Tuple of (MST edges, total weight)

    Example:
        >>> edges = [(0,1,10), (0,2,6), (0,3,5), (1,3,15), (2,3,4)]
        >>> mst, weight = prim(4, edges)
        >>> weight
        19
    """
    # Build adjacency list
    graph = defaultdict(list)
    for u, v, w in edges:
        graph[u].append((w, v))
        graph[v].append((w, u))

    visited = set()
    mst = []
    mst_weight = 0

    # Min-heap: (weight, from_vertex, to_vertex)
    min_heap = [(0, -1, start)]

    while min_heap and len(visited) < n:
        weight, frm, to = heapq.heappop(min_heap)

        if to in visited:
            continue

        visited.add(to)

        if frm != -1:
            mst.append((frm, to, weight))
            mst_weight += weight

        for next_weight, neighbor in graph[to]:
            if neighbor not in visited:
                heapq.heappush(min_heap, (next_weight, to, neighbor))

    return mst, mst_weight


def prim_with_trace(n: int, edges: List[Tuple[int, int, int]], start: int = 0) -> Tuple[List[Tuple[int, int, int]], int]:
    """Prim's with detailed trace for learning."""
    print("\n" + "=" * 60)
    print("Prim's Algorithm - MST Trace")
    print("=" * 60)

    print(f"\nVertices: {n}")
    print(f"Edges: {edges}")
    print(f"Start vertex: {start}")

    # Build adjacency list
    graph = defaultdict(list)
    for u, v, w in edges:
        graph[u].append((w, v))
        graph[v].append((w, u))

    print(f"\nAdjacency List:")
    for v in range(n):
        print(f"  {v}: {graph[v]}")

    visited = set()
    mst = []
    mst_weight = 0
    min_heap = [(0, -1, start)]

    print(f"\nInitial heap: {min_heap}")
    print("\n--- Processing ---")

    step = 0
    while min_heap and len(visited) < n:
        step += 1
        weight, frm, to = heapq.heappop(min_heap)

        print(f"\nStep {step}: Extract ({weight}, {frm}, {to})")

        if to in visited:
            print(f"  Vertex {to} already visited -> SKIP")
            continue

        visited.add(to)
        print(f"  Vertex {to} not visited -> ADD to MST")
        print(f"  Visited: {visited}")

        if frm != -1:
            mst.append((frm, to, weight))
            mst_weight += weight
            print(f"  MST edge: ({frm}, {to}, {weight})")
            print(f"  MST weight: {mst_weight}")

        print(f"  Adding edges from vertex {to}:")
        for next_weight, neighbor in graph[to]:
            if neighbor not in visited:
                heapq.heappush(min_heap, (next_weight, to, neighbor))
                print(f"    -> ({next_weight}, {to}, {neighbor})")
            else:
                print(f"    -> ({next_weight}, {to}, {neighbor}) - {neighbor} visited, skip")

        print(f"  Heap: {sorted(min_heap)}")

    print(f"\n{'=' * 60}")
    print("RESULT")
    print(f"{'=' * 60}")
    print(f"MST Edges: {mst}")
    print(f"MST Weight: {mst_weight}")

    return mst, mst_weight


def prim_matrix(adj_matrix: List[List[int]]) -> Tuple[int, List[int]]:
    """
    Prim's using adjacency matrix.
    Good for dense graphs, O(V^2) time.

    Args:
        adj_matrix: n x n matrix where adj_matrix[i][j] = weight or 0

    Returns:
        Tuple of (total weight, parent array)
    """
    n = len(adj_matrix)
    INF = float('inf')

    # key[v] = minimum weight edge to connect v to MST
    key = [INF] * n
    key[0] = 0

    # parent[v] = parent of v in MST
    parent = [-1] * n

    # Track vertices in MST
    in_mst = [False] * n

    for _ in range(n):
        # Find vertex with minimum key not in MST
        min_key = INF
        u = -1
        for v in range(n):
            if not in_mst[v] and key[v] < min_key:
                min_key = key[v]
                u = v

        if u == -1:
            break

        in_mst[u] = True

        # Update keys of adjacent vertices
        for v in range(n):
            if adj_matrix[u][v] > 0 and not in_mst[v] and adj_matrix[u][v] < key[v]:
                key[v] = adj_matrix[u][v]
                parent[v] = u

    return sum(key), parent


def prim_eager(n: int, edges: List[Tuple[int, int, int]], start: int = 0) -> Tuple[List[Tuple[int, int, int]], int]:
    """
    Eager Prim's using indexed priority queue.
    Updates existing entries instead of lazy deletion.
    More efficient for very dense graphs.
    """
    graph = defaultdict(list)
    for u, v, w in edges:
        graph[u].append((w, v))
        graph[v].append((w, u))

    visited = set()
    mst = []
    mst_weight = 0

    # best[v] = (weight, from) - best edge to reach v
    best = {v: (float('inf'), -1) for v in range(n)}
    best[start] = (0, -1)

    min_heap = [(0, start)]

    while min_heap and len(visited) < n:
        weight, u = heapq.heappop(min_heap)

        if u in visited:
            continue

        visited.add(u)
        frm = best[u][1]

        if frm != -1:
            mst.append((frm, u, weight))
            mst_weight += weight

        for next_weight, v in graph[u]:
            if v not in visited and next_weight < best[v][0]:
                best[v] = (next_weight, u)
                heapq.heappush(min_heap, (next_weight, v))

    return mst, mst_weight


def is_connected(n: int, edges: List[Tuple[int, int, int]]) -> bool:
    """Check if graph is connected (MST exists)."""
    mst, _ = prim(n, edges)
    return len(mst) == n - 1


def mst_weight_only(n: int, edges: List[Tuple[int, int, int]]) -> int:
    """Get just the MST weight."""
    _, weight = prim(n, edges)
    return weight


# =============================================================================
# Test Cases
# =============================================================================

def test_prim():
    """Test Prim's algorithm implementations."""
    print("\n" + "=" * 60)
    print("Prim's Algorithm - Test Cases")
    print("=" * 60)

    # Test 1: Basic graph
    print("\nTest 1: Basic graph")
    edges1 = [
        (0, 1, 10),
        (0, 2, 6),
        (0, 3, 5),
        (1, 3, 15),
        (2, 3, 4)
    ]

    mst, weight = prim(4, edges1)
    print(f"  MST: {mst}")
    print(f"  Weight: {weight}")
    assert weight == 19

    # Test 2: Larger graph
    print("\nTest 2: Larger graph")
    edges2 = [
        (0, 1, 4),
        (0, 7, 8),
        (1, 2, 8),
        (1, 7, 11),
        (2, 3, 7),
        (2, 5, 4),
        (2, 8, 2),
        (3, 4, 9),
        (3, 5, 14),
        (4, 5, 10),
        (5, 6, 2),
        (6, 7, 1),
        (6, 8, 6),
        (7, 8, 7)
    ]

    mst, weight = prim(9, edges2)
    print(f"  MST: {mst}")
    print(f"  Weight: {weight}")
    assert weight == 37  # Same as Kruskal's

    # Test 3: Different starting vertices
    print("\nTest 3: Different starting vertices (same MST weight)")
    for start in range(4):
        _, w = prim(4, edges1, start)
        print(f"  Start from {start}: weight = {w}")

    # Test 4: Adjacency matrix version
    print("\nTest 4: Adjacency matrix version")
    adj = [
        [0, 10, 6, 5],
        [10, 0, 0, 15],
        [6, 0, 0, 4],
        [5, 15, 4, 0]
    ]
    weight_matrix, parent = prim_matrix(adj)
    print(f"  Weight: {weight_matrix}")
    print(f"  Parent: {parent}")

    # Test 5: Eager Prim's
    print("\nTest 5: Eager Prim's")
    mst_eager, weight_eager = prim_eager(4, edges1)
    print(f"  MST: {mst_eager}")
    print(f"  Weight: {weight_eager}")

    print("\nAll tests passed!")


def test_with_trace():
    """Test with detailed trace."""
    edges = [
        (0, 1, 10),
        (0, 2, 6),
        (0, 3, 5),
        (1, 3, 15),
        (2, 3, 4)
    ]
    prim_with_trace(4, edges)


if __name__ == "__main__":
    test_prim()
    test_with_trace()
