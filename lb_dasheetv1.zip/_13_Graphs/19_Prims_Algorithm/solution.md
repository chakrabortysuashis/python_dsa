# Prim's Algorithm - Minimum Spanning Tree

## Problem Statement

Given a connected, undirected, weighted graph, find the Minimum Spanning Tree (MST) using Prim's algorithm. Start from any vertex and grow the MST by always adding the minimum weight edge that connects a vertex in the MST to a vertex outside.

## Graph Visualization

```
Input Graph:
        4
    A-------B
    |\     /|
   2| \8  / |6
    |  \ /  |
    C---D---E
      3   5

Prim's from A:
Step 1: Start with A
        MST = {A}
        Edges: A-B(4), A-C(2), A-D(8)
        Min: A-C(2) -> Add C

Step 2: MST = {A, C}
        Edges: A-B(4), A-D(8), C-D(3)
        Min: C-D(3) -> Add D

Step 3: MST = {A, C, D}
        Edges: A-B(4), D-B(?), D-E(5)
        Min: A-B(4) -> Add B

Step 4: MST = {A, C, D, B}
        Edges: D-E(5), B-E(6)
        Min: D-E(5) -> Add E

MST Complete!
Weight = 2 + 3 + 4 + 5 = 14
```

## Why Prim's Algorithm?

```
Vertex-based Greedy Approach:
+--------------------+
| Start from any     |
| vertex             |
+--------------------+
         |
         v
+--------------------+
| Grow MST by adding |
| minimum edge to    |
| unvisited vertex   |
+--------------------+
         |
         v
+--------------------+
| Use Priority Queue |
| for efficient min  |
| edge selection     |
+--------------------+
```

## Algorithm

```
Prim's MST:
1. Initialize:
   - Pick starting vertex
   - Mark it as visited
   - Add all its edges to min-heap

2. While MST doesn't include all vertices:
   a. Extract minimum weight edge from heap
   b. If destination not visited:
      - Add edge to MST
      - Mark destination visited
      - Add all edges from destination to heap

3. Return MST edges
```

## Step-by-Step Dry Run

### Graph:
```
Vertices: {0, 1, 2, 3}
Edges: (0,1,10), (0,2,6), (0,3,5), (1,3,15), (2,3,4)
```

### Execution (Starting from vertex 0):

```
INITIALIZATION:
Visited: {0}
MST edges: []
MST weight: 0
Min-Heap: [(5, 0, 3), (6, 0, 2), (10, 0, 1)]
          (weight, from, to)

STEP 1: Extract min (5, 0, 3)
  Vertex 3 not visited -> ADD
  Visited: {0, 3}
  MST: [(0, 3, 5)]
  Weight: 5
  Add edges from 3:
    (1, 3, 15) -> 1 not visited, add to heap
    (2, 3, 4) -> 2 not visited, add to heap
  Heap: [(4, 3, 2), (6, 0, 2), (10, 0, 1), (15, 3, 1)]

STEP 2: Extract min (4, 3, 2)
  Vertex 2 not visited -> ADD
  Visited: {0, 3, 2}
  MST: [(0, 3, 5), (3, 2, 4)]
  Weight: 9
  Add edges from 2:
    (0, 2, 6) -> 0 visited, skip
    (3, 2, 4) -> 3 visited, skip
  Heap: [(6, 0, 2), (10, 0, 1), (15, 3, 1)]

STEP 3: Extract min (6, 0, 2)
  Vertex 2 already visited -> SKIP
  Heap: [(10, 0, 1), (15, 3, 1)]

STEP 4: Extract min (10, 0, 1)
  Vertex 1 not visited -> ADD
  Visited: {0, 3, 2, 1}
  MST: [(0, 3, 5), (3, 2, 4), (0, 1, 10)]
  Weight: 19

All vertices visited! MST Complete.

RESULT:
MST Edges: [(0,3,5), (3,2,4), (0,1,10)]
MST Weight: 19
```

## Priority Queue State

```
Step | Extract        | Action | Heap After
-----|----------------|--------|---------------------------
  0  | -              | Init   | [(5,0,3), (6,0,2), (10,0,1)]
  1  | (5,0,3)        | ADD    | [(4,3,2), (6,0,2), (10,0,1), (15,3,1)]
  2  | (4,3,2)        | ADD    | [(6,0,2), (10,0,1), (15,3,1)]
  3  | (6,0,2)        | SKIP   | [(10,0,1), (15,3,1)]
  4  | (10,0,1)       | ADD    | [(15,3,1)]
```

## Code Template

```python
import heapq
from collections import defaultdict

def prim(n, edges, start=0):
    """
    n: number of vertices
    edges: list of (u, v, weight)
    start: starting vertex
    """
    # Build adjacency list
    graph = defaultdict(list)
    for u, v, w in edges:
        graph[u].append((w, v))
        graph[v].append((w, u))
    
    visited = set()
    mst = []
    mst_weight = 0
    
    # Min-heap: (weight, from_vertex, to_vertex)
    min_heap = [(0, -1, start)]  # Start with weight 0 to start vertex
    
    while min_heap and len(visited) < n:
        weight, frm, to = heapq.heappop(min_heap)
        
        if to in visited:
            continue
        
        visited.add(to)
        
        if frm != -1:  # Not the starting vertex
            mst.append((frm, to, weight))
            mst_weight += weight
        
        # Add edges to unvisited neighbors
        for next_weight, neighbor in graph[to]:
            if neighbor not in visited:
                heapq.heappush(min_heap, (next_weight, to, neighbor))
    
    return mst, mst_weight
```

## Time & Space Complexity

| Metric | Complexity | Explanation |
|--------|------------|-------------|
| Time | O(E log V) | Each edge pushed/popped once |
| Space | O(V + E) | Adjacency list + heap |

### With Different Implementations:
```
Binary Heap:     O(E log V)
Fibonacci Heap:  O(E + V log V)  - Better for dense graphs
Adjacency Matrix: O(V^2)         - Simple but slower
```

## Prim's vs Kruskal's

| Aspect | Prim's | Kruskal's |
|--------|--------|-----------|
| Approach | Vertex-based (grow MST) | Edge-based (merge forests) |
| Data Structure | Priority Queue | Union-Find |
| Best for | Dense graphs | Sparse graphs |
| Starting Point | Needs start vertex | No start vertex |
| Time | O(E log V) | O(E log E) |

## Key Points

1. **Greedy**: Always add minimum edge to MST
2. **Priority Queue**: Efficient minimum edge selection
3. **Visited set**: Prevents cycles
4. **Any starting vertex**: Result is same MST (for connected graph)
5. **Lazy deletion**: Skip edges to visited vertices

## Variations

### 1. Track Parent for Path
```python
parent = {start: None}
# In loop: parent[to] = frm
```

### 2. Dense Graph (Adjacency Matrix)
```python
def prim_matrix(adj_matrix):
    n = len(adj_matrix)
    key = [float('inf')] * n
    key[0] = 0
    in_mst = [False] * n
    
    for _ in range(n):
        # Find min key vertex not in MST
        u = min((k, i) for i, k in enumerate(key) if not in_mst[i])[1]
        in_mst[u] = True
        
        for v in range(n):
            if adj_matrix[u][v] and not in_mst[v] and adj_matrix[u][v] < key[v]:
                key[v] = adj_matrix[u][v]
    
    return sum(key)
```

### 3. Return MST as Adjacency List
```python
mst_adj = defaultdict(list)
for u, v, w in mst:
    mst_adj[u].append((v, w))
    mst_adj[v].append((u, w))
```
