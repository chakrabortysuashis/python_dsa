# Detect Cycle in Undirected Graph

## Problem Statement

Given an undirected graph, detect if it contains a cycle.

## Key Difference from Directed Graph

In undirected graphs, edge (u,v) means both u->v AND v->u exist. So when we visit neighbor from current vertex, we need to **ignore the parent** to avoid false positives.

## Graph Visualization

### Graph WITH Cycle:
```
    0 --- 1
    |     |
    2 --- 3

Edges: (0,1), (0,2), (1,3), (2,3)
Cycle: 0 -> 1 -> 3 -> 2 -> 0
```

### Graph WITHOUT Cycle (Tree):
```
    0 --- 1 --- 3
    |
    2

Edges: (0,1), (0,2), (1,3)
No cycle - this is a tree
```

## Approach: DFS with Parent Tracking

```
For undirected graph:
- If we visit a neighbor that is visited AND not our parent
- That's a cycle!

Why parent check?
- Edge (0,1) means 0->1 and 1->0
- When at 1, seeing 0 as visited is expected (it's parent)
- Only cycle if we see a visited vertex that's NOT our parent
```

## Algorithm

```python
def has_cycle_dfs(vertex, parent, visited, graph):
    visited.add(vertex)
    
    for neighbor in graph[vertex]:
        if neighbor not in visited:
            if has_cycle_dfs(neighbor, vertex, visited, graph):
                return True
        elif neighbor != parent:  # Key check!
            return True  # Cycle found
    
    return False
```

## Step-by-Step Dry Run

### Graph with Cycle:
```
0: [1, 2]
1: [0, 3]
2: [0, 3]
3: [1, 2]
```

### DFS from vertex 0:

```
STEP 1: Visit 0 (parent = -1)
        visited = {0}
        Neighbors: [1, 2]
        
STEP 2: Visit 1 (parent = 0)
        visited = {0, 1}
        Neighbors: [0, 3]
        - 0 is visited but is parent, skip
        - 3 not visited, recurse

STEP 3: Visit 3 (parent = 1)
        visited = {0, 1, 3}
        Neighbors: [1, 2]
        - 1 is visited but is parent, skip
        - 2 not visited, recurse

STEP 4: Visit 2 (parent = 3)
        visited = {0, 1, 3, 2}
        Neighbors: [0, 3]
        - 0 is visited AND NOT parent (parent is 3)
        - CYCLE FOUND!
        
Cycle: 0 -> 1 -> 3 -> 2 -> 0
```

## BFS Approach

Can also use BFS with parent tracking:

```python
def has_cycle_bfs(start, visited, graph):
    queue = deque([(start, -1)])  # (vertex, parent)
    visited.add(start)
    
    while queue:
        vertex, parent = queue.popleft()
        
        for neighbor in graph[vertex]:
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append((neighbor, vertex))
            elif neighbor != parent:
                return True  # Cycle!
    
    return False
```

## Union-Find Approach

Elegant alternative using Union-Find:

```python
def has_cycle_union_find(edges, n):
    parent = list(range(n))
    
    def find(x):
        if parent[x] != x:
            parent[x] = find(parent[x])
        return parent[x]
    
    for u, v in edges:
        pu, pv = find(u), find(v)
        if pu == pv:
            return True  # Same component = cycle!
        parent[pu] = pv  # Union
    
    return False
```

## Time & Space Complexity

| Approach | Time | Space |
|----------|------|-------|
| DFS | O(V + E) | O(V) |
| BFS | O(V + E) | O(V) |
| Union-Find | O(E * alpha(V)) | O(V) |

## Key Points

1. **Parent tracking** is essential for undirected graphs
2. Don't confuse parent edge with back edge
3. Handle **disconnected graphs** by checking all components
4. Union-Find is elegant but DFS/BFS are more intuitive

## Common Mistakes

1. Not tracking parent - causes false positive on every edge
2. Not handling disconnected graphs
3. Using directed graph approach (rec_stack not needed here)
