"""
Problem: Detect Cycle in Undirected Graph
=========================================

Key difference from directed graph:
- Edge (u,v) means both u->v and v->u exist
- Must track PARENT to avoid false positive on the same edge

Approaches:
1. DFS with parent tracking
2. BFS with parent tracking
3. Union-Find

Time: O(V + E)
Space: O(V)
"""

from collections import deque, defaultdict
from typing import List, Dict, Set


def detect_cycle_dfs(graph: Dict[int, List[int]]) -> bool:
    """
    Detect cycle using DFS with parent tracking.
    """
    visited = set()

    def dfs(vertex: int, parent: int) -> bool:
        visited.add(vertex)

        for neighbor in graph[vertex]:
            if neighbor not in visited:
                if dfs(neighbor, vertex):
                    return True
            elif neighbor != parent:
                # Visited vertex that's not parent = cycle!
                return True

        return False

    # Check all components (graph might be disconnected)
    for vertex in graph:
        if vertex not in visited:
            if dfs(vertex, -1):
                return True

    return False


def detect_cycle_dfs_trace(graph: Dict[int, List[int]]) -> bool:
    """DFS with detailed trace."""
    visited = set()

    print("\n" + "=" * 50)
    print("Cycle Detection - Undirected Graph (DFS)")
    print("=" * 50)

    def dfs(vertex: int, parent: int, depth: int = 0) -> bool:
        indent = "  " * depth
        visited.add(vertex)
        print(f"{indent}Visit {vertex} (parent: {parent})")

        for neighbor in graph[vertex]:
            print(f"{indent}  Check neighbor {neighbor}")

            if neighbor not in visited:
                print(f"{indent}    Not visited, recurse")
                if dfs(neighbor, vertex, depth + 1):
                    return True
            elif neighbor != parent:
                print(f"{indent}    CYCLE! {neighbor} visited and not parent")
                return True
            else:
                print(f"{indent}    Is parent, skip")

        return False

    for vertex in graph:
        if vertex not in visited:
            if dfs(vertex, -1):
                print("\nResult: CYCLE FOUND")
                return True

    print("\nResult: No cycle (Graph is a tree/forest)")
    return False


def detect_cycle_bfs(graph: Dict[int, List[int]]) -> bool:
    """
    Detect cycle using BFS with parent tracking.
    """
    visited = set()

    def bfs(start: int) -> bool:
        queue = deque([(start, -1)])  # (vertex, parent)
        visited.add(start)

        while queue:
            vertex, parent = queue.popleft()

            for neighbor in graph[vertex]:
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append((neighbor, vertex))
                elif neighbor != parent:
                    return True  # Cycle found

        return False

    for vertex in graph:
        if vertex not in visited:
            if bfs(vertex):
                return True

    return False


class UnionFind:
    """Union-Find data structure for cycle detection."""

    def __init__(self, n: int):
        self.parent = list(range(n))
        self.rank = [0] * n

    def find(self, x: int) -> int:
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])
        return self.parent[x]

    def union(self, x: int, y: int) -> bool:
        """Returns False if x and y already in same set (cycle!)."""
        px, py = self.find(x), self.find(y)

        if px == py:
            return False  # Same component = cycle!

        # Union by rank
        if self.rank[px] < self.rank[py]:
            px, py = py, px
        self.parent[py] = px
        if self.rank[px] == self.rank[py]:
            self.rank[px] += 1

        return True


def detect_cycle_union_find(n: int, edges: List[tuple]) -> bool:
    """
    Detect cycle using Union-Find.

    For each edge (u, v):
    - If u and v already in same component -> cycle!
    - Otherwise, union them
    """
    uf = UnionFind(n)

    for u, v in edges:
        if not uf.union(u, v):
            return True  # Cycle found

    return False


# =============================================================================
# Test Cases
# =============================================================================

def test_cycle_exists():
    """Graph with cycle."""
    print("\n" + "=" * 50)
    print("TEST: Graph WITH Cycle")
    print("=" * 50)

    # 0 --- 1
    # |     |
    # 2 --- 3
    graph = {
        0: [1, 2],
        1: [0, 3],
        2: [0, 3],
        3: [1, 2]
    }

    print("\nGraph:")
    print("  0 --- 1")
    print("  |     |")
    print("  2 --- 3")

    print(f"\nDFS result: {detect_cycle_dfs_trace(graph)}")
    print(f"BFS result: {detect_cycle_bfs(graph)}")

    # Union-Find
    edges = [(0, 1), (0, 2), (1, 3), (2, 3)]
    print(f"Union-Find result: {detect_cycle_union_find(4, edges)}")


def test_tree():
    """Tree (no cycle)."""
    print("\n" + "=" * 50)
    print("TEST: Tree (No Cycle)")
    print("=" * 50)

    # 0 --- 1 --- 3
    # |
    # 2
    graph = {
        0: [1, 2],
        1: [0, 3],
        2: [0],
        3: [1]
    }

    print("\nGraph (Tree):")
    print("  0 --- 1 --- 3")
    print("  |")
    print("  2")

    print(f"\nDFS result: {detect_cycle_dfs_trace(graph)}")
    print(f"BFS result: {detect_cycle_bfs(graph)}")


def test_disconnected():
    """Disconnected graph with cycle in one component."""
    print("\n" + "=" * 50)
    print("TEST: Disconnected Graph")
    print("=" * 50)

    graph = {
        0: [1],
        1: [0],
        # Disconnected component with cycle
        2: [3, 4],
        3: [2, 4],
        4: [2, 3]
    }

    print("\nDisconnected graph:")
    print("  Component 1: 0 --- 1 (no cycle)")
    print("  Component 2: 2-3-4 triangle (cycle!)")

    print(f"\nResult: {detect_cycle_dfs(graph)}")


if __name__ == "__main__":
    test_cycle_exists()
    test_tree()
    test_disconnected()
