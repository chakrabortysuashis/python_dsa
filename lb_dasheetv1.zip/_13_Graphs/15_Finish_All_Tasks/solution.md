# Find if Possible to Finish All Tasks

## Problem Statement

There are `numCourses` courses labeled from 0 to numCourses-1. Given prerequisites where prerequisites[i] = [a, b] means you must take course b before course a.

Determine if you can finish all courses (i.e., no circular dependency exists).

## Key Insight

This is **cycle detection in a directed graph**!
- If the dependency graph has a cycle, impossible to finish
- If it's a DAG (no cycle), possible to finish

## Example

```
Possible:
numCourses = 4
prerequisites = [[1,0], [2,0], [3,1], [3,2]]

Graph:
    0 --> 1 --> 3
    |           ^
    v           |
    2 ----------+

No cycle -> Return True

Impossible:
numCourses = 2
prerequisites = [[0,1], [1,0]]

Graph:
    0 <--> 1 (cycle!)

Cycle exists -> Return False
```

## Two Approaches

### 1. DFS with Recursion Stack
```python
def can_finish_dfs(num_courses, prerequisites):
    graph = defaultdict(list)
    for a, b in prerequisites:
        graph[b].append(a)  # b -> a
    
    visited = set()
    rec_stack = set()
    
    def has_cycle(node):
        visited.add(node)
        rec_stack.add(node)
        
        for neighbor in graph[node]:
            if neighbor not in visited:
                if has_cycle(neighbor):
                    return True
            elif neighbor in rec_stack:
                return True
        
        rec_stack.remove(node)
        return False
    
    for i in range(num_courses):
        if i not in visited:
            if has_cycle(i):
                return False
    
    return True
```

### 2. BFS (Kahn's Algorithm)
```python
def can_finish_bfs(num_courses, prerequisites):
    graph = defaultdict(list)
    in_degree = [0] * num_courses
    
    for a, b in prerequisites:
        graph[b].append(a)
        in_degree[a] += 1
    
    queue = deque([i for i in range(num_courses) if in_degree[i] == 0])
    processed = 0
    
    while queue:
        node = queue.popleft()
        processed += 1
        
        for neighbor in graph[node]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)
    
    return processed == num_courses
```

## Dry Run (BFS Approach)

```
numCourses = 4
prerequisites = [[1,0], [2,0], [3,1], [3,2]]

Graph: 0->[1,2], 1->[3], 2->[3]
in_degree = [0, 1, 1, 2]

Step 1: Queue = [0] (in_degree=0)
        Process 0, decrement in_degree[1], in_degree[2]
        in_degree = [0, 0, 0, 2]
        Queue = [1, 2]
        processed = 1

Step 2: Process 1, decrement in_degree[3]
        in_degree = [0, 0, 0, 1]
        Queue = [2]
        processed = 2

Step 3: Process 2, decrement in_degree[3]
        in_degree = [0, 0, 0, 0]
        Queue = [3]
        processed = 3

Step 4: Process 3
        Queue = []
        processed = 4

4 == numCourses -> Return True
```

## Time & Space Complexity

| Approach | Time | Space |
|----------|------|-------|
| DFS | O(V + E) | O(V) |
| BFS (Kahn) | O(V + E) | O(V) |

## Key Points

1. **Build correct graph direction**: If [a, b] means "take b before a", then edge is b -> a
2. **BFS approach**: If can't process all nodes, cycle exists
3. **DFS approach**: Check if back edge exists using recursion stack
4. This is same as **Course Schedule** problem on LeetCode
