# Count Spanning Trees (Kirchhoff's Theorem)

## Problem Statement

Given a connected, undirected graph, count the total number of spanning trees. A spanning tree is a subgraph that includes all vertices connected with minimum possible edges (V-1 edges) without any cycles.

## Graph Visualization

```
Example Graph:
    1 --- 2
    |   / |
    | /   |
    3 --- 4

This graph has multiple spanning trees:

Tree 1:     Tree 2:     Tree 3:     Tree 4:
1---2       1---2       1   2       1   2
|           |   |       |\ /|       |   |
3   4       3   4       | X |       |   |
    |               3   4   3---4

... and more!

Total spanning trees = 8
```

## Kirchhoff's Theorem (Matrix-Tree Theorem)

```
The number of spanning trees = any cofactor of the Laplacian matrix

Laplacian Matrix L = D - A
where:
  D = Degree matrix (diagonal matrix of vertex degrees)
  A = Adjacency matrix

Steps:
1. Build Laplacian matrix L
2. Remove any one row and column (say, last)
3. Calculate determinant of resulting matrix
4. |det| = number of spanning trees
```

## Step-by-Step Example

### Graph:
```
    0 --- 1
    |   / |
    | /   |
    2 --- 3
```

### Step 1: Build Adjacency Matrix A
```
    0  1  2  3
0 [ 0  1  1  0 ]
1 [ 1  0  1  1 ]
2 [ 1  1  0  1 ]
3 [ 0  1  1  0 ]
```

### Step 2: Build Degree Matrix D
```
Degree of each vertex:
  0: 2 (connected to 1, 2)
  1: 3 (connected to 0, 2, 3)
  2: 3 (connected to 0, 1, 3)
  3: 2 (connected to 1, 2)

    0  1  2  3
0 [ 2  0  0  0 ]
1 [ 0  3  0  0 ]
2 [ 0  0  3  0 ]
3 [ 0  0  0  2 ]
```

### Step 3: Laplacian L = D - A
```
    0  1  2  3
0 [ 2 -1 -1  0 ]
1 [-1  3 -1 -1 ]
2 [-1 -1  3 -1 ]
3 [ 0 -1 -1  2 ]
```

### Step 4: Remove last row and column
```
Minor matrix (remove row 3, col 3):
    0  1  2
0 [ 2 -1 -1 ]
1 [-1  3 -1 ]
2 [-1 -1  3 ]
```

### Step 5: Calculate Determinant
```
det = 2*(3*3 - (-1)*(-1)) - (-1)*(-1*3 - (-1)*(-1)) + (-1)*(-1*(-1) - 3*(-1))
    = 2*(9-1) - (-1)*(-3-1) + (-1)*(1+3)
    = 2*8 - (-1)*(-4) + (-1)*4
    = 16 - 4 - 4
    = 8

Number of spanning trees = 8
```

## Algorithm

```
countSpanningTrees(graph):
    1. n = number of vertices
    2. Build Laplacian matrix L (n x n)
       - L[i][i] = degree of vertex i
       - L[i][j] = -1 if edge exists between i and j
       - L[i][j] = 0 otherwise
    3. Create minor by removing last row and column
    4. Return abs(determinant(minor))
```

## Code Template

```python
import numpy as np

def count_spanning_trees(n, edges):
    """
    Count spanning trees using Kirchhoff's theorem.
    
    Args:
        n: number of vertices
        edges: list of (u, v) edges
    
    Returns:
        Number of spanning trees
    """
    # Build Laplacian matrix
    laplacian = [[0] * n for _ in range(n)]
    
    for u, v in edges:
        # Increase degree
        laplacian[u][u] += 1
        laplacian[v][v] += 1
        # Add -1 for edge
        laplacian[u][v] -= 1
        laplacian[v][u] -= 1
    
    # Remove last row and column
    minor = [row[:-1] for row in laplacian[:-1]]
    
    # Calculate determinant
    det = np.linalg.det(minor)
    
    return round(abs(det))
```

## Special Cases

### Complete Graph K_n
```
Number of spanning trees = n^(n-2)

Examples:
  K_3 (triangle): 3^1 = 3 trees
  K_4 (complete 4): 4^2 = 16 trees
  K_5: 5^3 = 125 trees

This is Cayley's formula!
```

### Cycle Graph C_n
```
Number of spanning trees = n

A cycle has exactly n spanning trees,
each formed by removing one edge.
```

### Tree
```
Number of spanning trees = 1

A tree itself is its only spanning tree.
```

## Time & Space Complexity

| Metric | Complexity | Explanation |
|--------|------------|-------------|
| Time | O(V^3) | Determinant calculation |
| Space | O(V^2) | Laplacian matrix storage |

## Dry Run: Triangle Graph

```
Graph: 0---1---2---0 (triangle)

Adjacency:
    0  1  2
0 [ 0  1  1 ]
1 [ 1  0  1 ]
2 [ 1  1  0 ]

Degrees: 0:2, 1:2, 2:2

Laplacian L = D - A:
    0  1  2
0 [ 2 -1 -1 ]
1 [-1  2 -1 ]
2 [-1 -1  2 ]

Minor (remove row 2, col 2):
    0  1
0 [ 2 -1 ]
1 [-1  2 ]

det = 2*2 - (-1)*(-1) = 4 - 1 = 3

Spanning trees = 3 (remove any one edge from triangle)
```

## Key Points

1. **Laplacian = Degree - Adjacency**
2. **Any cofactor works**: Remove any row i and column i
3. **Result is always integer**: Represents count
4. **Works for multigraphs**: Multiple edges increase matrix values
5. **Weighted version**: Use weights instead of -1

## Applications

1. Network reliability analysis
2. Random spanning tree generation
3. Graph connectivity measures
4. Electrical network analysis (resistance)
