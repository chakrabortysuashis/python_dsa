"""
Problem: Count Spanning Trees (Kirchhoff's Theorem)
===================================================

Count the total number of spanning trees in a graph using the Matrix-Tree Theorem.

Algorithm:
1. Build Laplacian matrix L = D - A
2. Remove any row and column
3. Calculate determinant = number of spanning trees

Time Complexity: O(V^3) for determinant
Space Complexity: O(V^2) for matrix
"""

from typing import List, Tuple
from fractions import Fraction


def count_spanning_trees(n: int, edges: List[Tuple[int, int]]) -> int:
    """
    Count spanning trees using Kirchhoff's theorem.

    Args:
        n: Number of vertices (0 to n-1)
        edges: List of (u, v) undirected edges

    Returns:
        Number of spanning trees

    Example:
        >>> edges = [(0,1), (0,2), (1,2), (1,3), (2,3)]
        >>> count_spanning_trees(4, edges)
        8
    """
    # Build Laplacian matrix
    laplacian = [[0] * n for _ in range(n)]

    for u, v in edges:
        # Diagonal: degree
        laplacian[u][u] += 1
        laplacian[v][v] += 1
        # Off-diagonal: -1 for each edge
        laplacian[u][v] -= 1
        laplacian[v][u] -= 1

    # Remove last row and column to get minor
    minor = [row[:-1] for row in laplacian[:-1]]

    # Calculate determinant
    det = determinant(minor)

    return round(abs(det))


def determinant(matrix: List[List[float]]) -> float:
    """
    Calculate determinant using Gaussian elimination.
    Uses Fraction for exact computation.
    """
    n = len(matrix)
    if n == 0:
        return 1
    if n == 1:
        return matrix[0][0]

    # Convert to Fraction for exact arithmetic
    mat = [[Fraction(matrix[i][j]) for j in range(n)] for i in range(n)]

    det = Fraction(1)

    for col in range(n):
        # Find pivot
        pivot_row = None
        for row in range(col, n):
            if mat[row][col] != 0:
                pivot_row = row
                break

        if pivot_row is None:
            return 0  # Singular matrix

        # Swap rows if needed
        if pivot_row != col:
            mat[col], mat[pivot_row] = mat[pivot_row], mat[col]
            det *= -1  # Sign change for row swap

        det *= mat[col][col]

        # Eliminate below
        for row in range(col + 1, n):
            if mat[row][col] != 0:
                factor = mat[row][col] / mat[col][col]
                for j in range(col, n):
                    mat[row][j] -= factor * mat[col][j]

    return float(det)


def count_spanning_trees_with_trace(n: int, edges: List[Tuple[int, int]]) -> int:
    """Count with detailed trace."""
    print("\n" + "=" * 60)
    print("Count Spanning Trees - Kirchhoff's Theorem")
    print("=" * 60)

    print(f"\nVertices: {n}")
    print(f"Edges: {edges}")

    # Build adjacency matrix
    adj = [[0] * n for _ in range(n)]
    for u, v in edges:
        adj[u][v] = 1
        adj[v][u] = 1

    print("\nAdjacency Matrix A:")
    for row in adj:
        print("  " + " ".join(f"{x:2}" for x in row))

    # Build degree matrix
    degree = [[0] * n for _ in range(n)]
    for i in range(n):
        degree[i][i] = sum(adj[i])

    print("\nDegree Matrix D:")
    for row in degree:
        print("  " + " ".join(f"{x:2}" for x in row))

    # Laplacian
    laplacian = [[degree[i][j] - adj[i][j] for j in range(n)] for i in range(n)]

    print("\nLaplacian Matrix L = D - A:")
    for row in laplacian:
        print("  " + " ".join(f"{x:2}" for x in row))

    # Minor
    minor = [row[:-1] for row in laplacian[:-1]]

    print(f"\nMinor (remove row {n-1}, col {n-1}):")
    for row in minor:
        print("  " + " ".join(f"{x:2}" for x in row))

    # Determinant
    det = determinant(minor)

    print(f"\nDeterminant = {det}")
    print(f"\nNumber of Spanning Trees = {round(abs(det))}")

    return round(abs(det))


def cayley_formula(n: int) -> int:
    """
    Count spanning trees in complete graph K_n.
    Uses Cayley's formula: n^(n-2)
    """
    if n <= 1:
        return 1
    return n ** (n - 2)


def cycle_spanning_trees(n: int) -> int:
    """
    Count spanning trees in cycle graph C_n.
    A cycle has exactly n spanning trees.
    """
    return n


def enumerate_spanning_trees(n: int, edges: List[Tuple[int, int]]) -> List[List[Tuple[int, int]]]:
    """
    Actually enumerate all spanning trees (for small graphs).
    Uses backtracking to find all subsets of V-1 edges that form a tree.
    """
    from itertools import combinations

    def is_tree(selected_edges: List[Tuple[int, int]]) -> bool:
        """Check if selected edges form a spanning tree."""
        if len(selected_edges) != n - 1:
            return False

        # Build adjacency list
        adj = {i: [] for i in range(n)}
        for u, v in selected_edges:
            adj[u].append(v)
            adj[v].append(u)

        # BFS to check connectivity
        visited = set()
        queue = [0]
        visited.add(0)

        while queue:
            node = queue.pop(0)
            for neighbor in adj[node]:
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(neighbor)

        return len(visited) == n

    spanning_trees = []

    for selected in combinations(edges, n - 1):
        if is_tree(list(selected)):
            spanning_trees.append(list(selected))

    return spanning_trees


# =============================================================================
# Test Cases
# =============================================================================

def test_count_spanning_trees():
    """Test spanning tree counting."""
    print("\n" + "=" * 60)
    print("Count Spanning Trees - Test Cases")
    print("=" * 60)

    # Test 1: Square with diagonal
    print("\nTest 1: Square with one diagonal")
    edges1 = [(0, 1), (0, 2), (1, 2), (1, 3), (2, 3)]
    count1 = count_spanning_trees(4, edges1)
    print(f"  Edges: {edges1}")
    print(f"  Spanning trees: {count1}")

    # Enumerate to verify
    trees1 = enumerate_spanning_trees(4, edges1)
    print(f"  Enumerated: {len(trees1)}")
    assert count1 == len(trees1)

    # Test 2: Triangle
    print("\nTest 2: Triangle (K3)")
    edges2 = [(0, 1), (1, 2), (0, 2)]
    count2 = count_spanning_trees(3, edges2)
    print(f"  Spanning trees: {count2}")
    assert count2 == 3  # Remove any one edge

    # Test 3: Complete K4
    print("\nTest 3: Complete graph K4")
    edges3 = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]
    count3 = count_spanning_trees(4, edges3)
    print(f"  Spanning trees: {count3}")
    print(f"  Cayley formula: {cayley_formula(4)}")
    assert count3 == 16  # 4^2

    # Test 4: Tree (already a spanning tree)
    print("\nTest 4: Tree (path graph)")
    edges4 = [(0, 1), (1, 2), (2, 3)]
    count4 = count_spanning_trees(4, edges4)
    print(f"  Spanning trees: {count4}")
    assert count4 == 1

    # Test 5: Cycle
    print("\nTest 5: Cycle graph C4")
    edges5 = [(0, 1), (1, 2), (2, 3), (3, 0)]
    count5 = count_spanning_trees(4, edges5)
    print(f"  Spanning trees: {count5}")
    assert count5 == 4

    print("\nAll tests passed!")


def test_with_trace():
    """Test with detailed trace."""
    edges = [(0, 1), (0, 2), (1, 2), (1, 3), (2, 3)]
    count_spanning_trees_with_trace(4, edges)


def test_enumerate():
    """Show all spanning trees for small graph."""
    print("\n" + "=" * 60)
    print("Enumerating All Spanning Trees")
    print("=" * 60)

    edges = [(0, 1), (1, 2), (0, 2)]  # Triangle
    trees = enumerate_spanning_trees(3, edges)

    print(f"\nTriangle graph: {edges}")
    print(f"All {len(trees)} spanning trees:")
    for i, tree in enumerate(trees, 1):
        print(f"  Tree {i}: {tree}")


if __name__ == "__main__":
    test_count_spanning_trees()
    test_with_trace()
    test_enumerate()
