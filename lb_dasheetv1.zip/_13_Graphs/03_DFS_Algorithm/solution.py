"""
Problem: Implement DFS Algorithm
================================

Implement Depth-First Search to traverse a graph depth-first.

Two approaches:
1. Recursive - Uses call stack implicitly
2. Iterative - Uses explicit stack

Time Complexity: O(V + E)
Space Complexity: O(V)
"""

from collections import defaultdict
from typing import List, Dict, Set, Optional


def dfs_recursive(graph: Dict[int, List[int]], start: int) -> List[int]:
    """
    DFS using recursion (implicit stack).

    The call stack acts as our stack data structure.

    Args:
        graph: Adjacency list representation
        start: Starting vertex

    Returns:
        List of vertices in DFS order
    """
    visited = set()
    result = []

    def dfs_helper(vertex: int) -> None:
        # Mark current vertex as visited
        visited.add(vertex)
        result.append(vertex)

        # Recursively visit all unvisited neighbors
        for neighbor in graph[vertex]:
            if neighbor not in visited:
                dfs_helper(neighbor)

    dfs_helper(start)
    return result


def dfs_iterative(graph: Dict[int, List[int]], start: int) -> List[int]:
    """
    DFS using explicit stack (iterative).

    Args:
        graph: Adjacency list representation
        start: Starting vertex

    Returns:
        List of vertices in DFS order
    """
    if start not in graph:
        return []

    visited = set()
    stack = [start]
    result = []

    while stack:
        # Pop from top of stack (LIFO)
        vertex = stack.pop()

        # Skip if already visited
        if vertex in visited:
            continue

        # Mark as visited and process
        visited.add(vertex)
        result.append(vertex)

        # Push unvisited neighbors to stack
        # Reverse to maintain same order as recursive
        for neighbor in reversed(graph[vertex]):
            if neighbor not in visited:
                stack.append(neighbor)

    return result


def dfs_with_trace(graph: Dict[int, List[int]], start: int) -> List[int]:
    """
    DFS with detailed step-by-step trace showing stack states.
    """
    if start not in graph:
        return []

    visited = set()
    stack = [start]
    result = []

    print("\n" + "=" * 60)
    print(f"DFS Traversal from vertex {start}")
    print("=" * 60)
    print(f"\nInitialization:")
    print(f"  Stack: {stack}")
    print(f"  Visited: {visited}")

    step = 1
    while stack:
        print(f"\n{'─' * 40}")
        print(f"Step {step}:")
        print(f"  Stack (before pop): {stack}")

        vertex = stack.pop()
        print(f"  Pop: {vertex}")

        if vertex in visited:
            print(f"  {vertex} already visited - SKIP")
            continue

        visited.add(vertex)
        result.append(vertex)
        print(f"  Visit: {vertex}")
        print(f"  Result so far: {result}")

        # Process neighbors
        neighbors = graph[vertex]
        print(f"  Neighbors of {vertex}: {neighbors}")

        pushed = []
        for neighbor in reversed(neighbors):
            if neighbor not in visited:
                stack.append(neighbor)
                pushed.append(neighbor)
                print(f"    - Push {neighbor} to stack")
            else:
                print(f"    - {neighbor} already visited, skip")

        print(f"  Stack (after): {stack}")
        step += 1

    print(f"\n{'=' * 60}")
    print(f"DFS Complete!")
    print(f"Traversal order: {' -> '.join(map(str, result))}")
    print("=" * 60 + "\n")

    return result


def dfs_recursive_with_trace(graph: Dict[int, List[int]], start: int) -> List[int]:
    """
    Recursive DFS with detailed trace showing recursion depth.
    """
    visited = set()
    result = []

    print("\n" + "=" * 60)
    print(f"DFS Recursive Traversal from vertex {start}")
    print("=" * 60)

    def dfs_helper(vertex: int, depth: int = 0) -> None:
        indent = "  " * depth
        print(f"{indent}DFS({vertex}):")
        print(f"{indent}  Visit {vertex}")

        visited.add(vertex)
        result.append(vertex)

        for neighbor in graph[vertex]:
            if neighbor not in visited:
                print(f"{indent}  -> Recurse into neighbor {neighbor}")
                dfs_helper(neighbor, depth + 1)
                print(f"{indent}  <- Backtrack from {neighbor}")
            else:
                print(f"{indent}  -> {neighbor} already visited, skip")

    dfs_helper(start)

    print(f"\n{'=' * 60}")
    print(f"DFS Complete!")
    print(f"Traversal order: {' -> '.join(map(str, result))}")
    print("=" * 60 + "\n")

    return result


def dfs_path_to_target(
    graph: Dict[int, List[int]],
    start: int,
    target: int
) -> Optional[List[int]]:
    """
    Find a path from start to target using DFS.

    Note: This finds A path, not necessarily the shortest path.
    """
    if start not in graph or target not in graph:
        return None

    if start == target:
        return [start]

    visited = set()
    stack = [(start, [start])]  # (vertex, path_to_vertex)

    while stack:
        vertex, path = stack.pop()

        if vertex == target:
            return path

        if vertex in visited:
            continue

        visited.add(vertex)

        for neighbor in graph[vertex]:
            if neighbor not in visited:
                stack.append((neighbor, path + [neighbor]))

    return None  # No path found


def dfs_all_paths(
    graph: Dict[int, List[int]],
    start: int,
    end: int
) -> List[List[int]]:
    """
    Find all paths from start to end using DFS.

    Uses backtracking to explore all possible paths.
    """
    if start not in graph or end not in graph:
        return []

    all_paths = []

    def dfs_helper(current: int, path: List[int]) -> None:
        if current == end:
            all_paths.append(path[:])  # Make a copy
            return

        for neighbor in graph[current]:
            if neighbor not in path:  # Avoid cycles
                path.append(neighbor)
                dfs_helper(neighbor, path)
                path.pop()  # Backtrack

    dfs_helper(start, [start])
    return all_paths


def dfs_connected_components(graph: Dict[int, List[int]]) -> List[Set[int]]:
    """
    Find all connected components in an undirected graph.
    """
    visited = set()
    components = []

    def dfs(vertex: int, component: Set[int]) -> None:
        visited.add(vertex)
        component.add(vertex)

        for neighbor in graph[vertex]:
            if neighbor not in visited:
                dfs(neighbor, component)

    for vertex in graph:
        if vertex not in visited:
            component = set()
            dfs(vertex, component)
            components.append(component)

    return components


def dfs_preorder_postorder(
    graph: Dict[int, List[int]],
    start: int
) -> tuple:
    """
    DFS with pre-order and post-order timestamps.

    Pre-order: When we first visit a vertex
    Post-order: When we finish processing a vertex (all descendants visited)

    Useful for topological sort, cycle detection, etc.
    """
    visited = set()
    preorder = []
    postorder = []

    def dfs(vertex: int) -> None:
        visited.add(vertex)
        preorder.append(vertex)  # Pre-order: first visit

        for neighbor in graph[vertex]:
            if neighbor not in visited:
                dfs(neighbor)

        postorder.append(vertex)  # Post-order: after all descendants

    dfs(start)
    return preorder, postorder


# =============================================================================
# Test Cases
# =============================================================================

def test_basic_dfs():
    """Test basic DFS traversal."""
    print("\n" + "=" * 60)
    print("TEST: Basic DFS Traversal")
    print("=" * 60)

    # Create graph:
    #     0 --- 1 --- 4
    #     |     |
    #     2 --- 3

    graph = {
        0: [1, 2],
        1: [0, 3, 4],
        2: [0, 3],
        3: [1, 2],
        4: [1]
    }

    print("\nGraph:")
    print("    0 --- 1 --- 4")
    print("    |     |")
    print("    2 --- 3")

    print("\n--- Iterative DFS ---")
    result_iter = dfs_with_trace(graph, 0)

    print("\n--- Recursive DFS ---")
    result_rec = dfs_recursive_with_trace(graph, 0)


def test_tree_dfs():
    """Test DFS on a tree structure."""
    print("\n" + "=" * 60)
    print("TEST: DFS on Tree")
    print("=" * 60)

    # Tree-like graph:
    #        0
    #      /   \
    #     1     2
    #    / \   / \
    #   3   4 5   6

    graph = {
        0: [1, 2],
        1: [0, 3, 4],
        2: [0, 5, 6],
        3: [1],
        4: [1],
        5: [2],
        6: [2]
    }

    print("\nTree structure:")
    print("       0")
    print("     /   \\")
    print("    1     2")
    print("   / \\   / \\")
    print("  3   4 5   6")

    result = dfs_iterative(graph, 0)
    print(f"\nDFS Order: {result}")
    print("Note: DFS goes deep first: 0 -> 1 -> 3 -> 4 -> 2 -> 5 -> 6")


def test_path_finding():
    """Test DFS path finding."""
    print("\n" + "=" * 60)
    print("TEST: Path Finding with DFS")
    print("=" * 60)

    graph = {
        0: [1, 2],
        1: [0, 3],
        2: [0, 3, 4],
        3: [1, 2, 5],
        4: [2],
        5: [3]
    }

    print("\nGraph:")
    print("  0 --- 1")
    print("  |     |")
    print("  2 --- 3 --- 5")
    print("  |")
    print("  4")

    path = dfs_path_to_target(graph, 0, 5)
    print(f"\nPath from 0 to 5: {path}")
    print("Note: DFS finds A path, not necessarily the shortest!")

    # Find all paths
    all_paths = dfs_all_paths(graph, 0, 5)
    print(f"\nAll paths from 0 to 5:")
    for i, p in enumerate(all_paths, 1):
        print(f"  Path {i}: {' -> '.join(map(str, p))}")


def test_pre_post_order():
    """Test pre-order and post-order traversal."""
    print("\n" + "=" * 60)
    print("TEST: Pre-order and Post-order")
    print("=" * 60)

    graph = {
        0: [1, 2],
        1: [3, 4],
        2: [5],
        3: [],
        4: [],
        5: []
    }

    print("\nDirected tree:")
    print("       0")
    print("      / \\")
    print("     1   2")
    print("    / \\   \\")
    print("   3   4   5")

    preorder, postorder = dfs_preorder_postorder(graph, 0)
    print(f"\nPre-order (first visit): {preorder}")
    print(f"Post-order (after descendants): {postorder}")
    print("\nPost-order reversed gives topological order for DAGs!")


def test_connected_components():
    """Test finding connected components."""
    print("\n" + "=" * 60)
    print("TEST: Connected Components")
    print("=" * 60)

    # Graph with 3 components
    graph = {
        0: [1, 2],
        1: [0, 2],
        2: [0, 1],
        # Component 2
        3: [4],
        4: [3],
        # Component 3
        5: []
    }

    print("\nGraph with 3 components:")
    print("  Component 1: 0-1-2 (triangle)")
    print("  Component 2: 3-4 (edge)")
    print("  Component 3: 5 (isolated)")

    components = dfs_connected_components(graph)
    print(f"\nFound {len(components)} components:")
    for i, comp in enumerate(components, 1):
        print(f"  Component {i}: {comp}")


if __name__ == "__main__":
    test_basic_dfs()
    test_tree_dfs()
    test_path_finding()
    test_pre_post_order()
    test_connected_components()
