# Implement DFS Algorithm

## Problem Statement

Implement Depth-First Search (DFS) algorithm to traverse a graph. Starting from a source vertex, explore as far as possible along each branch before backtracking.

## Graph Visualization

```
Example Graph:
        0
       / \
      1   2
     /|   |\
    3 4   5 6

Adjacency List:
0: [1, 2]
1: [0, 3, 4]
2: [0, 5, 6]
3: [1]
4: [1]
5: [2]
6: [2]
```

## DFS Concept

DFS explores the graph by going as **deep as possible** along each branch before backtracking, using a **Stack (LIFO)** or **Recursion**:

```
DFS Order from vertex 0:

Path: 0 -> 1 -> 3 (dead end, backtrack)
           -> 4 (dead end, backtrack)
      -> 2 -> 5 (dead end, backtrack)
           -> 6 (dead end, done)

Traversal: 0 -> 1 -> 3 -> 4 -> 2 -> 5 -> 6
```

## Algorithm

### Recursive DFS
```
DFS(graph, vertex, visited):
    1. Mark vertex as visited
    2. Process vertex
    3. For each neighbor of vertex:
        - If not visited:
            - Recursively call DFS(neighbor)
```

### Iterative DFS (with Stack)
```
DFS(graph, start):
    1. Create empty stack and visited set
    2. Push start to stack
    3. While stack is not empty:
        a. Pop top vertex
        b. If not visited:
            - Mark as visited
            - Process vertex
            - Push all unvisited neighbors to stack
```

## Step-by-Step Dry Run

### Graph:
```
    0 --- 1 --- 4
    |     |
    2 --- 3
```

### DFS from vertex 0 (Iterative):

```
INITIALIZATION:
Stack: [0]
Visited: {}
Result: []

STEP 1:
Action: Pop 0 from stack
Check: 0 not in visited
Process: Mark 0 visited, add to result
Push neighbors: [2, 1] (reversed order)

Stack: [2, 1]        <- After step
Visited: {0}
Result: [0]

STEP 2:
Action: Pop 1 from stack (LIFO - last in, first out)
Check: 1 not in visited
Process: Mark 1 visited, add to result
Push neighbors: [4, 3] (2 skipped - will be visited)

Stack: [2, 4, 3]
Visited: {0, 1}
Result: [0, 1]

STEP 3:
Action: Pop 3 from stack
Check: 3 not in visited
Process: Mark 3 visited, add to result
Push neighbors: [2] (1 already visited)

Stack: [2, 4, 2]
Visited: {0, 1, 3}
Result: [0, 1, 3]

STEP 4:
Action: Pop 2 from stack
Check: 2 not in visited
Process: Mark 2 visited, add to result
No unvisited neighbors

Stack: [2, 4]
Visited: {0, 1, 3, 2}
Result: [0, 1, 3, 2]

STEP 5:
Action: Pop 4 from stack
Check: 4 not in visited
Process: Mark 4 visited, add to result
No unvisited neighbors

Stack: [2]
Visited: {0, 1, 3, 2, 4}
Result: [0, 1, 3, 2, 4]

STEP 6:
Action: Pop 2 from stack
Check: 2 already visited -> Skip

Stack: []            <- Empty, DFS complete!
Visited: {0, 1, 3, 2, 4}
Result: [0, 1, 3, 2, 4]

FINAL OUTPUT: 0 -> 1 -> 3 -> 2 -> 4
```

## Stack State Visualization

```
Step | Action      | Stack State        | Visited Set
-----|-------------|--------------------|-----------------
  0  | Initialize  | [0]                | {}
  1  | Pop 0       | [] -> [2,1]        | {0}
  2  | Pop 1       | [2] -> [2,4,3]     | {0,1}
  3  | Pop 3       | [2,4] -> [2,4,2]   | {0,1,3}
  4  | Pop 2       | [2,4]              | {0,1,3,2}
  5  | Pop 4       | [2]                | {0,1,3,2,4}
  6  | Pop 2       | [] (skip, visited) | {0,1,3,2,4}
```

## Recursive DFS Visualization

```
DFS(0):
    Visit 0
    |
    +-- DFS(1):         <- First neighbor
    |       Visit 1
    |       |
    |       +-- DFS(3):     <- Go deeper
    |       |       Visit 3
    |       |       (no unvisited neighbors, return)
    |       |
    |       +-- DFS(4):     <- Backtrack, try next
    |               Visit 4
    |               (no unvisited neighbors, return)
    |
    +-- DFS(2):         <- Backtrack to 0, try next neighbor
            Visit 2
            (no unvisited neighbors, return)

Recursion Stack (implicit):
[0] -> [0,1] -> [0,1,3] -> [0,1] -> [0,1,4] -> [0,1] -> [0] -> [0,2] -> [0] -> []
```

## Why Use Stack (LIFO)?

```
Stack ensures depth-first exploration:

           0              Start here
         /   \
        1     2           Push 2, Push 1
       / \                Pop 1 (explore deeper)
      3   4               Push 4, Push 3
                          Pop 3 (explore deeper)
                          Dead end, pop 4
                          Dead end, pop 2
                          ...

Last In, First Out = Always explore the most recent branch first!
```

## DFS Applications

| Application | Why DFS? |
|-------------|----------|
| Cycle detection | Tracks ancestors in recursion stack |
| Topological sort | Post-order gives reverse topo order |
| Path finding | Naturally explores complete paths |
| Maze solving | Goes deep into one path before trying others |
| Connected components | Marks all nodes in component |
| Strongly connected components | Tarjan's/Kosaraju's algorithms |
| Backtracking problems | N-Queens, Sudoku, etc. |

## Code Templates

### Recursive DFS
```python
def dfs_recursive(graph, vertex, visited=None):
    if visited is None:
        visited = set()

    visited.add(vertex)
    result = [vertex]

    for neighbor in graph[vertex]:
        if neighbor not in visited:
            result.extend(dfs_recursive(graph, neighbor, visited))

    return result
```

### Iterative DFS
```python
def dfs_iterative(graph, start):
    visited = set()
    stack = [start]
    result = []

    while stack:
        vertex = stack.pop()

        if vertex not in visited:
            visited.add(vertex)
            result.append(vertex)

            # Push neighbors in reverse for correct order
            for neighbor in reversed(graph[vertex]):
                if neighbor not in visited:
                    stack.append(neighbor)

    return result
```

## Time & Space Complexity

| Metric | Complexity | Explanation |
|--------|------------|-------------|
| Time | O(V + E) | Visit each vertex once, check each edge once |
| Space | O(V) | Stack/recursion depth can be at most V |

### Detailed Analysis:

```
Time Complexity:
- Each vertex pushed/popped once: O(V)
- Each edge checked once: O(E)
- Total: O(V + E)

Space Complexity:
- Visited set: O(V)
- Stack/Recursion: O(V) worst case (linear graph)
- Total: O(V)

Note: Recursion can cause stack overflow for very deep graphs!
```

## BFS vs DFS Comparison

| Aspect | BFS | DFS |
|--------|-----|-----|
| Data Structure | Queue (FIFO) | Stack (LIFO) |
| Exploration | Level by level | Branch by branch |
| Shortest Path | Yes (unweighted) | No guarantee |
| Memory (wide tree) | Higher | Lower |
| Memory (deep tree) | Lower | Higher |

## Key Points

1. **Two implementations**: Recursive (simpler) and Iterative (avoids stack overflow)
2. **Mark visited when popping** for iterative (different from BFS!)
3. **Push in reverse order** in iterative to match recursive order
4. **Recursion depth limit**: Python default is ~1000, increase if needed
5. Does NOT guarantee shortest path
6. Can detect **cycles** by tracking vertices in current path

## Edge Cases

1. **Disconnected graph**: DFS only visits reachable vertices
2. **Single vertex**: Returns [start]
3. **Linear graph**: Maximum stack depth
4. **Complete graph**: All vertices at same depth
