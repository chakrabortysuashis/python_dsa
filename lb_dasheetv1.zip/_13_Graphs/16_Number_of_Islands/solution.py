"""
Problem: Number of Islands
==========================

Given a 2D grid of '1's (land) and '0's (water), count the number of islands.
An island is surrounded by water and formed by connecting adjacent lands
horizontally or vertically.

Approaches:
1. BFS - Use queue to explore connected land cells
2. DFS - Use recursion/stack to explore connected land cells
3. Union-Find - Group connected cells

Time Complexity: O(M * N) where M = rows, N = cols
Space Complexity: O(M * N) for visited set
"""

from collections import deque
from typing import List, Set, Tuple


def num_islands_bfs(grid: List[List[str]]) -> int:
    """
    Count islands using BFS.

    BFS explores all neighbors at current distance before going deeper.
    Good for finding shortest paths, but here we just need connectivity.

    Example:
        >>> grid = [['1','1','0'],['1','0','0'],['0','0','1']]
        >>> num_islands_bfs(grid)
        2
    """
    if not grid or not grid[0]:
        return 0

    rows, cols = len(grid), len(grid[0])
    visited = set()
    islands = 0

    # 4 directions: up, down, left, right
    directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]

    def bfs(start_r: int, start_c: int) -> None:
        """BFS to mark all connected land cells as visited."""
        queue = deque([(start_r, start_c)])
        visited.add((start_r, start_c))

        while queue:
            row, col = queue.popleft()

            for dr, dc in directions:
                nr, nc = row + dr, col + dc

                # Check bounds, land, and not visited
                if (0 <= nr < rows and 0 <= nc < cols and
                    grid[nr][nc] == '1' and (nr, nc) not in visited):
                    queue.append((nr, nc))
                    visited.add((nr, nc))

    # Scan entire grid
    for r in range(rows):
        for c in range(cols):
            if grid[r][c] == '1' and (r, c) not in visited:
                bfs(r, c)
                islands += 1

    return islands


def num_islands_dfs(grid: List[List[str]]) -> int:
    """
    Count islands using DFS (recursive).

    DFS goes deep into one path before backtracking.
    Uses call stack for recursion.
    """
    if not grid or not grid[0]:
        return 0

    rows, cols = len(grid), len(grid[0])
    visited = set()
    islands = 0

    def dfs(r: int, c: int) -> None:
        """DFS to mark all connected land cells as visited."""
        # Base case: out of bounds, water, or visited
        if (r < 0 or r >= rows or c < 0 or c >= cols or
            grid[r][c] == '0' or (r, c) in visited):
            return

        visited.add((r, c))

        # Explore 4 directions
        dfs(r + 1, c)  # down
        dfs(r - 1, c)  # up
        dfs(r, c + 1)  # right
        dfs(r, c - 1)  # left

    for r in range(rows):
        for c in range(cols):
            if grid[r][c] == '1' and (r, c) not in visited:
                dfs(r, c)
                islands += 1

    return islands


def num_islands_dfs_iterative(grid: List[List[str]]) -> int:
    """
    Count islands using iterative DFS with explicit stack.

    Avoids recursion limit issues for large grids.
    """
    if not grid or not grid[0]:
        return 0

    rows, cols = len(grid), len(grid[0])
    visited = set()
    islands = 0
    directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]

    def dfs_iterative(start_r: int, start_c: int) -> None:
        stack = [(start_r, start_c)]
        visited.add((start_r, start_c))

        while stack:
            row, col = stack.pop()

            for dr, dc in directions:
                nr, nc = row + dr, col + dc

                if (0 <= nr < rows and 0 <= nc < cols and
                    grid[nr][nc] == '1' and (nr, nc) not in visited):
                    stack.append((nr, nc))
                    visited.add((nr, nc))

    for r in range(rows):
        for c in range(cols):
            if grid[r][c] == '1' and (r, c) not in visited:
                dfs_iterative(r, c)
                islands += 1

    return islands


def num_islands_modify_grid(grid: List[List[str]]) -> int:
    """
    Count islands by modifying grid in-place.

    Instead of using visited set, mark visited land as water.
    Space efficient but modifies input.
    """
    if not grid or not grid[0]:
        return 0

    rows, cols = len(grid), len(grid[0])
    islands = 0

    def sink_island(r: int, c: int) -> None:
        """Sink the island by changing '1' to '0'."""
        if r < 0 or r >= rows or c < 0 or c >= cols or grid[r][c] == '0':
            return

        grid[r][c] = '0'  # Sink this cell

        sink_island(r + 1, c)
        sink_island(r - 1, c)
        sink_island(r, c + 1)
        sink_island(r, c - 1)

    for r in range(rows):
        for c in range(cols):
            if grid[r][c] == '1':
                sink_island(r, c)
                islands += 1

    return islands


class UnionFind:
    """Union-Find (Disjoint Set Union) data structure."""

    def __init__(self, n: int):
        self.parent = list(range(n))
        self.rank = [0] * n
        self.count = 0  # Number of distinct sets

    def find(self, x: int) -> int:
        """Find with path compression."""
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])
        return self.parent[x]

    def union(self, x: int, y: int) -> None:
        """Union by rank."""
        px, py = self.find(x), self.find(y)

        if px == py:
            return

        if self.rank[px] < self.rank[py]:
            px, py = py, px

        self.parent[py] = px
        if self.rank[px] == self.rank[py]:
            self.rank[px] += 1

        self.count -= 1

    def add(self) -> None:
        """Add a new set."""
        self.count += 1


def num_islands_union_find(grid: List[List[str]]) -> int:
    """
    Count islands using Union-Find.

    Useful when we need to handle dynamic connectivity queries.
    """
    if not grid or not grid[0]:
        return 0

    rows, cols = len(grid), len(grid[0])
    uf = UnionFind(rows * cols)

    def cell_id(r: int, c: int) -> int:
        return r * cols + c

    # Add all land cells as separate sets
    for r in range(rows):
        for c in range(cols):
            if grid[r][c] == '1':
                uf.add()

    # Union adjacent land cells
    for r in range(rows):
        for c in range(cols):
            if grid[r][c] == '1':
                # Only check right and down to avoid duplicate unions
                if c + 1 < cols and grid[r][c + 1] == '1':
                    uf.union(cell_id(r, c), cell_id(r, c + 1))
                if r + 1 < rows and grid[r + 1][c] == '1':
                    uf.union(cell_id(r, c), cell_id(r + 1, c))

    return uf.count


def num_islands_with_trace(grid: List[List[str]]) -> int:
    """BFS with detailed trace for learning."""
    if not grid or not grid[0]:
        return 0

    rows, cols = len(grid), len(grid[0])
    visited = set()
    islands = 0
    directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]
    direction_names = ['right', 'left', 'down', 'up']

    print("\n" + "=" * 60)
    print("Number of Islands - BFS Trace")
    print("=" * 60)

    def print_grid_state():
        print("\nCurrent Grid State:")
        for r in range(rows):
            row_str = ""
            for c in range(cols):
                if (r, c) in visited:
                    row_str += " V "  # Visited
                else:
                    row_str += f" {grid[r][c]} "
            print(row_str)

    print("\nOriginal Grid:")
    for row in grid:
        print(" ".join(row))

    def bfs_trace(start_r: int, start_c: int, island_num: int) -> None:
        print(f"\n--- BFS for Island {island_num} starting at ({start_r}, {start_c}) ---")

        queue = deque([(start_r, start_c)])
        visited.add((start_r, start_c))
        step = 0

        while queue:
            step += 1
            row, col = queue.popleft()
            print(f"\nStep {step}: Processing ({row}, {col})")
            print(f"  Queue before: {list(queue)}")

            for i, (dr, dc) in enumerate(directions):
                nr, nc = row + dr, col + dc

                if not (0 <= nr < rows and 0 <= nc < cols):
                    print(f"  {direction_names[i]}: ({nr}, {nc}) - out of bounds")
                elif grid[nr][nc] == '0':
                    print(f"  {direction_names[i]}: ({nr}, {nc}) - water")
                elif (nr, nc) in visited:
                    print(f"  {direction_names[i]}: ({nr}, {nc}) - already visited")
                else:
                    print(f"  {direction_names[i]}: ({nr}, {nc}) - land, adding to queue")
                    queue.append((nr, nc))
                    visited.add((nr, nc))

            print(f"  Queue after: {list(queue)}")

    for r in range(rows):
        for c in range(cols):
            if grid[r][c] == '1' and (r, c) not in visited:
                islands += 1
                print(f"\n{'='*40}")
                print(f"Found new island #{islands} at ({r}, {c})!")
                bfs_trace(r, c, islands)
                print_grid_state()

    print(f"\n{'='*60}")
    print(f"RESULT: {islands} island(s) found")
    print("=" * 60)

    return islands


# =============================================================================
# Test Cases
# =============================================================================

def test_num_islands():
    """Test all implementations."""
    print("\n" + "=" * 60)
    print("Number of Islands - Test Cases")
    print("=" * 60)

    # Test Case 1: Multiple islands
    grid1 = [
        ['1', '1', '0', '0', '0'],
        ['1', '1', '0', '0', '0'],
        ['0', '0', '1', '0', '0'],
        ['0', '0', '0', '1', '1']
    ]

    print("\nTest 1: Multiple islands")
    print("Grid:")
    for row in grid1:
        print("  " + " ".join(row))

    # Make copies since some methods modify grid
    import copy
    result_bfs = num_islands_bfs(copy.deepcopy(grid1))
    result_dfs = num_islands_dfs(copy.deepcopy(grid1))
    result_uf = num_islands_union_find(copy.deepcopy(grid1))

    print(f"\nResults:")
    print(f"  BFS: {result_bfs}")
    print(f"  DFS: {result_dfs}")
    print(f"  Union-Find: {result_uf}")
    assert result_bfs == result_dfs == result_uf == 3

    # Test Case 2: Single island
    grid2 = [
        ['1', '1', '1', '1', '0'],
        ['1', '1', '0', '1', '0'],
        ['1', '1', '0', '0', '0'],
        ['0', '0', '0', '0', '0']
    ]

    print("\nTest 2: Single island")
    result = num_islands_bfs(copy.deepcopy(grid2))
    print(f"  Result: {result}")
    assert result == 1

    # Test Case 3: No islands
    grid3 = [
        ['0', '0', '0'],
        ['0', '0', '0']
    ]

    print("\nTest 3: No islands")
    result = num_islands_bfs(grid3)
    print(f"  Result: {result}")
    assert result == 0

    # Test Case 4: All land
    grid4 = [
        ['1', '1'],
        ['1', '1']
    ]

    print("\nTest 4: All land (one island)")
    result = num_islands_bfs(grid4)
    print(f"  Result: {result}")
    assert result == 1

    # Test Case 5: Scattered islands
    grid5 = [
        ['1', '0', '1', '0', '1'],
        ['0', '0', '0', '0', '0'],
        ['1', '0', '1', '0', '1']
    ]

    print("\nTest 5: Scattered islands")
    result = num_islands_bfs(grid5)
    print(f"  Result: {result}")
    assert result == 6

    print("\nAll tests passed!")


def test_with_trace():
    """Test with detailed trace."""
    grid = [
        ['1', '1', '0'],
        ['1', '0', '0'],
        ['0', '0', '1']
    ]

    num_islands_with_trace(grid)


if __name__ == "__main__":
    test_num_islands()
    test_with_trace()
