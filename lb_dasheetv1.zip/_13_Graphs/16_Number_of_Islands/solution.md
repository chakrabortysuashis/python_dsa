# Number of Islands

## Problem Statement

Given a 2D grid map of '1's (land) and '0's (water), count the number of islands. An island is surrounded by water and is formed by connecting adjacent lands horizontally or vertically. Assume all four edges of the grid are surrounded by water.

## Graph Visualization

```
Grid Example:
    0   1   2   3   4
  +---+---+---+---+---+
0 | 1 | 1 | 0 | 0 | 0 |
  +---+---+---+---+---+
1 | 1 | 1 | 0 | 0 | 0 |
  +---+---+---+---+---+
2 | 0 | 0 | 1 | 0 | 0 |
  +---+---+---+---+---+
3 | 0 | 0 | 0 | 1 | 1 |
  +---+---+---+---+---+

Islands:
  - Island 1: cells (0,0), (0,1), (1,0), (1,1)
  - Island 2: cell (2,2)
  - Island 3: cells (3,3), (3,4)

Answer: 3 islands
```

## Graph Representation

```
Each '1' cell is a node
Adjacent '1' cells (up, down, left, right) are connected by edges

Cell (0,0) connects to:
  - (0,1) - right neighbor
  - (1,0) - down neighbor

This forms an implicit graph in the grid!
```

## BFS/DFS Approach

### Why BFS/DFS?
- We need to find **connected components** of '1's
- Each connected component = one island
- BFS/DFS can explore all cells in a component

### Algorithm
```
1. Iterate through each cell in the grid
2. When we find an unvisited '1':
   a. Increment island count
   b. Start BFS/DFS to mark all connected '1's as visited
3. Return the island count
```

## Step-by-Step Dry Run (BFS)

### Grid:
```
1 1 0
1 0 0
0 0 1
```

### Execution:

```
INITIALIZATION:
Islands = 0
Visited = {} (empty set)

SCAN GRID:

Cell (0,0): Value = '1', not visited
  -> Found new island! Islands = 1
  -> Start BFS from (0,0)

BFS from (0,0):
  Queue: [(0,0)]
  
  Step 1: Dequeue (0,0), mark visited
    Visited: {(0,0)}
    Check neighbors:
      (0,1): '1', not visited -> enqueue
      (1,0): '1', not visited -> enqueue
    Queue: [(0,1), (1,0)]
  
  Step 2: Dequeue (0,1), mark visited
    Visited: {(0,0), (0,1)}
    Check neighbors:
      (0,0): visited -> skip
      (0,2): '0' -> skip
      (1,1): '0' -> skip
    Queue: [(1,0)]
  
  Step 3: Dequeue (1,0), mark visited
    Visited: {(0,0), (0,1), (1,0)}
    Check neighbors:
      (0,0): visited -> skip
      (1,1): '0' -> skip
      (2,0): '0' -> skip
    Queue: [] -> BFS Complete for Island 1

Cell (0,1): Already visited -> skip
Cell (0,2): Value = '0' -> skip
Cell (1,0): Already visited -> skip
Cell (1,1): Value = '0' -> skip
Cell (1,2): Value = '0' -> skip
Cell (2,0): Value = '0' -> skip
Cell (2,1): Value = '0' -> skip

Cell (2,2): Value = '1', not visited
  -> Found new island! Islands = 2
  -> Start BFS from (2,2)

BFS from (2,2):
  Queue: [(2,2)]
  
  Step 1: Dequeue (2,2), mark visited
    Visited: {..., (2,2)}
    Check neighbors: all '0' or out of bounds
    Queue: [] -> BFS Complete for Island 2

FINAL: Islands = 2
```

## DFS vs BFS Comparison

```
DFS Approach:
+------------------------+
|  Recursively explore   |
|  one direction fully   |
|  before backtracking   |
+------------------------+
     |
     v
Go deep first: (0,0) -> (0,1) -> backtrack -> (1,0) -> done

BFS Approach:
+------------------------+
|  Explore all neighbors |
|  at current distance   |
|  before going deeper   |
+------------------------+
     |
     v
Go wide first: (0,0) -> [(0,1), (1,0)] -> done

Both work equally well for this problem!
Time: O(m*n) for both
Space: O(min(m,n)) for BFS, O(m*n) for DFS (worst case recursion)
```

## Code Template

```python
from collections import deque

def numIslands(grid):
    if not grid:
        return 0
    
    rows, cols = len(grid), len(grid[0])
    visited = set()
    islands = 0
    
    def bfs(r, c):
        queue = deque([(r, c)])
        visited.add((r, c))
        
        while queue:
            row, col = queue.popleft()
            # 4 directions: up, down, left, right
            directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]
            
            for dr, dc in directions:
                nr, nc = row + dr, col + dc
                if (0 <= nr < rows and 0 <= nc < cols and 
                    grid[nr][nc] == '1' and (nr, nc) not in visited):
                    queue.append((nr, nc))
                    visited.add((nr, nc))
    
    for r in range(rows):
        for c in range(cols):
            if grid[r][c] == '1' and (r, c) not in visited:
                bfs(r, c)
                islands += 1
    
    return islands
```

## Time & Space Complexity

| Metric | Complexity | Explanation |
|--------|------------|-------------|
| Time | O(M * N) | Visit each cell at most once |
| Space | O(M * N) | Visited set can hold all cells |

Where:
- M = Number of rows
- N = Number of columns

## Variations

### 1. Modify Grid In-Place
```python
# Instead of visited set, mark '1' as '0' after visiting
# Saves space but modifies input
```

### 2. Count Islands with Diagonal Connections
```python
# Add 8 directions instead of 4
directions = [(-1,-1), (-1,0), (-1,1), (0,-1), 
              (0,1), (1,-1), (1,0), (1,1)]
```

### 3. Union-Find Approach
```python
# Use Union-Find to group connected cells
# Initially each '1' cell is its own set
# Union adjacent '1' cells
# Count distinct sets
```

## Key Points

1. This is essentially **counting connected components** in a grid
2. Each cell with '1' is a node; adjacent '1's share an edge
3. BFS and DFS both work; BFS uses less stack space
4. Marking visited prevents counting same island multiple times
5. Common follow-ups: largest island, number of distinct islands
