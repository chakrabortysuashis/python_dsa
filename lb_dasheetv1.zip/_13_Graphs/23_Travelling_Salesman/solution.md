# Travelling Salesman Problem (TSP)

## Problem Statement

Given a set of cities and distances between every pair of cities, find the shortest possible route that visits every city exactly once and returns to the starting city.

## Graph Visualization

```
Cities and distances:
        10
    A -------- B
    |\        /|
  15| \20  25/ |35
    |  \    /  |
    D -------- C
        30

Possible tours:
A -> B -> C -> D -> A = 10 + 35 + 30 + 15 = 90
A -> B -> D -> C -> A = 10 + ? + 30 + 20 = ...
A -> C -> B -> D -> A = 20 + 35 + ? + 15 = ...
A -> C -> D -> B -> A = 20 + 30 + ? + 10 = ...
A -> D -> B -> C -> A = 15 + ? + 35 + 20 = ...
A -> D -> C -> B -> A = 15 + 30 + 35 + 10 = 90

Optimal tour: minimum cost cycle visiting all cities
```

## TSP is NP-Hard

```
+------------------+     +------------------+
| Brute Force      |     | DP with Bitmask  |
| O(n!)            |     | O(n^2 * 2^n)     |
+------------------+     +------------------+
| n=10: 3.6M       |     | n=10: 102K       |
| n=15: 1.3T       |     | n=15: 7.3M       |
| n=20: impossible |     | n=20: 419M       |
+------------------+     +------------------+

For large n: Use approximation algorithms
```

## Dynamic Programming Solution

```
State: dp[mask][i] = minimum cost to visit all cities in 'mask'
                     and end at city 'i'

mask = bitmask representing visited cities
  - mask = 5 (binary 101) means cities 0 and 2 visited

Transition:
dp[mask | (1<<j)][j] = min(dp[mask][i] + dist[i][j])
for all i in mask, j not in mask

Base case: dp[1][0] = 0 (start at city 0)
Answer: min(dp[(1<<n)-1][i] + dist[i][0]) for all i
```

## Step-by-Step Dry Run

### Graph (4 cities):
```
dist matrix:
     0    1    2    3
0 [  0   10   15   20 ]
1 [ 10    0   35   25 ]
2 [ 15   35    0   30 ]
3 [ 20   25   30    0 ]
```

### DP Execution:

```
n = 4, so mask goes from 0 to 15 (2^4 - 1)

INITIALIZATION:
dp[1][0] = 0  (only city 0 visited, currently at 0)
All other dp values = INF

ITERATION (process masks with increasing popcount):

mask = 1 (binary 0001, city 0 only):
  dp[1][0] = 0 (base case)
  
  Try adding city 1: mask | (1<<1) = 3
    dp[3][1] = min(INF, dp[1][0] + dist[0][1]) = 0 + 10 = 10
    
  Try adding city 2: mask | (1<<2) = 5
    dp[5][2] = min(INF, dp[1][0] + dist[0][2]) = 0 + 15 = 15
    
  Try adding city 3: mask | (1<<3) = 9
    dp[9][3] = min(INF, dp[1][0] + dist[0][3]) = 0 + 20 = 20

mask = 3 (binary 0011, cities 0,1):
  i = 1 (current city)
  
  Try adding city 2: mask | (1<<2) = 7
    dp[7][2] = min(INF, dp[3][1] + dist[1][2]) = 10 + 35 = 45
    
  Try adding city 3: mask | (1<<3) = 11
    dp[11][3] = min(INF, dp[3][1] + dist[1][3]) = 10 + 25 = 35

... (continue for all masks)

mask = 15 (binary 1111, all visited):
dp[15][1] = 45 (path 0->2->3->1 or 0->3->2->1)
dp[15][2] = 35 (path 0->1->3->2)
dp[15][3] = 45 (path 0->1->2->3 or 0->2->1->3)

FINAL ANSWER:
min(dp[15][i] + dist[i][0]) for i = 1,2,3
= min(dp[15][1]+10, dp[15][2]+15, dp[15][3]+20)
= min(45+10, 35+15, 45+20)
= min(55, 50, 65)
= 50

Optimal tour cost = 50
Path: 0 -> 1 -> 3 -> 2 -> 0 (cost: 10+25+30+15 = 80)
Wait, let me recalculate...
```

## Code Template

```python
def tsp_dp(dist):
    """
    Solve TSP using dynamic programming with bitmask.
    
    Args:
        dist: n x n distance matrix
    
    Returns:
        Minimum tour cost
    """
    n = len(dist)
    INF = float('inf')
    
    # dp[mask][i] = min cost to visit cities in mask, ending at i
    dp = [[INF] * n for _ in range(1 << n)]
    dp[1][0] = 0  # Start at city 0
    
    for mask in range(1, 1 << n):
        for last in range(n):
            if not (mask & (1 << last)):
                continue
            if dp[mask][last] == INF:
                continue
                
            # Try adding each unvisited city
            for next_city in range(n):
                if mask & (1 << next_city):
                    continue
                    
                new_mask = mask | (1 << next_city)
                dp[new_mask][next_city] = min(
                    dp[new_mask][next_city],
                    dp[mask][last] + dist[last][next_city]
                )
    
    # Return to starting city
    full_mask = (1 << n) - 1
    ans = INF
    for last in range(1, n):
        if dp[full_mask][last] != INF:
            ans = min(ans, dp[full_mask][last] + dist[last][0])
    
    return ans
```

## Time & Space Complexity

| Metric | Complexity | Explanation |
|--------|------------|-------------|
| Time | O(n^2 * 2^n) | n cities, 2^n masks, n transitions |
| Space | O(n * 2^n) | DP table |

## Approximation Algorithms

For large n, use approximation:

### 1. Nearest Neighbor (Greedy)
```python
def nearest_neighbor(dist):
    n = len(dist)
    visited = [False] * n
    tour = [0]
    visited[0] = True
    
    for _ in range(n - 1):
        last = tour[-1]
        nearest = min(
            (i for i in range(n) if not visited[i]),
            key=lambda i: dist[last][i]
        )
        tour.append(nearest)
        visited[nearest] = True
    
    return tour
# Approximation ratio: can be arbitrarily bad
```

### 2. Christofides Algorithm
```
1. Find MST
2. Find odd-degree vertices
3. Find minimum weight matching
4. Form Eulerian circuit
5. Convert to Hamiltonian path

Approximation ratio: 1.5 for metric TSP
```

## Applications

| Application | Description |
|-------------|-------------|
| Logistics | Delivery route optimization |
| Manufacturing | PCB drilling order |
| DNA Sequencing | Fragment ordering |
| Telescope scheduling | Observation order |

## Key Points

1. **NP-Hard**: No polynomial solution known
2. **DP bitmask**: Practical for n <= 20
3. **Approximations**: For larger instances
4. **Metric TSP**: Triangle inequality helps
5. **Asymmetric TSP**: Different from/to distances
