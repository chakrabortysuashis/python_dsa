"""
Problem: Travelling Salesman Problem (TSP)
==========================================

Find shortest tour visiting all cities exactly once and returning to start.

Approaches:
1. Brute Force: O(n!) - try all permutations
2. DP with Bitmask: O(n^2 * 2^n) - practical for n <= 20
3. Approximation: For larger instances

Time Complexity: O(n^2 * 2^n)
Space Complexity: O(n * 2^n)
"""

from typing import List, Tuple, Optional
from itertools import permutations
import random


def tsp_brute_force(dist: List[List[int]]) -> Tuple[int, List[int]]:
    """
    Brute force TSP - try all permutations.
    Only practical for very small n (< 10).

    Args:
        dist: n x n distance matrix

    Returns:
        Tuple of (minimum cost, optimal tour)
    """
    n = len(dist)
    if n <= 1:
        return 0, [0]

    min_cost = float('inf')
    best_tour = None

    # Try all permutations of cities 1 to n-1 (fix city 0 as start)
    for perm in permutations(range(1, n)):
        tour = [0] + list(perm) + [0]
        cost = sum(dist[tour[i]][tour[i + 1]] for i in range(n))

        if cost < min_cost:
            min_cost = cost
            best_tour = tour[:-1]  # Exclude duplicate start

    return min_cost, best_tour


def tsp_dp(dist: List[List[int]]) -> Tuple[int, List[int]]:
    """
    DP with bitmask solution for TSP.

    State: dp[mask][i] = min cost to visit cities in mask, ending at i
    Transition: dp[mask | (1<<j)][j] = min(dp[mask][i] + dist[i][j])

    Args:
        dist: n x n distance matrix

    Returns:
        Tuple of (minimum cost, optimal tour)
    """
    n = len(dist)
    INF = float('inf')

    # dp[mask][i] = min cost to reach state (mask, i)
    dp = [[INF] * n for _ in range(1 << n)]
    parent = [[-1] * n for _ in range(1 << n)]

    # Base case: start at city 0
    dp[1][0] = 0

    # Process all masks
    for mask in range(1, 1 << n):
        for last in range(n):
            # Check if last city is in mask
            if not (mask & (1 << last)):
                continue
            if dp[mask][last] == INF:
                continue

            # Try adding each unvisited city
            for next_city in range(n):
                if mask & (1 << next_city):
                    continue

                new_mask = mask | (1 << next_city)
                new_cost = dp[mask][last] + dist[last][next_city]

                if new_cost < dp[new_mask][next_city]:
                    dp[new_mask][next_city] = new_cost
                    parent[new_mask][next_city] = last

    # Find minimum cost to complete tour
    full_mask = (1 << n) - 1
    min_cost = INF
    last_city = -1

    for i in range(1, n):
        if dp[full_mask][i] != INF:
            cost = dp[full_mask][i] + dist[i][0]
            if cost < min_cost:
                min_cost = cost
                last_city = i

    # Reconstruct path
    tour = []
    mask = full_mask
    curr = last_city

    while curr != -1:
        tour.append(curr)
        prev = parent[mask][curr]
        mask ^= (1 << curr)
        curr = prev

    tour.reverse()

    return min_cost, tour


def tsp_dp_with_trace(dist: List[List[int]]) -> int:
    """TSP DP with detailed trace."""
    print("\n" + "=" * 60)
    print("TSP - Dynamic Programming with Bitmask")
    print("=" * 60)

    n = len(dist)
    INF = float('inf')

    print(f"\nNumber of cities: {n}")
    print("\nDistance matrix:")
    for i, row in enumerate(dist):
        print(f"  {i}: {row}")

    dp = [[INF] * n for _ in range(1 << n)]
    dp[1][0] = 0

    print(f"\nTotal states: {1 << n} masks x {n} cities = {n * (1 << n)}")
    print("\n--- Processing ---")

    for mask in range(1, 1 << n):
        popcount = bin(mask).count('1')
        if popcount <= 2:  # Only trace small masks
            cities_in_mask = [i for i in range(n) if mask & (1 << i)]
            print(f"\nmask = {mask} (binary {bin(mask)[2:].zfill(n)})")
            print(f"  Cities in mask: {cities_in_mask}")

        for last in range(n):
            if not (mask & (1 << last)):
                continue
            if dp[mask][last] == INF:
                continue

            for next_city in range(n):
                if mask & (1 << next_city):
                    continue

                new_mask = mask | (1 << next_city)
                new_cost = dp[mask][last] + dist[last][next_city]

                if new_cost < dp[new_mask][next_city]:
                    dp[new_mask][next_city] = new_cost
                    if popcount <= 2:
                        print(f"  dp[{new_mask}][{next_city}] = {new_cost} (from city {last})")

    full_mask = (1 << n) - 1
    min_cost = INF

    print(f"\n--- Complete tour cost ---")
    print(f"Full mask = {full_mask}")
    for i in range(1, n):
        if dp[full_mask][i] != INF:
            cost = dp[full_mask][i] + dist[i][0]
            print(f"  End at {i}, return to 0: {dp[full_mask][i]} + {dist[i][0]} = {cost}")
            min_cost = min(min_cost, cost)

    print(f"\n{'='*60}")
    print(f"Minimum tour cost: {min_cost}")
    print("=" * 60)

    return min_cost


def nearest_neighbor(dist: List[List[int]], start: int = 0) -> Tuple[int, List[int]]:
    """
    Nearest Neighbor heuristic - greedy approximation.

    Always move to the closest unvisited city.
    Fast but can be far from optimal.
    """
    n = len(dist)
    visited = [False] * n
    tour = [start]
    visited[start] = True
    total_cost = 0

    current = start
    for _ in range(n - 1):
        nearest = -1
        nearest_dist = float('inf')

        for j in range(n):
            if not visited[j] and dist[current][j] < nearest_dist:
                nearest = j
                nearest_dist = dist[current][j]

        tour.append(nearest)
        visited[nearest] = True
        total_cost += nearest_dist
        current = nearest

    # Return to start
    total_cost += dist[current][start]

    return total_cost, tour


def two_opt(dist: List[List[int]], tour: List[int]) -> Tuple[int, List[int]]:
    """
    2-opt local search improvement.

    Repeatedly reverse segments of the tour if it reduces cost.
    """
    n = len(tour)

    def tour_cost(t):
        return sum(dist[t[i]][t[(i + 1) % n]] for i in range(n))

    improved = True
    while improved:
        improved = False
        for i in range(n - 1):
            for j in range(i + 2, n):
                if j == n - 1 and i == 0:
                    continue

                # Try reversing segment from i+1 to j
                new_tour = tour[:i + 1] + tour[i + 1:j + 1][::-1] + tour[j + 1:]

                if tour_cost(new_tour) < tour_cost(tour):
                    tour = new_tour
                    improved = True

    return tour_cost(tour), tour


def simulated_annealing_tsp(dist: List[List[int]], iterations: int = 10000) -> Tuple[int, List[int]]:
    """
    Simulated annealing for TSP.
    Probabilistically accepts worse solutions to escape local minima.
    """
    import math

    n = len(dist)

    def tour_cost(t):
        return sum(dist[t[i]][t[(i + 1) % n]] for i in range(n))

    # Start with random tour
    tour = list(range(n))
    random.shuffle(tour)
    best_tour = tour[:]
    best_cost = tour_cost(tour)

    temperature = 10000
    cooling_rate = 0.9995

    for _ in range(iterations):
        # Generate neighbor by swapping two cities
        i, j = random.sample(range(n), 2)
        new_tour = tour[:]
        new_tour[i], new_tour[j] = new_tour[j], new_tour[i]

        current_cost = tour_cost(tour)
        new_cost = tour_cost(new_tour)
        delta = new_cost - current_cost

        # Accept if better or with probability based on temperature
        if delta < 0 or random.random() < math.exp(-delta / temperature):
            tour = new_tour
            if new_cost < best_cost:
                best_tour = tour[:]
                best_cost = new_cost

        temperature *= cooling_rate

    return best_cost, best_tour


# =============================================================================
# Test Cases
# =============================================================================

def test_tsp():
    """Test TSP implementations."""
    print("\n" + "=" * 60)
    print("Travelling Salesman Problem - Test Cases")
    print("=" * 60)

    # Test 1: Small graph
    print("\nTest 1: 4 cities")
    dist1 = [
        [0, 10, 15, 20],
        [10, 0, 35, 25],
        [15, 35, 0, 30],
        [20, 25, 30, 0]
    ]

    cost_bf, tour_bf = tsp_brute_force(dist1)
    cost_dp, tour_dp = tsp_dp(dist1)

    print(f"  Brute force: cost={cost_bf}, tour={tour_bf}")
    print(f"  DP bitmask: cost={cost_dp}, tour={tour_dp}")
    assert cost_bf == cost_dp

    # Test 2: Larger graph with heuristics
    print("\nTest 2: 6 cities with approximations")
    dist2 = [
        [0, 12, 10, 19, 8, 14],
        [12, 0, 3, 7, 6, 9],
        [10, 3, 0, 6, 12, 8],
        [19, 7, 6, 0, 4, 15],
        [8, 6, 12, 4, 0, 11],
        [14, 9, 8, 15, 11, 0]
    ]

    cost_dp, tour_dp = tsp_dp(dist2)
    cost_nn, tour_nn = nearest_neighbor(dist2)
    cost_2opt, tour_2opt = two_opt(dist2, tour_nn)

    print(f"  Optimal (DP): cost={cost_dp}")
    print(f"  Nearest Neighbor: cost={cost_nn}")
    print(f"  2-opt improvement: cost={cost_2opt}")

    # Test 3: Simulated annealing
    print("\nTest 3: Simulated Annealing")
    cost_sa, tour_sa = simulated_annealing_tsp(dist2, 5000)
    print(f"  SA result: cost={cost_sa}")

    print("\nAll tests completed!")


def test_with_trace():
    """Test with detailed trace."""
    dist = [
        [0, 10, 15, 20],
        [10, 0, 35, 25],
        [15, 35, 0, 30],
        [20, 25, 30, 0]
    ]
    tsp_dp_with_trace(dist)


if __name__ == "__main__":
    test_tsp()
    test_with_trace()
