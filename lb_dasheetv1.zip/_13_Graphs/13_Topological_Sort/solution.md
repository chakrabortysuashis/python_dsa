# Implement Topological Sort

## Problem Statement

Given a Directed Acyclic Graph (DAG), find a linear ordering of vertices such that for every directed edge (u, v), vertex u comes before v in the ordering.

## Use Cases

- **Build systems**: Compile files in dependency order
- **Task scheduling**: Complete prerequisites before dependent tasks
- **Course prerequisites**: Take required courses first

## Graph Visualization

```
DAG:
    5 --> 0 <-- 4
    |           |
    v           v
    2 --> 3 --> 1

One valid topological order: 5 -> 4 -> 2 -> 3 -> 1 -> 0
Another valid order: 4 -> 5 -> 2 -> 3 -> 1 -> 0
```

## Two Approaches

### 1. DFS-based (Reverse Post-order)

```python
def topo_sort_dfs(graph, n):
    visited = set()
    stack = []
    
    def dfs(node):
        visited.add(node)
        for neighbor in graph[node]:
            if neighbor not in visited:
                dfs(neighbor)
        stack.append(node)  # Post-order
    
    for i in range(n):
        if i not in visited:
            dfs(i)
    
    return stack[::-1]  # Reverse post-order
```

### 2. BFS-based (Kahn's Algorithm)

```python
def topo_sort_bfs(graph, n):
    in_degree = [0] * n
    for u in graph:
        for v in graph[u]:
            in_degree[v] += 1
    
    queue = deque([i for i in range(n) if in_degree[i] == 0])
    result = []
    
    while queue:
        node = queue.popleft()
        result.append(node)
        
        for neighbor in graph[node]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)
    
    return result if len(result) == n else []  # Empty if cycle exists
```

## Dry Run - Kahn's Algorithm

```
Graph: 5->0, 5->2, 4->0, 4->1, 2->3, 3->1

Step 1: Calculate in-degrees
  in_degree = [2, 2, 1, 1, 0, 0]  (for vertices 0-5)
  Vertices with in_degree=0: [4, 5]
  Queue = [4, 5]

Step 2: Process 4
  Remove edges: 4->0, 4->1
  in_degree = [1, 1, 1, 1, -, -]
  Queue = [5]
  Result = [4]

Step 3: Process 5
  Remove edges: 5->0, 5->2
  in_degree = [0, 1, 0, 1, -, -]
  New zero: 0, 2
  Queue = [0, 2]
  Result = [4, 5]

Step 4: Process 0
  No outgoing edges
  Queue = [2]
  Result = [4, 5, 0]

Step 5: Process 2
  Remove edge: 2->3
  in_degree[3] = 0
  Queue = [3]
  Result = [4, 5, 0, 2]

Step 6: Process 3
  Remove edge: 3->1
  in_degree[1] = 0
  Queue = [1]
  Result = [4, 5, 0, 2, 3]

Step 7: Process 1
  Queue = []
  Result = [4, 5, 0, 2, 3, 1]

Final: [4, 5, 0, 2, 3, 1]
```

## Time & Space Complexity

| Approach | Time | Space |
|----------|------|-------|
| DFS | O(V + E) | O(V) |
| BFS (Kahn) | O(V + E) | O(V) |

## Key Points

1. **Only works on DAGs** - no cycles allowed
2. **Multiple valid orderings** possible
3. **DFS approach**: Reverse of post-order traversal
4. **BFS approach**: Process vertices with in-degree 0 first
5. BFS can **detect cycles** (if result length < n vertices)
