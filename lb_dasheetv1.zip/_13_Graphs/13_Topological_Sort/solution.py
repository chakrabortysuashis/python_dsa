"""
Problem: Implement Topological Sort
===================================

Order vertices in DAG such that for edge (u,v), u comes before v.

Two approaches:
1. DFS: Reverse post-order
2. BFS: Kahn's algorithm (in-degree)

Time: O(V + E)
Space: O(V)
"""

from collections import deque, defaultdict
from typing import List, Dict


def topo_sort_dfs(n: int, graph: Dict[int, List[int]]) -> List[int]:
    """DFS-based topological sort (reverse post-order)."""
    visited = set()
    stack = []

    def dfs(node: int) -> None:
        visited.add(node)
        for neighbor in graph.get(node, []):
            if neighbor not in visited:
                dfs(neighbor)
        stack.append(node)  # Post-order

    for i in range(n):
        if i not in visited:
            dfs(i)

    return stack[::-1]  # Reverse post-order


def topo_sort_kahn(n: int, graph: Dict[int, List[int]]) -> List[int]:
    """BFS-based (Kahn's algorithm) using in-degree."""
    # Calculate in-degrees
    in_degree = [0] * n
    for u in range(n):
        for v in graph.get(u, []):
            in_degree[v] += 1

    # Start with vertices having in-degree 0
    queue = deque([i for i in range(n) if in_degree[i] == 0])
    result = []

    while queue:
        node = queue.popleft()
        result.append(node)

        for neighbor in graph.get(node, []):
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)

    # If result doesn't contain all vertices, graph has a cycle
    return result if len(result) == n else []


def topo_sort_kahn_trace(n: int, graph: Dict[int, List[int]]) -> List[int]:
    """Kahn's algorithm with detailed trace."""
    print(f"\n{'='*50}")
    print("Topological Sort - Kahn's Algorithm")
    print(f"{'='*50}")

    # Calculate in-degrees
    in_degree = [0] * n
    for u in range(n):
        for v in graph.get(u, []):
            in_degree[v] += 1

    print(f"\nIn-degrees: {in_degree}")

    queue = deque([i for i in range(n) if in_degree[i] == 0])
    result = []

    print(f"Initial queue (in-degree=0): {list(queue)}")

    step = 0
    while queue:
        step += 1
        node = queue.popleft()
        result.append(node)

        print(f"\nStep {step}: Process node {node}")
        print(f"  Result: {result}")

        for neighbor in graph.get(node, []):
            in_degree[neighbor] -= 1
            print(f"  Decrement in_degree[{neighbor}] -> {in_degree[neighbor]}")

            if in_degree[neighbor] == 0:
                queue.append(neighbor)
                print(f"  Add {neighbor} to queue")

        print(f"  Queue: {list(queue)}")

    print(f"\n{'='*50}")
    if len(result) == n:
        print(f"Topological order: {result}")
    else:
        print("CYCLE DETECTED! No valid topological order.")

    return result if len(result) == n else []


# Test
if __name__ == "__main__":
    # DAG: 5->0, 5->2, 4->0, 4->1, 2->3, 3->1
    graph = {
        5: [0, 2],
        4: [0, 1],
        2: [3],
        3: [1],
        0: [],
        1: []
    }

    print("DFS approach:", topo_sort_dfs(6, graph))
    print("\nKahn's approach (BFS):")
    topo_sort_kahn_trace(6, graph)

    # Test with cycle
    print("\n\n--- Testing graph with CYCLE ---")
    cyclic = {0: [1], 1: [2], 2: [0]}
    result = topo_sort_kahn(3, cyclic)
    print(f"Result for cyclic graph: {result if result else 'No valid order (cycle)'}")
