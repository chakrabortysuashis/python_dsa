# Making Wired Connections

## Problem Statement

There are n computers numbered from 0 to n-1 connected by ethernet cables. Given connections where connections[i] = [a, b] represents a connection between computers a and b, return the minimum number of times you need to change a cable to make all computers connected. If impossible, return -1.

## Key Insight

1. **Minimum cables needed**: To connect n computers, we need at least n-1 cables
2. **Extra cables**: If there are cycles, we have extra cables
3. **Connected components**: Each extra cable can connect one additional component

```
Formula:
- If cables < n-1: Impossible, return -1
- Else: Answer = number of connected components - 1
```

## Example

```
n = 6, connections = [[0,1], [0,2], [0,3], [1,2], [1,3]]

Graph:
    0---1
   /|\ /|
  2 | X |
     |/ \|
    3    (4, 5 disconnected)

Components: {0,1,2,3}, {4}, {5} = 3 components
Cables: 5 (need 5 minimum for 6 computers)
Extra cables: 5 - 3 + 1 = 3 (within component 0-1-2-3)

Answer: 3 - 1 = 2 cables to reconnect
```

## Solution: Count Components with Union-Find or BFS/DFS

### Union-Find Approach
```python
def make_connected(n, connections):
    if len(connections) < n - 1:
        return -1  # Not enough cables
    
    parent = list(range(n))
    
    def find(x):
        if parent[x] != x:
            parent[x] = find(parent[x])
        return parent[x]
    
    def union(x, y):
        px, py = find(x), find(y)
        if px != py:
            parent[px] = py
    
    for a, b in connections:
        union(a, b)
    
    # Count unique components
    components = len(set(find(i) for i in range(n)))
    return components - 1
```

### BFS/DFS Approach
```python
def make_connected(n, connections):
    if len(connections) < n - 1:
        return -1
    
    # Build adjacency list
    graph = defaultdict(list)
    for a, b in connections:
        graph[a].append(b)
        graph[b].append(a)
    
    # Count components using BFS
    visited = set()
    components = 0
    
    for i in range(n):
        if i not in visited:
            components += 1
            queue = deque([i])
            visited.add(i)
            while queue:
                node = queue.popleft()
                for neighbor in graph[node]:
                    if neighbor not in visited:
                        visited.add(neighbor)
                        queue.append(neighbor)
    
    return components - 1
```

## Time & Space Complexity

| Approach | Time | Space |
|----------|------|-------|
| Union-Find | O(n + m * alpha(n)) | O(n) |
| BFS/DFS | O(n + m) | O(n + m) |

Where m = number of connections
