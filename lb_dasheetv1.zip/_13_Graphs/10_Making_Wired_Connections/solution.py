"""
Problem: Making Wired Connections
=================================

Connect n computers with minimum cable changes.
Need at least n-1 cables. Answer = components - 1.

Time: O(n + m)
Space: O(n)
"""

from collections import defaultdict, deque
from typing import List


def make_connected_union_find(n: int, connections: List[List[int]]) -> int:
    """Union-Find approach."""
    if len(connections) < n - 1:
        return -1

    parent = list(range(n))
    rank = [0] * n

    def find(x: int) -> int:
        if parent[x] != x:
            parent[x] = find(parent[x])
        return parent[x]

    def union(x: int, y: int) -> None:
        px, py = find(x), find(y)
        if px != py:
            if rank[px] < rank[py]:
                px, py = py, px
            parent[py] = px
            if rank[px] == rank[py]:
                rank[px] += 1

    for a, b in connections:
        union(a, b)

    components = len(set(find(i) for i in range(n)))
    return components - 1


def make_connected_bfs(n: int, connections: List[List[int]]) -> int:
    """BFS approach to count components."""
    if len(connections) < n - 1:
        return -1

    graph = defaultdict(list)
    for a, b in connections:
        graph[a].append(b)
        graph[b].append(a)

    visited = set()
    components = 0

    for i in range(n):
        if i not in visited:
            components += 1
            queue = deque([i])
            visited.add(i)

            while queue:
                node = queue.popleft()
                for neighbor in graph[node]:
                    if neighbor not in visited:
                        visited.add(neighbor)
                        queue.append(neighbor)

    return components - 1


# Test
if __name__ == "__main__":
    # Test 1: Can be connected
    n1 = 6
    conn1 = [[0,1], [0,2], [0,3], [1,2], [1,3]]
    print(f"n={n1}, connections={conn1}")
    print(f"Operations needed: {make_connected_bfs(n1, conn1)}")  # 2

    # Test 2: Not enough cables
    n2 = 6
    conn2 = [[0,1], [0,2], [0,3], [1,2]]
    print(f"\nn={n2}, connections={conn2}")
    print(f"Operations needed: {make_connected_union_find(n2, conn2)}")  # -1

    # Test 3: Already connected
    n3 = 4
    conn3 = [[0,1], [0,2], [1,2], [2,3]]
    print(f"\nn={n3}, connections={conn3}")
    print(f"Operations needed: {make_connected_bfs(n3, conn3)}")  # 0
