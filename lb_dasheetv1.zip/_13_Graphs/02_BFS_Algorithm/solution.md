# Implement BFS Algorithm

## Problem Statement

Implement Breadth-First Search (BFS) algorithm to traverse a graph. Starting from a source vertex, visit all reachable vertices in level-order (closest vertices first).

## Graph Visualization

```
Example Graph:
        0
       / \
      1   2
     /|   |\
    3 4   5 6

Adjacency List:
0: [1, 2]
1: [0, 3, 4]
2: [0, 5, 6]
3: [1]
4: [1]
5: [2]
6: [2]
```

## BFS Concept

BFS explores the graph **level by level** using a **Queue (FIFO)**:
1. Visit all nodes at distance 1 from source
2. Then all nodes at distance 2
3. And so on...

```
BFS Order from vertex 0:

Level 0: [0]           Distance 0
Level 1: [1, 2]        Distance 1
Level 2: [3, 4, 5, 6]  Distance 2

Traversal: 0 -> 1 -> 2 -> 3 -> 4 -> 5 -> 6
```

## Algorithm

```
BFS(graph, start):
    1. Create empty queue and visited set
    2. Add start to queue and mark as visited
    3. While queue is not empty:
        a. Dequeue front vertex (current)
        b. Process current vertex
        c. For each neighbor of current:
            - If not visited:
                - Mark as visited
                - Enqueue neighbor
```

## Step-by-Step Dry Run

### Graph:
```
    0 --- 1 --- 4
    |     |
    2 --- 3
```

### BFS from vertex 0:

```
INITIALIZATION:
Queue: [0]
Visited: {0}
Result: []

STEP 1:
Action: Dequeue 0
Process: Add 0 to result
Neighbors of 0: [1, 2]
  - 1 not visited -> Mark visited, Enqueue
  - 2 not visited -> Mark visited, Enqueue

Queue: [1, 2]      <- After step
Visited: {0, 1, 2}
Result: [0]

STEP 2:
Action: Dequeue 1
Process: Add 1 to result
Neighbors of 1: [0, 3, 4]
  - 0 already visited -> Skip
  - 3 not visited -> Mark visited, Enqueue
  - 4 not visited -> Mark visited, Enqueue

Queue: [2, 3, 4]
Visited: {0, 1, 2, 3, 4}
Result: [0, 1]

STEP 3:
Action: Dequeue 2
Process: Add 2 to result
Neighbors of 2: [0, 3]
  - 0 already visited -> Skip
  - 3 already visited -> Skip

Queue: [3, 4]
Visited: {0, 1, 2, 3, 4}
Result: [0, 1, 2]

STEP 4:
Action: Dequeue 3
Process: Add 3 to result
Neighbors of 3: [1, 2]
  - All already visited -> Skip

Queue: [4]
Visited: {0, 1, 2, 3, 4}
Result: [0, 1, 2, 3]

STEP 5:
Action: Dequeue 4
Process: Add 4 to result
Neighbors of 4: [1]
  - 1 already visited -> Skip

Queue: []          <- Empty, BFS complete!
Visited: {0, 1, 2, 3, 4}
Result: [0, 1, 2, 3, 4]

FINAL OUTPUT: 0 -> 1 -> 2 -> 3 -> 4
```

## Queue State Visualization

```
Step | Action      | Queue State      | Visited Set
-----|-------------|------------------|------------------
  0  | Initialize  | [0]              | {0}
  1  | Dequeue 0   | [] -> [1,2]      | {0,1,2}
  2  | Dequeue 1   | [2] -> [2,3,4]   | {0,1,2,3,4}
  3  | Dequeue 2   | [3,4]            | {0,1,2,3,4}
  4  | Dequeue 3   | [4]              | {0,1,2,3,4}
  5  | Dequeue 4   | []               | {0,1,2,3,4}
```

## Why Use Queue (FIFO)?

```
Queue ensures level-by-level exploration:

           0              Level 0: Process first
         /   \
        1     2           Level 1: Added to queue, processed after 0
       / \   / \
      3   4 5   6         Level 2: Added after level 1, processed last

Queue progression:
[0] -> [1,2] -> [2,3,4] -> [3,4,5,6] -> ...

First In, First Out = Closer nodes processed first!
```

## BFS Applications

| Application | Why BFS? |
|-------------|----------|
| Shortest path (unweighted) | Finds minimum edges to reach target |
| Level-order traversal | Natural level-by-level exploration |
| Connected components | Can visit all nodes in component |
| Bipartite check | Level-based coloring |
| Minimum moves in puzzles | Each move = one level |

## Code Template

```python
from collections import deque

def bfs(graph, start):
    visited = set()
    queue = deque([start])
    visited.add(start)
    result = []

    while queue:
        # Dequeue front vertex
        vertex = queue.popleft()
        result.append(vertex)

        # Process all neighbors
        for neighbor in graph[vertex]:
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)

    return result
```

## Time & Space Complexity

| Metric | Complexity | Explanation |
|--------|------------|-------------|
| Time | O(V + E) | Visit each vertex once, check each edge once |
| Space | O(V) | Queue can hold at most V vertices |

Where:
- V = Number of vertices
- E = Number of edges

### Detailed Analysis:

```
Time Complexity Breakdown:
- Each vertex is enqueued once: O(V)
- Each vertex is dequeued once: O(V)
- For each vertex, we check all its neighbors: O(E) total
- Total: O(V + E)

Space Complexity Breakdown:
- Visited set: O(V)
- Queue: O(V) in worst case (all vertices at same level)
- Result array: O(V)
- Total: O(V)
```

## Common Variations

### 1. BFS with Level Tracking
```python
def bfs_levels(graph, start):
    visited = set([start])
    queue = deque([start])
    levels = []

    while queue:
        level_size = len(queue)
        current_level = []

        for _ in range(level_size):
            vertex = queue.popleft()
            current_level.append(vertex)

            for neighbor in graph[vertex]:
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(neighbor)

        levels.append(current_level)

    return levels
```

### 2. BFS for Shortest Path
```python
def shortest_path(graph, start, end):
    visited = set([start])
    queue = deque([(start, [start])])

    while queue:
        vertex, path = queue.popleft()

        if vertex == end:
            return path

        for neighbor in graph[vertex]:
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append((neighbor, path + [neighbor]))

    return []  # No path found
```

## Key Points

1. **Use deque** for O(1) popleft operation (list.pop(0) is O(n))
2. **Mark visited when enqueuing**, not when dequeuing (prevents duplicates in queue)
3. BFS finds **shortest path** in unweighted graphs
4. BFS explores **level by level** (all nodes at distance k before distance k+1)
5. Works for both **directed and undirected** graphs

## Edge Cases

1. **Disconnected graph**: BFS only visits vertices reachable from start
2. **Single vertex**: Returns [start]
3. **Isolated vertex**: Returns [start] with no neighbors to process
4. **Cycle in graph**: Handled by visited set
