"""
Problem: Implement BFS Algorithm
================================

Implement Breadth-First Search to traverse a graph level by level.

Algorithm:
1. Use a Queue (FIFO) data structure
2. Start from source, add to queue, mark visited
3. While queue not empty:
   - Dequeue front vertex
   - Process vertex
   - Enqueue all unvisited neighbors

Time Complexity: O(V + E)
Space Complexity: O(V)
"""

from collections import deque, defaultdict
from typing import List, Dict, Set, Tuple, Optional


def bfs_basic(graph: Dict[int, List[int]], start: int) -> List[int]:
    """
    Basic BFS traversal.

    Args:
        graph: Adjacency list representation
        start: Starting vertex

    Returns:
        List of vertices in BFS order

    Example:
        >>> graph = {0: [1, 2], 1: [0, 3], 2: [0, 3], 3: [1, 2]}
        >>> bfs_basic(graph, 0)
        [0, 1, 2, 3]
    """
    if start not in graph:
        return []

    visited = set()
    queue = deque([start])
    visited.add(start)
    result = []

    while queue:
        # Dequeue front vertex (FIFO)
        vertex = queue.popleft()
        result.append(vertex)

        # Process all neighbors
        for neighbor in graph[vertex]:
            if neighbor not in visited:
                visited.add(neighbor)  # Mark visited when enqueuing!
                queue.append(neighbor)

    return result


def bfs_with_trace(graph: Dict[int, List[int]], start: int) -> List[int]:
    """
    BFS with detailed step-by-step trace.

    Shows queue state at each step.
    """
    if start not in graph:
        return []

    visited = set()
    queue = deque([start])
    visited.add(start)
    result = []

    print("\n" + "=" * 60)
    print(f"BFS Traversal from vertex {start}")
    print("=" * 60)
    print(f"\nInitialization:")
    print(f"  Queue: {list(queue)}")
    print(f"  Visited: {visited}")

    step = 1
    while queue:
        print(f"\n{'─' * 40}")
        print(f"Step {step}:")

        # Show queue before dequeue
        print(f"  Queue (before): {list(queue)}")

        # Dequeue front vertex
        vertex = queue.popleft()
        result.append(vertex)
        print(f"  Dequeue: {vertex}")
        print(f"  Result so far: {result}")

        # Process neighbors
        print(f"  Neighbors of {vertex}: {graph[vertex]}")
        new_neighbors = []

        for neighbor in graph[vertex]:
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)
                new_neighbors.append(neighbor)
                print(f"    - {neighbor}: Not visited, enqueue")
            else:
                print(f"    - {neighbor}: Already visited, skip")

        print(f"  Queue (after): {list(queue)}")
        print(f"  Visited set: {visited}")

        step += 1

    print(f"\n{'=' * 60}")
    print(f"BFS Complete!")
    print(f"Traversal order: {' -> '.join(map(str, result))}")
    print(f"Total vertices visited: {len(result)}")
    print("=" * 60 + "\n")

    return result


def bfs_level_order(graph: Dict[int, List[int]], start: int) -> List[List[int]]:
    """
    BFS with level separation.

    Returns vertices grouped by their distance from start.

    Example:
        Level 0: [start]
        Level 1: [neighbors of start]
        Level 2: [neighbors of level 1]
        ...
    """
    if start not in graph:
        return []

    visited = set([start])
    queue = deque([start])
    levels = []

    print("\n" + "=" * 50)
    print(f"BFS Level Order from vertex {start}")
    print("=" * 50)

    level_num = 0
    while queue:
        level_size = len(queue)
        current_level = []

        print(f"\nLevel {level_num}:")
        print(f"  Processing {level_size} node(s)")

        for _ in range(level_size):
            vertex = queue.popleft()
            current_level.append(vertex)

            for neighbor in graph[vertex]:
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(neighbor)

        levels.append(current_level)
        print(f"  Nodes at this level: {current_level}")
        level_num += 1

    print(f"\nLevels: {levels}")
    return levels


def bfs_shortest_path(
    graph: Dict[int, List[int]],
    start: int,
    end: int
) -> Tuple[int, List[int]]:
    """
    Find shortest path between two vertices using BFS.

    BFS guarantees shortest path in unweighted graphs because
    it explores all vertices at distance k before distance k+1.

    Returns:
        Tuple of (distance, path)
        Returns (-1, []) if no path exists
    """
    if start not in graph or end not in graph:
        return (-1, [])

    if start == end:
        return (0, [start])

    visited = set([start])
    # Queue stores (vertex, path_to_vertex)
    queue = deque([(start, [start])])

    print(f"\nFinding shortest path from {start} to {end}")
    print("-" * 40)

    while queue:
        vertex, path = queue.popleft()
        print(f"At vertex {vertex}, path so far: {path}")

        for neighbor in graph[vertex]:
            if neighbor == end:
                final_path = path + [neighbor]
                print(f"Found target! Path: {final_path}")
                return (len(path), final_path)

            if neighbor not in visited:
                visited.add(neighbor)
                queue.append((neighbor, path + [neighbor]))

    print("No path found!")
    return (-1, [])


def bfs_distance_from_source(
    graph: Dict[int, List[int]],
    start: int
) -> Dict[int, int]:
    """
    Calculate distance from source to all reachable vertices.

    Returns dictionary mapping vertex -> distance from start.
    """
    if start not in graph:
        return {}

    distances = {start: 0}
    queue = deque([start])

    while queue:
        vertex = queue.popleft()

        for neighbor in graph[vertex]:
            if neighbor not in distances:
                distances[neighbor] = distances[vertex] + 1
                queue.append(neighbor)

    return distances


def bfs_connected_component(
    graph: Dict[int, List[int]],
    start: int
) -> Set[int]:
    """
    Find all vertices in the connected component containing start.
    """
    if start not in graph:
        return set()

    component = set()
    queue = deque([start])
    component.add(start)

    while queue:
        vertex = queue.popleft()

        for neighbor in graph[vertex]:
            if neighbor not in component:
                component.add(neighbor)
                queue.append(neighbor)

    return component


def bfs_all_paths(
    graph: Dict[int, List[int]],
    start: int,
    end: int
) -> List[List[int]]:
    """
    Find all paths from start to end using BFS.

    Note: This can be expensive for graphs with many paths!
    """
    if start not in graph or end not in graph:
        return []

    all_paths = []
    # Queue stores (current_vertex, current_path)
    queue = deque([(start, [start])])

    while queue:
        vertex, path = queue.popleft()

        if vertex == end:
            all_paths.append(path)
            continue

        for neighbor in graph[vertex]:
            if neighbor not in path:  # Avoid cycles in path
                queue.append((neighbor, path + [neighbor]))

    return all_paths


# =============================================================================
# Test Cases
# =============================================================================

def test_basic_bfs():
    """Test basic BFS traversal."""
    print("\n" + "=" * 60)
    print("TEST: Basic BFS Traversal")
    print("=" * 60)

    # Create graph:
    #     0 --- 1 --- 4
    #     |     |
    #     2 --- 3

    graph = {
        0: [1, 2],
        1: [0, 3, 4],
        2: [0, 3],
        3: [1, 2],
        4: [1]
    }

    print("\nGraph:")
    print("    0 --- 1 --- 4")
    print("    |     |")
    print("    2 --- 3")

    result = bfs_with_trace(graph, 0)
    print(f"\nBFS from 0: {result}")


def test_level_order():
    """Test BFS level order traversal."""
    print("\n" + "=" * 60)
    print("TEST: BFS Level Order")
    print("=" * 60)

    # Tree-like graph:
    #        0
    #      /   \
    #     1     2
    #    / \   / \
    #   3   4 5   6

    graph = {
        0: [1, 2],
        1: [0, 3, 4],
        2: [0, 5, 6],
        3: [1],
        4: [1],
        5: [2],
        6: [2]
    }

    print("\nGraph (tree-like):")
    print("       0")
    print("     /   \\")
    print("    1     2")
    print("   / \\   / \\")
    print("  3   4 5   6")

    levels = bfs_level_order(graph, 0)
    print(f"\nLevel order: {levels}")
    # Expected: [[0], [1, 2], [3, 4, 5, 6]]


def test_shortest_path():
    """Test BFS shortest path."""
    print("\n" + "=" * 60)
    print("TEST: Shortest Path (BFS)")
    print("=" * 60)

    graph = {
        0: [1, 2],
        1: [0, 3],
        2: [0, 3, 4],
        3: [1, 2, 5],
        4: [2, 5],
        5: [3, 4]
    }

    print("\nGraph:")
    print("  0 --- 1")
    print("  |     |")
    print("  2 --- 3 --- 5")
    print("  |           |")
    print("  4 ----------+")

    distance, path = bfs_shortest_path(graph, 0, 5)
    print(f"\nShortest path from 0 to 5:")
    print(f"  Distance: {distance}")
    print(f"  Path: {' -> '.join(map(str, path))}")


def test_distances():
    """Test distance calculation from source."""
    print("\n" + "=" * 60)
    print("TEST: Distances from Source")
    print("=" * 60)

    graph = {
        0: [1, 2],
        1: [0, 3, 4],
        2: [0, 3],
        3: [1, 2, 5],
        4: [1],
        5: [3]
    }

    distances = bfs_distance_from_source(graph, 0)
    print(f"\nDistances from vertex 0:")
    for vertex in sorted(distances.keys()):
        print(f"  Vertex {vertex}: distance = {distances[vertex]}")


def test_disconnected_graph():
    """Test BFS on disconnected graph."""
    print("\n" + "=" * 60)
    print("TEST: Disconnected Graph")
    print("=" * 60)

    # Two separate components
    graph = {
        0: [1, 2],
        1: [0, 2],
        2: [0, 1],
        # Component 2 (disconnected)
        3: [4],
        4: [3]
    }

    print("\nGraph with two components:")
    print("  Component 1: 0-1-2")
    print("  Component 2: 3-4")

    # BFS from 0 only reaches component 1
    result = bfs_basic(graph, 0)
    print(f"\nBFS from 0: {result}")
    print("Note: BFS only visits reachable vertices!")

    # Find connected component
    component = bfs_connected_component(graph, 0)
    print(f"Connected component containing 0: {component}")


if __name__ == "__main__":
    test_basic_bfs()
    test_level_order()
    test_shortest_path()
    test_distances()
    test_disconnected_graph()
