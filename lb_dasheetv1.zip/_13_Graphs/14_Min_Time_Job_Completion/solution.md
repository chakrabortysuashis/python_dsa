# Minimum Time for Job Completion (DAG)

## Problem Statement

Given n jobs with dependencies represented as a DAG, find the minimum time to complete all jobs. Each job has a duration, and a job can only start after all its prerequisites are complete.

## Approach: Topological Sort + Dynamic Programming

This is the **Critical Path Method** - find the longest path in the DAG.

```
min_time[job] = job_duration + max(min_time[prerequisite] for all prerequisites)
```

## Example

```
Jobs: A(3), B(2), C(4), D(1)
Dependencies: A->C, B->C, C->D

DAG:
    A(3)
        \
         --> C(4) --> D(1)
        /
    B(2)

Timeline:
  A: [0, 3)
  B: [0, 2)
  C: [3, 7)   (starts after A finishes at time 3)
  D: [7, 8)   (starts after C finishes at time 7)

Minimum time: 8
```

## Algorithm

```python
def min_time_to_complete(n, durations, dependencies):
    # Build graph and calculate in-degrees
    graph = defaultdict(list)
    in_degree = [0] * n
    
    for prereq, job in dependencies:
        graph[prereq].append(job)
        in_degree[job] += 1
    
    # completion[i] = earliest completion time for job i
    completion = durations[:]
    
    # Process in topological order
    queue = deque([i for i in range(n) if in_degree[i] == 0])
    
    while queue:
        job = queue.popleft()
        
        for next_job in graph[job]:
            # Update completion time: max of all prerequisites + duration
            completion[next_job] = max(
                completion[next_job],
                completion[job] + durations[next_job]
            )
            
            in_degree[next_job] -= 1
            if in_degree[next_job] == 0:
                queue.append(next_job)
    
    return max(completion)
```

## Dry Run

```
Jobs: 0(3), 1(2), 2(4), 3(1)
Dependencies: (0,2), (1,2), (2,3)

Initial:
  completion = [3, 2, 4, 1]
  in_degree = [0, 0, 2, 1]
  Queue = [0, 1]

Step 1: Process job 0
  Update job 2: completion[2] = max(4, 3+4) = 7
  in_degree[2] = 1
  Queue = [1]

Step 2: Process job 1
  Update job 2: completion[2] = max(7, 2+4) = 7
  in_degree[2] = 0 -> add to queue
  Queue = [2]

Step 3: Process job 2
  Update job 3: completion[3] = max(1, 7+1) = 8
  in_degree[3] = 0 -> add to queue
  Queue = [3]

Step 4: Process job 3
  No dependents
  Queue = []

Final: completion = [3, 2, 7, 8]
Minimum time = max(completion) = 8
```

## Time & Space Complexity

| Metric | Complexity |
|--------|------------|
| Time | O(V + E) |
| Space | O(V) |

## Key Points

1. This is finding the **longest path** in a DAG
2. Use **topological order** to ensure prerequisites processed first
3. Track **completion time**, not just order
4. Answer is `max(all completion times)`
