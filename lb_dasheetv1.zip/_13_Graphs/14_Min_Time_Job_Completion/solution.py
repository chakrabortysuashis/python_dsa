"""
Problem: Minimum Time for Job Completion (DAG)
==============================================

Find minimum time to complete all jobs given dependencies.
Uses Critical Path Method: longest path in DAG.

Time: O(V + E)
Space: O(V)
"""

from collections import deque, defaultdict
from typing import List, Tuple, Dict


def min_time_to_complete(n: int, durations: List[int],
                         dependencies: List[Tuple[int, int]]) -> int:
    """
    Calculate minimum time to complete all jobs.

    Args:
        n: Number of jobs (0 to n-1)
        durations: Duration of each job
        dependencies: List of (prerequisite, job) pairs

    Returns:
        Minimum time to complete all jobs
    """
    # Build graph and in-degrees
    graph = defaultdict(list)
    in_degree = [0] * n

    for prereq, job in dependencies:
        graph[prereq].append(job)
        in_degree[job] += 1

    # completion[i] = earliest completion time for job i
    completion = durations[:]

    # Process in topological order (Kahn's algorithm)
    queue = deque([i for i in range(n) if in_degree[i] == 0])

    while queue:
        job = queue.popleft()

        for next_job in graph[job]:
            # Next job starts after current job completes
            completion[next_job] = max(
                completion[next_job],
                completion[job] + durations[next_job]
            )

            in_degree[next_job] -= 1
            if in_degree[next_job] == 0:
                queue.append(next_job)

    return max(completion)


def min_time_with_trace(n: int, durations: List[int],
                        dependencies: List[Tuple[int, int]]) -> int:
    """With detailed trace."""
    print(f"\n{'='*50}")
    print("Minimum Time for Job Completion")
    print(f"{'='*50}")
    print(f"Jobs: {n}, Durations: {durations}")
    print(f"Dependencies: {dependencies}")

    graph = defaultdict(list)
    in_degree = [0] * n

    for prereq, job in dependencies:
        graph[prereq].append(job)
        in_degree[job] += 1

    completion = durations[:]
    start_time = [0] * n

    print(f"\nInitial completion times: {completion}")
    print(f"In-degrees: {in_degree}")

    queue = deque([i for i in range(n) if in_degree[i] == 0])
    print(f"Jobs with no prerequisites: {list(queue)}")

    while queue:
        job = queue.popleft()
        print(f"\nProcess job {job} (duration={durations[job]})")
        print(f"  Starts at: {start_time[job]}, Completes at: {completion[job]}")

        for next_job in graph[job]:
            old_completion = completion[next_job]
            new_start = completion[job]
            new_completion = new_start + durations[next_job]

            if new_completion > completion[next_job]:
                start_time[next_job] = new_start
                completion[next_job] = new_completion
                print(f"  Update job {next_job}: start={new_start}, complete={new_completion}")

            in_degree[next_job] -= 1
            if in_degree[next_job] == 0:
                queue.append(next_job)

    print(f"\nFinal completion times: {completion}")
    result = max(completion)
    print(f"Minimum time to complete all: {result}")

    return result


# Test
if __name__ == "__main__":
    # Example: A(3)->C, B(2)->C, C(4)->D(1)
    # Jobs: 0=A, 1=B, 2=C, 3=D
    n = 4
    durations = [3, 2, 4, 1]
    dependencies = [(0, 2), (1, 2), (2, 3)]

    result = min_time_with_trace(n, durations, dependencies)

    # Parallel jobs example
    print("\n" + "="*50)
    print("Parallel jobs (no dependencies)")
    result2 = min_time_to_complete(3, [5, 3, 4], [])
    print(f"Durations: [5, 3, 4], Dependencies: []")
    print(f"Min time (all parallel): {result2}")  # 5 (longest job)
