# Clone a Graph

## Problem Statement

Given a reference of a node in a connected undirected graph, return a deep copy (clone) of the graph. Each node contains a value and a list of its neighbors.

## Approach: BFS or DFS with HashMap

The key insight is to use a **HashMap** to map original nodes to their clones, preventing infinite loops and ensuring each node is cloned exactly once.

## BFS Solution

```python
def clone_graph_bfs(node):
    if not node:
        return None
    
    clones = {node: Node(node.val)}  # Map original -> clone
    queue = deque([node])
    
    while queue:
        curr = queue.popleft()
        
        for neighbor in curr.neighbors:
            if neighbor not in clones:
                clones[neighbor] = Node(neighbor.val)
                queue.append(neighbor)
            
            # Connect clone's neighbor
            clones[curr].neighbors.append(clones[neighbor])
    
    return clones[node]
```

## DFS Solution

```python
def clone_graph_dfs(node):
    if not node:
        return None
    
    clones = {}
    
    def dfs(original):
        if original in clones:
            return clones[original]
        
        clone = Node(original.val)
        clones[original] = clone
        
        for neighbor in original.neighbors:
            clone.neighbors.append(dfs(neighbor))
        
        return clone
    
    return dfs(node)
```

## Dry Run

```
Original Graph:
    1 --- 2
    |     |
    4 --- 3

BFS Steps:
1. Start with node 1, create clone of 1
   clones = {1: Clone(1)}
   Queue = [1]

2. Process node 1, neighbors: [2, 4]
   - Clone 2, add to map
   - Clone 4, add to map
   - Connect Clone(1).neighbors = [Clone(2), Clone(4)]
   Queue = [2, 4]

3. Process node 2, neighbors: [1, 3]
   - 1 already cloned
   - Clone 3, add to map
   - Connect Clone(2).neighbors = [Clone(1), Clone(3)]
   Queue = [4, 3]

4. Process node 4, neighbors: [1, 3]
   - 1, 3 already cloned
   - Connect Clone(4).neighbors = [Clone(1), Clone(3)]
   Queue = [3]

5. Process node 3, neighbors: [2, 4]
   - 2, 4 already cloned
   - Connect Clone(3).neighbors = [Clone(2), Clone(4)]
   Queue = []

Done! Return Clone(1)
```

## Time & Space Complexity

| Metric | Complexity |
|--------|------------|
| Time | O(V + E) |
| Space | O(V) |

## Key Points

1. **HashMap** prevents infinite loops and duplicate clones
2. Clone node when first encountered
3. Connect neighbors after cloning
4. Handle null input
