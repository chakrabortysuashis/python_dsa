"""
Problem: Clone a Graph
======================

Deep copy an undirected graph. Each node has value and neighbors list.

Key: Use HashMap to map original nodes to clones.

Time: O(V + E)
Space: O(V)
"""

from collections import deque
from typing import Optional, Dict


class Node:
    def __init__(self, val: int = 0, neighbors: list = None):
        self.val = val
        self.neighbors = neighbors if neighbors is not None else []


def clone_graph_bfs(node: Optional[Node]) -> Optional[Node]:
    """Clone using BFS."""
    if not node:
        return None

    clones: Dict[Node, Node] = {node: Node(node.val)}
    queue = deque([node])

    while queue:
        curr = queue.popleft()

        for neighbor in curr.neighbors:
            if neighbor not in clones:
                clones[neighbor] = Node(neighbor.val)
                queue.append(neighbor)

            clones[curr].neighbors.append(clones[neighbor])

    return clones[node]


def clone_graph_dfs(node: Optional[Node]) -> Optional[Node]:
    """Clone using DFS."""
    if not node:
        return None

    clones: Dict[Node, Node] = {}

    def dfs(original: Node) -> Node:
        if original in clones:
            return clones[original]

        clone = Node(original.val)
        clones[original] = clone

        for neighbor in original.neighbors:
            clone.neighbors.append(dfs(neighbor))

        return clone

    return dfs(node)


def print_graph(node: Optional[Node], name: str = "Graph") -> None:
    """Print graph structure."""
    if not node:
        print(f"{name}: Empty")
        return

    visited = set()
    queue = deque([node])
    visited.add(node)

    print(f"\n{name}:")
    while queue:
        curr = queue.popleft()
        neighbor_vals = [n.val for n in curr.neighbors]
        print(f"  Node {curr.val}: neighbors = {neighbor_vals}")

        for neighbor in curr.neighbors:
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)


# Test
if __name__ == "__main__":
    # Create graph: 1-2-3-4 (square)
    n1, n2, n3, n4 = Node(1), Node(2), Node(3), Node(4)
    n1.neighbors = [n2, n4]
    n2.neighbors = [n1, n3]
    n3.neighbors = [n2, n4]
    n4.neighbors = [n1, n3]

    print_graph(n1, "Original")

    clone = clone_graph_bfs(n1)
    print_graph(clone, "Clone (BFS)")

    # Verify deep copy
    print(f"\nOriginal node 1 id: {id(n1)}")
    print(f"Clone node 1 id: {id(clone)}")
    print(f"Different objects: {n1 is not clone}")
