"""
Problem: Kruskal's Algorithm - Minimum Spanning Tree
====================================================

Find MST using greedy edge selection with Union-Find for cycle detection.

Algorithm:
1. Sort all edges by weight
2. For each edge, if it doesn't create cycle, add to MST
3. Use Union-Find for O(1) cycle detection

Time Complexity: O(E log E) for sorting
Space Complexity: O(V) for Union-Find
"""

from typing import List, Tuple, Optional


class UnionFind:
    """
    Union-Find (Disjoint Set Union) with path compression and union by rank.

    Operations:
    - find(x): Find root of x's set, O(alpha(n))
    - union(x, y): Merge sets, O(alpha(n))

    alpha(n) is inverse Ackermann function, nearly constant.
    """

    def __init__(self, n: int):
        self.parent = list(range(n))
        self.rank = [0] * n
        self.components = n

    def find(self, x: int) -> int:
        """Find root with path compression."""
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])
        return self.parent[x]

    def union(self, x: int, y: int) -> bool:
        """
        Union by rank.
        Returns True if union performed, False if already same set.
        """
        px, py = self.find(x), self.find(y)

        if px == py:
            return False  # Already in same set (would create cycle)

        # Union by rank: attach smaller tree under larger
        if self.rank[px] < self.rank[py]:
            px, py = py, px

        self.parent[py] = px

        if self.rank[px] == self.rank[py]:
            self.rank[px] += 1

        self.components -= 1
        return True

    def connected(self, x: int, y: int) -> bool:
        """Check if x and y are in same set."""
        return self.find(x) == self.find(y)


def kruskal(n: int, edges: List[Tuple[int, int, int]]) -> Tuple[List[Tuple[int, int, int]], int]:
    """
    Kruskal's Algorithm for MST.

    Args:
        n: Number of vertices (0 to n-1)
        edges: List of (u, v, weight) tuples

    Returns:
        Tuple of (MST edges, total weight)

    Example:
        >>> edges = [(0,1,10), (0,2,6), (0,3,5), (1,3,15), (2,3,4)]
        >>> mst, weight = kruskal(4, edges)
        >>> weight
        19
    """
    # Sort edges by weight
    sorted_edges = sorted(edges, key=lambda x: x[2])

    uf = UnionFind(n)
    mst = []
    mst_weight = 0

    for u, v, weight in sorted_edges:
        if uf.union(u, v):  # If no cycle
            mst.append((u, v, weight))
            mst_weight += weight

            # MST complete when we have V-1 edges
            if len(mst) == n - 1:
                break

    return mst, mst_weight


def kruskal_with_trace(n: int, edges: List[Tuple[int, int, int]]) -> Tuple[List[Tuple[int, int, int]], int]:
    """Kruskal's with detailed trace for learning."""
    print("\n" + "=" * 60)
    print("Kruskal's Algorithm - MST Trace")
    print("=" * 60)

    print(f"\nVertices: {n}")
    print(f"Edges: {edges}")

    # Sort edges
    sorted_edges = sorted(edges, key=lambda x: x[2])
    print(f"\nSorted edges (by weight): {sorted_edges}")

    uf = UnionFind(n)
    mst = []
    mst_weight = 0

    print(f"\nInitial Union-Find:")
    print(f"  Parent: {uf.parent}")
    print(f"  Rank: {uf.rank}")

    print("\n--- Processing Edges ---")

    for i, (u, v, weight) in enumerate(sorted_edges):
        print(f"\nEdge {i + 1}: ({u}, {v}, weight={weight})")

        root_u = uf.find(u)
        root_v = uf.find(v)

        print(f"  find({u}) = {root_u}")
        print(f"  find({v}) = {root_v}")

        if root_u != root_v:
            print(f"  Different components -> ADD to MST")
            uf.union(u, v)
            mst.append((u, v, weight))
            mst_weight += weight
            print(f"  MST edges: {mst}")
            print(f"  MST weight: {mst_weight}")
            print(f"  Parent after union: {uf.parent}")

            if len(mst) == n - 1:
                print(f"\n  MST complete (has {n-1} edges)")
                break
        else:
            print(f"  Same component -> SKIP (would create cycle)")

    print(f"\n{'=' * 60}")
    print(f"RESULT")
    print(f"{'=' * 60}")
    print(f"MST Edges: {mst}")
    print(f"MST Weight: {mst_weight}")

    return mst, mst_weight


def maximum_spanning_tree(n: int, edges: List[Tuple[int, int, int]]) -> Tuple[List[Tuple[int, int, int]], int]:
    """
    Maximum Spanning Tree using modified Kruskal's.
    Sort edges in descending order instead.
    """
    sorted_edges = sorted(edges, key=lambda x: -x[2])  # Descending

    uf = UnionFind(n)
    mst = []
    mst_weight = 0

    for u, v, weight in sorted_edges:
        if uf.union(u, v):
            mst.append((u, v, weight))
            mst_weight += weight

            if len(mst) == n - 1:
                break

    return mst, mst_weight


def is_connected_mst(n: int, edges: List[Tuple[int, int, int]]) -> bool:
    """Check if graph is connected (MST exists)."""
    mst, _ = kruskal(n, edges)
    return len(mst) == n - 1


def kruskal_forest(n: int, edges: List[Tuple[int, int, int]]) -> List[List[Tuple[int, int, int]]]:
    """
    For disconnected graph, return MST for each component.
    """
    sorted_edges = sorted(edges, key=lambda x: x[2])
    uf = UnionFind(n)
    mst_edges = []

    for u, v, weight in sorted_edges:
        if uf.union(u, v):
            mst_edges.append((u, v, weight))

    # Group edges by component
    from collections import defaultdict
    component_edges = defaultdict(list)

    for u, v, weight in mst_edges:
        root = uf.find(u)
        component_edges[root].append((u, v, weight))

    return list(component_edges.values())


# =============================================================================
# Graph Visualization Helper
# =============================================================================

def visualize_graph(n: int, edges: List[Tuple[int, int, int]], mst_edges: List[Tuple[int, int, int]] = None):
    """Print ASCII visualization of graph and MST."""
    print("\nGraph Adjacency:")
    adj = [[] for _ in range(n)]
    for u, v, w in edges:
        adj[u].append((v, w))
        adj[v].append((u, w))

    mst_set = set()
    if mst_edges:
        for u, v, w in mst_edges:
            mst_set.add((min(u, v), max(u, v)))

    for i in range(n):
        neighbors = ", ".join(f"{v}(w={w}){'*' if (min(i,v), max(i,v)) in mst_set else ''}"
                             for v, w in sorted(adj[i]))
        print(f"  {i}: [{neighbors}]")

    if mst_edges:
        print("\n  * = MST edge")


# =============================================================================
# Test Cases
# =============================================================================

def test_kruskal():
    """Test Kruskal's algorithm implementations."""
    print("\n" + "=" * 60)
    print("Kruskal's Algorithm - Test Cases")
    print("=" * 60)

    # Test 1: Basic graph
    print("\nTest 1: Basic graph")
    edges1 = [
        (0, 1, 10),
        (0, 2, 6),
        (0, 3, 5),
        (1, 3, 15),
        (2, 3, 4)
    ]

    mst, weight = kruskal(4, edges1)
    print(f"  MST: {mst}")
    print(f"  Weight: {weight}")
    visualize_graph(4, edges1, mst)

    # Test 2: Larger graph
    print("\nTest 2: Larger graph")
    edges2 = [
        (0, 1, 4),
        (0, 7, 8),
        (1, 2, 8),
        (1, 7, 11),
        (2, 3, 7),
        (2, 5, 4),
        (2, 8, 2),
        (3, 4, 9),
        (3, 5, 14),
        (4, 5, 10),
        (5, 6, 2),
        (6, 7, 1),
        (6, 8, 6),
        (7, 8, 7)
    ]

    mst, weight = kruskal(9, edges2)
    print(f"  MST: {mst}")
    print(f"  Weight: {weight}")

    # Test 3: Maximum spanning tree
    print("\nTest 3: Maximum Spanning Tree")
    mst_max, weight_max = maximum_spanning_tree(4, edges1)
    print(f"  Max ST: {mst_max}")
    print(f"  Weight: {weight_max}")

    # Test 4: Disconnected graph
    print("\nTest 4: Disconnected graph (forest)")
    edges4 = [
        (0, 1, 5),
        (1, 2, 3),
        (3, 4, 2),
        (4, 5, 4)
    ]

    forest = kruskal_forest(6, edges4)
    print(f"  Forest components: {forest}")

    print("\nAll tests completed!")


def test_with_trace():
    """Test with detailed trace."""
    edges = [
        (0, 1, 10),
        (0, 2, 6),
        (0, 3, 5),
        (1, 3, 15),
        (2, 3, 4)
    ]
    kruskal_with_trace(4, edges)


if __name__ == "__main__":
    test_kruskal()
    test_with_trace()
