# Kruskal's Algorithm - Minimum Spanning Tree

## Problem Statement

Given a connected, undirected, weighted graph, find the Minimum Spanning Tree (MST) - a subset of edges that connects all vertices with minimum total edge weight, without forming any cycle.

## Graph Visualization

```
Input Graph:
        2
    A-------B
    |\     /|
   4| \3  / |6
    |  \ /  |
    D---C---E
      5   1

Edges sorted by weight:
1. C-E: 1
2. A-B: 2
3. A-C: 3
4. A-D: 4
5. C-D: 5
6. B-E: 6

MST Selection (Kruskal's):
1. C-E: 1 (no cycle) -> ADD
2. A-B: 2 (no cycle) -> ADD
3. A-C: 3 (no cycle) -> ADD
4. A-D: 4 (no cycle) -> ADD
5. C-D: 5 (would create cycle A-C-D-A) -> SKIP
6. B-E: 6 (would create cycle) -> SKIP

MST Weight = 1 + 2 + 3 + 4 = 10
MST Edges: {C-E, A-B, A-C, A-D}
```

## Why Kruskal's Algorithm?

```
Greedy Approach:
+------------------+
| Sort all edges   |
| by weight        |
+------------------+
         |
         v
+------------------+
| For each edge:   |
| If no cycle,     |
| add to MST       |
+------------------+
         |
         v
+------------------+
| Use Union-Find   |
| for cycle        |
| detection        |
+------------------+

Key Insight: Always pick smallest edge that doesn't create cycle
```

## Algorithm

```
Kruskal's MST:
1. Sort all edges by weight (ascending)
2. Initialize Union-Find with V vertices
3. For each edge (u, v, weight) in sorted order:
   a. If find(u) != find(v):  // Different components
      - Add edge to MST
      - union(u, v)
      - MST edges count++
   b. If MST has V-1 edges, stop
4. Return MST edges
```

## Union-Find Data Structure

```
Union-Find Operations:
+------------------+------------------+
| find(x)          | Find root/parent |
|                  | of x's set       |
+------------------+------------------+
| union(x, y)      | Merge sets       |
|                  | containing x, y  |
+------------------+------------------+

Optimizations:
1. Path Compression: Make all nodes point directly to root
2. Union by Rank: Attach smaller tree under larger tree

Time: O(alpha(n)) per operation (nearly constant)
```

## Step-by-Step Dry Run

### Graph:
```
Vertices: {0, 1, 2, 3}
Edges: (0,1,10), (0,2,6), (0,3,5), (1,3,15), (2,3,4)
```

### Execution:

```
STEP 1: Sort edges by weight
Sorted: [(2,3,4), (0,3,5), (0,2,6), (0,1,10), (1,3,15)]

STEP 2: Initialize Union-Find
Parent: [0, 1, 2, 3]  (each vertex is its own parent)
Rank:   [0, 0, 0, 0]
MST edges: []
MST weight: 0

STEP 3: Process edges

Edge (2,3,4):
  find(2) = 2, find(3) = 3
  2 != 3 -> Different components, ADD edge
  union(2, 3): Parent[3] = 2
  MST: [(2,3,4)], Weight: 4

  Parent: [0, 1, 2, 2]
         +-------+
         |       |
         2       3

Edge (0,3,5):
  find(0) = 0, find(3) = 2 (3->2)
  0 != 2 -> Different components, ADD edge
  union(0, 2): Parent[2] = 0
  MST: [(2,3,4), (0,3,5)], Weight: 9

  Parent: [0, 1, 0, 2]
         0
         |
         2
         |
         3

Edge (0,2,6):
  find(0) = 0, find(2) = 0 (2->0)
  0 == 0 -> Same component, SKIP (would create cycle)

Edge (0,1,10):
  find(0) = 0, find(1) = 1
  0 != 1 -> Different components, ADD edge
  union(0, 1): Parent[1] = 0
  MST: [(2,3,4), (0,3,5), (0,1,10)], Weight: 19

  Parent: [0, 0, 0, 2]
         0
        /|\
       1 2 
         |
         3

MST has 3 edges (V-1 = 4-1 = 3), STOP

RESULT:
MST Edges: [(2,3,4), (0,3,5), (0,1,10)]
MST Weight: 19
```

## Code Template

```python
class UnionFind:
    def __init__(self, n):
        self.parent = list(range(n))
        self.rank = [0] * n
    
    def find(self, x):
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])  # Path compression
        return self.parent[x]
    
    def union(self, x, y):
        px, py = self.find(x), self.find(y)
        if px == py:
            return False
        # Union by rank
        if self.rank[px] < self.rank[py]:
            px, py = py, px
        self.parent[py] = px
        if self.rank[px] == self.rank[py]:
            self.rank[px] += 1
        return True

def kruskal(n, edges):
    """
    n: number of vertices
    edges: list of (u, v, weight)
    """
    # Sort edges by weight
    edges.sort(key=lambda x: x[2])
    
    uf = UnionFind(n)
    mst = []
    mst_weight = 0
    
    for u, v, weight in edges:
        if uf.union(u, v):  # No cycle
            mst.append((u, v, weight))
            mst_weight += weight
            
            if len(mst) == n - 1:
                break
    
    return mst, mst_weight
```

## Time & Space Complexity

| Metric | Complexity | Explanation |
|--------|------------|-------------|
| Time | O(E log E) | Sorting edges dominates |
| Space | O(V) | Union-Find structure |

### Breakdown:
```
- Sorting: O(E log E)
- Union-Find operations: O(E * alpha(V)) ≈ O(E)
- Total: O(E log E) or O(E log V) since E ≤ V^2
```

## Kruskal's vs Prim's

| Aspect | Kruskal's | Prim's |
|--------|-----------|--------|
| Approach | Edge-based | Vertex-based |
| Data Structure | Union-Find | Priority Queue |
| Best for | Sparse graphs | Dense graphs |
| Time Complexity | O(E log E) | O(E log V) |

## Key Points

1. **Greedy**: Always pick minimum weight edge
2. **Union-Find**: Efficient cycle detection
3. **Sorting**: Critical step for greedy selection
4. **MST has V-1 edges**: Stop when reached
5. Works for **disconnected graphs**: Returns forest

## Common Variations

### 1. Maximum Spanning Tree
```python
# Sort edges in descending order
edges.sort(key=lambda x: -x[2])
```

### 2. Second Minimum Spanning Tree
```python
# For each MST edge:
#   Remove it and find MST
#   Track minimum among these
```

### 3. Check if Edge is in MST
```python
# Use Kruskal's, check if specific edge was added
```
