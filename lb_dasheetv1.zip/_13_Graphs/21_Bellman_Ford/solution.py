"""
Problem: Bellman-Ford Algorithm
===============================

Find shortest paths from source to all vertices.
Handles negative weights and detects negative cycles.

Algorithm:
1. Initialize dist[source] = 0, others = INF
2. Relax all edges V-1 times
3. Check for negative cycle (one more relaxation)

Time Complexity: O(V * E)
Space Complexity: O(V)
"""

from typing import List, Tuple, Optional, Dict


def bellman_ford(n: int, edges: List[Tuple[int, int, int]], source: int) -> Tuple[Optional[List[float]], bool]:
    """
    Bellman-Ford shortest path algorithm.

    Args:
        n: Number of vertices (0 to n-1)
        edges: List of (u, v, weight) directed edges
        source: Source vertex

    Returns:
        Tuple of (distances, has_negative_cycle)
        distances is None if negative cycle detected

    Example:
        >>> edges = [(0,1,-1), (0,2,4), (1,2,3), (1,3,2)]
        >>> dist, has_cycle = bellman_ford(4, edges, 0)
        >>> dist
        [0, -1, 2, 1]
    """
    INF = float('inf')
    dist = [INF] * n
    dist[source] = 0

    # Relax all edges V-1 times
    for _ in range(n - 1):
        for u, v, w in edges:
            if dist[u] != INF and dist[u] + w < dist[v]:
                dist[v] = dist[u] + w

    # Check for negative cycle
    for u, v, w in edges:
        if dist[u] != INF and dist[u] + w < dist[v]:
            return None, True  # Negative cycle

    return dist, False


def bellman_ford_with_path(n: int, edges: List[Tuple[int, int, int]], source: int) -> Tuple[List[float], List[int], bool]:
    """
    Bellman-Ford with path reconstruction.

    Returns:
        Tuple of (distances, parent, has_negative_cycle)
    """
    INF = float('inf')
    dist = [INF] * n
    parent = [-1] * n
    dist[source] = 0

    # Relax V-1 times
    for _ in range(n - 1):
        for u, v, w in edges:
            if dist[u] != INF and dist[u] + w < dist[v]:
                dist[v] = dist[u] + w
                parent[v] = u

    # Check negative cycle
    for u, v, w in edges:
        if dist[u] != INF and dist[u] + w < dist[v]:
            return dist, parent, True

    return dist, parent, False


def bellman_ford_with_trace(n: int, edges: List[Tuple[int, int, int]], source: int):
    """Bellman-Ford with detailed trace."""
    print("\n" + "=" * 60)
    print("Bellman-Ford Algorithm - Trace")
    print("=" * 60)

    print(f"\nVertices: {n}")
    print(f"Edges: {edges}")
    print(f"Source: {source}")

    INF = float('inf')
    dist = [INF] * n
    parent = [-1] * n
    dist[source] = 0

    print(f"\nInitial distances: {['INF' if d == INF else d for d in dist]}")

    for iteration in range(n - 1):
        print(f"\n--- Iteration {iteration + 1} ---")
        updated = False

        for u, v, w in edges:
            if dist[u] != INF and dist[u] + w < dist[v]:
                old_dist = dist[v]
                dist[v] = dist[u] + w
                parent[v] = u
                updated = True
                print(f"  Edge ({u},{v},{w}): dist[{v}] = {old_dist} -> {dist[v]}")

        print(f"  Distances: {['INF' if d == INF else d for d in dist]}")

        if not updated:
            print("  No updates, early termination possible")
            break

    print(f"\n--- Negative Cycle Check ---")
    has_cycle = False
    for u, v, w in edges:
        if dist[u] != INF and dist[u] + w < dist[v]:
            print(f"  Edge ({u},{v},{w}) can still be relaxed!")
            has_cycle = True

    if has_cycle:
        print("  NEGATIVE CYCLE DETECTED!")
    else:
        print("  No negative cycle")

    print(f"\n{'=' * 60}")
    print("RESULT")
    print(f"{'=' * 60}")
    print(f"Distances: {['INF' if d == INF else d for d in dist]}")
    print(f"Has negative cycle: {has_cycle}")

    return dist, has_cycle


def reconstruct_path(parent: List[int], source: int, target: int) -> List[int]:
    """Reconstruct path from source to target using parent array."""
    if parent[target] == -1 and target != source:
        return []  # No path

    path = []
    current = target

    while current != -1:
        path.append(current)
        current = parent[current]

    return path[::-1]


def find_negative_cycle(n: int, edges: List[Tuple[int, int, int]]) -> Optional[List[int]]:
    """
    Find and return a negative cycle if it exists.

    Returns list of vertices in the cycle, or None if no cycle.
    """
    INF = float('inf')
    dist = [0] * n  # Start with 0 to detect any cycle
    parent = [-1] * n

    # Relax V-1 times
    for _ in range(n - 1):
        for u, v, w in edges:
            if dist[u] + w < dist[v]:
                dist[v] = dist[u] + w
                parent[v] = u

    # Find vertex on cycle
    cycle_vertex = -1
    for u, v, w in edges:
        if dist[u] + w < dist[v]:
            cycle_vertex = v
            break

    if cycle_vertex == -1:
        return None

    # Find actual cycle
    # Go back n times to ensure we're in the cycle
    for _ in range(n):
        cycle_vertex = parent[cycle_vertex]

    # Collect cycle vertices
    cycle = []
    v = cycle_vertex
    while True:
        cycle.append(v)
        v = parent[v]
        if v == cycle_vertex:
            cycle.append(v)
            break

    return cycle[::-1]


def spfa(n: int, edges: List[Tuple[int, int, int]], source: int) -> Tuple[Optional[List[float]], bool]:
    """
    Shortest Path Faster Algorithm (SPFA).
    Optimized Bellman-Ford using queue.
    Average case: O(E), Worst case: O(VE)
    """
    from collections import deque

    # Build adjacency list
    graph = [[] for _ in range(n)]
    for u, v, w in edges:
        graph[u].append((v, w))

    INF = float('inf')
    dist = [INF] * n
    dist[source] = 0
    in_queue = [False] * n
    count = [0] * n  # Times vertex added to queue

    queue = deque([source])
    in_queue[source] = True
    count[source] = 1

    while queue:
        u = queue.popleft()
        in_queue[u] = False

        for v, w in graph[u]:
            if dist[u] + w < dist[v]:
                dist[v] = dist[u] + w

                if not in_queue[v]:
                    queue.append(v)
                    in_queue[v] = True
                    count[v] += 1

                    if count[v] >= n:
                        return None, True  # Negative cycle

    return dist, False


# =============================================================================
# Test Cases
# =============================================================================

def test_bellman_ford():
    """Test Bellman-Ford implementations."""
    print("\n" + "=" * 60)
    print("Bellman-Ford Algorithm - Test Cases")
    print("=" * 60)

    # Test 1: Basic graph with negative edge
    print("\nTest 1: Graph with negative edge")
    edges1 = [
        (0, 1, -1),
        (0, 2, 4),
        (1, 2, 3),
        (1, 3, 2),
        (1, 4, 2),
        (3, 2, 5),
        (3, 1, 1),
        (4, 3, -3)
    ]

    dist, has_cycle = bellman_ford(5, edges1, 0)
    print(f"  Distances from 0: {dist}")
    print(f"  Has negative cycle: {has_cycle}")
    assert dist == [0, -1, 2, -2, 1]
    assert not has_cycle

    # Test 2: Graph with negative cycle
    print("\nTest 2: Graph with negative cycle")
    edges2 = [
        (0, 1, 1),
        (1, 2, -1),
        (2, 3, -1),
        (3, 1, -1)  # Creates negative cycle 1->2->3->1
    ]

    dist, has_cycle = bellman_ford(4, edges2, 0)
    print(f"  Has negative cycle: {has_cycle}")
    assert has_cycle

    # Test 3: Find negative cycle
    print("\nTest 3: Find negative cycle vertices")
    cycle = find_negative_cycle(4, edges2)
    print(f"  Negative cycle: {cycle}")

    # Test 4: SPFA optimization
    print("\nTest 4: SPFA (optimized Bellman-Ford)")
    dist_spfa, _ = spfa(5, edges1, 0)
    print(f"  SPFA distances: {dist_spfa}")
    assert dist_spfa == [0, -1, 2, -2, 1]

    # Test 5: Path reconstruction
    print("\nTest 5: Path reconstruction")
    dist, parent, _ = bellman_ford_with_path(5, edges1, 0)
    path = reconstruct_path(parent, 0, 3)
    print(f"  Path 0 to 3: {path}")

    print("\nAll tests passed!")


def test_with_trace():
    """Test with detailed trace."""
    edges = [
        (0, 1, -1),
        (0, 2, 4),
        (1, 2, 3),
        (1, 3, 2),
        (1, 4, 2),
        (3, 2, 5),
        (3, 1, 1),
        (4, 3, -3)
    ]
    bellman_ford_with_trace(5, edges, 0)


if __name__ == "__main__":
    test_bellman_ford()
    test_with_trace()
