# Bellman-Ford Algorithm

## Problem Statement

Find the shortest paths from a source vertex to all other vertices in a weighted graph. Unlike Dijkstra's, Bellman-Ford can handle **negative edge weights** and detect **negative weight cycles**.

## Graph Visualization

```
Example Graph with Negative Edges:
        -1
    A ------> B
    |         |
  4 |         | 2
    v    3    v
    C ------> D
    ^         |
    |   -2    |
    +---------+

Shortest paths from A:
  A -> A: 0
  A -> B: -1 (direct)
  A -> C: 4 (direct)
  A -> D: 1 (A->B->D = -1+2)
```

## Why Bellman-Ford?

```
+------------------------+     +------------------------+
| Dijkstra's Algorithm   |     | Bellman-Ford           |
+------------------------+     +------------------------+
| Only positive weights  |     | Handles negative edges |
| Greedy approach        |     | Relaxes all edges V-1  |
| O(E log V)             |     | times O(VE)            |
| No cycle detection     |     | Detects negative cycle |
+------------------------+     +------------------------+
```

## Algorithm

```
Bellman-Ford:
1. Initialize distances:
   - dist[source] = 0
   - dist[all others] = infinity

2. Relax all edges V-1 times:
   For i = 1 to V-1:
       For each edge (u, v, weight):
           If dist[u] + weight < dist[v]:
               dist[v] = dist[u] + weight

3. Check for negative cycle:
   For each edge (u, v, weight):
       If dist[u] + weight < dist[v]:
           Negative cycle exists!
```

## Why V-1 Iterations?

```
In worst case, shortest path visits V-1 edges:
    0 -> 1 -> 2 -> 3 -> ... -> V-1

Each iteration guarantees at least one more vertex
gets its correct shortest distance.

After V-1 iterations, all shortest paths are found
(if no negative cycle).
```

## Step-by-Step Dry Run

### Graph:
```
Vertices: 0, 1, 2, 3, 4
Edges: (0,1,-1), (0,2,4), (1,2,3), (1,3,2), (1,4,2), (3,2,5), (3,1,1), (4,3,-3)
Source: 0
```

### Execution:

```
INITIALIZATION:
dist = [0, INF, INF, INF, INF]
parent = [-1, -1, -1, -1, -1]

ITERATION 1:
Edge (0,1,-1): dist[0] + (-1) = -1 < INF
  -> dist[1] = -1, parent[1] = 0
Edge (0,2,4): dist[0] + 4 = 4 < INF
  -> dist[2] = 4, parent[2] = 0
Edge (1,2,3): dist[1] + 3 = 2 < 4
  -> dist[2] = 2, parent[2] = 1
Edge (1,3,2): dist[1] + 2 = 1 < INF
  -> dist[3] = 1, parent[3] = 1
Edge (1,4,2): dist[1] + 2 = 1 < INF
  -> dist[4] = 1, parent[4] = 1
Edge (3,2,5): dist[3] + 5 = 6 > 2, no update
Edge (3,1,1): dist[3] + 1 = 2 > -1, no update
Edge (4,3,-3): dist[4] + (-3) = -2 < 1
  -> dist[3] = -2, parent[3] = 4

dist = [0, -1, 2, -2, 1]

ITERATION 2:
Edge (0,1,-1): 0 + (-1) = -1, no change
Edge (0,2,4): 0 + 4 = 4 > 2, no change
Edge (1,2,3): (-1) + 3 = 2, no change
Edge (1,3,2): (-1) + 2 = 1 > -2, no change
Edge (1,4,2): (-1) + 2 = 1, no change
Edge (3,2,5): (-2) + 5 = 3 > 2, no change
Edge (3,1,1): (-2) + 1 = -1, no change
Edge (4,3,-3): 1 + (-3) = -2, no change

dist = [0, -1, 2, -2, 1] (no change)

ITERATIONS 3, 4: No changes

NEGATIVE CYCLE CHECK:
For each edge, check if dist can be improved.
No improvement possible -> No negative cycle.

RESULT:
Shortest distances from 0: [0, -1, 2, -2, 1]
```

## Code Template

```python
def bellman_ford(n, edges, source):
    """
    n: number of vertices
    edges: list of (u, v, weight)
    source: starting vertex
    
    Returns (distances, has_negative_cycle)
    """
    INF = float('inf')
    dist = [INF] * n
    dist[source] = 0
    parent = [-1] * n
    
    # Relax all edges V-1 times
    for _ in range(n - 1):
        for u, v, w in edges:
            if dist[u] != INF and dist[u] + w < dist[v]:
                dist[v] = dist[u] + w
                parent[v] = u
    
    # Check for negative cycle
    for u, v, w in edges:
        if dist[u] != INF and dist[u] + w < dist[v]:
            return None, True  # Negative cycle detected
    
    return dist, False
```

## Time & Space Complexity

| Metric | Complexity | Explanation |
|--------|------------|-------------|
| Time | O(V * E) | V-1 iterations, each processes E edges |
| Space | O(V) | Distance and parent arrays |

## Negative Cycle Detection

```
If after V-1 iterations, any edge can still be relaxed,
a negative cycle exists.

Why? In a graph without negative cycles:
- Shortest path has at most V-1 edges
- V-1 iterations guarantee all shortest paths found
- If we can still relax, path keeps getting shorter -> cycle!
```

## Applications

| Application | Description |
|-------------|-------------|
| Currency Arbitrage | Detect profitable exchange cycles |
| Network Routing | Protocols like RIP use Bellman-Ford |
| Constraint Solving | System of difference constraints |
| Finding Negative Cycles | When any cycle detection is needed |

## Bellman-Ford vs Dijkstra

| Feature | Bellman-Ford | Dijkstra |
|---------|--------------|----------|
| Negative edges | Yes | No |
| Negative cycles | Detects | Not applicable |
| Time | O(VE) | O(E log V) |
| Use case | Negative weights | Positive weights |

## Key Points

1. **V-1 iterations**: Sufficient for shortest paths in acyclic case
2. **Negative cycle detection**: One more iteration to check
3. **Works with negative weights**: Main advantage over Dijkstra
4. **Slower than Dijkstra**: Use Dijkstra for positive weights only
5. **Path reconstruction**: Use parent array

## Variations

### 1. SPFA (Shortest Path Faster Algorithm)
```python
# Use queue to only process vertices whose distance changed
# Average case faster, worst case same as Bellman-Ford
```

### 2. Find Negative Cycle Path
```python
# After detecting cycle, trace back to find actual cycle vertices
```

### 3. Early Termination
```python
# If no updates in an iteration, algorithm can stop early
```
