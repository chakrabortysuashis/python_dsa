# Create a Graph and Print It

## Problem Statement

Create a graph data structure that can represent both directed and undirected graphs using an adjacency list. Implement methods to:
1. Add vertices
2. Add edges
3. Print the graph in a readable format

## Graph Visualization

### Example: Undirected Graph

```
Input edges: [(0,1), (0,2), (1,2), (1,3), (2,4)]

Visual representation:
        0
       / \
      1---2
      |   |
      3   4

Adjacency List:
0: [1, 2]
1: [0, 2, 3]
2: [0, 1, 4]
3: [1]
4: [2]
```

### Example: Directed Graph

```
Input edges: [(0,1), (0,2), (1,3), (2,1)]

Visual representation:
        0
       / \
      v   v
      1<--2
      |
      v
      3

Adjacency List:
0: [1, 2]
1: [3]
2: [1]
3: []
```

## Approach

### Using Adjacency List (Dictionary/HashMap)

The adjacency list is the most common representation for sparse graphs:
- Use a dictionary where keys are vertices
- Values are lists of adjacent vertices

```
graph = {
    vertex1: [neighbor1, neighbor2, ...],
    vertex2: [neighbor1, neighbor2, ...],
    ...
}
```

## Step-by-Step Construction

### Building Undirected Graph: [(0,1), (0,2), (1,2), (1,3)]

```
Step 1: Add edge (0, 1)
        graph = {0: [1], 1: [0]}

Step 2: Add edge (0, 2)
        graph = {0: [1, 2], 1: [0], 2: [0]}

Step 3: Add edge (1, 2)
        graph = {0: [1, 2], 1: [0, 2], 2: [0, 1]}

Step 4: Add edge (1, 3)
        graph = {0: [1, 2], 1: [0, 2, 3], 2: [0, 1], 3: [1]}

Final Graph:
    0 --> [1, 2]
    1 --> [0, 2, 3]
    2 --> [0, 1]
    3 --> [1]
```

### Building Directed Graph: [(0,1), (0,2), (1,3)]

```
Step 1: Add edge (0, 1)
        graph = {0: [1], 1: []}

Step 2: Add edge (0, 2)
        graph = {0: [1, 2], 1: [], 2: []}

Step 3: Add edge (1, 3)
        graph = {0: [1, 2], 1: [3], 2: [], 3: []}

Final Graph:
    0 --> [1, 2]
    1 --> [3]
    2 --> []
    3 --> []
```

## Adjacency Matrix vs Adjacency List

| Representation | Space | Add Edge | Check Edge | Iterate Neighbors |
|---------------|-------|----------|------------|-------------------|
| Adjacency List | O(V+E) | O(1) | O(degree) | O(degree) |
| Adjacency Matrix | O(V^2) | O(1) | O(1) | O(V) |

**Choose Adjacency List when:**
- Graph is sparse (E << V^2)
- Need to iterate over neighbors frequently
- Memory is a concern

**Choose Adjacency Matrix when:**
- Graph is dense (E close to V^2)
- Need O(1) edge lookup
- Performing matrix operations

## Time & Space Complexity

| Operation | Time Complexity |
|-----------|-----------------|
| Create empty graph | O(1) |
| Add vertex | O(1) |
| Add edge (undirected) | O(1) |
| Add edge (directed) | O(1) |
| Print graph | O(V + E) |

**Space Complexity:** O(V + E) for adjacency list

## Key Points

1. **Dictionary** is ideal for adjacency list in Python
2. **defaultdict(list)** simplifies adding edges without checking if vertex exists
3. For **undirected graphs**, add edge in both directions
4. For **directed graphs**, add edge only in one direction
5. Remember to handle **isolated vertices** (vertices with no edges)

## Related Problems

- BFS Traversal
- DFS Traversal
- Detect Cycle in Graph
- Connected Components
