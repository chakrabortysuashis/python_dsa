"""
Problem: Create a Graph and Print It
====================================

Implement a graph data structure using adjacency list representation.
Support both directed and undirected graphs.

Time Complexity:
- Add vertex: O(1)
- Add edge: O(1)
- Print graph: O(V + E)

Space Complexity: O(V + E)
"""

from collections import defaultdict
from typing import List, Set, Dict


class Graph:
    """
    Graph implementation using adjacency list (dictionary of lists).

    Example:
        g = Graph(directed=False)
        g.add_edge(0, 1)
        g.add_edge(0, 2)
        g.add_edge(1, 2)
        print(g)

        Output:
        0: [1, 2]
        1: [0, 2]
        2: [0, 1]
    """

    def __init__(self, directed: bool = False):
        """
        Initialize the graph.

        Args:
            directed: If True, creates a directed graph.
                     If False (default), creates an undirected graph.
        """
        # Using defaultdict(list) - automatically creates empty list for new vertices
        self.adj_list: Dict[int, List[int]] = defaultdict(list)
        self.directed = directed
        self.vertices: Set[int] = set()

    def add_vertex(self, vertex: int) -> None:
        """
        Add a vertex to the graph.

        If vertex already exists, this operation has no effect.

        Time: O(1)
        """
        self.vertices.add(vertex)
        # Ensure vertex exists in adjacency list even if no edges
        if vertex not in self.adj_list:
            self.adj_list[vertex] = []

    def add_edge(self, u: int, v: int) -> None:
        """
        Add an edge between vertices u and v.

        For undirected graph: adds edge in both directions (u-v and v-u)
        For directed graph: adds edge only from u to v

        Time: O(1)

        Args:
            u: Source vertex
            v: Destination vertex
        """
        # Automatically add vertices if they don't exist
        self.vertices.add(u)
        self.vertices.add(v)

        # Add edge from u to v
        self.adj_list[u].append(v)

        # For undirected graph, also add edge from v to u
        if not self.directed:
            self.adj_list[v].append(u)

    def remove_edge(self, u: int, v: int) -> None:
        """
        Remove edge between vertices u and v.

        Time: O(E) where E is number of edges from u
        """
        if v in self.adj_list[u]:
            self.adj_list[u].remove(v)

        if not self.directed and u in self.adj_list[v]:
            self.adj_list[v].remove(u)

    def has_edge(self, u: int, v: int) -> bool:
        """
        Check if edge exists between u and v.

        Time: O(degree of u)
        """
        return v in self.adj_list[u]

    def get_neighbors(self, vertex: int) -> List[int]:
        """
        Get all neighbors of a vertex.

        Time: O(1)
        """
        return self.adj_list[vertex]

    def get_degree(self, vertex: int) -> int:
        """
        Get degree (number of edges) of a vertex.

        For directed graph:
        - This returns out-degree
        - Use get_in_degree() for in-degree

        Time: O(1)
        """
        return len(self.adj_list[vertex])

    def get_in_degree(self, vertex: int) -> int:
        """
        Get in-degree of a vertex (directed graph only).

        Time: O(V + E)
        """
        if not self.directed:
            return self.get_degree(vertex)

        count = 0
        for v in self.adj_list:
            if vertex in self.adj_list[v]:
                count += 1
        return count

    def get_all_vertices(self) -> List[int]:
        """
        Get all vertices in sorted order.

        Time: O(V log V) due to sorting
        """
        return sorted(self.vertices)

    def get_num_vertices(self) -> int:
        """Get total number of vertices."""
        return len(self.vertices)

    def get_num_edges(self) -> int:
        """
        Get total number of edges.

        For undirected graph, each edge is counted once (not twice).
        """
        total = sum(len(neighbors) for neighbors in self.adj_list.values())
        if not self.directed:
            total //= 2  # Each edge counted twice in undirected graph
        return total

    def print_graph(self) -> None:
        """
        Print the adjacency list representation of the graph.

        Time: O(V + E)
        """
        print("\n" + "=" * 40)
        print(f"{'Directed' if self.directed else 'Undirected'} Graph")
        print(f"Vertices: {self.get_num_vertices()}, Edges: {self.get_num_edges()}")
        print("=" * 40)
        print("\nAdjacency List:")

        for vertex in sorted(self.vertices):
            neighbors = sorted(self.adj_list[vertex])
            arrow = " -> " if self.directed else " -- "
            print(f"  {vertex}{arrow}{neighbors}")

        print()

    def __str__(self) -> str:
        """String representation of the graph."""
        lines = []
        for vertex in sorted(self.vertices):
            neighbors = sorted(self.adj_list[vertex])
            lines.append(f"{vertex}: {neighbors}")
        return "\n".join(lines)

    def __repr__(self) -> str:
        return f"Graph(directed={self.directed}, vertices={self.vertices})"


def build_graph_from_edges(edges: List[tuple], directed: bool = False) -> Graph:
    """
    Build a graph from a list of edges.

    Args:
        edges: List of tuples (u, v) representing edges
        directed: If True, creates directed graph

    Returns:
        Graph object

    Example:
        edges = [(0, 1), (0, 2), (1, 2)]
        g = build_graph_from_edges(edges)
    """
    g = Graph(directed=directed)

    print(f"\nBuilding {'directed' if directed else 'undirected'} graph from edges: {edges}")
    print("-" * 50)

    for i, (u, v) in enumerate(edges, 1):
        print(f"Step {i}: Add edge ({u}, {v})")
        g.add_edge(u, v)
        print(f"         Current adjacency list:")
        for vertex in sorted(g.vertices):
            print(f"           {vertex}: {sorted(g.adj_list[vertex])}")
        print()

    return g


# =============================================================================
# Test Cases
# =============================================================================

def test_undirected_graph():
    """Test undirected graph operations."""
    print("\n" + "=" * 60)
    print("TEST: Undirected Graph")
    print("=" * 60)

    g = Graph(directed=False)

    # Add edges
    edges = [(0, 1), (0, 2), (1, 2), (1, 3), (2, 4)]
    for u, v in edges:
        g.add_edge(u, v)

    g.print_graph()

    # Test operations
    print("Operations:")
    print(f"  Neighbors of vertex 1: {g.get_neighbors(1)}")
    print(f"  Degree of vertex 2: {g.get_degree(2)}")
    print(f"  Has edge (0, 1): {g.has_edge(0, 1)}")
    print(f"  Has edge (0, 3): {g.has_edge(0, 3)}")

    # Expected output:
    # 0: [1, 2]
    # 1: [0, 2, 3]
    # 2: [0, 1, 4]
    # 3: [1]
    # 4: [2]


def test_directed_graph():
    """Test directed graph operations."""
    print("\n" + "=" * 60)
    print("TEST: Directed Graph")
    print("=" * 60)

    g = Graph(directed=True)

    # Add edges
    edges = [(0, 1), (0, 2), (1, 2), (2, 3), (3, 0)]
    for u, v in edges:
        g.add_edge(u, v)

    g.print_graph()

    # Test operations
    print("Operations:")
    print(f"  Out-neighbors of vertex 0: {g.get_neighbors(0)}")
    print(f"  Out-degree of vertex 0: {g.get_degree(0)}")
    print(f"  In-degree of vertex 0: {g.get_in_degree(0)}")
    print(f"  Has edge (0, 1): {g.has_edge(0, 1)}")
    print(f"  Has edge (1, 0): {g.has_edge(1, 0)}")  # False for directed

    # Expected output:
    # 0: [1, 2]
    # 1: [2]
    # 2: [3]
    # 3: [0]


def test_build_step_by_step():
    """Demonstrate step-by-step graph construction."""
    print("\n" + "=" * 60)
    print("TEST: Step-by-Step Construction")
    print("=" * 60)

    edges = [(0, 1), (0, 2), (1, 3), (2, 3)]
    g = build_graph_from_edges(edges, directed=False)

    print("\nFinal Graph:")
    print(g)


def test_isolated_vertex():
    """Test adding isolated vertices (vertices with no edges)."""
    print("\n" + "=" * 60)
    print("TEST: Isolated Vertex")
    print("=" * 60)

    g = Graph()

    # Add some edges
    g.add_edge(0, 1)
    g.add_edge(1, 2)

    # Add isolated vertex (no edges)
    g.add_vertex(5)

    g.print_graph()

    print(f"All vertices: {g.get_all_vertices()}")
    print(f"Neighbors of isolated vertex 5: {g.get_neighbors(5)}")


if __name__ == "__main__":
    test_undirected_graph()
    test_directed_graph()
    test_build_step_by_step()
    test_isolated_vertex()
