"""
Problem: Floyd-Warshall Algorithm
=================================

Find shortest paths between ALL pairs of vertices.

Algorithm:
For each intermediate vertex k:
    For each pair (i, j):
        dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j])

Time Complexity: O(V^3)
Space Complexity: O(V^2)
"""

from typing import List, Tuple, Optional


def floyd_warshall(n: int, edges: List[Tuple[int, int, int]]) -> Optional[List[List[float]]]:
    """
    Floyd-Warshall all-pairs shortest paths.

    Args:
        n: Number of vertices (0 to n-1)
        edges: List of (u, v, weight) directed edges

    Returns:
        Distance matrix, or None if negative cycle exists

    Example:
        >>> edges = [(0,1,3), (0,2,8), (1,3,-4), (2,1,1), (2,3,7), (3,2,2)]
        >>> dist = floyd_warshall(4, edges)
    """
    INF = float('inf')

    # Initialize distance matrix
    dist = [[INF] * n for _ in range(n)]

    # Distance to self is 0
    for i in range(n):
        dist[i][i] = 0

    # Fill in edge weights
    for u, v, w in edges:
        dist[u][v] = w

    # Floyd-Warshall: consider each vertex as intermediate
    for k in range(n):
        for i in range(n):
            for j in range(n):
                if dist[i][k] != INF and dist[k][j] != INF:
                    if dist[i][k] + dist[k][j] < dist[i][j]:
                        dist[i][j] = dist[i][k] + dist[k][j]

    # Check for negative cycle (diagonal < 0)
    for i in range(n):
        if dist[i][i] < 0:
            return None  # Negative cycle detected

    return dist


def floyd_warshall_with_path(n: int, edges: List[Tuple[int, int, int]]) -> Tuple[List[List[float]], List[List[int]]]:
    """
    Floyd-Warshall with path reconstruction.

    Returns:
        Tuple of (distance matrix, next vertex matrix)
    """
    INF = float('inf')

    dist = [[INF] * n for _ in range(n)]
    next_v = [[None] * n for _ in range(n)]

    for i in range(n):
        dist[i][i] = 0

    for u, v, w in edges:
        dist[u][v] = w
        next_v[u][v] = v

    for k in range(n):
        for i in range(n):
            for j in range(n):
                if dist[i][k] != INF and dist[k][j] != INF:
                    if dist[i][k] + dist[k][j] < dist[i][j]:
                        dist[i][j] = dist[i][k] + dist[k][j]
                        next_v[i][j] = next_v[i][k]

    return dist, next_v


def reconstruct_path(next_v: List[List[int]], i: int, j: int) -> List[int]:
    """Reconstruct path from i to j using next vertex matrix."""
    if next_v[i][j] is None:
        return []

    path = [i]
    while i != j:
        i = next_v[i][j]
        if i is None:
            return []
        path.append(i)

    return path


def floyd_warshall_with_trace(n: int, edges: List[Tuple[int, int, int]]):
    """Floyd-Warshall with detailed trace."""
    print("\n" + "=" * 60)
    print("Floyd-Warshall Algorithm - Trace")
    print("=" * 60)

    print(f"\nVertices: {n}")
    print(f"Edges: {edges}")

    INF = float('inf')

    dist = [[INF] * n for _ in range(n)]
    for i in range(n):
        dist[i][i] = 0
    for u, v, w in edges:
        dist[u][v] = w

    def print_matrix(matrix, title):
        print(f"\n{title}:")
        print("     " + "".join(f"{j:8}" for j in range(n)))
        for i in range(n):
            row = "".join(
                f"{'INF':>8}" if x == INF else f"{x:8.0f}" if isinstance(x, float) else f"{x:8}"
                for x in matrix[i]
            )
            print(f"{i:4} [{row}]")

    print_matrix(dist, "Initial Distance Matrix")

    for k in range(n):
        print(f"\n{'='*40}")
        print(f"k = {k} (using vertex {k} as intermediate)")
        print(f"{'='*40}")

        updated = False
        for i in range(n):
            for j in range(n):
                if dist[i][k] != INF and dist[k][j] != INF:
                    new_dist = dist[i][k] + dist[k][j]
                    if new_dist < dist[i][j]:
                        print(f"  dist[{i}][{j}] = min({dist[i][j]}, {dist[i][k]}+{dist[k][j]}) = {new_dist}")
                        dist[i][j] = new_dist
                        updated = True

        if not updated:
            print("  No updates")

        print_matrix(dist, f"After k={k}")

    print(f"\n{'='*60}")
    print("RESULT")
    print(f"{'='*60}")

    # Check negative cycle
    has_cycle = any(dist[i][i] < 0 for i in range(n))
    if has_cycle:
        print("NEGATIVE CYCLE DETECTED!")
    else:
        print_matrix(dist, "Final All-Pairs Shortest Paths")

    return dist


def transitive_closure(n: int, edges: List[Tuple[int, int]]) -> List[List[bool]]:
    """
    Find transitive closure using Floyd-Warshall variant.
    reach[i][j] = True if there's a path from i to j.
    """
    reach = [[False] * n for _ in range(n)]

    # Self-reachable
    for i in range(n):
        reach[i][i] = True

    # Direct edges
    for u, v in edges:
        reach[u][v] = True

    # Floyd-Warshall for reachability
    for k in range(n):
        for i in range(n):
            for j in range(n):
                reach[i][j] = reach[i][j] or (reach[i][k] and reach[k][j])

    return reach


def graph_diameter(dist: List[List[float]]) -> float:
    """Calculate graph diameter (longest shortest path)."""
    INF = float('inf')
    diameter = 0

    for row in dist:
        for d in row:
            if d != INF and d > diameter:
                diameter = d

    return diameter


# =============================================================================
# Test Cases
# =============================================================================

def test_floyd_warshall():
    """Test Floyd-Warshall implementations."""
    print("\n" + "=" * 60)
    print("Floyd-Warshall Algorithm - Test Cases")
    print("=" * 60)

    # Test 1: Basic graph
    print("\nTest 1: Basic graph with negative edge")
    edges1 = [
        (0, 1, 3),
        (0, 2, 8),
        (1, 3, -4),
        (2, 1, 1),
        (2, 3, 7),
        (3, 2, 2)
    ]

    dist = floyd_warshall(4, edges1)
    print("Distance matrix:")
    for i, row in enumerate(dist):
        print(f"  {i}: {row}")

    # Test 2: With path reconstruction
    print("\nTest 2: Path reconstruction")
    dist, next_v = floyd_warshall_with_path(4, edges1)
    path = reconstruct_path(next_v, 0, 3)
    print(f"  Shortest path 0 -> 3: {path}")
    print(f"  Distance: {dist[0][3]}")

    # Test 3: Transitive closure
    print("\nTest 3: Transitive closure")
    edges3 = [(0, 1), (1, 2), (2, 3)]
    reach = transitive_closure(4, edges3)
    print(f"  Can reach 3 from 0? {reach[0][3]}")
    print(f"  Can reach 0 from 3? {reach[3][0]}")

    # Test 4: Graph diameter
    print("\nTest 4: Graph diameter")
    diameter = graph_diameter(dist)
    print(f"  Diameter: {diameter}")

    print("\nAll tests passed!")


def test_with_trace():
    """Test with detailed trace."""
    edges = [
        (0, 1, 3),
        (0, 2, 8),
        (1, 3, -4),
        (2, 1, 1),
        (2, 3, 7),
        (3, 2, 2)
    ]
    floyd_warshall_with_trace(4, edges)


if __name__ == "__main__":
    test_floyd_warshall()
    test_with_trace()
