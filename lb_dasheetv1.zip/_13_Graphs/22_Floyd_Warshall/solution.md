# Floyd-Warshall Algorithm

## Problem Statement

Find shortest paths between ALL pairs of vertices in a weighted graph. The algorithm works with positive and negative edge weights (but no negative cycles).

## Graph Visualization

```
Input Graph:
        3
    0 -----> 1
    |        |
  8 |        | -4
    v    1   v
    2 -----> 3
    ^        |
    |   2    |
    +--------+

All-Pairs Shortest Paths:
         To
       0   1   2   3
    +----------------
  0 | 0   3   8  -1
F 1 | INF 0   INF -4
r 2 | INF 4   0   3
o 3 | INF 5   2   0
m
```

## Why Floyd-Warshall?

```
+------------------+     +------------------+
| Single Source:   |     | All Pairs:       |
| Dijkstra/BF      |     | Floyd-Warshall   |
+------------------+     +------------------+
| Run V times      |     | Single O(V^3)    |
| O(V*E log V) or  |     | algorithm        |
| O(V^2 * E)       |     |                  |
+------------------+     +------------------+
         |                        |
         v                        v
    Better for sparse      Better for dense
    graphs or single       graphs or when all
    source queries         pairs needed
```

## Algorithm

```
Floyd-Warshall:
1. Initialize dist[i][j]:
   - dist[i][i] = 0
   - dist[i][j] = weight(i,j) if edge exists
   - dist[i][j] = INF otherwise

2. For each intermediate vertex k = 0 to V-1:
   For each source i = 0 to V-1:
       For each destination j = 0 to V-1:
           dist[i][j] = min(dist[i][j], 
                           dist[i][k] + dist[k][j])

3. Check negative cycles:
   If dist[i][i] < 0 for any i, negative cycle exists
```

## Key Insight

```
Consider paths from i to j using vertices {0,1,...,k}

dist[i][j] with intermediate vertices {0,...,k} =
    min(
        dist[i][j] with {0,...,k-1},      // Not using k
        dist[i][k] + dist[k][j]            // Using k
    )

This is optimal substructure!
```

## Step-by-Step Dry Run

### Graph:
```
4 vertices, edges: (0,1,3), (0,2,8), (1,3,-4), (2,1,1), (2,3,7), (3,2,2)
```

### Initialization:
```
dist:
     0    1    2    3
0 [  0    3    8   INF ]
1 [ INF   0   INF  -4  ]
2 [ INF   1    0    7  ]
3 [ INF  INF   2    0  ]
```

### k = 0 (using vertex 0):
```
Check all i,j: Can we improve path i->j by going through 0?
dist[1][2] = min(INF, dist[1][0] + dist[0][2]) = min(INF, INF+8) = INF
dist[2][1] = min(1, dist[2][0] + dist[0][1]) = min(1, INF+3) = 1
... (no changes for k=0)

dist stays same
```

### k = 1 (using vertex 1):
```
dist[0][3] = min(INF, dist[0][1] + dist[1][3]) = min(INF, 3+(-4)) = -1
dist[2][3] = min(7, dist[2][1] + dist[1][3]) = min(7, 1+(-4)) = -3

dist:
     0    1    2    3
0 [  0    3    8   -1  ]
1 [ INF   0   INF  -4  ]
2 [ INF   1    0   -3  ]
3 [ INF  INF   2    0  ]
```

### k = 2 (using vertex 2):
```
dist[0][1] = min(3, dist[0][2] + dist[2][1]) = min(3, 8+1) = 3
dist[1][3] = min(-4, dist[1][2] + dist[2][3]) = min(-4, INF) = -4
dist[3][1] = min(INF, dist[3][2] + dist[2][1]) = min(INF, 2+1) = 3

dist:
     0    1    2    3
0 [  0    3    8   -1  ]
1 [ INF   0   INF  -4  ]
2 [ INF   1    0   -3  ]
3 [ INF   3    2    0  ]
```

### k = 3 (using vertex 3):
```
dist[0][2] = min(8, dist[0][3] + dist[3][2]) = min(8, -1+2) = 1
dist[1][2] = min(INF, dist[1][3] + dist[3][2]) = min(INF, -4+2) = -2
dist[2][1] = min(1, dist[2][3] + dist[3][1]) = min(1, -3+3) = 0

FINAL dist:
     0    1    2    3
0 [  0    3    1   -1  ]
1 [ INF   0   -2   -4  ]
2 [ INF   0    0   -3  ]
3 [ INF   3    2    0  ]
```

## Code Template

```python
def floyd_warshall(n, edges):
    """
    n: number of vertices
    edges: list of (u, v, weight)
    """
    INF = float('inf')
    
    # Initialize distance matrix
    dist = [[INF] * n for _ in range(n)]
    
    for i in range(n):
        dist[i][i] = 0
    
    for u, v, w in edges:
        dist[u][v] = w
    
    # Floyd-Warshall
    for k in range(n):
        for i in range(n):
            for j in range(n):
                if dist[i][k] != INF and dist[k][j] != INF:
                    dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j])
    
    # Check negative cycles
    for i in range(n):
        if dist[i][i] < 0:
            return None  # Negative cycle
    
    return dist
```

## Time & Space Complexity

| Metric | Complexity | Explanation |
|--------|------------|-------------|
| Time | O(V^3) | Three nested loops |
| Space | O(V^2) | Distance matrix |

## Path Reconstruction

```python
# Also maintain next[i][j] = next vertex on path from i to j
next_vertex = [[None] * n for _ in range(n)]

# Initialize
for u, v, w in edges:
    next_vertex[u][v] = v

# Update in main loop
if dist[i][k] + dist[k][j] < dist[i][j]:
    dist[i][j] = dist[i][k] + dist[k][j]
    next_vertex[i][j] = next_vertex[i][k]

# Reconstruct path
def get_path(i, j):
    if next_vertex[i][j] is None:
        return []
    path = [i]
    while i != j:
        i = next_vertex[i][j]
        path.append(i)
    return path
```

## Applications

| Application | Use Case |
|-------------|----------|
| Transitive closure | Reachability in digraphs |
| Network routing | All-pairs routing tables |
| Graph metrics | Diameter, radius calculation |
| Shortest path queries | When many queries needed |

## Key Points

1. **O(V^3)**: Simple to implement, good for dense graphs
2. **All pairs**: One run gives all shortest paths
3. **Negative edges OK**: But no negative cycles
4. **In-place possible**: Can use single 2D array
5. **Path reconstruction**: Maintain next-vertex matrix

## Comparison

| Algorithm | Type | Time | Negative Edges |
|-----------|------|------|----------------|
| Floyd-Warshall | All pairs | O(V^3) | Yes |
| Dijkstra (V times) | All pairs | O(VE log V) | No |
| Bellman-Ford (V times) | All pairs | O(V^2 E) | Yes |
| Johnson's | All pairs | O(VE log V) | Yes |
