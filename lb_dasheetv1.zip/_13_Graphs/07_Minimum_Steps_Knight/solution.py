"""
Problem: Minimum Steps by Knight
================================

Find minimum moves for a knight to reach from source to destination.

Knight moves in "L" shape: 2 squares + 1 perpendicular (8 possible moves)

Time: O(N^2)
Space: O(N^2)
"""

from collections import deque
from typing import Tuple


def min_knight_moves(n: int, start: Tuple[int, int], end: Tuple[int, int]) -> int:
    """
    BFS to find minimum knight moves.
    """
    if start == end:
        return 0

    # All 8 possible knight moves
    moves = [
        (-2, -1), (-2, 1),  # 2 up
        (-1, -2), (-1, 2),  # 1 up
        (1, -2), (1, 2),    # 1 down
        (2, -1), (2, 1)     # 2 down
    ]

    queue = deque([(start[0], start[1], 0)])  # (row, col, steps)
    visited = {start}

    while queue:
        r, c, steps = queue.popleft()

        for dr, dc in moves:
            nr, nc = r + dr, c + dc

            if (nr, nc) == end:
                return steps + 1

            if 0 <= nr < n and 0 <= nc < n and (nr, nc) not in visited:
                visited.add((nr, nc))
                queue.append((nr, nc, steps + 1))

    return -1  # Unreachable (shouldn't happen on valid board)


def min_knight_moves_trace(n: int, start: Tuple[int, int], end: Tuple[int, int]) -> int:
    """BFS with detailed trace."""
    moves = [(-2,-1),(-2,1),(-1,-2),(-1,2),(1,-2),(1,2),(2,-1),(2,1)]

    print(f"\n{'='*50}")
    print(f"Minimum Knight Moves ({n}x{n} board)")
    print(f"Start: {start}, End: {end}")
    print(f"{'='*50}")

    if start == end:
        print("Already at destination!")
        return 0

    queue = deque([(start[0], start[1], 0)])
    visited = {start}

    while queue:
        r, c, steps = queue.popleft()
        print(f"\nLevel {steps}: Process ({r},{c})")
        print(f"  Queue size: {len(queue)}")

        valid_moves = []
        for dr, dc in moves:
            nr, nc = r + dr, c + dc

            if (nr, nc) == end:
                print(f"  Found destination at ({nr},{nc})!")
                print(f"\nMinimum moves: {steps + 1}")
                return steps + 1

            if 0 <= nr < n and 0 <= nc < n and (nr, nc) not in visited:
                visited.add((nr, nc))
                queue.append((nr, nc, steps + 1))
                valid_moves.append((nr, nc))

        if valid_moves:
            print(f"  Added: {valid_moves}")

    return -1


# Test
if __name__ == "__main__":
    # Test 1: 8x8 board
    result = min_knight_moves_trace(8, (0, 0), (7, 7))
    print(f"\nResult: {result} moves")

    # Test 2: Same position
    print(f"\n(0,0) to (0,0): {min_knight_moves(8, (0, 0), (0, 0))} moves")

    # Test 3: Adjacent L-move
    print(f"(0,0) to (2,1): {min_knight_moves(8, (0, 0), (2, 1))} moves")
