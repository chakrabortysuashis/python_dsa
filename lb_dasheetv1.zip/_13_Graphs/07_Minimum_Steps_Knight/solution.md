# Minimum Steps by Knight

## Problem Statement

Given an N x N chessboard, find the minimum number of moves required for a Knight to reach from source to destination.

## Knight's Movement

A knight moves in an "L" shape:
- 2 squares in one direction + 1 square perpendicular
- 8 possible moves from any position

```
    . . X . X . .
    . X . . . X .
    . . . K . . .
    . X . . . X .
    . . X . X . .

K = Knight's position
X = Possible destinations
```

## Knight Moves Array

```python
moves = [
    (-2, -1), (-2, 1),   # 2 up
    (-1, -2), (-1, 2),   # 1 up
    (1, -2), (1, 2),     # 1 down
    (2, -1), (2, 1)      # 2 down
]
```

## Why BFS?

- Need MINIMUM steps = shortest path
- Unweighted graph (each move = 1 step)
- BFS explores level by level = optimal for shortest path

## Algorithm

```python
def min_knight_moves(n, start, end):
    if start == end:
        return 0
    
    moves = [(-2,-1),(-2,1),(-1,-2),(-1,2),
             (1,-2),(1,2),(2,-1),(2,1)]
    
    queue = deque([(start, 0)])  # (position, steps)
    visited = {start}
    
    while queue:
        (r, c), steps = queue.popleft()
        
        for dr, dc in moves:
            nr, nc = r + dr, c + dc
            
            if (nr, nc) == end:
                return steps + 1
            
            if (0 <= nr < n and 0 <= nc < n and
                (nr, nc) not in visited):
                visited.add((nr, nc))
                queue.append(((nr, nc), steps + 1))
    
    return -1  # Unreachable
```

## Step-by-Step Example

```
Board: 6x6
Start: (0, 0)
End: (5, 5)

BFS Levels:
Level 0: (0,0)                         Steps=0
Level 1: (1,2), (2,1)                  Steps=1
Level 2: (0,4), (2,3), (3,0), (3,2)... Steps=2
Level 3: ...                            Steps=3
Level 4: (5,5) reached!                 Steps=4

Minimum moves: 4
```

## Queue Visualization

```
Step 0: Queue = [(0,0,0)]
        Process (0,0), add knight moves
        
Step 1: Queue = [(1,2,1), (2,1,1)]
        Process (1,2), add valid moves
        
Step 2: Queue = [(2,1,1), (0,4,2), (3,0,2), ...]
        Continue until destination found
```

## Time & Space Complexity

| Metric | Complexity |
|--------|------------|
| Time | O(N^2) |
| Space | O(N^2) |

Each cell visited at most once.

## Key Points

1. Use BFS for minimum steps
2. 8 directional moves
3. Board boundary check
4. Mark visited when enqueuing
