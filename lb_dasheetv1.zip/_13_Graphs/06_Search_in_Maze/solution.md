# Search in a Maze

## Problem Statement

Given a maze represented as a 2D grid, find if there's a path from source to destination. The maze contains:
- `0`: Passable cell
- `1`: Wall (blocked)

## Maze Visualization

```
Maze (0=open, 1=wall):
+---+---+---+---+---+
| S | 0 | 1 | 0 | 0 |
+---+---+---+---+---+
| 0 | 0 | 0 | 0 | 1 |
+---+---+---+---+---+
| 1 | 0 | 1 | 0 | 0 |
+---+---+---+---+---+
| 0 | 0 | 0 | 1 | D |
+---+---+---+---+---+

S = Source (0,0)
D = Destination (3,4)
```

## Approach: BFS or DFS

Both BFS and DFS work. BFS finds shortest path, DFS just finds any path.

### Graph Representation
- Each cell (i, j) is a vertex
- Adjacent cells (up, down, left, right) are edges
- Only valid cells (within bounds, value=0) are connected

## BFS Solution (Shortest Path)

```python
def solve_maze_bfs(maze, start, end):
    rows, cols = len(maze), len(maze[0])
    directions = [(0,1), (0,-1), (1,0), (-1,0)]
    
    queue = deque([start])
    visited = {start}
    
    while queue:
        r, c = queue.popleft()
        
        if (r, c) == end:
            return True
        
        for dr, dc in directions:
            nr, nc = r + dr, c + dc
            if (0 <= nr < rows and 0 <= nc < cols and
                maze[nr][nc] == 0 and (nr, nc) not in visited):
                visited.add((nr, nc))
                queue.append((nr, nc))
    
    return False
```

## Step-by-Step BFS Dry Run

```
Maze:
[0, 0, 1, 0]
[0, 1, 0, 0]
[0, 0, 0, 1]
[1, 0, 0, D]

Start: (0,0), End: (3,3)

Step 1: Queue=[(0,0)], Visited={(0,0)}
        Process (0,0), neighbors: (0,1), (1,0)
        Queue=[(0,1), (1,0)]

Step 2: Process (0,1), neighbor: (invalid or visited)
        Queue=[(1,0)]
        
Step 3: Process (1,0), neighbors: (2,0)
        Queue=[(2,0)]

Step 4: Process (2,0), neighbors: (2,1)
        Queue=[(2,1)]

Step 5: Process (2,1), neighbors: (2,2)
        Queue=[(2,2)]

Step 6: Process (2,2), neighbors: (3,2)
        Queue=[(3,2)]

Step 7: Process (3,2), neighbors: (3,3)
        Queue=[(3,3)]

Step 8: Process (3,3) = END
        PATH FOUND!

Path: (0,0) -> (1,0) -> (2,0) -> (2,1) -> (2,2) -> (3,2) -> (3,3)
```

## DFS Solution

```python
def solve_maze_dfs(maze, start, end):
    rows, cols = len(maze), len(maze[0])
    directions = [(0,1), (0,-1), (1,0), (-1,0)]
    visited = set()
    
    def dfs(r, c):
        if (r, c) == end:
            return True
        
        visited.add((r, c))
        
        for dr, dc in directions:
            nr, nc = r + dr, c + dc
            if (0 <= nr < rows and 0 <= nc < cols and
                maze[nr][nc] == 0 and (nr, nc) not in visited):
                if dfs(nr, nc):
                    return True
        
        return False
    
    return dfs(start[0], start[1])
```

## Time & Space Complexity

| Metric | Complexity |
|--------|------------|
| Time | O(rows * cols) |
| Space | O(rows * cols) |

## Key Points

1. **4-directional movement**: up, down, left, right
2. **Boundary check**: 0 <= r < rows, 0 <= c < cols
3. **Wall check**: maze[r][c] == 0
4. **BFS for shortest path**, DFS for any path
5. **Mark visited** to avoid infinite loops
