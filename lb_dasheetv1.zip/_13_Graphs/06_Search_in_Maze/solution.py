"""
Problem: Search in a Maze
=========================

Find path from source to destination in a 2D maze.
0 = open cell, 1 = wall

Time: O(rows * cols)
Space: O(rows * cols)
"""

from collections import deque
from typing import List, Tuple, Optional


def solve_maze_bfs(maze: List[List[int]], start: Tuple[int, int],
                   end: Tuple[int, int]) -> Optional[List[Tuple[int, int]]]:
    """
    BFS solution - finds SHORTEST path.
    """
    if not maze or maze[start[0]][start[1]] == 1 or maze[end[0]][end[1]] == 1:
        return None

    rows, cols = len(maze), len(maze[0])
    directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]

    queue = deque([(start, [start])])
    visited = {start}

    while queue:
        (r, c), path = queue.popleft()

        if (r, c) == end:
            return path

        for dr, dc in directions:
            nr, nc = r + dr, c + dc

            if (0 <= nr < rows and 0 <= nc < cols and
                maze[nr][nc] == 0 and (nr, nc) not in visited):
                visited.add((nr, nc))
                queue.append(((nr, nc), path + [(nr, nc)]))

    return None


def solve_maze_dfs(maze: List[List[int]], start: Tuple[int, int],
                   end: Tuple[int, int]) -> Optional[List[Tuple[int, int]]]:
    """
    DFS solution - finds any path (not necessarily shortest).
    """
    if not maze or maze[start[0]][start[1]] == 1 or maze[end[0]][end[1]] == 1:
        return None

    rows, cols = len(maze), len(maze[0])
    directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]
    visited = set()
    result = []

    def dfs(r: int, c: int, path: List[Tuple[int, int]]) -> bool:
        if (r, c) == end:
            result.extend(path)
            return True

        visited.add((r, c))

        for dr, dc in directions:
            nr, nc = r + dr, c + dc

            if (0 <= nr < rows and 0 <= nc < cols and
                maze[nr][nc] == 0 and (nr, nc) not in visited):
                if dfs(nr, nc, path + [(nr, nc)]):
                    return True

        return False

    if dfs(start[0], start[1], [start]):
        return result
    return None


def solve_maze_bfs_trace(maze: List[List[int]], start: Tuple[int, int],
                          end: Tuple[int, int]) -> None:
    """BFS with detailed trace."""
    rows, cols = len(maze), len(maze[0])
    directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]
    dir_names = ['right', 'left', 'down', 'up']

    print("\n" + "=" * 50)
    print("Maze Search - BFS")
    print("=" * 50)
    print(f"\nMaze ({rows}x{cols}):")
    for row in maze:
        print("  " + " ".join(str(c) for c in row))
    print(f"\nStart: {start}, End: {end}")

    queue = deque([start])
    visited = {start}
    parent = {start: None}
    step = 0

    while queue:
        step += 1
        print(f"\nStep {step}: Queue = {list(queue)}")

        r, c = queue.popleft()
        print(f"  Process ({r}, {c})")

        if (r, c) == end:
            # Reconstruct path
            path = []
            curr = end
            while curr:
                path.append(curr)
                curr = parent[curr]
            path.reverse()
            print(f"\n  PATH FOUND!")
            print(f"  Path: {' -> '.join(str(p) for p in path)}")
            print(f"  Length: {len(path)}")
            return

        for i, (dr, dc) in enumerate(directions):
            nr, nc = r + dr, c + dc

            if (0 <= nr < rows and 0 <= nc < cols and
                maze[nr][nc] == 0 and (nr, nc) not in visited):
                visited.add((nr, nc))
                parent[(nr, nc)] = (r, c)
                queue.append((nr, nc))
                print(f"    Add ({nr}, {nc}) [{dir_names[i]}]")

    print("\n  NO PATH FOUND!")


# Test
if __name__ == "__main__":
    maze = [
        [0, 0, 1, 0, 0],
        [0, 0, 0, 0, 1],
        [1, 0, 1, 0, 0],
        [0, 0, 0, 1, 0],
        [0, 1, 0, 0, 0]
    ]

    solve_maze_bfs_trace(maze, (0, 0), (4, 4))

    path = solve_maze_bfs(maze, (0, 0), (4, 4))
    print(f"\nBFS path: {path}")

    path = solve_maze_dfs(maze, (0, 0), (4, 4))
    print(f"DFS path: {path}")
