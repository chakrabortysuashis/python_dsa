"""
Problem: Word Ladder
====================

Find shortest transformation from beginWord to endWord,
changing one letter at a time, using only words from dictionary.

Time: O(M^2 * N) where M=word length, N=number of words
Space: O(M * N)
"""

from collections import deque
from typing import List, Set


def ladder_length(begin: str, end: str, word_list: List[str]) -> int:
    """BFS solution."""
    word_set = set(word_list)
    if end not in word_set:
        return 0

    queue = deque([(begin, 1)])
    visited = {begin}

    while queue:
        word, length = queue.popleft()

        if word == end:
            return length

        # Try changing each character
        for i in range(len(word)):
            for c in 'abcdefghijklmnopqrstuvwxyz':
                if c != word[i]:
                    new_word = word[:i] + c + word[i+1:]

                    if new_word in word_set and new_word not in visited:
                        visited.add(new_word)
                        queue.append((new_word, length + 1))

    return 0


def ladder_length_trace(begin: str, end: str, word_list: List[str]) -> int:
    """BFS with detailed trace."""
    word_set = set(word_list)

    print(f"\n{'='*50}")
    print(f"Word Ladder: {begin} -> {end}")
    print(f"Dictionary: {word_list}")
    print(f"{'='*50}")

    if end not in word_set:
        print("End word not in dictionary!")
        return 0

    queue = deque([(begin, 1, [begin])])
    visited = {begin}

    while queue:
        word, length, path = queue.popleft()
        print(f"\nLevel {length}: '{word}'")
        print(f"  Path: {' -> '.join(path)}")

        if word == end:
            print(f"\n{'='*50}")
            print(f"FOUND! Length: {length}")
            print(f"Path: {' -> '.join(path)}")
            return length

        # Find valid transformations
        transforms = []
        for i in range(len(word)):
            for c in 'abcdefghijklmnopqrstuvwxyz':
                if c != word[i]:
                    new_word = word[:i] + c + word[i+1:]
                    if new_word in word_set and new_word not in visited:
                        visited.add(new_word)
                        queue.append((new_word, length + 1, path + [new_word]))
                        transforms.append(f"{word}[{i}]={c} -> {new_word}")

        if transforms:
            print(f"  Transforms: {transforms}")

    print("\nNo path found!")
    return 0


def ladder_length_bidirectional(begin: str, end: str, word_list: List[str]) -> int:
    """Bidirectional BFS - faster for large dictionaries."""
    word_set = set(word_list)
    if end not in word_set:
        return 0

    front, back = {begin}, {end}
    visited = {begin, end}
    length = 1

    while front and back:
        if len(front) > len(back):
            front, back = back, front

        next_front = set()
        for word in front:
            for i in range(len(word)):
                for c in 'abcdefghijklmnopqrstuvwxyz':
                    new_word = word[:i] + c + word[i+1:]

                    if new_word in back:
                        return length + 1

                    if new_word in word_set and new_word not in visited:
                        visited.add(new_word)
                        next_front.add(new_word)

        front = next_front
        length += 1

    return 0


# Test
if __name__ == "__main__":
    # Test 1
    result = ladder_length_trace(
        "hit", "cog",
        ["hot", "dot", "dog", "lot", "log", "cog"]
    )
    print(f"\nResult: {result}")  # 5

    # Test 2: No path
    result = ladder_length(
        "hit", "cog",
        ["hot", "dot", "dog", "lot", "log"]  # "cog" missing
    )
    print(f"\nNo cog in dict: {result}")  # 0

    # Test bidirectional
    result = ladder_length_bidirectional(
        "hit", "cog",
        ["hot", "dot", "dog", "lot", "log", "cog"]
    )
    print(f"\nBidirectional: {result}")  # 5
