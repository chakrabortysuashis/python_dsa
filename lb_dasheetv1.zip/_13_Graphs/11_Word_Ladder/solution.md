# Word Ladder

## Problem Statement

Given two words (beginWord and endWord) and a dictionary, find the length of the shortest transformation sequence from beginWord to endWord, where:
1. Only one letter can be changed at a time
2. Each transformed word must exist in the dictionary

## Example

```
beginWord = "hit"
endWord = "cog"
wordList = ["hot","dot","dog","lot","log","cog"]

Transformation:
hit -> hot -> dot -> dog -> cog

Length: 5
```

## Graph Model

- Each word is a **vertex**
- Two words are connected if they differ by exactly one character
- Problem becomes: **Shortest path from beginWord to endWord**

```
Graph:
    hit
     |
    hot
   /   \
 dot   lot
  |     |
 dog   log
   \   /
    cog
```

## BFS Solution

```python
def ladder_length(begin, end, word_list):
    if end not in word_list:
        return 0
    
    word_set = set(word_list)
    queue = deque([(begin, 1)])
    visited = {begin}
    
    while queue:
        word, length = queue.popleft()
        
        if word == end:
            return length
        
        # Try changing each position
        for i in range(len(word)):
            for c in 'abcdefghijklmnopqrstuvwxyz':
                new_word = word[:i] + c + word[i+1:]
                
                if new_word in word_set and new_word not in visited:
                    visited.add(new_word)
                    queue.append((new_word, length + 1))
    
    return 0
```

## Dry Run

```
begin="hit", end="cog"
wordSet = {hot, dot, dog, lot, log, cog}

Level 1: Queue = [(hit, 1)]
         Process "hit", try all single-char changes
         Found "hot" in wordSet
         Queue = [(hot, 2)]

Level 2: Process "hot"
         Found "dot", "lot"
         Queue = [(dot, 3), (lot, 3)]

Level 3: Process "dot"
         Found "dog"
         Queue = [(lot, 3), (dog, 4)]

Level 3: Process "lot"
         Found "log"
         Queue = [(dog, 4), (log, 4)]

Level 4: Process "dog"
         Found "cog" = END!
         Return 5
```

## Optimization: Bidirectional BFS

Search from both ends simultaneously - meets in the middle.

```python
def ladder_length_bidirectional(begin, end, word_list):
    word_set = set(word_list)
    if end not in word_set:
        return 0
    
    front, back = {begin}, {end}
    visited = set()
    length = 1
    
    while front and back:
        # Always expand smaller set
        if len(front) > len(back):
            front, back = back, front
        
        next_front = set()
        for word in front:
            for i in range(len(word)):
                for c in 'abcdefghijklmnopqrstuvwxyz':
                    new_word = word[:i] + c + word[i+1:]
                    
                    if new_word in back:
                        return length + 1
                    
                    if new_word in word_set and new_word not in visited:
                        visited.add(new_word)
                        next_front.add(new_word)
        
        front = next_front
        length += 1
    
    return 0
```

## Time & Space Complexity

| Approach | Time | Space |
|----------|------|-------|
| BFS | O(M^2 * N) | O(M * N) |
| Bidirectional BFS | O(M^2 * N/2) | O(M * N) |

M = word length, N = number of words

## Key Points

1. Use BFS for shortest path
2. Generate neighbors by changing one character
3. Use Set for O(1) word lookup
4. Bidirectional BFS for optimization
