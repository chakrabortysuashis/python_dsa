# Flood Fill Algorithm

## Problem Statement

Given an image (2D grid), a starting pixel (sr, sc), and a new color, perform flood fill - change the color of the starting pixel and all connected pixels of the same original color to the new color.

## Visualization

```
Before:              After (fill from (1,1) with color 2):
1 1 1                2 2 2
1 1 0        ->      2 2 0
1 0 1                2 0 1

Starting pixel (1,1) has color 1
All connected 1's become 2
```

## Approach: BFS or DFS

Both work - flood fill is essentially finding connected component of same-colored pixels.

### BFS Solution
```python
def flood_fill_bfs(image, sr, sc, new_color):
    if image[sr][sc] == new_color:
        return image
    
    original = image[sr][sc]
    rows, cols = len(image), len(image[0])
    directions = [(0,1), (0,-1), (1,0), (-1,0)]
    
    queue = deque([(sr, sc)])
    image[sr][sc] = new_color
    
    while queue:
        r, c = queue.popleft()
        
        for dr, dc in directions:
            nr, nc = r + dr, c + dc
            if (0 <= nr < rows and 0 <= nc < cols and
                image[nr][nc] == original):
                image[nr][nc] = new_color
                queue.append((nr, nc))
    
    return image
```

### DFS Solution
```python
def flood_fill_dfs(image, sr, sc, new_color):
    if image[sr][sc] == new_color:
        return image
    
    original = image[sr][sc]
    rows, cols = len(image), len(image[0])
    
    def dfs(r, c):
        if (r < 0 or r >= rows or c < 0 or c >= cols or
            image[r][c] != original):
            return
        
        image[r][c] = new_color
        dfs(r+1, c)
        dfs(r-1, c)
        dfs(r, c+1)
        dfs(r, c-1)
    
    dfs(sr, sc)
    return image
```

## Dry Run

```
Image:           Queue/Stack states (BFS):
1 1 1            
1 1 0            Step 1: Start (1,1), Queue=[(1,1)]
1 0 1            Step 2: Process (1,1), add (0,1),(1,0),(2,1) - wait, (2,1)=0
                 Step 3: Queue=[(0,1), (1,0)]
Start: (1,1)     Step 4: Process (0,1), add (0,0), (0,2)
New color: 2     Step 5: Queue=[(1,0), (0,0), (0,2)]
                 ... continue until queue empty

Result:
2 2 2
2 2 0
2 0 1
```

## Time & Space Complexity

| Metric | Complexity |
|--------|------------|
| Time | O(rows * cols) |
| Space | O(rows * cols) |

## Key Points

1. Check if starting color equals new color (avoid infinite loop)
2. 4-directional connectivity (can extend to 8)
3. Change color immediately when adding to queue/visiting
4. Same as finding connected component
