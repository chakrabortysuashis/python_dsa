"""
Problem: Flood Fill Algorithm
=============================

Fill all connected same-colored pixels with a new color.
Like the paint bucket tool in image editors.

Time: O(rows * cols)
Space: O(rows * cols)
"""

from collections import deque
from typing import List


def flood_fill_bfs(image: List[List[int]], sr: int, sc: int, new_color: int) -> List[List[int]]:
    """
    BFS flood fill.
    """
    if image[sr][sc] == new_color:
        return image

    original = image[sr][sc]
    rows, cols = len(image), len(image[0])
    directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]

    queue = deque([(sr, sc)])
    image[sr][sc] = new_color

    while queue:
        r, c = queue.popleft()

        for dr, dc in directions:
            nr, nc = r + dr, c + dc
            if (0 <= nr < rows and 0 <= nc < cols and
                image[nr][nc] == original):
                image[nr][nc] = new_color
                queue.append((nr, nc))

    return image


def flood_fill_dfs(image: List[List[int]], sr: int, sc: int, new_color: int) -> List[List[int]]:
    """
    DFS flood fill (recursive).
    """
    if image[sr][sc] == new_color:
        return image

    original = image[sr][sc]
    rows, cols = len(image), len(image[0])

    def dfs(r: int, c: int) -> None:
        if (r < 0 or r >= rows or c < 0 or c >= cols or
            image[r][c] != original):
            return

        image[r][c] = new_color
        dfs(r + 1, c)
        dfs(r - 1, c)
        dfs(r, c + 1)
        dfs(r, c - 1)

    dfs(sr, sc)
    return image


def flood_fill_trace(image: List[List[int]], sr: int, sc: int, new_color: int) -> List[List[int]]:
    """Flood fill with trace."""
    print(f"\n{'='*40}")
    print("Flood Fill (BFS)")
    print(f"{'='*40}")
    print(f"Start: ({sr}, {sc})")
    print(f"New color: {new_color}")
    print("\nOriginal image:")
    for row in image:
        print("  ", row)

    if image[sr][sc] == new_color:
        print("Already the target color!")
        return image

    original = image[sr][sc]
    print(f"Original color: {original}")

    rows, cols = len(image), len(image[0])
    directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]

    queue = deque([(sr, sc)])
    image[sr][sc] = new_color
    count = 1

    while queue:
        r, c = queue.popleft()
        print(f"\nProcess ({r}, {c})")

        for dr, dc in directions:
            nr, nc = r + dr, c + dc
            if (0 <= nr < rows and 0 <= nc < cols and
                image[nr][nc] == original):
                image[nr][nc] = new_color
                queue.append((nr, nc))
                count += 1
                print(f"  Fill ({nr}, {nc})")

    print(f"\nFilled {count} cells")
    print("\nResult:")
    for row in image:
        print("  ", row)

    return image


# Test
if __name__ == "__main__":
    # Test 1
    image = [
        [1, 1, 1],
        [1, 1, 0],
        [1, 0, 1]
    ]
    flood_fill_trace([row[:] for row in image], 1, 1, 2)

    # Test 2
    image2 = [
        [0, 0, 0],
        [0, 0, 0]
    ]
    flood_fill_trace(image2, 0, 0, 0)  # Same color - no change
