"""
Kth Smallest Element in BST
===========================
Use inorder: Left -> Root -> Right (ascending order)
"""

from typing import Optional


class TreeNode:
    def __init__(self, val: int):
        self.val = val
        self.left = self.right = None


class Solution:
    def kthSmallest(self, root: Optional[TreeNode], k: int) -> Optional[int]:
        self.count = 0
        self.result = None

        def inorder(node):
            if not node or self.result is not None:
                return
            inorder(node.left)
            self.count += 1
            if self.count == k:
                self.result = node.val
                return
            inorder(node.right)

        inorder(root)
        return self.result

    def kthSmallest_iterative(self, root, k):
        stack = []
        while True:
            while root:
                stack.append(root)
                root = root.left
            root = stack.pop()
            k -= 1
            if k == 0:
                return root.val
            root = root.right


def test():
    root = TreeNode(50)
    root.left, root.right = TreeNode(30), TreeNode(70)
    root.left.left, root.left.right = TreeNode(20), TreeNode(40)
    root.right.left, root.right.right = TreeNode(60), TreeNode(80)

    sol = Solution()
    for k in range(1, 8):
        print(f"Kth smallest (k={k}): {sol.kthSmallest(root, k)}")


if __name__ == "__main__":
    test()
