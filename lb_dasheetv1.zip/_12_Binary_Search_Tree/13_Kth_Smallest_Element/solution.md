# Find Kth Smallest Element in BST

## Problem Statement
Find the kth smallest element in a BST.

## BST Property Usage
**Inorder traversal (Left -> Root -> Right) gives ascending order!**

Count k elements in inorder to find kth smallest.

## Algorithm
```python
def kth_smallest(root, k):
    count = 0
    result = None
    
    def inorder(node):
        if not node or count >= k:
            return
        inorder(node.left)   # Left first
        count += 1
        if count == k:
            result = node.val
            return
        inorder(node.right)
```

## Time & Space
- Time: O(h + k)
- Space: O(h) for recursion
