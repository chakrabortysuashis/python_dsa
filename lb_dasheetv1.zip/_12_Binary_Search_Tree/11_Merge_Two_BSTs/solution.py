"""
Merge Two BSTs
==============

Algorithm:
1. Inorder traversal of both BSTs (two sorted arrays)
2. Merge two sorted arrays
3. Build balanced BST from merged array

Time: O(m + n), Space: O(m + n)
"""

from typing import Optional, List


class TreeNode:
    def __init__(self, val: int):
        self.val = val
        self.left: Optional['TreeNode'] = None
        self.right: Optional['TreeNode'] = None


class Solution:
    def mergeBSTs(self, root1: Optional[TreeNode], root2: Optional[TreeNode]) -> Optional[TreeNode]:
        # Get sorted arrays
        arr1, arr2 = [], []
        self._inorder(root1, arr1)
        self._inorder(root2, arr2)

        # Merge sorted arrays
        merged = self._merge_sorted(arr1, arr2)

        # Build balanced BST
        return self._build_balanced(merged, 0, len(merged) - 1)

    def _inorder(self, node, result):
        if node:
            self._inorder(node.left, result)
            result.append(node.val)
            self._inorder(node.right, result)

    def _merge_sorted(self, arr1: List[int], arr2: List[int]) -> List[int]:
        result = []
        i = j = 0
        while i < len(arr1) and j < len(arr2):
            if arr1[i] <= arr2[j]:
                result.append(arr1[i])
                i += 1
            else:
                result.append(arr2[j])
                j += 1
        result.extend(arr1[i:])
        result.extend(arr2[j:])
        return result

    def _build_balanced(self, arr, start, end):
        if start > end:
            return None
        mid = (start + end) // 2
        node = TreeNode(arr[mid])
        node.left = self._build_balanced(arr, start, mid - 1)
        node.right = self._build_balanced(arr, mid + 1, end)
        return node


def inorder(root):
    if not root: return []
    return inorder(root.left) + [root.val] + inorder(root.right)


def test():
    # BST 1: [1, 3, 5]
    root1 = TreeNode(3)
    root1.left = TreeNode(1)
    root1.right = TreeNode(5)

    # BST 2: [2, 4, 6]
    root2 = TreeNode(4)
    root2.left = TreeNode(2)
    root2.right = TreeNode(6)

    print(f"BST1: {inorder(root1)}")
    print(f"BST2: {inorder(root2)}")

    sol = Solution()
    merged = sol.mergeBSTs(root1, root2)

    print(f"Merged: {inorder(merged)}")


if __name__ == "__main__":
    test()
