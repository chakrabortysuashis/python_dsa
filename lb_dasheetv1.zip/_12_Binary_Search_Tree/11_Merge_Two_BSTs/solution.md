# Merge Two BSTs

## Problem Statement

Given two BSTs, merge them into a single balanced BST containing all elements.

## BST Property Usage

Inorder of BST = Sorted array. Merge two sorted arrays, then build balanced BST.

## Algorithm

```python
def merge_bsts(root1, root2):
    # Step 1: Get sorted arrays
    arr1 = inorder(root1)
    arr2 = inorder(root2)
    
    # Step 2: Merge sorted arrays
    merged = merge_sorted(arr1, arr2)
    
    # Step 3: Build balanced BST
    return build_balanced(merged)
```

## Time and Space Complexity

- **Time**: O(m + n) for inorder + merge + build
- **Space**: O(m + n) for storing arrays
