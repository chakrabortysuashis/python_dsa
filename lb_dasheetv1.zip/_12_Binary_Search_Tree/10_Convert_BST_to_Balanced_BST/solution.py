"""
Convert BST to Balanced BST
===========================

Algorithm:
1. Inorder traversal to get sorted array
2. Build balanced BST using middle element as root

Time: O(n), Space: O(n)
"""

from typing import Optional, List


class TreeNode:
    def __init__(self, val: int):
        self.val = val
        self.left: Optional['TreeNode'] = None
        self.right: Optional['TreeNode'] = None


class Solution:
    def balanceBST(self, root: Optional[TreeNode]) -> Optional[TreeNode]:
        # Get sorted array
        sorted_arr = []
        self._inorder(root, sorted_arr)

        # Build balanced BST
        return self._build_balanced(sorted_arr, 0, len(sorted_arr) - 1)

    def _inorder(self, node: Optional[TreeNode], result: List[int]) -> None:
        if node:
            self._inorder(node.left, result)
            result.append(node.val)
            self._inorder(node.right, result)

    def _build_balanced(self, arr: List[int], start: int, end: int) -> Optional[TreeNode]:
        if start > end:
            return None

        mid = (start + end) // 2
        node = TreeNode(arr[mid])
        node.left = self._build_balanced(arr, start, mid - 1)
        node.right = self._build_balanced(arr, mid + 1, end)
        return node


def height(root):
    if not root:
        return 0
    return 1 + max(height(root.left), height(root.right))


def test():
    # Create skewed BST
    root = TreeNode(10)
    root.right = TreeNode(20)
    root.right.right = TreeNode(30)
    root.right.right.right = TreeNode(40)
    root.right.right.right.right = TreeNode(50)

    print(f"Original height: {height(root)}")

    sol = Solution()
    balanced = sol.balanceBST(root)

    print(f"Balanced height: {height(balanced)}")


if __name__ == "__main__":
    test()
