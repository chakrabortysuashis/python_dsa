# Convert Normal BST to Balanced BST

## Problem Statement

Given a BST that may be skewed, convert it to a balanced BST with minimum height.

**Example:**
```
Skewed BST:              Balanced BST:
    10                        30
     \                       /  \
      20                   20    40
       \          -->     /       \
        30               10        50
         \
          40
           \
            50
            
Height: 5 -> 3
```

## BST Property Usage

Key insight: **Inorder of BST = Sorted array**

A balanced BST from sorted array uses **middle element as root** recursively.

## Algorithm

```python
def balance_bst(root):
    # Step 1: Get sorted array via inorder
    sorted_arr = inorder(root)
    
    # Step 2: Build balanced BST from sorted array
    return build_balanced(sorted_arr, 0, len(sorted_arr) - 1)

def build_balanced(arr, start, end):
    if start > end:
        return None
    
    mid = (start + end) // 2
    node = TreeNode(arr[mid])
    node.left = build_balanced(arr, start, mid - 1)
    node.right = build_balanced(arr, mid + 1, end)
    return node
```

## Dry Run

```
Sorted array: [10, 20, 30, 40, 50]

build(0, 4): mid=2, root=30
  build(0, 1): mid=0, root=10
    build(1, 1): mid=1, root=20
  build(3, 4): mid=3, root=40
    build(4, 4): mid=4, root=50

Result:
        30
       /  \
      10   40
       \    \
       20   50
```

## Time and Space Complexity

- **Time**: O(n) for inorder + O(n) for building = O(n)
- **Space**: O(n) for storing sorted array
