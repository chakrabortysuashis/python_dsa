"""
Deletion of a Node in BST
=========================

Problem: Delete a node with given key from BST while maintaining BST property.

Three Cases:
1. Node is a leaf (no children) - Simply remove
2. Node has one child - Replace with child
3. Node has two children - Replace with inorder successor/predecessor

Time Complexity: O(h) where h = height
Space Complexity: O(h) recursive, O(1) iterative
"""

from typing import Optional, List


class TreeNode:
    """Node class for Binary Search Tree"""
    def __init__(self, val: int):
        self.val = val
        self.left: Optional['TreeNode'] = None
        self.right: Optional['TreeNode'] = None


class Solution:
    """
    Multiple approaches to delete node in BST
    """

    def deleteNode(self, root: Optional[TreeNode], key: int) -> Optional[TreeNode]:
        """
        Approach 1: Recursive Delete with Inorder Successor

        Algorithm:
        1. Find the node to delete using BST property
        2. Handle three cases:
           - No children: return None
           - One child: return that child
           - Two children: replace with inorder successor

        Time: O(h), Space: O(h)
        """
        if not root:
            return None

        # Step 1: Find the node to delete
        if key < root.val:
            # Key is in left subtree
            root.left = self.deleteNode(root.left, key)
        elif key > root.val:
            # Key is in right subtree
            root.right = self.deleteNode(root.right, key)
        else:
            # Step 2: Node found! Handle deletion

            # Case 1 & 2: Node has 0 or 1 child
            if not root.left:
                return root.right  # Return right child (or None if no children)
            if not root.right:
                return root.left   # Return left child

            # Case 3: Node has two children
            # Find inorder successor (minimum in right subtree)
            successor = self._find_min(root.right)

            # Copy successor's value to current node
            root.val = successor.val

            # Delete the successor from right subtree
            # Successor has at most one child (right), so this is Case 1 or 2
            root.right = self.deleteNode(root.right, successor.val)

        return root

    def _find_min(self, node: TreeNode) -> TreeNode:
        """Find node with minimum value (leftmost node)"""
        while node.left:
            node = node.left
        return node

    def deleteNode_predecessor(self, root: Optional[TreeNode], key: int) -> Optional[TreeNode]:
        """
        Approach 2: Delete using Inorder Predecessor

        Instead of successor, use largest value in left subtree.
        Both approaches are valid and maintain BST property.

        Time: O(h), Space: O(h)
        """
        if not root:
            return None

        if key < root.val:
            root.left = self.deleteNode_predecessor(root.left, key)
        elif key > root.val:
            root.right = self.deleteNode_predecessor(root.right, key)
        else:
            # Node found
            if not root.left:
                return root.right
            if not root.right:
                return root.left

            # Use predecessor instead of successor
            predecessor = self._find_max(root.left)
            root.val = predecessor.val
            root.left = self.deleteNode_predecessor(root.left, predecessor.val)

        return root

    def _find_max(self, node: TreeNode) -> TreeNode:
        """Find node with maximum value (rightmost node)"""
        while node.right:
            node = node.right
        return node

    def deleteNode_iterative(self, root: Optional[TreeNode], key: int) -> Optional[TreeNode]:
        """
        Approach 3: Iterative Delete

        Uses parent tracking to avoid recursion.
        More complex but O(1) space.

        Time: O(h), Space: O(1)
        """
        # Find the node and its parent
        parent = None
        current = root

        while current and current.val != key:
            parent = current
            if key < current.val:
                current = current.left
            else:
                current = current.right

        # Node not found
        if not current:
            return root

        # Case 3: Two children - reduce to case 1 or 2
        if current.left and current.right:
            # Find inorder successor and its parent
            succ_parent = current
            successor = current.right

            while successor.left:
                succ_parent = successor
                successor = successor.left

            # Copy successor value
            current.val = successor.val

            # Now delete successor (has at most one child)
            current = successor
            parent = succ_parent

        # Case 1 & 2: Zero or one child
        child = current.left if current.left else current.right

        if not parent:
            # Deleting root
            return child

        # Link parent to child
        if parent.left == current:
            parent.left = child
        else:
            parent.right = child

        return root

    def deleteNode_with_steps(self, root: Optional[TreeNode], key: int) -> tuple:
        """
        Approach 4: Delete with Step Tracking

        Returns the modified tree and deletion steps for visualization.
        """
        steps = []

        def delete_helper(node, k):
            if not node:
                steps.append(f"Node {k} not found")
                return None

            steps.append(f"At node {node.val}, looking for {k}")

            if k < node.val:
                steps.append(f"{k} < {node.val}, go left")
                node.left = delete_helper(node.left, k)
            elif k > node.val:
                steps.append(f"{k} > {node.val}, go right")
                node.right = delete_helper(node.right, k)
            else:
                steps.append(f"Found node {k}!")

                if not node.left and not node.right:
                    steps.append("Case 1: Leaf node - simply remove")
                    return None
                elif not node.left:
                    steps.append("Case 2: No left child - replace with right child")
                    return node.right
                elif not node.right:
                    steps.append("Case 2: No right child - replace with left child")
                    return node.left
                else:
                    steps.append("Case 3: Two children - find inorder successor")
                    successor = self._find_min(node.right)
                    steps.append(f"Successor is {successor.val}")
                    steps.append(f"Copy {successor.val} to current node")
                    node.val = successor.val
                    steps.append(f"Delete successor {successor.val} from right subtree")
                    node.right = delete_helper(node.right, successor.val)

            return node

        new_root = delete_helper(root, key)
        return new_root, steps


# ==================== Helper Functions ====================

def build_bst(values: List[int]) -> Optional[TreeNode]:
    """Build BST from list of values"""
    if not values:
        return None
    root = None
    for val in values:
        root = insert_bst(root, val)
    return root


def insert_bst(root: Optional[TreeNode], val: int) -> TreeNode:
    """Insert value into BST"""
    if not root:
        return TreeNode(val)
    if val < root.val:
        root.left = insert_bst(root.left, val)
    else:
        root.right = insert_bst(root.right, val)
    return root


def inorder(root: Optional[TreeNode]) -> List[int]:
    """Get inorder traversal (sorted order)"""
    if not root:
        return []
    return inorder(root.left) + [root.val] + inorder(root.right)


def print_tree(root: Optional[TreeNode], level: int = 0, prefix: str = "Root: ") -> None:
    """Print tree structure"""
    if root:
        print(" " * (level * 4) + prefix + str(root.val))
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            else:
                print(" " * ((level + 1) * 4) + "L--- None")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")
            else:
                print(" " * ((level + 1) * 4) + "R--- None")


# ==================== Test Cases ====================

def test_delete_node():
    """Comprehensive test cases for BST deletion"""
    solution = Solution()

    print("=" * 60)
    print("DELETE NODE IN BST - TEST CASES")
    print("=" * 60)

    # Test Case 1: Delete leaf node
    print("\nTest 1: Delete leaf node (20)")
    print("-" * 40)
    root = build_bst([50, 30, 70, 20, 40])
    print("Before:")
    print_tree(root)
    print(f"Inorder: {inorder(root)}")

    root = solution.deleteNode(root, 20)
    print("\nAfter deleting 20:")
    print_tree(root)
    print(f"Inorder: {inorder(root)}")

    # Test Case 2: Delete node with one child
    print("\nTest 2: Delete node with one child (30)")
    print("-" * 40)
    root = build_bst([50, 30, 70, 20])
    print("Before (30 has only left child):")
    print_tree(root)

    root = solution.deleteNode(root, 30)
    print("\nAfter deleting 30:")
    print_tree(root)
    print(f"Inorder: {inorder(root)}")

    # Test Case 3: Delete node with two children
    print("\nTest 3: Delete node with two children (30)")
    print("-" * 40)
    root = build_bst([50, 30, 70, 20, 40, 35])
    print("Before (30 has two children):")
    print_tree(root)
    print(f"Inorder: {inorder(root)}")

    # Use version with steps
    root, steps = solution.deleteNode_with_steps(root, 30)
    print("\nDeletion steps:")
    for step in steps:
        print(f"  - {step}")

    print("\nAfter deleting 30:")
    print_tree(root)
    print(f"Inorder: {inorder(root)}")

    # Test Case 4: Delete root
    print("\nTest 4: Delete root node")
    print("-" * 40)
    root = build_bst([50, 30, 70, 20, 40, 60, 80])
    print("Before:")
    print_tree(root)

    root = solution.deleteNode(root, 50)
    print("\nAfter deleting root (50):")
    print_tree(root)
    print(f"Inorder: {inorder(root)}")

    # Test Case 5: Delete non-existent value
    print("\nTest 5: Delete non-existent value")
    print("-" * 40)
    root = build_bst([50, 30, 70])
    print(f"Inorder before: {inorder(root)}")
    root = solution.deleteNode(root, 100)
    print(f"Inorder after trying to delete 100: {inorder(root)}")
    print("Tree unchanged!")

    # Test Case 6: Delete from single node tree
    print("\nTest 6: Delete from single node tree")
    print("-" * 40)
    root = TreeNode(42)
    print(f"Single node tree: {root.val}")
    root = solution.deleteNode(root, 42)
    print(f"After deleting 42: {root}")

    # Test Case 7: Compare successor vs predecessor approach
    print("\nTest 7: Successor vs Predecessor approach")
    print("-" * 40)
    values = [50, 30, 70, 20, 40, 60, 80]

    root1 = build_bst(values)
    root2 = build_bst(values)

    root1 = solution.deleteNode(root1, 50)  # Uses successor
    root2 = solution.deleteNode_predecessor(root2, 50)  # Uses predecessor

    print(f"Original: {values}")
    print(f"After delete 50 (successor method): {inorder(root1)}")
    print(f"After delete 50 (predecessor method): {inorder(root2)}")
    print("Both maintain BST property!")


def demonstrate_three_cases():
    """Visual demonstration of three deletion cases"""
    solution = Solution()

    print("\n" + "=" * 60)
    print("THREE CASES OF BST DELETION")
    print("=" * 60)

    # Case 1: Leaf node
    print("\n" + "-" * 40)
    print("CASE 1: Delete LEAF node (no children)")
    print("-" * 40)
    root = build_bst([50, 30, 70, 20, 40])
    print("\nBefore (deleting 20 - leaf):")
    print_tree(root)

    root, steps = solution.deleteNode_with_steps(root, 20)
    print("\nSteps:")
    for s in steps:
        print(f"  {s}")
    print("\nAfter:")
    print_tree(root)

    # Case 2: One child
    print("\n" + "-" * 40)
    print("CASE 2: Delete node with ONE child")
    print("-" * 40)
    root = build_bst([50, 30, 70, 20])
    print("\nBefore (deleting 30 - has left child only):")
    print_tree(root)

    root, steps = solution.deleteNode_with_steps(root, 30)
    print("\nSteps:")
    for s in steps:
        print(f"  {s}")
    print("\nAfter:")
    print_tree(root)

    # Case 3: Two children
    print("\n" + "-" * 40)
    print("CASE 3: Delete node with TWO children")
    print("-" * 40)
    root = build_bst([50, 30, 70, 20, 40, 35, 45])
    print("\nBefore (deleting 30 - has two children):")
    print_tree(root)

    root, steps = solution.deleteNode_with_steps(root, 30)
    print("\nSteps:")
    for s in steps:
        print(f"  {s}")
    print("\nAfter:")
    print_tree(root)


if __name__ == "__main__":
    test_delete_node()
    demonstrate_three_cases()
