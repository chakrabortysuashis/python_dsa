# Deletion of a Node in a BST

## Problem Statement

Given a BST and a key, delete the node with the given key and return the root of the modified BST. The deletion should maintain the BST property.

**Example:**
```
Delete 30 from:
        50                      50
       /  \                    /  \
      30   70      -->        35   70
     / \   / \               /    / \
    20 40 60  80            20   60  80
      /                       \
     35                        40
```

## BST Property Usage

When deleting a node, we must ensure the BST property is maintained:
- All values in left subtree remain **less than** parent
- All values in right subtree remain **greater than** parent

**Key Insight**: The **inorder successor** (smallest value in right subtree) or **inorder predecessor** (largest value in left subtree) can replace the deleted node without violating BST property!

## Three Cases of Deletion

### Case 1: Node is a Leaf (No Children)
```
Delete 20:
    50              50
   /  \            /  \
  30   70   -->   30   70
 /               
20               (simply remove)
```
Simply remove the node - no restructuring needed.

### Case 2: Node has ONE Child
```
Delete 30:
    50              50
   /  \            /  \
  30   70   -->   20   70
 /                
20               (replace with child)
```
Replace node with its only child - child takes node's position.

### Case 3: Node has TWO Children (Most Complex)
```
Delete 30:
    50              50
   /  \            /  \
  30   70   -->   35   70
 / \             /    / \
20  40          20   60  80
   /              \
  35               40
```
**Strategy**: Find inorder successor (or predecessor), copy its value, delete the successor.

## Recursion with Tree Visualization

### Recursive Delete Algorithm

```
delete(node, key):
    BASE CASE:
        if node is NULL -> return NULL
    
    FIND THE NODE:
        if key < node.val -> node.left = delete(node.left, key)
        if key > node.val -> node.right = delete(node.right, key)
    
    DELETE THE NODE (key == node.val):
        Case 1 & 2: if no left child -> return right child
                    if no right child -> return left child
        Case 3: find inorder successor
                copy successor's value to node
                delete successor from right subtree
```

### Visual Recursion - Delete 30

```
Tree:       50
           /  \
          30   70
         / \
        20  40
           /
          35

delete(50, 30)
    |
    30 < 50, go left
    |
    v
delete(30, 30) <-- Found! Node has two children
    |
    Find successor: minimum in right subtree = 35
    |
    Copy 35 to current node
    |
    Delete 35 from right subtree
    |
    v
delete(40, 35)
    |
    35 < 40, go left
    |
    v
delete(35, 35) <-- Found! Leaf node
    |
    Return NULL (Case 1)
```

## Step-by-Step Dry Run

**Delete 30 from BST:**

```
Initial:        50
               /  \
              30   70
             / \   / \
            20 40 60  80
              /
             35

Step 1: Search for 30
        At 50: 30 < 50, go left
        At 30: Found! Node has two children

Step 2: Find inorder successor
        Successor = minimum in right subtree
        Go to 40, then left to 35
        Successor = 35

Step 3: Copy successor's value
        Replace 30 with 35
        
        Tree now:   50
                   /  \
                  35   70
                 / \   / \
                20 40 60  80
                  /
                 35  <-- need to delete this

Step 4: Delete successor (35) from right subtree
        35 < 40, go left
        35 == 35, found!
        35 is a leaf, simply remove

Step 5: Final tree
                    50
                   /  \
                  35   70
                 /  \  / \
                20  40 60 80
```

**Dry Run Table:**

| Step | Action | Node | Decision |
|------|--------|------|----------|
| 1 | Find 30 | 50 | Go left (30 < 50) |
| 2 | Find 30 | 30 | Found! Has 2 children |
| 3 | Find successor | 40 | Go left |
| 4 | Find successor | 35 | No left child, this is min |
| 5 | Copy value | 30 | Replace 30 with 35 |
| 6 | Delete 35 | 40 | Go left (35 < 40) |
| 7 | Delete 35 | 35 | Leaf node, remove |

## Algorithm

```python
def delete_node(root, key):
    if not root:
        return None
    
    # Find the node to delete
    if key < root.val:
        root.left = delete_node(root.left, key)
    elif key > root.val:
        root.right = delete_node(root.right, key)
    else:
        # Node found - handle three cases
        
        # Case 1 & 2: Zero or one child
        if not root.left:
            return root.right
        if not root.right:
            return root.left
        
        # Case 3: Two children
        # Find inorder successor (min in right subtree)
        successor = find_min(root.right)
        
        # Copy successor's value
        root.val = successor.val
        
        # Delete successor from right subtree
        root.right = delete_node(root.right, successor.val)
    
    return root

def find_min(node):
    while node.left:
        node = node.left
    return node
```

## Time and Space Complexity

### Time Complexity

| Operation | Best/Average | Worst Case |
|-----------|--------------|------------|
| Find node | O(log n) | O(n) |
| Find successor | O(log n) | O(n) |
| Delete successor | O(log n) | O(n) |
| **Total** | **O(log n)** | **O(n)** |

**Why O(n) worst case?**
Skewed tree - height equals n, must traverse entire tree.

### Space Complexity

| Approach | Space | Reason |
|----------|-------|--------|
| Recursive | O(h) | Call stack |
| Iterative | O(1) | Constant space |

## Key Insights

1. **Three cases based on children count**
   - 0 children: Just remove
   - 1 child: Replace with child
   - 2 children: Replace with successor/predecessor

2. **Inorder successor maintains BST property**
   - Successor is smallest value greater than current
   - Safe to move up without violating BST

3. **Deletion reduces to simpler cases**
   - Case 3 always reduces to Case 1 or 2
   - Successor has at most one child (right)

4. **Alternative: Use predecessor**
   - Largest in left subtree works too
   - Some implementations alternate for balance

## Common Mistakes

1. **Not handling all three cases** - Each case needs different logic
2. **Forgetting to return modified subtree** - Recursive call results must be reconnected
3. **Not finding correct successor** - Must be minimum of RIGHT subtree
4. **Memory leak** - In languages without GC, must free deleted node

## Related Problems

- Delete all nodes in range
- Delete nodes with even values
- Convert BST to doubly linked list (similar traversal)
