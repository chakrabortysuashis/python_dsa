# Replace Element with Least Greater on Right

## Problem Statement
Given an array, replace each element with the smallest element greater than it on its right side. If no such element exists, replace with -1.

## BST Property Usage
Process array from right to left:
1. Insert each element into BST
2. Before inserting, find inorder successor (least greater element)

## Algorithm
```python
def replace_with_least_greater(arr):
    result = [-1] * len(arr)
    root = None
    
    for i in range(len(arr) - 1, -1, -1):
        successor = find_successor(root, arr[i])
        result[i] = successor if successor else -1
        root = insert(root, arr[i])
    
    return result
```

## Time & Space
- Time: O(n * h) average O(n log n), worst O(n^2)
- Space: O(n) for BST
