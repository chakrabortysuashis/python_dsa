"""
Replace Element with Least Greater on Right
============================================
Process from right, use BST for efficient successor finding
"""

from typing import List, Optional


class TreeNode:
    def __init__(self, val: int):
        self.val = val
        self.left = self.right = None


class Solution:
    def replaceWithLeastGreater(self, arr: List[int]) -> List[int]:
        n = len(arr)
        result = [-1] * n
        root = None

        for i in range(n - 1, -1, -1):
            # Find successor before inserting
            result[i] = self._find_successor(root, arr[i])
            root = self._insert(root, arr[i])

        return result

    def _insert(self, root, val):
        if not root:
            return TreeNode(val)
        if val < root.val:
            root.left = self._insert(root.left, val)
        else:
            root.right = self._insert(root.right, val)
        return root

    def _find_successor(self, root, val):
        successor = -1
        while root:
            if val < root.val:
                successor = root.val
                root = root.left
            else:
                root = root.right
        return successor


def test():
    arr = [8, 58, 71, 18, 31, 32, 63, 92, 43, 3, 91, 93, 25, 80, 28]
    sol = Solution()
    result = sol.replaceWithLeastGreater(arr)
    print(f"Original: {arr}")
    print(f"Result:   {result}")


if __name__ == "__main__":
    test()
