"""
Binary Search Tree (BST) - Complete Implementation
==================================================

BST Property: For every node N:
- All values in left subtree < N.value
- All values in right subtree > N.value

Time Complexity:
- Balanced BST: O(log n) for search, insert, delete
- Skewed BST: O(n) worst case
"""

from typing import Optional, List, Tuple


class TreeNode:
    """Node class for Binary Search Tree"""

    def __init__(self, val: int):
        self.val = val
        self.left: Optional['TreeNode'] = None
        self.right: Optional['TreeNode'] = None

    def __repr__(self):
        return f"TreeNode({self.val})"


class BST:
    """
    Binary Search Tree with all standard operations.

    Operations:
    - insert(val): Insert a value into BST
    - search(val): Search for a value in BST
    - delete(val): Delete a value from BST
    - find_min(): Find minimum value
    - find_max(): Find maximum value
    - inorder(): Return sorted order (inorder traversal)
    - preorder(): Return preorder traversal
    - postorder(): Return postorder traversal
    - height(): Return height of tree
    - is_valid_bst(): Check if tree satisfies BST property
    """

    def __init__(self):
        self.root: Optional[TreeNode] = None

    # ==================== INSERT ====================
    def insert(self, val: int) -> None:
        """
        Insert a value into the BST.

        Algorithm:
        1. If tree is empty, create root
        2. Otherwise, compare with current node
        3. If val < current, go left; else go right
        4. Insert at the first NULL position

        Time: O(h) where h = height of tree
        Space: O(h) for recursive stack
        """
        self.root = self._insert_recursive(self.root, val)

    def _insert_recursive(self, node: Optional[TreeNode], val: int) -> TreeNode:
        # Base case: found the insertion point
        if node is None:
            return TreeNode(val)

        # BST property: smaller goes left, larger goes right
        if val < node.val:
            node.left = self._insert_recursive(node.left, val)
        else:  # val >= node.val (duplicates go right)
            node.right = self._insert_recursive(node.right, val)

        return node

    def insert_iterative(self, val: int) -> None:
        """Iterative version of insert - O(1) space"""
        new_node = TreeNode(val)

        if self.root is None:
            self.root = new_node
            return

        current = self.root
        while True:
            if val < current.val:
                if current.left is None:
                    current.left = new_node
                    return
                current = current.left
            else:
                if current.right is None:
                    current.right = new_node
                    return
                current = current.right

    # ==================== SEARCH ====================
    def search(self, val: int) -> Optional[TreeNode]:
        """
        Search for a value in BST.

        Algorithm:
        1. Start at root
        2. If val == current, found!
        3. If val < current, search left subtree
        4. If val > current, search right subtree
        5. If NULL, not found

        Time: O(h) where h = height
        Space: O(h) recursive, O(1) iterative
        """
        return self._search_recursive(self.root, val)

    def _search_recursive(self, node: Optional[TreeNode], val: int) -> Optional[TreeNode]:
        # Base cases: not found or found
        if node is None or node.val == val:
            return node

        # BST property guides the search
        if val < node.val:
            return self._search_recursive(node.left, val)
        else:
            return self._search_recursive(node.right, val)

    def search_iterative(self, val: int) -> Optional[TreeNode]:
        """Iterative search - O(1) space"""
        current = self.root
        while current:
            if val == current.val:
                return current
            elif val < current.val:
                current = current.left
            else:
                current = current.right
        return None

    def search_with_path(self, val: int) -> Tuple[Optional[TreeNode], List[int]]:
        """Search and return the path taken"""
        path = []
        current = self.root
        while current:
            path.append(current.val)
            if val == current.val:
                return current, path
            elif val < current.val:
                current = current.left
            else:
                current = current.right
        return None, path

    # ==================== DELETE ====================
    def delete(self, val: int) -> None:
        """
        Delete a value from BST.

        Three cases:
        1. Node is a leaf (no children): Simply remove it
        2. Node has one child: Replace node with its child
        3. Node has two children:
           - Find inorder successor (min in right subtree)
           - Replace node's value with successor's value
           - Delete the successor

        Time: O(h) where h = height
        Space: O(h) for recursive stack
        """
        self.root = self._delete_recursive(self.root, val)

    def _delete_recursive(self, node: Optional[TreeNode], val: int) -> Optional[TreeNode]:
        # Base case: node not found
        if node is None:
            return None

        # Find the node to delete
        if val < node.val:
            node.left = self._delete_recursive(node.left, val)
        elif val > node.val:
            node.right = self._delete_recursive(node.right, val)
        else:
            # Node found! Handle three cases:

            # Case 1 & 2: Node has 0 or 1 child
            if node.left is None:
                return node.right
            if node.right is None:
                return node.left

            # Case 3: Node has two children
            # Find inorder successor (smallest in right subtree)
            successor = self._find_min_node(node.right)

            # Replace current node's value with successor's value
            node.val = successor.val

            # Delete the successor from right subtree
            node.right = self._delete_recursive(node.right, successor.val)

        return node

    # ==================== MIN / MAX ====================
    def find_min(self) -> Optional[int]:
        """
        Find minimum value in BST.

        Key insight: Minimum is always at the leftmost node!
        Because all values in left subtree are smaller.

        Time: O(h)
        """
        if self.root is None:
            return None
        node = self._find_min_node(self.root)
        return node.val if node else None

    def _find_min_node(self, node: TreeNode) -> TreeNode:
        """Find the node with minimum value in subtree"""
        current = node
        while current.left:
            current = current.left
        return current

    def find_max(self) -> Optional[int]:
        """
        Find maximum value in BST.

        Key insight: Maximum is always at the rightmost node!
        Because all values in right subtree are larger.

        Time: O(h)
        """
        if self.root is None:
            return None
        node = self._find_max_node(self.root)
        return node.val if node else None

    def _find_max_node(self, node: TreeNode) -> TreeNode:
        """Find the node with maximum value in subtree"""
        current = node
        while current.right:
            current = current.right
        return current

    # ==================== TRAVERSALS ====================
    def inorder(self) -> List[int]:
        """
        Inorder traversal: Left -> Root -> Right

        KEY PROPERTY: Inorder of BST gives SORTED order!

        Why? We visit all smaller values (left), then current,
        then all larger values (right).

        Time: O(n), Space: O(n)
        """
        result = []
        self._inorder_recursive(self.root, result)
        return result

    def _inorder_recursive(self, node: Optional[TreeNode], result: List[int]) -> None:
        if node:
            self._inorder_recursive(node.left, result)   # Left subtree
            result.append(node.val)                       # Current node
            self._inorder_recursive(node.right, result)  # Right subtree

    def inorder_iterative(self) -> List[int]:
        """Iterative inorder using stack"""
        result = []
        stack = []
        current = self.root

        while current or stack:
            # Go to leftmost node
            while current:
                stack.append(current)
                current = current.left

            # Process current node
            current = stack.pop()
            result.append(current.val)

            # Move to right subtree
            current = current.right

        return result

    def preorder(self) -> List[int]:
        """
        Preorder traversal: Root -> Left -> Right

        Useful for creating a copy of the tree or
        getting prefix expression.
        """
        result = []
        self._preorder_recursive(self.root, result)
        return result

    def _preorder_recursive(self, node: Optional[TreeNode], result: List[int]) -> None:
        if node:
            result.append(node.val)                        # Current node
            self._preorder_recursive(node.left, result)    # Left subtree
            self._preorder_recursive(node.right, result)   # Right subtree

    def postorder(self) -> List[int]:
        """
        Postorder traversal: Left -> Right -> Root

        Useful for deleting tree or getting postfix expression.
        """
        result = []
        self._postorder_recursive(self.root, result)
        return result

    def _postorder_recursive(self, node: Optional[TreeNode], result: List[int]) -> None:
        if node:
            self._postorder_recursive(node.left, result)   # Left subtree
            self._postorder_recursive(node.right, result)  # Right subtree
            result.append(node.val)                         # Current node

    def level_order(self) -> List[List[int]]:
        """
        Level order traversal (BFS).
        Returns values level by level.
        """
        if not self.root:
            return []

        result = []
        queue = [self.root]

        while queue:
            level_size = len(queue)
            level = []

            for _ in range(level_size):
                node = queue.pop(0)
                level.append(node.val)

                if node.left:
                    queue.append(node.left)
                if node.right:
                    queue.append(node.right)

            result.append(level)

        return result

    # ==================== UTILITY FUNCTIONS ====================
    def height(self) -> int:
        """
        Calculate height of BST.

        Height = max depth from root to any leaf
        Empty tree has height -1, single node has height 0.

        Time: O(n)
        """
        return self._height_recursive(self.root)

    def _height_recursive(self, node: Optional[TreeNode]) -> int:
        if node is None:
            return -1
        return 1 + max(self._height_recursive(node.left),
                       self._height_recursive(node.right))

    def size(self) -> int:
        """Count total nodes in BST"""
        return self._size_recursive(self.root)

    def _size_recursive(self, node: Optional[TreeNode]) -> int:
        if node is None:
            return 0
        return 1 + self._size_recursive(node.left) + self._size_recursive(node.right)

    def is_valid_bst(self) -> bool:
        """
        Check if tree satisfies BST property.

        Method: Use range validation
        - Each node must be within (min_val, max_val)
        - For left child: max becomes parent's value
        - For right child: min becomes parent's value
        """
        return self._is_valid_recursive(self.root, float('-inf'), float('inf'))

    def _is_valid_recursive(self, node: Optional[TreeNode],
                            min_val: float, max_val: float) -> bool:
        if node is None:
            return True

        # Check BST property
        if node.val <= min_val or node.val >= max_val:
            return False

        # Recursively validate subtrees with updated ranges
        return (self._is_valid_recursive(node.left, min_val, node.val) and
                self._is_valid_recursive(node.right, node.val, max_val))

    # ==================== INORDER SUCCESSOR/PREDECESSOR ====================
    def inorder_successor(self, val: int) -> Optional[int]:
        """
        Find inorder successor of a value.

        Inorder successor = smallest value greater than val

        Two cases:
        1. Node has right subtree: successor is min of right subtree
        2. No right subtree: go up until we find a parent from left
        """
        successor = None
        current = self.root

        while current:
            if val < current.val:
                successor = current  # This could be the successor
                current = current.left
            else:
                current = current.right

        return successor.val if successor else None

    def inorder_predecessor(self, val: int) -> Optional[int]:
        """
        Find inorder predecessor of a value.

        Inorder predecessor = largest value smaller than val
        """
        predecessor = None
        current = self.root

        while current:
            if val > current.val:
                predecessor = current  # This could be the predecessor
                current = current.right
            else:
                current = current.left

        return predecessor.val if predecessor else None

    # ==================== RANGE QUERIES ====================
    def range_query(self, low: int, high: int) -> List[int]:
        """
        Find all values in range [low, high].

        BST property helps prune search:
        - If node.val > low, search left subtree
        - If node.val in range, include it
        - If node.val < high, search right subtree

        Time: O(h + k) where k = number of values in range
        """
        result = []
        self._range_query_recursive(self.root, low, high, result)
        return result

    def _range_query_recursive(self, node: Optional[TreeNode],
                               low: int, high: int, result: List[int]) -> None:
        if node is None:
            return

        # If node.val > low, there might be values in left subtree
        if node.val > low:
            self._range_query_recursive(node.left, low, high, result)

        # If node.val is in range, include it
        if low <= node.val <= high:
            result.append(node.val)

        # If node.val < high, there might be values in right subtree
        if node.val < high:
            self._range_query_recursive(node.right, low, high, result)

    def count_in_range(self, low: int, high: int) -> int:
        """Count nodes with values in range [low, high]"""
        return len(self.range_query(low, high))

    # ==================== KTH SMALLEST/LARGEST ====================
    def kth_smallest(self, k: int) -> Optional[int]:
        """
        Find kth smallest element (1-indexed).

        Use inorder traversal and count!
        Inorder gives sorted order, so kth element is kth smallest.
        """
        self.count = 0
        self.result = None
        self._kth_smallest_recursive(self.root, k)
        return self.result

    def _kth_smallest_recursive(self, node: Optional[TreeNode], k: int) -> None:
        if node is None or self.result is not None:
            return

        # Inorder: left, root, right
        self._kth_smallest_recursive(node.left, k)

        self.count += 1
        if self.count == k:
            self.result = node.val
            return

        self._kth_smallest_recursive(node.right, k)

    def kth_largest(self, k: int) -> Optional[int]:
        """
        Find kth largest element (1-indexed).

        Use reverse inorder (right, root, left) and count!
        """
        self.count = 0
        self.result = None
        self._kth_largest_recursive(self.root, k)
        return self.result

    def _kth_largest_recursive(self, node: Optional[TreeNode], k: int) -> None:
        if node is None or self.result is not None:
            return

        # Reverse inorder: right, root, left
        self._kth_largest_recursive(node.right, k)

        self.count += 1
        if self.count == k:
            self.result = node.val
            return

        self._kth_largest_recursive(node.left, k)

    # ==================== LCA (Lowest Common Ancestor) ====================
    def lca(self, p: int, q: int) -> Optional[int]:
        """
        Find Lowest Common Ancestor of two values.

        BST property makes this easy:
        - If both p, q < node: LCA is in left subtree
        - If both p, q > node: LCA is in right subtree
        - Otherwise: current node is the split point (LCA)

        Time: O(h)
        """
        current = self.root
        while current:
            if p < current.val and q < current.val:
                current = current.left
            elif p > current.val and q > current.val:
                current = current.right
            else:
                return current.val
        return None

    # ==================== VISUALIZATION ====================
    def display(self) -> None:
        """Display BST structure"""
        if not self.root:
            print("(empty tree)")
            return

        lines = []
        self._display_recursive(self.root, "", True, lines)
        print("\n".join(lines))

    def _display_recursive(self, node: Optional[TreeNode], prefix: str,
                           is_tail: bool, lines: List[str]) -> None:
        if node is None:
            return

        connector = "\\-- " if is_tail else "|-- "
        lines.append(prefix + connector + str(node.val))

        children = []
        if node.left:
            children.append(("L", node.left))
        if node.right:
            children.append(("R", node.right))

        for i, (label, child) in enumerate(children):
            is_last = (i == len(children) - 1)
            new_prefix = prefix + ("    " if is_tail else "|   ")
            self._display_recursive(child, new_prefix, is_last, lines)


# ==================== HELPER FUNCTIONS ====================

def build_bst_from_list(values: List[int]) -> BST:
    """Build BST by inserting values in order"""
    bst = BST()
    for val in values:
        bst.insert(val)
    return bst


def sorted_array_to_bst(arr: List[int]) -> BST:
    """
    Build a balanced BST from sorted array.

    Strategy: Use middle element as root for balance
    """
    bst = BST()
    bst.root = _sorted_array_to_bst_recursive(arr, 0, len(arr) - 1)
    return bst


def _sorted_array_to_bst_recursive(arr: List[int], start: int, end: int) -> Optional[TreeNode]:
    if start > end:
        return None

    mid = (start + end) // 2
    node = TreeNode(arr[mid])
    node.left = _sorted_array_to_bst_recursive(arr, start, mid - 1)
    node.right = _sorted_array_to_bst_recursive(arr, mid + 1, end)
    return node


# ==================== DEMONSTRATION ====================

def main():
    print("=" * 60)
    print("BINARY SEARCH TREE - COMPLETE DEMONSTRATION")
    print("=" * 60)

    # Create BST
    bst = BST()
    values = [50, 30, 70, 20, 40, 60, 80, 10, 35]

    print("\n1. INSERTING VALUES:", values)
    for val in values:
        bst.insert(val)

    print("\nBST Structure:")
    bst.display()

    # Traversals
    print("\n2. TRAVERSALS:")
    print(f"   Inorder (SORTED):  {bst.inorder()}")
    print(f"   Preorder:          {bst.preorder()}")
    print(f"   Postorder:         {bst.postorder()}")
    print(f"   Level order:       {bst.level_order()}")

    # Search
    print("\n3. SEARCH OPERATIONS:")
    for target in [40, 25, 80]:
        node, path = bst.search_with_path(target)
        status = "Found" if node else "Not found"
        print(f"   Search {target}: {status}, Path: {path}")

    # Min/Max
    print("\n4. MIN/MAX:")
    print(f"   Minimum: {bst.find_min()}")
    print(f"   Maximum: {bst.find_max()}")

    # Successor/Predecessor
    print("\n5. SUCCESSOR/PREDECESSOR:")
    for val in [30, 40, 50]:
        succ = bst.inorder_successor(val)
        pred = bst.inorder_predecessor(val)
        print(f"   Value {val}: Successor={succ}, Predecessor={pred}")

    # Range Query
    print("\n6. RANGE QUERY [25, 65]:")
    print(f"   Values: {bst.range_query(25, 65)}")

    # Kth smallest/largest
    print("\n7. KTH ELEMENT:")
    print(f"   3rd smallest: {bst.kth_smallest(3)}")
    print(f"   3rd largest:  {bst.kth_largest(3)}")

    # LCA
    print("\n8. LOWEST COMMON ANCESTOR:")
    print(f"   LCA(20, 40) = {bst.lca(20, 40)}")
    print(f"   LCA(20, 80) = {bst.lca(20, 80)}")

    # Tree properties
    print("\n9. TREE PROPERTIES:")
    print(f"   Height: {bst.height()}")
    print(f"   Size:   {bst.size()}")
    print(f"   Valid BST: {bst.is_valid_bst()}")

    # Delete
    print("\n10. DELETE OPERATIONS:")
    print(f"   Before delete: {bst.inorder()}")

    print("   Deleting 20 (leaf node)...")
    bst.delete(20)
    print(f"   After:  {bst.inorder()}")

    print("   Deleting 30 (node with two children)...")
    bst.delete(30)
    print(f"   After:  {bst.inorder()}")

    print("\n   Final BST Structure:")
    bst.display()

    # Balanced BST from sorted array
    print("\n11. BALANCED BST FROM SORTED ARRAY:")
    sorted_arr = [10, 20, 30, 40, 50, 60, 70]
    balanced_bst = sorted_array_to_bst(sorted_arr)
    print(f"   Input: {sorted_arr}")
    print("   Balanced BST:")
    balanced_bst.display()
    print(f"   Height: {balanced_bst.height()} (optimal for {len(sorted_arr)} nodes)")


if __name__ == "__main__":
    main()
