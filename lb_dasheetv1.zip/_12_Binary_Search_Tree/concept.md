# Binary Search Tree (BST) - Complete Guide

## What is a Binary Search Tree?

A **Binary Search Tree (BST)** is a binary tree data structure where each node follows a specific ordering property:

```
        For any node N:
        - All values in LEFT subtree < N.value
        - All values in RIGHT subtree > N.value
        
                    50
                   /  \
                  30   70
                 / \   / \
                20 40 60  80
                
        Every node satisfies: left < node < right
```

## The BST Property

### Core Property
```
For every node in the tree:
1. Left subtree contains only nodes with values LESS than the node
2. Right subtree contains only nodes with values GREATER than the node
3. Both left and right subtrees must also be BSTs
```

### Visual Example
```
                    50 (root)
                   /  \
                  30   70
                 / \   / \
                20 40 60  80
               /
              10

Verify BST property:
- Node 50: Left subtree (30,20,40,10) all < 50 ✓
           Right subtree (70,60,80) all > 50 ✓
- Node 30: Left (20,10) < 30, Right (40) > 30 ✓
- Node 70: Left (60) < 70, Right (80) > 70 ✓
```

## Why Use BST for Searching?

### The Power of Elimination

BST enables **binary search** on a tree structure:

```
Search for 40 in BST:

Step 1:     [50]        40 < 50, go LEFT
           /    \
         30      70
        / \     / \
       20  40  60  80

Step 2:      50
           /    \
         [30]    70      40 > 30, go RIGHT
        /   \   / \
       20   40 60  80

Step 3:      50
           /    \
          30     70
        /   \   / \
       20  [40] 60  80   FOUND!

Only 3 comparisons instead of checking all 7 nodes!
```

### Comparison with Other Structures

| Operation | Array (unsorted) | Array (sorted) | Linked List | BST (balanced) |
|-----------|-----------------|----------------|-------------|----------------|
| Search    | O(n)            | O(log n)       | O(n)        | O(log n)       |
| Insert    | O(1)            | O(n)           | O(1)        | O(log n)       |
| Delete    | O(n)            | O(n)           | O(n)        | O(log n)       |

**BST gives us the best of both worlds**: fast search like sorted array + fast insert/delete like linked list.

## BST Operations

### 1. Search Operation

```
ALGORITHM: Search(node, target)
    if node is NULL:
        return NOT_FOUND
    if target == node.value:
        return FOUND
    if target < node.value:
        return Search(node.left, target)    // Go left
    else:
        return Search(node.right, target)   // Go right
```

**Visual Trace - Search for 25:**
```
        50
       /  \
      30   70
     / \
    20  40
   /
  10

Step 1: 25 < 50, go LEFT to 30
Step 2: 25 < 30, go LEFT to 20
Step 3: 25 > 20, go RIGHT (NULL)
Result: 25 NOT FOUND
```

### 2. Insert Operation

```
ALGORITHM: Insert(node, value)
    if node is NULL:
        return new Node(value)
    if value < node.value:
        node.left = Insert(node.left, value)
    else:
        node.right = Insert(node.right, value)
    return node
```

**Visual Trace - Insert 25:**
```
Before:         After:
    50              50
   /  \            /  \
  30   70        30   70
 / \            / \
20  40        20  40
             /
            10     (existing)
             \
             25    <-- NEW NODE

Path: 50 -> 30 -> 20 -> (25 > 20, insert as right child)
```

### 3. Delete Operation (Most Complex)

Three cases to handle:

#### Case 1: Node has NO children (Leaf)
```
Delete 40:
    50              50
   /  \            /  \
  30   70   -->   30   70
 / \             /
20  40          20

Simply remove the node
```

#### Case 2: Node has ONE child
```
Delete 20:
    50              50
   /  \            /  \
  30   70   -->   30   70
 /               /
20              10
 \
 10

Replace node with its only child
```

#### Case 3: Node has TWO children
```
Delete 30 (has two children):

Method: Replace with INORDER SUCCESSOR (smallest in right subtree)
        OR INORDER PREDECESSOR (largest in left subtree)

    50                  50
   /  \                /  \
  30   70    -->      35   70
 / \                 /
20  40              20
   /                  \
  35                   40
                      (35 moved up)

Step 1: Find inorder successor of 30 (which is 35)
Step 2: Replace 30's value with 35
Step 3: Delete original 35 (which is Case 1 or 2)
```

**Complete Delete Algorithm:**
```
ALGORITHM: Delete(node, value)
    if node is NULL:
        return NULL
    
    if value < node.value:
        node.left = Delete(node.left, value)
    else if value > node.value:
        node.right = Delete(node.right, value)
    else:
        // Found the node to delete
        if node.left is NULL:
            return node.right
        if node.right is NULL:
            return node.left
        
        // Node has two children
        successor = findMin(node.right)
        node.value = successor.value
        node.right = Delete(node.right, successor.value)
    
    return node
```

## Inorder Traversal Gives Sorted Order

**Key Property**: Inorder traversal of a BST produces elements in SORTED order!

```
BST:            Inorder: Left -> Root -> Right
    50
   /  \         Visit order:
  30   70       10 -> 20 -> 30 -> 40 -> 50 -> 60 -> 70 -> 80
 / \   / \
20 40 60  80    Output: [10, 20, 30, 40, 50, 60, 70, 80]
/                       ^ SORTED! ^
10

WHY? Because we always visit:
1. All smaller values first (left subtree)
2. Then current value (root)
3. Then all larger values (right subtree)
```

**Algorithm:**
```
def inorder(node):
    if node:
        inorder(node.left)      # All smaller values
        print(node.value)       # Current value
        inorder(node.right)     # All larger values
```

## Time Complexity Analysis

### Balanced vs Skewed BST

**Balanced BST:**
```
        50
       /  \
      25   75
     / \   / \
    10 30 60  90

Height = log(n)
Operations = O(log n)
```

**Skewed BST (Worst Case):**
```
    10
     \
      20
       \
        30
         \
          40
           \
            50

Becomes a linked list!
Height = n
Operations = O(n)
```

### Complexity Summary

| Operation | Best/Average Case | Worst Case (Skewed) |
|-----------|-------------------|---------------------|
| Search    | O(log n)          | O(n)                |
| Insert    | O(log n)          | O(n)                |
| Delete    | O(log n)          | O(n)                |
| Minimum   | O(log n)          | O(n)                |
| Maximum   | O(log n)          | O(n)                |

**Space Complexity:**
- Iterative operations: O(1)
- Recursive operations: O(h) where h = height of tree

## Self-Balancing BSTs

To guarantee O(log n) operations, we use self-balancing BSTs:

### 1. AVL Tree

**Property**: For every node, |height(left) - height(right)| <= 1

```
Valid AVL:          Invalid AVL:
    30                  30
   /  \                /
  20   40             20
 /                   /
10                  10
                   /
Height diff = 1    5
                   Height diff = 3 (violates AVL)
```

**Rotations** are used to maintain balance:
```
Right Rotation:        Left Rotation:
    30                     10
   /                        \
  20       -->    20         20      -->    20
 /               /  \          \           /  \
10              10   30         30        10   30
```

### 2. Red-Black Tree

**Properties:**
1. Every node is either RED or BLACK
2. Root is always BLACK
3. No two consecutive RED nodes
4. Every path from root to NULL has same number of BLACK nodes

```
         (B)50
        /     \
     (R)30    (R)70
      / \      / \
   (B)20(B)40(B)60(B)80

B = Black, R = Red
```

### Comparison of Self-Balancing BSTs

| Feature | AVL | Red-Black |
|---------|-----|-----------|
| Balance | Strictly balanced | Loosely balanced |
| Search | Faster (shorter height) | Slightly slower |
| Insert/Delete | More rotations | Fewer rotations |
| Use case | Read-heavy | Write-heavy |

## Common BST Patterns

### Pattern 1: Range Queries
```python
# Find all values in range [low, high]
def range_query(node, low, high, result):
    if not node:
        return
    if node.val > low:
        range_query(node.left, low, high, result)
    if low <= node.val <= high:
        result.append(node.val)
    if node.val < high:
        range_query(node.right, low, high, result)
```

### Pattern 2: Kth Smallest/Largest
```
Use inorder traversal and count!
- Kth smallest: Inorder, stop at kth
- Kth largest: Reverse inorder, stop at kth
```

### Pattern 3: Validate BST
```python
def is_valid_bst(node, min_val, max_val):
    if not node:
        return True
    if node.val <= min_val or node.val >= max_val:
        return False
    return (is_valid_bst(node.left, min_val, node.val) and
            is_valid_bst(node.right, node.val, max_val))
```

### Pattern 4: LCA in BST
```
LCA of p and q:
- If both < node.val: LCA is in left subtree
- If both > node.val: LCA is in right subtree
- Otherwise: current node is LCA (split point)
```

## Key Takeaways

1. **BST Property**: left < root < right enables binary search
2. **Inorder = Sorted**: Powerful property for many problems
3. **Operations are O(h)**: h = log(n) for balanced, h = n for skewed
4. **Self-balancing BSTs**: Guarantee O(log n) operations
5. **Three delete cases**: Leaf, one child, two children
6. **Inorder successor/predecessor**: Essential for delete and queries

## Practice Problems Categories

| Category | Problems |
|----------|----------|
| Basic Operations | Search, Insert, Delete, Min/Max |
| Validation | Is BST valid, Check preorder |
| Traversal | Inorder successor, Kth element |
| Construction | Build from preorder, Convert BT to BST |
| Advanced | Merge BSTs, Find median, Balance BST |

Master BST and you'll have a powerful tool for ordered data operations!
