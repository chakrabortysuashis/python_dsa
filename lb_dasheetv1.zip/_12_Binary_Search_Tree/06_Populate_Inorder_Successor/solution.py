"""
Populate Inorder Successor of All Nodes
=======================================

Problem: Set each node's 'next' pointer to its inorder successor.

Key Insight: Use REVERSE inorder (Right -> Root -> Left).
The previously visited node in reverse inorder is the successor!

Time Complexity: O(n)
Space Complexity: O(h) for recursion
"""

from typing import Optional, List


class TreeNode:
    def __init__(self, val: int):
        self.val = val
        self.left: Optional['TreeNode'] = None
        self.right: Optional['TreeNode'] = None
        self.next: Optional['TreeNode'] = None  # Inorder successor pointer


class Solution:
    def populateNext_reverseInorder(self, root: Optional[TreeNode]) -> None:
        """
        Approach 1: Reverse Inorder Traversal

        Process Right -> Root -> Left
        The previously visited node is the successor of current node.

        Time: O(n), Space: O(h)
        """
        self.prev = None

        def reverse_inorder(node):
            if not node:
                return

            # Process right subtree first (larger values)
            reverse_inorder(node.right)

            # Current node's successor is the previously visited node
            node.next = self.prev
            self.prev = node

            # Process left subtree (smaller values)
            reverse_inorder(node.left)

        reverse_inorder(root)

    def populateNext_regularInorder(self, root: Optional[TreeNode]) -> None:
        """
        Approach 2: Regular Inorder Traversal

        Process Left -> Root -> Right
        Set previous node's next to current node.

        Time: O(n), Space: O(h)
        """
        self.prev = None

        def inorder(node):
            if not node:
                return

            inorder(node.left)

            # Previous node's next is current node
            if self.prev:
                self.prev.next = node
            self.prev = node

            inorder(node.right)

        inorder(root)

    def populateNext_iterative(self, root: Optional[TreeNode]) -> None:
        """
        Approach 3: Iterative with Stack

        Morris traversal variant or stack-based approach.

        Time: O(n), Space: O(h)
        """
        if not root:
            return

        stack = []
        prev = None
        current = root

        while current or stack:
            # Go to leftmost node
            while current:
                stack.append(current)
                current = current.left

            # Process current
            current = stack.pop()

            # Set previous node's successor
            if prev:
                prev.next = current
            prev = current

            # Move to right subtree
            current = current.right

    def populateNext_morris(self, root: Optional[TreeNode]) -> None:
        """
        Approach 4: Morris Traversal (O(1) space)

        Uses threaded tree concept for O(1) extra space.

        Time: O(n), Space: O(1)
        """
        prev = None
        current = root

        while current:
            if not current.left:
                # Process current
                if prev:
                    prev.next = current
                prev = current
                current = current.right
            else:
                # Find inorder predecessor
                predecessor = current.left
                while predecessor.right and predecessor.right != current:
                    predecessor = predecessor.right

                if not predecessor.right:
                    # Create thread
                    predecessor.right = current
                    current = current.left
                else:
                    # Remove thread, process current
                    predecessor.right = None
                    if prev:
                        prev.next = current
                    prev = current
                    current = current.right


# ==================== Helper Functions ====================

def build_bst(values: List[int]) -> Optional[TreeNode]:
    if not values:
        return None
    root = None
    for val in values:
        root = insert_bst(root, val)
    return root


def insert_bst(root: Optional[TreeNode], val: int) -> TreeNode:
    if not root:
        return TreeNode(val)
    if val < root.val:
        root.left = insert_bst(root.left, val)
    else:
        root.right = insert_bst(root.right, val)
    return root


def print_tree(root: Optional[TreeNode], level: int = 0, prefix: str = "Root: ") -> None:
    if root:
        next_val = root.next.val if root.next else "NULL"
        print(" " * (level * 4) + prefix + f"{root.val} -> next: {next_val}")
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")


def print_inorder_chain(root: Optional[TreeNode]) -> str:
    """Print the linked chain using next pointers"""
    # Find minimum (starting point)
    current = root
    while current and current.left:
        current = current.left

    # Follow next pointers
    result = []
    while current:
        result.append(str(current.val))
        current = current.next

    return " -> ".join(result) + " -> NULL"


def get_inorder(root: Optional[TreeNode]) -> List[int]:
    if not root:
        return []
    return get_inorder(root.left) + [root.val] + get_inorder(root.right)


# ==================== Test Cases ====================

def test_populate_next():
    solution = Solution()

    print("=" * 60)
    print("POPULATE INORDER SUCCESSOR - TEST CASES")
    print("=" * 60)

    # Test 1: Standard BST
    print("\nTest 1: Standard BST")
    print("-" * 40)
    root = build_bst([50, 30, 70, 20, 40, 60, 80])
    print(f"Inorder (sorted): {get_inorder(root)}")

    solution.populateNext_reverseInorder(root)
    print("\nAfter populating next pointers:")
    print_tree(root)
    print(f"\nInorder chain: {print_inorder_chain(root)}")

    # Test 2: Compare both approaches
    print("\nTest 2: Compare reverse vs regular inorder")
    print("-" * 40)

    # Approach 1: Reverse inorder
    root1 = build_bst([5, 3, 7, 2, 4, 6, 8])
    solution.populateNext_reverseInorder(root1)
    chain1 = print_inorder_chain(root1)

    # Approach 2: Regular inorder
    root2 = build_bst([5, 3, 7, 2, 4, 6, 8])
    solution.populateNext_regularInorder(root2)
    chain2 = print_inorder_chain(root2)

    print(f"Reverse inorder: {chain1}")
    print(f"Regular inorder: {chain2}")
    print(f"Both match: {chain1 == chain2}")

    # Test 3: Single node
    print("\nTest 3: Single node tree")
    print("-" * 40)
    root = TreeNode(42)
    solution.populateNext_reverseInorder(root)
    print(f"Node 42: next = {root.next}")

    # Test 4: Left-skewed tree
    print("\nTest 4: Left-skewed tree")
    print("-" * 40)
    root = build_bst([50, 40, 30, 20, 10])
    print(f"Original inorder: {get_inorder(root)}")
    solution.populateNext_reverseInorder(root)
    print(f"Chain: {print_inorder_chain(root)}")

    # Test 5: Right-skewed tree
    print("\nTest 5: Right-skewed tree")
    print("-" * 40)
    root = build_bst([10, 20, 30, 40, 50])
    print(f"Original inorder: {get_inorder(root)}")
    solution.populateNext_reverseInorder(root)
    print(f"Chain: {print_inorder_chain(root)}")

    # Test 6: Verify using next pointers for traversal
    print("\nTest 6: Traverse using next pointers only")
    print("-" * 40)
    root = build_bst([50, 25, 75, 10, 30, 60, 90])
    solution.populateNext_reverseInorder(root)

    # Find min and traverse
    current = root
    while current.left:
        current = current.left

    print("Traversal using next pointers:")
    vals = []
    while current:
        vals.append(current.val)
        current = current.next
    print(f"Values: {vals}")
    print(f"Is sorted: {vals == sorted(vals)}")


if __name__ == "__main__":
    test_populate_next()
