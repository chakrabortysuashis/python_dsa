# Populate Inorder Successor of All Nodes

## Problem Statement

Given a BST, populate the `next` pointer for each node to point to its inorder successor. The `next` pointer should be NULL for the last node (maximum element).

**Example:**
```
BST:                     After population:
        50                      50 -> 60
       /  \                    /  \
      30   70                30 -> 40  70 -> 80
     / \   / \              / \       / \
    20 40 60  80          20->30 40->50 60->70 80->NULL

Inorder: 20 -> 30 -> 40 -> 50 -> 60 -> 70 -> 80 -> NULL
```

## BST Property Usage

The BST property gives us sorted order through **inorder traversal** (Left -> Root -> Right).

Key insight: Process nodes in reverse inorder (Right -> Root -> Left) and keep track of the previously visited node - that's the successor!

```
Reverse Inorder: 80, 70, 60, 50, 40, 30, 20

Processing 80: prev = NULL, so 80.next = NULL, prev = 80
Processing 70: prev = 80, so 70.next = 80, prev = 70
Processing 60: prev = 70, so 60.next = 70, prev = 60
... and so on
```

## Recursion with Tree Visualization

### Reverse Inorder Approach

```
populateNext(node, prev):
    if node is NULL:
        return prev
    
    # Process right subtree first (larger values)
    prev = populateNext(node.right, prev)
    
    # Current node's successor is prev
    node.next = prev
    prev = node
    
    # Process left subtree (smaller values)
    return populateNext(node.left, prev)
```

### Visual Trace

```
        50
       /  \
      30   70
     / \
    20  40

Reverse inorder: 70 -> 50 -> 40 -> 30 -> 20

Step 1: Visit 70, prev=NULL
        70.next = NULL, prev = 70

Step 2: Visit 50, prev=70
        50.next = 70, prev = 50

Step 3: Visit 40, prev=50
        40.next = 50, prev = 40

Step 4: Visit 30, prev=40
        30.next = 40, prev = 30

Step 5: Visit 20, prev=30
        20.next = 30, prev = 20
```

## Step-by-Step Dry Run

```
BST:        50
           /  \
          30   70
         / \
        20  40

Call: populateNext(50, NULL)

    Call: populateNext(70, NULL)  [right subtree first]
        70 has no children
        70.next = NULL
        return 70

    Back at 50: prev = 70
    50.next = 70
    prev = 50

    Call: populateNext(30, 50)  [left subtree]
        
        Call: populateNext(40, 50)  [right of 30]
            40.next = 50
            return 40

        Back at 30: prev = 40
        30.next = 40
        prev = 30

        Call: populateNext(20, 30)  [left of 30]
            20.next = 30
            return 20

        return 20

    return 20

Final links:
20 -> 30 -> 40 -> 50 -> 70 -> NULL
```

## Algorithm

### Approach 1: Reverse Inorder (Optimal)
```python
def populate_next(root):
    prev = None
    
    def reverse_inorder(node):
        nonlocal prev
        if not node:
            return
        
        # Process right subtree first
        reverse_inorder(node.right)
        
        # Set current node's successor
        node.next = prev
        prev = node
        
        # Process left subtree
        reverse_inorder(node.left)
    
    reverse_inorder(root)
```

### Approach 2: Regular Inorder with Previous Tracking
```python
def populate_next_inorder(root):
    prev = None
    
    def inorder(node):
        nonlocal prev
        if not node:
            return
        
        inorder(node.left)
        
        # Previous node's next is current node
        if prev:
            prev.next = node
        prev = node
        
        inorder(node.right)
    
    inorder(root)
```

## Time and Space Complexity

### Time Complexity: O(n)
- Visit each node exactly once

### Space Complexity: O(h)
- Recursion stack depth = height of tree
- O(log n) for balanced, O(n) for skewed

## Key Insights

1. **Reverse inorder for successor**
   - Process larger values first
   - Current node's successor is the previously visited node

2. **Regular inorder for predecessor**
   - Process smaller values first
   - Previous node's next is current node

3. **Both approaches achieve same result**
   - Reverse inorder: set current.next = prev
   - Regular inorder: set prev.next = current

4. **No extra space needed for links**
   - Only tracking one previous pointer
   - Modifying nodes in-place

## Applications

1. **Thread Binary Tree** - Similar concept
2. **Flatten BST to sorted list**
3. **Iterator implementation** - Next pointer enables O(1) iteration
4. **Navigation** - Quickly find next element

## Related Problems

- Flatten BST to linked list
- Convert BST to sorted doubly linked list
- Thread Binary Tree
