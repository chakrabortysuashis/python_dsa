"""
Check if a Tree is a BST
========================

Problem: Validate if a binary tree satisfies BST property.

Key Insight: Each node must be within a valid RANGE based on all ancestors,
not just its immediate parent.

Approaches:
1. Range Validation - pass min/max bounds down
2. Inorder Traversal - check if strictly increasing

Time Complexity: O(n)
Space Complexity: O(h) for recursion
"""

from typing import Optional, List


class TreeNode:
    def __init__(self, val: int):
        self.val = val
        self.left: Optional['TreeNode'] = None
        self.right: Optional['TreeNode'] = None


class Solution:
    def isValidBST_range(self, root: Optional[TreeNode]) -> bool:
        """
        Approach 1: Range Validation

        Key insight: Each node must be within (min_val, max_val)
        - Left child inherits parent's value as new max
        - Right child inherits parent's value as new min

        Time: O(n), Space: O(h)
        """
        def validate(node: Optional[TreeNode],
                    min_val: float, max_val: float) -> bool:
            # Empty tree is valid BST
            if not node:
                return True

            # Check if current node violates BST property
            if node.val <= min_val or node.val >= max_val:
                return False

            # Recursively validate subtrees with updated ranges
            # Left subtree: all values must be less than current
            # Right subtree: all values must be greater than current
            return (validate(node.left, min_val, node.val) and
                    validate(node.right, node.val, max_val))

        return validate(root, float('-inf'), float('inf'))

    def isValidBST_inorder(self, root: Optional[TreeNode]) -> bool:
        """
        Approach 2: Inorder Traversal

        Key insight: Inorder traversal of BST gives sorted order.
        If inorder is NOT strictly increasing, it's not a valid BST.

        Time: O(n), Space: O(h)
        """
        self.prev = float('-inf')

        def inorder(node: Optional[TreeNode]) -> bool:
            if not node:
                return True

            # Check left subtree
            if not inorder(node.left):
                return False

            # Check current node against previous
            if node.val <= self.prev:
                return False
            self.prev = node.val

            # Check right subtree
            return inorder(node.right)

        return inorder(root)

    def isValidBST_iterative(self, root: Optional[TreeNode]) -> bool:
        """
        Approach 3: Iterative Inorder with Stack

        Same logic as inorder approach but using explicit stack.
        Useful when recursion depth is a concern.

        Time: O(n), Space: O(h)
        """
        stack = []
        prev = float('-inf')
        current = root

        while current or stack:
            # Go to leftmost node
            while current:
                stack.append(current)
                current = current.left

            # Process current
            current = stack.pop()

            # Check BST property
            if current.val <= prev:
                return False
            prev = current.val

            # Move to right subtree
            current = current.right

        return True

    def isValidBST_with_reason(self, root: Optional[TreeNode]) -> tuple:
        """
        Approach 4: Validate with explanation

        Returns (is_valid, reason) for debugging/understanding.
        """
        def validate(node, min_val, max_val, path):
            if not node:
                return True, "Valid (empty subtree)"

            if node.val <= min_val:
                return False, f"Node {node.val} <= {min_val} (min bound from ancestor)"

            if node.val >= max_val:
                return False, f"Node {node.val} >= {max_val} (max bound from ancestor)"

            # Check left subtree
            left_valid, left_reason = validate(
                node.left, min_val, node.val, path + f" -> L({node.left.val if node.left else 'null'})"
            )
            if not left_valid:
                return False, left_reason

            # Check right subtree
            right_valid, right_reason = validate(
                node.right, node.val, max_val, path + f" -> R({node.right.val if node.right else 'null'})"
            )
            if not right_valid:
                return False, right_reason

            return True, "Valid"

        return validate(root, float('-inf'), float('inf'), "root")

    def findViolatingNode(self, root: Optional[TreeNode]) -> Optional[int]:
        """
        Find the first node that violates BST property.
        Useful for debugging.
        """
        def find(node, min_val, max_val):
            if not node:
                return None

            if node.val <= min_val or node.val >= max_val:
                return node.val

            left_violation = find(node.left, min_val, node.val)
            if left_violation is not None:
                return left_violation

            return find(node.right, node.val, max_val)

        return find(root, float('-inf'), float('inf'))


# ==================== Helper Functions ====================

def build_tree_from_list(values: List) -> Optional[TreeNode]:
    """Build tree from level-order list (None for missing nodes)"""
    if not values or values[0] is None:
        return None

    root = TreeNode(values[0])
    queue = [root]
    i = 1

    while queue and i < len(values):
        node = queue.pop(0)

        if i < len(values) and values[i] is not None:
            node.left = TreeNode(values[i])
            queue.append(node.left)
        i += 1

        if i < len(values) and values[i] is not None:
            node.right = TreeNode(values[i])
            queue.append(node.right)
        i += 1

    return root


def print_tree(root: Optional[TreeNode], level: int = 0, prefix: str = "Root: ") -> None:
    if root:
        print(" " * (level * 4) + prefix + str(root.val))
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            else:
                print(" " * ((level + 1) * 4) + "L--- None")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")
            else:
                print(" " * ((level + 1) * 4) + "R--- None")


# ==================== Test Cases ====================

def test_is_valid_bst():
    solution = Solution()

    print("=" * 60)
    print("CHECK IF TREE IS BST - TEST CASES")
    print("=" * 60)

    # Test 1: Valid BST
    print("\nTest 1: Valid BST")
    print("-" * 40)
    root = build_tree_from_list([50, 30, 70, 20, 40, 60, 80])
    print("Tree:")
    print_tree(root)

    result = solution.isValidBST_range(root)
    print(f"\nIs Valid BST (Range method): {result}")
    print(f"Is Valid BST (Inorder method): {solution.isValidBST_inorder(root)}")

    # Test 2: Invalid BST - value violates ancestor constraint
    print("\nTest 2: Invalid BST (ancestor violation)")
    print("-" * 40)
    # Manually build: 50 -> left:30 -> right:60 (60 > 50!)
    root = TreeNode(50)
    root.left = TreeNode(30)
    root.right = TreeNode(70)
    root.left.right = TreeNode(60)  # This violates! 60 > 50

    print("Tree:")
    print_tree(root)

    is_valid, reason = solution.isValidBST_with_reason(root)
    print(f"\nIs Valid BST: {is_valid}")
    print(f"Reason: {reason}")

    violating = solution.findViolatingNode(root)
    print(f"Violating node: {violating}")

    # Test 3: Invalid BST - left > parent
    print("\nTest 3: Invalid BST (left > parent)")
    print("-" * 40)
    root = build_tree_from_list([10, 20, 5])  # Left child (20) > parent (10)
    print("Tree:")
    print_tree(root)

    is_valid, reason = solution.isValidBST_with_reason(root)
    print(f"\nIs Valid BST: {is_valid}")
    print(f"Reason: {reason}")

    # Test 4: Single node
    print("\nTest 4: Single node tree")
    print("-" * 40)
    root = TreeNode(42)
    print(f"Single node: {root.val}")
    print(f"Is Valid BST: {solution.isValidBST_range(root)}")

    # Test 5: Empty tree
    print("\nTest 5: Empty tree")
    print("-" * 40)
    print(f"Is Valid BST (None): {solution.isValidBST_range(None)}")

    # Test 6: Duplicate values
    print("\nTest 6: Tree with duplicate values")
    print("-" * 40)
    root = TreeNode(50)
    root.left = TreeNode(50)  # Duplicate!
    print("Tree with duplicate 50:")
    print_tree(root)

    is_valid, reason = solution.isValidBST_with_reason(root)
    print(f"\nIs Valid BST: {is_valid}")
    print(f"Reason: {reason}")
    print("(BST typically doesn't allow duplicates)")

    # Test 7: Compare all methods
    print("\nTest 7: Compare all three methods")
    print("-" * 40)
    root = build_tree_from_list([5, 1, 8, None, None, 6, 9])
    print("Tree:")
    print_tree(root)

    print(f"\nRange method:     {solution.isValidBST_range(root)}")
    print(f"Inorder method:   {solution.isValidBST_inorder(root)}")
    print(f"Iterative method: {solution.isValidBST_iterative(root)}")


def demonstrate_why_local_check_fails():
    """Show why checking only parent-child is insufficient"""
    print("\n" + "=" * 60)
    print("WHY LOCAL CHECK IS NOT ENOUGH")
    print("=" * 60)

    # Build a tree that passes local check but fails BST
    #      50
    #     /  \
    #   30    70
    #     \
    #      60  <- Locally: 60 > 30, looks fine!
    #          <- Globally: 60 > 50, in wrong subtree!

    root = TreeNode(50)
    root.left = TreeNode(30)
    root.right = TreeNode(70)
    root.left.right = TreeNode(60)

    print("\nTree that PASSES local parent-child check:")
    print_tree(root)
    print("\n30's right child is 60")
    print("Local check: 60 > 30? YES (looks valid)")
    print("But 60 is in LEFT subtree of 50!")
    print("Global check: 60 should be < 50, but 60 > 50")
    print("\nThis is why we need RANGE validation!")

    solution = Solution()
    is_valid, reason = solution.isValidBST_with_reason(root)
    print(f"\nActual result: {is_valid}")
    print(f"Reason: {reason}")


if __name__ == "__main__":
    test_is_valid_bst()
    demonstrate_why_local_check_fails()
