# Check if a Tree is a BST

## Problem Statement

Given a binary tree, determine if it is a valid Binary Search Tree (BST).

A valid BST is defined as:
- The left subtree of a node contains only nodes with values **less than** the node's value
- The right subtree of a node contains only nodes with values **greater than** the node's value
- Both left and right subtrees must also be BSTs

**Example 1 - Valid BST:**
```
        50
       /  \
      30   70
     / \   / \
    20 40 60  80

Valid! Every node satisfies BST property.
```

**Example 2 - Invalid BST:**
```
        50
       /  \
      30   70
     / \
    20  60  <-- 60 > 50, but in left subtree!

Invalid! 60 is in left subtree of 50 but greater than 50.
```

## BST Property Usage

The key insight is that BST property is **not just local** - it applies to the entire subtree:

```
WRONG approach (checking only parent-child):
        50
       /  \
      30   70
        \
         60   <- 60 > 30, looks valid locally
              <- But 60 > 50, violates BST with grandparent!
```

**Correct approach**: Each node must be within a valid RANGE:
- Left child of 50: must be in range (-inf, 50)
- Right child of 50: must be in range (50, +inf)
- Left child of 30: must be in range (-inf, 30)
- Right child of 30: must be in range (30, 50) <- 50 inherited from parent!

## Recursion with Tree Visualization

### Range Validation Method

```
isValidBST(node, min_val, max_val):
    if node is NULL:
        return True
    
    if node.val <= min_val OR node.val >= max_val:
        return False
    
    # Left subtree: max becomes current node's value
    # Right subtree: min becomes current node's value
    return isValidBST(node.left, min_val, node.val) AND
           isValidBST(node.right, node.val, max_val)
```

### Visual Trace

```
        50
       /  \
      30   70

isValidBST(50, -inf, +inf)
    50 is in (-inf, +inf)? YES
    |
    +-- isValidBST(30, -inf, 50)
    |       30 is in (-inf, 50)? YES
    |       Returns True
    |
    +-- isValidBST(70, 50, +inf)
            70 is in (50, +inf)? YES
            Returns True

Result: True (valid BST)
```

## Step-by-Step Dry Run

### Example: Invalid BST

```
        50
       /  \
      30   70
        \
         60

Check node 50:
- Range: (-inf, +inf)
- 50 in range? YES
- Check left subtree with range (-inf, 50)
- Check right subtree with range (50, +inf)

Check node 30:
- Range: (-inf, 50)
- 30 in range? YES
- Check right subtree with range (30, 50)  <-- NEW MAX!

Check node 60:
- Range: (30, 50)
- 60 in range (30, 50)? NO! 60 > 50
- Return FALSE

RESULT: Invalid BST
```

### Dry Run Table

| Node | Range | In Range? | Decision |
|------|-------|-----------|----------|
| 50 | (-inf, +inf) | Yes | Continue |
| 30 | (-inf, 50) | Yes | Continue |
| 60 | (30, 50) | **No** | **Return False** |

## Algorithm

### Approach 1: Range Validation (Best)
```python
def is_valid_bst(root):
    def validate(node, min_val, max_val):
        if not node:
            return True
        
        if node.val <= min_val or node.val >= max_val:
            return False
        
        return (validate(node.left, min_val, node.val) and
                validate(node.right, node.val, max_val))
    
    return validate(root, float('-inf'), float('inf'))
```

### Approach 2: Inorder Traversal
```python
def is_valid_bst_inorder(root):
    """
    Inorder traversal of BST gives sorted order.
    Check if inorder is strictly increasing.
    """
    prev = float('-inf')
    
    def inorder(node):
        nonlocal prev
        if not node:
            return True
        
        # Check left subtree
        if not inorder(node.left):
            return False
        
        # Check current node
        if node.val <= prev:
            return False
        prev = node.val
        
        # Check right subtree
        return inorder(node.right)
    
    return inorder(root)
```

## Time and Space Complexity

### Time Complexity: O(n)

Both approaches visit each node exactly once.

### Space Complexity

| Approach | Space |
|----------|-------|
| Range validation | O(h) - recursion stack |
| Inorder | O(h) - recursion stack |
| Iterative inorder | O(h) - explicit stack |

Where h = height of tree (log n for balanced, n for skewed)

## Key Insights

1. **Local check is NOT enough**
   - Must validate against entire ancestor path
   - Range propagation solves this

2. **Range narrows as we descend**
   - Left child: inherits parent as new max
   - Right child: inherits parent as new min

3. **Inorder alternative**
   - BST inorder = sorted order
   - Just verify strictly increasing

4. **Handle duplicates**
   - Typically BST doesn't allow duplicates
   - If allowed, decide: left or right?
   - Modify comparison operators accordingly

## Common Mistakes

1. **Only checking parent-child relationship**
   - Must check against all ancestors

2. **Using `<=` instead of `<`**
   - BST typically requires strict inequality
   - No duplicates allowed

3. **Not handling empty tree**
   - Empty tree is a valid BST

4. **Integer overflow**
   - Use float('-inf') and float('inf')
   - Or pass None and handle specially

## Related Problems

- Find minimum difference in BST (use inorder)
- Find two swapped nodes in BST
- Recover BST
- Convert sorted array to BST
