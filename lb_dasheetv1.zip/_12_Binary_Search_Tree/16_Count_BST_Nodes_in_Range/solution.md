# Count BST Nodes in Range

## Problem Statement
Count nodes with values in range [low, high].

## BST Property Usage
BST property helps prune unnecessary subtrees:
- If node.val > low: search left subtree
- If node.val < high: search right subtree
- If low <= node.val <= high: count this node

## Algorithm
```python
def count_in_range(root, low, high):
    if not root:
        return 0
    
    count = 0
    if low <= root.val <= high:
        count = 1
    
    if root.val > low:
        count += count_in_range(root.left, low, high)
    if root.val < high:
        count += count_in_range(root.right, low, high)
    
    return count
```

## Time & Space
- Time: O(h + k) where k = nodes in range
- Space: O(h) for recursion
