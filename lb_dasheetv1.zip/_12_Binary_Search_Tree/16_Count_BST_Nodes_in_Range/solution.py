"""
Count BST Nodes in Range [low, high]
====================================
Use BST property to prune search
"""

from typing import Optional, List


class TreeNode:
    def __init__(self, val: int):
        self.val = val
        self.left = self.right = None


class Solution:
    def countInRange(self, root: Optional[TreeNode], low: int, high: int) -> int:
        if not root:
            return 0

        count = 0

        # Count current node if in range
        if low <= root.val <= high:
            count = 1

        # Search left if there might be values in range
        if root.val > low:
            count += self.countInRange(root.left, low, high)

        # Search right if there might be values in range
        if root.val < high:
            count += self.countInRange(root.right, low, high)

        return count

    def getNodesInRange(self, root: Optional[TreeNode], low: int, high: int) -> List[int]:
        result = []

        def traverse(node):
            if not node:
                return
            if node.val > low:
                traverse(node.left)
            if low <= node.val <= high:
                result.append(node.val)
            if node.val < high:
                traverse(node.right)

        traverse(root)
        return result


def test():
    root = TreeNode(50)
    root.left, root.right = TreeNode(30), TreeNode(70)
    root.left.left, root.left.right = TreeNode(20), TreeNode(40)
    root.right.left, root.right.right = TreeNode(60), TreeNode(80)

    sol = Solution()
    print(f"Nodes in [25, 65]: {sol.getNodesInRange(root, 25, 65)}")
    print(f"Count in [25, 65]: {sol.countInRange(root, 25, 65)}")


if __name__ == "__main__":
    test()
