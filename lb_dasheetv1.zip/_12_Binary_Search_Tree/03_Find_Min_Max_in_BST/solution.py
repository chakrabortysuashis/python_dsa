"""
Find Min and Max Value in BST
=============================

Problem: Find the minimum and maximum values in a BST.

BST Property Used:
- Minimum is always at the LEFTMOST node
- Maximum is always at the RIGHTMOST node

Time Complexity: O(h) where h = height
Space Complexity: O(1) iterative, O(h) recursive
"""

from typing import Optional, List, Tuple


class TreeNode:
    def __init__(self, val: int):
        self.val = val
        self.left: Optional['TreeNode'] = None
        self.right: Optional['TreeNode'] = None


class Solution:
    def findMin_iterative(self, root: Optional[TreeNode]) -> Optional[int]:
        """
        Find minimum value iteratively.

        Key insight: Keep going left until no more left child.
        The leftmost node has the minimum value due to BST property.

        Time: O(h), Space: O(1)
        """
        if not root:
            return None

        current = root
        while current.left:
            current = current.left

        return current.val

    def findMax_iterative(self, root: Optional[TreeNode]) -> Optional[int]:
        """
        Find maximum value iteratively.

        Key insight: Keep going right until no more right child.
        The rightmost node has the maximum value due to BST property.

        Time: O(h), Space: O(1)
        """
        if not root:
            return None

        current = root
        while current.right:
            current = current.right

        return current.val

    def findMin_recursive(self, root: Optional[TreeNode]) -> Optional[int]:
        """
        Find minimum value recursively.

        Time: O(h), Space: O(h) for call stack
        """
        if not root:
            return None
        if not root.left:
            return root.val
        return self.findMin_recursive(root.left)

    def findMax_recursive(self, root: Optional[TreeNode]) -> Optional[int]:
        """
        Find maximum value recursively.

        Time: O(h), Space: O(h) for call stack
        """
        if not root:
            return None
        if not root.right:
            return root.val
        return self.findMax_recursive(root.right)

    def findMinMax(self, root: Optional[TreeNode]) -> Tuple[Optional[int], Optional[int]]:
        """
        Find both min and max in single function.

        Returns (min_val, max_val) tuple.
        """
        if not root:
            return (None, None)

        # Find min (leftmost)
        min_node = root
        while min_node.left:
            min_node = min_node.left

        # Find max (rightmost)
        max_node = root
        while max_node.right:
            max_node = max_node.right

        return (min_node.val, max_node.val)

    def findMinMax_with_path(self, root: Optional[TreeNode]) -> dict:
        """
        Find min and max with paths taken.
        Useful for understanding/visualization.
        """
        result = {
            'min': {'value': None, 'path': []},
            'max': {'value': None, 'path': []}
        }

        if not root:
            return result

        # Find min with path
        current = root
        while current:
            result['min']['path'].append(current.val)
            if not current.left:
                result['min']['value'] = current.val
                break
            current = current.left

        # Find max with path
        current = root
        while current:
            result['max']['path'].append(current.val)
            if not current.right:
                result['max']['value'] = current.val
                break
            current = current.right

        return result

    def findMinInSubtree(self, node: Optional[TreeNode]) -> Optional[TreeNode]:
        """
        Find minimum node in a subtree.
        Returns the node itself (not just value).
        Used in delete operation to find inorder successor.
        """
        if not node:
            return None
        while node.left:
            node = node.left
        return node

    def findSecondMin(self, root: Optional[TreeNode]) -> Optional[int]:
        """
        Find second minimum value.

        The second minimum is either:
        1. Parent of minimum (if min is leftmost leaf)
        2. Right child of minimum (if min has right subtree)
        """
        if not root:
            return None

        # Find min and its parent
        parent = None
        current = root

        while current.left:
            parent = current
            current = current.left

        # Case 1: Min has a right subtree
        # Second min is the minimum of that subtree
        if current.right:
            return self.findMin_iterative(current.right)

        # Case 2: Min is a leaf, second min is its parent
        return parent.val if parent else None

    def findSecondMax(self, root: Optional[TreeNode]) -> Optional[int]:
        """
        Find second maximum value.

        The second maximum is either:
        1. Parent of maximum (if max is rightmost leaf)
        2. Left child of maximum (if max has left subtree)
        """
        if not root:
            return None

        parent = None
        current = root

        while current.right:
            parent = current
            current = current.right

        if current.left:
            return self.findMax_iterative(current.left)

        return parent.val if parent else None


# ==================== Helper Functions ====================

def build_bst(values: List[int]) -> Optional[TreeNode]:
    """Build BST from list of values"""
    if not values:
        return None
    root = None
    for val in values:
        root = insert_bst(root, val)
    return root


def insert_bst(root: Optional[TreeNode], val: int) -> TreeNode:
    """Insert value into BST"""
    if not root:
        return TreeNode(val)
    if val < root.val:
        root.left = insert_bst(root.left, val)
    else:
        root.right = insert_bst(root.right, val)
    return root


def print_tree(root: Optional[TreeNode], level: int = 0, prefix: str = "Root: ") -> None:
    """Print tree structure"""
    if root:
        print(" " * (level * 4) + prefix + str(root.val))
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")


# ==================== Test Cases ====================

def test_find_min_max():
    solution = Solution()

    print("=" * 60)
    print("FIND MIN AND MAX IN BST - TEST CASES")
    print("=" * 60)

    # Test 1: Standard BST
    print("\nTest 1: Standard BST")
    print("-" * 40)
    root = build_bst([50, 30, 70, 20, 40, 60, 80, 10])
    print("BST:")
    print_tree(root)

    min_val = solution.findMin_iterative(root)
    max_val = solution.findMax_iterative(root)
    print(f"\nMinimum: {min_val}")
    print(f"Maximum: {max_val}")

    # With paths
    result = solution.findMinMax_with_path(root)
    print(f"Path to min: {result['min']['path']}")
    print(f"Path to max: {result['max']['path']}")

    # Test 2: Single node
    print("\nTest 2: Single node tree")
    print("-" * 40)
    single = TreeNode(42)
    min_val, max_val = solution.findMinMax(single)
    print(f"Single node: 42")
    print(f"Min: {min_val}, Max: {max_val}")

    # Test 3: Left-skewed tree
    print("\nTest 3: Left-skewed tree")
    print("-" * 40)
    root = build_bst([50, 40, 30, 20, 10])
    print("BST:")
    print_tree(root)
    result = solution.findMinMax_with_path(root)
    print(f"Min: {result['min']['value']}, Path: {result['min']['path']}")
    print(f"Max: {result['max']['value']}, Path: {result['max']['path']}")

    # Test 4: Right-skewed tree
    print("\nTest 4: Right-skewed tree")
    print("-" * 40)
    root = build_bst([10, 20, 30, 40, 50])
    print("BST:")
    print_tree(root)
    result = solution.findMinMax_with_path(root)
    print(f"Min: {result['min']['value']}, Path: {result['min']['path']}")
    print(f"Max: {result['max']['value']}, Path: {result['max']['path']}")

    # Test 5: Second min/max
    print("\nTest 5: Second minimum and maximum")
    print("-" * 40)
    root = build_bst([50, 30, 70, 20, 40, 60, 80, 10, 25])
    print("BST:")
    print_tree(root)

    second_min = solution.findSecondMin(root)
    second_max = solution.findSecondMax(root)
    print(f"\nMin: {solution.findMin_iterative(root)}, Second Min: {second_min}")
    print(f"Max: {solution.findMax_iterative(root)}, Second Max: {second_max}")

    # Test 6: Empty tree
    print("\nTest 6: Empty tree")
    print("-" * 40)
    min_val, max_val = solution.findMinMax(None)
    print(f"Min: {min_val}, Max: {max_val}")


if __name__ == "__main__":
    test_find_min_max()
