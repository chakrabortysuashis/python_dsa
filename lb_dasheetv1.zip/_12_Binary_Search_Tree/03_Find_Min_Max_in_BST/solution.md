# Find Min and Max Value in a BST

## Problem Statement

Given a Binary Search Tree, find the minimum and maximum values in the tree.

**Example:**
```
BST:
        50
       /  \
      30   70
     / \   / \
    20 40 60  80
   /
  10

Minimum: 10 (leftmost node)
Maximum: 80 (rightmost node)
```

## BST Property Usage

The BST property gives us a direct path to min and max:

- **Minimum**: Always at the **leftmost** node
  - All left children are smaller than their parent
  - Keep going left until no more left child
  
- **Maximum**: Always at the **rightmost** node
  - All right children are larger than their parent
  - Keep going right until no more right child

```
Find Min:           Find Max:
    50                  50
   /                      \
  30                      70
 /                          \
20                          80  <-- Maximum
/
10  <-- Minimum
```

## Recursion with Tree Visualization

### Find Minimum
```
findMin(node):
    if node.left is NULL:
        return node  // This is the minimum!
    return findMin(node.left)  // Keep going left
```

### Find Maximum
```
findMax(node):
    if node.right is NULL:
        return node  // This is the maximum!
    return findMax(node.right)  // Keep going right
```

### Visual Trace - Find Min

```
        50
       /  \
      30   70
     /
    20
   /
  10

Step 1: At 50, has left child (30) -> go left
Step 2: At 30, has left child (20) -> go left
Step 3: At 20, has left child (10) -> go left
Step 4: At 10, no left child -> FOUND MIN = 10
```

## Step-by-Step Dry Run

### Finding Minimum

```
BST:        50
           /  \
          30   70
         / \   / \
        20 40 60  80
       /
      10

Start at root (50)
|
v
current = 50
current.left = 30? YES -> move left
|
v
current = 30
current.left = 20? YES -> move left
|
v
current = 20
current.left = 10? YES -> move left
|
v
current = 10
current.left = NULL? YES -> STOP

Minimum = 10
```

### Dry Run Table

| Step | Current | Has Left? | Action | Next |
|------|---------|-----------|--------|------|
| 1 | 50 | Yes (30) | Go left | 30 |
| 2 | 30 | Yes (20) | Go left | 20 |
| 3 | 20 | Yes (10) | Go left | 10 |
| 4 | 10 | No | **Return 10** | - |

## Algorithm

### Iterative Approach (Preferred)
```python
def find_min(root):
    if not root:
        return None
    current = root
    while current.left:
        current = current.left
    return current.val

def find_max(root):
    if not root:
        return None
    current = root
    while current.right:
        current = current.right
    return current.val
```

### Recursive Approach
```python
def find_min_recursive(node):
    if not node:
        return None
    if not node.left:
        return node.val
    return find_min_recursive(node.left)

def find_max_recursive(node):
    if not node:
        return None
    if not node.right:
        return node.val
    return find_max_recursive(node.right)
```

## Time and Space Complexity

### Time Complexity: O(h)

| Tree Type | Height | Time |
|-----------|--------|------|
| Balanced | log(n) | O(log n) |
| Skewed (left) | n | O(n) for min |
| Skewed (right) | n | O(n) for max |

### Space Complexity

| Approach | Space |
|----------|-------|
| Iterative | O(1) |
| Recursive | O(h) |

## Key Insights

1. **BST property guarantees position**
   - Min is always leftmost
   - Max is always rightmost

2. **No need to check all nodes**
   - Only traverse one path from root
   - O(h) instead of O(n)

3. **Works for any subtree**
   - Can find min/max in any subtree
   - Useful for deletion (finding successor)

4. **Handle empty tree**
   - Always check if root is NULL first

## Applications

1. **Delete operation** - Finding inorder successor needs min in right subtree
2. **Range validation** - Checking if values are within expected range
3. **Statistics** - Finding range (max - min) of values
4. **Validation** - Verifying BST property

## Related Problems

- Find inorder successor (uses findMin)
- Delete node in BST (uses findMin/findMax)
- Find second minimum/maximum
- Find floor/ceiling of a value
