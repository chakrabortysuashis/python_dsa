# Count Pairs from 2 BSTs with Sum X

## Problem Statement
Given two BSTs and a target sum X, count pairs (a, b) where a is from BST1, b is from BST2, and a + b = X.

## BST Property Usage
Use two-pointer technique on inorder traversals:
- Forward iterator on BST1 (increasing)
- Backward iterator on BST2 (decreasing)

## Algorithm
```python
def count_pairs(root1, root2, x):
    stack1, stack2 = [], []
    # Initialize: leftmost from BST1, rightmost from BST2
    push_left(root1, stack1)
    push_right(root2, stack2)
    
    count = 0
    while stack1 and stack2:
        top1, top2 = stack1[-1], stack2[-1]
        curr_sum = top1.val + top2.val
        
        if curr_sum == x:
            count += 1
            # Move both pointers
        elif curr_sum < x:
            # Need larger sum, advance BST1
        else:
            # Need smaller sum, advance BST2
```

## Time & Space
- Time: O(m + n)
- Space: O(h1 + h2) for stacks
