"""
Count Pairs from 2 BSTs with Sum X
==================================
Two-pointer technique using BST iterators
"""

from typing import Optional


class TreeNode:
    def __init__(self, val: int):
        self.val = val
        self.left = self.right = None


class Solution:
    def countPairs(self, root1: Optional[TreeNode], root2: Optional[TreeNode], x: int) -> int:
        # Forward iterator for BST1
        stack1 = []
        self._push_left(root1, stack1)

        # Backward iterator for BST2
        stack2 = []
        self._push_right(root2, stack2)

        count = 0

        while stack1 and stack2:
            top1, top2 = stack1[-1], stack2[-1]
            curr_sum = top1.val + top2.val

            if curr_sum == x:
                count += 1
                # Move both
                node1 = stack1.pop()
                self._push_left(node1.right, stack1)
                node2 = stack2.pop()
                self._push_right(node2.left, stack2)
            elif curr_sum < x:
                # Need larger, advance BST1
                node = stack1.pop()
                self._push_left(node.right, stack1)
            else:
                # Need smaller, advance BST2
                node = stack2.pop()
                self._push_right(node.left, stack2)

        return count

    def _push_left(self, node, stack):
        while node:
            stack.append(node)
            node = node.left

    def _push_right(self, node, stack):
        while node:
            stack.append(node)
            node = node.right


def test():
    # BST1: [1, 3, 5]
    root1 = TreeNode(3)
    root1.left, root1.right = TreeNode(1), TreeNode(5)

    # BST2: [2, 4, 6]
    root2 = TreeNode(4)
    root2.left, root2.right = TreeNode(2), TreeNode(6)

    sol = Solution()
    print(f"Pairs with sum 7: {sol.countPairs(root1, root2, 7)}")  # (1,6), (3,4), (5,2)


if __name__ == "__main__":
    test()
