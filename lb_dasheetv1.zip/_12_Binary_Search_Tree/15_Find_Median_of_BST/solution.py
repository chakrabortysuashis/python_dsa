"""
Find Median of BST - O(n) time O(1) space
=========================================
Use Morris Traversal for O(1) space inorder
"""

from typing import Optional


class TreeNode:
    def __init__(self, val: int):
        self.val = val
        self.left = self.right = None


class Solution:
    def findMedian(self, root: Optional[TreeNode]) -> float:
        # Count nodes
        n = self._count_morris(root)

        if n == 0:
            return 0

        if n % 2 == 1:
            return self._kth_morris(root, n // 2 + 1)
        else:
            a = self._kth_morris(root, n // 2)
            b = self._kth_morris(root, n // 2 + 1)
            return (a + b) / 2

    def _count_morris(self, root):
        count = 0
        current = root
        while current:
            if not current.left:
                count += 1
                current = current.right
            else:
                pred = current.left
                while pred.right and pred.right != current:
                    pred = pred.right
                if not pred.right:
                    pred.right = current
                    current = current.left
                else:
                    pred.right = None
                    count += 1
                    current = current.right
        return count

    def _kth_morris(self, root, k):
        count = 0
        current = root
        while current:
            if not current.left:
                count += 1
                if count == k:
                    return current.val
                current = current.right
            else:
                pred = current.left
                while pred.right and pred.right != current:
                    pred = pred.right
                if not pred.right:
                    pred.right = current
                    current = current.left
                else:
                    pred.right = None
                    count += 1
                    if count == k:
                        return current.val
                    current = current.right
        return None


def test():
    root = TreeNode(50)
    root.left, root.right = TreeNode(30), TreeNode(70)
    root.left.left, root.left.right = TreeNode(20), TreeNode(40)
    root.right.left, root.right.right = TreeNode(60), TreeNode(80)

    sol = Solution()
    print(f"Median: {sol.findMedian(root)}")  # 7 elements, median is 50


if __name__ == "__main__":
    test()
