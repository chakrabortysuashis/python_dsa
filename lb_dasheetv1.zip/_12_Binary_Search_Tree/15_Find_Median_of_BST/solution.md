# Find Median of BST in O(n) time O(1) space

## Problem Statement
Find the median of BST without using extra space (O(1) space).

## BST Property Usage
Inorder gives sorted order. Use **Morris Traversal** for O(1) space inorder.

## Algorithm
1. Count nodes using Morris traversal
2. Find middle element(s) using Morris traversal again

```python
def find_median(root):
    n = count_nodes_morris(root)
    
    if n % 2 == 1:
        # Odd: return middle element
        return kth_element_morris(root, n // 2 + 1)
    else:
        # Even: return average of two middle elements
        a = kth_element_morris(root, n // 2)
        b = kth_element_morris(root, n // 2 + 1)
        return (a + b) / 2
```

## Time & Space
- Time: O(n) for Morris traversal
- Space: O(1) - no extra space!
