# Inorder Successor and Predecessor in BST

## Problem Statement

Given a BST and a target node value, find:
- **Inorder Successor**: The smallest value greater than the target
- **Inorder Predecessor**: The largest value smaller than the target

**Example:**
```
BST:
        50
       /  \
      30   70
     / \   / \
    20 40 60  80

For node 30:
- Inorder Successor: 40 (next in sorted order)
- Inorder Predecessor: 20 (previous in sorted order)

Inorder traversal: [20, 30, 40, 50, 60, 70, 80]
                       ^   ^
                  pred=20  succ=40
```

## BST Property Usage

The BST property helps us find successor/predecessor efficiently without full traversal:

**For Successor (smallest value > target):**
- If target < current: current could be successor, search LEFT for smaller candidate
- If target >= current: successor must be in RIGHT subtree

**For Predecessor (largest value < target):**
- If target > current: current could be predecessor, search RIGHT for larger candidate
- If target <= current: predecessor must be in LEFT subtree

## Recursion with Tree Visualization

### Finding Inorder Successor

```
findSuccessor(node, target, successor):
    if node is NULL:
        return successor
    
    if target < node.val:
        # Current node could be successor
        # Look for smaller successor in left subtree
        return findSuccessor(node.left, target, node)
    else:
        # Successor must be larger, go right
        return findSuccessor(node.right, target, successor)
```

### Visual Trace - Find Successor of 30

```
        50
       /  \
      30   70
     / \   / \
    20 40 60  80

Step 1: At 50, target(30) < 50
        50 could be successor, go LEFT
        successor_candidate = 50

Step 2: At 30, target(30) >= 30
        Current can't be successor, go RIGHT
        successor_candidate = 50 (unchanged)

Step 3: At 40, target(30) < 40
        40 could be successor, go LEFT
        successor_candidate = 40

Step 4: At NULL (40 has no left child)
        Return successor_candidate = 40

RESULT: Successor of 30 is 40
```

## Step-by-Step Dry Run

### Finding Predecessor of 50

```
BST:        50
           /  \
          30   70
         / \
        20  40

Target = 50

Step 1: At 50, target(50) <= 50
        Can't be predecessor, go LEFT
        predecessor = None

Step 2: At 30, target(50) > 30
        30 could be predecessor!
        Go RIGHT for larger candidate
        predecessor = 30

Step 3: At 40, target(50) > 40
        40 is larger than 30, update!
        Go RIGHT for larger candidate
        predecessor = 40

Step 4: NULL (40 has no right child)
        Return predecessor = 40
```

### Dry Run Table (Successor of 25)

```
BST: [50, 30, 70, 20, 40]
Target = 25
```

| Step | Node | Compare | Action | Successor Candidate |
|------|------|---------|--------|---------------------|
| 1 | 50 | 25 < 50 | Go left, update succ | 50 |
| 2 | 30 | 25 < 30 | Go left, update succ | 30 |
| 3 | 20 | 25 > 20 | Go right | 30 |
| 4 | NULL | - | Return | **30** |

## Algorithm

### Iterative Approach (Recommended)

```python
def inorder_successor(root, target):
    successor = None
    current = root
    
    while current:
        if target < current.val:
            # Current could be successor
            successor = current
            current = current.left
        else:
            # Need larger value
            current = current.right
    
    return successor

def inorder_predecessor(root, target):
    predecessor = None
    current = root
    
    while current:
        if target > current.val:
            # Current could be predecessor
            predecessor = current
            current = current.right
        else:
            # Need smaller value
            current = current.left
    
    return predecessor
```

### When Node Reference is Given

If we have a reference to the node (not just value):

```python
def successor_with_node(node):
    # Case 1: Node has right subtree
    # Successor is leftmost node in right subtree
    if node.right:
        current = node.right
        while current.left:
            current = current.left
        return current
    
    # Case 2: No right subtree
    # Successor is nearest ancestor where node is in left subtree
    # (Need parent pointers or search from root)
```

## Time and Space Complexity

### Time Complexity: O(h)

We traverse at most one path from root to leaf.

| Tree Type | Height | Time |
|-----------|--------|------|
| Balanced | log(n) | O(log n) |
| Skewed | n | O(n) |

### Space Complexity

| Approach | Space |
|----------|-------|
| Iterative | O(1) |
| Recursive | O(h) |

## Key Insights

1. **BST ordering enables O(h) search**
   - No need for full inorder traversal O(n)
   - Binary search approach

2. **Successor/Predecessor update rules:**
   - Successor: Update when going LEFT (found smaller candidate)
   - Predecessor: Update when going RIGHT (found larger candidate)

3. **Alternative method with node reference:**
   - If right subtree exists: successor = min of right subtree
   - Otherwise: nearest ancestor where node is in left subtree

4. **Edge cases:**
   - Target not in tree (still works!)
   - Target is min/max (returns None for predecessor/successor)
   - Single node tree

## Applications

1. **Range queries** - Finding next/previous elements
2. **Delete operation** - Finding replacement node
3. **Floor/Ceiling** - Finding nearest values
4. **Navigation** - Next/Previous in sorted order

## Related Problems

- Delete node in BST (uses successor)
- Floor and Ceiling in BST
- Closest value in BST
- K closest values in BST
