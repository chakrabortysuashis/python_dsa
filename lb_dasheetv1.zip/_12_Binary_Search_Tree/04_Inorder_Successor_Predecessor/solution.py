"""
Inorder Successor and Predecessor in BST
========================================

Inorder Successor: Smallest value GREATER than target
Inorder Predecessor: Largest value SMALLER than target

BST Property Usage:
- Successor: Go left when target < node (update candidate), right otherwise
- Predecessor: Go right when target > node (update candidate), left otherwise

Time Complexity: O(h)
Space Complexity: O(1) iterative, O(h) recursive
"""

from typing import Optional, List, Tuple


class TreeNode:
    def __init__(self, val: int):
        self.val = val
        self.left: Optional['TreeNode'] = None
        self.right: Optional['TreeNode'] = None
        self.parent: Optional['TreeNode'] = None  # Optional parent pointer


class Solution:
    def inorderSuccessor(self, root: Optional[TreeNode], target: int) -> Optional[int]:
        """
        Find inorder successor (smallest value > target).

        Algorithm:
        1. If target < current: current could be successor, go left for smaller
        2. If target >= current: successor is in right subtree

        Time: O(h), Space: O(1)
        """
        successor = None
        current = root

        while current:
            if target < current.val:
                # Current value is greater than target
                # It could be the successor, but there might be smaller valid values
                successor = current.val
                current = current.left  # Look for smaller successor
            else:
                # Current value <= target, need to find larger value
                current = current.right

        return successor

    def inorderPredecessor(self, root: Optional[TreeNode], target: int) -> Optional[int]:
        """
        Find inorder predecessor (largest value < target).

        Algorithm:
        1. If target > current: current could be predecessor, go right for larger
        2. If target <= current: predecessor is in left subtree

        Time: O(h), Space: O(1)
        """
        predecessor = None
        current = root

        while current:
            if target > current.val:
                # Current value is smaller than target
                # It could be the predecessor, but there might be larger valid values
                predecessor = current.val
                current = current.right  # Look for larger predecessor
            else:
                # Current value >= target, need to find smaller value
                current = current.left

        return predecessor

    def findSuccessorPredecessor(self, root: Optional[TreeNode], target: int) -> Tuple[Optional[int], Optional[int]]:
        """
        Find both successor and predecessor in single traversal.

        Returns (predecessor, successor) tuple.
        """
        predecessor = None
        successor = None
        current = root

        while current:
            if target < current.val:
                successor = current.val
                current = current.left
            elif target > current.val:
                predecessor = current.val
                current = current.right
            else:
                # Found exact match
                # Predecessor is max of left subtree
                if current.left:
                    temp = current.left
                    while temp.right:
                        temp = temp.right
                    predecessor = temp.val

                # Successor is min of right subtree
                if current.right:
                    temp = current.right
                    while temp.left:
                        temp = temp.left
                    successor = temp.val
                break

        return (predecessor, successor)

    def inorderSuccessor_recursive(self, root: Optional[TreeNode], target: int) -> Optional[int]:
        """
        Recursive version of inorder successor.

        Time: O(h), Space: O(h)
        """
        def helper(node, target, successor):
            if not node:
                return successor

            if target < node.val:
                return helper(node.left, target, node.val)
            else:
                return helper(node.right, target, successor)

        return helper(root, target, None)

    def successorWithNodeReference(self, node: TreeNode, root: TreeNode) -> Optional[TreeNode]:
        """
        Find successor when we have node reference.

        Two cases:
        1. Node has right subtree: successor is min of right subtree
        2. No right subtree: go up until we find ancestor from left

        Time: O(h), Space: O(1)
        """
        # Case 1: Has right subtree
        if node.right:
            current = node.right
            while current.left:
                current = current.left
            return current

        # Case 2: No right subtree
        # If parent pointers available
        if hasattr(node, 'parent') and node.parent:
            current = node
            parent = node.parent
            while parent and parent.right == current:
                current = parent
                parent = parent.parent
            return parent

        # Without parent pointers: search from root
        successor = None
        current = root
        while current:
            if node.val < current.val:
                successor = current
                current = current.left
            elif node.val > current.val:
                current = current.right
            else:
                break
        return successor

    def floorAndCeil(self, root: Optional[TreeNode], target: int) -> Tuple[Optional[int], Optional[int]]:
        """
        Find floor (largest <= target) and ceil (smallest >= target).

        Similar to predecessor/successor but includes equal values.
        """
        floor_val = None
        ceil_val = None
        current = root

        while current:
            if current.val == target:
                return (target, target)
            elif target < current.val:
                ceil_val = current.val
                current = current.left
            else:
                floor_val = current.val
                current = current.right

        return (floor_val, ceil_val)


# ==================== Helper Functions ====================

def build_bst(values: List[int]) -> Optional[TreeNode]:
    if not values:
        return None
    root = None
    for val in values:
        root = insert_bst(root, val)
    return root


def insert_bst(root: Optional[TreeNode], val: int) -> TreeNode:
    if not root:
        return TreeNode(val)
    if val < root.val:
        root.left = insert_bst(root.left, val)
    else:
        root.right = insert_bst(root.right, val)
    return root


def inorder(root: Optional[TreeNode]) -> List[int]:
    if not root:
        return []
    return inorder(root.left) + [root.val] + inorder(root.right)


def print_tree(root: Optional[TreeNode], level: int = 0, prefix: str = "Root: ") -> None:
    if root:
        print(" " * (level * 4) + prefix + str(root.val))
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")


# ==================== Test Cases ====================

def test_successor_predecessor():
    solution = Solution()

    print("=" * 60)
    print("INORDER SUCCESSOR AND PREDECESSOR - TEST CASES")
    print("=" * 60)

    # Test 1: Standard BST
    print("\nTest 1: Standard BST")
    print("-" * 40)
    root = build_bst([50, 30, 70, 20, 40, 60, 80])
    print("BST:")
    print_tree(root)
    print(f"\nInorder (sorted): {inorder(root)}")

    # Test various targets
    targets = [30, 50, 20, 80, 45, 25]
    print("\nSuccessor/Predecessor results:")
    for target in targets:
        succ = solution.inorderSuccessor(root, target)
        pred = solution.inorderPredecessor(root, target)
        print(f"  Target {target}: Predecessor={pred}, Successor={succ}")

    # Test 2: Find both at once
    print("\nTest 2: Find both for existing node")
    print("-" * 40)
    pred, succ = solution.findSuccessorPredecessor(root, 50)
    print(f"For node 50: Predecessor={pred}, Successor={succ}")

    pred, succ = solution.findSuccessorPredecessor(root, 30)
    print(f"For node 30: Predecessor={pred}, Successor={succ}")

    # Test 3: Edge cases - min and max
    print("\nTest 3: Edge cases (min and max)")
    print("-" * 40)
    min_val = 20
    max_val = 80
    print(f"Predecessor of min ({min_val}): {solution.inorderPredecessor(root, min_val)}")
    print(f"Successor of max ({max_val}): {solution.inorderSuccessor(root, max_val)}")

    # Test 4: Value not in tree
    print("\nTest 4: Value not in tree")
    print("-" * 40)
    for target in [25, 45, 65, 15, 90]:
        succ = solution.inorderSuccessor(root, target)
        pred = solution.inorderPredecessor(root, target)
        print(f"  Target {target}: Predecessor={pred}, Successor={succ}")

    # Test 5: Floor and Ceiling
    print("\nTest 5: Floor and Ceiling")
    print("-" * 40)
    for target in [30, 25, 45, 50, 55]:
        floor_val, ceil_val = solution.floorAndCeil(root, target)
        print(f"  Target {target}: Floor={floor_val}, Ceiling={ceil_val}")

    # Test 6: Single path traversal efficiency
    print("\nTest 6: Demonstrate O(h) efficiency")
    print("-" * 40)
    large_bst = build_bst([50, 25, 75, 12, 37, 62, 87, 6, 18, 31, 43, 56, 68, 81, 93])
    sorted_vals = inorder(large_bst)
    print(f"BST with 15 nodes: {sorted_vals}")

    target = 40
    succ = solution.inorderSuccessor(large_bst, target)
    pred = solution.inorderPredecessor(large_bst, target)
    print(f"\nFor target {target}: Predecessor={pred}, Successor={succ}")
    print("Found in O(log n) = O(4) steps, not O(n) = O(15)!")


if __name__ == "__main__":
    test_successor_predecessor()
