# Find LCA of 2 Nodes in a BST

## Problem Statement

Given a BST and two node values p and q, find their Lowest Common Ancestor (LCA).

The LCA is defined as the lowest node in the tree that has both p and q as descendants (a node can be a descendant of itself).

**Example:**
```
BST:
        50
       /  \
      30   70
     / \   / \
    20 40 60  80

LCA(20, 40) = 30  (30 is parent of both)
LCA(20, 70) = 50  (50 is the split point)
LCA(30, 40) = 30  (30 is ancestor of 40, and is itself)
```

## BST Property Usage

The BST property makes LCA search trivial! The key insight is:

**LCA is the SPLIT POINT** - where p and q diverge to different subtrees.

```
For any node:
- If both p and q < node.val: LCA is in LEFT subtree
- If both p and q > node.val: LCA is in RIGHT subtree
- Otherwise: current node IS the LCA (split point)

Example: LCA(20, 70) in BST rooted at 50
- At 50: 20 < 50, but 70 > 50
- Split! One goes left, one goes right
- Therefore, 50 is the LCA
```

## Recursion with Tree Visualization

### Algorithm

```
findLCA(node, p, q):
    if both p and q < node.val:
        return findLCA(node.left, p, q)
    
    if both p and q > node.val:
        return findLCA(node.right, p, q)
    
    # Split point - this is the LCA!
    return node
```

### Visual Trace - LCA(20, 40)

```
        50
       /  \
      30   70
     / \
    20  40

Step 1: At 50
        20 < 50? YES
        40 < 50? YES
        Both less -> go LEFT

Step 2: At 30
        20 < 30? YES
        40 < 30? NO (40 > 30)
        Split! 20 goes left, 40 goes right
        LCA = 30
```

## Step-by-Step Dry Run

### Example: LCA(60, 80)

```
BST:        50
           /  \
          30   70
              / \
             60  80

p = 60, q = 80

Step 1: At node 50
        p=60 > 50? YES
        q=80 > 50? YES
        Both greater -> go RIGHT

Step 2: At node 70
        p=60 < 70? YES
        q=80 > 70? YES
        Split! 60 goes left, 80 goes right
        LCA = 70
```

### Dry Run Table

| Step | Node | p < node? | q < node? | Decision |
|------|------|-----------|-----------|----------|
| 1 | 50 | No (60>50) | No (80>50) | Go right |
| 2 | 70 | Yes (60<70) | No (80>70) | **Split! LCA=70** |

## Algorithm

### Iterative Approach (Optimal)
```python
def lca_bst(root, p, q):
    current = root
    
    while current:
        if p < current.val and q < current.val:
            current = current.left
        elif p > current.val and q > current.val:
            current = current.right
        else:
            return current
    
    return None
```

### Recursive Approach
```python
def lca_bst_recursive(root, p, q):
    if not root:
        return None
    
    if p < root.val and q < root.val:
        return lca_bst_recursive(root.left, p, q)
    
    if p > root.val and q > root.val:
        return lca_bst_recursive(root.right, p, q)
    
    return root
```

## Time and Space Complexity

### Time Complexity: O(h)

We only traverse one path from root to LCA.

| Tree Type | Height | Time |
|-----------|--------|------|
| Balanced | log(n) | O(log n) |
| Skewed | n | O(n) |

### Space Complexity

| Approach | Space |
|----------|-------|
| Iterative | O(1) |
| Recursive | O(h) |

## Key Insights

1. **BST makes LCA easy**
   - No need to search both subtrees
   - Just find the split point

2. **Split point IS the LCA**
   - Where p and q diverge
   - Or where one equals current node

3. **Works even if p or q IS the LCA**
   - If p == node, one "goes" to current, other might go somewhere else
   - Current node is still the LCA

4. **No need to verify p and q exist**
   - If they don't exist, we still find where they would diverge
   - Add existence check if needed

## Comparison with Generic Binary Tree LCA

| BST LCA | Generic BT LCA |
|---------|----------------|
| O(h) time | O(n) time |
| Single path traversal | Must search both subtrees |
| Use BST property | Use recursion from both children |

## Common Mistakes

1. **Not handling p == q case** - LCA of same node is itself
2. **Not handling p or q == root** - Root can be LCA
3. **Incorrect comparison** - Need `<` and `>`, not `<=` and `>=`

## Applications

1. **Finding path between two nodes**
2. **Distance between two nodes** = dist(root, p) + dist(root, q) - 2*dist(root, LCA)
3. **Common ancestor queries**

## Related Problems

- LCA in Binary Tree (harder, O(n))
- Distance between two nodes in BST
- Path between two nodes
