"""
Find LCA of 2 Nodes in BST
==========================

Problem: Find the Lowest Common Ancestor of two nodes in a BST.

Key Insight: LCA is the SPLIT POINT where p and q diverge to different subtrees.
- If both p, q < node: LCA is in left subtree
- If both p, q > node: LCA is in right subtree
- Otherwise: current node is LCA

Time Complexity: O(h)
Space Complexity: O(1) iterative, O(h) recursive
"""

from typing import Optional, List


class TreeNode:
    def __init__(self, val: int):
        self.val = val
        self.left: Optional['TreeNode'] = None
        self.right: Optional['TreeNode'] = None


class Solution:
    def lowestCommonAncestor_iterative(self, root: Optional[TreeNode],
                                        p: int, q: int) -> Optional[TreeNode]:
        """
        Approach 1: Iterative (Optimal)

        BST property: LCA is where p and q split to different subtrees.

        Time: O(h), Space: O(1)
        """
        current = root

        while current:
            # Both values are smaller - LCA is in left subtree
            if p < current.val and q < current.val:
                current = current.left
            # Both values are larger - LCA is in right subtree
            elif p > current.val and q > current.val:
                current = current.right
            # Split point - this is the LCA!
            else:
                return current

        return None

    def lowestCommonAncestor_recursive(self, root: Optional[TreeNode],
                                        p: int, q: int) -> Optional[TreeNode]:
        """
        Approach 2: Recursive

        Same logic as iterative, but using recursion.

        Time: O(h), Space: O(h)
        """
        if not root:
            return None

        # Both in left subtree
        if p < root.val and q < root.val:
            return self.lowestCommonAncestor_recursive(root.left, p, q)

        # Both in right subtree
        if p > root.val and q > root.val:
            return self.lowestCommonAncestor_recursive(root.right, p, q)

        # Split point - current node is LCA
        return root

    def lowestCommonAncestor_withPath(self, root: Optional[TreeNode],
                                       p: int, q: int) -> tuple:
        """
        Approach 3: Return LCA with path for visualization

        Returns (LCA node, path taken)
        """
        path = []
        current = root

        while current:
            path.append(current.val)

            if p < current.val and q < current.val:
                current = current.left
            elif p > current.val and q > current.val:
                current = current.right
            else:
                return current, path

        return None, path

    def distanceFromRoot(self, root: Optional[TreeNode], val: int) -> int:
        """Helper: Find distance from root to a node"""
        dist = 0
        current = root

        while current and current.val != val:
            dist += 1
            if val < current.val:
                current = current.left
            else:
                current = current.right

        return dist if current else -1

    def distanceBetweenNodes(self, root: Optional[TreeNode], p: int, q: int) -> int:
        """
        Find distance between two nodes using LCA.

        Distance = dist(root, p) + dist(root, q) - 2 * dist(root, LCA)
        """
        lca = self.lowestCommonAncestor_iterative(root, p, q)
        if not lca:
            return -1

        dist_p = self.distanceFromRoot(lca, p)
        dist_q = self.distanceFromRoot(lca, q)

        if dist_p == -1 or dist_q == -1:
            return -1

        return dist_p + dist_q

    def findPath(self, root: Optional[TreeNode], val: int) -> List[int]:
        """Find path from root to a node"""
        path = []
        current = root

        while current:
            path.append(current.val)
            if current.val == val:
                break
            elif val < current.val:
                current = current.left
            else:
                current = current.right

        return path if current and current.val == val else []


# ==================== Helper Functions ====================

def build_bst(values: List[int]) -> Optional[TreeNode]:
    if not values:
        return None
    root = None
    for val in values:
        root = insert_bst(root, val)
    return root


def insert_bst(root: Optional[TreeNode], val: int) -> TreeNode:
    if not root:
        return TreeNode(val)
    if val < root.val:
        root.left = insert_bst(root.left, val)
    else:
        root.right = insert_bst(root.right, val)
    return root


def print_tree(root: Optional[TreeNode], level: int = 0, prefix: str = "Root: ") -> None:
    if root:
        print(" " * (level * 4) + prefix + str(root.val))
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")


# ==================== Test Cases ====================

def test_lca():
    solution = Solution()

    print("=" * 60)
    print("LOWEST COMMON ANCESTOR IN BST - TEST CASES")
    print("=" * 60)

    # Build test tree
    root = build_bst([50, 30, 70, 20, 40, 60, 80])
    print("\nBST:")
    print_tree(root)

    # Test cases
    test_pairs = [
        (20, 40, "Siblings"),
        (20, 70, "Different subtrees"),
        (30, 40, "Parent-child"),
        (60, 80, "Siblings in right subtree"),
        (20, 80, "Far apart"),
        (50, 70, "Root is LCA"),
        (30, 30, "Same node"),
    ]

    print("\nLCA Test Results:")
    print("-" * 50)

    for p, q, description in test_pairs:
        lca, path = solution.lowestCommonAncestor_withPath(root, p, q)
        print(f"LCA({p}, {q}): {lca.val if lca else None}")
        print(f"  Description: {description}")
        print(f"  Path taken: {' -> '.join(map(str, path))}")
        print()

    # Test distance calculation
    print("\nDistance Between Nodes:")
    print("-" * 40)
    for p, q, _ in test_pairs[:4]:
        dist = solution.distanceBetweenNodes(root, p, q)
        print(f"Distance({p}, {q}) = {dist}")

    # Test path finding
    print("\nPaths from Root:")
    print("-" * 40)
    for val in [20, 40, 60, 80]:
        path = solution.findPath(root, val)
        print(f"Path to {val}: {' -> '.join(map(str, path))}")


def demonstrate_split_point():
    """Visual demonstration of LCA as split point"""
    solution = Solution()

    print("\n" + "=" * 60)
    print("LCA AS SPLIT POINT DEMONSTRATION")
    print("=" * 60)

    root = build_bst([50, 30, 70, 20, 40, 60, 80, 10, 25, 35, 45])
    print("\nBST:")
    print_tree(root)

    # Show how LCA is the split point
    print("\nFinding LCA(10, 45):")
    print("-" * 40)

    lca, path = solution.lowestCommonAncestor_withPath(root, 10, 45)
    print(f"Path to split point: {' -> '.join(map(str, path))}")
    print(f"\nAt each node:")
    for i, node_val in enumerate(path):
        if i == len(path) - 1:
            print(f"  {node_val}: SPLIT! 10 and 45 diverge here")
        else:
            direction = "LEFT" if 10 < node_val and 45 < node_val else "RIGHT"
            print(f"  {node_val}: Both 10 and 45 < {node_val}? -> {direction}")

    print(f"\nLCA(10, 45) = {lca.val}")

    # Show paths
    path_to_10 = solution.findPath(root, 10)
    path_to_45 = solution.findPath(root, 45)
    print(f"\nPath to 10: {' -> '.join(map(str, path_to_10))}")
    print(f"Path to 45: {' -> '.join(map(str, path_to_45))}")


if __name__ == "__main__":
    test_lca()
    demonstrate_split_point()
