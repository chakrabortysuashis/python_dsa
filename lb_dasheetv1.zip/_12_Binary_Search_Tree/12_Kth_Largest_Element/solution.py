"""
Kth Largest Element in BST
==========================
Use reverse inorder: Right -> Root -> Left (descending order)
"""

from typing import Optional


class TreeNode:
    def __init__(self, val: int):
        self.val = val
        self.left: Optional['TreeNode'] = None
        self.right: Optional['TreeNode'] = None


class Solution:
    def kthLargest(self, root: Optional[TreeNode], k: int) -> Optional[int]:
        self.count = 0
        self.result = None

        def reverse_inorder(node):
            if not node or self.result is not None:
                return
            reverse_inorder(node.right)
            self.count += 1
            if self.count == k:
                self.result = node.val
                return
            reverse_inorder(node.left)

        reverse_inorder(root)
        return self.result


def build_bst(vals):
    if not vals: return None
    root = TreeNode(vals[0])
    for v in vals[1:]:
        curr = root
        while True:
            if v < curr.val:
                if curr.left: curr = curr.left
                else: curr.left = TreeNode(v); break
            else:
                if curr.right: curr = curr.right
                else: curr.right = TreeNode(v); break
    return root


def test():
    root = build_bst([50, 30, 70, 20, 40, 60, 80])
    sol = Solution()
    for k in range(1, 8):
        print(f"Kth largest (k={k}): {sol.kthLargest(root, k)}")


if __name__ == "__main__":
    test()
