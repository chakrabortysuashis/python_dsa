# Find Kth Largest Element in BST

## Problem Statement
Find the kth largest element in a BST.

## BST Property Usage
**Reverse inorder (Right -> Root -> Left) gives descending order!**

Count k elements in reverse inorder to find kth largest.

## Algorithm
```python
def kth_largest(root, k):
    count = 0
    result = None
    
    def reverse_inorder(node):
        if not node or count >= k:
            return
        reverse_inorder(node.right)  # Right first
        count += 1
        if count == k:
            result = node.val
            return
        reverse_inorder(node.left)
```

## Time & Space
- Time: O(h + k) 
- Space: O(h) for recursion
