# Find a Value in a BST

## Problem Statement

Given the root of a Binary Search Tree (BST) and a target value, determine if the target exists in the BST. If found, return the node; otherwise, return null.

**Example:**
```
BST:
        50
       /  \
      30   70
     / \   / \
    20 40 60  80

Target: 40 -> Found at node 40
Target: 25 -> Not found (return null)
```

## BST Property Usage

The **BST property** is the key to efficient searching:
- All values in the left subtree are **less than** the current node
- All values in the right subtree are **greater than** the current node

This property allows us to **eliminate half the tree** at each step, similar to binary search on a sorted array!

```
Search for 40:
Step 1: 40 < 50 -> Go LEFT (eliminate right subtree with 70,60,80)
Step 2: 40 > 30 -> Go RIGHT (eliminate left subtree with 20)
Step 3: 40 == 40 -> FOUND!

We only visited 3 nodes instead of checking all 7!
```

## Recursion with Tree Visualization

### Recursive Approach

```
search(node, target):
    BASE CASE: 
        if node is NULL -> return NULL (not found)
        if node.val == target -> return node (found!)
    
    RECURSIVE CASE:
        if target < node.val -> search LEFT subtree
        if target > node.val -> search RIGHT subtree
```

### Visual Recursion Tree (Search for 40)

```
                    search(50, 40)
                         |
                    50 > 40, go left
                         |
                         v
                    search(30, 40)
                         |
                    30 < 40, go right
                         |
                         v
                    search(40, 40)
                         |
                    40 == 40, FOUND!
                         |
                         v
                    return node(40)
```

## Step-by-Step Dry Run

**Example: Search for 25 in BST**

```
BST:        50
           /  \
          30   70
         / \
        20  40

Target = 25

Step 1: current = 50
        25 < 50? YES -> Go LEFT
        
                [50]
               /    \
             30      70
            / \
           20  40

Step 2: current = 30
        25 < 30? YES -> Go LEFT
        
                 50
               /    \
             [30]    70
             / \
            20  40

Step 3: current = 20
        25 < 20? NO
        25 > 20? YES -> Go RIGHT
        
                 50
               /    \
              30     70
             / \
           [20] 40

Step 4: current = 20.right = NULL
        NULL reached -> NOT FOUND

Result: 25 is not in the BST
```

**Dry Run Table:**

| Step | Current Node | Compare | Decision | Next Node |
|------|--------------|---------|----------|-----------|
| 1    | 50           | 25 < 50 | Go LEFT  | 30        |
| 2    | 30           | 25 < 30 | Go LEFT  | 20        |
| 3    | 20           | 25 > 20 | Go RIGHT | NULL      |
| 4    | NULL         | -       | NOT FOUND| -         |

## Algorithm

### Recursive Solution
```python
def search_bst(root, target):
    # Base case: not found or found
    if root is None:
        return None
    if root.val == target:
        return root
    
    # BST property: go left or right
    if target < root.val:
        return search_bst(root.left, target)
    else:
        return search_bst(root.right, target)
```

### Iterative Solution (More Space Efficient)
```python
def search_bst_iterative(root, target):
    current = root
    while current:
        if current.val == target:
            return current
        elif target < current.val:
            current = current.left
        else:
            current = current.right
    return None
```

## Time and Space Complexity

### Time Complexity

| Case | Complexity | Tree Shape |
|------|------------|------------|
| Best | O(1) | Target is at root |
| Average | O(log n) | Balanced BST |
| Worst | O(n) | Skewed BST (like linked list) |

**Why O(log n) for balanced BST?**
- At each step, we eliminate half the remaining nodes
- Total comparisons = height of tree
- Balanced tree height = log(n)

**Why O(n) for skewed BST?**
```
Skewed BST:
    10
     \
      20
       \
        30
         \
          40

Search for 40: Must visit ALL 4 nodes
Height = n (not log n)
```

### Space Complexity

| Approach | Space | Reason |
|----------|-------|--------|
| Recursive | O(h) | Call stack depth = height |
| Iterative | O(1) | Only using pointers |

Where h = height of tree:
- Balanced: h = O(log n)
- Skewed: h = O(n)

## Key Insights

1. **BST Search = Binary Search on Tree**
   - Sorted array uses binary search
   - BST uses BST property for same effect

2. **Each comparison eliminates half the tree**
   - If target < current: eliminate right subtree
   - If target > current: eliminate left subtree

3. **Iterative is preferred** for O(1) space when recursion isn't necessary

4. **Path followed = ancestors of target node** (if found)

## Common Mistakes to Avoid

1. **Not handling NULL node** - Always check for empty subtree
2. **Using == for comparison only** - Need < and > for BST navigation
3. **Forgetting iterative solution** - Often simpler and more efficient

## Related Problems

- Find minimum in BST (go left until NULL)
- Find maximum in BST (go right until NULL)
- Search in sorted array (same concept, different structure)
- Validate BST (search with range constraints)
