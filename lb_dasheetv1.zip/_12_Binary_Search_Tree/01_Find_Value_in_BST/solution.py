"""
Find a Value in a BST
=====================

Problem: Given a BST and a target value, find if target exists in the BST.

BST Property Used:
- All values in left subtree < current node
- All values in right subtree > current node
- This allows us to eliminate half the tree at each step!

Time Complexity: O(h) where h = height of tree
                 O(log n) for balanced BST, O(n) for skewed BST
Space Complexity: O(h) recursive, O(1) iterative
"""

from typing import Optional, List


class TreeNode:
    """Node class for Binary Search Tree"""
    def __init__(self, val: int):
        self.val = val
        self.left: Optional['TreeNode'] = None
        self.right: Optional['TreeNode'] = None


class Solution:
    """
    Multiple approaches to search in BST
    """

    def searchBST_recursive(self, root: Optional[TreeNode], val: int) -> Optional[TreeNode]:
        """
        Approach 1: Recursive Search

        Algorithm:
        1. If root is NULL, return NULL (not found)
        2. If root.val == val, return root (found!)
        3. If val < root.val, search in left subtree
        4. If val > root.val, search in right subtree

        Time: O(h), Space: O(h) for call stack
        """
        # Base case: not found
        if root is None:
            return None

        # Base case: found
        if root.val == val:
            return root

        # BST property: decide which subtree to search
        if val < root.val:
            # Target is smaller, must be in left subtree
            return self.searchBST_recursive(root.left, val)
        else:
            # Target is larger, must be in right subtree
            return self.searchBST_recursive(root.right, val)

    def searchBST_iterative(self, root: Optional[TreeNode], val: int) -> Optional[TreeNode]:
        """
        Approach 2: Iterative Search (Space Optimized)

        Algorithm:
        1. Start at root
        2. While current is not NULL:
           - If found, return current
           - If val < current, go left
           - If val > current, go right
        3. Return NULL if loop exits (not found)

        Time: O(h), Space: O(1)
        """
        current = root

        while current:
            if current.val == val:
                return current  # Found!
            elif val < current.val:
                current = current.left  # Search left subtree
            else:
                current = current.right  # Search right subtree

        return None  # Not found

    def searchBST_with_path(self, root: Optional[TreeNode], val: int) -> tuple:
        """
        Approach 3: Search with Path Tracking

        Returns both the node (if found) and the path taken.
        Useful for understanding how BST search works.

        Time: O(h), Space: O(h) for path
        """
        path = []
        current = root

        while current:
            path.append(current.val)

            if current.val == val:
                return current, path, "Found"
            elif val < current.val:
                current = current.left
            else:
                current = current.right

        return None, path, "Not Found"

    def searchBST_with_comparisons(self, root: Optional[TreeNode], val: int) -> tuple:
        """
        Approach 4: Search with Comparison Count

        Counts the number of comparisons made.
        Demonstrates efficiency of BST search.

        Time: O(h), Space: O(1)
        """
        current = root
        comparisons = 0

        while current:
            comparisons += 1

            if current.val == val:
                return current, comparisons
            elif val < current.val:
                current = current.left
            else:
                current = current.right

        return None, comparisons


# ==================== Helper Functions ====================

def build_bst(values: List[int]) -> Optional[TreeNode]:
    """Build a BST from a list of values"""
    if not values:
        return None

    root = None
    for val in values:
        root = insert_bst(root, val)
    return root


def insert_bst(root: Optional[TreeNode], val: int) -> TreeNode:
    """Insert a value into BST"""
    if root is None:
        return TreeNode(val)

    if val < root.val:
        root.left = insert_bst(root.left, val)
    else:
        root.right = insert_bst(root.right, val)

    return root


def print_tree(root: Optional[TreeNode], level: int = 0, prefix: str = "Root: ") -> None:
    """Print tree structure"""
    if root is not None:
        print(" " * (level * 4) + prefix + str(root.val))
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            else:
                print(" " * ((level + 1) * 4) + "L--- None")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")
            else:
                print(" " * ((level + 1) * 4) + "R--- None")


# ==================== Test Cases ====================

def test_search_bst():
    """Comprehensive test cases"""
    solution = Solution()

    print("=" * 60)
    print("FIND VALUE IN BST - TEST CASES")
    print("=" * 60)

    # Test Case 1: Standard BST
    print("\nTest 1: Standard BST")
    print("-" * 40)
    values = [50, 30, 70, 20, 40, 60, 80]
    root = build_bst(values)
    print("BST structure:")
    print_tree(root)

    # Search for existing value
    target = 40
    result = solution.searchBST_recursive(root, target)
    print(f"\nSearch for {target}: {'Found' if result else 'Not found'}")

    # With path tracking
    node, path, status = solution.searchBST_with_path(root, target)
    print(f"Path taken: {path}")
    print(f"Status: {status}")

    # Test Case 2: Search for non-existing value
    print("\nTest 2: Search for non-existing value")
    print("-" * 40)
    target = 25
    node, path, status = solution.searchBST_with_path(root, target)
    print(f"Search for {target}")
    print(f"Path taken: {path}")
    print(f"Status: {status}")

    # Test Case 3: Search at root
    print("\nTest 3: Search for root value")
    print("-" * 40)
    target = 50
    node, comparisons = solution.searchBST_with_comparisons(root, target)
    print(f"Search for {target}: {'Found' if node else 'Not found'}")
    print(f"Comparisons made: {comparisons}")

    # Test Case 4: Search for leaf
    print("\nTest 4: Search for leaf value")
    print("-" * 40)
    target = 80
    node, comparisons = solution.searchBST_with_comparisons(root, target)
    print(f"Search for {target}: {'Found' if node else 'Not found'}")
    print(f"Comparisons made: {comparisons}")

    # Test Case 5: Empty tree
    print("\nTest 5: Empty tree")
    print("-" * 40)
    result = solution.searchBST_recursive(None, 10)
    print(f"Search in empty tree: {'Found' if result else 'Not found'}")

    # Test Case 6: Single node tree
    print("\nTest 6: Single node tree")
    print("-" * 40)
    single_root = TreeNode(42)
    result = solution.searchBST_recursive(single_root, 42)
    print(f"Search for 42 in single-node tree: {'Found' if result else 'Not found'}")
    result = solution.searchBST_recursive(single_root, 10)
    print(f"Search for 10 in single-node tree: {'Found' if result else 'Not found'}")

    # Test Case 7: Skewed tree (worst case)
    print("\nTest 7: Skewed tree (worst case)")
    print("-" * 40)
    skewed_values = [10, 20, 30, 40, 50]
    skewed_root = build_bst(skewed_values)
    print("Skewed BST:")
    print_tree(skewed_root)

    target = 50
    node, comparisons = solution.searchBST_with_comparisons(skewed_root, target)
    print(f"\nSearch for {target}: {comparisons} comparisons (worst case = n = {len(skewed_values)})")

    # Test Case 8: Comparison of iterative vs recursive
    print("\nTest 8: Iterative vs Recursive")
    print("-" * 40)
    values = [50, 30, 70, 20, 40, 60, 80, 10, 35]
    root = build_bst(values)
    target = 35

    result_recursive = solution.searchBST_recursive(root, target)
    result_iterative = solution.searchBST_iterative(root, target)

    print(f"Search for {target}")
    print(f"Recursive result: {'Found' if result_recursive else 'Not found'}")
    print(f"Iterative result: {'Found' if result_iterative else 'Not found'}")
    print("Both give same result, iterative uses O(1) space!")


def demonstrate_bst_search_efficiency():
    """
    Demonstrate how BST search eliminates half the tree at each step
    """
    print("\n" + "=" * 60)
    print("BST SEARCH EFFICIENCY DEMONSTRATION")
    print("=" * 60)

    solution = Solution()

    # Build a balanced BST with 15 nodes
    # This gives us a tree of height 3
    values = [50, 25, 75, 12, 37, 62, 87, 6, 18, 31, 43, 56, 68, 81, 93]
    root = build_bst(values)

    print(f"\nBST with {len(values)} nodes (height = 3)")
    print("In a balanced BST, any search takes at most 4 comparisons!")

    # Search for various values
    test_values = [50, 6, 93, 31, 100]

    for target in test_values:
        node, comparisons = solution.searchBST_with_comparisons(root, target)
        status = "Found" if node else "Not Found"
        print(f"\nSearch({target}): {status}, Comparisons: {comparisons}")

        # Show path
        _, path, _ = solution.searchBST_with_path(root, target)
        print(f"  Path: {' -> '.join(map(str, path))}")

    print(f"\nWith {len(values)} nodes, worst case is log2({len(values)}) + 1 = {len(values).bit_length()} comparisons")
    print("If we checked every node, we'd need up to 15 comparisons!")


if __name__ == "__main__":
    test_search_bst()
    demonstrate_bst_search_efficiency()
