"""
Convert Binary Tree to BST
==========================

Keep structure, change values to satisfy BST property.

Algorithm:
1. Extract all values
2. Sort them
3. Fill back using inorder traversal

Time: O(n log n) for sorting
Space: O(n) for storing values
"""

from typing import Optional, List


class TreeNode:
    def __init__(self, val: int):
        self.val = val
        self.left: Optional['TreeNode'] = None
        self.right: Optional['TreeNode'] = None


class Solution:
    def convertBTtoBST(self, root: Optional[TreeNode]) -> Optional[TreeNode]:
        if not root:
            return None

        # Step 1: Extract all values
        values = []
        self._extract_values(root, values)

        # Step 2: Sort
        values.sort()

        # Step 3: Fill inorder
        self.index = 0
        self._fill_inorder(root, values)

        return root

    def _extract_values(self, node: Optional[TreeNode], values: List[int]) -> None:
        if node:
            values.append(node.val)
            self._extract_values(node.left, values)
            self._extract_values(node.right, values)

    def _fill_inorder(self, node: Optional[TreeNode], values: List[int]) -> None:
        if node:
            self._fill_inorder(node.left, values)
            node.val = values[self.index]
            self.index += 1
            self._fill_inorder(node.right, values)


def inorder(root):
    if not root:
        return []
    return inorder(root.left) + [root.val] + inorder(root.right)


def test():
    # Create Binary Tree
    root = TreeNode(10)
    root.left = TreeNode(2)
    root.right = TreeNode(7)
    root.left.left = TreeNode(8)
    root.left.right = TreeNode(4)

    print("Before:", inorder(root))

    sol = Solution()
    sol.convertBTtoBST(root)

    print("After:", inorder(root))
    print("Is sorted:", inorder(root) == sorted(inorder(root)))


if __name__ == "__main__":
    test()
