# Convert Binary Tree to BST

## Problem Statement

Given a Binary Tree, convert it to a Binary Search Tree while keeping the original tree structure intact.

**Example:**
```
Binary Tree:          BST (same structure):
       10                    8
      /  \                  / \
     2    7        -->     4   10
    / \                   / \
   8   4                 2   7
   
Values: [10, 2, 7, 8, 4]
Sorted: [2, 4, 7, 8, 10]
Fill inorder positions with sorted values
```

## BST Property Usage

Key insight: **Inorder traversal of BST gives sorted order**

So to convert BT to BST:
1. Extract all values from BT (any traversal)
2. Sort the values
3. Fill back using inorder traversal

This maintains structure because inorder positions remain same!

## Algorithm

```python
def convert_bt_to_bst(root):
    # Step 1: Extract all values
    values = []
    extract_values(root, values)  # Any traversal
    
    # Step 2: Sort values
    values.sort()
    
    # Step 3: Fill back in inorder
    index = [0]
    fill_inorder(root, values, index)
```

## Step-by-Step Dry Run

```
Binary Tree:
       10
      /  \
     2    7
    / \
   8   4

Step 1: Extract values = [10, 2, 8, 4, 7]
Step 2: Sort = [2, 4, 7, 8, 10]
Step 3: Inorder traversal fills:
        Position 1 (leftmost): 8 -> 2
        Position 2: 2 -> 4
        Position 3: 10 -> 7
        Position 4: 4 -> 8
        Position 5: 7 -> 10

Result:
        7
       / \
      4   10
     / \
    2   8
```

## Time and Space Complexity

- **Time**: O(n log n) for sorting
- **Space**: O(n) for storing values
