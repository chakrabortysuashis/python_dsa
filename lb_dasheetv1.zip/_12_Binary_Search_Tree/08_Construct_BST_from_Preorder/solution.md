# Construct BST from Preorder Traversal

## Problem Statement

Given a preorder traversal of a BST, construct the original BST.

**Example:**
```
Preorder: [50, 30, 20, 40, 70, 60, 80]

Constructed BST:
        50
       /  \
      30   70
     / \   / \
    20 40 60  80

Preorder = Root -> Left -> Right
So first element is always the root!
```

## BST Property Usage

Key insights from BST property:
1. **First element is root** (preorder visits root first)
2. **Elements < root go to left subtree**
3. **Elements > root go to right subtree**

```
Preorder: [50, 30, 20, 40, 70, 60, 80]

Step 1: First element 50 is ROOT
Step 2: Find where left subtree ends
        Elements < 50: [30, 20, 40] -> LEFT subtree
        Elements > 50: [70, 60, 80] -> RIGHT subtree

Recursively build:
- Left preorder: [30, 20, 40] -> root 30, left [20], right [40]
- Right preorder: [70, 60, 80] -> root 70, left [60], right [80]
```

## Recursion with Tree Visualization

### Approach 1: Range-Based (Optimal O(n))

```
buildBST(preorder, index, min, max):
    if index >= length or not in range:
        return NULL
    
    val = preorder[index]
    if val < min or val > max:
        return NULL
    
    node = new Node(val)
    index++
    
    node.left = buildBST(preorder, index, min, val)
    node.right = buildBST(preorder, index, val, max)
    
    return node
```

### Visual Trace

```
Preorder: [50, 30, 20, 40, 70, 60, 80]
Index: 0, Range: (-inf, +inf)

build(50, -inf, +inf)
    Create node 50
    |
    +-- build(30, -inf, 50)  [left, range updated]
    |       Create node 30
    |       |
    |       +-- build(20, -inf, 30)
    |       |       Create node 20
    |       |       Left: NULL (40 not in range)
    |       |       Right: NULL
    |       |
    |       +-- build(40, 30, 50)
    |               Create node 40
    |
    +-- build(70, 50, +inf)  [right, range updated]
            Create node 70
            |
            +-- build(60, 50, 70)
            |       Create node 60
            |
            +-- build(80, 70, +inf)
                    Create node 80
```

## Step-by-Step Dry Run

### Preorder: [8, 5, 1, 7, 10, 12]

```
Step 1: idx=0, val=8, range=(-inf, +inf)
        Create node(8)
        Call left with range(-inf, 8)
        
Step 2: idx=1, val=5, range=(-inf, 8)
        5 in range? YES
        Create node(5)
        Call left with range(-inf, 5)

Step 3: idx=2, val=1, range=(-inf, 5)
        1 in range? YES
        Create node(1)
        Left/Right: NULL (no valid values)

Step 4: idx=3, val=7, range=(5, 8)
        7 in range (5,8)? YES
        Create node(7)

Step 5: idx=4, val=10, range=(8, +inf)
        10 in range? YES
        Create node(10)

Step 6: idx=5, val=12, range=(10, +inf)
        12 in range? YES
        Create node(12)

Result:
        8
       / \
      5   10
     / \    \
    1   7    12
```

## Algorithm

### Approach 1: Range-Based (O(n))
```python
def bst_from_preorder(preorder):
    index = [0]  # Use list to maintain state across calls
    
    def build(min_val, max_val):
        if index[0] >= len(preorder):
            return None
        
        val = preorder[index[0]]
        if val < min_val or val > max_val:
            return None
        
        node = TreeNode(val)
        index[0] += 1
        
        node.left = build(min_val, val)
        node.right = build(val, max_val)
        
        return node
    
    return build(float('-inf'), float('inf'))
```

### Approach 2: Simple Insert (O(n^2))
```python
def bst_from_preorder_simple(preorder):
    if not preorder:
        return None
    
    root = TreeNode(preorder[0])
    for val in preorder[1:]:
        insert(root, val)
    
    return root
```

## Time and Space Complexity

### Approach 1 (Range-Based)
- **Time**: O(n) - each element processed once
- **Space**: O(h) - recursion stack

### Approach 2 (Simple Insert)
- **Time**: O(n^2) worst case - inserting n elements, each O(n)
- **Space**: O(h) - recursion stack

## Key Insights

1. **Preorder first = Root**
   - Root -> Left -> Right traversal order

2. **BST property divides elements**
   - Values < root -> left subtree
   - Values > root -> right subtree

3. **Range bounds track validity**
   - Left child: max becomes parent value
   - Right child: min becomes parent value

4. **Same approach works for postorder**
   - Process from end, build right first

## Related Problems

- Construct BST from postorder
- Serialize/Deserialize BST
- Verify preorder sequence of BST
