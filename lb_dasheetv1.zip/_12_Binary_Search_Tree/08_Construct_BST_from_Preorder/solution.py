"""
Construct BST from Preorder Traversal
=====================================

Problem: Build BST from its preorder traversal.

Key Insight:
- First element is root
- BST property: left < root < right
- Use range bounds to determine validity

Time Complexity: O(n) with range method, O(n^2) with simple insert
Space Complexity: O(h) for recursion
"""

from typing import Optional, List


class TreeNode:
    def __init__(self, val: int):
        self.val = val
        self.left: Optional['TreeNode'] = None
        self.right: Optional['TreeNode'] = None


class Solution:
    def bstFromPreorder_optimal(self, preorder: List[int]) -> Optional[TreeNode]:
        """
        Approach 1: Range-Based Construction (Optimal)

        Use min/max bounds to determine which elements belong to current subtree.
        Each element is processed exactly once.

        Time: O(n), Space: O(h)
        """
        self.index = 0

        def build(min_val: float, max_val: float) -> Optional[TreeNode]:
            # No more elements or current element out of range
            if self.index >= len(preorder):
                return None

            val = preorder[self.index]

            # Current value doesn't belong to this subtree
            if val < min_val or val > max_val:
                return None

            # Create node and move to next element
            node = TreeNode(val)
            self.index += 1

            # Build subtrees with updated ranges
            node.left = build(min_val, val)   # Left: max becomes current
            node.right = build(val, max_val)  # Right: min becomes current

            return node

        return build(float('-inf'), float('inf'))

    def bstFromPreorder_stack(self, preorder: List[int]) -> Optional[TreeNode]:
        """
        Approach 2: Iterative with Stack

        Use monotonic stack to track potential parents.

        Time: O(n), Space: O(n)
        """
        if not preorder:
            return None

        root = TreeNode(preorder[0])
        stack = [root]

        for i in range(1, len(preorder)):
            node = TreeNode(preorder[i])

            if preorder[i] < stack[-1].val:
                # Smaller value goes to left
                stack[-1].left = node
            else:
                # Find the parent for this node
                parent = None
                while stack and preorder[i] > stack[-1].val:
                    parent = stack.pop()
                parent.right = node

            stack.append(node)

        return root

    def bstFromPreorder_simple(self, preorder: List[int]) -> Optional[TreeNode]:
        """
        Approach 3: Simple Insertion

        Insert each element one by one into BST.
        Simple but less efficient.

        Time: O(n^2) worst case, Space: O(h)
        """
        if not preorder:
            return None

        root = TreeNode(preorder[0])

        def insert(node, val):
            if val < node.val:
                if node.left:
                    insert(node.left, val)
                else:
                    node.left = TreeNode(val)
            else:
                if node.right:
                    insert(node.right, val)
                else:
                    node.right = TreeNode(val)

        for val in preorder[1:]:
            insert(root, val)

        return root

    def bstFromPreorder_withSteps(self, preorder: List[int]) -> tuple:
        """
        Approach 4: With step tracking for visualization
        """
        steps = []
        self.index = 0

        def build(min_val, max_val, depth=0):
            if self.index >= len(preorder):
                return None

            val = preorder[self.index]

            if val < min_val or val > max_val:
                steps.append(f"{'  '*depth}{val} not in range ({min_val}, {max_val}) - skip")
                return None

            steps.append(f"{'  '*depth}Create node({val}) in range ({min_val}, {max_val})")
            node = TreeNode(val)
            self.index += 1

            node.left = build(min_val, val, depth + 1)
            node.right = build(val, max_val, depth + 1)

            return node

        root = build(float('-inf'), float('inf'))
        return root, steps


# ==================== Helper Functions ====================

def preorder_traversal(root: Optional[TreeNode]) -> List[int]:
    if not root:
        return []
    return [root.val] + preorder_traversal(root.left) + preorder_traversal(root.right)


def inorder_traversal(root: Optional[TreeNode]) -> List[int]:
    if not root:
        return []
    return inorder_traversal(root.left) + [root.val] + inorder_traversal(root.right)


def print_tree(root: Optional[TreeNode], level: int = 0, prefix: str = "Root: ") -> None:
    if root:
        print(" " * (level * 4) + prefix + str(root.val))
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            else:
                print(" " * ((level + 1) * 4) + "L--- None")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")
            else:
                print(" " * ((level + 1) * 4) + "R--- None")


# ==================== Test Cases ====================

def test_construct_bst():
    solution = Solution()

    print("=" * 60)
    print("CONSTRUCT BST FROM PREORDER - TEST CASES")
    print("=" * 60)

    # Test 1: Standard case
    print("\nTest 1: Standard preorder")
    print("-" * 40)
    preorder = [50, 30, 20, 40, 70, 60, 80]
    print(f"Preorder: {preorder}")

    root = solution.bstFromPreorder_optimal(preorder)
    print("\nConstructed BST:")
    print_tree(root)

    # Verify
    print(f"\nVerify preorder: {preorder_traversal(root)}")
    print(f"Inorder (sorted): {inorder_traversal(root)}")

    # Test 2: With step tracking
    print("\nTest 2: With step-by-step construction")
    print("-" * 40)
    preorder = [8, 5, 1, 7, 10, 12]
    print(f"Preorder: {preorder}")

    root, steps = solution.bstFromPreorder_withSteps(preorder)
    print("\nConstruction steps:")
    for step in steps:
        print(f"  {step}")

    print("\nResult:")
    print_tree(root)

    # Test 3: Compare all approaches
    print("\nTest 3: Compare all approaches")
    print("-" * 40)
    preorder = [10, 5, 2, 7, 15, 12, 20]

    root1 = solution.bstFromPreorder_optimal(preorder)
    root2 = solution.bstFromPreorder_stack(preorder)
    root3 = solution.bstFromPreorder_simple(preorder)

    pre1 = preorder_traversal(root1)
    pre2 = preorder_traversal(root2)
    pre3 = preorder_traversal(root3)

    print(f"Original:  {preorder}")
    print(f"Optimal:   {pre1}")
    print(f"Stack:     {pre2}")
    print(f"Simple:    {pre3}")
    print(f"All match: {pre1 == pre2 == pre3 == preorder}")

    # Test 4: Single node
    print("\nTest 4: Single node")
    print("-" * 40)
    preorder = [42]
    root = solution.bstFromPreorder_optimal(preorder)
    print(f"Preorder: {preorder}")
    print(f"Tree: {root.val}")

    # Test 5: Skewed tree
    print("\nTest 5: Right-skewed (ascending order)")
    print("-" * 40)
    preorder = [1, 2, 3, 4, 5]
    root = solution.bstFromPreorder_optimal(preorder)
    print(f"Preorder: {preorder}")
    print("Tree:")
    print_tree(root)

    # Test 6: Left-skewed (descending in preorder)
    print("\nTest 6: Left-skewed")
    print("-" * 40)
    preorder = [5, 4, 3, 2, 1]
    root = solution.bstFromPreorder_optimal(preorder)
    print(f"Preorder: {preorder}")
    print("Tree:")
    print_tree(root)


if __name__ == "__main__":
    test_construct_bst()
