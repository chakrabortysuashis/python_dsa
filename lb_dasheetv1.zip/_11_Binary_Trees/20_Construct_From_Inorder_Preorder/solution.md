# Construct Binary Tree from Inorder and Preorder Traversals

## Problem Statement

Given two integer arrays `preorder` and `inorder` representing the preorder and inorder traversals of a binary tree, construct and return the binary tree.

## Example

```
Input:
preorder = [3, 9, 20, 15, 7]
inorder  = [9, 3, 15, 20, 7]

Output:
    3
   / \
  9  20
    /  \
   15   7

Explanation:
- Preorder: Root first, then left, then right
- Inorder: Left first, then root, then right
```

---

## Visualization

```
preorder = [3, 9, 20, 15, 7]
            ^
            Root is always first!

inorder = [9, 3, 15, 20, 7]
              ^
           Find 3 -> splits into:
           Left: [9]  |  Right: [15, 20, 7]

Building process:
1. Root = 3 (first in preorder)
2. In inorder, 3 is at index 1
   - Left subtree: inorder[0:1] = [9]
   - Right subtree: inorder[2:5] = [15, 20, 7]
3. Recursively build left and right
```

---

## Intuition: Divide and Conquer

**Key Insights:**
1. **Preorder first element = Root** of current subtree
2. **Inorder position of root** divides array into left and right subtrees
3. **Count of left elements** in inorder = count in preorder

**Leap of Faith:** Trust that recursively building left and right subtrees with correct slices gives the answer!

---

## Approach 1: Recursive with Hashmap

### Algorithm

```
1. Use hashmap for O(1) lookup of inorder indices
2. Take first element of preorder as root
3. Find root's index in inorder
4. Elements left of root index = left subtree
5. Elements right of root index = right subtree
6. Recursively build left and right
```

### Recursion Tree

```
build(pre=[3,9,20,15,7], in=[9,3,15,20,7])
    |
    +-- root = 3, inorder_idx = 1
    |
    +-- Left: build(pre=[9], in=[9])
    |       root = 9
    |       Left: None
    |       Right: None
    |       return Node(9)
    |
    +-- Right: build(pre=[20,15,7], in=[15,20,7])
            root = 20, inorder_idx = 1 (in this subarray)
            |
            +-- Left: build(pre=[15], in=[15])
            |       return Node(15)
            |
            +-- Right: build(pre=[7], in=[7])
                    return Node(7)
            
            return Node(20, 15, 7)
    
    return Node(3, Node(9), Node(20, 15, 7))
```

### Code

```python
def buildTree(preorder, inorder):
    # Hashmap for O(1) index lookup
    inorder_map = {val: idx for idx, val in enumerate(inorder)}
    pre_idx = [0]  # Mutable index for preorder
    
    def build(in_left, in_right):
        if in_left > in_right:
            return None
        
        # Root is current preorder element
        root_val = preorder[pre_idx[0]]
        pre_idx[0] += 1
        root = TreeNode(root_val)
        
        # Find root position in inorder
        in_idx = inorder_map[root_val]
        
        # Build left subtree first (before right in preorder)
        root.left = build(in_left, in_idx - 1)
        root.right = build(in_idx + 1, in_right)
        
        return root
    
    return build(0, len(inorder) - 1)
```

### Dry Run

```
preorder = [3, 9, 20, 15, 7]
inorder  = [9, 3, 15, 20, 7]
inorder_map = {9:0, 3:1, 15:2, 20:3, 7:4}

build(0, 4), pre_idx=0:
  root = 3, pre_idx = 1
  in_idx = 1
  
  left = build(0, 0):  # [9]
    root = 9, pre_idx = 2
    in_idx = 0
    left = build(0, -1) = None
    right = build(1, 0) = None
    return Node(9)
  
  right = build(2, 4):  # [15, 20, 7]
    root = 20, pre_idx = 3
    in_idx = 3
    
    left = build(2, 2):  # [15]
      root = 15, pre_idx = 4
      return Node(15)
    
    right = build(4, 4):  # [7]
      root = 7, pre_idx = 5
      return Node(7)
    
    return Node(20, 15, 7)
  
  return Node(3, 9, (20, 15, 7))
```

---

## Approach 2: Recursive with Array Slicing

### Code

```python
def buildTreeSlicing(preorder, inorder):
    if not preorder or not inorder:
        return None
    
    root_val = preorder[0]
    root = TreeNode(root_val)
    
    mid = inorder.index(root_val)
    
    # Left subtree: inorder[0:mid], preorder[1:mid+1]
    root.left = buildTreeSlicing(preorder[1:mid+1], inorder[:mid])
    
    # Right subtree: inorder[mid+1:], preorder[mid+1:]
    root.right = buildTreeSlicing(preorder[mid+1:], inorder[mid+1:])
    
    return root
```

**Note:** Less efficient due to array copies, but easier to understand.

---

## Approach 3: Iterative with Stack

### Code

```python
def buildTreeIterative(preorder, inorder):
    if not preorder:
        return None
    
    root = TreeNode(preorder[0])
    stack = [root]
    in_idx = 0
    
    for i in range(1, len(preorder)):
        node = TreeNode(preorder[i])
        
        if stack[-1].val != inorder[in_idx]:
            # Still going left
            stack[-1].left = node
        else:
            # Backtrack to find parent
            parent = None
            while stack and stack[-1].val == inorder[in_idx]:
                parent = stack.pop()
                in_idx += 1
            parent.right = node
        
        stack.append(node)
    
    return root
```

---

## Complexity Analysis

| Approach | Time | Space |
|----------|------|-------|
| Hashmap | O(N) | O(N) for hashmap |
| Array Slicing | O(N^2) | O(N^2) for copies |
| Iterative | O(N) | O(N) for stack |

---

## Edge Cases

| Case | Input | Output |
|------|-------|--------|
| Empty arrays | `[], []` | `None` |
| Single node | `[1], [1]` | `Node(1)` |
| Left skewed | `[1,2,3], [3,2,1]` | Chain left |
| Right skewed | `[1,2,3], [1,2,3]` | Chain right |

---

## Key Insight: Why It Works

```
For any tree:
- Preorder: [ROOT, ...left..., ...right...]
- Inorder:  [...left..., ROOT, ...right...]

The count of left subtree nodes in both arrays is the SAME!

If root is at index k in inorder:
- Left subtree has k nodes
- In preorder: left is preorder[1:k+1]
- In preorder: right is preorder[k+1:]
```

---

## Key Takeaways

1. **Preorder gives root:** First element is always root
2. **Inorder splits tree:** Root position divides left/right
3. **Hashmap optimization:** O(1) index lookup
4. **Order matters:** Build left before right (matches preorder)
5. **Array slicing:** Simpler but O(N^2)

---

## Related Problems

- Construct Binary Tree from Inorder and Postorder (LeetCode 106)
- Construct Binary Search Tree from Preorder (LeetCode 1008)
- Serialize and Deserialize Binary Tree (LeetCode 297)
