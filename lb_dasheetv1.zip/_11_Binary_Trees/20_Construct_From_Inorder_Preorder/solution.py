"""
Construct Binary Tree from Inorder and Preorder Traversals
==========================================================

Problem: Given preorder and inorder traversals, construct the binary tree.

Key Insights:
- Preorder: Root first, then left subtree, then right subtree
- Inorder: Left subtree, then root, then right subtree
- First element of preorder is always the root
- Root's position in inorder divides left and right subtrees

Example:
    preorder = [3, 9, 20, 15, 7]
    inorder  = [9, 3, 15, 20, 7]

    Output:
        3
       / \
      9  20
        /  \
       15   7
"""

from collections import deque
from typing import List, Optional


class TreeNode:
    """Binary Tree Node"""
    def __init__(self, val: int = 0, left: 'TreeNode' = None, right: 'TreeNode' = None):
        self.val = val
        self.left = left
        self.right = right


# =============================================================================
# SOLUTION 1: Recursive with Hashmap (Optimal)
# =============================================================================

def buildTree(preorder: List[int], inorder: List[int]) -> Optional[TreeNode]:
    """
    Build tree using hashmap for O(1) index lookup.

    Algorithm:
    1. Create hashmap of inorder indices
    2. Use preorder index to track current root
    3. Recursively build with inorder bounds

    Time Complexity: O(N)
    Space Complexity: O(N) for hashmap

    Args:
        preorder: Preorder traversal array
        inorder: Inorder traversal array

    Returns:
        Root of constructed tree
    """
    if not preorder or not inorder:
        return None

    # Hashmap for O(1) index lookup in inorder
    inorder_map = {val: idx for idx, val in enumerate(inorder)}

    # Use list for mutable preorder index
    pre_idx = [0]

    def build(in_left: int, in_right: int) -> Optional[TreeNode]:
        """Build tree for inorder[in_left:in_right+1]"""
        if in_left > in_right:
            return None

        # Current root is at pre_idx in preorder
        root_val = preorder[pre_idx[0]]
        pre_idx[0] += 1

        root = TreeNode(root_val)

        # Find root position in inorder
        in_idx = inorder_map[root_val]

        # IMPORTANT: Build left first, then right
        # This matches preorder traversal order
        root.left = build(in_left, in_idx - 1)
        root.right = build(in_idx + 1, in_right)

        return root

    return build(0, len(inorder) - 1)


# =============================================================================
# SOLUTION 2: Recursive with Array Slicing (Simpler but O(N^2))
# =============================================================================

def buildTreeSlicing(preorder: List[int], inorder: List[int]) -> Optional[TreeNode]:
    """
    Build tree using array slicing.

    Easier to understand but less efficient due to array copies.

    Time: O(N^2) - index() and slicing
    Space: O(N^2) - array copies
    """
    if not preorder or not inorder:
        return None

    # Root is first element of preorder
    root_val = preorder[0]
    root = TreeNode(root_val)

    # Find root in inorder (divides left and right)
    mid = inorder.index(root_val)

    # Left subtree
    # inorder: everything before mid
    # preorder: next 'mid' elements after root
    root.left = buildTreeSlicing(preorder[1:mid + 1], inorder[:mid])

    # Right subtree
    # inorder: everything after mid
    # preorder: remaining elements
    root.right = buildTreeSlicing(preorder[mid + 1:], inorder[mid + 1:])

    return root


# =============================================================================
# SOLUTION 3: Iterative with Stack
# =============================================================================

def buildTreeIterative(preorder: List[int], inorder: List[int]) -> Optional[TreeNode]:
    """
    Iterative solution using stack.

    Time: O(N), Space: O(N)
    """
    if not preorder:
        return None

    root = TreeNode(preorder[0])
    stack = [root]
    in_idx = 0

    for i in range(1, len(preorder)):
        node = TreeNode(preorder[i])

        if stack[-1].val != inorder[in_idx]:
            # Still going left
            stack[-1].left = node
        else:
            # Need to backtrack to find correct parent
            parent = None
            while stack and stack[-1].val == inorder[in_idx]:
                parent = stack.pop()
                in_idx += 1
            parent.right = node

        stack.append(node)

    return root


# =============================================================================
# BONUS: Construct from Inorder and Postorder
# =============================================================================

def buildTreeFromPostorder(inorder: List[int], postorder: List[int]) -> Optional[TreeNode]:
    """
    Build tree from inorder and postorder traversals.

    Key insight: Postorder's last element is root.
    Process right subtree before left (reverse of postorder).
    """
    if not inorder or not postorder:
        return None

    inorder_map = {val: idx for idx, val in enumerate(inorder)}
    post_idx = [len(postorder) - 1]

    def build(in_left: int, in_right: int) -> Optional[TreeNode]:
        if in_left > in_right:
            return None

        root_val = postorder[post_idx[0]]
        post_idx[0] -= 1

        root = TreeNode(root_val)
        in_idx = inorder_map[root_val]

        # Build RIGHT first (postorder is root-right-left reversed)
        root.right = build(in_idx + 1, in_right)
        root.left = build(in_left, in_idx - 1)

        return root

    return build(0, len(inorder) - 1)


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def tree_to_list(root: Optional[TreeNode]) -> List[Optional[int]]:
    """Convert tree to level-order list."""
    if not root:
        return []

    result = []
    queue = deque([root])

    while queue:
        node = queue.popleft()
        if node:
            result.append(node.val)
            queue.append(node.left)
            queue.append(node.right)
        else:
            result.append(None)

    while result and result[-1] is None:
        result.pop()

    return result


def preorder_traversal(root: Optional[TreeNode]) -> List[int]:
    """Get preorder traversal."""
    result = []
    def traverse(node):
        if node:
            result.append(node.val)
            traverse(node.left)
            traverse(node.right)
    traverse(root)
    return result


def inorder_traversal(root: Optional[TreeNode]) -> List[int]:
    """Get inorder traversal."""
    result = []
    def traverse(node):
        if node:
            traverse(node.left)
            result.append(node.val)
            traverse(node.right)
    traverse(root)
    return result


def print_tree(root: Optional[TreeNode], level: int = 0, prefix: str = "Root: "):
    """Print tree structure for visualization."""
    if root is not None:
        print(" " * (level * 4) + prefix + str(root.val))
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            else:
                print(" " * ((level + 1) * 4) + "L--- None")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")
            else:
                print(" " * ((level + 1) * 4) + "R--- None")


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("CONSTRUCT TREE FROM INORDER AND PREORDER - TEST CASES")
    print("=" * 60)

    # Test Case 1: LeetCode example
    print("\nTest Case 1: [3,9,20,15,7]")
    print("-" * 40)
    preorder1 = [3, 9, 20, 15, 7]
    inorder1 = [9, 3, 15, 20, 7]
    print(f"Preorder: {preorder1}")
    print(f"Inorder:  {inorder1}")
    tree1 = buildTree(preorder1, inorder1)
    print("\nConstructed tree:")
    print_tree(tree1)

    # Verify
    print(f"\nVerification:")
    print(f"Preorder: {preorder_traversal(tree1)}")
    print(f"Inorder:  {inorder_traversal(tree1)}")

    # Test Case 2: Empty arrays
    print("\n" + "-" * 40)
    print("Test Case 2: Empty arrays")
    print(f"Result: {buildTree([], [])}")

    # Test Case 3: Single node
    print("\n" + "-" * 40)
    print("Test Case 3: Single node")
    tree3 = buildTree([1], [1])
    print_tree(tree3)

    # Test Case 4: Left skewed
    print("\n" + "-" * 40)
    print("Test Case 4: Left skewed tree")
    preorder4 = [1, 2, 3]
    inorder4 = [3, 2, 1]
    tree4 = buildTree(preorder4, inorder4)
    print(f"Preorder: {preorder4}")
    print(f"Inorder:  {inorder4}")
    print("\nConstructed tree:")
    print_tree(tree4)

    # Test Case 5: Right skewed
    print("\n" + "-" * 40)
    print("Test Case 5: Right skewed tree")
    preorder5 = [1, 2, 3]
    inorder5 = [1, 2, 3]
    tree5 = buildTree(preorder5, inorder5)
    print(f"Preorder: {preorder5}")
    print(f"Inorder:  {inorder5}")
    print("\nConstructed tree:")
    print_tree(tree5)

    # Comparison of methods
    print("\n" + "=" * 60)
    print("COMPARISON OF ALL METHODS")
    print("=" * 60)

    preorder = [3, 9, 20, 15, 7]
    inorder = [9, 3, 15, 20, 7]

    tree_hashmap = buildTree(preorder, inorder)
    tree_slicing = buildTreeSlicing(preorder, inorder)
    tree_iterative = buildTreeIterative(preorder, inorder)

    print(f"\nHashmap method:   {tree_to_list(tree_hashmap)}")
    print(f"Slicing method:   {tree_to_list(tree_slicing)}")
    print(f"Iterative method: {tree_to_list(tree_iterative)}")

    # Test postorder construction
    print("\n" + "-" * 40)
    print("BONUS: Construct from Inorder and Postorder")
    inorder_p = [9, 3, 15, 20, 7]
    postorder = [9, 15, 7, 20, 3]
    tree_post = buildTreeFromPostorder(inorder_p, postorder)
    print(f"Inorder:   {inorder_p}")
    print(f"Postorder: {postorder}")
    print("\nConstructed tree:")
    print_tree(tree_post)

    print("\n" + "=" * 60)
    print("All tests completed!")
    print("=" * 60)
