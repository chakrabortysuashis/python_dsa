"""
Convert Binary Tree to Sum Tree
===============================

Problem: Replace each node's value with the sum of all values
in its left and right subtrees. Leaves become 0.

Example:
        10                20
       /  \              /  \
      -2   6    ->      4    12
     / \  / \          / \  / \
    8  -4 7  5        0   0 0  0
"""

from collections import deque
from typing import List, Optional


class TreeNode:
    """Binary Tree Node"""
    def __init__(self, val: int = 0, left: 'TreeNode' = None, right: 'TreeNode' = None):
        self.val = val
        self.left = left
        self.right = right


# =============================================================================
# SOLUTION 1: Single-Pass Post-Order
# =============================================================================

def toSumTree(root: Optional[TreeNode]) -> Optional[TreeNode]:
    """
    Convert tree to sum tree using post-order traversal.

    Algorithm:
    1. Recursively get left subtree sum
    2. Recursively get right subtree sum
    3. Update node.val = left_sum + right_sum
    4. Return old_val + new_val (contribution to parent)

    Time Complexity: O(N)
    Space Complexity: O(H) for recursion

    Args:
        root: Root of binary tree

    Returns:
        Root of converted sum tree
    """
    def convert(node: Optional[TreeNode]) -> int:
        """
        Convert node to sum tree and return subtree total.

        Returns: Sum of original values in subtree (including this node)
        """
        if not node:
            return 0

        # Post-order: process children first
        left_sum = convert(node.left)
        right_sum = convert(node.right)

        # Store old value before modifying
        old_val = node.val

        # Update node value to sum of children's subtrees
        node.val = left_sum + right_sum

        # Return total contribution of this subtree
        return old_val + node.val

    convert(root)
    return root


# =============================================================================
# SOLUTION 2: Iterative Post-Order with Stack
# =============================================================================

def toSumTreeIterative(root: Optional[TreeNode]) -> Optional[TreeNode]:
    """
    Iterative solution using post-order traversal.

    Uses hashmap to store subtree sums.

    Time: O(N), Space: O(N)
    """
    if not root:
        return None

    subtree_sums = {None: 0}
    stack = [(root, False)]

    while stack:
        node, processed = stack.pop()

        if processed:
            # Children have been processed
            left_sum = subtree_sums.get(node.left, 0)
            right_sum = subtree_sums.get(node.right, 0)

            old_val = node.val
            node.val = left_sum + right_sum
            subtree_sums[node] = old_val + node.val
        else:
            stack.append((node, True))
            if node.right:
                stack.append((node.right, False))
            if node.left:
                stack.append((node.left, False))

    return root


# =============================================================================
# SOLUTION 3: Two-Pass (Less Efficient)
# =============================================================================

def toSumTreeTwoPass(root: Optional[TreeNode]) -> Optional[TreeNode]:
    """
    Two-pass approach: calculate sums, then update.

    Less efficient (O(N^2)) but easier to understand.
    """
    def subtreeSum(node: Optional[TreeNode]) -> int:
        """Calculate sum of all values in subtree."""
        if not node:
            return 0
        return node.val + subtreeSum(node.left) + subtreeSum(node.right)

    def update(node: Optional[TreeNode]) -> None:
        """Update each node to sum of its subtrees."""
        if not node:
            return

        # Calculate before recursive update changes children
        left_sum = subtreeSum(node.left)
        right_sum = subtreeSum(node.right)
        node.val = left_sum + right_sum

        update(node.left)
        update(node.right)

    update(root)
    return root


# =============================================================================
# BONUS: Check if Tree is Sum Tree
# =============================================================================

def isSumTree(root: Optional[TreeNode]) -> bool:
    """
    Check if given tree is already a sum tree.

    A sum tree has: node.val = sum of left subtree + sum of right subtree
    """
    def check(node: Optional[TreeNode]) -> tuple:
        """Returns (is_sum_tree, subtree_sum)"""
        if not node:
            return (True, 0)

        # Leaf nodes are always sum trees
        if not node.left and not node.right:
            return (True, node.val)

        left_valid, left_sum = check(node.left)
        right_valid, right_sum = check(node.right)

        # This node is valid if children are valid AND
        # node.val equals sum of children's subtrees
        is_valid = (left_valid and right_valid and
                   node.val == left_sum + right_sum)

        # Subtree sum = node.val + left_sum + right_sum
        # But in sum tree, node.val = left_sum + right_sum
        # So subtree sum = 2 * node.val for non-leaves
        total = node.val + left_sum + right_sum

        return (is_valid, total)

    return check(root)[0]


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def build_tree(values: List[Optional[int]]) -> Optional[TreeNode]:
    """Build binary tree from level-order list representation."""
    if not values or values[0] is None:
        return None

    root = TreeNode(values[0])
    queue = deque([root])
    i = 1

    while queue and i < len(values):
        node = queue.popleft()

        if i < len(values) and values[i] is not None:
            node.left = TreeNode(values[i])
            queue.append(node.left)
        i += 1

        if i < len(values) and values[i] is not None:
            node.right = TreeNode(values[i])
            queue.append(node.right)
        i += 1

    return root


def tree_to_list(root: Optional[TreeNode]) -> List[Optional[int]]:
    """Convert tree to level-order list."""
    if not root:
        return []

    result = []
    queue = deque([root])

    while queue:
        node = queue.popleft()
        if node:
            result.append(node.val)
            queue.append(node.left)
            queue.append(node.right)
        else:
            result.append(None)

    # Remove trailing Nones
    while result and result[-1] is None:
        result.pop()

    return result


def print_tree(root: Optional[TreeNode], level: int = 0, prefix: str = "Root: "):
    """Print tree structure for visualization."""
    if root is not None:
        print(" " * (level * 4) + prefix + str(root.val))
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            else:
                print(" " * ((level + 1) * 4) + "L--- None")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")
            else:
                print(" " * ((level + 1) * 4) + "R--- None")


def clone_tree(root: Optional[TreeNode]) -> Optional[TreeNode]:
    """Create a deep copy of the tree."""
    if not root:
        return None
    new_node = TreeNode(root.val)
    new_node.left = clone_tree(root.left)
    new_node.right = clone_tree(root.right)
    return new_node


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("CONVERT TO SUM TREE - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal tree
    print("\nTest Case 1: Normal tree")
    print("-" * 40)
    tree1 = build_tree([10, -2, 6, 8, -4, 7, 5])
    print("Original tree:")
    print_tree(tree1)
    toSumTree(tree1)
    print("\nSum tree:")
    print_tree(tree1)
    print(f"Is sum tree: {isSumTree(tree1)}")

    # Test Case 2: Empty tree
    print("\n" + "-" * 40)
    print("Test Case 2: Empty tree")
    print(f"Result: {toSumTree(None)}")

    # Test Case 3: Single node
    print("\n" + "-" * 40)
    print("Test Case 3: Single node [5]")
    tree3 = TreeNode(5)
    print(f"Before: {tree3.val}")
    toSumTree(tree3)
    print(f"After: {tree3.val}")

    # Test Case 4: Simple tree
    print("\n" + "-" * 40)
    print("Test Case 4: Simple tree [1, 2, 3]")
    tree4 = build_tree([1, 2, 3])
    print("Original:")
    print_tree(tree4)
    toSumTree(tree4)
    print("\nSum tree:")
    print_tree(tree4)

    # Test Case 5: All negative
    print("\n" + "-" * 40)
    print("Test Case 5: All negative values")
    tree5 = build_tree([-1, -2, -3])
    print("Original:")
    print_tree(tree5)
    toSumTree(tree5)
    print("\nSum tree:")
    print_tree(tree5)

    # Comparison of methods
    print("\n" + "=" * 60)
    print("COMPARISON OF METHODS")
    print("=" * 60)

    original = build_tree([10, 5, 15, 3, 7, 12, 20])
    print("\nOriginal tree:")
    print_tree(original)

    tree_copy1 = clone_tree(original)
    tree_copy2 = clone_tree(original)
    tree_copy3 = clone_tree(original)

    toSumTree(tree_copy1)
    toSumTreeIterative(tree_copy2)
    toSumTreeTwoPass(tree_copy3)

    print("\nSingle-pass recursive:")
    print_tree(tree_copy1)
    print(f"List: {tree_to_list(tree_copy1)}")

    print("\nIterative:")
    print(f"List: {tree_to_list(tree_copy2)}")

    print("\nTwo-pass:")
    print(f"List: {tree_to_list(tree_copy3)}")

    print("\n" + "=" * 60)
    print("All tests completed!")
    print("=" * 60)
