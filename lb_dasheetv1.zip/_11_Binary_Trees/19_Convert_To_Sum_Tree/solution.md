# Convert Binary Tree to Sum Tree

## Problem Statement

Given a binary tree, convert it to a **Sum Tree** where each node's value is replaced by the sum of all values in its left and right subtrees. Leaf nodes become 0.

## Example

```
Input:
        10
       /  \
      -2   6
     / \  / \
    8  -4 7  5

Output:
        20
       /  \
      4    12
     / \  / \
    0   0 0  0

Explanation:
- Leaf nodes (8, -4, 7, 5) become 0
- Node -2: sum of subtree = 8 + (-4) = 4
- Node 6: sum of subtree = 7 + 5 = 12
- Node 10: sum = (4 + (-2)) + (12 + 6) = 20
```

---

## Visualization

```
Original:           Sum Tree:
    10                 20
   /  \               /  \
  -2   6      ->     4    12
 / \  / \           / \  / \
8  -4 7  5         0   0 0  0

For node -2:
  Left subtree sum: 8
  Right subtree sum: -4
  New value = 8 + (-4) = 4

For root 10:
  Left subtree total: 8 + (-4) + (-2) = 2
  Right subtree total: 7 + 5 + 6 = 18
  New value = 2 + 18 = 20
```

---

## Intuition: Post-Order Traversal

**Key Insight:** We need subtree sums before updating the node. Use **post-order** (children first, then parent).

**For each node:**
1. Get sum of left subtree (including left child's original value)
2. Get sum of right subtree (including right child's original value)
3. Store original value
4. Update node value = left_sum + right_sum
5. Return node's contribution = old_value + new_value

**Leap of Faith:** Trust that recursive calls return correct subtree sums!

---

## Approach 1: Recursive Post-Order

### Algorithm

```
1. Base case: if null, return 0
2. Recursively get left subtree sum
3. Recursively get right subtree sum
4. Store old value
5. node.val = left_sum + right_sum
6. Return old_value + node.val (total contribution)
```

### Recursion Tree

```
toSumTree(10)
    |
    +-- toSumTree(-2)
    |       |
    |       +-- toSumTree(8) = 8 (leaf)
    |       |       8.val = 0, return 8
    |       |
    |       +-- toSumTree(-4) = -4 (leaf)
    |       |       (-4).val = 0, return -4
    |       |
    |       old = -2
    |       (-2).val = 8 + (-4) = 4
    |       return -2 + 4 = 2
    |
    +-- toSumTree(6)
    |       |
    |       +-- toSumTree(7) = 7, 7.val = 0
    |       +-- toSumTree(5) = 5, 5.val = 0
    |       old = 6
    |       6.val = 7 + 5 = 12
    |       return 6 + 12 = 18
    |
    old = 10
    10.val = 2 + 18 = 20
    return 10 + 20 = 30
```

### Code

```python
def toSumTree(root):
    def convert(node):
        if not node:
            return 0
        
        # Post-order: children first
        left_sum = convert(node.left)
        right_sum = convert(node.right)
        
        # Store old value
        old_val = node.val
        
        # Update to sum of children
        node.val = left_sum + right_sum
        
        # Return total contribution of this subtree
        return old_val + node.val
    
    convert(root)
    return root
```

### Dry Run

```
Tree:
    1
   / \
  2   3

convert(1):
  convert(2):
    convert(None) = 0
    convert(None) = 0
    old = 2
    2.val = 0 + 0 = 0
    return 2 + 0 = 2
  
  convert(3):
    old = 3
    3.val = 0
    return 3 + 0 = 3
  
  old = 1
  1.val = 2 + 3 = 5
  return 1 + 5 = 6

Result:
    5
   / \
  0   0
```

---

## Approach 2: Two-Pass (Calculate sums first)

### Code

```python
def toSumTreeTwoPass(root):
    # First pass: calculate subtree sums
    def subtreeSum(node):
        if not node:
            return 0
        return node.val + subtreeSum(node.left) + subtreeSum(node.right)
    
    # Second pass: update values
    def update(node):
        if not node:
            return
        
        left_sum = subtreeSum(node.left)
        right_sum = subtreeSum(node.right)
        node.val = left_sum + right_sum
        
        update(node.left)
        update(node.right)
    
    update(root)
    return root
```

**Note:** This is O(N^2), less efficient than single-pass.

---

## Complexity Analysis

| Approach | Time | Space |
|----------|------|-------|
| Single-Pass | O(N) | O(H) for recursion |
| Two-Pass | O(N^2) | O(H) for recursion |

---

## Edge Cases

| Case | Input | Output |
|------|-------|--------|
| Empty tree | `None` | `None` |
| Single node | `[5]` | `[0]` |
| All same values | `[1,1,1]` | `[2,0,0]` |
| Negative values | `[-1,-2,-3]` | `[-5,0,0]` |

---

## Key Takeaways

1. **Post-order is key:** Need children's sums before updating parent
2. **Return contribution:** old_value + new_value for parent's calculation
3. **Leaves become 0:** No children means sum = 0
4. **In-place modification:** Original tree is modified
5. **Total sum preserved:** Root's old value + root's new value = total tree sum

---

## Related Problems

- Sum Root to Leaf Numbers (LeetCode 129)
- Binary Tree Maximum Path Sum (LeetCode 124)
- Sum of Left Leaves (LeetCode 404)
- Check if Tree is Sum Tree
