# Diameter of a Binary Tree

## Problem Statement

Given a binary tree, find its **diameter**. The diameter is the **length of the longest path** between any two nodes in the tree. This path may or may not pass through the root.

**Note:** The length is measured by the number of edges between nodes.

## Example

```
Input:
        1
       / \
      2   3
     / \
    4   5

Diameter = 3 (path: 4 -> 2 -> 1 -> 3 or 5 -> 2 -> 1 -> 3)
```

## Tree Visualization

```
        1
       / \
      2   3
     / \
    4   5

Longest path: 4 -> 2 -> 1 -> 3
              or 5 -> 2 -> 1 -> 3
              
Number of edges: 3
```

### Important: Path May Not Pass Through Root!

```
        1
       /
      2
     / \
    3   4
   /     \
  5       6

Diameter path: 5 -> 3 -> 2 -> 4 -> 6
This path does NOT go through root (1)!
Diameter = 4
```

---

## Intuition

### Key Insight

For any node, the longest path **passing through that node** = `left_height + right_height`

The diameter is the **maximum such path across all nodes**.

```
        1
       / \
      2   3
     / \
    4   5

At node 2:
  left_height (from 4) = 1
  right_height (from 5) = 1
  path through 2 = 1 + 1 = 2

At node 1:
  left_height (from 2) = 2
  right_height (from 3) = 1
  path through 1 = 2 + 1 = 3 <- Maximum!
```

### The "Leap of Faith"

- Trust that height calculation works for subtrees
- At each node, calculate the path through it
- Track the maximum path seen so far

---

## Approach: Single Pass DFS

### Algorithm

```
1. Initialize max_diameter = 0
2. For each node (using DFS to calculate height):
   a. Get left subtree height
   b. Get right subtree height
   c. Path through this node = left_height + right_height
   d. Update max_diameter if this path is longer
   e. Return height of this node (1 + max(left, right))
3. Return max_diameter
```

### Why This Works

We compute height bottom-up. At each node:
- We already know heights of children
- We can calculate the path through current node
- We update global maximum if needed

---

## Recursion Tree

```
Tree:
        1
       / \
      2   3
     /
    4

diameter(1)
    |
    +-- height(2)                    [returns 2, updates max]
    |       |
    |       +-- height(4)            [returns 1, path=0]
    |       |       |
    |       |       +-- height(None) = 0
    |       |       +-- height(None) = 0
    |       |       path = 0+0 = 0
    |       |       return 1
    |       |
    |       +-- height(None) = 0
    |       path = 1+0 = 1
    |       return 2
    |
    +-- height(3)                    [returns 1, path=0]
            |
            +-- height(None) = 0
            +-- height(None) = 0
            path = 0+0 = 0
            return 1
    
    At node 1: path = 2+1 = 3
    max_diameter = 3
```

---

## Code Implementation

### Python Solution

```python
def diameterOfBinaryTree(root):
    """
    Find diameter of binary tree.
    
    Time: O(N) - visit each node once
    Space: O(H) - recursion stack
    """
    max_diameter = [0]  # Use list for mutable reference
    
    def height(node):
        if node is None:
            return 0
        
        # Get heights of subtrees
        left_height = height(node.left)
        right_height = height(node.right)
        
        # Path through this node
        path_through_node = left_height + right_height
        
        # Update maximum diameter
        max_diameter[0] = max(max_diameter[0], path_through_node)
        
        # Return height of this subtree
        return 1 + max(left_height, right_height)
    
    height(root)
    return max_diameter[0]
```

### Alternative: Using Class Variable

```python
class Solution:
    def diameterOfBinaryTree(self, root):
        self.max_diameter = 0
        
        def height(node):
            if not node:
                return 0
            
            left = height(node.left)
            right = height(node.right)
            
            self.max_diameter = max(self.max_diameter, left + right)
            
            return 1 + max(left, right)
        
        height(root)
        return self.max_diameter
```

---

## Dry Run

```
Tree:
        1
       / \
      2   3
     / \
    4   5

Step-by-step:

1. Call height(1)
   -> Calls height(2)

2. Call height(2)
   -> Calls height(4)

3. Call height(4)
   -> Calls height(None) = 0 (left)
   -> Calls height(None) = 0 (right)
   -> path = 0 + 0 = 0
   -> max_diameter = max(0, 0) = 0
   -> return 1 + max(0, 0) = 1

4. Back to height(2)
   -> left_height = 1
   -> Calls height(5)

5. Call height(5)
   -> left = 0, right = 0
   -> path = 0, max_diameter still 0
   -> return 1

6. Back to height(2)
   -> left_height = 1, right_height = 1
   -> path = 1 + 1 = 2
   -> max_diameter = max(0, 2) = 2
   -> return 1 + max(1, 1) = 2

7. Back to height(1)
   -> left_height = 2
   -> Calls height(3)

8. Call height(3)
   -> left = 0, right = 0
   -> path = 0
   -> return 1

9. Back to height(1)
   -> left_height = 2, right_height = 1
   -> path = 2 + 1 = 3
   -> max_diameter = max(2, 3) = 3
   -> return 1 + max(2, 1) = 3

Final: max_diameter = 3
```

---

## Call Stack Visualization

```
Call Stack states:

[height(1)]
    |
[height(1), height(2)]
    |
[height(1), height(2), height(4)]
    |
[height(1), height(2), height(4), height(None)]  <- returns 0
    |
[height(1), height(2), height(4)]  <- computes, returns 1
    |
[height(1), height(2), height(5)]
    |
[height(1), height(2)]  <- gets left=1, right=1, path=2, returns 2
    |
[height(1), height(3)]
    |
[height(1)]  <- gets left=2, right=1, path=3, returns 3
    |
[]  <- Done! max_diameter = 3
```

---

## Complexity Analysis

### Time Complexity: O(N)

- We visit each node exactly once
- At each node, we do O(1) work
- Total: O(N)

### Space Complexity: O(H)

- Recursion stack depth = height of tree
- Best case (balanced): O(log N)
- Worst case (skewed): O(N)

---

## Edge Cases

| Case | Tree | Diameter |
|------|------|----------|
| Empty tree | `None` | 0 |
| Single node | `[1]` | 0 |
| Two nodes | `[1, 2]` | 1 |
| Linear/Skewed | `1->2->3->4` | 3 |
| Balanced | `[1,2,3,4,5,6,7]` | 4 |

---

## Common Mistakes

### 1. Returning height instead of diameter
```python
# WRONG
def diameter(root):
    if not root:
        return 0
    return 1 + max(diameter(root.left), diameter(root.right))
```

### 2. Only checking paths through root
```python
# WRONG - misses paths not through root
def diameter(root):
    if not root:
        return 0
    return height(root.left) + height(root.right)
```

### 3. Confusing edges vs nodes
- Diameter counts **edges**, not nodes
- Path 4 -> 2 -> 1 -> 3 has 3 edges, 4 nodes

---

## Naive Approach (Less Optimal)

Calculate height separately, leading to O(N^2) time:

```python
def diameter_naive(root):
    if not root:
        return 0
    
    # Diameter through root
    through_root = height(root.left) + height(root.right)
    
    # Diameter in left subtree
    left_diameter = diameter_naive(root.left)
    
    # Diameter in right subtree  
    right_diameter = diameter_naive(root.right)
    
    return max(through_root, left_diameter, right_diameter)
```

**Why O(N^2)?** For each node, we call height() which is O(N). Total: O(N^2).

Our optimized approach calculates diameter while computing height in a single pass!

---

## Key Takeaways

1. **Diameter = longest path between any two nodes** (measured in edges)
2. **Path through node = left_height + right_height**
3. **Single pass solution:** Calculate diameter while computing height
4. **Watch out:** Path may not go through root!
5. **Time O(N), Space O(H)**

---

## Related Problems

- Diameter of Binary Tree (LeetCode 543)
- Binary Tree Maximum Path Sum (LeetCode 124)
- Longest Univalue Path (LeetCode 687)
- Height of Binary Tree
