"""
Diameter of a Binary Tree
=========================

Problem: Find the diameter of a binary tree.
         The diameter is the length of the longest path between any two nodes.
         This path may or may not pass through the root.

Note: Length is measured by number of edges.

Example:
        1
       / \
      2   3
     / \
    4   5

    Diameter = 3 (path: 4 -> 2 -> 1 -> 3)
"""

from collections import deque
from typing import List, Optional


class TreeNode:
    """Binary Tree Node"""
    def __init__(self, val: int = 0, left: 'TreeNode' = None, right: 'TreeNode' = None):
        self.val = val
        self.left = left
        self.right = right


# =============================================================================
# SOLUTION 1: Optimized Single Pass (Recommended)
# =============================================================================

def diameterOfBinaryTree(root: Optional[TreeNode]) -> int:
    """
    Find diameter using single DFS pass.

    Key insight: For each node, the path through it = left_height + right_height.
    Track maximum path seen while computing heights.

    Time Complexity: O(N) - visit each node once
    Space Complexity: O(H) - recursion stack depth

    Args:
        root: Root of binary tree

    Returns:
        Diameter (number of edges on longest path)
    """
    max_diameter = [0]  # Use list for mutable reference in nested function

    def height(node: Optional[TreeNode]) -> int:
        """Calculate height while updating diameter."""
        if node is None:
            return 0

        # Recursively get heights of subtrees
        left_height = height(node.left)
        right_height = height(node.right)

        # Path through this node = sum of heights
        path_through_node = left_height + right_height

        # Update maximum diameter
        max_diameter[0] = max(max_diameter[0], path_through_node)

        # Return height of this subtree
        return 1 + max(left_height, right_height)

    height(root)
    return max_diameter[0]


# =============================================================================
# SOLUTION 2: Using Class (Alternative Style)
# =============================================================================

class Solution:
    """Class-based solution for diameter calculation."""

    def __init__(self):
        self.max_diameter = 0

    def diameterOfBinaryTree(self, root: Optional[TreeNode]) -> int:
        """Find diameter using instance variable to track maximum."""
        self.max_diameter = 0
        self._height(root)
        return self.max_diameter

    def _height(self, node: Optional[TreeNode]) -> int:
        """Calculate height while tracking diameter."""
        if not node:
            return 0

        left = self._height(node.left)
        right = self._height(node.right)

        # Update diameter
        self.max_diameter = max(self.max_diameter, left + right)

        return 1 + max(left, right)


# =============================================================================
# SOLUTION 3: Naive Approach (O(N^2) - For Understanding)
# =============================================================================

def diameterNaive(root: Optional[TreeNode]) -> int:
    """
    Naive approach: Check diameter at each node separately.

    For each node, calculate:
    1. Diameter through this node (left_height + right_height)
    2. Diameter in left subtree
    3. Diameter in right subtree

    Time: O(N^2) - height() called for each node
    Space: O(H)

    NOT RECOMMENDED - just for understanding!
    """
    def height(node: Optional[TreeNode]) -> int:
        if not node:
            return 0
        return 1 + max(height(node.left), height(node.right))

    if not root:
        return 0

    # Diameter through root
    through_root = height(root.left) + height(root.right)

    # Diameter in subtrees
    left_diameter = diameterNaive(root.left)
    right_diameter = diameterNaive(root.right)

    return max(through_root, left_diameter, right_diameter)


# =============================================================================
# SOLUTION 4: Iterative (Post-order with Stack)
# =============================================================================

def diameterIterative(root: Optional[TreeNode]) -> int:
    """
    Iterative solution using post-order traversal.

    Uses a dictionary to store heights of processed nodes.

    Time: O(N), Space: O(N)
    """
    if not root:
        return 0

    max_diameter = 0
    heights = {None: 0}  # Height of null node is 0
    stack = [(root, False)]  # (node, processed)

    while stack:
        node, processed = stack.pop()

        if processed:
            # Both children have been processed
            left_height = heights.get(node.left, 0)
            right_height = heights.get(node.right, 0)

            # Update diameter
            max_diameter = max(max_diameter, left_height + right_height)

            # Store height of this node
            heights[node] = 1 + max(left_height, right_height)
        else:
            # First visit - push back with processed=True, then children
            stack.append((node, True))

            if node.right:
                stack.append((node.right, False))
            if node.left:
                stack.append((node.left, False))

    return max_diameter


# =============================================================================
# BONUS: Diameter with Path Nodes Count
# =============================================================================

def diameterNodes(root: Optional[TreeNode]) -> int:
    """
    Return diameter counting nodes instead of edges.

    Diameter (nodes) = Diameter (edges) + 1
    """
    edges = diameterOfBinaryTree(root)
    return edges + 1 if root else 0


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def build_tree(values: List[Optional[int]]) -> Optional[TreeNode]:
    """Build binary tree from level-order list representation."""
    if not values or values[0] is None:
        return None

    root = TreeNode(values[0])
    queue = deque([root])
    i = 1

    while queue and i < len(values):
        node = queue.popleft()

        if i < len(values) and values[i] is not None:
            node.left = TreeNode(values[i])
            queue.append(node.left)
        i += 1

        if i < len(values) and values[i] is not None:
            node.right = TreeNode(values[i])
            queue.append(node.right)
        i += 1

    return root


def print_tree(root: Optional[TreeNode], level: int = 0, prefix: str = "Root: "):
    """Print tree structure for visualization."""
    if root is not None:
        print(" " * (level * 4) + prefix + str(root.val))
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("DIAMETER OF BINARY TREE - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal tree
    print("\nTest Case 1: Normal binary tree")
    print("-" * 40)
    tree1 = build_tree([1, 2, 3, 4, 5])
    print("Tree structure:")
    print_tree(tree1)
    print(f"\nDiameter (edges):    {diameterOfBinaryTree(tree1)}")
    print(f"Diameter (iterative):{diameterIterative(tree1)}")
    print(f"Diameter (naive):    {diameterNaive(tree1)}")
    print(f"Diameter (nodes):    {diameterNodes(tree1)}")

    # Test Case 2: Empty tree
    print("\n" + "-" * 40)
    print("Test Case 2: Empty tree")
    print(f"Diameter: {diameterOfBinaryTree(None)}")

    # Test Case 3: Single node
    print("\n" + "-" * 40)
    print("Test Case 3: Single node")
    tree3 = TreeNode(1)
    print(f"Diameter: {diameterOfBinaryTree(tree3)}")

    # Test Case 4: Two nodes
    print("\n" + "-" * 40)
    print("Test Case 4: Two nodes")
    tree4 = build_tree([1, 2])
    print_tree(tree4)
    print(f"Diameter: {diameterOfBinaryTree(tree4)}")

    # Test Case 5: Linear tree (skewed)
    print("\n" + "-" * 40)
    print("Test Case 5: Linear tree (left skewed)")
    tree5 = build_tree([1, 2, None, 3, None, 4])
    print("Tree structure:")
    print_tree(tree5)
    print(f"Diameter: {diameterOfBinaryTree(tree5)}")

    # Test Case 6: Path not through root
    print("\n" + "-" * 40)
    print("Test Case 6: Longest path NOT through root")
    #         1
    #        /
    #       2
    #      / \
    #     3   4
    #    /     \
    #   5       6
    tree6 = build_tree([1, 2, None, 3, 4, 5, None, None, 6])
    print("Tree structure:")
    print_tree(tree6)
    print(f"Diameter: {diameterOfBinaryTree(tree6)}")
    print("(Path: 5 -> 3 -> 2 -> 4 -> 6, doesn't go through root!)")

    # Test Case 7: Complete binary tree
    print("\n" + "-" * 40)
    print("Test Case 7: Complete binary tree")
    tree7 = build_tree([1, 2, 3, 4, 5, 6, 7])
    print("Tree structure:")
    print_tree(tree7)
    print(f"Diameter: {diameterOfBinaryTree(tree7)}")

    # Comparison of methods
    print("\n" + "=" * 60)
    print("COMPARISON OF ALL METHODS")
    print("=" * 60)

    test_cases = [
        ([1, 2, 3, 4, 5], "Normal tree"),
        ([1, 2, 3, 4, 5, 6, 7], "Complete tree"),
        ([1, 2, None, 3, None, 4, None, 5], "Left skewed"),
    ]

    for values, name in test_cases:
        tree = build_tree(values)
        d1 = diameterOfBinaryTree(tree)
        d2 = diameterIterative(tree)
        d3 = diameterNaive(tree)
        print(f"\n{name}: Optimized={d1}, Iterative={d2}, Naive={d3}")

    print("\n" + "=" * 60)
    print("All tests completed!")
    print("=" * 60)
