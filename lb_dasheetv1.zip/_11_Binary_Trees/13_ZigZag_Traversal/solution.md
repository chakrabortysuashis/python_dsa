# Zig-Zag (Spiral) Level Order Traversal

## Problem Statement

Given a binary tree, return the **zig-zag level order traversal** of its nodes' values.
- First level: Left to Right
- Second level: Right to Left
- Third level: Left to Right
- And so on...

This is also known as **Spiral Order Traversal**.

## Example

```
Input:
        1
       / \
      2   3
     / \ / \
    4  5 6  7

Output: [[1], [3, 2], [4, 5, 6, 7]]

Level 0 (L->R): [1]
Level 1 (R->L): [3, 2]
Level 2 (L->R): [4, 5, 6, 7]

Spiral: 1 -> 3 -> 2 -> 4 -> 5 -> 6 -> 7
```

---

## Visualization

```
Level 0:     -->        1          (Left to Right)
                       / \
Level 1:    <--       2   3        (Right to Left)
                     / \ / \
Level 2:     -->    4  5 6  7      (Left to Right)

Direction alternates at each level!
```

---

## Intuition: The Leap of Faith

**Key Insight:** This is level-order traversal with alternating directions.

**Two Approaches:**
1. BFS with direction flag - reverse alternate levels
2. Two stacks - one for L->R, one for R->L

### The "Leap of Faith"

Trust that we can collect each level's nodes, then simply reverse alternate levels!

---

## Approach 1: BFS with Direction Flag

### Algorithm

```
1. Perform normal level order traversal (BFS)
2. Maintain a direction flag (left_to_right)
3. After collecting each level:
   - If right_to_left: reverse the level
4. Toggle direction for next level
```

### Recursion Tree (Conceptual)

```
zigzag(root)
    |
    +-- Level 0: [1] (L->R, no reverse)
    |
    +-- Level 1: [2, 3] collected
    |       -> reverse to [3, 2] (R->L)
    |
    +-- Level 2: [4, 5, 6, 7] (L->R, no reverse)

Direction toggles: True -> False -> True -> ...
```

### Code

```python
def zigzagLevelOrder(root):
    if not root:
        return []
    
    result = []
    queue = deque([root])
    left_to_right = True
    
    while queue:
        level_size = len(queue)
        level = []
        
        for _ in range(level_size):
            node = queue.popleft()
            level.append(node.val)
            
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
        
        # Reverse if right to left
        if not left_to_right:
            level.reverse()
        
        result.append(level)
        left_to_right = not left_to_right
    
    return result
```

### Dry Run

```
Tree:
        1
       / \
      2   3
     / \
    4   5

Level 0: queue=[1], left_to_right=True
  - Process 1, add 2,3
  - level=[1], no reverse
  - result=[[1]]

Level 1: queue=[2,3], left_to_right=False
  - Process 2, add 4,5
  - Process 3
  - level=[2,3], REVERSE to [3,2]
  - result=[[1], [3,2]]

Level 2: queue=[4,5], left_to_right=True
  - Process 4, 5
  - level=[4,5], no reverse
  - result=[[1], [3,2], [4,5]]

Final: [[1], [3, 2], [4, 5]]
```

---

## Approach 2: Two Stacks

### Algorithm

```
1. Use two stacks: s1 (current level), s2 (next level)
2. Start with root in s1
3. While processing s1:
   - If L->R: push left child first, then right (to s2)
   - If R->L: push right child first, then left (to s2)
4. Swap stacks when s1 empty
```

### Visualization

```
Stack-based approach:

Initial: s1=[1], s2=[]

Pop 1 from s1 (L->R direction)
  Push children to s2 in reverse: s2=[3, 2]
  Output: 1

Pop 3 from s2 (R->L direction)
  Push to s1: s1=[6, 7]
Pop 2 from s2
  Push to s1: s1=[6, 7, 4, 5]
  Output: 3, 2

Pop 5, 4, 7, 6 from s1 (L->R again)
  Output: 5, 4, 7, 6... wait, this needs adjustment!
```

**Note:** Two-stack approach requires careful child ordering.

---

## Approach 3: Deque-based (Optimal)

### Algorithm

```
1. Use deque for result building
2. Based on direction:
   - L->R: append to right of level list
   - R->L: append to left of level list
```

### Code

```python
def zigzagLevelOrderDeque(root):
    if not root:
        return []
    
    result = []
    queue = deque([root])
    left_to_right = True
    
    while queue:
        level_size = len(queue)
        level = deque()
        
        for _ in range(level_size):
            node = queue.popleft()
            
            # Add based on direction
            if left_to_right:
                level.append(node.val)
            else:
                level.appendleft(node.val)
            
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
        
        result.append(list(level))
        left_to_right = not left_to_right
    
    return result
```

---

## Approach 4: Recursive DFS

### Algorithm

```
1. DFS with level tracking
2. Build levels in result list
3. Insert based on direction:
   - Even level (0, 2, 4...): append
   - Odd level (1, 3, 5...): insert at front
```

### Recursion Tree

```
zigzag(node=1, level=0, result)
    |
    +-- Add 1 to result[0] (append, L->R)
    |
    +-- zigzag(node=2, level=1, result)
    |       |
    |       +-- Add 2 to result[1] at front (R->L)
    |       +-- zigzag(4, 2) -> append 4 to result[2]
    |       +-- zigzag(5, 2) -> append 5 to result[2]
    |
    +-- zigzag(node=3, level=1, result)
            |
            +-- Add 3 to result[1] at front -> [3, 2]
            +-- zigzag(6, 2) -> append 6
            +-- zigzag(7, 2) -> append 7
```

### Code

```python
def zigzagDFS(root):
    result = []
    
    def dfs(node, level):
        if not node:
            return
        
        # Create new level list if needed
        if level >= len(result):
            result.append(deque())
        
        # Add based on direction
        if level % 2 == 0:
            result[level].append(node.val)
        else:
            result[level].appendleft(node.val)
        
        dfs(node.left, level + 1)
        dfs(node.right, level + 1)
    
    dfs(root, 0)
    return [list(level) for level in result]
```

---

## Complexity Analysis

| Approach | Time | Space |
|----------|------|-------|
| BFS + Reverse | O(N) | O(N) - queue + result |
| Two Stacks | O(N) | O(N) - two stacks |
| Deque BFS | O(N) | O(N) - queue + result |
| DFS | O(N) | O(H) - recursion + O(N) result |

**Where:**
- N = number of nodes
- H = height of tree

---

## Edge Cases

| Case | Input | Output |
|------|-------|--------|
| Empty tree | `None` | `[]` |
| Single node | `[1]` | `[[1]]` |
| Two levels | `[1,2,3]` | `[[1], [3,2]]` |
| Left skewed | `1->2->3` | `[[1], [2], [3]]` |
| Complete tree | 7 nodes | `[[1], [3,2], [4,5,6,7]]` |

---

## Call Stack Visualization (DFS)

```
Tree:
    1
   / \
  2   3

dfs(1, level=0)
    result[0].append(1) -> result = [[1]]
    |
    +-- dfs(2, level=1)
    |       result[1].appendleft(2) -> result = [[1], [2]]
    |       +-- dfs(None) return
    |       +-- dfs(None) return
    |
    +-- dfs(3, level=1)
            result[1].appendleft(3) -> result = [[1], [3,2]]
            +-- dfs(None) return
            +-- dfs(None) return

Final: [[1], [3, 2]]
```

---

## Key Takeaways

1. **Core idea:** Level order + alternate direction
2. **BFS approach:** Collect level, reverse if needed
3. **Deque optimization:** O(1) insert at front
4. **DFS approach:** Track level, insert based on parity
5. **Direction logic:** `level % 2 == 0` means L->R

---

## Related Problems

- Binary Tree Level Order Traversal (LeetCode 102)
- Binary Tree Level Order Traversal II (LeetCode 107)
- Binary Tree Zigzag Level Order Traversal (LeetCode 103)
- N-ary Tree Level Order Traversal (LeetCode 429)
