"""
Zig-Zag (Spiral) Level Order Traversal
======================================

Problem: Return the zigzag level order traversal of a binary tree.
- Level 0: Left to Right
- Level 1: Right to Left
- Level 2: Left to Right (and so on...)

Example:
        1
       / \
      2   3
     / \ / \
    4  5 6  7

Output: [[1], [3, 2], [4, 5, 6, 7]]
"""

from collections import deque
from typing import List, Optional


class TreeNode:
    """Binary Tree Node"""
    def __init__(self, val: int = 0, left: 'TreeNode' = None, right: 'TreeNode' = None):
        self.val = val
        self.left = left
        self.right = right


# =============================================================================
# SOLUTION 1: BFS with Direction Flag (Reverse alternate levels)
# =============================================================================

def zigzagLevelOrder(root: Optional[TreeNode]) -> List[List[int]]:
    """
    Zigzag level order using BFS with direction flag.

    Algorithm:
    1. Perform normal level order traversal
    2. Reverse alternate levels (odd levels)

    Time Complexity: O(N) - visit each node once
    Space Complexity: O(N) - queue can hold up to N/2 nodes

    Args:
        root: Root of binary tree

    Returns:
        List of levels with zigzag ordering
    """
    if not root:
        return []

    result = []
    queue = deque([root])
    left_to_right = True  # Direction flag

    while queue:
        level_size = len(queue)
        level = []

        # Process all nodes at current level
        for _ in range(level_size):
            node = queue.popleft()
            level.append(node.val)

            # Add children for next level
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)

        # Reverse if going right to left
        if not left_to_right:
            level.reverse()

        result.append(level)
        left_to_right = not left_to_right  # Toggle direction

    return result


# =============================================================================
# SOLUTION 2: BFS with Deque (No reversal needed)
# =============================================================================

def zigzagLevelOrderDeque(root: Optional[TreeNode]) -> List[List[int]]:
    """
    Zigzag traversal using deque for O(1) front insertion.

    Instead of reversing, we insert at front for R->L levels.

    Time: O(N), Space: O(N)
    """
    if not root:
        return []

    result = []
    queue = deque([root])
    left_to_right = True

    while queue:
        level_size = len(queue)
        level = deque()  # Use deque for O(1) front insertion

        for _ in range(level_size):
            node = queue.popleft()

            # Insert based on direction
            if left_to_right:
                level.append(node.val)  # Add to right
            else:
                level.appendleft(node.val)  # Add to left

            # Always add children left to right
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)

        result.append(list(level))
        left_to_right = not left_to_right

    return result


# =============================================================================
# SOLUTION 3: DFS Recursive
# =============================================================================

def zigzagLevelOrderDFS(root: Optional[TreeNode]) -> List[List[int]]:
    """
    Zigzag traversal using DFS with level tracking.

    Algorithm:
    1. DFS traverse the tree with level info
    2. For even levels: append to level list
    3. For odd levels: prepend to level list

    Time: O(N), Space: O(H) for recursion + O(N) for result
    """
    result = []

    def dfs(node: Optional[TreeNode], level: int) -> None:
        if not node:
            return

        # Create new level list if needed
        if level >= len(result):
            result.append(deque())

        # Add value based on level direction
        if level % 2 == 0:
            result[level].append(node.val)  # L->R: append
        else:
            result[level].appendleft(node.val)  # R->L: prepend

        # Recurse on children
        dfs(node.left, level + 1)
        dfs(node.right, level + 1)

    dfs(root, 0)
    return [list(level) for level in result]


# =============================================================================
# SOLUTION 4: Two Stacks Approach
# =============================================================================

def zigzagTwoStacks(root: Optional[TreeNode]) -> List[List[int]]:
    """
    Zigzag traversal using two stacks.

    Algorithm:
    - Stack 1: Process current level
    - Stack 2: Build next level
    - Alternate child order based on direction

    Time: O(N), Space: O(N)
    """
    if not root:
        return []

    result = []
    current_stack = [root]
    next_stack = []
    left_to_right = True
    current_level = []

    while current_stack:
        node = current_stack.pop()
        current_level.append(node.val)

        if left_to_right:
            # Add left then right for next R->L
            if node.left:
                next_stack.append(node.left)
            if node.right:
                next_stack.append(node.right)
        else:
            # Add right then left for next L->R
            if node.right:
                next_stack.append(node.right)
            if node.left:
                next_stack.append(node.left)

        # Level complete
        if not current_stack:
            result.append(current_level)
            current_level = []
            current_stack, next_stack = next_stack, current_stack
            left_to_right = not left_to_right

    return result


# =============================================================================
# SOLUTION 5: Iterative with Index-based insertion
# =============================================================================

def zigzagLevelOrderIndexed(root: Optional[TreeNode]) -> List[List[int]]:
    """
    Zigzag using index calculation for position.

    For R->L levels, calculate reverse index:
    position = level_size - 1 - current_index

    Time: O(N), Space: O(N)
    """
    if not root:
        return []

    result = []
    queue = deque([root])
    left_to_right = True

    while queue:
        level_size = len(queue)
        level = [0] * level_size  # Pre-allocate

        for i in range(level_size):
            node = queue.popleft()

            # Calculate index based on direction
            if left_to_right:
                index = i
            else:
                index = level_size - 1 - i

            level[index] = node.val

            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)

        result.append(level)
        left_to_right = not left_to_right

    return result


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def build_tree(values: List[Optional[int]]) -> Optional[TreeNode]:
    """Build binary tree from level-order list representation."""
    if not values or values[0] is None:
        return None

    root = TreeNode(values[0])
    queue = deque([root])
    i = 1

    while queue and i < len(values):
        node = queue.popleft()

        if i < len(values) and values[i] is not None:
            node.left = TreeNode(values[i])
            queue.append(node.left)
        i += 1

        if i < len(values) and values[i] is not None:
            node.right = TreeNode(values[i])
            queue.append(node.right)
        i += 1

    return root


def print_tree(root: Optional[TreeNode], level: int = 0, prefix: str = "Root: "):
    """Print tree structure for visualization."""
    if root is not None:
        print(" " * (level * 4) + prefix + str(root.val))
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            else:
                print(" " * ((level + 1) * 4) + "L--- None")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")
            else:
                print(" " * ((level + 1) * 4) + "R--- None")


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("ZIGZAG LEVEL ORDER TRAVERSAL - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal binary tree
    print("\nTest Case 1: Normal binary tree")
    print("-" * 40)
    tree1 = build_tree([1, 2, 3, 4, 5, 6, 7])
    print("Tree structure:")
    print_tree(tree1)
    print(f"\nZigzag (BFS):     {zigzagLevelOrder(tree1)}")
    print(f"Zigzag (Deque):   {zigzagLevelOrderDeque(tree1)}")
    print(f"Zigzag (DFS):     {zigzagLevelOrderDFS(tree1)}")
    print(f"Zigzag (2 Stack): {zigzagTwoStacks(tree1)}")
    print(f"Zigzag (Indexed): {zigzagLevelOrderIndexed(tree1)}")

    # Test Case 2: Empty tree
    print("\n" + "-" * 40)
    print("Test Case 2: Empty tree")
    print(f"Zigzag: {zigzagLevelOrder(None)}")

    # Test Case 3: Single node
    print("\n" + "-" * 40)
    print("Test Case 3: Single node")
    tree3 = TreeNode(1)
    print(f"Zigzag: {zigzagLevelOrder(tree3)}")

    # Test Case 4: Two levels
    print("\n" + "-" * 40)
    print("Test Case 4: Two levels")
    tree4 = build_tree([1, 2, 3])
    print("Tree structure:")
    print_tree(tree4)
    print(f"Zigzag: {zigzagLevelOrder(tree4)}")
    print("Expected: [[1], [3, 2]]")

    # Test Case 5: Left skewed tree
    print("\n" + "-" * 40)
    print("Test Case 5: Left skewed tree")
    tree5 = build_tree([1, 2, None, 3, None, 4])
    print("Tree structure:")
    print_tree(tree5)
    print(f"Zigzag: {zigzagLevelOrder(tree5)}")

    # Test Case 6: Right skewed tree
    print("\n" + "-" * 40)
    print("Test Case 6: Right skewed tree")
    tree6 = build_tree([1, None, 2, None, 3, None, 4])
    print("Tree structure:")
    print_tree(tree6)
    print(f"Zigzag: {zigzagLevelOrder(tree6)}")

    # Test Case 7: LeetCode Example
    print("\n" + "-" * 40)
    print("Test Case 7: LeetCode Example [3,9,20,null,null,15,7]")
    tree7 = build_tree([3, 9, 20, None, None, 15, 7])
    print("Tree structure:")
    print_tree(tree7)
    print(f"Zigzag: {zigzagLevelOrder(tree7)}")
    print("Expected: [[3], [20, 9], [15, 7]]")

    # Comparison of all methods
    print("\n" + "=" * 60)
    print("COMPARISON OF ALL METHODS")
    print("=" * 60)

    test_tree = build_tree([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15])
    print("\nComplete binary tree (4 levels):")
    print_tree(test_tree)
    print(f"\nBFS + Reverse: {zigzagLevelOrder(test_tree)}")
    print(f"Deque BFS:     {zigzagLevelOrderDeque(test_tree)}")
    print(f"DFS Recursive: {zigzagLevelOrderDFS(test_tree)}")
    print(f"Two Stacks:    {zigzagTwoStacks(test_tree)}")
    print(f"Index-based:   {zigzagLevelOrderIndexed(test_tree)}")

    print("\n" + "=" * 60)
    print("All tests completed!")
    print("=" * 60)
