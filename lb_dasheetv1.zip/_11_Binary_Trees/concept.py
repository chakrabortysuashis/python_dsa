"""
Binary Trees - Core Concepts and Implementations
================================================

This module provides a comprehensive implementation of binary tree operations
including all traversals, tree properties, and utility functions.
"""

from collections import deque
from typing import List, Optional


class TreeNode:
    """
    Binary Tree Node class.

    Attributes:
        val: The value stored in the node
        left: Reference to left child (None if no left child)
        right: Reference to right child (None if no right child)
    """

    def __init__(self, val: int = 0, left: 'TreeNode' = None, right: 'TreeNode' = None):
        self.val = val
        self.left = left
        self.right = right

    def __repr__(self):
        return f"TreeNode({self.val})"


# ============================================================================
# TREE CONSTRUCTION UTILITIES
# ============================================================================

def build_tree_from_list(values: List[Optional[int]]) -> Optional[TreeNode]:
    """
    Build a binary tree from a list (level-order representation).

    Args:
        values: List of values where None represents missing nodes
                Example: [1, 2, 3, None, 5] represents:
                        1
                       / \
                      2   3
                       \
                        5

    Returns:
        Root of the constructed tree

    Time: O(N), Space: O(N)
    """
    if not values or values[0] is None:
        return None

    root = TreeNode(values[0])
    queue = deque([root])
    i = 1

    while queue and i < len(values):
        node = queue.popleft()

        # Process left child
        if i < len(values) and values[i] is not None:
            node.left = TreeNode(values[i])
            queue.append(node.left)
        i += 1

        # Process right child
        if i < len(values) and values[i] is not None:
            node.right = TreeNode(values[i])
            queue.append(node.right)
        i += 1

    return root


def tree_to_list(root: Optional[TreeNode]) -> List[Optional[int]]:
    """
    Convert a binary tree to its level-order list representation.

    Time: O(N), Space: O(N)
    """
    if not root:
        return []

    result = []
    queue = deque([root])

    while queue:
        node = queue.popleft()
        if node:
            result.append(node.val)
            queue.append(node.left)
            queue.append(node.right)
        else:
            result.append(None)

    # Remove trailing Nones
    while result and result[-1] is None:
        result.pop()

    return result


# ============================================================================
# DEPTH-FIRST TRAVERSALS - RECURSIVE
# ============================================================================

def inorder_recursive(root: Optional[TreeNode]) -> List[int]:
    """
    Inorder Traversal (Left -> Root -> Right) - Recursive

    Process:
    1. Recursively traverse left subtree
    2. Visit the root
    3. Recursively traverse right subtree

    Use Case: In BST, gives sorted order

    Time: O(N) - visit each node once
    Space: O(H) - recursion stack, where H is height
           O(log N) for balanced, O(N) for skewed
    """
    result = []

    def traverse(node):
        if node is None:
            return

        traverse(node.left)      # L: Go left
        result.append(node.val)  # Root: Process current
        traverse(node.right)     # R: Go right

    traverse(root)
    return result


def preorder_recursive(root: Optional[TreeNode]) -> List[int]:
    """
    Preorder Traversal (Root -> Left -> Right) - Recursive

    Process:
    1. Visit the root
    2. Recursively traverse left subtree
    3. Recursively traverse right subtree

    Use Case: Create a copy of tree, serialize tree

    Time: O(N), Space: O(H)
    """
    result = []

    def traverse(node):
        if node is None:
            return

        result.append(node.val)  # Root: Process current first
        traverse(node.left)      # L: Go left
        traverse(node.right)     # R: Go right

    traverse(root)
    return result


def postorder_recursive(root: Optional[TreeNode]) -> List[int]:
    """
    Postorder Traversal (Left -> Right -> Root) - Recursive

    Process:
    1. Recursively traverse left subtree
    2. Recursively traverse right subtree
    3. Visit the root

    Use Case: Delete tree, calculate folder sizes

    Time: O(N), Space: O(H)
    """
    result = []

    def traverse(node):
        if node is None:
            return

        traverse(node.left)      # L: Go left
        traverse(node.right)     # R: Go right
        result.append(node.val)  # Root: Process current last

    traverse(root)
    return result


# ============================================================================
# DEPTH-FIRST TRAVERSALS - ITERATIVE
# ============================================================================

def inorder_iterative(root: Optional[TreeNode]) -> List[int]:
    """
    Inorder Traversal - Iterative using explicit stack

    Algorithm:
    1. Start from root, go left as far as possible, pushing nodes to stack
    2. Pop a node, process it
    3. Move to its right child and repeat

    Time: O(N), Space: O(H)
    """
    result = []
    stack = []
    current = root

    while stack or current:
        # Go left as far as possible
        while current:
            stack.append(current)
            current = current.left

        # Process current node
        current = stack.pop()
        result.append(current.val)

        # Move to right subtree
        current = current.right

    return result


def preorder_iterative(root: Optional[TreeNode]) -> List[int]:
    """
    Preorder Traversal - Iterative using explicit stack

    Algorithm:
    1. Push root to stack
    2. Pop a node, process it
    3. Push right child first, then left (so left is processed first)

    Time: O(N), Space: O(H)
    """
    if not root:
        return []

    result = []
    stack = [root]

    while stack:
        node = stack.pop()
        result.append(node.val)

        # Push right first so left is processed first (LIFO)
        if node.right:
            stack.append(node.right)
        if node.left:
            stack.append(node.left)

    return result


def postorder_iterative(root: Optional[TreeNode]) -> List[int]:
    """
    Postorder Traversal - Iterative using two stacks

    Algorithm:
    1. Push root to stack1
    2. Pop from stack1, push to stack2
    3. Push left and right children to stack1
    4. Stack2 will have postorder in reverse

    Alternative: Use one stack with visited flag

    Time: O(N), Space: O(N)
    """
    if not root:
        return []

    result = []
    stack1 = [root]
    stack2 = []

    while stack1:
        node = stack1.pop()
        stack2.append(node)

        # Push left first, then right
        if node.left:
            stack1.append(node.left)
        if node.right:
            stack1.append(node.right)

    # Pop from stack2 to get postorder
    while stack2:
        result.append(stack2.pop().val)

    return result


def postorder_iterative_one_stack(root: Optional[TreeNode]) -> List[int]:
    """
    Postorder Traversal - Iterative using single stack

    Uses a 'last visited' pointer to track when to process a node.

    Time: O(N), Space: O(H)
    """
    if not root:
        return []

    result = []
    stack = []
    current = root
    last_visited = None

    while stack or current:
        # Go left as far as possible
        while current:
            stack.append(current)
            current = current.left

        # Peek at top of stack
        peek_node = stack[-1]

        # If right child exists and not yet processed, move to right
        if peek_node.right and last_visited != peek_node.right:
            current = peek_node.right
        else:
            # Process this node
            result.append(peek_node.val)
            last_visited = stack.pop()

    return result


# ============================================================================
# BREADTH-FIRST TRAVERSAL
# ============================================================================

def level_order(root: Optional[TreeNode]) -> List[List[int]]:
    """
    Level Order Traversal - BFS using queue

    Returns nodes grouped by level.

    Algorithm:
    1. Add root to queue
    2. For each level, process all nodes in current queue
    3. Add their children to queue for next level

    Time: O(N), Space: O(W) where W is max width (N/2 for complete tree)
    """
    if not root:
        return []

    result = []
    queue = deque([root])

    while queue:
        level_size = len(queue)
        level_nodes = []

        for _ in range(level_size):
            node = queue.popleft()
            level_nodes.append(node.val)

            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)

        result.append(level_nodes)

    return result


def level_order_flat(root: Optional[TreeNode]) -> List[int]:
    """
    Level Order Traversal - Returns flat list instead of grouped by level.

    Time: O(N), Space: O(W)
    """
    if not root:
        return []

    result = []
    queue = deque([root])

    while queue:
        node = queue.popleft()
        result.append(node.val)

        if node.left:
            queue.append(node.left)
        if node.right:
            queue.append(node.right)

    return result


# ============================================================================
# TREE PROPERTIES
# ============================================================================

def height(root: Optional[TreeNode]) -> int:
    """
    Calculate the height of the tree.

    Height = number of edges on longest path from root to leaf
    (Some definitions count nodes instead of edges, adding 1)

    Time: O(N), Space: O(H)
    """
    if root is None:
        return -1  # Empty tree has height -1 (or 0 if counting nodes)

    left_height = height(root.left)
    right_height = height(root.right)

    return 1 + max(left_height, right_height)


def height_nodes(root: Optional[TreeNode]) -> int:
    """
    Calculate height counting nodes (alternative definition).

    Time: O(N), Space: O(H)
    """
    if root is None:
        return 0

    return 1 + max(height_nodes(root.left), height_nodes(root.right))


def count_nodes(root: Optional[TreeNode]) -> int:
    """
    Count total number of nodes in the tree.

    Time: O(N), Space: O(H)
    """
    if root is None:
        return 0

    return 1 + count_nodes(root.left) + count_nodes(root.right)


def count_leaves(root: Optional[TreeNode]) -> int:
    """
    Count number of leaf nodes.

    Time: O(N), Space: O(H)
    """
    if root is None:
        return 0

    if root.left is None and root.right is None:
        return 1

    return count_leaves(root.left) + count_leaves(root.right)


def max_depth(root: Optional[TreeNode]) -> int:
    """
    Maximum depth of the tree (same as height when counting nodes).

    Time: O(N), Space: O(H)
    """
    if root is None:
        return 0

    return 1 + max(max_depth(root.left), max_depth(root.right))


def min_depth(root: Optional[TreeNode]) -> int:
    """
    Minimum depth - shortest path from root to any leaf.

    Time: O(N), Space: O(H)
    """
    if root is None:
        return 0

    # If one child is missing, take the path with the child
    if root.left is None:
        return 1 + min_depth(root.right)
    if root.right is None:
        return 1 + min_depth(root.left)

    return 1 + min(min_depth(root.left), min_depth(root.right))


def diameter(root: Optional[TreeNode]) -> int:
    """
    Diameter of tree - longest path between any two nodes.

    The path may or may not pass through the root.

    Time: O(N), Space: O(H)
    """
    max_diameter = [0]  # Use list to allow modification in nested function

    def height_and_diameter(node):
        if node is None:
            return 0

        left_height = height_and_diameter(node.left)
        right_height = height_and_diameter(node.right)

        # Diameter through this node
        current_diameter = left_height + right_height
        max_diameter[0] = max(max_diameter[0], current_diameter)

        return 1 + max(left_height, right_height)

    height_and_diameter(root)
    return max_diameter[0]


def is_balanced(root: Optional[TreeNode]) -> bool:
    """
    Check if tree is height-balanced.

    A tree is balanced if for every node, the height difference
    between left and right subtrees is at most 1.

    Time: O(N), Space: O(H)
    """
    def check(node):
        if node is None:
            return 0

        left_height = check(node.left)
        if left_height == -1:
            return -1

        right_height = check(node.right)
        if right_height == -1:
            return -1

        if abs(left_height - right_height) > 1:
            return -1

        return 1 + max(left_height, right_height)

    return check(root) != -1


def is_symmetric(root: Optional[TreeNode]) -> bool:
    """
    Check if tree is symmetric (mirror of itself).

    Time: O(N), Space: O(H)
    """
    if root is None:
        return True

    def is_mirror(left, right):
        if left is None and right is None:
            return True
        if left is None or right is None:
            return False

        return (left.val == right.val and
                is_mirror(left.left, right.right) and
                is_mirror(left.right, right.left))

    return is_mirror(root.left, root.right)


def mirror_tree(root: Optional[TreeNode]) -> Optional[TreeNode]:
    """
    Create a mirror (inverted) copy of the tree.

    Time: O(N), Space: O(H)
    """
    if root is None:
        return None

    # Swap left and right children
    root.left, root.right = mirror_tree(root.right), mirror_tree(root.left)

    return root


def is_same_tree(p: Optional[TreeNode], q: Optional[TreeNode]) -> bool:
    """
    Check if two trees are identical.

    Time: O(N), Space: O(H)
    """
    if p is None and q is None:
        return True
    if p is None or q is None:
        return False

    return (p.val == q.val and
            is_same_tree(p.left, q.left) and
            is_same_tree(p.right, q.right))


# ============================================================================
# VISUALIZATION
# ============================================================================

def print_tree(root: Optional[TreeNode], level: int = 0, prefix: str = "Root: "):
    """
    Print tree structure visually.

    Example output:
    Root: 1
        L--- 2
            L--- 4
            R--- 5
        R--- 3
    """
    if root is not None:
        print(" " * (level * 4) + prefix + str(root.val))
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            else:
                print(" " * ((level + 1) * 4) + "L--- None")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")
            else:
                print(" " * ((level + 1) * 4) + "R--- None")


def print_tree_visual(root: Optional[TreeNode]) -> None:
    """
    Print tree in a more visual format.
    """
    def get_height(node):
        if not node:
            return 0
        return 1 + max(get_height(node.left), get_height(node.right))

    def fill_map(node, row, col, height, tree_map):
        if not node:
            return

        tree_map[row][col] = str(node.val)

        if height > 1:
            gap = 2 ** (height - 2)
            if node.left:
                tree_map[row + 1][col - gap] = '/'
                fill_map(node.left, row + 2, col - 2 * gap, height - 1, tree_map)
            if node.right:
                tree_map[row + 1][col + gap] = '\\'
                fill_map(node.right, row + 2, col + 2 * gap, height - 1, tree_map)

    if not root:
        print("Empty tree")
        return

    h = get_height(root)
    width = 2 ** (h + 1) - 1
    tree_map = [[' ' for _ in range(width)] for _ in range(2 * h - 1)]

    fill_map(root, 0, width // 2, h, tree_map)

    for row in tree_map:
        print(''.join(row).rstrip())


# ============================================================================
# TEST / DEMO
# ============================================================================

if __name__ == "__main__":
    # Create a sample tree:
    #         1
    #        / \
    #       2   3
    #      / \   \
    #     4   5   6

    root = TreeNode(1)
    root.left = TreeNode(2)
    root.right = TreeNode(3)
    root.left.left = TreeNode(4)
    root.left.right = TreeNode(5)
    root.right.right = TreeNode(6)

    print("=" * 60)
    print("BINARY TREE DEMONSTRATION")
    print("=" * 60)

    print("\nTree Structure:")
    print_tree(root)

    print("\n" + "-" * 40)
    print("TRAVERSALS")
    print("-" * 40)

    print(f"\nInorder (L-Root-R):   {inorder_recursive(root)}")
    print(f"Inorder (iterative):  {inorder_iterative(root)}")

    print(f"\nPreorder (Root-L-R):  {preorder_recursive(root)}")
    print(f"Preorder (iterative): {preorder_iterative(root)}")

    print(f"\nPostorder (L-R-Root): {postorder_recursive(root)}")
    print(f"Postorder (iterative):{postorder_iterative(root)}")

    print(f"\nLevel Order:          {level_order(root)}")
    print(f"Level Order (flat):   {level_order_flat(root)}")

    print("\n" + "-" * 40)
    print("TREE PROPERTIES")
    print("-" * 40)

    print(f"\nHeight (edges):       {height(root)}")
    print(f"Height (nodes):       {height_nodes(root)}")
    print(f"Total nodes:          {count_nodes(root)}")
    print(f"Leaf nodes:           {count_leaves(root)}")
    print(f"Diameter:             {diameter(root)}")
    print(f"Is balanced:          {is_balanced(root)}")
    print(f"Is symmetric:         {is_symmetric(root)}")

    print("\n" + "-" * 40)
    print("BUILD FROM LIST")
    print("-" * 40)

    # Build tree from list
    values = [1, 2, 3, 4, 5, None, 6]
    tree2 = build_tree_from_list(values)
    print(f"\nBuilt from: {values}")
    print("Result:")
    print_tree(tree2)
    print(f"Back to list: {tree_to_list(tree2)}")

    print("\n" + "=" * 60)
    print("End of demonstration")
    print("=" * 60)
