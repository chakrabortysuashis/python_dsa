"""
Preorder Traversal of Binary Tree
=================================

Problem: Return the preorder traversal of a binary tree's node values.
         Preorder: Node -> Left -> Right (N-L-R)

Key Property: Root is always first in preorder!

Example:
        1
       / \
      2   3
     / \
    4   5

    Preorder: [1, 2, 4, 5, 3]
"""

from collections import deque
from typing import List, Optional


class TreeNode:
    """Binary Tree Node"""
    def __init__(self, val: int = 0, left: 'TreeNode' = None, right: 'TreeNode' = None):
        self.val = val
        self.left = left
        self.right = right


# =============================================================================
# SOLUTION 1: Recursive
# =============================================================================

def preorderRecursive(root: Optional[TreeNode]) -> List[int]:
    """
    Preorder traversal using recursion.

    Order: Node -> Left -> Right

    Time Complexity: O(N)
    Space Complexity: O(H) - recursion stack

    Args:
        root: Root of binary tree

    Returns:
        List of node values in preorder sequence
    """
    result = []

    def traverse(node: Optional[TreeNode]):
        if node is None:
            return

        result.append(node.val)   # N: Visit current node FIRST
        traverse(node.left)       # L: Process left subtree
        traverse(node.right)      # R: Process right subtree

    traverse(root)
    return result


# =============================================================================
# SOLUTION 2: Iterative (Using Stack)
# =============================================================================

def preorderIterative(root: Optional[TreeNode]) -> List[int]:
    """
    Preorder traversal using explicit stack.

    Algorithm:
    1. Push root to stack
    2. Pop node, visit it
    3. Push RIGHT first, then LEFT (LIFO - left processed first)
    4. Repeat

    Time: O(N), Space: O(H)
    """
    if not root:
        return []

    result = []
    stack = [root]

    while stack:
        node = stack.pop()
        result.append(node.val)

        # Push right first so left is processed first (LIFO)
        if node.right:
            stack.append(node.right)
        if node.left:
            stack.append(node.left)

    return result


# =============================================================================
# SOLUTION 3: Morris Traversal (O(1) Space)
# =============================================================================

def preorderMorris(root: Optional[TreeNode]) -> List[int]:
    """
    Morris Preorder Traversal - O(1) extra space!

    Similar to Morris Inorder, but visit node when
    creating the thread (BEFORE going left).

    Time: O(N), Space: O(1)
    """
    result = []
    current = root

    while current:
        if current.left is None:
            # No left child - visit and move right
            result.append(current.val)
            current = current.right
        else:
            # Find predecessor
            predecessor = current.left
            while predecessor.right and predecessor.right != current:
                predecessor = predecessor.right

            if predecessor.right is None:
                # First visit - visit NOW, create thread, go left
                result.append(current.val)  # Visit BEFORE going left!
                predecessor.right = current
                current = current.left
            else:
                # Returning - just remove thread, go right
                predecessor.right = None
                current = current.right

    return result


# =============================================================================
# SOLUTION 4: Generator (Lazy Evaluation)
# =============================================================================

def preorderGenerator(root: Optional[TreeNode]):
    """Preorder traversal as a generator."""
    if root is None:
        return

    yield root.val
    yield from preorderGenerator(root.left)
    yield from preorderGenerator(root.right)


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def build_tree(values: List[Optional[int]]) -> Optional[TreeNode]:
    """Build binary tree from level-order list."""
    if not values or values[0] is None:
        return None

    root = TreeNode(values[0])
    queue = deque([root])
    i = 1

    while queue and i < len(values):
        node = queue.popleft()

        if i < len(values) and values[i] is not None:
            node.left = TreeNode(values[i])
            queue.append(node.left)
        i += 1

        if i < len(values) and values[i] is not None:
            node.right = TreeNode(values[i])
            queue.append(node.right)
        i += 1

    return root


def print_tree(root: Optional[TreeNode], level: int = 0, prefix: str = "Root: "):
    """Print tree structure."""
    if root is not None:
        print(" " * (level * 4) + prefix + str(root.val))
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("PREORDER TRAVERSAL - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal tree
    print("\nTest Case 1: Normal binary tree")
    print("-" * 40)
    tree1 = build_tree([1, 2, 3, 4, 5])
    print("Tree structure:")
    print_tree(tree1)
    print(f"\nRecursive:  {preorderRecursive(tree1)}")
    print(f"Iterative:  {preorderIterative(tree1)}")
    print(f"Morris:     {preorderMorris(tree1)}")
    print(f"Generator:  {list(preorderGenerator(tree1))}")

    # Test Case 2: Empty tree
    print("\n" + "-" * 40)
    print("Test Case 2: Empty tree")
    print(f"Preorder: {preorderRecursive(None)}")

    # Test Case 3: Single node
    print("\n" + "-" * 40)
    print("Test Case 3: Single node")
    tree3 = TreeNode(1)
    print(f"Preorder: {preorderRecursive(tree3)}")

    # Test Case 4: Left skewed tree
    print("\n" + "-" * 40)
    print("Test Case 4: Left skewed tree")
    tree4 = build_tree([1, 2, None, 3, None, 4])
    print("Tree structure:")
    print_tree(tree4)
    print(f"Preorder: {preorderRecursive(tree4)}")

    # Test Case 5: Right skewed tree
    print("\n" + "-" * 40)
    print("Test Case 5: Right skewed tree")
    tree5 = build_tree([1, None, 2, None, 3, None, 4])
    print("Tree structure:")
    print_tree(tree5)
    print(f"Preorder: {preorderRecursive(tree5)}")

    # Comparison of traversals
    print("\n" + "=" * 60)
    print("COMPARISON: INORDER vs PREORDER vs POSTORDER")
    print("=" * 60)

    def inorder(root):
        if not root: return []
        return inorder(root.left) + [root.val] + inorder(root.right)

    def postorder(root):
        if not root: return []
        return postorder(root.left) + postorder(root.right) + [root.val]

    test_tree = build_tree([1, 2, 3, 4, 5, 6, 7])
    print("\nTest tree:")
    print_tree(test_tree)
    print(f"\nInorder (L-N-R):   {inorder(test_tree)}")
    print(f"Preorder (N-L-R):  {preorderRecursive(test_tree)}")
    print(f"Postorder (L-R-N): {postorder(test_tree)}")

    print("\n" + "=" * 60)
    print("All tests completed!")
    print("=" * 60)
