# Preorder Traversal of Binary Tree

## Problem Statement

Given a binary tree, return the **preorder traversal** of its nodes' values.

**Preorder:** Root -> Left -> Right (N-L-R)

## Example

```
Input:
        1
       / \
      2   3
     / \
    4   5

Output: [1, 2, 4, 5, 3]

Traversal: Visit root first, then left subtree, then right subtree
```

## Tree Visualization

```
        1           <- Visit 1 first (Root)
       / \
      2   3         <- Then entire left subtree (2,4,5), then right (3)
     / \
    4   5

Preorder process:
1. Visit root (1)
2. Go to left subtree, visit root (2)
3. Go to left subtree, visit root (4)
4. Back up, visit right (5)
5. Back up to root, visit right subtree (3)

Result: 1 -> 2 -> 4 -> 5 -> 3
```

---

## Key Property

**Preorder is used to create a copy of the tree or serialize it.**

The first element is always the root!

```
Preorder: [1, 2, 4, 5, 3]
           ^
           Root is first!
```

---

## Approach 1: Recursive

### Algorithm

```
preorder(node):
    if node is None:
        return
    
    visit(node)           # N: Process current node FIRST
    preorder(node.left)   # L: Process left subtree
    preorder(node.right)  # R: Process right subtree
```

### Recursion Tree

```
Tree:
        1
       / \
      2   3

preorder(1)
    |
    +-- visit(1)  -> Output: [1]
    |
    +-- preorder(2)
    |       |
    |       +-- visit(2)  -> Output: [1, 2]
    |       +-- preorder(4) -> visit(4)  -> Output: [1, 2, 4]
    |       +-- preorder(5) -> visit(5)  -> Output: [1, 2, 4, 5]
    |
    +-- preorder(3)
            |
            +-- visit(3)  -> Output: [1, 2, 4, 5, 3]

Final: [1, 2, 4, 5, 3]
```

### Code

```python
def preorderRecursive(root):
    """
    Time: O(N), Space: O(H)
    """
    result = []
    
    def traverse(node):
        if node is None:
            return
        
        result.append(node.val)   # N: Visit first
        traverse(node.left)       # L
        traverse(node.right)      # R
    
    traverse(root)
    return result
```

---

## Approach 2: Iterative (Using Stack)

### Key Insight

Use a stack. Push right child first, then left child (so left is processed first due to LIFO).

### Algorithm

```
1. Push root to stack
2. While stack not empty:
   a. Pop node, visit it
   b. Push right child (if exists)
   c. Push left child (if exists)
3. Return result
```

### Step-by-Step Visualization

```
Tree:
        1
       / \
      2   3
     / \
    4   5

Step 1: Push root
        Stack: [1]

Step 2: Pop 1, visit 1, push right(3), push left(2)
        Stack: [3, 2], Result: [1]

Step 3: Pop 2, visit 2, push right(5), push left(4)
        Stack: [3, 5, 4], Result: [1, 2]

Step 4: Pop 4, visit 4, no children
        Stack: [3, 5], Result: [1, 2, 4]

Step 5: Pop 5, visit 5, no children
        Stack: [3], Result: [1, 2, 4, 5]

Step 6: Pop 3, visit 3, no children
        Stack: [], Result: [1, 2, 4, 5, 3]

Done!
```

### Code

```python
def preorderIterative(root):
    """
    Time: O(N), Space: O(H)
    """
    if not root:
        return []
    
    result = []
    stack = [root]
    
    while stack:
        node = stack.pop()
        result.append(node.val)
        
        # Push right first, then left (LIFO - left processed first)
        if node.right:
            stack.append(node.right)
        if node.left:
            stack.append(node.left)
    
    return result
```

---

## Approach 3: Morris Traversal (O(1) Space)

### Code

```python
def preorderMorris(root):
    """
    Morris Preorder - O(1) space
    
    Similar to Morris Inorder, but visit node when
    creating the thread (not when returning).
    """
    result = []
    current = root
    
    while current:
        if current.left is None:
            result.append(current.val)
            current = current.right
        else:
            predecessor = current.left
            while predecessor.right and predecessor.right != current:
                predecessor = predecessor.right
            
            if predecessor.right is None:
                result.append(current.val)  # Visit BEFORE going left
                predecessor.right = current
                current = current.left
            else:
                predecessor.right = None
                current = current.right
    
    return result
```

---

## Complexity Analysis

| Approach | Time | Space |
|----------|------|-------|
| Recursive | O(N) | O(H) |
| Iterative | O(N) | O(H) |
| Morris | O(N) | O(1) |

---

## Comparison: Inorder vs Preorder vs Postorder

```
Tree:
        1
       / \
      2   3

Inorder (L-N-R):   [2, 1, 3]  - Visit node in MIDDLE
Preorder (N-L-R):  [1, 2, 3]  - Visit node FIRST (PRE)
Postorder (L-R-N): [2, 3, 1]  - Visit node LAST (POST)
```

---

## Memory Aid

```
PREorder = PRE = Before = Visit FIRST
           Node - Left - Right
           
Think: "Visit node BEFORE going to children"
```

---

## Edge Cases

| Case | Input | Output |
|------|-------|--------|
| Empty tree | `None` | `[]` |
| Single node | `[1]` | `[1]` |
| Left skewed | `1->2->3` | `[1, 2, 3]` |
| Right skewed | `1->2->3` | `[1, 2, 3]` |

---

## Use Cases

1. **Copy a tree** - Preorder visits root first, perfect for reconstruction
2. **Serialize tree** - First element is root
3. **Expression trees** - Preorder gives prefix notation
4. **Directory listing** - Print folder before contents

---

## Key Takeaways

1. **Preorder: N -> L -> R** (Node, Left, Right)
2. **Root is always first** in preorder
3. **Iterative:** Push right first, then left
4. **Used for:** Tree copy, serialization, prefix expressions

---

## Related Problems

- Binary Tree Preorder Traversal (LeetCode 144)
- Construct Binary Tree from Preorder and Inorder
- Verify Preorder Sequence in BST
- Flatten Binary Tree to Linked List
