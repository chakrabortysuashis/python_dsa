# Level Order Traversal of Binary Tree

## Problem Statement

Given a binary tree, return the **level order traversal** of its nodes' values. (i.e., from left to right, level by level).

**Also known as:** Breadth-First Search (BFS) Traversal

## Example

```
Input:
        1
       / \
      2   3
     / \   \
    4   5   6

Output: [[1], [2, 3], [4, 5, 6]]
Flat output: [1, 2, 3, 4, 5, 6]
```

## Tree Visualization

```
Level 0:        1           <- Start here (root)
               / \
Level 1:      2   3         <- Process all nodes at this level
             / \   \
Level 2:    4   5   6       <- Then this level

Traversal Order: 1 -> 2 -> 3 -> 4 -> 5 -> 6
```

---

## Intuition

Unlike DFS which goes deep first, **BFS explores all neighbors before moving to the next level**. We use a **Queue** (FIFO) to achieve this:

1. Start with root in queue
2. Process all nodes at current level
3. Add their children to queue for next level
4. Repeat until queue is empty

**Why Queue?**
- Queue maintains FIFO (First In, First Out) order
- Nodes added first (current level) are processed first
- Children (next level) wait in queue

---

## Approach: BFS using Queue

### Algorithm

```
1. If root is null, return empty list
2. Create a queue and add root
3. While queue is not empty:
   a. Get current level size (nodes in queue)
   b. Process all nodes at current level:
      - Dequeue node
      - Add its value to result
      - Enqueue left child (if exists)
      - Enqueue right child (if exists)
4. Return result
```

### Step-by-Step Dry Run

```
Tree:
        1
       / \
      2   3
     / \
    4   5

Initial: Queue = [1], Result = []

--- Level 0 (size = 1) ---
  Dequeue 1
  Add children: Queue = [2, 3]
  Result = [[1]]

--- Level 1 (size = 2) ---
  Dequeue 2
  Add children: Queue = [3, 4, 5]
  
  Dequeue 3
  Add children: Queue = [4, 5] (3 has no children)
  Result = [[1], [2, 3]]

--- Level 2 (size = 2) ---
  Dequeue 4 (no children)
  Dequeue 5 (no children)
  Queue = []
  Result = [[1], [2, 3], [4, 5]]

Queue empty -> Done!
Final Result: [[1], [2, 3], [4, 5]]
```

### Queue State Visualization

```
Step 0: [1]           <- Initial
        ^
        
Step 1: [2, 3]        <- After processing level 0
         ^
         
Step 2: [3, 4, 5]     <- After dequeuing 2, adding its children
            ^
            
Step 3: [4, 5]        <- After dequeuing 3
         ^
         
Step 4: [5]           <- After dequeuing 4
         ^
         
Step 5: []            <- After dequeuing 5, Done!
```

---

## Code Implementation

### Python Solution

```python
from collections import deque
from typing import List, Optional

class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def levelOrder(root: Optional[TreeNode]) -> List[List[int]]:
    """
    Level Order Traversal using BFS
    
    Time: O(N) - visit each node once
    Space: O(W) - max width of tree (queue size)
    """
    if not root:
        return []
    
    result = []
    queue = deque([root])
    
    while queue:
        level_size = len(queue)  # Nodes at current level
        level_nodes = []
        
        for _ in range(level_size):
            node = queue.popleft()
            level_nodes.append(node.val)
            
            # Add children for next level
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
        
        result.append(level_nodes)
    
    return result
```

### Why `level_size = len(queue)`?

This is the **key insight**! At the start of each level:
- Queue contains exactly all nodes of that level
- We save this count before processing
- This lets us know when current level ends and next begins

```
Level 1: Queue = [2, 3]
         level_size = 2
         
         Process 2 -> Queue = [3, 4, 5]  (size changed but we process only 2)
         Process 3 -> Queue = [4, 5]
         
Level 2: Queue = [4, 5]
         level_size = 2 (fresh count)
```

---

## Alternative: Flat Level Order (Without Grouping)

```python
def levelOrderFlat(root: Optional[TreeNode]) -> List[int]:
    """
    Returns flat list without level grouping
    """
    if not root:
        return []
    
    result = []
    queue = deque([root])
    
    while queue:
        node = queue.popleft()
        result.append(node.val)
        
        if node.left:
            queue.append(node.left)
        if node.right:
            queue.append(node.right)
    
    return result
```

---

## Complexity Analysis

### Time Complexity: O(N)

- We visit each node exactly once
- Each node is enqueued and dequeued once
- Total operations: O(N)

### Space Complexity: O(W)

- W = maximum width of tree
- For a **complete binary tree**: W = N/2 (last level)
- For a **skewed tree**: W = 1
- Result array: O(N) additional space

```
Complete tree (worst case for width):
        1
       / \
      2   3
     /\ /\
    4 5 6 7
    
Max queue size = 4 (N/2)
Space = O(N)
```

---

## Common Variations

### 1. Level Order with Level Numbers

```python
def levelOrderWithNumbers(root):
    if not root:
        return []
    
    result = []
    queue = deque([(root, 0)])  # (node, level)
    
    while queue:
        node, level = queue.popleft()
        
        if level >= len(result):
            result.append([])
        result[level].append(node.val)
        
        if node.left:
            queue.append((node.left, level + 1))
        if node.right:
            queue.append((node.right, level + 1))
    
    return result
```

### 2. Level Order using Recursion (DFS)

```python
def levelOrderDFS(root):
    result = []
    
    def dfs(node, level):
        if not node:
            return
        
        if level >= len(result):
            result.append([])
        
        result[level].append(node.val)
        dfs(node.left, level + 1)
        dfs(node.right, level + 1)
    
    dfs(root, 0)
    return result
```

---

## Edge Cases

| Case | Input | Output |
|------|-------|--------|
| Empty tree | `None` | `[]` |
| Single node | `[1]` | `[[1]]` |
| Left skewed | `[1,2,null,3]` | `[[1],[2],[3]]` |
| Right skewed | `[1,null,2,null,3]` | `[[1],[2],[3]]` |

---

## Key Takeaways

1. **Use Queue for BFS** - FIFO ensures level-by-level processing
2. **Track level size** - `len(queue)` at start of each level
3. **Time O(N), Space O(W)** - Visit each node once, queue holds one level
4. **Foundation for many problems** - Zigzag, reverse level order, views, etc.

---

## Related Problems

- Reverse Level Order Traversal
- Zigzag Level Order Traversal
- Level Order Traversal II (bottom-up)
- Binary Tree Right Side View
- Average of Levels in Binary Tree
