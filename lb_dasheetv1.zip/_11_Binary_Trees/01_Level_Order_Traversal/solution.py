"""
Level Order Traversal of Binary Tree
====================================

Problem: Given a binary tree, return the level order traversal of its nodes' values.
         (i.e., from left to right, level by level)

Example:
    Input:        1
                 / \
                2   3
               / \   \
              4   5   6

    Output: [[1], [2, 3], [4, 5, 6]]
"""

from collections import deque
from typing import List, Optional


class TreeNode:
    """Binary Tree Node"""
    def __init__(self, val: int = 0, left: 'TreeNode' = None, right: 'TreeNode' = None):
        self.val = val
        self.left = left
        self.right = right

    def __repr__(self):
        return f"TreeNode({self.val})"


# =============================================================================
# SOLUTION 1: BFS using Queue (Standard Approach)
# =============================================================================

def levelOrder(root: Optional[TreeNode]) -> List[List[int]]:
    """
    Level Order Traversal using BFS with Queue.

    Algorithm:
    1. Start with root in queue
    2. For each level:
       - Count nodes in queue (level_size)
       - Process exactly level_size nodes
       - Add their children for next level

    Time Complexity: O(N) - visit each node once
    Space Complexity: O(W) - W is max width of tree
                      For complete tree: O(N/2) = O(N)

    Args:
        root: Root of binary tree

    Returns:
        List of lists, where each inner list contains values at that level
    """
    # Edge case: empty tree
    if not root:
        return []

    result = []
    queue = deque([root])

    while queue:
        # Number of nodes at current level
        level_size = len(queue)
        level_nodes = []

        # Process all nodes at current level
        for _ in range(level_size):
            node = queue.popleft()
            level_nodes.append(node.val)

            # Add children for next level (left first, then right)
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)

        result.append(level_nodes)

    return result


# =============================================================================
# SOLUTION 2: BFS - Flat Output (No Level Grouping)
# =============================================================================

def levelOrderFlat(root: Optional[TreeNode]) -> List[int]:
    """
    Level Order Traversal returning flat list.

    Time: O(N), Space: O(W)
    """
    if not root:
        return []

    result = []
    queue = deque([root])

    while queue:
        node = queue.popleft()
        result.append(node.val)

        if node.left:
            queue.append(node.left)
        if node.right:
            queue.append(node.right)

    return result


# =============================================================================
# SOLUTION 3: DFS Recursive Approach
# =============================================================================

def levelOrderDFS(root: Optional[TreeNode]) -> List[List[int]]:
    """
    Level Order using DFS (recursive).

    Instead of BFS, we use DFS and track the level number.
    When we reach a node, we add it to the appropriate level in result.

    Time: O(N), Space: O(H) for recursion stack
    """
    result = []

    def dfs(node: Optional[TreeNode], level: int):
        if not node:
            return

        # If this level doesn't exist in result, create it
        if level >= len(result):
            result.append([])

        # Add current node to its level
        result[level].append(node.val)

        # Recurse: left first, then right (maintains left-to-right order)
        dfs(node.left, level + 1)
        dfs(node.right, level + 1)

    dfs(root, 0)
    return result


# =============================================================================
# SOLUTION 4: BFS with Level Numbers (Alternative)
# =============================================================================

def levelOrderWithNumbers(root: Optional[TreeNode]) -> List[List[int]]:
    """
    Level Order with explicit level tracking in queue.

    Each queue element is (node, level) tuple.
    """
    if not root:
        return []

    result = []
    queue = deque([(root, 0)])  # (node, level)

    while queue:
        node, level = queue.popleft()

        # Create new level list if needed
        if level >= len(result):
            result.append([])

        result[level].append(node.val)

        if node.left:
            queue.append((node.left, level + 1))
        if node.right:
            queue.append((node.right, level + 1))

    return result


# =============================================================================
# HELPER: Build tree from list
# =============================================================================

def build_tree(values: List[Optional[int]]) -> Optional[TreeNode]:
    """
    Build binary tree from level-order list representation.
    None represents missing nodes.

    Example: [1, 2, 3, None, 5] creates:
            1
           / \
          2   3
           \
            5
    """
    if not values or values[0] is None:
        return None

    root = TreeNode(values[0])
    queue = deque([root])
    i = 1

    while queue and i < len(values):
        node = queue.popleft()

        # Left child
        if i < len(values) and values[i] is not None:
            node.left = TreeNode(values[i])
            queue.append(node.left)
        i += 1

        # Right child
        if i < len(values) and values[i] is not None:
            node.right = TreeNode(values[i])
            queue.append(node.right)
        i += 1

    return root


def print_tree(root: Optional[TreeNode], level: int = 0, prefix: str = "Root: "):
    """Print tree structure for visualization"""
    if root is not None:
        print(" " * (level * 4) + prefix + str(root.val))
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("LEVEL ORDER TRAVERSAL - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal tree
    print("\nTest Case 1: Normal binary tree")
    print("-" * 40)
    tree1 = build_tree([1, 2, 3, 4, 5, None, 6])
    print("Tree structure:")
    print_tree(tree1)
    print(f"\nBFS Level Order: {levelOrder(tree1)}")
    print(f"Flat Level Order: {levelOrderFlat(tree1)}")
    print(f"DFS Level Order: {levelOrderDFS(tree1)}")

    # Test Case 2: Empty tree
    print("\n" + "-" * 40)
    print("Test Case 2: Empty tree")
    print(f"Level Order: {levelOrder(None)}")

    # Test Case 3: Single node
    print("\n" + "-" * 40)
    print("Test Case 3: Single node")
    tree3 = TreeNode(1)
    print(f"Level Order: {levelOrder(tree3)}")

    # Test Case 4: Left skewed tree
    print("\n" + "-" * 40)
    print("Test Case 4: Left skewed tree")
    tree4 = build_tree([1, 2, None, 3, None, 4])
    print("Tree structure:")
    print_tree(tree4)
    print(f"Level Order: {levelOrder(tree4)}")

    # Test Case 5: Right skewed tree
    print("\n" + "-" * 40)
    print("Test Case 5: Right skewed tree")
    tree5 = build_tree([1, None, 2, None, 3, None, 4])
    print("Tree structure:")
    print_tree(tree5)
    print(f"Level Order: {levelOrder(tree5)}")

    # Test Case 6: Complete binary tree
    print("\n" + "-" * 40)
    print("Test Case 6: Complete binary tree")
    tree6 = build_tree([1, 2, 3, 4, 5, 6, 7])
    print("Tree structure:")
    print_tree(tree6)
    print(f"Level Order: {levelOrder(tree6)}")

    # Comparison of all methods
    print("\n" + "=" * 60)
    print("COMPARISON OF ALL METHODS")
    print("=" * 60)
    test_tree = build_tree([1, 2, 3, 4, 5, 6, 7, 8, 9])
    print("\nTest tree:")
    print_tree(test_tree)
    print(f"\nBFS (Standard):      {levelOrder(test_tree)}")
    print(f"DFS (Recursive):     {levelOrderDFS(test_tree)}")
    print(f"With Level Numbers:  {levelOrderWithNumbers(test_tree)}")
    print(f"Flat Output:         {levelOrderFlat(test_tree)}")

    print("\n" + "=" * 60)
    print("All tests completed!")
    print("=" * 60)
