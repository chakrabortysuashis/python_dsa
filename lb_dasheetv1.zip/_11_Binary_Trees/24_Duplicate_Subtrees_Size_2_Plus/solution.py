"""
Find Duplicate Subtrees of Size 2 or More
==========================================
"""

from collections import defaultdict, deque
from typing import List, Optional


class TreeNode:
    def __init__(self, val: int = 0, left: 'TreeNode' = None, right: 'TreeNode' = None):
        self.val = val
        self.left = left
        self.right = right


def findDuplicateSubtrees(root: Optional[TreeNode]) -> List[TreeNode]:
    """
    Find all duplicate subtrees with size >= 2.

    Serialize each subtree and count occurrences.
    """
    count = defaultdict(int)
    result = []

    def serialize(node: Optional[TreeNode]) -> str:
        if not node:
            return "#"

        # Serialize current subtree
        serial = f"{node.val},{serialize(node.left)},{serialize(node.right)}"

        count[serial] += 1

        # If seen exactly twice and has at least 2 nodes
        # (size >= 2 means at least 2 commas before #,#)
        if count[serial] == 2:
            # Count actual nodes (non-# elements)
            nodes = [x for x in serial.split(',') if x != '#']
            if len(nodes) >= 2:
                result.append(node)

        return serial

    serialize(root)
    return result


def getSubtreeSize(node: Optional[TreeNode]) -> int:
    """Get size of subtree."""
    if not node:
        return 0
    return 1 + getSubtreeSize(node.left) + getSubtreeSize(node.right)


def build_tree(values: List[Optional[int]]) -> Optional[TreeNode]:
    if not values or values[0] is None:
        return None
    root = TreeNode(values[0])
    queue = deque([root])
    i = 1
    while queue and i < len(values):
        node = queue.popleft()
        if i < len(values) and values[i] is not None:
            node.left = TreeNode(values[i])
            queue.append(node.left)
        i += 1
        if i < len(values) and values[i] is not None:
            node.right = TreeNode(values[i])
            queue.append(node.right)
        i += 1
    return root


if __name__ == "__main__":
    print("DUPLICATE SUBTREES SIZE 2+ - TEST CASES")
    print("=" * 40)

    # Build tree with duplicate subtrees
    root = TreeNode(1)
    root.left = TreeNode(2)
    root.left.left = TreeNode(4)
    root.right = TreeNode(3)
    root.right.left = TreeNode(2)
    root.right.left.left = TreeNode(4)
    root.right.right = TreeNode(4)

    duplicates = findDuplicateSubtrees(root)
    print(f"Found {len(duplicates)} duplicate subtrees of size >= 2")
    for node in duplicates:
        print(f"  Root value: {node.val}, size: {getSubtreeSize(node)}")

    print("=" * 40)
