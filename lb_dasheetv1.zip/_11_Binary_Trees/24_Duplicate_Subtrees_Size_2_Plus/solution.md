# Find Duplicate Subtrees of Size 2 or More

## Problem Statement

Find all duplicate subtrees in a binary tree where the subtree has at least 2 nodes.

## Example

```
        1
       / \
      2   3
     /   / \
    4   2   4
       /
      4

Duplicate subtrees:
-   2     (appears twice)
   /
  4
```

---

## Intuition

**Serialize each subtree** and use a hashmap to count occurrences.
- Subtree serialization creates unique string for each structure
- Same serialization = duplicate subtree

---

## Code

```python
def findDuplicateSubtrees(root):
    count = {}
    result = []
    
    def serialize(node):
        if not node:
            return "#"
        
        # Post-order: left, right, then current
        serial = f"{node.val},{serialize(node.left)},{serialize(node.right)}"
        
        count[serial] = count.get(serial, 0) + 1
        
        # Check size >= 2 and first duplicate
        if count[serial] == 2 and serial.count(',') >= 2:
            result.append(node)
        
        return serial
    
    serialize(root)
    return result
```

---

## Recursion Tree

```
serialize(1)
    |
    +-- serialize(2)
    |       +-- serialize(4) -> "4,#,#"
    |       +-- serialize(None) -> "#"
    |       return "2,4,#,#,#"
    |
    +-- serialize(3)
            +-- serialize(2)
            |       +-- serialize(4) -> "4,#,#"
            |       return "2,4,#,#,#"  <- DUPLICATE!
            +-- serialize(4) -> "4,#,#"
            return "3,2,4,#,#,#,4,#,#"

Duplicate found: "2,4,#,#,#"
```

---

## Complexity

| Time | Space |
|------|-------|
| O(N^2) | O(N^2) for serializations |
