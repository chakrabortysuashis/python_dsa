# Boundary Traversal of Binary Tree

## Problem Statement

Given a binary tree, return the **boundary traversal** in anti-clockwise direction starting from root.

**Boundary includes:**
1. Left boundary (excluding leaves)
2. All leaf nodes (left to right)
3. Right boundary (excluding leaves, in reverse)

## Example

```
Input:
        1
       / \
      2   3
     / \   \
    4   5   6
       / \
      7   8

Output: [1, 2, 4, 7, 8, 6, 3]

Breakdown:
- Left boundary:  [1, 2]
- Leaves:         [4, 7, 8, 6]
- Right boundary: [3] (reversed)
```

---

## Visualization

```
Boundary Traversal (Anti-clockwise):

        1  -----> Start here
       /|\
      2 | 3      Left boundary: 1 -> 2
     /| |  \     (not 4, it's a leaf)
    4 | |   6
      | 5   |
     /| |\  |
    7 | | 8 |    Leaves (L to R): 4, 7, 8, 6
      | |   |
      v v   v
      
Right boundary (bottom-up): 3 (6 is leaf)

Result: [1, 2, 4, 7, 8, 6, 3]
```

---

## Intuition: Three Parts

**Part 1: Left Boundary (Top to Bottom)**
- Start from root, go left
- If no left child, go right
- Stop before reaching a leaf

**Part 2: Leaves (Left to Right)**
- All leaf nodes in order
- Can use any traversal (preorder works)

**Part 3: Right Boundary (Bottom to Top)**
- Start from root, go right
- If no right child, go left
- Collect in reverse order (use stack)
- Stop before reaching a leaf

---

## Approach 1: Three Separate Traversals

### Algorithm

```
1. Add root (if not a leaf)
2. Collect left boundary (excluding leaves)
3. Collect all leaves (left to right)
4. Collect right boundary in reverse (excluding leaves)
```

### Recursion Tree

```
For tree:
        1
       / \
      2   3
     / \
    4   5

getLeftBoundary(1):
    add 1
    getLeftBoundary(2):
        add 2
        getLeftBoundary(4): STOP (leaf!)

getLeaves(1):
    getLeaves(2):
        getLeaves(4): add 4 (leaf)
        getLeaves(5): add 5 (leaf)
    getLeaves(3): add 3 (leaf)

getRightBoundary(1):
    getRightBoundary(3): STOP (leaf)
    (nothing to add)

Result: [1, 2, 4, 5, 3]
```

### Code

```python
def boundaryTraversal(root):
    if not root:
        return []
    
    result = []
    
    # Add root if not leaf
    if not isLeaf(root):
        result.append(root.val)
    
    # Left boundary
    addLeftBoundary(root.left, result)
    
    # Leaves
    addLeaves(root, result)
    
    # Right boundary (reverse)
    addRightBoundary(root.right, result)
    
    return result

def isLeaf(node):
    return node and not node.left and not node.right

def addLeftBoundary(node, result):
    while node:
        if not isLeaf(node):
            result.append(node.val)
        if node.left:
            node = node.left
        else:
            node = node.right

def addLeaves(node, result):
    if not node:
        return
    if isLeaf(node):
        result.append(node.val)
        return
    addLeaves(node.left, result)
    addLeaves(node.right, result)

def addRightBoundary(node, result):
    stack = []
    while node:
        if not isLeaf(node):
            stack.append(node.val)
        if node.right:
            node = node.right
        else:
            node = node.left
    
    while stack:
        result.append(stack.pop())
```

### Dry Run

```
Tree:
        1
       / \
      2   3
     /     \
    4       5

Step 1: Root (not leaf) -> result = [1]

Step 2: Left boundary starting from node 2
  - Node 2 (not leaf): result = [1, 2]
  - Node 4 (LEAF): stop
  result = [1, 2]

Step 3: Leaves (preorder)
  - Node 4 (leaf): result = [1, 2, 4]
  - Node 5 (leaf): result = [1, 2, 4, 5]

Step 4: Right boundary starting from node 3
  - Node 3 (not leaf): stack = [3]
  - Node 5 (LEAF): stop
  - Pop stack: result = [1, 2, 4, 5, 3]

Final: [1, 2, 4, 5, 3]
```

---

## Approach 2: Single Traversal with Flags

### Code

```python
def boundaryTraversalSinglePass(root):
    if not root:
        return []
    
    result = []
    
    def traverse(node, is_left_boundary, is_right_boundary):
        if not node:
            return
        
        # Add to result if:
        # 1. Left boundary node (before leaves), OR
        # 2. Leaf node
        if is_left_boundary or isLeaf(node):
            result.append(node.val)
        
        # Traverse left subtree
        if node.left:
            traverse(node.left, 
                    is_left_boundary, 
                    is_right_boundary and not node.right)
        
        # Traverse right subtree
        if node.right:
            traverse(node.right,
                    is_left_boundary and not node.left,
                    is_right_boundary)
        
        # Add right boundary AFTER children (reverse order)
        if is_right_boundary and not isLeaf(node) and not is_left_boundary:
            result.append(node.val)
    
    traverse(root, True, True)
    return result
```

---

## Complexity Analysis

| Approach | Time | Space |
|----------|------|-------|
| Three Traversals | O(N) | O(H) for recursion |
| Single Pass | O(N) | O(H) for recursion |

**Note:** Each node is visited exactly once.

---

## Edge Cases

| Case | Input | Output |
|------|-------|--------|
| Empty tree | `None` | `[]` |
| Single node | `[1]` | `[1]` |
| Only left children | `1->2->3` | `[1, 2, 3]` |
| Only right children | `1->2->3` | `[1, 2, 3]` |
| Complete tree | 7 nodes | Full boundary |

---

## Special Cases Visualization

```
Case: Left skewed
    1
   /
  2
 /
3

Boundary: [1, 2, 3]
- Left boundary: [1, 2]
- Leaves: [3]
- Right boundary: []

Case: Right skewed
1
 \
  2
   \
    3

Boundary: [1, 3, 2]
- Left boundary: []
- Leaves: [3]
- Right boundary: [2] (reversed)
```

---

## Key Takeaways

1. **Three parts:** Left boundary, leaves, right boundary (reversed)
2. **Exclude leaves from boundaries:** They're added separately
3. **Order matters:** Anti-clockwise from root
4. **Right boundary reversed:** Use stack or recursion trick
5. **Edge case:** Single node is both root and leaf

---

## Related Problems

- Binary Tree Right Side View (LeetCode 199)
- Binary Tree Left Side View
- Leaf-Similar Trees (LeetCode 872)
- Sum of Left Leaves (LeetCode 404)
