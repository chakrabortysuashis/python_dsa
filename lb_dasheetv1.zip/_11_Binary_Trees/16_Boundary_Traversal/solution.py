"""
Boundary Traversal of Binary Tree
=================================

Problem: Return the boundary of a binary tree in anti-clockwise direction.

Boundary consists of:
1. Left boundary (excluding leaves)
2. All leaf nodes (left to right)
3. Right boundary in reverse (excluding leaves)

Example:
        1
       / \
      2   3
     / \   \
    4   5   6

Output: [1, 2, 4, 5, 6, 3]
"""

from collections import deque
from typing import List, Optional


class TreeNode:
    """Binary Tree Node"""
    def __init__(self, val: int = 0, left: 'TreeNode' = None, right: 'TreeNode' = None):
        self.val = val
        self.left = left
        self.right = right


# =============================================================================
# SOLUTION 1: Three Separate Traversals
# =============================================================================

def boundaryTraversal(root: Optional[TreeNode]) -> List[int]:
    """
    Boundary traversal using three separate traversals.

    1. Left boundary (top to bottom, excluding leaves)
    2. Leaves (left to right)
    3. Right boundary (bottom to top, excluding leaves)

    Time Complexity: O(N)
    Space Complexity: O(H) for recursion

    Args:
        root: Root of binary tree

    Returns:
        Boundary traversal list
    """
    if not root:
        return []

    def isLeaf(node: TreeNode) -> bool:
        return node and not node.left and not node.right

    def addLeftBoundary(node: Optional[TreeNode], result: List[int]) -> None:
        """Add left boundary nodes (excluding leaves)"""
        curr = node
        while curr:
            if not isLeaf(curr):
                result.append(curr.val)
            # Prefer left, else right
            if curr.left:
                curr = curr.left
            else:
                curr = curr.right

    def addLeaves(node: Optional[TreeNode], result: List[int]) -> None:
        """Add all leaf nodes (preorder traversal)"""
        if not node:
            return
        if isLeaf(node):
            result.append(node.val)
            return
        addLeaves(node.left, result)
        addLeaves(node.right, result)

    def addRightBoundary(node: Optional[TreeNode], result: List[int]) -> None:
        """Add right boundary nodes in reverse (excluding leaves)"""
        stack = []
        curr = node
        while curr:
            if not isLeaf(curr):
                stack.append(curr.val)
            # Prefer right, else left
            if curr.right:
                curr = curr.right
            else:
                curr = curr.left

        # Add in reverse order
        while stack:
            result.append(stack.pop())

    result = []

    # Add root if not a leaf
    if not isLeaf(root):
        result.append(root.val)

    # Add left boundary (starting from left child)
    addLeftBoundary(root.left, result)

    # Add all leaves
    addLeaves(root, result)

    # Add right boundary in reverse (starting from right child)
    addRightBoundary(root.right, result)

    return result


# =============================================================================
# SOLUTION 2: Recursive with Flags
# =============================================================================

def boundaryTraversalRecursive(root: Optional[TreeNode]) -> List[int]:
    """
    Boundary traversal using single recursive traversal with flags.

    Flags track if node is part of left/right boundary.

    Time: O(N), Space: O(H)
    """
    if not root:
        return []

    def isLeaf(node: TreeNode) -> bool:
        return node and not node.left and not node.right

    result = []

    def traverse(node: Optional[TreeNode], is_left: bool, is_right: bool) -> None:
        if not node:
            return

        # Add left boundary nodes or leaves
        if is_left or isLeaf(node):
            result.append(node.val)

        # Recurse left
        traverse(node.left, is_left, is_right and not node.right)

        # Recurse right
        traverse(node.right, is_left and not node.left, is_right)

        # Add right boundary AFTER recursion (reverse order)
        if is_right and not isLeaf(node) and not is_left:
            result.append(node.val)

    traverse(root, True, True)
    return result


# =============================================================================
# SOLUTION 3: Iterative Complete Solution
# =============================================================================

def boundaryTraversalIterative(root: Optional[TreeNode]) -> List[int]:
    """
    Fully iterative boundary traversal.

    Uses explicit stacks for all three parts.

    Time: O(N), Space: O(N)
    """
    if not root:
        return []

    def isLeaf(node: TreeNode) -> bool:
        return node and not node.left and not node.right

    result = []

    # Handle single node case
    if isLeaf(root):
        return [root.val]

    result.append(root.val)

    # Left boundary
    curr = root.left
    while curr:
        if not isLeaf(curr):
            result.append(curr.val)
        curr = curr.left if curr.left else curr.right

    # Leaves using iterative preorder
    stack = [root]
    while stack:
        node = stack.pop()
        if isLeaf(node):
            result.append(node.val)
        # Push right first, then left (so left is processed first)
        if node.right:
            stack.append(node.right)
        if node.left:
            stack.append(node.left)

    # Right boundary (collect then reverse)
    right_boundary = []
    curr = root.right
    while curr:
        if not isLeaf(curr):
            right_boundary.append(curr.val)
        curr = curr.right if curr.right else curr.left

    # Add right boundary in reverse
    result.extend(reversed(right_boundary))

    return result


# =============================================================================
# BONUS: Get Specific Parts
# =============================================================================

def getLeftBoundary(root: Optional[TreeNode]) -> List[int]:
    """Get only the left boundary (excluding leaves)"""
    if not root:
        return []

    def isLeaf(node):
        return node and not node.left and not node.right

    result = []
    curr = root
    while curr:
        if not isLeaf(curr):
            result.append(curr.val)
        curr = curr.left if curr.left else curr.right
    return result


def getRightBoundary(root: Optional[TreeNode]) -> List[int]:
    """Get only the right boundary in reverse (excluding leaves)"""
    if not root:
        return []

    def isLeaf(node):
        return node and not node.left and not node.right

    result = []
    curr = root
    while curr:
        if not isLeaf(curr):
            result.append(curr.val)
        curr = curr.right if curr.right else curr.left
    return result[::-1]


def getLeaves(root: Optional[TreeNode]) -> List[int]:
    """Get all leaf nodes left to right"""
    if not root:
        return []

    def isLeaf(node):
        return node and not node.left and not node.right

    result = []

    def collect(node):
        if not node:
            return
        if isLeaf(node):
            result.append(node.val)
        collect(node.left)
        collect(node.right)

    collect(root)
    return result


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def build_tree(values: List[Optional[int]]) -> Optional[TreeNode]:
    """Build binary tree from level-order list representation."""
    if not values or values[0] is None:
        return None

    root = TreeNode(values[0])
    queue = deque([root])
    i = 1

    while queue and i < len(values):
        node = queue.popleft()

        if i < len(values) and values[i] is not None:
            node.left = TreeNode(values[i])
            queue.append(node.left)
        i += 1

        if i < len(values) and values[i] is not None:
            node.right = TreeNode(values[i])
            queue.append(node.right)
        i += 1

    return root


def print_tree(root: Optional[TreeNode], level: int = 0, prefix: str = "Root: "):
    """Print tree structure for visualization."""
    if root is not None:
        print(" " * (level * 4) + prefix + str(root.val))
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            else:
                print(" " * ((level + 1) * 4) + "L--- None")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")
            else:
                print(" " * ((level + 1) * 4) + "R--- None")


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("BOUNDARY TRAVERSAL - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal binary tree
    print("\nTest Case 1: Normal binary tree")
    print("-" * 40)
    tree1 = build_tree([1, 2, 3, 4, 5, None, 6])
    print("Tree structure:")
    print_tree(tree1)
    print(f"\nBoundary (3 parts): {boundaryTraversal(tree1)}")
    print(f"Boundary (recursive): {boundaryTraversalRecursive(tree1)}")
    print(f"Boundary (iterative): {boundaryTraversalIterative(tree1)}")
    print(f"Left boundary: {getLeftBoundary(tree1)}")
    print(f"Leaves: {getLeaves(tree1)}")
    print(f"Right boundary: {getRightBoundary(tree1)}")

    # Test Case 2: Empty tree
    print("\n" + "-" * 40)
    print("Test Case 2: Empty tree")
    print(f"Boundary: {boundaryTraversal(None)}")

    # Test Case 3: Single node
    print("\n" + "-" * 40)
    print("Test Case 3: Single node")
    tree3 = TreeNode(1)
    print(f"Boundary: {boundaryTraversal(tree3)}")

    # Test Case 4: Left skewed
    print("\n" + "-" * 40)
    print("Test Case 4: Left skewed tree")
    tree4 = build_tree([1, 2, None, 3, None, 4])
    print("Tree structure:")
    print_tree(tree4)
    print(f"Boundary: {boundaryTraversal(tree4)}")

    # Test Case 5: Right skewed
    print("\n" + "-" * 40)
    print("Test Case 5: Right skewed tree")
    tree5 = build_tree([1, None, 2, None, 3, None, 4])
    print("Tree structure:")
    print_tree(tree5)
    print(f"Boundary: {boundaryTraversal(tree5)}")

    # Test Case 6: Complete tree
    print("\n" + "-" * 40)
    print("Test Case 6: Complete binary tree")
    tree6 = build_tree([1, 2, 3, 4, 5, 6, 7])
    print("Tree structure:")
    print_tree(tree6)
    print(f"Boundary: {boundaryTraversal(tree6)}")

    # Test Case 7: Complex tree
    print("\n" + "-" * 40)
    print("Test Case 7: Complex tree")
    tree7 = build_tree([1, 2, 3, 4, 5, 6, 7, None, None, 8, 9])
    print("Tree structure:")
    print_tree(tree7)
    print(f"Boundary: {boundaryTraversal(tree7)}")

    # Comparison
    print("\n" + "=" * 60)
    print("COMPARISON OF ALL METHODS")
    print("=" * 60)

    test_tree = build_tree([20, 8, 22, 4, 12, None, 25, None, None, 10, 14])
    print("\nTest tree:")
    print_tree(test_tree)
    print(f"\nThree parts:  {boundaryTraversal(test_tree)}")
    print(f"Recursive:    {boundaryTraversalRecursive(test_tree)}")
    print(f"Iterative:    {boundaryTraversalIterative(test_tree)}")

    print("\n" + "=" * 60)
    print("All tests completed!")
    print("=" * 60)
