"""
Reverse Level Order Traversal of Binary Tree
=============================================

Problem: Given a binary tree, return the bottom-up level order traversal.
         (from left to right, level by level from leaf to root)

Example:
    Input:        1
                 / \
                2   3
               / \
              4   5

    Output: [[4, 5], [2, 3], [1]]
"""

from collections import deque
from typing import List, Optional


class TreeNode:
    """Binary Tree Node"""
    def __init__(self, val: int = 0, left: 'TreeNode' = None, right: 'TreeNode' = None):
        self.val = val
        self.left = left
        self.right = right


# =============================================================================
# SOLUTION 1: Level Order + Reverse
# =============================================================================

def reverseLevelOrder(root: Optional[TreeNode]) -> List[List[int]]:
    """
    Reverse Level Order using standard BFS then reversing result.

    Algorithm:
    1. Perform standard level order traversal
    2. Reverse the result array

    Time Complexity: O(N) for traversal + O(L) for reversal where L = levels
    Space Complexity: O(N) for result storage
    """
    if not root:
        return []

    result = []
    queue = deque([root])

    while queue:
        level_size = len(queue)
        level = []

        for _ in range(level_size):
            node = queue.popleft()
            level.append(node.val)

            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)

        result.append(level)

    # Reverse to get bottom-up order
    return result[::-1]


# =============================================================================
# SOLUTION 2: Using Stack
# =============================================================================

def reverseLevelOrderStack(root: Optional[TreeNode]) -> List[List[int]]:
    """
    Reverse Level Order using a stack to reverse levels.

    Push each level to stack, then pop all for reverse order.

    Time: O(N), Space: O(N)
    """
    if not root:
        return []

    result = []
    stack = []  # Stack to store levels
    queue = deque([root])

    while queue:
        level_size = len(queue)
        level = []

        for _ in range(level_size):
            node = queue.popleft()
            level.append(node.val)

            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)

        stack.append(level)  # Push to stack

    # Pop from stack for reverse order
    while stack:
        result.append(stack.pop())

    return result


# =============================================================================
# SOLUTION 3: Insert at Front using Deque
# =============================================================================

def reverseLevelOrderDeque(root: Optional[TreeNode]) -> List[List[int]]:
    """
    Reverse Level Order by inserting each level at the front.

    Using deque.appendleft() gives O(1) insertion at front.
    (list.insert(0, x) would be O(N))

    Time: O(N), Space: O(N)
    """
    if not root:
        return []

    result = deque()  # Use deque for O(1) front insertion
    queue = deque([root])

    while queue:
        level_size = len(queue)
        level = []

        for _ in range(level_size):
            node = queue.popleft()
            level.append(node.val)

            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)

        result.appendleft(level)  # Insert at front - O(1)

    return list(result)


# =============================================================================
# SOLUTION 4: DFS Recursive
# =============================================================================

def reverseLevelOrderDFS(root: Optional[TreeNode]) -> List[List[int]]:
    """
    Reverse Level Order using DFS with level tracking, then reverse.

    Time: O(N), Space: O(H) for recursion + O(N) for result
    """
    result = []

    def dfs(node: Optional[TreeNode], level: int):
        if not node:
            return

        # Create new level list if needed
        if level >= len(result):
            result.append([])

        # Add current node to its level
        result[level].append(node.val)

        # Recurse on children
        dfs(node.left, level + 1)
        dfs(node.right, level + 1)

    dfs(root, 0)
    return result[::-1]  # Reverse at the end


# =============================================================================
# SOLUTION 5: Flat Reverse Level Order
# =============================================================================

def reverseLevelOrderFlat(root: Optional[TreeNode]) -> List[int]:
    """
    Returns flat list in reverse level order (no level grouping).

    Time: O(N), Space: O(N)
    """
    if not root:
        return []

    levels = reverseLevelOrder(root)

    # Flatten the result
    result = []
    for level in levels:
        result.extend(level)

    return result


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def build_tree(values: List[Optional[int]]) -> Optional[TreeNode]:
    """Build binary tree from level-order list representation."""
    if not values or values[0] is None:
        return None

    root = TreeNode(values[0])
    queue = deque([root])
    i = 1

    while queue and i < len(values):
        node = queue.popleft()

        if i < len(values) and values[i] is not None:
            node.left = TreeNode(values[i])
            queue.append(node.left)
        i += 1

        if i < len(values) and values[i] is not None:
            node.right = TreeNode(values[i])
            queue.append(node.right)
        i += 1

    return root


def print_tree(root: Optional[TreeNode], level: int = 0, prefix: str = "Root: "):
    """Print tree structure for visualization."""
    if root is not None:
        print(" " * (level * 4) + prefix + str(root.val))
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("REVERSE LEVEL ORDER TRAVERSAL - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal tree
    print("\nTest Case 1: Normal binary tree")
    print("-" * 40)
    tree1 = build_tree([1, 2, 3, 4, 5, None, 6])
    print("Tree structure:")
    print_tree(tree1)
    print(f"\nReverse Level Order:        {reverseLevelOrder(tree1)}")
    print(f"Using Stack:                {reverseLevelOrderStack(tree1)}")
    print(f"Using Deque (appendleft):   {reverseLevelOrderDeque(tree1)}")
    print(f"Using DFS:                  {reverseLevelOrderDFS(tree1)}")
    print(f"Flat output:                {reverseLevelOrderFlat(tree1)}")

    # Test Case 2: Empty tree
    print("\n" + "-" * 40)
    print("Test Case 2: Empty tree")
    print(f"Reverse Level Order: {reverseLevelOrder(None)}")

    # Test Case 3: Single node
    print("\n" + "-" * 40)
    print("Test Case 3: Single node")
    tree3 = TreeNode(1)
    print(f"Reverse Level Order: {reverseLevelOrder(tree3)}")

    # Test Case 4: Complete binary tree
    print("\n" + "-" * 40)
    print("Test Case 4: Complete binary tree")
    tree4 = build_tree([1, 2, 3, 4, 5, 6, 7])
    print("Tree structure:")
    print_tree(tree4)
    print(f"\nReverse Level Order: {reverseLevelOrder(tree4)}")

    # Test Case 5: Left skewed
    print("\n" + "-" * 40)
    print("Test Case 5: Left skewed tree")
    tree5 = build_tree([1, 2, None, 3, None, 4])
    print("Tree structure:")
    print_tree(tree5)
    print(f"Reverse Level Order: {reverseLevelOrder(tree5)}")

    # Comparison with normal level order
    print("\n" + "=" * 60)
    print("COMPARISON: NORMAL vs REVERSE")
    print("=" * 60)

    from collections import deque

    def normalLevelOrder(root):
        if not root:
            return []
        result = []
        queue = deque([root])
        while queue:
            level_size = len(queue)
            level = []
            for _ in range(level_size):
                node = queue.popleft()
                level.append(node.val)
                if node.left:
                    queue.append(node.left)
                if node.right:
                    queue.append(node.right)
            result.append(level)
        return result

    test_tree = build_tree([1, 2, 3, 4, 5, 6, 7])
    print("\nTree:")
    print_tree(test_tree)
    print(f"\nNormal Level Order:  {normalLevelOrder(test_tree)}")
    print(f"Reverse Level Order: {reverseLevelOrder(test_tree)}")

    print("\n" + "=" * 60)
    print("All tests completed!")
    print("=" * 60)
