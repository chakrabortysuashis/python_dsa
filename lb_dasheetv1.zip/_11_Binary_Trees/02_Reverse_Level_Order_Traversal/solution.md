# Reverse Level Order Traversal

## Problem Statement

Given a binary tree, return the **bottom-up level order traversal** of its nodes' values. (i.e., from left to right, level by level from leaf to root).

## Example

```
Input:
        1
       / \
      2   3
     / \
    4   5

Output: [[4, 5], [2, 3], [1]]

Normal Level Order: [[1], [2, 3], [4, 5]]
Reverse Level Order: [[4, 5], [2, 3], [1]]
```

## Tree Visualization

```
Level 2 (Bottom):  4   5      <- Output first
                  / \ 
Level 1:         2   3        <- Output second
                  \
Level 0 (Top):     1          <- Output last

Traversal: Still process 1 -> 2 -> 3 -> 4 -> 5
Output: [[4,5], [2,3], [1]] (reversed)
```

---

## Intuition

Reverse Level Order is just **Level Order with reversed output**. We have two main approaches:

1. **Do Level Order, then reverse** - Simple and intuitive
2. **Use a stack** - Add levels to stack, pop for reverse order
3. **Insert at front** - Instead of appending, insert each level at the beginning

---

## Approach 1: Level Order + Reverse

### Algorithm

```
1. Perform standard level order traversal
2. Reverse the result array
3. Return reversed result
```

### Dry Run

```
Tree:
        1
       / \
      2   3
     / \
    4   5

Level Order: [[1], [2, 3], [4, 5]]

Reverse: [[4, 5], [2, 3], [1]]
```

### Code

```python
from collections import deque

def reverseLevelOrder(root):
    if not root:
        return []
    
    result = []
    queue = deque([root])
    
    while queue:
        level_size = len(queue)
        level = []
        
        for _ in range(level_size):
            node = queue.popleft()
            level.append(node.val)
            
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
        
        result.append(level)
    
    return result[::-1]  # Reverse at the end
```

**Time: O(N) + O(L) for reversal, Space: O(N)**

---

## Approach 2: Using Stack

### Algorithm

```
1. Perform level order traversal
2. Instead of appending to result, push to stack
3. Pop from stack to get reverse order
```

### Visualization

```
Level Order builds:
  Level 0: [1]
  Level 1: [2, 3]
  Level 2: [4, 5]

Stack (LIFO):
  Push [1]      -> Stack: [[1]]
  Push [2,3]    -> Stack: [[1], [2,3]]
  Push [4,5]    -> Stack: [[1], [2,3], [4,5]]

Pop all:
  Pop [4,5]     -> Result: [[4,5]]
  Pop [2,3]     -> Result: [[4,5], [2,3]]
  Pop [1]       -> Result: [[4,5], [2,3], [1]]
```

### Code

```python
def reverseLevelOrderStack(root):
    if not root:
        return []
    
    result = []
    stack = []  # To store levels
    queue = deque([root])
    
    while queue:
        level_size = len(queue)
        level = []
        
        for _ in range(level_size):
            node = queue.popleft()
            level.append(node.val)
            
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
        
        stack.append(level)  # Push level to stack
    
    # Pop from stack for reverse order
    while stack:
        result.append(stack.pop())
    
    return result
```

---

## Approach 3: Insert at Front (Deque)

### Algorithm

```
1. Perform level order traversal
2. Insert each level at the FRONT of result (index 0)
3. Naturally gives reverse order
```

### Code

```python
def reverseLevelOrderFront(root):
    if not root:
        return []
    
    result = deque()  # Use deque for O(1) front insertion
    queue = deque([root])
    
    while queue:
        level_size = len(queue)
        level = []
        
        for _ in range(level_size):
            node = queue.popleft()
            level.append(node.val)
            
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
        
        result.appendleft(level)  # Insert at front
    
    return list(result)
```

**Note:** Using `deque` for `appendleft` gives O(1). Using `list.insert(0, x)` is O(N).

---

## Approach 4: DFS Recursive

### Algorithm

```
1. Use DFS with level tracking
2. Insert nodes at (maxDepth - currentLevel) position
   OR
   Use same DFS as level order, then reverse
```

### Code

```python
def reverseLevelOrderDFS(root):
    result = []
    
    def dfs(node, level):
        if not node:
            return
        
        if level >= len(result):
            result.append([])
        
        result[level].append(node.val)
        
        dfs(node.left, level + 1)
        dfs(node.right, level + 1)
    
    dfs(root, 0)
    return result[::-1]  # Reverse
```

---

## Complexity Analysis

| Approach | Time | Space |
|----------|------|-------|
| Level Order + Reverse | O(N) | O(N) |
| Using Stack | O(N) | O(N) |
| Insert at Front (deque) | O(N) | O(N) |
| DFS + Reverse | O(N) | O(H) + O(N) |

**Where:**
- N = number of nodes
- H = height of tree

---

## Step-by-Step Dry Run (Detailed)

```
Tree:
        1
       / \
      2   3
     / \   \
    4   5   6

Using Level Order + Reverse:

Initial: Queue = [1], Result = []

--- Process Level 0 ---
Queue size = 1
  Dequeue 1, add children [2, 3]
  Level = [1]
Result = [[1]]
Queue = [2, 3]

--- Process Level 1 ---
Queue size = 2
  Dequeue 2, add children [4, 5]
  Dequeue 3, add children [6]
  Level = [2, 3]
Result = [[1], [2, 3]]
Queue = [4, 5, 6]

--- Process Level 2 ---
Queue size = 3
  Dequeue 4 (no children)
  Dequeue 5 (no children)
  Dequeue 6 (no children)
  Level = [4, 5, 6]
Result = [[1], [2, 3], [4, 5, 6]]
Queue = []

--- Reverse ---
Result = [[4, 5, 6], [2, 3], [1]]

Final Output: [[4, 5, 6], [2, 3], [1]]
```

---

## Edge Cases

| Case | Input | Output |
|------|-------|--------|
| Empty tree | `None` | `[]` |
| Single node | `[1]` | `[[1]]` |
| Left skewed | `[1,2,null,3]` | `[[3],[2],[1]]` |
| Right skewed | `[1,null,2,null,3]` | `[[3],[2],[1]]` |

---

## Key Takeaways

1. **Reverse Level Order = Level Order + Reverse**
2. Multiple approaches all achieve O(N) time
3. **deque.appendleft()** is O(1), **list.insert(0, x)** is O(N)
4. Stack naturally reverses order (LIFO)

---

## Related Problems

- Level Order Traversal
- Level Order Traversal II (LeetCode 107)
- Binary Tree Zigzag Level Order Traversal
- Average of Levels in Binary Tree
