# Convert Binary Tree to Doubly Linked List

## Problem Statement

Given a binary tree, convert it to a **Doubly Linked List (DLL)** in-place.
- The `left` pointer should point to the previous node
- The `right` pointer should point to the next node
- The DLL should follow **inorder** traversal order

## Example

```
Input:
        10
       /  \
      5    20
     / \   / \
    3   8 15  25

Output DLL: 3 <-> 5 <-> 8 <-> 10 <-> 15 <-> 20 <-> 25

Inorder: [3, 5, 8, 10, 15, 20, 25]
```

---

## Visualization

```
Tree:
        10
       /  \
      5    20

Conversion:
       prev
        |
   5 <- 10 -> 20
   |          |
left       right

DLL: 5 <-> 10 <-> 20

Pointers:
- 5.right = 10
- 10.left = 5
- 10.right = 20
- 20.left = 10
```

---

## Intuition: Inorder Traversal

**Key Insight:** Inorder traversal gives sorted order for BST.

**Approach:** During inorder traversal:
1. Track the `previous` node
2. Connect previous.right to current
3. Connect current.left to previous
4. Update previous = current

**Leap of Faith:** Trust that after processing left subtree, we have the correct `prev` pointer!

---

## Approach 1: Recursive with Global Previous

### Algorithm

```
1. Process left subtree (recursively)
2. At current node:
   - If prev exists: prev.right = current, current.left = prev
   - Else: current is the head of DLL
3. Update prev = current
4. Process right subtree
```

### Recursion Tree

```
convertToDLL(10), prev=None
    |
    +-- convertToDLL(5), prev=None
    |       |
    |       +-- convertToDLL(3), prev=None
    |       |       head = 3, prev = 3
    |       |
    |       3.right = 5, 5.left = 3
    |       prev = 5
    |       |
    |       +-- convertToDLL(8), prev=5
    |               5.right = 8, 8.left = 5
    |               prev = 8
    |
    8.right = 10, 10.left = 8
    prev = 10
    |
    +-- convertToDLL(20), prev=10
            10.right = 20, 20.left = 10
            ...continue

Final DLL: 3 <-> 5 <-> 8 <-> 10 <-> 20
```

### Code

```python
def bTreeToDLL(root):
    if not root:
        return None
    
    head = [None]  # Use list for mutable reference
    prev = [None]
    
    def convert(node):
        if not node:
            return
        
        # Process left subtree
        convert(node.left)
        
        # Process current node
        if prev[0]:
            prev[0].right = node
            node.left = prev[0]
        else:
            head[0] = node  # First node becomes head
        
        prev[0] = node
        
        # Process right subtree
        convert(node.right)
    
    convert(root)
    return head[0]
```

### Dry Run

```
Tree:
    1
   / \
  2   3

convert(1):
  convert(2):
    convert(None) return
    head = 2, prev = 2  (first node)
    convert(None) return
  
  # At node 1
  prev=2, so: 2.right=1, 1.left=2
  prev = 1
  
  convert(3):
    convert(None) return
    # prev=1, so: 1.right=3, 3.left=1
    prev = 3
    convert(None) return

DLL: 2 <-> 1 <-> 3
```

---

## Approach 2: Iterative with Stack

### Code

```python
def bTreeToDLLIterative(root):
    if not root:
        return None
    
    stack = []
    current = root
    head = None
    prev = None
    
    while stack or current:
        # Go to leftmost node
        while current:
            stack.append(current)
            current = current.left
        
        current = stack.pop()
        
        # Connect nodes
        if prev:
            prev.right = current
            current.left = prev
        else:
            head = current
        
        prev = current
        current = current.right
    
    return head
```

---

## Approach 3: Morris Traversal (O(1) Space)

### Code

```python
def bTreeToDLLMorris(root):
    if not root:
        return None
    
    head = None
    prev = None
    current = root
    
    while current:
        if not current.left:
            # Process current
            if prev:
                prev.right = current
                current.left = prev
            else:
                head = current
            prev = current
            current = current.right
        else:
            # Find inorder predecessor
            predecessor = current.left
            while predecessor.right and predecessor.right != current:
                predecessor = predecessor.right
            
            if not predecessor.right:
                # Create thread
                predecessor.right = current
                current = current.left
            else:
                # Remove thread and process
                predecessor.right = None
                if prev:
                    prev.right = current
                    current.left = prev
                else:
                    head = current
                prev = current
                current = current.right
    
    return head
```

---

## Complexity Analysis

| Approach | Time | Space |
|----------|------|-------|
| Recursive | O(N) | O(H) - call stack |
| Iterative Stack | O(N) | O(H) - explicit stack |
| Morris | O(N) | O(1) |

---

## Edge Cases

| Case | Input | Output |
|------|-------|--------|
| Empty tree | `None` | `None` |
| Single node | `[1]` | `1` (self-linked) |
| Left skewed | `1->2->3` | `3 <-> 2 <-> 1` |
| Right skewed | `1->2->3` | `1 <-> 2 <-> 3` |

---

## Key Takeaways

1. **Inorder for sorted DLL:** Especially useful for BST
2. **In-place conversion:** Reuse left/right pointers
3. **Track head and prev:** Head is first inorder node
4. **No extra nodes:** Just reassign pointers
5. **Morris saves space:** O(1) space using threading

---

## Related Problems

- Flatten Binary Tree to Linked List (LeetCode 114)
- Convert Sorted List to BST (LeetCode 109)
- Convert BST to Sorted Doubly Linked List (LeetCode 426)
