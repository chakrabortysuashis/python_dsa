"""
Convert Binary Tree to Doubly Linked List
==========================================

Problem: Convert binary tree to DLL in-place.
- left pointer = previous node
- right pointer = next node
- Order follows inorder traversal

Example:
        10
       /  \
      5    20
     / \
    3   8

DLL: 3 <-> 5 <-> 8 <-> 10 <-> 20
"""

from typing import List, Optional


class TreeNode:
    """Binary Tree Node (also serves as DLL node)"""
    def __init__(self, val: int = 0, left: 'TreeNode' = None, right: 'TreeNode' = None):
        self.val = val
        self.left = left   # In DLL: previous
        self.right = right  # In DLL: next


# =============================================================================
# SOLUTION 1: Recursive Inorder
# =============================================================================

def bTreeToDLL(root: Optional[TreeNode]) -> Optional[TreeNode]:
    """
    Convert binary tree to DLL using inorder traversal.

    Algorithm:
    1. Process left subtree
    2. Connect prev.right = current, current.left = prev
    3. Update prev = current
    4. Process right subtree

    Time Complexity: O(N)
    Space Complexity: O(H) for recursion

    Args:
        root: Root of binary tree

    Returns:
        Head of the doubly linked list
    """
    if not root:
        return None

    head = [None]  # List for mutable reference
    prev = [None]

    def convert(node: Optional[TreeNode]) -> None:
        if not node:
            return

        # Process left subtree
        convert(node.left)

        # Process current node
        if prev[0]:
            # Connect previous node to current
            prev[0].right = node
            node.left = prev[0]
        else:
            # First node becomes head
            head[0] = node

        # Update previous
        prev[0] = node

        # Process right subtree
        convert(node.right)

    convert(root)
    return head[0]


# =============================================================================
# SOLUTION 2: Iterative with Stack
# =============================================================================

def bTreeToDLLIterative(root: Optional[TreeNode]) -> Optional[TreeNode]:
    """
    Iterative conversion using explicit stack.

    Simulates recursive inorder traversal.

    Time: O(N), Space: O(H)
    """
    if not root:
        return None

    stack = []
    current = root
    head = None
    prev = None

    while stack or current:
        # Go to leftmost node
        while current:
            stack.append(current)
            current = current.left

        # Process current node
        current = stack.pop()

        if prev:
            prev.right = current
            current.left = prev
        else:
            head = current

        prev = current

        # Move to right subtree
        current = current.right

    return head


# =============================================================================
# SOLUTION 3: Morris Traversal (O(1) Space)
# =============================================================================

def bTreeToDLLMorris(root: Optional[TreeNode]) -> Optional[TreeNode]:
    """
    Convert using Morris traversal for O(1) space.

    Uses threading to traverse without stack.

    Time: O(N), Space: O(1)
    """
    if not root:
        return None

    head = None
    prev = None
    current = root

    while current:
        if not current.left:
            # No left child, process current
            if prev:
                prev.right = current
                current.left = prev
            else:
                head = current

            prev = current
            current = current.right
        else:
            # Find inorder predecessor
            predecessor = current.left
            while predecessor.right and predecessor.right != current:
                predecessor = predecessor.right

            if not predecessor.right:
                # Create thread
                predecessor.right = current
                current = current.left
            else:
                # Thread exists, process current
                predecessor.right = None  # Remove thread

                if prev:
                    prev.right = current
                    current.left = prev
                else:
                    head = current

                prev = current
                current = current.right

    return head


# =============================================================================
# SOLUTION 4: Using List (Simple but Extra Space)
# =============================================================================

def bTreeToDLLSimple(root: Optional[TreeNode]) -> Optional[TreeNode]:
    """
    Simple approach: collect inorder, then link.

    Less efficient but easier to understand.

    Time: O(N), Space: O(N)
    """
    if not root:
        return None

    nodes = []

    def inorder(node: Optional[TreeNode]) -> None:
        if not node:
            return
        inorder(node.left)
        nodes.append(node)
        inorder(node.right)

    inorder(root)

    # Link all nodes
    for i in range(len(nodes)):
        if i > 0:
            nodes[i].left = nodes[i - 1]
        else:
            nodes[i].left = None

        if i < len(nodes) - 1:
            nodes[i].right = nodes[i + 1]
        else:
            nodes[i].right = None

    return nodes[0] if nodes else None


# =============================================================================
# BONUS: Convert to Circular DLL
# =============================================================================

def bTreeToCircularDLL(root: Optional[TreeNode]) -> Optional[TreeNode]:
    """
    Convert to circular doubly linked list.

    Head's left points to tail, tail's right points to head.
    """
    if not root:
        return None

    head = [None]
    prev = [None]

    def convert(node: Optional[TreeNode]) -> None:
        if not node:
            return

        convert(node.left)

        if prev[0]:
            prev[0].right = node
            node.left = prev[0]
        else:
            head[0] = node

        prev[0] = node

        convert(node.right)

    convert(root)

    # Make it circular
    if head[0] and prev[0]:
        head[0].left = prev[0]
        prev[0].right = head[0]

    return head[0]


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def build_tree(values: List[Optional[int]]) -> Optional[TreeNode]:
    """Build binary tree from level-order list representation."""
    if not values or values[0] is None:
        return None

    from collections import deque
    root = TreeNode(values[0])
    queue = deque([root])
    i = 1

    while queue and i < len(values):
        node = queue.popleft()

        if i < len(values) and values[i] is not None:
            node.left = TreeNode(values[i])
            queue.append(node.left)
        i += 1

        if i < len(values) and values[i] is not None:
            node.right = TreeNode(values[i])
            queue.append(node.right)
        i += 1

    return root


def print_dll(head: Optional[TreeNode], max_nodes: int = 20) -> str:
    """Print DLL for visualization."""
    if not head:
        return "Empty"

    result = []
    current = head
    count = 0

    while current and count < max_nodes:
        result.append(str(current.val))
        current = current.right
        count += 1

    if current:
        result.append("...")

    return " <-> ".join(result)


def verify_dll(head: Optional[TreeNode]) -> bool:
    """Verify DLL has correct prev/next pointers."""
    if not head:
        return True

    prev = None
    current = head

    while current:
        if current.left != prev:
            return False
        prev = current
        current = current.right

    return True


def dll_to_list(head: Optional[TreeNode]) -> List[int]:
    """Convert DLL back to list."""
    result = []
    current = head
    while current:
        result.append(current.val)
        current = current.right
    return result


def print_tree(root: Optional[TreeNode], level: int = 0, prefix: str = "Root: "):
    """Print tree structure for visualization."""
    if root is not None:
        print(" " * (level * 4) + prefix + str(root.val))
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("CONVERT BINARY TREE TO DOUBLY LINKED LIST - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal BST
    print("\nTest Case 1: BST")
    print("-" * 40)
    tree1 = build_tree([10, 5, 20, 3, 8, 15, 25])
    print("Tree structure:")
    print_tree(tree1)
    dll1 = bTreeToDLL(build_tree([10, 5, 20, 3, 8, 15, 25]))
    print(f"\nDLL: {print_dll(dll1)}")
    print(f"As list: {dll_to_list(dll1)}")
    print(f"Valid DLL: {verify_dll(dll1)}")

    # Test Case 2: Empty tree
    print("\n" + "-" * 40)
    print("Test Case 2: Empty tree")
    print(f"DLL: {print_dll(bTreeToDLL(None))}")

    # Test Case 3: Single node
    print("\n" + "-" * 40)
    print("Test Case 3: Single node")
    tree3 = TreeNode(5)
    dll3 = bTreeToDLL(tree3)
    print(f"DLL: {print_dll(dll3)}")

    # Test Case 4: Left skewed
    print("\n" + "-" * 40)
    print("Test Case 4: Left skewed tree")
    tree4 = build_tree([3, 2, None, 1])
    print("Tree structure:")
    print_tree(tree4)
    dll4 = bTreeToDLL(build_tree([3, 2, None, 1]))
    print(f"DLL: {print_dll(dll4)}")

    # Test Case 5: Right skewed
    print("\n" + "-" * 40)
    print("Test Case 5: Right skewed tree")
    tree5 = build_tree([1, None, 2, None, 3])
    print("Tree structure:")
    print_tree(tree5)
    dll5 = bTreeToDLL(build_tree([1, None, 2, None, 3]))
    print(f"DLL: {print_dll(dll5)}")

    # Comparison of methods
    print("\n" + "=" * 60)
    print("COMPARISON OF ALL METHODS")
    print("=" * 60)

    test_tree_vals = [10, 5, 20, 3, 8, 15, 25]
    print(f"\nOriginal tree: {test_tree_vals}")

    dll_rec = bTreeToDLL(build_tree(test_tree_vals))
    dll_iter = bTreeToDLLIterative(build_tree(test_tree_vals))
    dll_morris = bTreeToDLLMorris(build_tree(test_tree_vals))
    dll_simple = bTreeToDLLSimple(build_tree(test_tree_vals))
    dll_circular = bTreeToCircularDLL(build_tree(test_tree_vals))

    print(f"Recursive:  {dll_to_list(dll_rec)}")
    print(f"Iterative:  {dll_to_list(dll_iter)}")
    print(f"Morris:     {dll_to_list(dll_morris)}")
    print(f"Simple:     {dll_to_list(dll_simple)}")
    print(f"Circular:   {dll_to_list(dll_circular)}")

    # Verify circular DLL
    print(f"\nCircular DLL verification:")
    print(f"  Head: {dll_circular.val}")
    print(f"  Head.left (tail): {dll_circular.left.val if dll_circular.left else None}")

    print("\n" + "=" * 60)
    print("All tests completed!")
    print("=" * 60)
