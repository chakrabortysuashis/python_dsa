# Check if Two Trees are Mirror of Each Other

## Problem Statement

Given two binary trees, check if they are mirrors of each other.

## Example

```
Tree 1:       Tree 2:
    1             1
   / \           / \
  2   3         3   2
 /     \       /     \
4       5     5       4

These ARE mirrors!
```

---

## Intuition

Two trees are mirrors if:
1. Both roots have same value (or both null)
2. Left subtree of T1 mirrors right subtree of T2
3. Right subtree of T1 mirrors left subtree of T2

---

## Recursion Tree

```
isMirror(1, 1)
    |
    +-- values equal? 1 == 1 YES
    |
    +-- isMirror(T1.left=2, T2.right=2)
    |       values equal? YES
    |       +-- isMirror(4, 4) = True
    |       +-- isMirror(None, None) = True
    |       return True
    |
    +-- isMirror(T1.right=3, T2.left=3)
            values equal? YES
            +-- isMirror(None, None) = True
            +-- isMirror(5, 5) = True
            return True

Final: True
```

---

## Code

```python
def isMirror(root1, root2):
    # Both null - mirrors
    if not root1 and not root2:
        return True
    
    # One null, one not - not mirrors
    if not root1 or not root2:
        return False
    
    # Values must match
    # AND left-right cross comparison
    return (root1.val == root2.val and
            isMirror(root1.left, root2.right) and
            isMirror(root1.right, root2.left))
```

---

## Complexity

| Time | Space |
|------|-------|
| O(min(N1, N2)) | O(min(H1, H2)) |

---

## Key Takeaways

1. Cross-compare: left with right, right with left
2. Base case: both null = True, one null = False
3. Same logic as "is tree symmetric" (mirror of itself)
