"""
Check if Two Trees are Mirror of Each Other
============================================
"""

from collections import deque
from typing import List, Optional


class TreeNode:
    def __init__(self, val: int = 0, left: 'TreeNode' = None, right: 'TreeNode' = None):
        self.val = val
        self.left = left
        self.right = right


def isMirror(root1: Optional[TreeNode], root2: Optional[TreeNode]) -> bool:
    """
    Check if two trees are mirrors.

    Two trees are mirrors if:
    1. Roots have same value
    2. Left of T1 mirrors Right of T2
    3. Right of T1 mirrors Left of T2
    """
    # Both null
    if not root1 and not root2:
        return True

    # One null
    if not root1 or not root2:
        return False

    # Values must match AND cross-children must be mirrors
    return (root1.val == root2.val and
            isMirror(root1.left, root2.right) and
            isMirror(root1.right, root2.left))


def isMirrorIterative(root1: Optional[TreeNode], root2: Optional[TreeNode]) -> bool:
    """Iterative approach using queue."""
    queue = deque([(root1, root2)])

    while queue:
        n1, n2 = queue.popleft()

        if not n1 and not n2:
            continue
        if not n1 or not n2:
            return False
        if n1.val != n2.val:
            return False

        # Cross-enqueue
        queue.append((n1.left, n2.right))
        queue.append((n1.right, n2.left))

    return True


def isSymmetric(root: Optional[TreeNode]) -> bool:
    """Check if tree is symmetric (mirror of itself)."""
    if not root:
        return True
    return isMirror(root.left, root.right)


def build_tree(values: List[Optional[int]]) -> Optional[TreeNode]:
    if not values or values[0] is None:
        return None
    root = TreeNode(values[0])
    queue = deque([root])
    i = 1
    while queue and i < len(values):
        node = queue.popleft()
        if i < len(values) and values[i] is not None:
            node.left = TreeNode(values[i])
            queue.append(node.left)
        i += 1
        if i < len(values) and values[i] is not None:
            node.right = TreeNode(values[i])
            queue.append(node.right)
        i += 1
    return root


if __name__ == "__main__":
    print("CHECK TWO TREES MIRROR - TEST CASES")
    print("=" * 40)

    # Mirror trees
    tree1 = build_tree([1, 2, 3])
    tree2 = build_tree([1, 3, 2])
    print(f"[1,2,3] and [1,3,2]: {isMirror(tree1, tree2)}")  # True

    # Not mirrors
    tree3 = build_tree([1, 2, 3])
    tree4 = build_tree([1, 2, 3])
    print(f"[1,2,3] and [1,2,3]: {isMirror(tree3, tree4)}")  # False

    # Symmetric tree
    symm = build_tree([1, 2, 2, 3, 4, 4, 3])
    print(f"Symmetric [1,2,2,3,4,4,3]: {isSymmetric(symm)}")  # True

    print("=" * 40)
