"""
Check if Binary Tree is Height-Balanced
=======================================

Problem: Determine if a binary tree is height-balanced.

Definition: A binary tree is height-balanced if for every node,
the heights of its left and right subtrees differ by at most 1.

Example:
    Balanced:       Unbalanced:
        1               1
       / \             /
      2   3           2
     / \             /
    4   5           3
"""

from collections import deque
from typing import List, Optional, Tuple


class TreeNode:
    """Binary Tree Node"""
    def __init__(self, val: int = 0, left: 'TreeNode' = None, right: 'TreeNode' = None):
        self.val = val
        self.left = left
        self.right = right


# =============================================================================
# SOLUTION 1: Naive Top-Down - O(N^2)
# =============================================================================

def isBalancedNaive(root: Optional[TreeNode]) -> bool:
    """
    Naive approach: For each node, calculate heights of subtrees.

    Problem: Height is recalculated multiple times for same nodes.

    Time Complexity: O(N^2) - height called for each node
    Space Complexity: O(H) - recursion depth

    Args:
        root: Root of binary tree

    Returns:
        True if tree is height-balanced
    """
    def height(node: Optional[TreeNode]) -> int:
        if not node:
            return 0
        return 1 + max(height(node.left), height(node.right))

    if not root:
        return True

    # Check current node
    left_height = height(root.left)
    right_height = height(root.right)

    if abs(left_height - right_height) > 1:
        return False

    # Check both subtrees
    return isBalancedNaive(root.left) and isBalancedNaive(root.right)


# =============================================================================
# SOLUTION 2: Optimized Bottom-Up - O(N)
# =============================================================================

def isBalanced(root: Optional[TreeNode]) -> bool:
    """
    Optimized approach: Calculate height and check balance in one pass.

    Use -1 as sentinel value to indicate unbalanced subtree.
    This allows early termination when imbalance is detected.

    Time Complexity: O(N) - each node visited once
    Space Complexity: O(H) - recursion depth

    Args:
        root: Root of binary tree

    Returns:
        True if tree is height-balanced
    """
    def checkHeight(node: Optional[TreeNode]) -> int:
        """
        Returns height if balanced, -1 if unbalanced.
        """
        if not node:
            return 0

        # Check left subtree
        left_height = checkHeight(node.left)
        if left_height == -1:
            return -1  # Left subtree is unbalanced

        # Check right subtree
        right_height = checkHeight(node.right)
        if right_height == -1:
            return -1  # Right subtree is unbalanced

        # Check current node balance
        if abs(left_height - right_height) > 1:
            return -1  # Current node is unbalanced

        # Return height of current node
        return 1 + max(left_height, right_height)

    return checkHeight(root) != -1


# =============================================================================
# SOLUTION 3: Bottom-Up with Tuple Return
# =============================================================================

def isBalancedTuple(root: Optional[TreeNode]) -> bool:
    """
    Alternative: Return (is_balanced, height) tuple.

    More explicit than using -1 sentinel.

    Time: O(N), Space: O(H)
    """
    def check(node: Optional[TreeNode]) -> Tuple[bool, int]:
        """Returns (is_balanced, height)"""
        if not node:
            return (True, 0)

        left_balanced, left_height = check(node.left)
        if not left_balanced:
            return (False, 0)

        right_balanced, right_height = check(node.right)
        if not right_balanced:
            return (False, 0)

        is_balanced = abs(left_height - right_height) <= 1
        height = 1 + max(left_height, right_height)

        return (is_balanced, height)

    return check(root)[0]


# =============================================================================
# SOLUTION 4: Iterative Post-Order
# =============================================================================

def isBalancedIterative(root: Optional[TreeNode]) -> bool:
    """
    Iterative approach using post-order traversal.

    Process children before parent, store heights in hashmap.

    Time: O(N), Space: O(N) for hashmap
    """
    if not root:
        return True

    heights = {None: 0}
    stack = [(root, False)]  # (node, processed_flag)

    while stack:
        node, processed = stack.pop()

        if processed:
            # Children have been processed, check balance
            left_h = heights.get(node.left, 0)
            right_h = heights.get(node.right, 0)

            if abs(left_h - right_h) > 1:
                return False

            heights[node] = 1 + max(left_h, right_h)
        else:
            # Push node back with processed flag
            stack.append((node, True))

            # Push children (will be processed first)
            if node.right:
                stack.append((node.right, False))
            if node.left:
                stack.append((node.left, False))

    return True


# =============================================================================
# SOLUTION 5: DFS with Early Exit (Using Exception)
# =============================================================================

def isBalancedException(root: Optional[TreeNode]) -> bool:
    """
    Use exception for early exit when imbalance found.

    Not recommended for production but shows early exit concept.

    Time: O(N), Space: O(H)
    """
    class UnbalancedException(Exception):
        pass

    def height(node: Optional[TreeNode]) -> int:
        if not node:
            return 0

        left_h = height(node.left)
        right_h = height(node.right)

        if abs(left_h - right_h) > 1:
            raise UnbalancedException()

        return 1 + max(left_h, right_h)

    try:
        height(root)
        return True
    except UnbalancedException:
        return False


# =============================================================================
# BONUS: Get Balance Factor at Each Node
# =============================================================================

def getBalanceFactors(root: Optional[TreeNode]) -> dict:
    """
    Get balance factor (left_height - right_height) for each node.

    Useful for debugging and understanding tree structure.
    """
    factors = {}

    def height(node: Optional[TreeNode]) -> int:
        if not node:
            return 0

        left_h = height(node.left)
        right_h = height(node.right)

        factors[node.val] = left_h - right_h

        return 1 + max(left_h, right_h)

    height(root)
    return factors


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def build_tree(values: List[Optional[int]]) -> Optional[TreeNode]:
    """Build binary tree from level-order list representation."""
    if not values or values[0] is None:
        return None

    root = TreeNode(values[0])
    queue = deque([root])
    i = 1

    while queue and i < len(values):
        node = queue.popleft()

        if i < len(values) and values[i] is not None:
            node.left = TreeNode(values[i])
            queue.append(node.left)
        i += 1

        if i < len(values) and values[i] is not None:
            node.right = TreeNode(values[i])
            queue.append(node.right)
        i += 1

    return root


def print_tree(root: Optional[TreeNode], level: int = 0, prefix: str = "Root: "):
    """Print tree structure for visualization."""
    if root is not None:
        print(" " * (level * 4) + prefix + str(root.val))
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            else:
                print(" " * ((level + 1) * 4) + "L--- None")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")
            else:
                print(" " * ((level + 1) * 4) + "R--- None")


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("CHECK BALANCED BINARY TREE - TEST CASES")
    print("=" * 60)

    # Test Case 1: Balanced tree
    print("\nTest Case 1: Balanced tree")
    print("-" * 40)
    tree1 = build_tree([1, 2, 3, 4, 5])
    print("Tree structure:")
    print_tree(tree1)
    print(f"\nNaive:     {isBalancedNaive(tree1)}")
    print(f"Optimized: {isBalanced(tree1)}")
    print(f"Tuple:     {isBalancedTuple(tree1)}")
    print(f"Iterative: {isBalancedIterative(tree1)}")
    print(f"Balance factors: {getBalanceFactors(tree1)}")

    # Test Case 2: Empty tree
    print("\n" + "-" * 40)
    print("Test Case 2: Empty tree")
    print(f"Balanced: {isBalanced(None)}")

    # Test Case 3: Single node
    print("\n" + "-" * 40)
    print("Test Case 3: Single node")
    tree3 = TreeNode(1)
    print(f"Balanced: {isBalanced(tree3)}")

    # Test Case 4: Unbalanced - left skewed
    print("\n" + "-" * 40)
    print("Test Case 4: Unbalanced left skewed")
    tree4 = build_tree([1, 2, None, 3, None, 4])
    print("Tree structure:")
    print_tree(tree4)
    print(f"Balanced: {isBalanced(tree4)}")
    print(f"Balance factors: {getBalanceFactors(tree4)}")

    # Test Case 5: Unbalanced - right skewed
    print("\n" + "-" * 40)
    print("Test Case 5: Unbalanced right skewed")
    tree5 = build_tree([1, None, 2, None, 3, None, 4])
    print("Tree structure:")
    print_tree(tree5)
    print(f"Balanced: {isBalanced(tree5)}")

    # Test Case 6: LeetCode Example - Balanced
    print("\n" + "-" * 40)
    print("Test Case 6: [3,9,20,null,null,15,7] - Balanced")
    tree6 = build_tree([3, 9, 20, None, None, 15, 7])
    print("Tree structure:")
    print_tree(tree6)
    print(f"Balanced: {isBalanced(tree6)}")

    # Test Case 7: LeetCode Example - Unbalanced
    print("\n" + "-" * 40)
    print("Test Case 7: [1,2,2,3,3,null,null,4,4] - Unbalanced")
    tree7 = build_tree([1, 2, 2, 3, 3, None, None, 4, 4])
    print("Tree structure:")
    print_tree(tree7)
    print(f"Balanced: {isBalanced(tree7)}")
    print(f"Balance factors: {getBalanceFactors(tree7)}")

    # Test Case 8: Complete binary tree
    print("\n" + "-" * 40)
    print("Test Case 8: Complete binary tree (7 nodes)")
    tree8 = build_tree([1, 2, 3, 4, 5, 6, 7])
    print("Tree structure:")
    print_tree(tree8)
    print(f"Balanced: {isBalanced(tree8)}")

    # Comparison
    print("\n" + "=" * 60)
    print("COMPARISON OF ALL METHODS")
    print("=" * 60)

    test_cases = [
        ("Balanced", build_tree([1, 2, 3, 4, 5, 6, 7])),
        ("Unbalanced", build_tree([1, 2, None, 3, None, 4])),
        ("Single", TreeNode(1)),
        ("Empty", None),
    ]

    for name, tree in test_cases:
        n = isBalancedNaive(tree)
        o = isBalanced(tree)
        t = isBalancedTuple(tree)
        i = isBalancedIterative(tree)
        print(f"{name}: Naive={n}, Optimized={o}, Tuple={t}, Iterative={i}")

    print("\n" + "=" * 60)
    print("All tests completed!")
    print("=" * 60)
