# Check if Binary Tree is Balanced

## Problem Statement

Given a binary tree, determine if it is **height-balanced**.

**Definition:** A binary tree is height-balanced if for **every node**, the heights of its left and right subtrees differ by at most 1.

## Example

```
Balanced:           Not Balanced:
     1                   1
    / \                 / \
   2   3               2   3
  / \                 /
 4   5               4
                    /
                   5

Height diff at each node <= 1    Height diff at node 2 is 2
```

---

## Visualization

```
Balanced Tree Check:

        1          height=3
       / \
      2   3        height(2)=2, height(3)=1
     / \           |2-1| = 1 <= 1 (OK)
    4   5          height=1

Check at each node:
- Node 1: |height(2) - height(3)| = |2 - 1| = 1 <= 1  PASS
- Node 2: |height(4) - height(5)| = |1 - 1| = 0 <= 1  PASS
- Node 3: |0 - 0| = 0 <= 1  PASS
- Leaves: Always balanced

Result: BALANCED
```

---

## Intuition: The Leap of Faith

**Naive Approach:** 
- For each node, calculate height of left and right subtrees
- Check if difference <= 1
- Problem: O(N^2) because height is recalculated for each node

**Optimized Approach:**
- Calculate height bottom-up
- Return -1 if subtree is unbalanced (early termination)
- "Leap of Faith": Trust that recursive calls tell us if subtrees are balanced AND their heights

---

## Approach 1: Naive (Top-Down) - O(N^2)

### Algorithm

```
1. For each node, check if |height(left) - height(right)| <= 1
2. Recursively check if left and right subtrees are balanced
3. All conditions must be true
```

### Recursion Tree (Naive)

```
isBalanced(1)
    |
    +-- height(2) = 2    <-- Calculates height
    +-- height(3) = 1
    +-- |2-1| <= 1? YES
    |
    +-- isBalanced(2)    <-- Recalculates height again!
    |       +-- height(4) = 1
    |       +-- height(5) = 1
    |       +-- isBalanced(4)
    |       +-- isBalanced(5)
    |
    +-- isBalanced(3)
```

**Problem:** Height is calculated multiple times for same nodes!

### Code

```python
def isBalancedNaive(root):
    if not root:
        return True
    
    left_height = height(root.left)
    right_height = height(root.right)
    
    # Check current node AND both subtrees
    return (abs(left_height - right_height) <= 1 and
            isBalancedNaive(root.left) and
            isBalancedNaive(root.right))
```

---

## Approach 2: Optimized (Bottom-Up) - O(N)

### Algorithm

```
1. Use height calculation that returns -1 if unbalanced
2. Base case: None has height 0
3. If any child returns -1, propagate -1 upward
4. If |left_height - right_height| > 1, return -1
5. Otherwise return actual height
```

### Recursion Tree (Optimized)

```
checkHeight(1)
    |
    +-- checkHeight(2)
    |       |
    |       +-- checkHeight(4)
    |       |       +-- checkHeight(None) = 0
    |       |       +-- checkHeight(None) = 0
    |       |       return 1 + max(0,0) = 1
    |       |
    |       +-- checkHeight(5)
    |       |       return 1
    |       |
    |       return 1 + max(1,1) = 2
    |
    +-- checkHeight(3)
    |       +-- checkHeight(None) = 0
    |       +-- checkHeight(None) = 0
    |       return 1
    |
    +-- |2 - 1| <= 1? YES
    return 1 + max(2, 1) = 3

Final: 3 (not -1), so tree is BALANCED
```

### Code

```python
def isBalanced(root):
    def checkHeight(node):
        if not node:
            return 0
        
        left = checkHeight(node.left)
        if left == -1:
            return -1  # Left subtree unbalanced
        
        right = checkHeight(node.right)
        if right == -1:
            return -1  # Right subtree unbalanced
        
        if abs(left - right) > 1:
            return -1  # Current node unbalanced
        
        return 1 + max(left, right)
    
    return checkHeight(root) != -1
```

### Dry Run

```
Unbalanced Tree:
        1
       /
      2
     /
    3

checkHeight(1):
  checkHeight(2):
    checkHeight(3):
      checkHeight(None) = 0
      checkHeight(None) = 0
      return 1
    checkHeight(None) = 0
    |1 - 0| = 1 <= 1, return 2
  checkHeight(None) = 0
  |2 - 0| = 2 > 1, return -1  <-- UNBALANCED!

Result: -1 means NOT BALANCED
```

---

## Approach 3: Iterative (Post-Order with Stack)

### Algorithm

```
1. Post-order traversal (children before parent)
2. Store height in hashmap
3. Check balance when processing each node
```

### Code

```python
def isBalancedIterative(root):
    if not root:
        return True
    
    heights = {None: 0}
    stack = [(root, False)]  # (node, processed)
    
    while stack:
        node, processed = stack.pop()
        
        if processed:
            left_h = heights.get(node.left, 0)
            right_h = heights.get(node.right, 0)
            
            if abs(left_h - right_h) > 1:
                return False
            
            heights[node] = 1 + max(left_h, right_h)
        else:
            stack.append((node, True))
            if node.right:
                stack.append((node.right, False))
            if node.left:
                stack.append((node.left, False))
    
    return True
```

---

## Complexity Analysis

| Approach | Time | Space |
|----------|------|-------|
| Naive (Top-Down) | O(N^2) | O(H) |
| Optimized (Bottom-Up) | O(N) | O(H) |
| Iterative | O(N) | O(N) - hashmap |

**Why O(N^2) for naive?**
- For each node, we calculate height: O(N)
- We do this for N nodes
- Worst case (skewed tree): N + (N-1) + ... + 1 = O(N^2)

---

## Edge Cases

| Case | Input | Output |
|------|-------|--------|
| Empty tree | `None` | `True` |
| Single node | `[1]` | `True` |
| Two levels balanced | `[1,2,3]` | `True` |
| Left skewed (3 nodes) | `1->2->3` | `False` |
| Right skewed (3 nodes) | `1->2->3` | `False` |
| Complete tree | Any | `True` |

---

## Call Stack Visualization

```
Balanced Tree:
    1
   / \
  2   3

checkHeight(1)
    |
    +-- checkHeight(2)
    |       +-- checkHeight(None) -> 0
    |       +-- checkHeight(None) -> 0
    |       |0-0| = 0 <= 1, return 1
    |
    +-- checkHeight(3)
    |       +-- checkHeight(None) -> 0
    |       +-- checkHeight(None) -> 0
    |       return 1
    |
    +-- |1-1| = 0 <= 1
    return 2

Unbalanced Tree:
    1
   /
  2
 /
3

checkHeight(1)
    |
    +-- checkHeight(2)
    |       +-- checkHeight(3) -> 1
    |       +-- checkHeight(None) -> 0
    |       |1-0| = 1 <= 1, return 2
    |
    +-- checkHeight(None) -> 0
    +-- |2-0| = 2 > 1
    return -1  (UNBALANCED!)
```

---

## Key Takeaways

1. **Naive O(N^2):** Check balance + calculate height separately
2. **Optimized O(N):** Combine both in single traversal
3. **Use -1 as sentinel:** Indicates unbalanced subtree
4. **Early termination:** Return immediately when unbalanced detected
5. **Bottom-up is key:** Process children first, then parent

---

## Related Problems

- Balanced Binary Tree (LeetCode 110)
- Maximum Depth of Binary Tree (LeetCode 104)
- Diameter of Binary Tree (LeetCode 543)
- Validate Binary Search Tree (LeetCode 98)
