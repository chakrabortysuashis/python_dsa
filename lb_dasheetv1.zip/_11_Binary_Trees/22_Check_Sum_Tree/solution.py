"""
Check if Binary Tree is a Sum Tree
==================================

A sum tree has the property that each node's value equals
the sum of all values in its left and right subtrees.
"""

from collections import deque
from typing import List, Optional, Tuple


class TreeNode:
    def __init__(self, val: int = 0, left: 'TreeNode' = None, right: 'TreeNode' = None):
        self.val = val
        self.left = left
        self.right = right


def isSumTree(root: Optional[TreeNode]) -> bool:
    """
    Check if tree is a sum tree.

    Time: O(N), Space: O(H)
    """
    def check(node: Optional[TreeNode]) -> Tuple[bool, int]:
        """Returns (is_valid_sum_tree, subtree_sum)"""
        if not node:
            return (True, 0)

        # Leaf node is always a sum tree
        if not node.left and not node.right:
            return (True, node.val)

        # Check children
        left_valid, left_sum = check(node.left)
        right_valid, right_sum = check(node.right)

        # Current node is valid if:
        # 1. Both subtrees are valid sum trees
        # 2. node.val == left_sum + right_sum
        is_valid = (left_valid and right_valid and
                   node.val == left_sum + right_sum)

        # Total sum of this subtree
        total = node.val + left_sum + right_sum

        return (is_valid, total)

    if not root:
        return True

    return check(root)[0]


def isSumTreeIterative(root: Optional[TreeNode]) -> bool:
    """Iterative approach using post-order traversal."""
    if not root:
        return True

    stack = [(root, False)]
    sums = {None: 0}

    while stack:
        node, processed = stack.pop()

        if processed:
            left_sum = sums.get(node.left, 0)
            right_sum = sums.get(node.right, 0)

            # Check if leaf
            if not node.left and not node.right:
                sums[node] = node.val
            else:
                if node.val != left_sum + right_sum:
                    return False
                sums[node] = node.val + left_sum + right_sum
        else:
            stack.append((node, True))
            if node.right:
                stack.append((node.right, False))
            if node.left:
                stack.append((node.left, False))

    return True


def build_tree(values: List[Optional[int]]) -> Optional[TreeNode]:
    if not values or values[0] is None:
        return None
    root = TreeNode(values[0])
    queue = deque([root])
    i = 1
    while queue and i < len(values):
        node = queue.popleft()
        if i < len(values) and values[i] is not None:
            node.left = TreeNode(values[i])
            queue.append(node.left)
        i += 1
        if i < len(values) and values[i] is not None:
            node.right = TreeNode(values[i])
            queue.append(node.right)
        i += 1
    return root


if __name__ == "__main__":
    print("CHECK SUM TREE - TEST CASES")
    print("=" * 40)

    # Test 1: Valid sum tree
    #      26
    #     /  \
    #   10    3
    #  / \     \
    # 4   6     3
    root1 = TreeNode(26)
    root1.left = TreeNode(10)
    root1.right = TreeNode(3)
    root1.left.left = TreeNode(4)
    root1.left.right = TreeNode(6)
    root1.right.right = TreeNode(3)

    print(f"Sum tree 1: {isSumTree(root1)}")  # True

    # Test 2: Not a sum tree
    root2 = build_tree([10, 4, 6])
    print(f"Sum tree 2 [10,4,6]: {isSumTree(root2)}")  # True (10=4+6)

    # Test 3: Invalid
    root3 = build_tree([10, 3, 4])
    print(f"Sum tree 3 [10,3,4]: {isSumTree(root3)}")  # False (10!=3+4)

    print("=" * 40)
