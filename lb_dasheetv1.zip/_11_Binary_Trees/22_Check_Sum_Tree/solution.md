# Check if Binary Tree is a Sum Tree

## Problem Statement

Check if a binary tree is a **Sum Tree** - where each node's value equals the sum of values in its left and right subtrees. Leaf nodes are considered sum trees with sum = their value.

## Example

```
Sum Tree:           Not Sum Tree:
     26                   10
    /  \                 /  \
  10    3               4    6
 / \     \
4   6     3

26 = (4+6+10) + (3+3) = 20 + 6 = 26  VALID
10 != 4 + 6 = 10  (node 10 is valid)
But recursively, all must be valid.
```

---

## Intuition

**Key Insight:** For each internal node:
`node.val == sum(left_subtree) + sum(right_subtree)`

**Recursive Approach:**
1. Leaf nodes are always valid sum trees
2. For internal nodes, check if value equals sum of children's subtrees
3. Return subtree sum for parent's calculation

---

## Recursion Tree

```
isSumTree(26)
    |
    +-- check(10)
    |       +-- check(4) = (True, 4) [leaf]
    |       +-- check(6) = (True, 6) [leaf]
    |       10 == 4 + 6? YES
    |       return (True, 4 + 6 + 10 = 20)
    |
    +-- check(3)
    |       +-- check(None) = (True, 0)
    |       +-- check(3) = (True, 3) [leaf]
    |       3 == 0 + 3? YES
    |       return (True, 0 + 3 + 3 = 6)
    |
    +-- 26 == 20 + 6? YES
    return True
```

---

## Code

```python
def isSumTree(root):
    def check(node):
        # Returns (is_valid, subtree_sum)
        if not node:
            return (True, 0)
        
        # Leaf node
        if not node.left and not node.right:
            return (True, node.val)
        
        left_valid, left_sum = check(node.left)
        right_valid, right_sum = check(node.right)
        
        # Check current node
        is_valid = (left_valid and right_valid and 
                   node.val == left_sum + right_sum)
        
        # Subtree sum = node + left + right
        total = node.val + left_sum + right_sum
        
        return (is_valid, total)
    
    return check(root)[0]
```

---

## Complexity

| Time | Space |
|------|-------|
| O(N) | O(H) |

---

## Key Takeaways

1. **Post-order traversal:** Check children before parent
2. **Return tuple:** (validity, sum) for parent's use
3. **Leaf base case:** Always valid, sum = value
4. **Sum tree property:** `node.val = left_sum + right_sum`
