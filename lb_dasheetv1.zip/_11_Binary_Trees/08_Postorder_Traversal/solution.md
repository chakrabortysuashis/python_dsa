# Postorder Traversal of Binary Tree

## Problem Statement

Given a binary tree, return the **postorder traversal** of its nodes' values.

**Postorder:** Left -> Right -> Root (L-R-N)

## Example

```
Input:
        1
       / \
      2   3
     / \
    4   5

Output: [4, 5, 2, 3, 1]

Traversal: Visit left subtree, then right subtree, then root (last)
```

## Tree Visualization

```
        1           <- Visit 1 LAST
       / \
      2   3         <- Visit 2 before 1, Visit 3 before 1
     / \
    4   5           <- Visit 4, 5 first (leaves)

Postorder process:
1. Go to left subtree of 1
2. Go to left subtree of 2 -> visit 4
3. Go to right subtree of 2 -> visit 5
4. Back to 2, visit 2
5. Go to right subtree of 1 -> visit 3
6. Back to root, visit 1

Result: 4 -> 5 -> 2 -> 3 -> 1
```

---

## Key Property

**Postorder is used to delete a tree (children before parent).**

The root is always LAST!

```
Postorder: [4, 5, 2, 3, 1]
                        ^
                        Root is last!
```

---

## Approach 1: Recursive

### Algorithm

```
postorder(node):
    if node is None:
        return
    
    postorder(node.left)   # L: Process left subtree
    postorder(node.right)  # R: Process right subtree
    visit(node)            # N: Process current node LAST
```

### Recursion Tree

```
Tree:
        1
       / \
      2   3

postorder(1)
    |
    +-- postorder(2)
    |       |
    |       +-- postorder(4) -> visit(4)  -> Output: [4]
    |       +-- postorder(5) -> visit(5)  -> Output: [4, 5]
    |       +-- visit(2)                  -> Output: [4, 5, 2]
    |
    +-- postorder(3)
    |       |
    |       +-- visit(3)                  -> Output: [4, 5, 2, 3]
    |
    +-- visit(1)                          -> Output: [4, 5, 2, 3, 1]

Final: [4, 5, 2, 3, 1]
```

### Code

```python
def postorderRecursive(root):
    """
    Time: O(N), Space: O(H)
    """
    result = []
    
    def traverse(node):
        if node is None:
            return
        
        traverse(node.left)       # L
        traverse(node.right)      # R
        result.append(node.val)   # N: Visit LAST
    
    traverse(root)
    return result
```

---

## Approach 2: Iterative (Two Stacks)

### Key Insight

Use two stacks:
1. First stack for traversal
2. Second stack to reverse the order

### Algorithm

```
1. Push root to stack1
2. While stack1 not empty:
   a. Pop node from stack1, push to stack2
   b. Push left child to stack1 (if exists)
   c. Push right child to stack1 (if exists)
3. Pop all from stack2 to get postorder
```

### Step-by-Step Visualization

```
Tree:
        1
       / \
      2   3

Step 1: stack1=[1], stack2=[]

Step 2: Pop 1 from stack1, push to stack2
        Push left(2), right(3) to stack1
        stack1=[2,3], stack2=[1]

Step 3: Pop 3, push to stack2
        stack1=[2], stack2=[1,3]

Step 4: Pop 2, push to stack2
        Push left(4), right(5)
        stack1=[4,5], stack2=[1,3,2]

Step 5: Pop 5, push to stack2
        stack1=[4], stack2=[1,3,2,5]

Step 6: Pop 4, push to stack2
        stack1=[], stack2=[1,3,2,5,4]

Step 7: Pop all from stack2
        Result: [4,5,2,3,1]
```

### Code

```python
def postorderTwoStacks(root):
    """
    Time: O(N), Space: O(N)
    """
    if not root:
        return []
    
    result = []
    stack1 = [root]
    stack2 = []
    
    while stack1:
        node = stack1.pop()
        stack2.append(node)
        
        # Push left first, then right
        if node.left:
            stack1.append(node.left)
        if node.right:
            stack1.append(node.right)
    
    # Pop from stack2
    while stack2:
        result.append(stack2.pop().val)
    
    return result
```

---

## Approach 3: Iterative (One Stack)

### Key Insight

Use a "last visited" pointer to know when we're returning from right subtree.

### Code

```python
def postorderOneStack(root):
    """
    Time: O(N), Space: O(H)
    """
    if not root:
        return []
    
    result = []
    stack = []
    current = root
    last_visited = None
    
    while stack or current:
        # Go left as far as possible
        while current:
            stack.append(current)
            current = current.left
        
        # Peek at top
        peek_node = stack[-1]
        
        # If right child exists and not yet visited
        if peek_node.right and last_visited != peek_node.right:
            current = peek_node.right
        else:
            # Visit this node
            result.append(peek_node.val)
            last_visited = stack.pop()
    
    return result
```

---

## Approach 4: Modified Preorder (Reverse)

### Key Insight

Postorder (L-R-N) is reverse of modified preorder (N-R-L)!

```
Preorder:          N-L-R
Modified Preorder: N-R-L
Reverse:           L-R-N (Postorder!)
```

### Code

```python
def postorderReverse(root):
    """
    Do N-R-L traversal, then reverse.
    Time: O(N), Space: O(N)
    """
    if not root:
        return []
    
    result = []
    stack = [root]
    
    while stack:
        node = stack.pop()
        result.append(node.val)
        
        # Push left first, then right (opposite of preorder)
        if node.left:
            stack.append(node.left)
        if node.right:
            stack.append(node.right)
    
    return result[::-1]  # Reverse to get postorder
```

---

## Complexity Analysis

| Approach | Time | Space |
|----------|------|-------|
| Recursive | O(N) | O(H) |
| Two Stacks | O(N) | O(N) |
| One Stack | O(N) | O(H) |
| Reverse | O(N) | O(N) |

---

## Memory Aid

```
POSTorder = POST = After = Visit LAST
            Left - Right - Node
            
Think: "Visit node AFTER (POST) visiting children"
```

---

## Comparison: All Three Traversals

```
Tree:
        1
       / \
      2   3
     / \
    4   5

Inorder (L-N-R):   [4, 2, 5, 1, 3]  - Node in MIDDLE
Preorder (N-L-R):  [1, 2, 4, 5, 3]  - Node FIRST
Postorder (L-R-N): [4, 5, 2, 3, 1]  - Node LAST
```

---

## Use Cases

1. **Delete a tree** - Must delete children before parent
2. **Calculate folder size** - Need children sizes first
3. **Expression trees** - Postorder gives postfix notation
4. **Dependency resolution** - Process dependencies first

---

## Edge Cases

| Case | Input | Output |
|------|-------|--------|
| Empty tree | `None` | `[]` |
| Single node | `[1]` | `[1]` |
| Left skewed | `1->2->3` | `[3, 2, 1]` |
| Right skewed | `1->2->3` | `[3, 2, 1]` |

---

## Key Takeaways

1. **Postorder: L -> R -> N** (Left, Right, Node)
2. **Root is always last** in postorder
3. **Iterative is tricky** - two stacks or last_visited pointer
4. **Used for:** Deletion, folder sizes, postfix expressions
5. **Reverse of N-R-L** gives postorder

---

## Related Problems

- Binary Tree Postorder Traversal (LeetCode 145)
- Construct Binary Tree from Inorder and Postorder
- Delete Nodes And Return Forest
- Maximum Binary Tree
