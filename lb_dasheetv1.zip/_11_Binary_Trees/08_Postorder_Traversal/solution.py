"""
Postorder Traversal of Binary Tree
==================================

Problem: Return the postorder traversal of a binary tree's node values.
         Postorder: Left -> Right -> Node (L-R-N)

Key Property: Root is always LAST in postorder!
              Used for: deleting trees, calculating sizes

Example:
        1
       / \
      2   3
     / \
    4   5

    Postorder: [4, 5, 2, 3, 1]
"""

from collections import deque
from typing import List, Optional


class TreeNode:
    """Binary Tree Node"""
    def __init__(self, val: int = 0, left: 'TreeNode' = None, right: 'TreeNode' = None):
        self.val = val
        self.left = left
        self.right = right


# =============================================================================
# SOLUTION 1: Recursive
# =============================================================================

def postorderRecursive(root: Optional[TreeNode]) -> List[int]:
    """
    Postorder traversal using recursion.

    Order: Left -> Right -> Node

    Time Complexity: O(N)
    Space Complexity: O(H) - recursion stack

    Args:
        root: Root of binary tree

    Returns:
        List of node values in postorder sequence
    """
    result = []

    def traverse(node: Optional[TreeNode]):
        if node is None:
            return

        traverse(node.left)       # L: Process left subtree
        traverse(node.right)      # R: Process right subtree
        result.append(node.val)   # N: Visit current node LAST

    traverse(root)
    return result


# =============================================================================
# SOLUTION 2: Iterative (Two Stacks)
# =============================================================================

def postorderTwoStacks(root: Optional[TreeNode]) -> List[int]:
    """
    Postorder traversal using two stacks.

    Algorithm:
    1. Push root to stack1
    2. Pop from stack1, push to stack2
    3. Push children to stack1 (left first, then right)
    4. Pop all from stack2 for result

    Time: O(N), Space: O(N)
    """
    if not root:
        return []

    result = []
    stack1 = [root]
    stack2 = []

    while stack1:
        node = stack1.pop()
        stack2.append(node)

        # Push left first, then right
        if node.left:
            stack1.append(node.left)
        if node.right:
            stack1.append(node.right)

    # Pop from stack2 to get postorder
    while stack2:
        result.append(stack2.pop().val)

    return result


# =============================================================================
# SOLUTION 3: Iterative (One Stack with Last Visited)
# =============================================================================

def postorderOneStack(root: Optional[TreeNode]) -> List[int]:
    """
    Postorder traversal using single stack.

    Uses 'last_visited' pointer to track when returning from right subtree.

    Time: O(N), Space: O(H)
    """
    if not root:
        return []

    result = []
    stack = []
    current = root
    last_visited = None

    while stack or current:
        # Go left as far as possible
        while current:
            stack.append(current)
            current = current.left

        # Peek at top of stack
        peek_node = stack[-1]

        # If right child exists and hasn't been visited yet
        if peek_node.right and last_visited != peek_node.right:
            # Move to right subtree
            current = peek_node.right
        else:
            # Visit this node (both children processed)
            result.append(peek_node.val)
            last_visited = stack.pop()

    return result


# =============================================================================
# SOLUTION 4: Modified Preorder + Reverse
# =============================================================================

def postorderReverse(root: Optional[TreeNode]) -> List[int]:
    """
    Postorder by doing N-R-L traversal then reversing.

    Key insight: Postorder (L-R-N) = Reverse of (N-R-L)

    Time: O(N), Space: O(N)
    """
    if not root:
        return []

    result = []
    stack = [root]

    while stack:
        node = stack.pop()
        result.append(node.val)

        # Push left first, then right (opposite of preorder)
        # This gives N-R-L order
        if node.left:
            stack.append(node.left)
        if node.right:
            stack.append(node.right)

    # Reverse to get L-R-N (postorder)
    return result[::-1]


# =============================================================================
# SOLUTION 5: Generator (Lazy Evaluation)
# =============================================================================

def postorderGenerator(root: Optional[TreeNode]):
    """Postorder traversal as a generator."""
    if root is None:
        return

    yield from postorderGenerator(root.left)
    yield from postorderGenerator(root.right)
    yield root.val


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def build_tree(values: List[Optional[int]]) -> Optional[TreeNode]:
    """Build binary tree from level-order list."""
    if not values or values[0] is None:
        return None

    root = TreeNode(values[0])
    queue = deque([root])
    i = 1

    while queue and i < len(values):
        node = queue.popleft()

        if i < len(values) and values[i] is not None:
            node.left = TreeNode(values[i])
            queue.append(node.left)
        i += 1

        if i < len(values) and values[i] is not None:
            node.right = TreeNode(values[i])
            queue.append(node.right)
        i += 1

    return root


def print_tree(root: Optional[TreeNode], level: int = 0, prefix: str = "Root: "):
    """Print tree structure."""
    if root is not None:
        print(" " * (level * 4) + prefix + str(root.val))
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("POSTORDER TRAVERSAL - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal tree
    print("\nTest Case 1: Normal binary tree")
    print("-" * 40)
    tree1 = build_tree([1, 2, 3, 4, 5])
    print("Tree structure:")
    print_tree(tree1)
    print(f"\nRecursive:   {postorderRecursive(tree1)}")
    print(f"Two Stacks:  {postorderTwoStacks(tree1)}")
    print(f"One Stack:   {postorderOneStack(tree1)}")
    print(f"Reverse:     {postorderReverse(tree1)}")
    print(f"Generator:   {list(postorderGenerator(tree1))}")

    # Test Case 2: Empty tree
    print("\n" + "-" * 40)
    print("Test Case 2: Empty tree")
    print(f"Postorder: {postorderRecursive(None)}")

    # Test Case 3: Single node
    print("\n" + "-" * 40)
    print("Test Case 3: Single node")
    tree3 = TreeNode(1)
    print(f"Postorder: {postorderRecursive(tree3)}")

    # Test Case 4: Left skewed tree
    print("\n" + "-" * 40)
    print("Test Case 4: Left skewed tree")
    tree4 = build_tree([1, 2, None, 3, None, 4])
    print("Tree structure:")
    print_tree(tree4)
    print(f"Postorder: {postorderRecursive(tree4)}")

    # Test Case 5: Right skewed tree
    print("\n" + "-" * 40)
    print("Test Case 5: Right skewed tree")
    tree5 = build_tree([1, None, 2, None, 3, None, 4])
    print("Tree structure:")
    print_tree(tree5)
    print(f"Postorder: {postorderRecursive(tree5)}")

    # Comparison of all traversals
    print("\n" + "=" * 60)
    print("COMPARISON: ALL THREE TRAVERSALS")
    print("=" * 60)

    def inorder(root):
        if not root: return []
        return inorder(root.left) + [root.val] + inorder(root.right)

    def preorder(root):
        if not root: return []
        return [root.val] + preorder(root.left) + preorder(root.right)

    test_tree = build_tree([1, 2, 3, 4, 5, 6, 7])
    print("\nTest tree:")
    print_tree(test_tree)
    print(f"\nInorder (L-N-R):   {inorder(test_tree)}")
    print(f"Preorder (N-L-R):  {preorder(test_tree)}")
    print(f"Postorder (L-R-N): {postorderRecursive(test_tree)}")

    print("\n" + "=" * 60)
    print("All tests completed!")
    print("=" * 60)
