"""
Height of a Binary Tree
=======================

Problem: Find the height (maximum depth) of a binary tree.

Definition:
- Height (edges): Number of edges on longest path from root to leaf
- Height (nodes): Number of nodes on longest path from root to leaf

Example:
        1
       / \
      2   3
     / \
    4   5

    Height (nodes) = 3
    Height (edges) = 2
"""

from collections import deque
from typing import List, Optional


class TreeNode:
    """Binary Tree Node"""
    def __init__(self, val: int = 0, left: 'TreeNode' = None, right: 'TreeNode' = None):
        self.val = val
        self.left = left
        self.right = right


# =============================================================================
# SOLUTION 1: Recursive (DFS) - Node Convention
# =============================================================================

def maxDepth(root: Optional[TreeNode]) -> int:
    """
    Find maximum depth (height) of binary tree - counting nodes.

    Recursive formula:
        height(node) = 1 + max(height(left), height(right))

    Base case:
        height(None) = 0

    Time Complexity: O(N) - visit each node once
    Space Complexity: O(H) - recursion stack depth = height

    Args:
        root: Root of binary tree

    Returns:
        Height counting nodes (0 for empty tree)
    """
    # Base case: empty tree
    if root is None:
        return 0

    # Recursive case: height = 1 + max of children heights
    left_height = maxDepth(root.left)
    right_height = maxDepth(root.right)

    return 1 + max(left_height, right_height)


# =============================================================================
# SOLUTION 2: Recursive (DFS) - Edge Convention
# =============================================================================

def heightEdges(root: Optional[TreeNode]) -> int:
    """
    Find height counting edges (not nodes).

    Base case: height(None) = -1

    Time: O(N), Space: O(H)
    """
    if root is None:
        return -1  # Empty tree has height -1

    left_height = heightEdges(root.left)
    right_height = heightEdges(root.right)

    return 1 + max(left_height, right_height)


# =============================================================================
# SOLUTION 3: Iterative BFS (Level Order)
# =============================================================================

def maxDepthBFS(root: Optional[TreeNode]) -> int:
    """
    Find height using level order traversal.

    Count the number of levels = height.

    Time: O(N), Space: O(W) where W is max width
    """
    if not root:
        return 0

    height = 0
    queue = deque([root])

    while queue:
        level_size = len(queue)
        height += 1  # Each level = +1 height

        for _ in range(level_size):
            node = queue.popleft()
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)

    return height


# =============================================================================
# SOLUTION 4: Iterative DFS (Using Stack)
# =============================================================================

def maxDepthDFS(root: Optional[TreeNode]) -> int:
    """
    Find height using iterative DFS with explicit stack.

    Store (node, depth) pairs in stack.
    Track maximum depth seen.

    Time: O(N), Space: O(H)
    """
    if not root:
        return 0

    max_depth = 0
    stack = [(root, 1)]  # (node, current_depth)

    while stack:
        node, depth = stack.pop()
        max_depth = max(max_depth, depth)

        if node.right:
            stack.append((node.right, depth + 1))
        if node.left:
            stack.append((node.left, depth + 1))

    return max_depth


# =============================================================================
# BONUS: Minimum Depth
# =============================================================================

def minDepth(root: Optional[TreeNode]) -> int:
    """
    Find minimum depth - shortest path from root to any leaf.

    Note: A leaf is a node with no children.
    If one child is None, we must go to the other child.

    Time: O(N), Space: O(H)
    """
    if not root:
        return 0

    # If left is None, only consider right path
    if not root.left:
        return 1 + minDepth(root.right)

    # If right is None, only consider left path
    if not root.right:
        return 1 + minDepth(root.left)

    # Both children exist, take minimum
    return 1 + min(minDepth(root.left), minDepth(root.right))


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def build_tree(values: List[Optional[int]]) -> Optional[TreeNode]:
    """Build binary tree from level-order list representation."""
    if not values or values[0] is None:
        return None

    root = TreeNode(values[0])
    queue = deque([root])
    i = 1

    while queue and i < len(values):
        node = queue.popleft()

        if i < len(values) and values[i] is not None:
            node.left = TreeNode(values[i])
            queue.append(node.left)
        i += 1

        if i < len(values) and values[i] is not None:
            node.right = TreeNode(values[i])
            queue.append(node.right)
        i += 1

    return root


def print_tree(root: Optional[TreeNode], level: int = 0, prefix: str = "Root: "):
    """Print tree structure for visualization."""
    if root is not None:
        print(" " * (level * 4) + prefix + str(root.val))
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("HEIGHT OF BINARY TREE - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal tree
    print("\nTest Case 1: Normal binary tree")
    print("-" * 40)
    tree1 = build_tree([1, 2, 3, 4, 5])
    print("Tree structure:")
    print_tree(tree1)
    print(f"\nHeight (nodes):    {maxDepth(tree1)}")
    print(f"Height (edges):    {heightEdges(tree1)}")
    print(f"Height (BFS):      {maxDepthBFS(tree1)}")
    print(f"Height (DFS iter): {maxDepthDFS(tree1)}")
    print(f"Min Depth:         {minDepth(tree1)}")

    # Test Case 2: Empty tree
    print("\n" + "-" * 40)
    print("Test Case 2: Empty tree")
    print(f"Height: {maxDepth(None)}")

    # Test Case 3: Single node
    print("\n" + "-" * 40)
    print("Test Case 3: Single node")
    tree3 = TreeNode(1)
    print(f"Height (nodes): {maxDepth(tree3)}")
    print(f"Height (edges): {heightEdges(tree3)}")

    # Test Case 4: Left skewed tree
    print("\n" + "-" * 40)
    print("Test Case 4: Left skewed tree")
    tree4 = build_tree([1, 2, None, 3, None, 4])
    print("Tree structure:")
    print_tree(tree4)
    print(f"Height: {maxDepth(tree4)}")

    # Test Case 5: Right skewed tree
    print("\n" + "-" * 40)
    print("Test Case 5: Right skewed tree")
    tree5 = build_tree([1, None, 2, None, 3, None, 4])
    print("Tree structure:")
    print_tree(tree5)
    print(f"Height: {maxDepth(tree5)}")

    # Test Case 6: Complete binary tree
    print("\n" + "-" * 40)
    print("Test Case 6: Complete binary tree (7 nodes)")
    tree6 = build_tree([1, 2, 3, 4, 5, 6, 7])
    print("Tree structure:")
    print_tree(tree6)
    print(f"Height: {maxDepth(tree6)}")
    print(f"Min Depth: {minDepth(tree6)}")

    # Test Case 7: Unbalanced tree (for min depth)
    print("\n" + "-" * 40)
    print("Test Case 7: Unbalanced tree")
    tree7 = build_tree([1, 2, 3, 4, 5, None, None, 8])
    print("Tree structure:")
    print_tree(tree7)
    print(f"Max Depth: {maxDepth(tree7)}")
    print(f"Min Depth: {minDepth(tree7)}")

    # Comparison of all methods
    print("\n" + "=" * 60)
    print("COMPARISON OF ALL METHODS")
    print("=" * 60)

    test_tree = build_tree([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    print("\nTest tree:")
    print_tree(test_tree)
    print(f"\nRecursive (nodes): {maxDepth(test_tree)}")
    print(f"Recursive (edges): {heightEdges(test_tree)}")
    print(f"Iterative BFS:     {maxDepthBFS(test_tree)}")
    print(f"Iterative DFS:     {maxDepthDFS(test_tree)}")

    print("\n" + "=" * 60)
    print("All tests completed!")
    print("=" * 60)
