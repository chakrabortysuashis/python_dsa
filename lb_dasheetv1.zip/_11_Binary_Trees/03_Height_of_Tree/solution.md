# Height of a Binary Tree

## Problem Statement

Given a binary tree, find its **height** (also called **maximum depth**).

**Definition:** Height is the number of edges (or nodes, depending on convention) on the longest path from the root to a leaf.

## Example

```
Input:
        1
       / \
      2   3
     / \
    4   5

Height (counting edges): 2
Height (counting nodes): 3
```

## Two Common Conventions

| Convention | Empty Tree | Single Node | Above Tree |
|------------|------------|-------------|------------|
| Edges | -1 | 0 | 2 |
| Nodes | 0 | 1 | 3 |

**Note:** Most interview questions use the **nodes** convention (LeetCode uses this).

---

## Tree Visualization

```
                    1          <- Level 0, Depth 0
                   / \
Height = 2        2   3        <- Level 1, Depth 1
(edges)          / \
                4   5          <- Level 2, Depth 2

Longest path: 1 -> 2 -> 4 (or 1 -> 2 -> 5)
Edges on path: 2
Nodes on path: 3
```

---

## Intuition: Recursive Thinking

**Key Insight:** Height of a tree = 1 + max(height of left subtree, height of right subtree)

```
height(node) = 1 + max(height(left), height(right))

For node 2:
  left height (4) = 0 (leaf)
  right height (5) = 0 (leaf)
  height(2) = 1 + max(0, 0) = 1

For node 1:
  left height (2) = 1
  right height (3) = 0
  height(1) = 1 + max(1, 0) = 2
```

### The "Leap of Faith"

Trust that `height(left)` and `height(right)` give correct heights for subtrees. Just combine them!

---

## Approach 1: Recursive (DFS)

### Algorithm

```
1. Base case: if node is None, return 0 (or -1 for edge convention)
2. Recursively find height of left subtree
3. Recursively find height of right subtree
4. Return 1 + max(left_height, right_height)
```

### Recursion Tree

```
Tree:
        1
       / \
      2   3
     /
    4

height(1)
    |
    +-- height(2)
    |       |
    |       +-- height(4)
    |       |       |
    |       |       +-- height(None) = 0
    |       |       +-- height(None) = 0
    |       |       return 1 + max(0,0) = 1
    |       |
    |       +-- height(None) = 0
    |       return 1 + max(1, 0) = 2
    |
    +-- height(3)
            |
            +-- height(None) = 0
            +-- height(None) = 0
            return 1 + max(0, 0) = 1
    
    return 1 + max(2, 1) = 3
```

### Code

```python
def height(root):
    # Base case: empty tree
    if root is None:
        return 0  # Use -1 for edge convention
    
    # Recursive case
    left_height = height(root.left)
    right_height = height(root.right)
    
    # Height = 1 + max of children heights
    return 1 + max(left_height, right_height)
```

### Dry Run

```
Tree:
        1
       / \
      2   3
     / \
    4   5

Call Stack (bottom-up):
height(4) -> left=0, right=0 -> return 1
height(5) -> left=0, right=0 -> return 1
height(2) -> left=1, right=1 -> return 2
height(3) -> left=0, right=0 -> return 1
height(1) -> left=2, right=1 -> return 3

Answer: 3 (nodes) or 2 (edges, subtract 1)
```

---

## Approach 2: Iterative (BFS - Level Order)

### Algorithm

```
1. If root is None, return 0
2. Use level order traversal
3. Count the number of levels
4. Return level count
```

### Code

```python
from collections import deque

def heightIterative(root):
    if not root:
        return 0
    
    height = 0
    queue = deque([root])
    
    while queue:
        level_size = len(queue)
        height += 1  # Increment for each level
        
        for _ in range(level_size):
            node = queue.popleft()
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
    
    return height
```

### Dry Run

```
Tree:
        1
       / \
      2   3
     / \
    4   5

Level 0: Queue = [1], height = 1
Level 1: Queue = [2, 3], height = 2
Level 2: Queue = [4, 5], height = 3
Queue empty -> return 3
```

---

## Approach 3: Iterative DFS (Using Stack)

```python
def heightIterativeDFS(root):
    if not root:
        return 0
    
    max_height = 0
    stack = [(root, 1)]  # (node, current_depth)
    
    while stack:
        node, depth = stack.pop()
        max_height = max(max_height, depth)
        
        if node.left:
            stack.append((node.left, depth + 1))
        if node.right:
            stack.append((node.right, depth + 1))
    
    return max_height
```

---

## Complexity Analysis

| Approach | Time | Space |
|----------|------|-------|
| Recursive | O(N) | O(H) - call stack |
| BFS | O(N) | O(W) - queue |
| Iterative DFS | O(N) | O(H) - stack |

**Where:**
- N = number of nodes
- H = height of tree (log N for balanced, N for skewed)
- W = maximum width

---

## Call Stack Visualization

```
Tree:
        1
       / \
      2   3

Call Stack during recursion:

Step 1: Call height(1)
        Stack: [height(1)]

Step 2: height(1) calls height(2)
        Stack: [height(1), height(2)]

Step 3: height(2) calls height(4)
        Stack: [height(1), height(2), height(4)]

Step 4: height(4) calls height(None) -> returns 0
        height(4) calls height(None) -> returns 0
        height(4) returns 1
        Stack: [height(1), height(2)]

Step 5: height(2) calls height(5)
        Stack: [height(1), height(2), height(5)]

Step 6: height(5) returns 1
        Stack: [height(1), height(2)]

Step 7: height(2) has left=1, right=1 -> returns 2
        Stack: [height(1)]

Step 8: height(1) calls height(3)
        Stack: [height(1), height(3)]

Step 9: height(3) returns 1
        height(1) has left=2, right=1 -> returns 3
        Stack: []

Final Answer: 3
```

---

## Edge Cases

| Case | Tree | Height (nodes) |
|------|------|----------------|
| Empty tree | `None` | 0 |
| Single node | `[1]` | 1 |
| Left skewed | `1->2->3->4` | 4 |
| Right skewed | `1->2->3->4` | 4 |
| Balanced | Complete tree | log(N) + 1 |

---

## Related Concepts

### Minimum Depth
Shortest path from root to any leaf:

```python
def minDepth(root):
    if not root:
        return 0
    
    if not root.left:
        return 1 + minDepth(root.right)
    if not root.right:
        return 1 + minDepth(root.left)
    
    return 1 + min(minDepth(root.left), minDepth(root.right))
```

### Height vs Depth
- **Height**: From node DOWN to leaf (count from bottom)
- **Depth**: From root DOWN to node (count from top)

```
        1    <- depth=0, height=2
       / \
      2   3  <- depth=1, height=1
     /
    4        <- depth=2, height=0
```

---

## Key Takeaways

1. **Recursive formula:** `height = 1 + max(left_height, right_height)`
2. **Base case:** Empty node has height 0 (or -1 for edges)
3. **Time O(N):** Must visit every node
4. **Space O(H):** Call stack depth = tree height
5. **Foundation problem:** Used in balanced tree checks, diameter, etc.

---

## Related Problems

- Maximum Depth of Binary Tree (LeetCode 104)
- Minimum Depth of Binary Tree (LeetCode 111)
- Balanced Binary Tree (LeetCode 110)
- Diameter of Binary Tree (LeetCode 543)
