"""
Diagonal Traversal of Binary Tree
=================================

Problem: Return the diagonal traversal of a binary tree.

Diagonal: All nodes on the same line from top-right to bottom-left.

Key Rule:
- Right child: same diagonal
- Left child: next diagonal (d + 1)

Example:
        8
       / \
      3   10
     / \    \
    1   6    14

Output: [[8, 10, 14], [3, 6], [1, 4]]
"""

from collections import deque, defaultdict
from typing import List, Optional


class TreeNode:
    """Binary Tree Node"""
    def __init__(self, val: int = 0, left: 'TreeNode' = None, right: 'TreeNode' = None):
        self.val = val
        self.left = left
        self.right = right


# =============================================================================
# SOLUTION 1: DFS Recursive with Diagonal Tracking
# =============================================================================

def diagonalTraversal(root: Optional[TreeNode]) -> List[List[int]]:
    """
    Diagonal traversal using DFS with diagonal number tracking.

    Rule:
    - Right child stays on same diagonal (d)
    - Left child moves to next diagonal (d + 1)

    Time Complexity: O(N)
    Space Complexity: O(N) for hashmap + O(H) for recursion

    Args:
        root: Root of binary tree

    Returns:
        List of diagonals, each diagonal is a list of values
    """
    if not root:
        return []

    diagonals = defaultdict(list)

    def traverse(node: Optional[TreeNode], d: int) -> None:
        if not node:
            return

        # Add current node to its diagonal
        diagonals[d].append(node.val)

        # Left child: next diagonal
        traverse(node.left, d + 1)

        # Right child: same diagonal
        traverse(node.right, d)

    traverse(root, 0)

    # Return diagonals in order (0, 1, 2, ...)
    return [diagonals[i] for i in range(len(diagonals))]


# =============================================================================
# SOLUTION 2: BFS with Diagonal Tracking
# =============================================================================

def diagonalTraversalBFS(root: Optional[TreeNode]) -> List[List[int]]:
    """
    Diagonal traversal using BFS.

    Queue stores (node, diagonal_number) pairs.

    Time: O(N), Space: O(N)
    """
    if not root:
        return []

    diagonals = defaultdict(list)
    queue = deque([(root, 0)])

    while queue:
        node, d = queue.popleft()
        diagonals[d].append(node.val)

        # Left child goes to next diagonal
        if node.left:
            queue.append((node.left, d + 1))

        # Right child stays on same diagonal
        if node.right:
            queue.append((node.right, d))

    # Return diagonals in order
    max_diagonal = max(diagonals.keys())
    return [diagonals[i] for i in range(max_diagonal + 1)]


# =============================================================================
# SOLUTION 3: Optimized - Follow Right Pointers
# =============================================================================

def diagonalTraversalOptimized(root: Optional[TreeNode]) -> List[List[int]]:
    """
    Optimized diagonal traversal.

    Key insight: For a diagonal, keep following right pointers.
    Push left children to queue for processing next diagonal.

    Time: O(N), Space: O(W) where W is max width
    """
    if not root:
        return []

    result = []
    queue = deque([root])

    while queue:
        diagonal = []
        next_diagonal_starts = deque()

        # Process all nodes that start a right chain
        while queue:
            node = queue.popleft()

            # Follow right pointers for this diagonal
            while node:
                diagonal.append(node.val)

                # Left child starts a new diagonal
                if node.left:
                    next_diagonal_starts.append(node.left)

                # Continue right on same diagonal
                node = node.right

        result.append(diagonal)
        queue = next_diagonal_starts

    return result


# =============================================================================
# SOLUTION 4: Iterative DFS with Stack
# =============================================================================

def diagonalTraversalStack(root: Optional[TreeNode]) -> List[List[int]]:
    """
    Iterative DFS using explicit stack.

    Stack stores (node, diagonal_number).

    Time: O(N), Space: O(N)
    """
    if not root:
        return []

    diagonals = defaultdict(list)
    stack = [(root, 0)]

    while stack:
        node, d = stack.pop()
        diagonals[d].append(node.val)

        # Push right first (will be processed second - preorder style)
        if node.right:
            stack.append((node.right, d))

        # Push left (will be processed first)
        if node.left:
            stack.append((node.left, d + 1))

    # Note: Order within diagonal might differ from BFS
    return [diagonals[i] for i in range(len(diagonals))]


# =============================================================================
# BONUS: Anti-Diagonal Traversal
# =============================================================================

def antiDiagonalTraversal(root: Optional[TreeNode]) -> List[List[int]]:
    """
    Anti-diagonal: Left = same diagonal, Right = next diagonal.

    This is the mirror of diagonal traversal.
    """
    if not root:
        return []

    diagonals = defaultdict(list)

    def traverse(node: Optional[TreeNode], d: int) -> None:
        if not node:
            return

        diagonals[d].append(node.val)
        traverse(node.right, d + 1)  # Right: next diagonal
        traverse(node.left, d)       # Left: same diagonal

    traverse(root, 0)
    return [diagonals[i] for i in range(len(diagonals))]


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def build_tree(values: List[Optional[int]]) -> Optional[TreeNode]:
    """Build binary tree from level-order list representation."""
    if not values or values[0] is None:
        return None

    root = TreeNode(values[0])
    queue = deque([root])
    i = 1

    while queue and i < len(values):
        node = queue.popleft()

        if i < len(values) and values[i] is not None:
            node.left = TreeNode(values[i])
            queue.append(node.left)
        i += 1

        if i < len(values) and values[i] is not None:
            node.right = TreeNode(values[i])
            queue.append(node.right)
        i += 1

    return root


def print_tree(root: Optional[TreeNode], level: int = 0, prefix: str = "Root: "):
    """Print tree structure for visualization."""
    if root is not None:
        print(" " * (level * 4) + prefix + str(root.val))
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            else:
                print(" " * ((level + 1) * 4) + "L--- None")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")
            else:
                print(" " * ((level + 1) * 4) + "R--- None")


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("DIAGONAL TRAVERSAL - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal binary tree
    print("\nTest Case 1: Normal binary tree")
    print("-" * 40)
    tree1 = build_tree([8, 3, 10, 1, 6, None, 14, None, None, 4, 7, 13])
    print("Tree structure:")
    print_tree(tree1)
    print(f"\nDFS:       {diagonalTraversal(tree1)}")
    print(f"BFS:       {diagonalTraversalBFS(tree1)}")
    print(f"Optimized: {diagonalTraversalOptimized(tree1)}")

    # Test Case 2: Empty tree
    print("\n" + "-" * 40)
    print("Test Case 2: Empty tree")
    print(f"Diagonal: {diagonalTraversal(None)}")

    # Test Case 3: Single node
    print("\n" + "-" * 40)
    print("Test Case 3: Single node")
    tree3 = TreeNode(1)
    print(f"Diagonal: {diagonalTraversal(tree3)}")

    # Test Case 4: Right skewed tree
    print("\n" + "-" * 40)
    print("Test Case 4: Right skewed tree")
    tree4 = build_tree([1, None, 2, None, 3, None, 4])
    print("Tree structure:")
    print_tree(tree4)
    print(f"Diagonal: {diagonalTraversal(tree4)}")
    print("Expected: [[1, 2, 3, 4]] (all on same diagonal)")

    # Test Case 5: Left skewed tree
    print("\n" + "-" * 40)
    print("Test Case 5: Left skewed tree")
    tree5 = build_tree([1, 2, None, 3, None, 4])
    print("Tree structure:")
    print_tree(tree5)
    print(f"Diagonal: {diagonalTraversal(tree5)}")
    print("Expected: [[1], [2], [3], [4]] (each on different diagonal)")

    # Test Case 6: Complete binary tree
    print("\n" + "-" * 40)
    print("Test Case 6: Complete binary tree")
    tree6 = build_tree([1, 2, 3, 4, 5, 6, 7])
    print("Tree structure:")
    print_tree(tree6)
    print(f"Diagonal: {diagonalTraversal(tree6)}")

    # Test Case 7: Anti-diagonal
    print("\n" + "-" * 40)
    print("Test Case 7: Anti-diagonal traversal")
    print(f"Anti-diagonal: {antiDiagonalTraversal(tree6)}")

    # Comparison
    print("\n" + "=" * 60)
    print("COMPARISON OF ALL METHODS")
    print("=" * 60)

    test_tree = build_tree([1, 2, 3, 4, 5, 6, 7, 8, 9])
    print("\nTest tree:")
    print_tree(test_tree)
    print(f"\nDFS Recursive: {diagonalTraversal(test_tree)}")
    print(f"BFS:           {diagonalTraversalBFS(test_tree)}")
    print(f"Optimized:     {diagonalTraversalOptimized(test_tree)}")
    print(f"Stack DFS:     {diagonalTraversalStack(test_tree)}")

    print("\n" + "=" * 60)
    print("All tests completed!")
    print("=" * 60)
