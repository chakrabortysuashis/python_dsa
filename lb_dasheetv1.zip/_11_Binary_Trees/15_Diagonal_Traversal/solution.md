# Diagonal Traversal of Binary Tree

## Problem Statement

Given a binary tree, return the **diagonal traversal** of the tree.

**Definition:** Diagonal traversal prints all nodes that are on the same diagonal line from top-right to bottom-left.

## Example

```
Input:
        8
       / \
      3   10
     / \    \
    1   6    14
       / \   /
      4   7 13

Output: [[8, 10, 14], [3, 6, 7, 13], [1, 4]]

Diagonal 0: 8 -> 10 -> 14
Diagonal 1: 3 -> 6 -> 7 -> 13
Diagonal 2: 1 -> 4
```

---

## Visualization

```
Diagonal Lines:

        8 --------- 10 --------- 14    (Diagonal 0)
       /            /            /
      3 ------- 6 ------- 7    13      (Diagonal 1)
     /         /         /     /
    1 ------- 4                        (Diagonal 2)

Key Insight:
- Moving RIGHT: same diagonal (d)
- Moving LEFT: next diagonal (d + 1)
```

---

## Intuition: The Leap of Faith

**Key Observation:**
- When we move to `right` child: stay on same diagonal
- When we move to `left` child: go to next diagonal (d + 1)

**Leap of Faith:** Trust that tracking diagonal number and grouping nodes by it gives the answer!

---

## Approach 1: Recursive DFS with Diagonal Tracking

### Algorithm

```
1. Start with root at diagonal 0
2. For each node:
   - Add node to diagonal d
   - Recurse left with diagonal d + 1
   - Recurse right with diagonal d
3. Return diagonals in order
```

### Recursion Tree

```
traverse(8, d=0)
    |
    +-- diagonals[0].add(8)
    |
    +-- traverse(3, d=1)
    |       +-- diagonals[1].add(3)
    |       +-- traverse(1, d=2)
    |       |       +-- diagonals[2].add(1)
    |       +-- traverse(6, d=1)
    |               +-- diagonals[1].add(6)
    |               +-- traverse(4, d=2)
    |               |       +-- diagonals[2].add(4)
    |               +-- traverse(7, d=1)
    |                       +-- diagonals[1].add(7)
    |
    +-- traverse(10, d=0)
            +-- diagonals[0].add(10)
            +-- traverse(14, d=0)
                    +-- diagonals[0].add(14)
                    +-- traverse(13, d=1)
                            +-- diagonals[1].add(13)
```

### Code

```python
def diagonalTraversal(root):
    if not root:
        return []
    
    diagonals = defaultdict(list)
    
    def traverse(node, d):
        if not node:
            return
        
        diagonals[d].append(node.val)
        traverse(node.left, d + 1)  # Left child: next diagonal
        traverse(node.right, d)     # Right child: same diagonal
    
    traverse(root, 0)
    
    # Return diagonals in order
    return [diagonals[i] for i in range(len(diagonals))]
```

### Dry Run

```
Tree:
        1
       / \
      2   3
     / \
    4   5

traverse(1, d=0): diagonals = {0: [1]}
traverse(2, d=1): diagonals = {0: [1], 1: [2]}
traverse(4, d=2): diagonals = {0: [1], 1: [2], 2: [4]}
traverse(5, d=1): diagonals = {0: [1], 1: [2, 5], 2: [4]}
traverse(3, d=0): diagonals = {0: [1, 3], 1: [2, 5], 2: [4]}

Result: [[1, 3], [2, 5], [4]]
```

---

## Approach 2: BFS with Diagonal Tracking

### Algorithm

```
1. Use queue with (node, diagonal) pairs
2. For each node, add to its diagonal
3. Add children with appropriate diagonal numbers
```

### Code

```python
def diagonalTraversalBFS(root):
    if not root:
        return []
    
    diagonals = defaultdict(list)
    queue = deque([(root, 0)])
    
    while queue:
        node, d = queue.popleft()
        diagonals[d].append(node.val)
        
        if node.left:
            queue.append((node.left, d + 1))
        if node.right:
            queue.append((node.right, d))
    
    return [diagonals[i] for i in range(len(diagonals))]
```

---

## Approach 3: Iterative (Using Right Pointer Optimization)

### Algorithm

```
1. Start with root
2. Keep going right (same diagonal)
3. Push left children to queue for next diagonal
```

### Code

```python
def diagonalTraversalOptimized(root):
    if not root:
        return []
    
    result = []
    queue = deque([root])
    
    while queue:
        diagonal = []
        next_diagonal = deque()
        
        while queue:
            node = queue.popleft()
            
            # Traverse entire diagonal using right pointers
            while node:
                diagonal.append(node.val)
                if node.left:
                    next_diagonal.append(node.left)
                node = node.right
        
        result.append(diagonal)
        queue = next_diagonal
    
    return result
```

---

## Complexity Analysis

| Approach | Time | Space |
|----------|------|-------|
| DFS Recursive | O(N) | O(N) for hashmap + O(H) stack |
| BFS | O(N) | O(N) for queue + hashmap |
| Optimized | O(N) | O(W) queue width |

---

## Edge Cases

| Case | Input | Output |
|------|-------|--------|
| Empty tree | `None` | `[]` |
| Single node | `[1]` | `[[1]]` |
| Right skewed | `1->2->3` | `[[1, 2, 3]]` |
| Left skewed | `1->2->3` | `[[1], [2], [3]]` |
| Complete tree | 7 nodes | `[[1,3,7], [2,6], [4,5]]` |

---

## Key Takeaways

1. **Diagonal rule:** Right = same diagonal, Left = next diagonal
2. **Tracking:** Use hashmap with diagonal number as key
3. **Order matters:** DFS gives preorder within diagonal, BFS gives level order
4. **Optimization:** Can traverse right children directly without queue

---

## Related Problems

- Vertical Order Traversal (LeetCode 987)
- Binary Tree Level Order Traversal (LeetCode 102)
- Print Nodes at K Distance (Similar concept)
- Anti-Diagonal Traversal
