# Check if All Leaves are at Same Level

## Problem Statement

Check if all leaf nodes in a binary tree are at the same level (depth).

## Example

```
Same Level:          Different Levels:
     1                    1
    / \                  / \
   2   3                2   3
  / \   \                \
 4   5   6                5

All leaves at level 2     Leaves at levels 1 and 2
```

---

## Intuition

**Approach 1:** Find level of first leaf, check all others match.

**Approach 2:** Track min and max leaf levels, check if equal.

---

## Recursion Tree

```
checkLeaves(1, level=0)
    |
    +-- checkLeaves(2, level=1)
    |       +-- checkLeaves(4, level=2) -> leaf, first_leaf_level=2
    |       +-- checkLeaves(5, level=2) -> leaf, level==2 OK
    |
    +-- checkLeaves(3, level=1)
            +-- checkLeaves(6, level=2) -> leaf, level==2 OK

All leaves at level 2 -> TRUE
```

---

## Code

```python
def checkLeavesLevel(root):
    first_leaf_level = [None]
    
    def check(node, level):
        if not node:
            return True
        
        # Leaf node
        if not node.left and not node.right:
            if first_leaf_level[0] is None:
                first_leaf_level[0] = level
            return level == first_leaf_level[0]
        
        return check(node.left, level + 1) and check(node.right, level + 1)
    
    return check(root, 0)
```

---

## Complexity

| Time | Space |
|------|-------|
| O(N) | O(H) |

---

## Key Takeaways

1. Track first leaf's level as reference
2. All subsequent leaves must match
3. Early termination on mismatch
