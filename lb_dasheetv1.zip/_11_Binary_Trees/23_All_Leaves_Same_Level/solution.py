"""
Check if All Leaves are at Same Level
=====================================
"""

from collections import deque
from typing import List, Optional


class TreeNode:
    def __init__(self, val: int = 0, left: 'TreeNode' = None, right: 'TreeNode' = None):
        self.val = val
        self.left = left
        self.right = right


def checkLeavesLevel(root: Optional[TreeNode]) -> bool:
    """Check if all leaves are at the same level."""
    if not root:
        return True

    first_leaf_level = [None]

    def check(node: Optional[TreeNode], level: int) -> bool:
        if not node:
            return True

        # Leaf node
        if not node.left and not node.right:
            if first_leaf_level[0] is None:
                first_leaf_level[0] = level
            return level == first_leaf_level[0]

        return (check(node.left, level + 1) and
                check(node.right, level + 1))

    return check(root, 0)


def checkLeavesLevelBFS(root: Optional[TreeNode]) -> bool:
    """BFS approach - check if all leaves in same level."""
    if not root:
        return True

    queue = deque([(root, 0)])
    leaf_level = None

    while queue:
        node, level = queue.popleft()

        # Check if leaf
        if not node.left and not node.right:
            if leaf_level is None:
                leaf_level = level
            elif level != leaf_level:
                return False
        else:
            if node.left:
                queue.append((node.left, level + 1))
            if node.right:
                queue.append((node.right, level + 1))

    return True


def build_tree(values: List[Optional[int]]) -> Optional[TreeNode]:
    if not values or values[0] is None:
        return None
    root = TreeNode(values[0])
    queue = deque([root])
    i = 1
    while queue and i < len(values):
        node = queue.popleft()
        if i < len(values) and values[i] is not None:
            node.left = TreeNode(values[i])
            queue.append(node.left)
        i += 1
        if i < len(values) and values[i] is not None:
            node.right = TreeNode(values[i])
            queue.append(node.right)
        i += 1
    return root


if __name__ == "__main__":
    print("ALL LEAVES SAME LEVEL - TEST CASES")
    print("=" * 40)

    # Test 1: All leaves at same level
    tree1 = build_tree([1, 2, 3, 4, 5, 6, 7])
    print(f"Complete tree: {checkLeavesLevel(tree1)}")  # True

    # Test 2: Leaves at different levels
    tree2 = build_tree([1, 2, 3, None, 5])
    print(f"Different levels: {checkLeavesLevel(tree2)}")  # False

    # Test 3: Single node
    tree3 = TreeNode(1)
    print(f"Single node: {checkLeavesLevel(tree3)}")  # True

    print("=" * 40)
