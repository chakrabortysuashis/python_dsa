"""
Mirror (Invert) a Binary Tree
=============================

Problem: Convert a binary tree into its mirror image.
         Swap left and right children at every node.

Example:
    Input:          Output:
        1               1
       / \             / \
      2   3    =>     3   2
     / \   \         /   / \
    4   5   6       6   5   4
"""

from collections import deque
from typing import List, Optional


class TreeNode:
    """Binary Tree Node"""
    def __init__(self, val: int = 0, left: 'TreeNode' = None, right: 'TreeNode' = None):
        self.val = val
        self.left = left
        self.right = right


# =============================================================================
# SOLUTION 1: Recursive (Postorder - Mirror children, then swap)
# =============================================================================

def mirror(root: Optional[TreeNode]) -> Optional[TreeNode]:
    """
    Mirror a binary tree in-place using recursion.

    Approach: Postorder style
    1. Mirror left subtree
    2. Mirror right subtree
    3. Swap left and right children

    Time Complexity: O(N) - visit each node once
    Space Complexity: O(H) - recursion stack depth

    Args:
        root: Root of binary tree

    Returns:
        Root of mirrored tree (same node, modified)
    """
    if root is None:
        return None

    # Mirror subtrees first
    mirror(root.left)
    mirror(root.right)

    # Swap children
    root.left, root.right = root.right, root.left

    return root


# =============================================================================
# SOLUTION 2: Recursive (Preorder - Swap first, then mirror children)
# =============================================================================

def mirror_preorder(root: Optional[TreeNode]) -> Optional[TreeNode]:
    """
    Mirror using preorder style (swap first).

    Also works! The order doesn't matter as long as we
    process all nodes.

    Time: O(N), Space: O(H)
    """
    if root is None:
        return None

    # Swap first
    root.left, root.right = root.right, root.left

    # Then mirror subtrees
    mirror_preorder(root.left)
    mirror_preorder(root.right)

    return root


# =============================================================================
# SOLUTION 3: Iterative BFS (Level Order)
# =============================================================================

def mirror_bfs(root: Optional[TreeNode]) -> Optional[TreeNode]:
    """
    Mirror using BFS (level-order traversal).

    Process each node level by level, swapping children.

    Time: O(N), Space: O(W) where W is max width
    """
    if not root:
        return None

    queue = deque([root])

    while queue:
        node = queue.popleft()

        # Swap children
        node.left, node.right = node.right, node.left

        # Add children to queue for processing
        if node.left:
            queue.append(node.left)
        if node.right:
            queue.append(node.right)

    return root


# =============================================================================
# SOLUTION 4: Iterative DFS (Stack)
# =============================================================================

def mirror_dfs(root: Optional[TreeNode]) -> Optional[TreeNode]:
    """
    Mirror using iterative DFS with stack.

    Time: O(N), Space: O(H)
    """
    if not root:
        return None

    stack = [root]

    while stack:
        node = stack.pop()

        # Swap children
        node.left, node.right = node.right, node.left

        # Add children to stack
        if node.left:
            stack.append(node.left)
        if node.right:
            stack.append(node.right)

    return root


# =============================================================================
# SOLUTION 5: Create New Mirror Tree (Without Modifying Original)
# =============================================================================

def create_mirror(root: Optional[TreeNode]) -> Optional[TreeNode]:
    """
    Create a NEW mirrored tree without modifying the original.

    Time: O(N), Space: O(N) for new tree + O(H) for recursion
    """
    if not root:
        return None

    # Create new node
    new_node = TreeNode(root.val)

    # Mirror: left child becomes mirror of right, and vice versa
    new_node.left = create_mirror(root.right)
    new_node.right = create_mirror(root.left)

    return new_node


# =============================================================================
# BONUS: Check if Two Trees are Mirrors
# =============================================================================

def is_mirror(root1: Optional[TreeNode], root2: Optional[TreeNode]) -> bool:
    """
    Check if two trees are mirror images of each other.

    Time: O(min(N1, N2)), Space: O(min(H1, H2))
    """
    # Both empty
    if root1 is None and root2 is None:
        return True

    # One empty, one not
    if root1 is None or root2 is None:
        return False

    # Values must match, and children must be crossed mirrors
    return (root1.val == root2.val and
            is_mirror(root1.left, root2.right) and
            is_mirror(root1.right, root2.left))


# =============================================================================
# BONUS: Check if Tree is Symmetric
# =============================================================================

def is_symmetric(root: Optional[TreeNode]) -> bool:
    """
    Check if tree is symmetric (mirror of itself).

    Time: O(N), Space: O(H)
    """
    if not root:
        return True

    return is_mirror(root.left, root.right)


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def build_tree(values: List[Optional[int]]) -> Optional[TreeNode]:
    """Build binary tree from level-order list."""
    if not values or values[0] is None:
        return None

    root = TreeNode(values[0])
    queue = deque([root])
    i = 1

    while queue and i < len(values):
        node = queue.popleft()

        if i < len(values) and values[i] is not None:
            node.left = TreeNode(values[i])
            queue.append(node.left)
        i += 1

        if i < len(values) and values[i] is not None:
            node.right = TreeNode(values[i])
            queue.append(node.right)
        i += 1

    return root


def tree_to_list(root: Optional[TreeNode]) -> List[Optional[int]]:
    """Convert tree to level-order list."""
    if not root:
        return []

    result = []
    queue = deque([root])

    while queue:
        node = queue.popleft()
        if node:
            result.append(node.val)
            queue.append(node.left)
            queue.append(node.right)
        else:
            result.append(None)

    # Remove trailing Nones
    while result and result[-1] is None:
        result.pop()

    return result


def print_tree(root: Optional[TreeNode], level: int = 0, prefix: str = "Root: "):
    """Print tree structure."""
    if root is not None:
        print(" " * (level * 4) + prefix + str(root.val))
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            else:
                print(" " * ((level + 1) * 4) + "L--- None")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")
            else:
                print(" " * ((level + 1) * 4) + "R--- None")


def inorder(root: Optional[TreeNode]) -> List[int]:
    """Get inorder traversal."""
    if not root:
        return []
    return inorder(root.left) + [root.val] + inorder(root.right)


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("MIRROR OF BINARY TREE - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal tree
    print("\nTest Case 1: Normal binary tree")
    print("-" * 40)
    tree1 = build_tree([1, 2, 3, 4, 5, None, 6])
    print("Original tree:")
    print_tree(tree1)
    print(f"Inorder: {inorder(tree1)}")

    # Create a copy and mirror it
    tree1_mirror = build_tree([1, 2, 3, 4, 5, None, 6])
    mirror(tree1_mirror)
    print("\nAfter mirroring:")
    print_tree(tree1_mirror)
    print(f"Inorder: {inorder(tree1_mirror)}")

    # Test Case 2: Empty tree
    print("\n" + "-" * 40)
    print("Test Case 2: Empty tree")
    result = mirror(None)
    print(f"Mirror of None: {result}")

    # Test Case 3: Single node
    print("\n" + "-" * 40)
    print("Test Case 3: Single node")
    tree3 = TreeNode(1)
    print("Before:", tree_to_list(tree3))
    mirror(tree3)
    print("After:", tree_to_list(tree3))

    # Test Case 4: Symmetric tree (mirror of itself)
    print("\n" + "-" * 40)
    print("Test Case 4: Symmetric tree")
    tree4 = build_tree([1, 2, 2, 3, 4, 4, 3])
    print("Tree structure:")
    print_tree(tree4)
    print(f"Is symmetric: {is_symmetric(tree4)}")

    # Test Case 5: Test all mirror methods
    print("\n" + "-" * 40)
    print("Test Case 5: Comparing all mirror methods")

    methods = [
        ("Recursive (postorder)", mirror),
        ("Recursive (preorder)", mirror_preorder),
        ("BFS", mirror_bfs),
        ("DFS Stack", mirror_dfs),
    ]

    for name, method in methods:
        test_tree = build_tree([1, 2, 3, 4, 5])
        method(test_tree)
        print(f"{name}: {tree_to_list(test_tree)}")

    # Test Case 6: Create new mirror (non-destructive)
    print("\n" + "-" * 40)
    print("Test Case 6: Create new mirror (original unchanged)")
    original = build_tree([1, 2, 3, 4, 5])
    new_mirror = create_mirror(original)
    print(f"Original: {tree_to_list(original)}")
    print(f"New mirror: {tree_to_list(new_mirror)}")

    # Test Case 7: Check if two trees are mirrors
    print("\n" + "-" * 40)
    print("Test Case 7: Check if trees are mirrors")
    tree_a = build_tree([1, 2, 3])
    tree_b = build_tree([1, 3, 2])
    print(f"Tree A: {tree_to_list(tree_a)}")
    print(f"Tree B: {tree_to_list(tree_b)}")
    print(f"Are mirrors: {is_mirror(tree_a, tree_b)}")

    print("\n" + "=" * 60)
    print("All tests completed!")
    print("=" * 60)
