# Mirror of a Binary Tree

## Problem Statement

Given a binary tree, convert it into its **mirror** (also called **inverted** tree). In a mirror tree, left and right children of every node are swapped.

## Example

```
Input:                    Output (Mirror):
        1                         1
       / \                       / \
      2   3                     3   2
     / \   \                   /   / \
    4   5   6                 6   5   4

Left becomes Right, Right becomes Left (at every node)
```

## Tree Visualization

```
Original:               Mirror:
        1                   1
       / \                 / \
      2   3      =>       3   2
     / \   \             /   / \
    4   5   6           6   5   4

Inorder (Original): 4, 2, 5, 1, 3, 6
Inorder (Mirror):   6, 3, 1, 5, 2, 4  (Reversed!)
```

---

## Intuition

### Key Insight

To mirror a tree:
1. Mirror the left subtree
2. Mirror the right subtree
3. Swap the left and right children of current node

It's a **postorder** operation - process children first, then current node.

### The "Leap of Faith"

Trust that `mirror(left)` and `mirror(right)` correctly mirror the subtrees.
Then just swap them!

```
mirror(node):
    mirror(node.left)   <- Trust this works
    mirror(node.right)  <- Trust this works
    swap(node.left, node.right)  <- Just swap!
```

---

## Approach 1: Recursive (DFS)

### Algorithm

```
1. Base case: if node is None, return None
2. Recursively mirror left subtree
3. Recursively mirror right subtree
4. Swap left and right children
5. Return the node
```

### Recursion Tree

```
Original Tree:
        1
       / \
      2   3

mirror(1)
    |
    +-- mirror(2)
    |       |
    |       +-- mirror(None) = None
    |       +-- mirror(None) = None
    |       swap(None, None)
    |       return 2
    |
    +-- mirror(3)
            |
            +-- mirror(None) = None
            +-- mirror(None) = None
            swap(None, None)
            return 3
    
    swap(2, 3) -> node.left=3, node.right=2
    return 1

Result:
        1
       / \
      3   2
```

### Code

```python
def mirror(root):
    """
    Mirror a binary tree in-place.
    
    Time: O(N) - visit each node once
    Space: O(H) - recursion stack
    """
    if root is None:
        return None
    
    # Mirror subtrees first (postorder)
    mirror(root.left)
    mirror(root.right)
    
    # Swap children
    root.left, root.right = root.right, root.left
    
    return root
```

### Alternative: Preorder Style

```python
def mirror_preorder(root):
    """Swap first, then recurse (also works!)"""
    if root is None:
        return None
    
    # Swap first
    root.left, root.right = root.right, root.left
    
    # Then mirror subtrees
    mirror_preorder(root.left)
    mirror_preorder(root.right)
    
    return root
```

---

## Approach 2: Iterative (BFS)

### Algorithm

```
1. If root is None, return None
2. Use a queue for level-order traversal
3. For each node:
   a. Swap its left and right children
   b. Add children to queue
4. Return root
```

### Code

```python
from collections import deque

def mirror_iterative(root):
    """Mirror using BFS (level-order)."""
    if not root:
        return None
    
    queue = deque([root])
    
    while queue:
        node = queue.popleft()
        
        # Swap children
        node.left, node.right = node.right, node.left
        
        # Add children to queue
        if node.left:
            queue.append(node.left)
        if node.right:
            queue.append(node.right)
    
    return root
```

---

## Approach 3: Iterative DFS (Stack)

```python
def mirror_stack(root):
    """Mirror using explicit stack (DFS)."""
    if not root:
        return None
    
    stack = [root]
    
    while stack:
        node = stack.pop()
        
        # Swap children
        node.left, node.right = node.right, node.left
        
        # Add children to stack
        if node.left:
            stack.append(node.left)
        if node.right:
            stack.append(node.right)
    
    return root
```

---

## Dry Run

```
Original:
        1
       / \
      2   3
     /
    4

Step 1: mirror(1) calls mirror(2)
Step 2: mirror(2) calls mirror(4)
Step 3: mirror(4) calls mirror(None), mirror(None)
        Swaps None, None -> no change
        Returns 4
Step 4: Back to mirror(2)
        left=4, right=None
        Calls mirror(None) -> None
        Swaps: left=None, right=4
        Returns 2 (now has right child 4)
Step 5: Back to mirror(1)
        left=2, calls mirror(3)
Step 6: mirror(3) -> swaps None, None
        Returns 3
Step 7: Back to mirror(1)
        Swaps: left=3, right=2
        Returns 1

Result:
        1
       / \
      3   2
           \
            4
```

---

## Complexity Analysis

| Approach | Time | Space |
|----------|------|-------|
| Recursive | O(N) | O(H) |
| BFS | O(N) | O(W) |
| DFS Stack | O(N) | O(H) |

**Where:**
- N = number of nodes
- H = height of tree
- W = maximum width

---

## Variations

### 1. Create New Mirror Tree (Don't Modify Original)

```python
def create_mirror(root):
    """Create a new mirrored tree without modifying original."""
    if not root:
        return None
    
    new_node = TreeNode(root.val)
    new_node.left = create_mirror(root.right)  # Note: right -> left
    new_node.right = create_mirror(root.left)  # Note: left -> right
    
    return new_node
```

### 2. Check if Two Trees are Mirror

```python
def is_mirror(root1, root2):
    """Check if two trees are mirror images of each other."""
    if root1 is None and root2 is None:
        return True
    
    if root1 is None or root2 is None:
        return False
    
    return (root1.val == root2.val and
            is_mirror(root1.left, root2.right) and
            is_mirror(root1.right, root2.left))
```

### 3. Check if Tree is Symmetric (Mirror of Itself)

```python
def is_symmetric(root):
    """Check if tree is symmetric around its center."""
    if not root:
        return True
    
    return is_mirror(root.left, root.right)
```

---

## Edge Cases

| Case | Input | Output |
|------|-------|--------|
| Empty tree | `None` | `None` |
| Single node | `[1]` | `[1]` |
| Already symmetric | `[1,2,2]` | `[1,2,2]` |
| Left skewed | `[1,2,null,3]` | Right skewed |
| Right skewed | `[1,null,2,null,3]` | Left skewed |

---

## Key Properties of Mirror Trees

1. **Inorder traversal reverses**
   - Original: L-Root-R
   - Mirror: R-Root-L (reversed)

2. **Preorder and Postorder swap**
   - Preorder becomes "right-first preorder"
   - Postorder becomes "right-first postorder"

3. **Level order reverses each level**
   - Each level's nodes appear in reverse order

4. **Structure is preserved**
   - Height remains same
   - Number of nodes remains same
   - Shape is horizontally flipped

---

## Key Takeaways

1. **Mirror = swap left and right at every node**
2. **Works recursively (trust the process)** or iteratively
3. **Both preorder and postorder swapping work**
4. **In-place modification: O(1) extra space (ignoring recursion stack)**
5. **Time O(N):** Must visit every node

---

## Related Problems

- Invert Binary Tree (LeetCode 226)
- Symmetric Tree (LeetCode 101)
- Same Tree (LeetCode 100)
- Flip Equivalent Binary Trees (LeetCode 951)
