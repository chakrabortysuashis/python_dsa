# Minimum Swaps to Convert Binary Tree to BST

## Problem Statement

Given a complete binary tree represented as an array, find the minimum number of swaps required to convert it to a Binary Search Tree (BST).

## Example

```
Input: [5, 6, 7, 8, 9, 10, 11]

Tree:          5
             /   \
            6     7
           / \   / \
          8   9 10  11

Inorder: [8, 6, 9, 5, 10, 7, 11]
Sorted:  [5, 6, 7, 8, 9, 10, 11]

Output: 3 swaps needed
```

---

## Key Insight

For a BST, the **inorder traversal** must be **sorted**.

**Algorithm:**
1. Get inorder traversal of tree
2. Find minimum swaps to sort the inorder array
3. Return swap count

---

## Approach: Cycle Detection

### Algorithm

```
1. Get inorder traversal
2. Create pairs: (value, original_index)
3. Sort by value
4. Find cycles in permutation
5. Swaps = sum(cycle_length - 1) for all cycles
```

### Recursion Tree (Inorder)

```
inorder(root=5)
    |
    +-- inorder(6)
    |       +-- inorder(8) -> add 8
    |       +-- add 6
    |       +-- inorder(9) -> add 9
    |
    +-- add 5
    |
    +-- inorder(7)
            +-- inorder(10) -> add 10
            +-- add 7
            +-- inorder(11) -> add 11

Inorder: [8, 6, 9, 5, 10, 7, 11]
```

### Code

```python
def minSwaps(arr):
    n = len(arr)
    # Get inorder traversal
    inorder = getInorder(arr)
    
    # Create (value, index) pairs and sort
    pairs = [(val, i) for i, val in enumerate(inorder)]
    pairs.sort()
    
    # Count cycles
    visited = [False] * n
    swaps = 0
    
    for i in range(n):
        if visited[i] or pairs[i][1] == i:
            continue
        
        # Count cycle length
        cycle_len = 0
        j = i
        while not visited[j]:
            visited[j] = True
            j = pairs[j][1]
            cycle_len += 1
        
        swaps += cycle_len - 1
    
    return swaps
```

---

## Complexity

| Aspect | Value |
|--------|-------|
| Time | O(N log N) for sorting |
| Space | O(N) for inorder array |

---

## Key Takeaways

1. **BST property:** Inorder must be sorted
2. **Reduction:** Problem becomes "min swaps to sort array"
3. **Cycle detection:** Each cycle of length k needs k-1 swaps
4. **Permutation:** Track where each element should go
