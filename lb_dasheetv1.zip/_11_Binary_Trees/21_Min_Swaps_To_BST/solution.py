"""
Minimum Swaps to Convert Binary Tree to BST
============================================

Problem: Given a binary tree, find minimum swaps to make it a BST.

Key Insight: BST's inorder traversal is sorted.
So we need minimum swaps to sort the inorder traversal.
"""

from collections import deque
from typing import List, Optional


class TreeNode:
    def __init__(self, val: int = 0, left: 'TreeNode' = None, right: 'TreeNode' = None):
        self.val = val
        self.left = left
        self.right = right


def minSwapsBST(arr: List[int]) -> int:
    """
    Find minimum swaps to convert binary tree (array form) to BST.

    Algorithm:
    1. Get inorder traversal
    2. Find min swaps to sort using cycle detection
    """
    n = len(arr)
    if n <= 1:
        return 0

    # Build tree and get inorder
    root = buildTree(arr)
    inorder = []
    getInorder(root, inorder)

    # Min swaps to sort = count cycles
    return minSwapsToSort(inorder)


def buildTree(arr: List[int]) -> Optional[TreeNode]:
    """Build complete binary tree from array."""
    if not arr:
        return None

    root = TreeNode(arr[0])
    queue = deque([root])
    i = 1

    while queue and i < len(arr):
        node = queue.popleft()

        if i < len(arr):
            node.left = TreeNode(arr[i])
            queue.append(node.left)
        i += 1

        if i < len(arr):
            node.right = TreeNode(arr[i])
            queue.append(node.right)
        i += 1

    return root


def getInorder(node: Optional[TreeNode], result: List[int]) -> None:
    """Get inorder traversal."""
    if not node:
        return
    getInorder(node.left, result)
    result.append(node.val)
    getInorder(node.right, result)


def minSwapsToSort(arr: List[int]) -> int:
    """
    Find minimum swaps to sort array using cycle detection.

    For each cycle of length k, we need k-1 swaps.
    """
    n = len(arr)

    # Create (value, original_index) pairs
    pairs = [(val, i) for i, val in enumerate(arr)]
    pairs.sort()  # Sort by value

    visited = [False] * n
    swaps = 0

    for i in range(n):
        # Already in correct position or already visited
        if visited[i] or pairs[i][1] == i:
            continue

        # Find cycle length
        cycle_len = 0
        j = i

        while not visited[j]:
            visited[j] = True
            j = pairs[j][1]  # Go to original index
            cycle_len += 1

        # Cycle of length k needs k-1 swaps
        swaps += cycle_len - 1

    return swaps


# Alternative: Direct array method
def minSwapsDirect(arr: List[int]) -> int:
    """Direct method without building tree."""
    n = len(arr)

    # For complete binary tree, inorder can be computed directly
    # But for simplicity, we'll use the tree method
    return minSwapsBST(arr)


if __name__ == "__main__":
    print("=" * 50)
    print("MINIMUM SWAPS TO BST - TEST CASES")
    print("=" * 50)

    # Test Case 1
    arr1 = [5, 6, 7, 8, 9, 10, 11]
    print(f"\nArray: {arr1}")
    print(f"Min swaps: {minSwapsBST(arr1)}")

    # Test Case 2
    arr2 = [1, 2, 3]
    print(f"\nArray: {arr2}")
    print(f"Min swaps: {minSwapsBST(arr2)}")

    # Test Case 3
    arr3 = [3, 2, 1]
    print(f"\nArray: {arr3}")
    print(f"Min swaps: {minSwapsBST(arr3)}")

    print("\n" + "=" * 50)
