# Inorder Traversal of Binary Tree

## Problem Statement

Given a binary tree, return the **inorder traversal** of its nodes' values.

**Inorder:** Left -> Root -> Right (L-N-R)

## Example

```
Input:
        1
       / \
      2   3
     / \
    4   5

Output: [4, 2, 5, 1, 3]

Traversal: Left subtree first, then node, then right subtree
```

## Tree Visualization

```
        1
       / \
      2   3
     / \
    4   5

Inorder process:
1. Go to leftmost (4)
2. Visit 4
3. Back to parent (2)
4. Visit 2
5. Go to right child (5)
6. Visit 5
7. Back to root (1)
8. Visit 1
9. Go to right subtree (3)
10. Visit 3

Result: 4 -> 2 -> 5 -> 1 -> 3
```

---

## Key Property

**In a Binary Search Tree (BST), inorder traversal gives nodes in sorted order!**

```
BST:
        4
       / \
      2   6
     / \ / \
    1  3 5  7

Inorder: 1, 2, 3, 4, 5, 6, 7 (Sorted!)
```

---

## Approach 1: Recursive

### Algorithm

```
inorder(node):
    if node is None:
        return
    
    inorder(node.left)    # L: Process left subtree
    visit(node)           # N: Process current node
    inorder(node.right)   # R: Process right subtree
```

### Recursion Tree

```
Tree:
        1
       / \
      2   3

inorder(1)
    |
    +-- inorder(2)
    |       |
    |       +-- inorder(4) -> inorder(None), visit(4), inorder(None)
    |       |
    |       +-- visit(2)
    |       |
    |       +-- inorder(5) -> inorder(None), visit(5), inorder(None)
    |
    +-- visit(1)
    |
    +-- inorder(3) -> inorder(None), visit(3), inorder(None)

Output: 4, 2, 5, 1, 3
```

### Code

```python
def inorderRecursive(root):
    """
    Time: O(N) - visit each node once
    Space: O(H) - recursion stack
    """
    result = []
    
    def traverse(node):
        if node is None:
            return
        
        traverse(node.left)       # L
        result.append(node.val)   # N
        traverse(node.right)      # R
    
    traverse(root)
    return result
```

---

## Approach 2: Iterative (Using Stack)

### Key Insight

We need to "remember" where to return after going left. Use a **stack**!

### Algorithm

```
1. Start at root
2. Go left as far as possible, pushing nodes to stack
3. When can't go left anymore:
   a. Pop from stack (current node)
   b. Visit it
   c. Go to its right child
4. Repeat until stack is empty and current is None
```

### Step-by-Step Visualization

```
Tree:
        1
       / \
      2   3
     / \
    4   5

Step 1: current=1, push 1, go left
        Stack: [1]

Step 2: current=2, push 2, go left
        Stack: [1, 2]

Step 3: current=4, push 4, go left
        Stack: [1, 2, 4]

Step 4: current=None, pop 4, visit 4, go right
        Stack: [1, 2], Result: [4]

Step 5: current=None, pop 2, visit 2, go right to 5
        Stack: [1], Result: [4, 2]

Step 6: current=5, push 5, go left
        Stack: [1, 5]

Step 7: current=None, pop 5, visit 5, go right
        Stack: [1], Result: [4, 2, 5]

Step 8: current=None, pop 1, visit 1, go right to 3
        Stack: [], Result: [4, 2, 5, 1]

Step 9: current=3, push 3, go left
        Stack: [3]

Step 10: current=None, pop 3, visit 3, go right
         Stack: [], Result: [4, 2, 5, 1, 3]

Step 11: current=None, stack empty, DONE!
```

### Code

```python
def inorderIterative(root):
    """
    Time: O(N), Space: O(H)
    """
    result = []
    stack = []
    current = root
    
    while stack or current:
        # Go left as far as possible
        while current:
            stack.append(current)
            current = current.left
        
        # Process current node
        current = stack.pop()
        result.append(current.val)
        
        # Move to right subtree
        current = current.right
    
    return result
```

---

## Approach 3: Morris Traversal (O(1) Space)

### Key Idea

Use the tree's empty right pointers as "threads" to find predecessors.

### Algorithm

```
1. If current has no left child:
   - Visit current
   - Go to right
2. If current has left child:
   - Find rightmost node in left subtree (predecessor)
   - If predecessor.right is None:
     - Make predecessor.right = current (create thread)
     - Go left
   - If predecessor.right == current:
     - Remove thread (predecessor.right = None)
     - Visit current
     - Go right
```

### Code

```python
def inorderMorris(root):
    """
    Morris Traversal - O(1) extra space!
    
    Time: O(N), Space: O(1)
    """
    result = []
    current = root
    
    while current:
        if current.left is None:
            # No left child - visit and go right
            result.append(current.val)
            current = current.right
        else:
            # Find predecessor (rightmost in left subtree)
            predecessor = current.left
            while predecessor.right and predecessor.right != current:
                predecessor = predecessor.right
            
            if predecessor.right is None:
                # Create thread
                predecessor.right = current
                current = current.left
            else:
                # Thread exists - we've returned
                predecessor.right = None  # Remove thread
                result.append(current.val)
                current = current.right
    
    return result
```

---

## Complexity Analysis

| Approach | Time | Space |
|----------|------|-------|
| Recursive | O(N) | O(H) |
| Iterative | O(N) | O(H) |
| Morris | O(N) | O(1) |

**Where H = height of tree**
- Balanced: H = O(log N)
- Skewed: H = O(N)

---

## Call Stack Visualization (Recursive)

```
Tree:
        1
       / \
      2   3

Call Stack Evolution:

[inorder(1)]
[inorder(1), inorder(2)]
[inorder(1), inorder(2), inorder(4)]
[inorder(1), inorder(2), inorder(4), inorder(None)]  <- returns
[inorder(1), inorder(2), inorder(4)]  <- visits 4
[inorder(1), inorder(2), inorder(4), inorder(None)]  <- returns
[inorder(1), inorder(2)]  <- visits 2
[inorder(1), inorder(2), inorder(5)]
... and so on
```

---

## Edge Cases

| Case | Input | Output |
|------|-------|--------|
| Empty tree | `None` | `[]` |
| Single node | `[1]` | `[1]` |
| Left skewed | `1->2->3` | `[3, 2, 1]` |
| Right skewed | `1->2->3` | `[1, 2, 3]` |

---

## Memory Aid

```
INorder = IN the middle
          Left - [Node] - Right
          
Think: "Visit node IN between left and right"
```

---

## Key Takeaways

1. **Inorder: L -> N -> R** (Left, Node, Right)
2. **BST property:** Gives sorted order
3. **Recursive is cleaner**, iterative avoids stack overflow
4. **Morris traversal:** O(1) space but modifies tree temporarily
5. **Stack mimics recursion** in iterative approach

---

## Related Problems

- Binary Tree Inorder Traversal (LeetCode 94)
- Validate Binary Search Tree
- Kth Smallest Element in BST
- Recover Binary Search Tree
