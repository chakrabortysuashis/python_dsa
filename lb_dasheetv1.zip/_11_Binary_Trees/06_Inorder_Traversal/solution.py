"""
Inorder Traversal of Binary Tree
================================

Problem: Return the inorder traversal of a binary tree's node values.
         Inorder: Left -> Node -> Right (L-N-R)

Key Property: In BST, inorder gives sorted order!

Example:
        1
       / \
      2   3
     / \
    4   5

    Inorder: [4, 2, 5, 1, 3]
"""

from collections import deque
from typing import List, Optional


class TreeNode:
    """Binary Tree Node"""
    def __init__(self, val: int = 0, left: 'TreeNode' = None, right: 'TreeNode' = None):
        self.val = val
        self.left = left
        self.right = right


# =============================================================================
# SOLUTION 1: Recursive
# =============================================================================

def inorderRecursive(root: Optional[TreeNode]) -> List[int]:
    """
    Inorder traversal using recursion.

    Order: Left -> Node -> Right

    Time Complexity: O(N) - visit each node once
    Space Complexity: O(H) - recursion stack depth
                      O(log N) balanced, O(N) skewed

    Args:
        root: Root of binary tree

    Returns:
        List of node values in inorder sequence
    """
    result = []

    def traverse(node: Optional[TreeNode]):
        if node is None:
            return

        traverse(node.left)       # L: Process left subtree
        result.append(node.val)   # N: Visit current node
        traverse(node.right)      # R: Process right subtree

    traverse(root)
    return result


# =============================================================================
# SOLUTION 2: Iterative (Using Stack)
# =============================================================================

def inorderIterative(root: Optional[TreeNode]) -> List[int]:
    """
    Inorder traversal using explicit stack.

    Algorithm:
    1. Go left as far as possible, pushing nodes to stack
    2. Pop node, visit it
    3. Move to right child
    4. Repeat until stack empty and current is None

    Time: O(N), Space: O(H)
    """
    result = []
    stack = []
    current = root

    while stack or current:
        # Go left as far as possible
        while current:
            stack.append(current)
            current = current.left

        # Process current node
        current = stack.pop()
        result.append(current.val)

        # Move to right subtree
        current = current.right

    return result


# =============================================================================
# SOLUTION 3: Morris Traversal (O(1) Space)
# =============================================================================

def inorderMorris(root: Optional[TreeNode]) -> List[int]:
    """
    Morris Inorder Traversal - O(1) extra space!

    Uses threading: temporarily use right pointers of
    nodes with no right child to point back to successor.

    Algorithm:
    1. If no left child: visit, go right
    2. If has left child:
       - Find predecessor (rightmost in left subtree)
       - If predecessor.right is None: create thread, go left
       - If predecessor.right == current: remove thread, visit, go right

    Time: O(N), Space: O(1)
    Note: Temporarily modifies tree, restores before returning
    """
    result = []
    current = root

    while current:
        if current.left is None:
            # No left child - visit and move right
            result.append(current.val)
            current = current.right
        else:
            # Find inorder predecessor (rightmost in left subtree)
            predecessor = current.left
            while predecessor.right and predecessor.right != current:
                predecessor = predecessor.right

            if predecessor.right is None:
                # First visit - create thread
                predecessor.right = current
                current = current.left
            else:
                # Returning via thread - remove it and visit
                predecessor.right = None
                result.append(current.val)
                current = current.right

    return result


# =============================================================================
# SOLUTION 4: Generator (Lazy Evaluation)
# =============================================================================

def inorderGenerator(root: Optional[TreeNode]):
    """
    Inorder traversal as a generator.

    Useful when you don't need all values at once.
    Memory efficient for large trees.
    """
    if root is None:
        return

    yield from inorderGenerator(root.left)
    yield root.val
    yield from inorderGenerator(root.right)


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def build_tree(values: List[Optional[int]]) -> Optional[TreeNode]:
    """Build binary tree from level-order list."""
    if not values or values[0] is None:
        return None

    root = TreeNode(values[0])
    queue = deque([root])
    i = 1

    while queue and i < len(values):
        node = queue.popleft()

        if i < len(values) and values[i] is not None:
            node.left = TreeNode(values[i])
            queue.append(node.left)
        i += 1

        if i < len(values) and values[i] is not None:
            node.right = TreeNode(values[i])
            queue.append(node.right)
        i += 1

    return root


def print_tree(root: Optional[TreeNode], level: int = 0, prefix: str = "Root: "):
    """Print tree structure."""
    if root is not None:
        print(" " * (level * 4) + prefix + str(root.val))
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("INORDER TRAVERSAL - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal tree
    print("\nTest Case 1: Normal binary tree")
    print("-" * 40)
    tree1 = build_tree([1, 2, 3, 4, 5])
    print("Tree structure:")
    print_tree(tree1)
    print(f"\nRecursive:  {inorderRecursive(tree1)}")
    print(f"Iterative:  {inorderIterative(tree1)}")
    print(f"Morris:     {inorderMorris(tree1)}")
    print(f"Generator:  {list(inorderGenerator(tree1))}")

    # Test Case 2: Empty tree
    print("\n" + "-" * 40)
    print("Test Case 2: Empty tree")
    print(f"Inorder: {inorderRecursive(None)}")

    # Test Case 3: Single node
    print("\n" + "-" * 40)
    print("Test Case 3: Single node")
    tree3 = TreeNode(1)
    print(f"Inorder: {inorderRecursive(tree3)}")

    # Test Case 4: Left skewed tree
    print("\n" + "-" * 40)
    print("Test Case 4: Left skewed tree")
    tree4 = build_tree([1, 2, None, 3, None, 4])
    print("Tree structure:")
    print_tree(tree4)
    print(f"Inorder: {inorderRecursive(tree4)}")

    # Test Case 5: Right skewed tree
    print("\n" + "-" * 40)
    print("Test Case 5: Right skewed tree")
    tree5 = build_tree([1, None, 2, None, 3, None, 4])
    print("Tree structure:")
    print_tree(tree5)
    print(f"Inorder: {inorderRecursive(tree5)}")

    # Test Case 6: BST - should give sorted order
    print("\n" + "-" * 40)
    print("Test Case 6: BST (should give sorted order)")
    # Build BST:     4
    #              /   \
    #             2     6
    #            / \   / \
    #           1   3 5   7
    bst = TreeNode(4)
    bst.left = TreeNode(2, TreeNode(1), TreeNode(3))
    bst.right = TreeNode(6, TreeNode(5), TreeNode(7))
    print("BST structure:")
    print_tree(bst)
    print(f"Inorder (sorted!): {inorderRecursive(bst)}")

    # Comparison of all methods
    print("\n" + "=" * 60)
    print("COMPARISON OF ALL METHODS")
    print("=" * 60)

    test_tree = build_tree([1, 2, 3, 4, 5, 6, 7])
    print("\nTest tree:")
    print_tree(test_tree)
    print(f"\nRecursive:  {inorderRecursive(test_tree)}")
    print(f"Iterative:  {inorderIterative(test_tree)}")
    print(f"Morris:     {inorderMorris(test_tree)}")

    print("\n" + "=" * 60)
    print("All tests completed!")
    print("=" * 60)
