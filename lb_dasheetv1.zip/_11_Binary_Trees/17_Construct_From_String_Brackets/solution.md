# Construct Binary Tree from String with Brackets

## Problem Statement

Given a string consisting of parentheses and integers, construct the binary tree it represents.

**Format:** `"root(left)(right)"` where left and right subtrees are recursively represented.

## Example

```
Input: "4(2(3)(1))(6(5))"

Output:
        4
       / \
      2   6
     / \ /
    3  1 5

Explanation:
- 4 is root
- (2(3)(1)) is left subtree
- (6(5)) is right subtree
```

---

## Visualization

```
String: "4(2(3)(1))(6(5))"

Parsing:
4           -> Root = 4
(           -> Start left subtree
  2         -> Left child = 2
  (3)       -> Left's left = 3
  (1)       -> Left's right = 1
)           -> End left subtree
(           -> Start right subtree
  6         -> Right child = 6
  (5)       -> Right's left = 5
)           -> End right subtree

Tree:
        4
       / \
      2   6
     / \ /
    3  1 5
```

---

## Intuition: Recursive Parsing

**Key Observations:**
1. Number comes first (possibly negative)
2. `(` indicates start of child subtree
3. `)` indicates end of subtree
4. First `(...)` is left child, second `(...)` is right child

**Leap of Faith:** Trust that recursive calls will correctly build subtrees!

---

## Approach 1: Recursive with Index Tracking

### Algorithm

```
1. Parse the number (root value)
2. If '(' found:
   - Recurse to build left subtree
   - If another '(' found, recurse for right subtree
3. Return constructed node
```

### Recursion Tree

```
construct("4(2(3)(1))(6(5))")
    |
    +-- root = 4
    |
    +-- construct("2(3)(1)")  [left]
    |       |
    |       +-- root = 2
    |       +-- construct("3") = Node(3)
    |       +-- construct("1") = Node(1)
    |       return Node(2, 3, 1)
    |
    +-- construct("6(5)")  [right]
            |
            +-- root = 6
            +-- construct("5") = Node(5)
            return Node(6, 5, None)
    
    return Node(4, left=Node(2,3,1), right=Node(6,5,None))
```

### Code

```python
def str2tree(s):
    if not s:
        return None
    
    idx = [0]  # Use list for mutable index
    
    def build():
        if idx[0] >= len(s):
            return None
        
        # Parse number
        start = idx[0]
        if s[idx[0]] == '-':
            idx[0] += 1
        while idx[0] < len(s) and s[idx[0]].isdigit():
            idx[0] += 1
        
        node = TreeNode(int(s[start:idx[0]]))
        
        # Parse left subtree
        if idx[0] < len(s) and s[idx[0]] == '(':
            idx[0] += 1  # Skip '('
            node.left = build()
            idx[0] += 1  # Skip ')'
        
        # Parse right subtree
        if idx[0] < len(s) and s[idx[0]] == '(':
            idx[0] += 1  # Skip '('
            node.right = build()
            idx[0] += 1  # Skip ')'
        
        return node
    
    return build()
```

### Dry Run

```
s = "4(2(3)(1))(6(5))"

build() at idx=0:
  Parse "4", idx=1
  node = TreeNode(4)
  
  s[1] = '(', idx=2
  node.left = build():
    Parse "2", idx=3
    node = TreeNode(2)
    
    s[3] = '(', idx=4
    node.left = build():
      Parse "3", idx=5
      return TreeNode(3)
    idx=6 (skip ')')
    
    s[6] = '(', idx=7
    node.right = build():
      Parse "1", idx=8
      return TreeNode(1)
    idx=9 (skip ')')
    
    return TreeNode(2, left=3, right=1)
  idx=10 (skip ')')
  
  s[10] = '(', idx=11
  node.right = build():
    Parse "6", idx=12
    ...continue similarly
```

---

## Approach 2: Stack-based Iterative

### Algorithm

```
1. Use stack to track parent nodes
2. When number found: create node, attach to parent
3. When '(': push current node to stack
4. When ')': pop from stack
```

### Code

```python
def str2treeIterative(s):
    if not s:
        return None
    
    stack = []
    i = 0
    
    while i < len(s):
        if s[i] == ')':
            stack.pop()
            i += 1
        elif s[i] == '(':
            i += 1
        else:
            # Parse number
            j = i
            if s[i] == '-':
                i += 1
            while i < len(s) and s[i].isdigit():
                i += 1
            
            node = TreeNode(int(s[j:i]))
            
            if stack:
                parent = stack[-1]
                if not parent.left:
                    parent.left = node
                else:
                    parent.right = node
            
            stack.append(node)
    
    return stack[0] if stack else None
```

---

## Complexity Analysis

| Approach | Time | Space |
|----------|------|-------|
| Recursive | O(N) | O(H) for recursion |
| Stack-based | O(N) | O(H) for stack |

Where N = length of string, H = height of tree.

---

## Edge Cases

| Case | Input | Output |
|------|-------|--------|
| Empty string | `""` | `None` |
| Single node | `"5"` | `TreeNode(5)` |
| Negative number | `"-4(2)(3)"` | Root = -4 |
| Left child only | `"1(2)"` | `1 -> 2` |
| Deep nesting | `"1(2(3(4)))"` | Chain |

---

## Key Takeaways

1. **Parse numbers carefully:** Handle negatives and multi-digit
2. **Track index:** Use mutable container (list) in Python
3. **Two children rule:** First `()` is left, second is right
4. **Stack alternative:** Can be done iteratively with stack
5. **Balanced parens:** Input assumed to be valid

---

## Related Problems

- Construct Binary Tree from Preorder and Inorder (LeetCode 105)
- Serialize and Deserialize Binary Tree (LeetCode 297)
- Construct String from Binary Tree (LeetCode 606)
- Recover a Tree From Preorder Traversal (LeetCode 1028)
