"""
Construct Binary Tree from String with Bracket Representation
=============================================================

Problem: Given a string with format "root(left)(right)", construct the tree.

Example:
    Input: "4(2(3)(1))(6(5))"

    Output:
            4
           / \
          2   6
         / \ /
        3  1 5
"""

from collections import deque
from typing import List, Optional


class TreeNode:
    """Binary Tree Node"""
    def __init__(self, val: int = 0, left: 'TreeNode' = None, right: 'TreeNode' = None):
        self.val = val
        self.left = left
        self.right = right


# =============================================================================
# SOLUTION 1: Recursive with Index Tracking
# =============================================================================

def str2tree(s: str) -> Optional[TreeNode]:
    """
    Construct binary tree from string representation.

    Format: "root(left_subtree)(right_subtree)"

    Algorithm:
    1. Parse number for current node
    2. If '(' found, recursively build left subtree
    3. If another '(' found, build right subtree
    4. Return node

    Time Complexity: O(N)
    Space Complexity: O(H) for recursion

    Args:
        s: String representation of tree

    Returns:
        Root of constructed tree
    """
    if not s:
        return None

    idx = [0]  # Use list for mutable index in nested function

    def build() -> Optional[TreeNode]:
        if idx[0] >= len(s):
            return None

        # Parse number (handle negative numbers)
        start = idx[0]
        if s[idx[0]] == '-':
            idx[0] += 1
        while idx[0] < len(s) and s[idx[0]].isdigit():
            idx[0] += 1

        node = TreeNode(int(s[start:idx[0]]))

        # Parse left subtree if exists
        if idx[0] < len(s) and s[idx[0]] == '(':
            idx[0] += 1  # Skip '('
            node.left = build()
            idx[0] += 1  # Skip ')'

        # Parse right subtree if exists
        if idx[0] < len(s) and s[idx[0]] == '(':
            idx[0] += 1  # Skip '('
            node.right = build()
            idx[0] += 1  # Skip ')'

        return node

    return build()


# =============================================================================
# SOLUTION 2: Stack-based Iterative
# =============================================================================

def str2treeIterative(s: str) -> Optional[TreeNode]:
    """
    Iterative solution using stack.

    Algorithm:
    1. Parse numbers and create nodes
    2. Use stack to track parent-child relationships
    3. '(' means go deeper, ')' means go back up

    Time: O(N), Space: O(H)
    """
    if not s:
        return None

    stack = []
    i = 0

    while i < len(s):
        if s[i] == ')':
            # End of subtree, pop from stack
            stack.pop()
            i += 1
        elif s[i] == '(':
            # Start of subtree, just skip
            i += 1
        else:
            # Parse number
            j = i
            if s[i] == '-':
                i += 1
            while i < len(s) and s[i].isdigit():
                i += 1

            node = TreeNode(int(s[j:i]))

            # Attach to parent if exists
            if stack:
                parent = stack[-1]
                if not parent.left:
                    parent.left = node
                else:
                    parent.right = node

            stack.append(node)

    return stack[0] if stack else None


# =============================================================================
# SOLUTION 3: Recursive with String Slicing (Less Efficient)
# =============================================================================

def str2treeSlicing(s: str) -> Optional[TreeNode]:
    """
    Alternative recursive approach using string slicing.

    Less efficient due to string copies but easier to understand.

    Time: O(N^2) worst case due to slicing
    Space: O(N) for string copies
    """
    if not s:
        return None

    # Find the first '(' - everything before is the root value
    first_paren = s.find('(')

    if first_paren == -1:
        # No children, just a number
        return TreeNode(int(s))

    root_val = int(s[:first_paren])
    node = TreeNode(root_val)

    # Find matching ')' for left subtree
    count = 0
    left_start = first_paren + 1
    left_end = left_start

    for i in range(first_paren, len(s)):
        if s[i] == '(':
            count += 1
        elif s[i] == ')':
            count -= 1
            if count == 0:
                left_end = i
                break

    # Build left subtree
    node.left = str2treeSlicing(s[left_start:left_end])

    # Build right subtree (if exists)
    if left_end + 1 < len(s) and s[left_end + 1] == '(':
        # Right subtree exists
        right_start = left_end + 2
        right_end = len(s) - 1  # Last ')' closes right subtree
        node.right = str2treeSlicing(s[right_start:right_end])

    return node


# =============================================================================
# BONUS: Convert Tree Back to String
# =============================================================================

def tree2str(root: Optional[TreeNode]) -> str:
    """
    Convert tree back to string representation.

    Note: This produces minimal representation where:
    - Empty right subtree: omit "()"
    - Empty left subtree with right present: keep "()"
    """
    if not root:
        return ""

    result = str(root.val)

    if root.left or root.right:
        # Must include left subtree
        result += "(" + tree2str(root.left) + ")"

    if root.right:
        # Include right subtree only if it exists
        result += "(" + tree2str(root.right) + ")"

    return result


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def build_tree_from_list(values: List[Optional[int]]) -> Optional[TreeNode]:
    """Build binary tree from level-order list representation."""
    if not values or values[0] is None:
        return None

    root = TreeNode(values[0])
    queue = deque([root])
    i = 1

    while queue and i < len(values):
        node = queue.popleft()

        if i < len(values) and values[i] is not None:
            node.left = TreeNode(values[i])
            queue.append(node.left)
        i += 1

        if i < len(values) and values[i] is not None:
            node.right = TreeNode(values[i])
            queue.append(node.right)
        i += 1

    return root


def print_tree(root: Optional[TreeNode], level: int = 0, prefix: str = "Root: "):
    """Print tree structure for visualization."""
    if root is not None:
        print(" " * (level * 4) + prefix + str(root.val))
        if root.left or root.right:
            if root.left:
                print_tree(root.left, level + 1, "L--- ")
            else:
                print(" " * ((level + 1) * 4) + "L--- None")
            if root.right:
                print_tree(root.right, level + 1, "R--- ")
            else:
                print(" " * ((level + 1) * 4) + "R--- None")


def trees_equal(t1: Optional[TreeNode], t2: Optional[TreeNode]) -> bool:
    """Check if two trees are identical."""
    if not t1 and not t2:
        return True
    if not t1 or not t2:
        return False
    return (t1.val == t2.val and
            trees_equal(t1.left, t2.left) and
            trees_equal(t1.right, t2.right))


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("CONSTRUCT TREE FROM STRING - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal case
    print("\nTest Case 1: '4(2(3)(1))(6(5))'")
    print("-" * 40)
    s1 = "4(2(3)(1))(6(5))"
    tree1_rec = str2tree(s1)
    tree1_iter = str2treeIterative(s1)
    tree1_slice = str2treeSlicing(s1)
    print("Recursive result:")
    print_tree(tree1_rec)
    print(f"\nAll methods equal: {trees_equal(tree1_rec, tree1_iter) and trees_equal(tree1_rec, tree1_slice)}")
    print(f"Back to string: {tree2str(tree1_rec)}")

    # Test Case 2: Empty string
    print("\n" + "-" * 40)
    print("Test Case 2: Empty string")
    print(f"Result: {str2tree('')}")

    # Test Case 3: Single node
    print("\n" + "-" * 40)
    print("Test Case 3: '42'")
    tree3 = str2tree("42")
    print_tree(tree3)

    # Test Case 4: Negative numbers
    print("\n" + "-" * 40)
    print("Test Case 4: '-4(2)(-3)'")
    tree4 = str2tree("-4(2)(-3)")
    print_tree(tree4)

    # Test Case 5: Left child only
    print("\n" + "-" * 40)
    print("Test Case 5: '1(2(3(4)))'")
    tree5 = str2tree("1(2(3(4)))")
    print_tree(tree5)

    # Test Case 6: Right child only
    print("\n" + "-" * 40)
    print("Test Case 6: '1()(2)'")
    tree6 = str2tree("1()(2)")
    print_tree(tree6)

    # Test Case 7: Complex tree
    print("\n" + "-" * 40)
    print("Test Case 7: '1(2(4)(5(7)(8)))(3(6))'")
    tree7 = str2tree("1(2(4)(5(7)(8)))(3(6))")
    print_tree(tree7)

    # Comparison
    print("\n" + "=" * 60)
    print("ROUND-TRIP TEST (string -> tree -> string)")
    print("=" * 60)

    test_strings = [
        "4(2(3)(1))(6(5))",
        "1(2)(3)",
        "5",
        "-1(-2)(3)",
    ]

    for s in test_strings:
        tree = str2tree(s)
        back = tree2str(tree)
        tree_again = str2tree(back)
        match = trees_equal(tree, tree_again)
        print(f"'{s}' -> tree -> '{back}' | Match: {match}")

    print("\n" + "=" * 60)
    print("All tests completed!")
    print("=" * 60)
