# Binary Trees - Complete Guide

## Table of Contents
1. [Introduction](#introduction)
2. [Tree Terminology](#tree-terminology)
3. [Binary Tree Properties](#binary-tree-properties)
4. [Types of Binary Trees](#types-of-binary-trees)
5. [Tree Traversals](#tree-traversals)
6. [Recursive vs Iterative Traversals](#recursive-vs-iterative-traversals)
7. [Time and Space Complexity](#time-and-space-complexity)

---

## Introduction

A **Binary Tree** is a hierarchical data structure in which each node has at most two children, referred to as the **left child** and **right child**. Unlike linear data structures (arrays, linked lists), trees are non-linear and allow for efficient searching, insertion, and deletion operations.

```
        1           <-- Root
       / \
      2   3         <-- Level 1
     / \   \
    4   5   6       <-- Level 2 (Leaves: 4, 5, 6)
```

---

## Tree Terminology

### Basic Terms

| Term | Definition | Example |
|------|------------|---------|
| **Node** | Basic unit containing data and references to children | Each circle in the tree |
| **Root** | The topmost node (no parent) | Node 1 in above example |
| **Leaf** | A node with no children | Nodes 4, 5, 6 |
| **Edge** | Connection between parent and child | Lines connecting nodes |
| **Parent** | Node with child(ren) | Node 2 is parent of 4, 5 |
| **Child** | Node connected below a parent | Nodes 4, 5 are children of 2 |
| **Sibling** | Nodes sharing the same parent | Nodes 4 and 5 are siblings |
| **Ancestor** | Any node on path from root to current node | 1, 2 are ancestors of 4 |
| **Descendant** | Any node in subtree of current node | 4, 5 are descendants of 2 |

### Measurement Terms

| Term | Definition | Formula/Example |
|------|------------|-----------------|
| **Height of Node** | Longest path from node to any leaf | Height of root = height of tree |
| **Height of Tree** | Height of the root node | For above tree: 2 |
| **Depth of Node** | Path length from root to node | Depth of node 4 = 2 |
| **Level** | Depth + 1 (some definitions say level = depth) | Root is at level 0 or 1 |
| **Degree** | Number of children of a node | Degree of node 2 = 2 |

### Visual Representation of Height and Depth

```
Height = 2    Depth = 0       1           Level 0
                             / \
Height = 1    Depth = 1     2   3         Level 1
                           / \   \
Height = 0    Depth = 2   4   5   6       Level 2

Note: Height decreases as we go down; Depth increases as we go down
```

---

## Binary Tree Properties

### Mathematical Properties

1. **Maximum nodes at level L**: 2^L (if root is at level 0)
   - Level 0: 2^0 = 1 node (root)
   - Level 1: 2^1 = 2 nodes
   - Level 2: 2^2 = 4 nodes

2. **Maximum nodes in tree of height H**: 2^(H+1) - 1
   - Height 0: 2^1 - 1 = 1 node
   - Height 1: 2^2 - 1 = 3 nodes
   - Height 2: 2^3 - 1 = 7 nodes

3. **Minimum height for N nodes**: ceil(log2(N+1)) - 1 or floor(log2(N))

4. **Number of leaf nodes vs internal nodes**:
   - In a full binary tree: L = I + 1 (leaves = internal + 1)

5. **Number of NULL pointers**: N + 1 (where N is total nodes)
   - Each node has 2 pointers, total = 2N
   - Non-NULL pointers = N - 1 (edges)
   - NULL pointers = 2N - (N-1) = N + 1

---

## Types of Binary Trees

### 1. Full Binary Tree (Strictly Binary Tree)
Every node has **0 or 2 children** (never 1).

```
        1
       / \
      2   3
     / \
    4   5

Valid: Every internal node has exactly 2 children
```

**Properties:**
- L = I + 1 (Leaves = Internal nodes + 1)
- Total nodes = 2L - 1 = 2I + 1

### 2. Complete Binary Tree
All levels completely filled except possibly the last, which is filled **left to right**.

```
        1             1
       / \           / \
      2   3         2   3
     / \           / \ /
    4   5         4  5 6

  Complete         Complete
```

```
        1
       / \
      2   3
       \
        5

  NOT Complete (5 should be left child)
```

**Properties:**
- Height = floor(log2(N))
- Used in **Heaps**
- Can be efficiently stored in arrays

### 3. Perfect Binary Tree
All internal nodes have 2 children AND all leaves are at the same level.

```
        1
       / \
      2   3
     / \ / \
    4  5 6  7

All leaves (4,5,6,7) at same level
```

**Properties:**
- Total nodes = 2^(H+1) - 1
- Leaves = 2^H
- Internal nodes = 2^H - 1

### 4. Balanced Binary Tree
Height difference between left and right subtrees is at most 1 for **every node**.

```
        1              1
       / \            / \
      2   3          2   3
     /              /     \
    4              4       5

  Balanced        Balanced
```

```
        1
       /
      2
     /
    3

  NOT Balanced (height diff > 1)
```

**Properties:**
- Height = O(log N)
- Examples: AVL Tree, Red-Black Tree

### 5. Degenerate (Skewed) Tree
Each node has only one child, essentially a linked list.

```
    1           1
     \         /
      2       2
       \     /
        3   3

Right Skewed  Left Skewed
```

**Properties:**
- Height = N - 1 (worst case)
- Operations become O(N) instead of O(log N)

### Comparison Table

| Type | Definition | Height | Use Case |
|------|------------|--------|----------|
| Full | 0 or 2 children | O(N) to O(log N) | Expression trees |
| Complete | Left-filled levels | O(log N) | Heaps, Priority Queues |
| Perfect | All leaves same level | O(log N) | Theoretical analysis |
| Balanced | Height diff <= 1 | O(log N) | BST, AVL, Red-Black |
| Skewed | One child only | O(N) | Avoid this! |

---

## Tree Traversals

Tree traversal means visiting every node exactly once. There are two main categories:

### 1. Depth-First Traversals (DFS)
Goes deep before going wide. Uses **recursion** or **stack**.

#### Inorder Traversal (Left -> Root -> Right)
```
        1
       / \
      2   3
     / \
    4   5

Visit order: 4 -> 2 -> 5 -> 1 -> 3

Process:
1. Go to leftmost node (4)
2. Visit it
3. Go to parent (2)
4. Visit right child (5)
5. Go to root (1)
6. Visit right subtree (3)
```

**Use Case**: In BST, gives sorted order!

#### Preorder Traversal (Root -> Left -> Right)
```
        1
       / \
      2   3
     / \
    4   5

Visit order: 1 -> 2 -> 4 -> 5 -> 3

Process:
1. Visit root (1)
2. Visit left subtree completely (2 -> 4 -> 5)
3. Visit right subtree (3)
```

**Use Case**: Create a copy of tree, prefix expression

#### Postorder Traversal (Left -> Right -> Root)
```
        1
       / \
      2   3
     / \
    4   5

Visit order: 4 -> 5 -> 2 -> 3 -> 1

Process:
1. Visit left subtree completely (4 -> 5 -> 2)
2. Visit right subtree (3)
3. Visit root (1)
```

**Use Case**: Delete tree, postfix expression, calculate folder size

### 2. Breadth-First Traversal (BFS)
Goes level by level. Uses **queue**.

#### Level Order Traversal
```
        1
       / \
      2   3
     / \   \
    4   5   6

Visit order: 1 -> 2 -> 3 -> 4 -> 5 -> 6

Level 0: 1
Level 1: 2, 3
Level 2: 4, 5, 6
```

**Use Case**: Find minimum depth, level-wise processing

### Traversal Comparison

| Traversal | Order | Data Structure | Use Case |
|-----------|-------|----------------|----------|
| Inorder | L-Root-R | Stack/Recursion | Sorted order in BST |
| Preorder | Root-L-R | Stack/Recursion | Copy tree, serialize |
| Postorder | L-R-Root | Stack/Recursion | Delete tree, postfix |
| Level Order | Level by level | Queue | BFS, shortest path |

### Memory Aid: Where is ROOT?

```
INorder   -> Root in the MIDDLE  (L-Root-R)
PREorder  -> Root FIRST          (Root-L-R)  
POSTorder -> Root LAST           (L-R-Root)
```

---

## Recursive vs Iterative Traversals

### Recursive Approach

**Advantages:**
- Clean, intuitive code
- Mirrors tree's recursive structure
- Easy to understand and implement

**Disadvantages:**
- Uses call stack (risk of stack overflow for deep trees)
- Function call overhead
- Space: O(H) for call stack

```python
def inorder_recursive(root):
    if root is None:
        return
    inorder_recursive(root.left)   # Process left
    print(root.val)                 # Process root
    inorder_recursive(root.right)  # Process right
```

### Iterative Approach

**Advantages:**
- No stack overflow risk
- More control over traversal
- Often faster (no function call overhead)

**Disadvantages:**
- More complex code
- Need to manually manage stack
- Harder to understand initially

```python
def inorder_iterative(root):
    stack = []
    current = root
    
    while stack or current:
        # Go left as far as possible
        while current:
            stack.append(current)
            current = current.left
        
        # Process current node
        current = stack.pop()
        print(current.val)
        
        # Move to right subtree
        current = current.right
```

### When to Use Which?

| Scenario | Recommended | Reason |
|----------|-------------|--------|
| Interview (correctness) | Recursive | Cleaner, less bug-prone |
| Very deep trees | Iterative | Avoid stack overflow |
| Need to pause/resume | Iterative | Manual stack control |
| Quick implementation | Recursive | Faster to write |

---

## Time and Space Complexity

### Traversal Complexities

| Operation | Time | Space (Recursive) | Space (Iterative) |
|-----------|------|-------------------|-------------------|
| Inorder | O(N) | O(H) | O(H) |
| Preorder | O(N) | O(H) | O(H) |
| Postorder | O(N) | O(H) | O(H) |
| Level Order | O(N) | N/A | O(W) |

Where:
- N = Number of nodes
- H = Height of tree (log N for balanced, N for skewed)
- W = Maximum width (N/2 for complete tree at last level)

### Common Operations Complexity

| Operation | Best (Balanced) | Worst (Skewed) |
|-----------|-----------------|----------------|
| Search | O(log N) | O(N) |
| Insert | O(log N) | O(N) |
| Delete | O(log N) | O(N) |
| Find Height | O(N) | O(N) |
| Find Diameter | O(N) | O(N) |

### Space Complexity Analysis

**Recursive Traversal:**
```
        1
       / \
      2   3
     /
    4

Call Stack for Inorder:
[inorder(1)] -> [inorder(2)] -> [inorder(4)] -> return
                               [inorder(None)] -> return
              <- print(2)
              [inorder(5)]
...

Max stack depth = Height of tree
```

**Level Order (Queue-based):**
```
        1
       / \
      2   3
     / \ / \
    4  5 6  7

Queue states:
[1]           -> Process 1
[2, 3]        -> Process 2
[3, 4, 5]     -> Process 3
[4, 5, 6, 7]  -> Max width = 4 = N/2

Space = O(Width) = O(N) in worst case
```

---

## Summary

### Key Takeaways

1. **Binary trees** are hierarchical structures with at most 2 children per node
2. **Height** is counted downward (to leaves), **depth** upward (from root)
3. **Complete trees** enable array representation and are used in heaps
4. **Balanced trees** guarantee O(log N) operations
5. **DFS traversals** (in/pre/post) use stack; **BFS** (level order) uses queue
6. **Recursive** code is cleaner; **iterative** avoids stack overflow
7. All traversals are **O(N)** time since we visit each node once

### Common Patterns

1. **Recursion Template:**
   ```python
   def solve(root):
       if root is None:
           return base_case
       
       left_result = solve(root.left)
       right_result = solve(root.right)
       
       return combine(left_result, right_result, root.val)
   ```

2. **Level Order Template:**
   ```python
   def level_order(root):
       if not root:
           return []
       
       queue = deque([root])
       result = []
       
       while queue:
           level_size = len(queue)
           for _ in range(level_size):
               node = queue.popleft()
               result.append(node.val)
               if node.left:
                   queue.append(node.left)
               if node.right:
                   queue.append(node.right)
       
       return result
   ```

### Practice Problems (In This Course)

1. Level Order Traversal
2. Reverse Level Order Traversal
3. Height of a Tree
4. Diameter of a Tree
5. Mirror of a Tree
6. Inorder Traversal (Recursive & Iterative)
7. Preorder Traversal (Recursive & Iterative)
8. Postorder Traversal (Recursive & Iterative)
9. Left View of a Tree
10. Right View of a Tree
11. Top View of a Tree
12. Bottom View of a Tree

---

*Happy Learning! Master trees, and you'll ace half the interview questions!*
