# Product Array Puzzle

## Problem Statement

Given an array `arr[]` of `n` integers, construct a product array `result[]` where `result[i]` is equal to the product of all elements of `arr[]` **except** `arr[i]`.

**Constraint**: Solve it **without using division operator**.

**Example 1:**
```
Input: arr = [10, 3, 5, 6, 2]
Output: [180, 600, 360, 300, 900]
Explanation: 
  result[0] = 3*5*6*2 = 180
  result[1] = 10*5*6*2 = 600
  result[2] = 10*3*6*2 = 360
  result[3] = 10*3*5*2 = 300
  result[4] = 10*3*5*6 = 900
```

**Example 2:**
```
Input: arr = [1, 2, 3, 4, 5]
Output: [120, 60, 40, 30, 24]
```

---

## Approach Intuition

### Why No Division?
- If we could use division: `result[i] = totalProduct / arr[i]`
- But what if `arr[i] = 0`? Division fails!
- Also, the problem explicitly forbids it

### Key Insight: Prefix and Suffix Products
For each index `i`, the product of all elements except `arr[i]` is:
```
result[i] = (product of elements BEFORE i) * (product of elements AFTER i)
          = prefix[i] * suffix[i]
```

---

## Brute Force Approach

### Algorithm
For each index, multiply all other elements.

### Code
```python
def product_except_self_brute(arr):
    n = len(arr)
    result = []
    
    for i in range(n):
        product = 1
        for j in range(n):
            if i != j:
                product *= arr[j]
        result.append(product)
    
    return result
```

### Complexity
- **Time**: O(n^2)
- **Space**: O(n) for result

---

## Optimal Approach: Prefix and Suffix Products

### Algorithm
1. Create `prefix[]` where `prefix[i] = arr[0] * arr[1] * ... * arr[i-1]`
2. Create `suffix[]` where `suffix[i] = arr[i+1] * arr[i+2] * ... * arr[n-1]`
3. `result[i] = prefix[i] * suffix[i]`

### Visualization

```
Array: [10, 3, 5, 6, 2]
Index:   0  1  2  3  4

=== Building Prefix Products ===
prefix[0] = 1              (nothing before index 0)
prefix[1] = 10             (arr[0])
prefix[2] = 10*3 = 30      (arr[0]*arr[1])
prefix[3] = 10*3*5 = 150   (arr[0]*arr[1]*arr[2])
prefix[4] = 10*3*5*6 = 900 (arr[0]*arr[1]*arr[2]*arr[3])

prefix = [1, 10, 30, 150, 900]

=== Building Suffix Products ===
suffix[4] = 1              (nothing after index 4)
suffix[3] = 2              (arr[4])
suffix[2] = 6*2 = 12       (arr[3]*arr[4])
suffix[1] = 5*6*2 = 60     (arr[2]*arr[3]*arr[4])
suffix[0] = 3*5*6*2 = 180  (arr[1]*arr[2]*arr[3]*arr[4])

suffix = [180, 60, 12, 2, 1]

=== Computing Result ===
result[0] = prefix[0] * suffix[0] = 1 * 180 = 180
result[1] = prefix[1] * suffix[1] = 10 * 60 = 600
result[2] = prefix[2] * suffix[2] = 30 * 12 = 360
result[3] = prefix[3] * suffix[3] = 150 * 2 = 300
result[4] = prefix[4] * suffix[4] = 900 * 1 = 900

result = [180, 600, 360, 300, 900]
```

### Search Space Reduction (Space Optimization)

```
Instead of two arrays, use ONE result array:

Pass 1 (left to right): Store prefix products in result
Pass 2 (right to left): Multiply by suffix on-the-fly

Space: O(n) for output only -> O(1) extra space!
```

---

## Dry Run with Different Example

```
Array: [1, 2, 3, 4]
Index:  0  1  2  3

Pass 1 - Build prefix in result:
  result[0] = 1
  result[1] = result[0] * arr[0] = 1 * 1 = 1
  result[2] = result[1] * arr[1] = 1 * 2 = 2
  result[3] = result[2] * arr[2] = 2 * 3 = 6
  
  result = [1, 1, 2, 6]

Pass 2 - Multiply suffix:
  suffix = 1
  
  i=3: result[3] = result[3] * suffix = 6 * 1 = 6
       suffix = suffix * arr[3] = 1 * 4 = 4
       
  i=2: result[2] = result[2] * suffix = 2 * 4 = 8
       suffix = suffix * arr[2] = 4 * 3 = 12
       
  i=1: result[1] = result[1] * suffix = 1 * 12 = 12
       suffix = suffix * arr[1] = 12 * 2 = 24
       
  i=0: result[0] = result[0] * suffix = 1 * 24 = 24
       suffix = suffix * arr[0] = 24 * 1 = 24

Final result = [24, 12, 8, 6]

Verify: 2*3*4=24, 1*3*4=12, 1*2*4=8, 1*2*3=6 ✓
```

---

## Code Implementation

```python
def product_except_self(arr):
    n = len(arr)
    result = [1] * n
    
    # Pass 1: Calculate prefix products
    prefix = 1
    for i in range(n):
        result[i] = prefix
        prefix *= arr[i]
    
    # Pass 2: Multiply by suffix products
    suffix = 1
    for i in range(n - 1, -1, -1):
        result[i] *= suffix
        suffix *= arr[i]
    
    return result
```

---

## Handling Zeros

```
If array contains ONE zero:
  - All positions except zero's position will have product 0
  - Zero's position will have product of all non-zero elements

If array contains MORE THAN ONE zero:
  - All positions will have product 0

Example: [1, 2, 0, 4]
  result[0] = 2*0*4 = 0
  result[1] = 1*0*4 = 0
  result[2] = 1*2*4 = 8  (only non-zero!)
  result[3] = 1*2*0 = 0
```

---

## Time and Space Complexity

### Optimal Approach
- **Time Complexity**: O(n)
  - Two passes through the array
  
- **Space Complexity**: O(1) extra
  - Result array doesn't count as extra space
  - Only using a variable for running product

### Comparison
| Approach | Time | Space |
|----------|------|-------|
| Brute Force | O(n^2) | O(n) |
| With Division | O(n) | O(n) |
| Prefix/Suffix | O(n) | O(n) |
| Space Optimized | O(n) | O(1) extra |

---

## Key Takeaways

1. **Prefix-Suffix pattern**: Common technique for "all except current" problems

2. **Two-pass technique**: Build prefix in first pass, multiply suffix in second

3. **Space optimization**: Store intermediate results in output array

4. **Handle edge cases**: 
   - Empty array
   - Single element
   - Zeros in array (one zero vs multiple zeros)

5. **No division needed**: This solution works even with zeros!

6. **Related problems**:
   - Trapping Rain Water (prefix max, suffix max)
   - Maximum Product Subarray
