"""
Product Array Puzzle
====================

Problem: Given an array, construct a product array where each element
is the product of all elements except the element at that index.
Solve WITHOUT using division operator.

Time Complexity: O(n)
Space Complexity: O(1) extra (output array doesn't count)
"""


def product_except_self_brute(arr: list) -> list:
    """
    Brute Force: For each index, multiply all other elements.

    Time: O(n^2)
    Space: O(n)
    """
    n = len(arr)
    result = []

    for i in range(n):
        product = 1
        for j in range(n):
            if i != j:
                product *= arr[j]
        result.append(product)

    return result


def product_except_self_with_arrays(arr: list) -> list:
    """
    Using separate prefix and suffix arrays.
    Clearer logic but uses O(n) extra space.

    Time: O(n)
    Space: O(n)
    """
    n = len(arr)
    if n == 0:
        return []

    # prefix[i] = product of arr[0..i-1]
    prefix = [1] * n
    for i in range(1, n):
        prefix[i] = prefix[i - 1] * arr[i - 1]

    # suffix[i] = product of arr[i+1..n-1]
    suffix = [1] * n
    for i in range(n - 2, -1, -1):
        suffix[i] = suffix[i + 1] * arr[i + 1]

    # result[i] = prefix[i] * suffix[i]
    result = [prefix[i] * suffix[i] for i in range(n)]

    return result


def product_except_self(arr: list) -> list:
    """
    Space-optimized solution using only output array.

    Pass 1: Store prefix products in result
    Pass 2: Multiply by suffix products on-the-fly

    Time: O(n)
    Space: O(1) extra
    """
    n = len(arr)
    if n == 0:
        return []

    result = [1] * n

    # Pass 1: Calculate prefix products
    # result[i] = arr[0] * arr[1] * ... * arr[i-1]
    prefix = 1
    for i in range(n):
        result[i] = prefix
        prefix *= arr[i]

    # Pass 2: Multiply by suffix products
    # Multiply result[i] by arr[i+1] * arr[i+2] * ... * arr[n-1]
    suffix = 1
    for i in range(n - 1, -1, -1):
        result[i] *= suffix
        suffix *= arr[i]

    return result


def product_except_self_handle_zeros(arr: list) -> list:
    """
    Explicit handling of zeros for clarity.

    - 0 zeros: Normal calculation
    - 1 zero: Only zero's position is non-zero
    - 2+ zeros: All zeros
    """
    n = len(arr)
    zero_count = arr.count(0)

    if zero_count > 1:
        # More than one zero: all products are zero
        return [0] * n

    if zero_count == 1:
        # Exactly one zero
        zero_idx = arr.index(0)
        product_without_zero = 1
        for i, val in enumerate(arr):
            if i != zero_idx:
                product_without_zero *= val

        result = [0] * n
        result[zero_idx] = product_without_zero
        return result

    # No zeros: use standard approach
    return product_except_self(arr)


# ==================== TEST CASES ====================

def test_product_array():
    """Comprehensive test cases."""

    print("=" * 60)
    print("PRODUCT ARRAY PUZZLE")
    print("=" * 60)

    test_cases = [
        # (array, expected)
        ([10, 3, 5, 6, 2], [180, 600, 360, 300, 900]),
        ([1, 2, 3, 4, 5], [120, 60, 40, 30, 24]),
        ([1, 2, 3, 4], [24, 12, 8, 6]),
        ([2, 3], [3, 2]),
        ([5], [1]),  # Single element
        ([], []),     # Empty
        ([1, 2, 0, 4], [0, 0, 8, 0]),  # One zero
        ([0, 0, 2, 3], [0, 0, 0, 0]),  # Multiple zeros
        ([1, 1, 1, 1], [1, 1, 1, 1]),  # All ones
        ([-1, 2, -3, 4], [-24, 12, -8, 6]),  # Negative numbers
    ]

    all_passed = True

    for i, (arr, expected) in enumerate(test_cases, 1):
        result = product_except_self(arr.copy())
        brute_result = product_except_self_brute(arr.copy())
        status = "PASS" if result == expected else "FAIL"

        if result != expected:
            all_passed = False

        print(f"\nTest {i}: {status}")
        print(f"  Array: {arr}")
        print(f"  Expected: {expected}")
        print(f"  Optimized: {result}")
        print(f"  Brute force: {brute_result}")

    # Compare all implementations
    print("\n" + "-" * 60)
    print("Comparing All Implementations:")
    print("-" * 60)

    for arr, expected in test_cases[:5]:
        r1 = product_except_self(arr.copy())
        r2 = product_except_self_with_arrays(arr.copy())
        r3 = product_except_self_handle_zeros(arr.copy())

        all_same = r1 == r2 == r3 == expected
        print(f"  {arr} -> {r1} [{'PASS' if all_same else 'FAIL'}]")

    print("\n" + "=" * 60)
    print(f"All tests passed: {all_passed}")
    print("=" * 60)


def visualize_algorithm(arr: list):
    """Visualize the prefix-suffix product algorithm."""

    print(f"\nVisualizing Product Except Self")
    print(f"Array: {arr}")
    print("=" * 60)

    n = len(arr)
    if n == 0:
        print("Empty array!")
        return

    result = [1] * n

    # Pass 1: Prefix products
    print("\n--- Pass 1: Building Prefix Products ---")
    prefix = 1
    for i in range(n):
        result[i] = prefix
        print(f"  i={i}: result[{i}] = {prefix} (prefix before arr[{i}]={arr[i]})")
        prefix *= arr[i]
        print(f"        prefix = {prefix} (after multiplying arr[{i}])")

    print(f"\nAfter Pass 1: result = {result}")

    # Pass 2: Multiply by suffix
    print("\n--- Pass 2: Multiplying by Suffix ---")
    suffix = 1
    for i in range(n - 1, -1, -1):
        old_val = result[i]
        result[i] *= suffix
        print(f"  i={i}: result[{i}] = {old_val} * {suffix} = {result[i]}")
        suffix *= arr[i]
        print(f"        suffix = {suffix} (after multiplying arr[{i}]={arr[i]})")

    print(f"\nFinal result: {result}")

    # Verification
    print("\n--- Verification ---")
    for i in range(n):
        product = 1
        terms = []
        for j in range(n):
            if i != j:
                product *= arr[j]
                terms.append(str(arr[j]))
        print(f"  result[{i}] = {' * '.join(terms) if terms else '1'} = {product}")


if __name__ == "__main__":
    test_product_array()

    # Visualize specific examples
    visualize_algorithm([10, 3, 5, 6, 2])
    visualize_algorithm([1, 2, 3, 4])
