"""
Bishu and Soldiers
==================

Problem: Bishu has power P. Find count and sum of soldiers with power <= P.

Solution: Sort + Binary Search + Prefix Sum
- Sort soldiers array
- Build prefix sum array
- For each query, binary search for rightmost index <= P

Time: O(n log n) preprocessing + O(log n) per query
Space: O(n)
"""

import bisect


def bishu_brute(soldiers: list, power: int) -> tuple:
    """
    Brute Force: Check each soldier.
    Time: O(n) per query
    """
    count = 0
    total = 0

    for s in soldiers:
        if s <= power:
            count += 1
            total += s

    return count, total


class BishuSoldiers:
    """
    Optimized solution with preprocessing.
    Supports multiple queries efficiently.
    """

    def __init__(self, soldiers: list):
        """
        Preprocess: Sort and build prefix sums.
        Time: O(n log n)
        """
        self.soldiers = sorted(soldiers)
        self.n = len(soldiers)

        # Build prefix sum array
        self.prefix = [0] * self.n if self.n > 0 else []
        if self.n > 0:
            self.prefix[0] = self.soldiers[0]
            for i in range(1, self.n):
                self.prefix[i] = self.prefix[i - 1] + self.soldiers[i]

    def query(self, power: int) -> tuple:
        """
        Query for count and sum of soldiers with power <= given power.
        Time: O(log n) using binary search
        """
        if self.n == 0 or power < self.soldiers[0]:
            return 0, 0

        # bisect_right gives first index > power
        # So soldiers that can be defeated are at indices 0 to bisect_right-1
        idx = bisect.bisect_right(self.soldiers, power)

        if idx == 0:
            return 0, 0

        count = idx
        total = self.prefix[idx - 1]

        return count, total

    def query_manual(self, power: int) -> tuple:
        """
        Manual binary search implementation.
        Find largest index where soldiers[i] <= power.
        """
        if self.n == 0:
            return 0, 0

        low, high = 0, self.n - 1
        result = -1

        while low <= high:
            mid = low + (high - low) // 2

            if self.soldiers[mid] <= power:
                result = mid      # Store potential answer
                low = mid + 1     # Search right for larger valid index
            else:
                high = mid - 1    # Search left

        if result == -1:
            return 0, 0

        return result + 1, self.prefix[result]


def solve_queries(soldiers: list, queries: list) -> list:
    """
    Solve multiple queries efficiently.
    """
    bs = BishuSoldiers(soldiers)
    return [bs.query(p) for p in queries]


# ==================== TEST CASES ====================

def test_bishu_soldiers():
    """Comprehensive test cases."""

    print("=" * 60)
    print("BISHU AND SOLDIERS")
    print("=" * 60)

    test_cases = [
        # (soldiers, power, expected_count, expected_sum)
        ([1, 2, 3, 4, 5, 6, 7], 3, 3, 6),
        ([1, 2, 3, 4, 5, 6, 7], 5, 5, 15),
        ([7, 2, 5, 1, 8], 5, 3, 8),
        ([7, 2, 5, 1, 8], 7, 4, 15),
        ([7, 2, 5, 1, 8], 0, 0, 0),
        ([7, 2, 5, 1, 8], 10, 5, 23),
        ([5, 5, 5, 5], 5, 4, 20),
        ([5, 5, 5, 5], 4, 0, 0),
        ([10], 10, 1, 10),
        ([10], 5, 0, 0),
        ([], 5, 0, 0),
    ]

    all_passed = True

    for i, (soldiers, power, exp_count, exp_sum) in enumerate(test_cases, 1):
        bs = BishuSoldiers(soldiers)
        count, total = bs.query(power)
        brute_count, brute_sum = bishu_brute(soldiers, power)

        status = "PASS" if count == exp_count and total == exp_sum else "FAIL"
        if count != exp_count or total != exp_sum:
            all_passed = False

        print(f"\nTest {i}: {status}")
        print(f"  Soldiers: {soldiers}")
        print(f"  Power: {power}")
        print(f"  Expected: count={exp_count}, sum={exp_sum}")
        print(f"  Binary Search: count={count}, sum={total}")
        print(f"  Brute Force: count={brute_count}, sum={brute_sum}")

    # Test multiple queries
    print("\n" + "-" * 60)
    print("Multiple Queries Test:")
    print("-" * 60)

    soldiers = [7, 2, 5, 1, 8, 3, 6, 4]
    queries = [1, 3, 5, 7, 10]
    results = solve_queries(soldiers, queries)

    print(f"\nSoldiers: {soldiers}")
    print(f"Sorted: {sorted(soldiers)}")
    print(f"\nQueries and Results:")
    for p, (c, s) in zip(queries, results):
        print(f"  Power {p}: count={c}, sum={s}")

    # Test manual vs bisect
    print("\n" + "-" * 60)
    print("Manual vs Bisect Comparison:")
    print("-" * 60)

    bs = BishuSoldiers([7, 2, 5, 1, 8])
    for power in [0, 1, 5, 7, 10]:
        r1 = bs.query(power)
        r2 = bs.query_manual(power)
        match = "MATCH" if r1 == r2 else "DIFFER"
        print(f"  Power {power}: bisect={r1}, manual={r2} [{match}]")

    print("\n" + "=" * 60)
    print(f"All tests passed: {all_passed}")
    print("=" * 60)


def visualize_algorithm(soldiers: list, power: int):
    """Visualize the binary search process."""

    print(f"\nVisualizing Bishu and Soldiers")
    print(f"Soldiers: {soldiers}")
    print(f"Bishu's Power: {power}")
    print("=" * 60)

    sorted_soldiers = sorted(soldiers)
    n = len(sorted_soldiers)

    print(f"\nSorted soldiers: {sorted_soldiers}")

    # Build prefix
    prefix = [0] * n
    prefix[0] = sorted_soldiers[0] if n > 0 else 0
    for i in range(1, n):
        prefix[i] = prefix[i - 1] + sorted_soldiers[i]
    print(f"Prefix sums:     {prefix}")

    # Binary search visualization
    print(f"\nBinary search for rightmost index where soldier <= {power}:")

    low, high = 0, n - 1
    result = -1
    step = 1

    while low <= high:
        mid = low + (high - low) // 2

        # Visualize current state
        visual = "["
        for i, val in enumerate(sorted_soldiers):
            if i == low and i == mid and i == high:
                visual += f"(L,M,H){val}"
            elif i == low and i == mid:
                visual += f"(L,M){val}"
            elif i == mid and i == high:
                visual += f"(M,H){val}"
            elif i == low:
                visual += f"(L){val}"
            elif i == mid:
                visual += f"(M){val}"
            elif i == high:
                visual += f"(H){val}"
            else:
                visual += f"{val}"
            if i < n - 1:
                visual += ", "
        visual += "]"

        print(f"\n  Step {step}: {visual}")
        print(f"  low={low}, mid={mid}, high={high}")
        print(f"  soldiers[{mid}] = {sorted_soldiers[mid]}", end="")

        if sorted_soldiers[mid] <= power:
            result = mid
            print(f" <= {power}: Valid! result={result}, search right")
            low = mid + 1
        else:
            print(f" > {power}: Too strong, search left")
            high = mid - 1

        step += 1

    if result == -1:
        print(f"\nNo soldiers can be defeated!")
        print(f"Count = 0, Sum = 0")
    else:
        count = result + 1
        total = prefix[result]
        print(f"\nResult: index = {result}")
        print(f"Count = {result + 1} soldiers")
        print(f"Sum = prefix[{result}] = {total}")
        print(f"\nSoldiers defeated: {sorted_soldiers[:result+1]}")


if __name__ == "__main__":
    test_bishu_soldiers()

    # Visualize specific examples
    visualize_algorithm([1, 2, 3, 4, 5, 6, 7], 5)
    visualize_algorithm([7, 2, 5, 1, 8], 5)
