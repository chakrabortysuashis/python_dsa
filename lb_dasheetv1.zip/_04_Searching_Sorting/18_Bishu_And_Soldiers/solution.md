# Bishu and Soldiers

## Problem Statement

Bishu has power `P`. There are `N` soldiers with powers given in an array. Bishu can defeat soldiers whose power is **less than or equal to** his power.

For each query power `P`, find:
1. Count of soldiers Bishu can defeat
2. Sum of powers of those soldiers

**Example 1:**
```
Input: soldiers = [1, 2, 3, 4, 5, 6, 7], P = 3
Output: count = 3, sum = 6
Explanation: Bishu can defeat soldiers with powers 1, 2, 3
             Count = 3, Sum = 1 + 2 + 3 = 6
```

**Example 2:**
```
Input: soldiers = [7, 2, 5, 1, 8], P = 5
Output: count = 3, sum = 8
Explanation: Soldiers with power <= 5: [2, 5, 1]
             Count = 3, Sum = 2 + 5 + 1 = 8
```

---

## Approach Intuition

### Key Insight
If array is **sorted**, we can use **binary search** to find how many soldiers have power <= P.
- Find the rightmost position where soldier power <= P
- All soldiers up to that position can be defeated

### Why Binary Search?
```
Sorted: [1, 2, 3, 4, 5, 6, 7], P = 3

Binary search for rightmost position <= 3:
  Answer: index 2 (value 3)
  Count = 2 + 1 = 3 soldiers (indices 0, 1, 2)
```

### For Sum: Prefix Sum Array
Precompute prefix sums to get sum of first k elements in O(1).

---

## Brute Force Approach

### Algorithm
For each query, iterate through all soldiers.

### Code
```python
def bishu_brute(soldiers, power):
    count = 0
    total = 0
    
    for s in soldiers:
        if s <= power:
            count += 1
            total += s
    
    return count, total
```

### Complexity
- **Time**: O(n) per query, O(n * q) for q queries
- **Space**: O(1)

---

## Optimal Approach: Binary Search + Prefix Sum

### Algorithm
1. **Preprocessing** (once):
   - Sort the soldiers array
   - Build prefix sum array
   
2. **Per Query**:
   - Binary search for rightmost index where soldier[i] <= P
   - Count = index + 1
   - Sum = prefix_sum[index]

### Visualization of Binary Search

```
Sorted soldiers: [1, 2, 3, 4, 5, 6, 7]
Prefix sums:     [1, 3, 6, 10, 15, 21, 28]
Query P = 5

Binary search for largest index where soldiers[i] <= 5:

Step 1: low=0, high=6, mid=3
        [1, 2, 3, 4, 5, 6, 7]
         L        M        H
        soldiers[3] = 4 <= 5
        Result = 3, search right: low = 4

Step 2: low=4, high=6, mid=5
        [1, 2, 3, 4, 5, 6, 7]
                     L  M  H
        soldiers[5] = 6 > 5
        Search left: high = 4

Step 3: low=4, high=4, mid=4
        [1, 2, 3, 4, 5, 6, 7]
                     LMH
        soldiers[4] = 5 <= 5
        Result = 4, search right: low = 5

Step 4: low=5, high=4
        low > high, stop!
        Final result index = 4

Count = 4 + 1 = 5 soldiers
Sum = prefix[4] = 15
```

### Search Space Reduction

```
Array size: n = 7
Query power: 5

Brute force: Check all 7 elements
Binary search: Check log2(7) = 3 elements

For n = 1,000,000 and 10,000 queries:
  Brute: 10 billion operations
  Binary: 200,000 operations
```

---

## Dry Run with Different Example

```
Soldiers: [7, 2, 5, 1, 8]
Sorted:   [1, 2, 5, 7, 8]
Prefix:   [1, 3, 8, 15, 23]

Query 1: P = 5
  Binary search for <= 5: index 2 (value 5)
  Count = 3, Sum = prefix[2] = 8

Query 2: P = 7
  Binary search for <= 7: index 3 (value 7)
  Count = 4, Sum = prefix[3] = 15

Query 3: P = 0
  Binary search for <= 0: index -1 (not found)
  Count = 0, Sum = 0

Query 4: P = 10
  Binary search for <= 10: index 4 (value 8)
  Count = 5, Sum = prefix[4] = 23
```

---

## Code Implementation

```python
import bisect

def preprocess(soldiers):
    """Sort and build prefix sum array."""
    soldiers = sorted(soldiers)
    n = len(soldiers)
    
    # Build prefix sums
    prefix = [0] * n
    prefix[0] = soldiers[0]
    for i in range(1, n):
        prefix[i] = prefix[i-1] + soldiers[i]
    
    return soldiers, prefix

def query(soldiers, prefix, power):
    """
    Find count and sum of soldiers Bishu can defeat.
    Uses binary search for O(log n) per query.
    """
    if not soldiers or power < soldiers[0]:
        return 0, 0
    
    # Find rightmost index where soldiers[i] <= power
    # bisect_right gives first index > power
    # So we want bisect_right - 1
    idx = bisect.bisect_right(soldiers, power) - 1
    
    if idx < 0:
        return 0, 0
    
    count = idx + 1
    total = prefix[idx]
    
    return count, total

def query_manual_binary_search(soldiers, prefix, power):
    """Manual binary search implementation."""
    if not soldiers:
        return 0, 0
    
    low, high = 0, len(soldiers) - 1
    result = -1
    
    while low <= high:
        mid = low + (high - low) // 2
        
        if soldiers[mid] <= power:
            result = mid  # Store potential answer
            low = mid + 1  # Search right for larger valid index
        else:
            high = mid - 1  # Search left
    
    if result == -1:
        return 0, 0
    
    return result + 1, prefix[result]
```

---

## Time and Space Complexity

### Preprocessing
- **Time**: O(n log n) for sorting
- **Space**: O(n) for prefix sum array

### Per Query
- **Time**: O(log n) for binary search
- **Space**: O(1)

### Total for Q queries
- **Time**: O(n log n + Q log n)
- **Space**: O(n)

### Comparison
| Approach | Preprocessing | Per Query | Total (Q queries) |
|----------|--------------|-----------|-------------------|
| Brute Force | O(1) | O(n) | O(Q * n) |
| Binary Search | O(n log n) | O(log n) | O(n log n + Q log n) |

---

## Key Takeaways

1. **Sort + Binary Search**: Classic pattern for range queries

2. **Prefix Sum**: Enables O(1) range sum queries after O(n) preprocessing

3. **bisect_right vs bisect_left**:
   - `bisect_right(arr, x)`: First index where arr[i] > x
   - `bisect_left(arr, x)`: First index where arr[i] >= x

4. **For "count <= P"**: Use `bisect_right(arr, P)` directly as count

5. **For "sum of elements <= P"**: Use prefix sum at index `bisect_right(arr, P) - 1`

6. **Handle edge cases**:
   - Power less than smallest soldier
   - Power greater than largest soldier
   - Empty array

7. **Related problems**:
   - Count of elements in range [L, R]
   - Sum of elements in range
   - Kth smallest/largest
