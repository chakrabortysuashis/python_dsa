"""
ROTI-Prata SPOJ
===============

Problem: Find minimum time to make P pratas with L cooks of varying efficiency.

Solution: Binary search on time, check if P pratas can be made.

Time: O(L * log(max_time))
Space: O(1)
"""

import math


def pratas_in_time(rank: int, time: int) -> int:
    """Count pratas a cook with given rank can make in given time."""
    # Time for k pratas = rank * (1 + 2 + ... + k) = rank * k(k+1)/2
    # Solve: rank * k(k+1)/2 <= time
    # k^2 + k - 2*time/rank <= 0
    # k = (-1 + sqrt(1 + 8*time/rank)) / 2
    if rank == 0:
        return 0
    discriminant = 1 + 8 * time / rank
    return int((-1 + math.sqrt(discriminant)) / 2)


def min_time_pratas(P: int, ranks: list) -> int:
    """Find minimum time to make P pratas."""
    if P == 0:
        return 0
    if not ranks:
        return -1

    # Binary search on time
    low = 1
    high = max(ranks) * P * (P + 1) // 2  # Upper bound: slowest cook makes all
    result = high

    while low <= high:
        mid = (low + high) // 2
        total = sum(pratas_in_time(r, mid) for r in ranks)

        if total >= P:
            result = mid
            high = mid - 1
        else:
            low = mid + 1

    return result


def test_prata():
    print("=" * 50)
    print("ROTI-PRATA SPOJ")
    print("=" * 50)

    test_cases = [
        (10, [1, 2, 3, 4], 12),
        (8, [1, 1], 36),
        (10, [1], 55),
    ]

    for P, ranks, expected in test_cases:
        result = min_time_pratas(P, ranks)
        print(f"\nP={P}, Ranks={ranks}")
        print(f"Min time: {result}")
        print(f"Expected: {expected}, {'PASS' if result == expected else 'FAIL'}")


if __name__ == "__main__":
    test_prata()
