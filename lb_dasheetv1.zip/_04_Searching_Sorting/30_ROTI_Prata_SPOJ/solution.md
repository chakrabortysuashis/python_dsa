# ROTI-Prata SPOJ Problem

## Problem Statement

A restaurant needs to make `P` pratas. There are `L` cooks with different efficiencies. Cook `i` takes `R[i]` minutes for first prata, `2*R[i]` for second, `3*R[i]` for third, etc. Find minimum time to make all pratas.

**Example:**
```
Input: P = 10, R = [1, 2, 3, 4]
Output: 12
Explanation: In 12 minutes:
  Cook 1 (R=1): makes 4 pratas (1+2+3+4=10 min, done by 10)
  Cook 2 (R=2): makes 3 pratas (2+4+6=12 min)
  Cook 3 (R=3): makes 2 pratas (3+6=9 min)
  Cook 4 (R=4): makes 1 prata (4 min)
  Total: 4+3+2+1 = 10 pratas
```

---

## Approach: Binary Search on Time

### Validation
For time `T`, calculate how many pratas each cook can make:
- Cook with rank R: makes k pratas where `R(1+2+...+k) <= T`
- Solve: `R * k(k+1)/2 <= T` => `k = floor((-1 + sqrt(1 + 8T/R)) / 2)`

---

## Code

```python
import math

def pratas_in_time(R, T):
    """Count pratas cook with rank R can make in time T."""
    # R * k(k+1)/2 <= T
    # k^2 + k - 2T/R <= 0
    # k = (-1 + sqrt(1 + 8T/R)) / 2
    return int((-1 + math.sqrt(1 + 8 * T / R)) / 2)

def min_time_pratas(P, ranks):
    low, high = 1, max(ranks) * P * (P + 1) // 2
    result = high
    
    while low <= high:
        mid = (low + high) // 2
        total = sum(pratas_in_time(r, mid) for r in ranks)
        
        if total >= P:
            result = mid
            high = mid - 1
        else:
            low = mid + 1
    
    return result
```

---

## Complexity

- **Time**: O(L * log(max_time))
- **Space**: O(1)
