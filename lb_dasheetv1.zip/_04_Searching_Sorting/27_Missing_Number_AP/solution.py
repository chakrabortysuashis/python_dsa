"""
Missing Number in Arithmetic Progression
========================================

Problem: Find missing number in AP using binary search.

Time: O(log n)
Space: O(1)
"""


def find_missing_in_ap(arr: list) -> int:
    """Binary search for missing element in AP."""
    n = len(arr)
    if n < 2:
        return -1

    # Calculate common difference
    d = (arr[-1] - arr[0]) // n

    low, high = 0, n - 1

    while low < high:
        mid = (low + high) // 2
        expected = arr[0] + mid * d

        if arr[mid] == expected:
            low = mid + 1  # Missing in right half
        else:
            high = mid  # Missing at or before mid

    return arr[0] + low * d


def find_missing_linear(arr: list) -> int:
    """Linear scan for verification."""
    n = len(arr)
    d = (arr[-1] - arr[0]) // n

    for i in range(n - 1):
        if arr[i + 1] - arr[i] != d:
            return arr[i] + d

    return -1


def test_missing_ap():
    print("=" * 50)
    print("MISSING NUMBER IN AP")
    print("=" * 50)

    test_cases = [
        ([2, 4, 8, 10, 12, 14], 6),
        ([1, 6, 11, 16, 21, 31], 26),
        ([5, 10, 15, 25, 30], 20),
        ([2, 4, 6, 10], 8),
    ]

    for arr, expected in test_cases:
        result = find_missing_in_ap(arr)
        linear = find_missing_linear(arr)
        print(f"\nAP: {arr}")
        print(f"Missing: {result} (linear: {linear})")
        print(f"Expected: {expected}, {'PASS' if result == expected else 'FAIL'}")


if __name__ == "__main__":
    test_missing_ap()
