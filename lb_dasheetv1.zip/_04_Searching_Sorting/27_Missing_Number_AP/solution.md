# Missing Number in Arithmetic Progression

## Problem Statement

Given an array that represents an arithmetic progression with one number missing, find the missing number using binary search.

**Example:**
```
Input: arr = [2, 4, 8, 10, 12, 14]
Output: 6
Explanation: AP with d=2, missing 6 between 4 and 8
```

---

## Approach: Binary Search

### Key Insight
In a complete AP: `arr[i] = arr[0] + i * d`

If `arr[mid] == expected[mid]`, missing is in right half.
Otherwise, missing is in left half (including mid).

### Visualization

```
arr = [2, 4, 8, 10, 12, 14]
d = (14 - 2) / 6 = 2

Expected: [2, 4, 6, 8, 10, 12, 14]

Binary search:
mid=2: arr[2]=8, expected=2+2*2=6, 8!=6 -> left half
mid=1: arr[1]=4, expected=2+1*2=4, 4==4 -> right half [2,2]
mid=2: arr[2]=8, expected=6, missing is 6
```

---

## Code

```python
def find_missing_in_ap(arr):
    n = len(arr)
    d = (arr[-1] - arr[0]) // n  # Common difference
    
    low, high = 0, n - 1
    
    while low < high:
        mid = (low + high) // 2
        expected = arr[0] + mid * d
        
        if arr[mid] == expected:
            low = mid + 1  # Missing in right half
        else:
            high = mid  # Missing in left half (including mid)
    
    return arr[0] + low * d
```

---

## Complexity

- **Time**: O(log n)
- **Space**: O(1)
