# Find a Fixed Point (Value Equal to Index)

## Problem Statement

Given a sorted array of distinct integers, find an index `i` such that `arr[i] == i`. Such an index is called a **Fixed Point**. If no fixed point exists, return -1.

**Example 1:**
```
Input: arr = [-10, -5, 0, 3, 7]
Output: 3
Explanation: arr[3] = 3, so 3 is a fixed point
```

**Example 2:**
```
Input: arr = [0, 2, 5, 8, 17]
Output: 0
Explanation: arr[0] = 0, so 0 is a fixed point
```

**Example 3:**
```
Input: arr = [-10, -5, 3, 4, 7, 9]
Output: -1
Explanation: No index i exists where arr[i] == i
```

---

## Binary Search Intuition

Since the array is **sorted with distinct integers**, we can use binary search!

**Key Insight**: Define a difference function `diff[i] = arr[i] - i`
- If `diff[i] < 0`: arr[i] < i, fixed point (if exists) is to the RIGHT
- If `diff[i] > 0`: arr[i] > i, fixed point (if exists) is to the LEFT
- If `diff[i] == 0`: arr[i] == i, FOUND!

**Why does this work?**
- Array is sorted and has distinct elements
- As index increases by 1, value increases by at least 1 (distinct elements)
- Therefore, `diff[i] = arr[i] - i` is a non-decreasing sequence!
- We can binary search for where `diff[i] == 0`

---

## Brute Force Approach

### Algorithm
Linear scan through the array, check if `arr[i] == i` at each position.

### Code
```python
def fixed_point_brute(arr):
    for i in range(len(arr)):
        if arr[i] == i:
            return i
    return -1
```

### Complexity
- **Time**: O(n)
- **Space**: O(1)

---

## Optimal Approach: Binary Search

### Algorithm
1. Start with `low = 0`, `high = n - 1`
2. Calculate `mid`
3. If `arr[mid] == mid`: Found fixed point!
4. If `arr[mid] < mid`: Fixed point must be to the RIGHT (low = mid + 1)
5. If `arr[mid] > mid`: Fixed point must be to the LEFT (high = mid - 1)

### Visualization of Pointer Movement

```
Array: [-10, -5, 0, 3, 7]
Index:   0    1  2  3  4

diff[i] = arr[i] - i:
        [-10, -6, -2, 0, 3]
          ^            ^
       negative      positive
                     |
              Fixed point at diff=0

Step 1: low=0, high=4
        [-10, -5, 0, 3, 7]
          L       M     H
        mid = 2, arr[2] = 0
        0 < 2 (arr[mid] < mid)
        Search RIGHT: low = mid + 1 = 3

Step 2: low=3, high=4
        [-10, -5, 0, 3, 7]
                    L  M  H
        mid = 3, arr[3] = 3
        3 == 3 (arr[mid] == mid)
        FOUND! Fixed point = 3
```

### Another Example

```
Array: [0, 2, 5, 8, 17]
Index:  0  1  2  3   4

Step 1: low=0, high=4
        [0, 2, 5, 8, 17]
         L     M       H
        mid = 2, arr[2] = 5
        5 > 2 (arr[mid] > mid)
        Search LEFT: high = mid - 1 = 1

Step 2: low=0, high=1
        [0, 2, 5, 8, 17]
         L  H
         M
        mid = 0, arr[0] = 0
        0 == 0 (arr[mid] == mid)
        FOUND! Fixed point = 0
```

### Example with No Fixed Point

```
Array: [-10, -5, 3, 4, 7, 9]
Index:   0    1  2  3  4  5

diff:  [-10, -6, 1, 1, 3, 4]
       All either negative or positive, never 0!

Step 1: low=0, high=5, mid=2
        arr[2] = 3 > 2 -> high = 1

Step 2: low=0, high=1, mid=0
        arr[0] = -10 < 0 -> low = 1

Step 3: low=1, high=1, mid=1
        arr[1] = -5 < 1 -> low = 2

Step 4: low=2, high=1
        low > high, STOP!
        Return -1 (no fixed point)
```

---

## Search Space Reduction

```
Array size: n = 5

Binary Search approach:
  Step 1: Search space = 5 elements
  Step 2: Search space = 2 elements (eliminated ~60%)
  Step 3: Found or 1 element left

Maximum steps = log2(5) ≈ 3 steps

vs Linear Search: Up to 5 comparisons
```

---

## Code Implementation

```python
def find_fixed_point(arr):
    low, high = 0, len(arr) - 1
    
    while low <= high:
        mid = low + (high - low) // 2
        
        if arr[mid] == mid:
            return mid  # Fixed point found
        elif arr[mid] < mid:
            low = mid + 1  # Search right half
        else:
            high = mid - 1  # Search left half
    
    return -1  # No fixed point
```

---

## Handling Multiple Fixed Points

If the array can have duplicates and you need the **leftmost** fixed point:

```python
def find_first_fixed_point(arr):
    low, high = 0, len(arr) - 1
    result = -1
    
    while low <= high:
        mid = low + (high - low) // 2
        
        if arr[mid] == mid:
            result = mid      # Store potential answer
            high = mid - 1    # Keep searching LEFT
        elif arr[mid] < mid:
            low = mid + 1
        else:
            high = mid - 1
    
    return result
```

---

## Time and Space Complexity

### Optimal Approach
- **Time Complexity**: O(log n)
  - Binary search halves the search space each time
  
- **Space Complexity**: O(1)
  - Only using a few variables

### Comparison
| Approach | Time | Space |
|----------|------|-------|
| Brute Force | O(n) | O(1) |
| Binary Search | O(log n) | O(1) |

---

## Key Takeaways

1. **Sorted + Distinct = Binary Search**: The key properties enable binary search

2. **Difference function insight**: 
   - `diff[i] = arr[i] - i` is non-decreasing for sorted distinct arrays
   - Binary search for `diff[i] == 0`

3. **Decision at each step**:
   - `arr[mid] < mid`: Elements are "too small", search RIGHT
   - `arr[mid] > mid`: Elements are "too large", search LEFT

4. **Edge cases**:
   - Empty array: return -1
   - All negative: no fixed point possible if all values < 0
   - Single element: check if arr[0] == 0

5. **With duplicates**: Problem becomes harder, may need to search both directions
