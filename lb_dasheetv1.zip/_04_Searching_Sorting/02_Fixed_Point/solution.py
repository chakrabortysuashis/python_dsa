"""
Find a Fixed Point (Value Equal to Index)
==========================================

Problem: Given a sorted array of distinct integers, find an index i such that arr[i] == i.
Return -1 if no such index exists.

Time Complexity: O(log n)
Space Complexity: O(1)
"""


def find_fixed_point(arr: list) -> int:
    """
    Find a fixed point using binary search.

    A fixed point is an index i where arr[i] == i.

    Key insight: For sorted distinct arrays:
    - If arr[mid] < mid: fixed point must be on RIGHT (values are too small)
    - If arr[mid] > mid: fixed point must be on LEFT (values are too large)
    - If arr[mid] == mid: FOUND!

    Args:
        arr: Sorted array of distinct integers

    Returns:
        Index of fixed point, or -1 if none exists
    """
    low, high = 0, len(arr) - 1

    while low <= high:
        mid = low + (high - low) // 2

        if arr[mid] == mid:
            return mid  # Fixed point found!
        elif arr[mid] < mid:
            # arr[mid] is less than its index
            # Values are "too small" for their positions
            # Fixed point (if exists) must be to the RIGHT
            low = mid + 1
        else:
            # arr[mid] is greater than its index
            # Values are "too large" for their positions
            # Fixed point (if exists) must be to the LEFT
            high = mid - 1

    return -1  # No fixed point exists


def find_fixed_point_brute(arr: list) -> int:
    """
    Brute force approach: Linear scan.

    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    for i in range(len(arr)):
        if arr[i] == i:
            return i
    return -1


def find_first_fixed_point(arr: list) -> int:
    """
    Find the FIRST (leftmost) fixed point.

    Useful when array might have multiple fixed points
    (though with distinct elements, there can be at most one).

    Time Complexity: O(log n)
    Space Complexity: O(1)
    """
    low, high = 0, len(arr) - 1
    result = -1

    while low <= high:
        mid = low + (high - low) // 2

        if arr[mid] == mid:
            result = mid      # Store this fixed point
            high = mid - 1    # Keep searching LEFT for earlier one
        elif arr[mid] < mid:
            low = mid + 1
        else:
            high = mid - 1

    return result


def find_last_fixed_point(arr: list) -> int:
    """
    Find the LAST (rightmost) fixed point.

    Time Complexity: O(log n)
    Space Complexity: O(1)
    """
    low, high = 0, len(arr) - 1
    result = -1

    while low <= high:
        mid = low + (high - low) // 2

        if arr[mid] == mid:
            result = mid      # Store this fixed point
            low = mid + 1     # Keep searching RIGHT for later one
        elif arr[mid] < mid:
            low = mid + 1
        else:
            high = mid - 1

    return result


def count_fixed_points(arr: list) -> int:
    """
    Count total number of fixed points.

    For distinct elements, there can be at most 1.
    For arrays with duplicates, there could be more.

    Time Complexity: O(n) for counting all
    """
    count = 0
    for i in range(len(arr)):
        if arr[i] == i:
            count += 1
    return count


def find_all_fixed_points(arr: list) -> list:
    """
    Find all fixed points in the array.

    Time Complexity: O(n)

    Returns:
        List of all fixed point indices
    """
    return [i for i in range(len(arr)) if arr[i] == i]


# ==================== TEST CASES ====================

def test_fixed_point():
    """Comprehensive test cases."""

    print("=" * 60)
    print("FIND FIXED POINT")
    print("=" * 60)

    test_cases = [
        # (array, expected)
        ([-10, -5, 0, 3, 7], 3),
        ([0, 2, 5, 8, 17], 0),
        ([-10, -5, 3, 4, 7, 9], -1),
        ([0], 0),
        ([1], -1),
        ([-1, 0, 1, 2, 3, 4, 5, 7], 7),
        ([-10, -5, -2, 0, 1, 3, 6], 6),
        ([], -1),
        ([-5, -4, -3, -2, -1], -1),
        ([5, 6, 7, 8, 9], -1),
        ([-10, -5, 2, 10, 20], 2),
    ]

    all_passed = True

    for i, (arr, expected) in enumerate(test_cases, 1):
        result = find_fixed_point(arr)
        status = "PASS" if result == expected else "FAIL"

        if result != expected:
            all_passed = False

        print(f"\nTest {i}: {status}")
        print(f"  Array: {arr}")
        print(f"  Expected: {expected}")
        print(f"  Got: {result}")

        if result != -1:
            print(f"  Verification: arr[{result}] = {arr[result]}")

    print("\n" + "=" * 60)
    print(f"All tests passed: {all_passed}")
    print("=" * 60)


def visualize_search(arr: list):
    """Visualize the binary search process."""

    print(f"\nVisualizing fixed point search in {arr}")
    print("Index:  " + "  ".join(f"{i:3}" for i in range(len(arr))))
    print("Value:  " + "  ".join(f"{v:3}" for v in arr))
    print("diff:   " + "  ".join(f"{arr[i]-i:3}" for i in range(len(arr))))
    print("-" * 50)

    low, high = 0, len(arr) - 1
    step = 1

    while low <= high:
        mid = low + (high - low) // 2

        # Create visualization string
        vis = ["   "] * len(arr)
        vis[low] = " L "
        vis[high] = " H "
        vis[mid] = " M " if mid != low and mid != high else vis[mid]

        if low == mid == high:
            vis[mid] = "LMH"
        elif low == mid:
            vis[mid] = "LM "
        elif mid == high:
            vis[mid] = "MH "

        print(f"Step {step}: " + "".join(vis))
        print(f"        low={low}, mid={mid}, high={high}")
        print(f"        arr[{mid}] = {arr[mid]}, comparing with index {mid}")

        if arr[mid] == mid:
            print(f"        {arr[mid]} == {mid} -> FOUND! Fixed point = {mid}")
            return mid
        elif arr[mid] < mid:
            print(f"        {arr[mid]} < {mid} -> Search RIGHT (low = {mid + 1})")
            low = mid + 1
        else:
            print(f"        {arr[mid]} > {mid} -> Search LEFT (high = {mid - 1})")
            high = mid - 1

        step += 1

    print("No fixed point found!")
    return -1


def explain_intuition():
    """Explain why binary search works for this problem."""

    print("\n" + "=" * 60)
    print("WHY BINARY SEARCH WORKS")
    print("=" * 60)

    arr = [-10, -5, 0, 3, 7]

    print(f"\nArray: {arr}")
    print("\nLet's compute diff[i] = arr[i] - i:")
    print()

    for i in range(len(arr)):
        diff = arr[i] - i
        relation = "==" if diff == 0 else ("<" if diff < 0 else ">")
        print(f"  i={i}: arr[{i}]={arr[i]:3}, diff = {arr[i]} - {i} = {diff:3}  (arr[i] {relation} i)")

    print("\nObservation:")
    print("  - For SORTED array with DISTINCT elements:")
    print("  - As i increases by 1, arr[i] increases by at least 1")
    print("  - Therefore diff[i] = arr[i] - i is NON-DECREASING")
    print()
    print("  - If diff[mid] < 0: all diff[0..mid] likely < 0, search RIGHT")
    print("  - If diff[mid] > 0: all diff[mid..n-1] likely > 0, search LEFT")
    print("  - If diff[mid] == 0: FOUND fixed point!")


if __name__ == "__main__":
    test_fixed_point()

    # Visualize examples
    print("\n" + "=" * 60)
    print("VISUALIZATION EXAMPLES")
    print("=" * 60)

    visualize_search([-10, -5, 0, 3, 7])
    visualize_search([0, 2, 5, 8, 17])
    visualize_search([-10, -5, 3, 4, 7, 9])

    # Explain intuition
    explain_intuition()
