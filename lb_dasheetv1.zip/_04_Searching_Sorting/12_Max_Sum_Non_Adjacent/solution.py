"""
Maximum Sum Such That No Two Elements Are Adjacent
===================================================

Problem: Find maximum sum of subsequence where no two elements are adjacent.

Also known as: House Robber, Stickler Thief

DP recurrence: dp[i] = max(arr[i] + dp[i-2], dp[i-1])

Time: O(n)
Space: O(1) with optimization
"""

from typing import List, Tuple


def max_sum_non_adjacent(arr: List[int]) -> int:
    """
    Find maximum sum where no two elements are adjacent.

    At each position, choose to:
    1. Include current element + best sum ending 2 positions back
    2. Exclude current element and take best sum ending 1 position back

    Time: O(n)
    Space: O(1)
    """
    if not arr:
        return 0
    if len(arr) == 1:
        return arr[0]

    # prev2 represents dp[i-2]
    # prev1 represents dp[i-1]
    prev2 = 0
    prev1 = arr[0]

    for i in range(1, len(arr)):
        # Include arr[i]: arr[i] + prev2
        # Exclude arr[i]: prev1
        current = max(arr[i] + prev2, prev1)
        prev2 = prev1
        prev1 = current

    return prev1


def max_sum_with_dp_array(arr: List[int]) -> List[int]:
    """
    DP with full array (for learning/debugging).

    Time: O(n)
    Space: O(n)
    """
    if not arr:
        return []

    n = len(arr)
    dp = [0] * n

    dp[0] = arr[0]
    if n > 1:
        dp[1] = max(arr[0], arr[1])

    for i in range(2, n):
        dp[i] = max(arr[i] + dp[i - 2], dp[i - 1])

    return dp


def max_sum_with_elements(arr: List[int]) -> Tuple[int, List[int]]:
    """
    Return both maximum sum and the elements selected.

    Time: O(n)
    Space: O(n) for backtracking
    """
    if not arr:
        return 0, []
    if len(arr) == 1:
        return arr[0], [arr[0]]

    n = len(arr)
    dp = [0] * n

    dp[0] = arr[0]
    dp[1] = max(arr[0], arr[1])

    for i in range(2, n):
        dp[i] = max(arr[i] + dp[i - 2], dp[i - 1])

    # Backtrack to find selected elements
    result = []
    i = n - 1

    while i >= 0:
        if i == 0:
            result.append(arr[i])
            break
        elif i == 1:
            if arr[1] > arr[0]:
                result.append(arr[1])
            else:
                result.append(arr[0])
            break
        elif dp[i] != dp[i - 1]:
            # Current element was included
            result.append(arr[i])
            i -= 2
        else:
            # Current element was excluded
            i -= 1

    return dp[n - 1], result[::-1]


def max_sum_recursive(arr: List[int], i: int = None) -> int:
    """
    Recursive approach (for understanding, not efficient).

    Time: O(2^n) without memoization
    """
    if i is None:
        i = len(arr) - 1

    if i < 0:
        return 0
    if i == 0:
        return arr[0]

    # Include arr[i] or exclude it
    include = arr[i] + max_sum_recursive(arr, i - 2)
    exclude = max_sum_recursive(arr, i - 1)

    return max(include, exclude)


def max_sum_memoized(arr: List[int]) -> int:
    """
    Memoized recursive approach.

    Time: O(n)
    Space: O(n)
    """
    n = len(arr)
    memo = {}

    def dp(i):
        if i < 0:
            return 0
        if i in memo:
            return memo[i]

        memo[i] = max(arr[i] + dp(i - 2), dp(i - 1))
        return memo[i]

    return dp(n - 1)


def house_robber_circular(arr: List[int]) -> int:
    """
    Variant: Houses are arranged in a circle.
    First and last houses are adjacent.

    Solution: Max of (rob 0 to n-2) and (rob 1 to n-1)

    Time: O(n)
    Space: O(1)
    """
    if not arr:
        return 0
    if len(arr) == 1:
        return arr[0]
    if len(arr) == 2:
        return max(arr[0], arr[1])

    # Case 1: Include first, exclude last
    max1 = max_sum_non_adjacent(arr[:-1])

    # Case 2: Exclude first, can include last
    max2 = max_sum_non_adjacent(arr[1:])

    return max(max1, max2)


# ==================== TEST CASES ====================

def test_max_sum():
    """Test all approaches."""

    print("=" * 60)
    print("MAX SUM NON ADJACENT")
    print("=" * 60)

    test_cases = [
        ([5, 5, 10, 100, 10, 5], 110),
        ([1, 2, 3], 4),
        ([1, 20, 3], 20),
        ([5, 5, 10, 40, 50, 35], 80),
        ([1, 2, 3, 4, 5], 9),
        ([2, 1, 1, 2], 4),
        ([5], 5),
        ([], 0),
    ]

    for arr, expected in test_cases:
        result = max_sum_non_adjacent(arr)
        _, elements = max_sum_with_elements(arr.copy()) if arr else (0, [])

        status = "PASS" if result == expected else "FAIL"
        print(f"\nArray: {arr}")
        print(f"Expected: {expected}, Got: {result} [{status}]")
        print(f"Selected elements: {elements}")

    # Test circular variant
    print("\n" + "=" * 60)
    print("HOUSE ROBBER CIRCULAR")
    print("=" * 60)

    circular_tests = [
        ([2, 3, 2], 3),
        ([1, 2, 3, 1], 4),
        ([1, 2, 3], 3),
    ]

    for arr, expected in circular_tests:
        result = house_robber_circular(arr)
        status = "PASS" if result == expected else "FAIL"
        print(f"Array: {arr}, Expected: {expected}, Got: {result} [{status}]")


def visualize_dp(arr: List[int]):
    """Visualize the DP process step by step."""

    print(f"\n{'='*60}")
    print(f"DP VISUALIZATION for {arr}")
    print("=" * 60)

    if not arr:
        print("Empty array!")
        return

    n = len(arr)
    dp = max_sum_with_dp_array(arr)

    print("\nStep-by-step DP computation:")
    print(f"Array: {arr}")
    print()

    # Show headers
    print(f"{'i':>5} | {'arr[i]':>8} | {'Include':>15} | {'Exclude':>10} | {'dp[i]':>8}")
    print("-" * 60)

    for i in range(n):
        if i == 0:
            include = arr[0]
            exclude = "-"
            print(f"{i:>5} | {arr[i]:>8} | {include:>15} | {exclude:>10} | {dp[i]:>8}")
        elif i == 1:
            include = f"{arr[1]} + 0 = {arr[1]}"
            exclude = dp[0]
            print(f"{i:>5} | {arr[i]:>8} | {include:>15} | {exclude:>10} | {dp[i]:>8}")
        else:
            include_val = arr[i] + dp[i - 2]
            include = f"{arr[i]} + {dp[i-2]} = {include_val}"
            exclude = dp[i - 1]
            print(f"{i:>5} | {arr[i]:>8} | {include:>15} | {exclude:>10} | {dp[i]:>8}")

    print()
    print(f"Final DP array: {dp}")
    print(f"Maximum sum: {dp[-1]}")

    # Show selected elements
    max_sum, elements = max_sum_with_elements(arr)
    print(f"Selected elements: {elements}")


if __name__ == "__main__":
    test_max_sum()

    # Visualize examples
    visualize_dp([5, 5, 10, 100, 10, 5])
    visualize_dp([1, 2, 3, 4, 5])
    visualize_dp([3, 2, 7, 10])
