# Maximum Sum Such That No Two Elements Are Adjacent

## Problem Statement

Given an array of positive integers, find the maximum sum of a subsequence such that no two elements in the subsequence are adjacent in the original array.

**Example 1:**
```
Input: arr = [5, 5, 10, 100, 10, 5]
Output: 110
Explanation: Pick 5 + 100 + 5 = 110 (indices 0, 3, 5)
```

**Example 2:**
```
Input: arr = [1, 2, 3]
Output: 4
Explanation: Pick 1 + 3 = 4 (indices 0, 2)
```

**Example 3:**
```
Input: arr = [1, 20, 3]
Output: 20
Explanation: Pick 20 (index 1)
```

---

## Dynamic Programming Intuition

At each position i, we have two choices:
1. **Include arr[i]**: Add arr[i] to the max sum ending at i-2 (skip i-1)
2. **Exclude arr[i]**: Take the max sum ending at i-1

```
dp[i] = max(arr[i] + dp[i-2], dp[i-1])
```

---

## Visualization

```
Array: [5, 5, 10, 100, 10, 5]
Index:  0  1   2    3   4  5

dp[0] = 5 (only one element)
dp[1] = max(5, 5) = 5 (pick first or second)

dp[2] = max(arr[2] + dp[0], dp[1])
      = max(10 + 5, 5) = 15

dp[3] = max(arr[3] + dp[1], dp[2])
      = max(100 + 5, 15) = 105

dp[4] = max(arr[4] + dp[2], dp[3])
      = max(10 + 15, 105) = 105

dp[5] = max(arr[5] + dp[3], dp[4])
      = max(5 + 105, 105) = 110

Answer: 110
```

---

## Space Optimization

We only need the last two values, not the entire dp array!

```
prev2 = 0 (dp[i-2])
prev1 = 0 (dp[i-1])

For each element:
  current = max(arr[i] + prev2, prev1)
  prev2 = prev1
  prev1 = current
```

---

## Code Implementation

```python
def max_sum_non_adjacent(arr):
    """
    Find maximum sum where no two elements are adjacent.
    
    Time: O(n)
    Space: O(1)
    """
    if not arr:
        return 0
    if len(arr) == 1:
        return arr[0]
    
    # prev2 = max sum including/excluding (i-2)th element
    # prev1 = max sum including/excluding (i-1)th element
    prev2 = 0
    prev1 = arr[0]
    
    for i in range(1, len(arr)):
        # Include arr[i]: add to prev2
        # Exclude arr[i]: take prev1
        current = max(arr[i] + prev2, prev1)
        prev2 = prev1
        prev1 = current
    
    return prev1
```

---

## With Full DP Array (for understanding)

```python
def max_sum_dp_array(arr):
    """DP with full array to trace decisions."""
    if not arr:
        return 0
    
    n = len(arr)
    dp = [0] * n
    
    dp[0] = arr[0]
    if n > 1:
        dp[1] = max(arr[0], arr[1])
    
    for i in range(2, n):
        dp[i] = max(arr[i] + dp[i-2], dp[i-1])
    
    return dp[n-1]
```

---

## Finding the Actual Elements

```python
def max_sum_with_elements(arr):
    """Return both max sum and the elements selected."""
    if not arr:
        return 0, []
    
    n = len(arr)
    dp = [0] * n
    dp[0] = arr[0]
    
    if n > 1:
        dp[1] = max(arr[0], arr[1])
    
    for i in range(2, n):
        dp[i] = max(arr[i] + dp[i-2], dp[i-1])
    
    # Backtrack to find elements
    result = []
    i = n - 1
    
    while i >= 0:
        if i == 0 or dp[i] != dp[i-1]:
            result.append(arr[i])
            i -= 2
        else:
            i -= 1
    
    return dp[n-1], result[::-1]
```

---

## Dry Run with Backtracking

```
Array: [5, 5, 10, 100, 10, 5]
dp:    [5, 5, 15, 105, 105, 110]

Backtrack from i=5:
  dp[5]=110 != dp[4]=105 -> Include arr[5]=5
  i = 5-2 = 3

i=3:
  dp[3]=105 != dp[2]=15 -> Include arr[3]=100
  i = 3-2 = 1

i=1:
  dp[1]=5 == dp[0]=5 -> Could be either
  Let's check: was arr[1] included?
  If arr[1] was included: dp[1] would be arr[1] + dp[-1] = 5 + 0 = 5
  If arr[0] was included: dp[1] would be arr[0] = 5
  Either works, let's exclude arr[1]
  i = 0

i=0:
  Include arr[0]=5
  i = -2 (done)

Selected: [5, 100, 5] -> Sum = 110
```

---

## Variants

### House Robber (Circular)
Houses are in a circle, so first and last are adjacent.

```python
def house_robber_circular(arr):
    if len(arr) == 1:
        return arr[0]
    
    # Case 1: Rob houses 0 to n-2 (exclude last)
    max1 = max_sum_non_adjacent(arr[:-1])
    
    # Case 2: Rob houses 1 to n-1 (exclude first)
    max2 = max_sum_non_adjacent(arr[1:])
    
    return max(max1, max2)
```

---

## Time and Space Complexity

| Approach | Time | Space |
|----------|------|-------|
| Recursive (naive) | O(2^n) | O(n) |
| DP with array | O(n) | O(n) |
| DP optimized | O(n) | O(1) |

---

## Key Takeaways

1. **DP recurrence**: `dp[i] = max(arr[i] + dp[i-2], dp[i-1])`
2. **Space optimization**: Only need last two values
3. **Backtracking for elements**: Track which elements were included
4. **Classic problem variants**: House Robber, Stickler Thief
5. **Pattern recognition**: Include/exclude decisions on sequences
