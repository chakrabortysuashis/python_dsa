"""
Searching and Sorting Algorithms - Complete Implementation
==========================================================

This module contains implementations of all major searching and sorting algorithms
with detailed comments explaining each step.
"""


# ==================== SEARCHING ALGORITHMS ====================

def linear_search(arr: list, target: int) -> int:
    """
    Linear Search: Traverse array element by element until target is found.

    Time Complexity: O(n)
    Space Complexity: O(1)

    Args:
        arr: List of elements to search
        target: Element to find

    Returns:
        Index of target if found, -1 otherwise
    """
    for i in range(len(arr)):
        if arr[i] == target:
            return i
    return -1


def binary_search(arr: list, target: int) -> int:
    """
    Binary Search: Divide and conquer - eliminate half the search space each step.

    PREREQUISITE: Array must be SORTED!

    Time Complexity: O(log n)
    Space Complexity: O(1)

    Args:
        arr: SORTED list of elements
        target: Element to find

    Returns:
        Index of target if found, -1 otherwise
    """
    low, high = 0, len(arr) - 1

    while low <= high:
        # Calculate mid without overflow (important for large arrays)
        mid = low + (high - low) // 2

        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            # Target is in right half
            low = mid + 1
        else:
            # Target is in left half
            high = mid - 1

    return -1  # Target not found


def binary_search_recursive(arr: list, target: int, low: int = None, high: int = None) -> int:
    """
    Binary Search (Recursive version)

    Time Complexity: O(log n)
    Space Complexity: O(log n) due to recursion stack
    """
    if low is None:
        low = 0
    if high is None:
        high = len(arr) - 1

    if low > high:
        return -1

    mid = low + (high - low) // 2

    if arr[mid] == target:
        return mid
    elif arr[mid] < target:
        return binary_search_recursive(arr, target, mid + 1, high)
    else:
        return binary_search_recursive(arr, target, low, mid - 1)


def first_occurrence(arr: list, target: int) -> int:
    """
    Find the FIRST occurrence of target in a sorted array with duplicates.

    Time Complexity: O(log n)
    Space Complexity: O(1)
    """
    low, high = 0, len(arr) - 1
    result = -1

    while low <= high:
        mid = low + (high - low) // 2

        if arr[mid] == target:
            result = mid        # Store potential answer
            high = mid - 1      # Continue searching left for earlier occurrence
        elif arr[mid] < target:
            low = mid + 1
        else:
            high = mid - 1

    return result


def last_occurrence(arr: list, target: int) -> int:
    """
    Find the LAST occurrence of target in a sorted array with duplicates.

    Time Complexity: O(log n)
    Space Complexity: O(1)
    """
    low, high = 0, len(arr) - 1
    result = -1

    while low <= high:
        mid = low + (high - low) // 2

        if arr[mid] == target:
            result = mid        # Store potential answer
            low = mid + 1       # Continue searching right for later occurrence
        elif arr[mid] < target:
            low = mid + 1
        else:
            high = mid - 1

    return result


def lower_bound(arr: list, target: int) -> int:
    """
    Find the index of first element >= target (lower bound).

    Time Complexity: O(log n)
    Space Complexity: O(1)

    Returns:
        Index of first element >= target, or len(arr) if no such element
    """
    low, high = 0, len(arr)

    while low < high:
        mid = low + (high - low) // 2

        if arr[mid] < target:
            low = mid + 1
        else:
            high = mid

    return low


def upper_bound(arr: list, target: int) -> int:
    """
    Find the index of first element > target (upper bound).

    Time Complexity: O(log n)
    Space Complexity: O(1)

    Returns:
        Index of first element > target, or len(arr) if no such element
    """
    low, high = 0, len(arr)

    while low < high:
        mid = low + (high - low) // 2

        if arr[mid] <= target:
            low = mid + 1
        else:
            high = mid

    return low


# ==================== SORTING ALGORITHMS ====================

def bubble_sort(arr: list) -> list:
    """
    Bubble Sort: Repeatedly swap adjacent elements if they're in wrong order.
    Largest elements "bubble up" to the end.

    Time Complexity: O(n^2) worst/average, O(n) best (with optimization)
    Space Complexity: O(1)
    Stable: Yes

    Args:
        arr: List to sort (will be modified in place)

    Returns:
        Sorted list
    """
    n = len(arr)

    for i in range(n):
        swapped = False

        # Last i elements are already in place
        for j in range(n - i - 1):
            if arr[j] > arr[j + 1]:
                # Swap adjacent elements
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True

        # Optimization: If no swaps occurred, array is already sorted
        if not swapped:
            break

    return arr


def selection_sort(arr: list) -> list:
    """
    Selection Sort: Find minimum element and place it at the beginning.
    Repeat for remaining unsorted portion.

    Time Complexity: O(n^2) for all cases
    Space Complexity: O(1)
    Stable: No (but can be made stable)

    Note: Makes minimum number of swaps (at most n-1 swaps)
    """
    n = len(arr)

    for i in range(n):
        # Find minimum element in unsorted portion
        min_idx = i
        for j in range(i + 1, n):
            if arr[j] < arr[min_idx]:
                min_idx = j

        # Swap minimum with first element of unsorted portion
        arr[i], arr[min_idx] = arr[min_idx], arr[i]

    return arr


def insertion_sort(arr: list) -> list:
    """
    Insertion Sort: Build sorted array one element at a time.
    Insert each element into its correct position in the sorted portion.

    Time Complexity: O(n^2) worst/average, O(n) best (nearly sorted)
    Space Complexity: O(1)
    Stable: Yes

    Best for:
    - Small arrays
    - Nearly sorted arrays
    - Online sorting (data arrives incrementally)
    """
    for i in range(1, len(arr)):
        key = arr[i]  # Element to be inserted
        j = i - 1

        # Shift elements greater than key to the right
        while j >= 0 and arr[j] > key:
            arr[j + 1] = arr[j]
            j -= 1

        # Insert key at its correct position
        arr[j + 1] = key

    return arr


def merge_sort(arr: list) -> list:
    """
    Merge Sort: Divide array into halves, recursively sort, then merge.
    Classic divide-and-conquer algorithm.

    Time Complexity: O(n log n) for all cases
    Space Complexity: O(n)
    Stable: Yes

    Best for:
    - When stable sort is required
    - Linked lists (no extra space needed)
    - External sorting (large files)
    - Parallel processing
    """
    if len(arr) <= 1:
        return arr

    # Divide
    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])

    # Conquer (merge)
    return _merge(left, right)


def _merge(left: list, right: list) -> list:
    """Helper function to merge two sorted arrays."""
    result = []
    i = j = 0

    # Compare elements from both arrays and add smaller one
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:  # <= for stability
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1

    # Add remaining elements
    result.extend(left[i:])
    result.extend(right[j:])

    return result


def merge_sort_inplace(arr: list, left: int = 0, right: int = None) -> list:
    """
    Merge Sort (In-place version using indices)

    Time Complexity: O(n log n)
    Space Complexity: O(n) for temporary arrays during merge
    """
    if right is None:
        right = len(arr) - 1

    if left < right:
        mid = (left + right) // 2
        merge_sort_inplace(arr, left, mid)
        merge_sort_inplace(arr, mid + 1, right)
        _merge_inplace(arr, left, mid, right)

    return arr


def _merge_inplace(arr: list, left: int, mid: int, right: int):
    """Helper function for in-place merge sort."""
    # Create temporary arrays
    left_arr = arr[left:mid + 1]
    right_arr = arr[mid + 1:right + 1]

    i = j = 0
    k = left

    while i < len(left_arr) and j < len(right_arr):
        if left_arr[i] <= right_arr[j]:
            arr[k] = left_arr[i]
            i += 1
        else:
            arr[k] = right_arr[j]
            j += 1
        k += 1

    while i < len(left_arr):
        arr[k] = left_arr[i]
        i += 1
        k += 1

    while j < len(right_arr):
        arr[k] = right_arr[j]
        j += 1
        k += 1


def quick_sort(arr: list, low: int = 0, high: int = None) -> list:
    """
    Quick Sort: Pick pivot, partition array, recursively sort partitions.

    Time Complexity: O(n log n) average, O(n^2) worst
    Space Complexity: O(log n) average (recursion stack)
    Stable: No

    Best for:
    - General-purpose sorting
    - When average case performance matters
    - Cache-friendly operations
    """
    if high is None:
        high = len(arr) - 1

    if low < high:
        # Partition and get pivot index
        pivot_idx = _partition(arr, low, high)

        # Recursively sort partitions
        quick_sort(arr, low, pivot_idx - 1)
        quick_sort(arr, pivot_idx + 1, high)

    return arr


def _partition(arr: list, low: int, high: int) -> int:
    """
    Lomuto partition scheme: Use last element as pivot.

    After partitioning:
    - Elements < pivot are on the left
    - Elements >= pivot are on the right
    - Pivot is in its final sorted position
    """
    pivot = arr[high]
    i = low - 1  # Index of smaller element

    for j in range(low, high):
        if arr[j] <= pivot:
            i += 1
            arr[i], arr[j] = arr[j], arr[i]

    # Place pivot in correct position
    arr[i + 1], arr[high] = arr[high], arr[i + 1]

    return i + 1


def quick_sort_hoare(arr: list, low: int = 0, high: int = None) -> list:
    """
    Quick Sort with Hoare partition scheme.
    Generally more efficient than Lomuto as it makes fewer swaps.
    """
    if high is None:
        high = len(arr) - 1

    if low < high:
        pivot_idx = _partition_hoare(arr, low, high)
        quick_sort_hoare(arr, low, pivot_idx)
        quick_sort_hoare(arr, pivot_idx + 1, high)

    return arr


def _partition_hoare(arr: list, low: int, high: int) -> int:
    """Hoare partition scheme: Use first element as pivot."""
    pivot = arr[low]
    i = low - 1
    j = high + 1

    while True:
        # Move i right until element >= pivot
        i += 1
        while arr[i] < pivot:
            i += 1

        # Move j left until element <= pivot
        j -= 1
        while arr[j] > pivot:
            j -= 1

        if i >= j:
            return j

        arr[i], arr[j] = arr[j], arr[i]


def heap_sort(arr: list) -> list:
    """
    Heap Sort: Build max-heap, then extract maximum repeatedly.

    Time Complexity: O(n log n) for all cases
    Space Complexity: O(1)
    Stable: No

    Best for:
    - When O(n log n) worst-case is required with O(1) space
    - Finding k largest/smallest elements
    - Priority queue operations
    """
    n = len(arr)

    # Build max-heap (heapify all non-leaf nodes)
    # Start from last non-leaf node and move to root
    for i in range(n // 2 - 1, -1, -1):
        _heapify(arr, n, i)

    # Extract elements one by one
    for i in range(n - 1, 0, -1):
        # Move current root (max) to end
        arr[0], arr[i] = arr[i], arr[0]

        # Heapify reduced heap
        _heapify(arr, i, 0)

    return arr


def _heapify(arr: list, n: int, i: int):
    """
    Heapify subtree rooted at index i.
    n is the size of the heap.

    Max-heap property: Parent >= Children
    """
    largest = i
    left = 2 * i + 1
    right = 2 * i + 2

    # Check if left child exists and is greater than root
    if left < n and arr[left] > arr[largest]:
        largest = left

    # Check if right child exists and is greater than largest so far
    if right < n and arr[right] > arr[largest]:
        largest = right

    # If largest is not root, swap and continue heapifying
    if largest != i:
        arr[i], arr[largest] = arr[largest], arr[i]
        _heapify(arr, n, largest)


def counting_sort(arr: list) -> list:
    """
    Counting Sort: Count occurrences of each element, then reconstruct array.

    Time Complexity: O(n + k) where k is the range of input
    Space Complexity: O(k)
    Stable: Yes

    Best for:
    - Small range of integer values
    - When k = O(n)
    """
    if not arr:
        return arr

    # Find range
    min_val, max_val = min(arr), max(arr)
    range_size = max_val - min_val + 1

    # Count occurrences
    count = [0] * range_size
    for num in arr:
        count[num - min_val] += 1

    # Build sorted array
    result = []
    for i, c in enumerate(count):
        result.extend([i + min_val] * c)

    return result


def radix_sort(arr: list) -> list:
    """
    Radix Sort: Sort digit by digit from least significant to most significant.

    Time Complexity: O(d * (n + k)) where d is number of digits, k is radix (10)
    Space Complexity: O(n + k)
    Stable: Yes

    Best for:
    - Sorting integers with fixed number of digits
    - Strings of fixed length
    """
    if not arr:
        return arr

    # Handle negative numbers by separating them
    negatives = [-x for x in arr if x < 0]
    positives = [x for x in arr if x >= 0]

    # Sort positives
    if positives:
        max_val = max(positives)
        exp = 1
        while max_val // exp > 0:
            positives = _counting_sort_by_digit(positives, exp)
            exp *= 10

    # Sort negatives (in reverse)
    if negatives:
        max_val = max(negatives)
        exp = 1
        while max_val // exp > 0:
            negatives = _counting_sort_by_digit(negatives, exp)
            exp *= 10
        negatives = [-x for x in reversed(negatives)]

    return negatives + positives


def _counting_sort_by_digit(arr: list, exp: int) -> list:
    """Helper for radix sort: Count sort based on digit at exp position."""
    n = len(arr)
    output = [0] * n
    count = [0] * 10

    # Count occurrences of digits
    for num in arr:
        digit = (num // exp) % 10
        count[digit] += 1

    # Convert to cumulative count
    for i in range(1, 10):
        count[i] += count[i - 1]

    # Build output array (traverse in reverse for stability)
    for i in range(n - 1, -1, -1):
        digit = (arr[i] // exp) % 10
        count[digit] -= 1
        output[count[digit]] = arr[i]

    return output


# ==================== TEST CASES ====================

def test_searching():
    """Test all searching algorithms."""
    print("=" * 50)
    print("TESTING SEARCHING ALGORITHMS")
    print("=" * 50)

    # Test data
    sorted_arr = [1, 3, 5, 7, 9, 11, 13, 15, 17, 19]
    unsorted_arr = [64, 34, 25, 12, 22, 11, 90]
    duplicates_arr = [1, 2, 2, 2, 3, 4, 4, 5]

    # Linear Search
    print("\n1. Linear Search:")
    print(f"   Array: {unsorted_arr}")
    print(f"   Search 22: Index = {linear_search(unsorted_arr, 22)}")
    print(f"   Search 100: Index = {linear_search(unsorted_arr, 100)}")

    # Binary Search
    print("\n2. Binary Search:")
    print(f"   Sorted Array: {sorted_arr}")
    print(f"   Search 7: Index = {binary_search(sorted_arr, 7)}")
    print(f"   Search 8: Index = {binary_search(sorted_arr, 8)}")

    # Binary Search Recursive
    print("\n3. Binary Search (Recursive):")
    print(f"   Search 15: Index = {binary_search_recursive(sorted_arr, 15)}")

    # First and Last Occurrence
    print("\n4. First & Last Occurrence:")
    print(f"   Array with duplicates: {duplicates_arr}")
    print(f"   First occurrence of 2: {first_occurrence(duplicates_arr, 2)}")
    print(f"   Last occurrence of 2: {last_occurrence(duplicates_arr, 2)}")
    print(f"   First occurrence of 4: {first_occurrence(duplicates_arr, 4)}")
    print(f"   Last occurrence of 4: {last_occurrence(duplicates_arr, 4)}")

    # Lower and Upper Bound
    print("\n5. Lower & Upper Bound:")
    print(f"   Array: {duplicates_arr}")
    print(f"   Lower bound of 2: {lower_bound(duplicates_arr, 2)}")
    print(f"   Upper bound of 2: {upper_bound(duplicates_arr, 2)}")
    print(f"   Lower bound of 3: {lower_bound(duplicates_arr, 3)}")
    print(f"   Upper bound of 3: {upper_bound(duplicates_arr, 3)}")


def test_sorting():
    """Test all sorting algorithms."""
    print("\n" + "=" * 50)
    print("TESTING SORTING ALGORITHMS")
    print("=" * 50)

    test_arrays = [
        [64, 34, 25, 12, 22, 11, 90],
        [5, 4, 3, 2, 1],
        [1, 2, 3, 4, 5],
        [1],
        [],
        [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5]
    ]

    algorithms = [
        ("Bubble Sort", bubble_sort),
        ("Selection Sort", selection_sort),
        ("Insertion Sort", insertion_sort),
        ("Merge Sort", merge_sort),
        ("Quick Sort", quick_sort),
        ("Heap Sort", heap_sort),
        ("Counting Sort", counting_sort),
        ("Radix Sort", radix_sort),
    ]

    for name, algo in algorithms:
        print(f"\n{name}:")
        for arr in test_arrays:
            original = arr.copy()
            if algo in [quick_sort, heap_sort, merge_sort_inplace]:
                sorted_arr = algo(arr.copy())
            else:
                sorted_arr = algo(arr.copy())
            print(f"   {original} -> {sorted_arr}")


def compare_complexity():
    """Demonstrate time complexity differences."""
    import time
    import random

    print("\n" + "=" * 50)
    print("COMPLEXITY COMPARISON")
    print("=" * 50)

    sizes = [100, 500, 1000, 2000]

    algorithms = [
        ("Bubble Sort", bubble_sort),
        ("Insertion Sort", insertion_sort),
        ("Merge Sort", merge_sort),
        ("Quick Sort", quick_sort),
        ("Heap Sort", heap_sort),
    ]

    print("\nTime (seconds) for different array sizes:\n")
    print(f"{'Algorithm':<20} | ", end="")
    for size in sizes:
        print(f"{size:>8}", end=" | ")
    print()
    print("-" * 60)

    for name, algo in algorithms:
        print(f"{name:<20} | ", end="")
        for size in sizes:
            arr = [random.randint(1, 1000) for _ in range(size)]

            start = time.time()
            if algo in [quick_sort, heap_sort]:
                algo(arr.copy())
            else:
                algo(arr.copy())
            elapsed = time.time() - start

            print(f"{elapsed:>8.4f} | ", end="")
        print()


if __name__ == "__main__":
    test_searching()
    test_sorting()

    # Uncomment to see complexity comparison
    # compare_complexity()

    print("\n" + "=" * 50)
    print("All tests completed!")
    print("=" * 50)
