# Count Triplets with Sum Less Than Value

## Problem Statement

Given an array `arr` of distinct integers and a value `sum`, count all triplets (i, j, k) where `arr[i] + arr[j] + arr[k] < sum` and `i < j < k`.

**Example 1:**
```
Input: arr = [-2, 0, 1, 3], sum = 2
Output: 2
Explanation: Triplets: (-2, 0, 1) and (-2, 0, 3) have sum < 2
```

**Example 2:**
```
Input: arr = [5, 1, 3, 4, 7], sum = 12
Output: 4
Explanation: Triplets with sum < 12: (1,3,4), (1,3,5), (1,4,5), (1,3,7)
```

---

## Approach Intuition

### Key Insight
After **sorting**, for a fixed element at index i:
- Use **two pointers** (j, k) to find pairs where `arr[i] + arr[j] + arr[k] < sum`
- If a triplet satisfies condition, ALL elements between j and k also work!

### Why Sorting Helps
```
Sorted: [-2, 0, 1, 3]

If arr[i] + arr[j] + arr[k] < sum, then:
  arr[i] + arr[j] + arr[k-1] < sum (smaller k means smaller sum)
  arr[i] + arr[j] + arr[k-2] < sum
  ... and so on
```

---

## Brute Force Approach

### Algorithm
Check all possible triplets using three nested loops.

### Code
```python
def count_triplets_brute(arr, target_sum):
    n = len(arr)
    count = 0
    
    for i in range(n - 2):
        for j in range(i + 1, n - 1):
            for k in range(j + 1, n):
                if arr[i] + arr[j] + arr[k] < target_sum:
                    count += 1
    
    return count
```

### Complexity
- **Time**: O(n^3) - three nested loops
- **Space**: O(1)

---

## Optimal Approach: Sort + Two Pointers

### Algorithm
1. **Sort** the array
2. Fix first element at index `i`
3. Use two pointers `j = i+1` and `k = n-1`
4. If `arr[i] + arr[j] + arr[k] < sum`:
   - Count ALL triplets from j to k: add `(k - j)` to count
   - Move j forward (try larger second element)
5. Else move k backward (need smaller sum)

### Visualization of Pointer Movement

```
Array: [-2, 0, 1, 3], sum = 2
Sorted: [-2, 0, 1, 3]

=== Fix i = 0, arr[i] = -2 ===

Step 1: j=1, k=3
        [-2, 0, 1, 3]
          i  j     k
          L        H
        sum = -2 + 0 + 3 = 1 < 2
        Valid! All pairs (j, k'), k' in [j+1, k] work
        Count += (k - j) = 3 - 1 = 2
        Triplets counted: (-2,0,1) and (-2,0,3)
        Move j forward: j = 2

Step 2: j=2, k=3
        [-2, 0, 1, 3]
          i     j  k
        sum = -2 + 1 + 3 = 2, NOT < 2
        Move k backward: k = 2
        
Step 3: j=2, k=2
        j >= k, stop this iteration

=== Fix i = 1, arr[i] = 0 ===

Step 1: j=2, k=3
        [-2, 0, 1, 3]
             i  j  k
        sum = 0 + 1 + 3 = 4, NOT < 2
        Move k backward: k = 2

Step 2: j=2, k=2
        j >= k, stop

Total count = 2
```

### Search Space Reduction

```
Without optimization: C(4,3) = 4 triplet checks
With two pointers: ~3 operations (after sorting)

For n = 1000:
  Brute force: ~166 million operations
  Optimized: ~1 million operations
```

---

## Why Count = (k - j)?

```
When arr[i] + arr[j] + arr[k] < sum:

Array: [1, 2, 3, 4, 5, 6], i=0, j=1, k=5
       arr[i]=1, arr[j]=2, arr[k]=6

If (1 + 2 + 6) < sum, then:
  (1 + 2 + 5) < sum  (k=4)
  (1 + 2 + 4) < sum  (k=3)
  (1 + 2 + 3) < sum  (k=2)

All k' where j < k' <= k form valid triplets!
Number of such k' = k - j
```

---

## Dry Run with Different Example

```
Array: [1, 2, 3, 4, 5], sum = 8
Sorted: [1, 2, 3, 4, 5]

i=0 (arr[i]=1):
  j=1, k=4: 1+2+5=8, NOT < 8, k--
  j=1, k=3: 1+2+4=7 < 8, count += 3-1=2, j++
  j=2, k=3: 1+3+4=8, NOT < 8, k--
  j=2, k=2: stop

i=1 (arr[i]=2):
  j=2, k=4: 2+3+5=10, NOT < 8, k--
  j=2, k=3: 2+3+4=9, NOT < 8, k--
  j=2, k=2: stop

i=2 (arr[i]=3):
  j=3, k=4: 3+4+5=12, NOT < 8, k--
  j=3, k=3: stop

Total count = 2
Triplets: (1,2,3), (1,2,4)
```

---

## Code Implementation

```python
def count_triplets(arr, target_sum):
    arr.sort()  # Sort first
    n = len(arr)
    count = 0
    
    for i in range(n - 2):
        j = i + 1      # Left pointer
        k = n - 1      # Right pointer
        
        while j < k:
            current_sum = arr[i] + arr[j] + arr[k]
            
            if current_sum < target_sum:
                # All elements from j+1 to k form valid triplets with i,j
                count += (k - j)
                j += 1  # Try larger second element
            else:
                k -= 1  # Need smaller sum
    
    return count
```

---

## Time and Space Complexity

### Optimal Approach
- **Time Complexity**: O(n^2)
  - Sorting: O(n log n)
  - Two pointers for each i: O(n^2) total
  
- **Space Complexity**: O(1)
  - Sorting in-place (or O(n) if not)

### Comparison
| Approach | Time | Space |
|----------|------|-------|
| Brute Force | O(n^3) | O(1) |
| Sort + Two Pointers | O(n^2) | O(1) |

---

## Key Takeaways

1. **Sorting enables two pointers**: Transform O(n^3) to O(n^2)

2. **Counting trick**: When condition holds, count ALL valid pairs at once
   - Don't iterate through each - use math: `count += (k - j)`

3. **Monotonic property**: 
   - If sum with k is valid, sums with smaller k are also valid
   - This allows skipping explicit checks

4. **Similar problems**:
   - 3Sum (find triplets equal to sum)
   - 3Sum Closest
   - Count triplets with sum in range

5. **Two pointer pattern**: Fix one element, use two pointers on remaining
