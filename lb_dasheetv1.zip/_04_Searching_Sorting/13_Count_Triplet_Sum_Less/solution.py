"""
Count Triplets with Sum Less Than Value
========================================

Problem: Given an array of distinct integers and a value sum, count all
triplets (i, j, k) where arr[i] + arr[j] + arr[k] < sum and i < j < k.

Time Complexity: O(n^2)
Space Complexity: O(1) or O(n) for sorting
"""


def count_triplets_brute(arr: list, target_sum: int) -> int:
    """
    Brute Force: Check all possible triplets.

    Time: O(n^3)
    Space: O(1)
    """
    n = len(arr)
    count = 0

    for i in range(n - 2):
        for j in range(i + 1, n - 1):
            for k in range(j + 1, n):
                if arr[i] + arr[j] + arr[k] < target_sum:
                    count += 1

    return count


def count_triplets(arr: list, target_sum: int) -> int:
    """
    Optimal: Sort + Two Pointers approach.

    Key insight: After sorting, if arr[i] + arr[j] + arr[k] < sum,
    then all elements between j and k also form valid triplets with i,j.

    Time: O(n^2)
    Space: O(1) if sorting in-place
    """
    arr = sorted(arr)  # Create sorted copy
    n = len(arr)
    count = 0

    # Fix first element
    for i in range(n - 2):
        j = i + 1      # Second element (left pointer)
        k = n - 1      # Third element (right pointer)

        while j < k:
            current_sum = arr[i] + arr[j] + arr[k]

            if current_sum < target_sum:
                # All elements from j+1 to k form valid triplets!
                # Triplets: (arr[i], arr[j], arr[j+1]), (arr[i], arr[j], arr[j+2]), ...
                count += (k - j)
                j += 1  # Try larger second element
            else:
                k -= 1  # Sum too large, need smaller third element

    return count


def count_triplets_with_list(arr: list, target_sum: int) -> tuple:
    """
    Return count AND the actual triplets for verification.

    Returns: (count, list of triplets)
    """
    arr_sorted = sorted(arr)
    n = len(arr_sorted)
    count = 0
    triplets = []

    for i in range(n - 2):
        j = i + 1
        k = n - 1

        while j < k:
            current_sum = arr_sorted[i] + arr_sorted[j] + arr_sorted[k]

            if current_sum < target_sum:
                # Collect all valid triplets for this j
                for m in range(j + 1, k + 1):
                    triplets.append((arr_sorted[i], arr_sorted[j], arr_sorted[m]))
                count += (k - j)
                j += 1
            else:
                k -= 1

    return count, triplets


def count_triplets_binary_search(arr: list, target_sum: int) -> int:
    """
    Alternative: Binary search approach.

    For each pair (i, j), binary search for largest k where sum < target.

    Time: O(n^2 log n)
    Space: O(1)
    """
    import bisect

    arr = sorted(arr)
    n = len(arr)
    count = 0

    for i in range(n - 2):
        for j in range(i + 1, n - 1):
            # Find largest k where arr[i] + arr[j] + arr[k] < target_sum
            remaining = target_sum - arr[i] - arr[j]

            # Find position where arr[k] >= remaining
            # All elements before this position are valid
            k = bisect.bisect_left(arr, remaining, j + 1, n)

            # Count valid triplets: indices from j+1 to k-1
            if k > j + 1:
                count += (k - j - 1)

    return count


# ==================== TEST CASES ====================

def test_count_triplets():
    """Comprehensive test cases."""

    print("=" * 60)
    print("COUNT TRIPLETS WITH SUM LESS THAN VALUE")
    print("=" * 60)

    test_cases = [
        # (array, target_sum, expected_count)
        ([-2, 0, 1, 3], 2, 2),
        ([5, 1, 3, 4, 7], 12, 4),
        ([1, 2, 3, 4, 5], 8, 2),
        ([1, 2, 3], 6, 0),
        ([1, 2, 3], 7, 1),
        ([-1, 0, 1, 2], 2, 3),
        ([1, 1, 1, 1], 4, 4),  # All same
        ([1, 2], 10, 0),  # Too few elements
        ([], 10, 0),  # Empty
        ([1, 2, 3, 4, 5, 6], 10, 4),
    ]

    all_passed = True

    for i, (arr, target, expected) in enumerate(test_cases, 1):
        result = count_triplets(arr.copy(), target)
        brute_result = count_triplets_brute(arr.copy(), target)
        status = "PASS" if result == expected and brute_result == expected else "FAIL"

        if result != expected:
            all_passed = False

        print(f"\nTest {i}: {status}")
        print(f"  Array: {arr}")
        print(f"  Target sum: {target}")
        print(f"  Expected: {expected}")
        print(f"  Optimized: {result}")
        print(f"  Brute force: {brute_result}")

    # Test with triplet listing
    print("\n" + "-" * 60)
    print("Verification with actual triplets:")
    print("-" * 60)

    arr = [-2, 0, 1, 3]
    target = 2
    count, triplets = count_triplets_with_list(arr, target)
    print(f"\nArray: {arr}, Target: {target}")
    print(f"Count: {count}")
    print(f"Triplets: {triplets}")

    arr = [1, 2, 3, 4, 5]
    target = 8
    count, triplets = count_triplets_with_list(arr, target)
    print(f"\nArray: {arr}, Target: {target}")
    print(f"Count: {count}")
    print(f"Triplets: {triplets}")

    # Test binary search approach
    print("\n" + "-" * 60)
    print("Binary Search Approach Verification:")
    print("-" * 60)

    for arr, target, expected in test_cases[:5]:
        bs_result = count_triplets_binary_search(arr.copy(), target)
        status = "PASS" if bs_result == expected else "FAIL"
        print(f"  Array: {arr}, Target: {target} -> {bs_result} [{status}]")

    print("\n" + "=" * 60)
    print(f"All tests passed: {all_passed}")
    print("=" * 60)


def visualize_algorithm(arr: list, target_sum: int):
    """Visualize the two-pointer algorithm step by step."""

    print(f"\nVisualizing triplet count for sum < {target_sum}")
    print(f"Original array: {arr}")

    arr = sorted(arr)
    print(f"Sorted array: {arr}")
    print("=" * 60)

    n = len(arr)
    total_count = 0

    for i in range(n - 2):
        print(f"\n--- Fixing i = {i}, arr[i] = {arr[i]} ---")

        j = i + 1
        k = n - 1

        step = 1
        while j < k:
            current_sum = arr[i] + arr[j] + arr[k]

            # Visual representation
            visual = "["
            for idx in range(n):
                if idx == i:
                    visual += f"(i){arr[idx]}"
                elif idx == j:
                    visual += f"(j){arr[idx]}"
                elif idx == k:
                    visual += f"(k){arr[idx]}"
                else:
                    visual += f"{arr[idx]}"
                if idx < n - 1:
                    visual += ", "
            visual += "]"

            print(f"\n  Step {step}: {visual}")
            print(f"  Sum = {arr[i]} + {arr[j]} + {arr[k]} = {current_sum}")

            if current_sum < target_sum:
                added = k - j
                total_count += added
                print(f"  {current_sum} < {target_sum}: Valid!")
                print(f"  All k' in [{j+1}, {k}] work with i={i}, j={j}")
                print(f"  Count += {added}, Total = {total_count}")
                j += 1
                print(f"  Move j forward: j = {j}")
            else:
                print(f"  {current_sum} >= {target_sum}: Too large")
                k -= 1
                print(f"  Move k backward: k = {k}")

            step += 1

        print(f"  j >= k, done with i = {i}")

    print(f"\n{'=' * 60}")
    print(f"Final count: {total_count}")


if __name__ == "__main__":
    test_count_triplets()

    # Visualize specific examples
    visualize_algorithm([-2, 0, 1, 3], 2)
    visualize_algorithm([1, 2, 3, 4, 5], 8)
