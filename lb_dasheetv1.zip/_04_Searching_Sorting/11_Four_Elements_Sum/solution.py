"""
Find Four Elements That Sum to a Given Value
=============================================

Problem: Find four elements a, b, c, d such that a + b + c + d = X.

Optimal approach: Sort + Two Pointers O(n^3)
"""

from typing import List


def four_sum_brute(arr: List[int], X: int) -> List[List[int]]:
    """
    Brute force: Check all quadruples.

    Time: O(n^4)
    Space: O(1)
    """
    n = len(arr)
    result = []
    seen = set()

    for i in range(n - 3):
        for j in range(i + 1, n - 2):
            for k in range(j + 1, n - 1):
                for l in range(k + 1, n):
                    if arr[i] + arr[j] + arr[k] + arr[l] == X:
                        quad = tuple(sorted([arr[i], arr[j], arr[k], arr[l]]))
                        if quad not in seen:
                            result.append(list(quad))
                            seen.add(quad)

    return result


def four_sum_hash(arr: List[int], X: int) -> List[List[int]]:
    """
    Hash map approach: Store pair sums.

    Time: O(n^2)
    Space: O(n^2)
    """
    n = len(arr)
    if n < 4:
        return []

    pair_sums = {}  # sum -> list of (i, j) pairs

    # Store all pair sums with their indices
    for i in range(n - 1):
        for j in range(i + 1, n):
            s = arr[i] + arr[j]
            if s not in pair_sums:
                pair_sums[s] = []
            pair_sums[s].append((i, j))

    result = []
    seen = set()

    # Find complementary pairs
    for i in range(n - 1):
        for j in range(i + 1, n):
            complement = X - arr[i] - arr[j]

            if complement in pair_sums:
                for (p, q) in pair_sums[complement]:
                    # Ensure no index overlap
                    if p > j:
                        quad = tuple(sorted([arr[i], arr[j], arr[p], arr[q]]))
                        if quad not in seen:
                            result.append(list(quad))
                            seen.add(quad)

    return result


def four_sum(arr: List[int], X: int) -> List[List[int]]:
    """
    Optimal: Sort + Two Pointers.

    1. Sort array
    2. Fix first two elements (nested loops)
    3. Use two pointers for remaining two

    Time: O(n^3)
    Space: O(1) excluding output
    """
    n = len(arr)
    if n < 4:
        return []

    arr.sort()
    result = []

    for i in range(n - 3):
        # Skip duplicates for first element
        if i > 0 and arr[i] == arr[i - 1]:
            continue

        for j in range(i + 1, n - 2):
            # Skip duplicates for second element
            if j > i + 1 and arr[j] == arr[j - 1]:
                continue

            # Two pointers for remaining elements
            left = j + 1
            right = n - 1
            target = X - arr[i] - arr[j]

            while left < right:
                curr_sum = arr[left] + arr[right]

                if curr_sum == target:
                    result.append([arr[i], arr[j], arr[left], arr[right]])

                    # Skip duplicates for third element
                    while left < right and arr[left] == arr[left + 1]:
                        left += 1
                    # Skip duplicates for fourth element
                    while left < right and arr[right] == arr[right - 1]:
                        right -= 1

                    left += 1
                    right -= 1

                elif curr_sum < target:
                    left += 1
                else:
                    right -= 1

    return result


def four_sum_single(arr: List[int], X: int) -> List[int]:
    """Find just one quadruple (not all)."""
    n = len(arr)
    if n < 4:
        return []

    arr_sorted = sorted(arr)

    for i in range(n - 3):
        for j in range(i + 1, n - 2):
            left = j + 1
            right = n - 1
            target = X - arr_sorted[i] - arr_sorted[j]

            while left < right:
                curr_sum = arr_sorted[left] + arr_sorted[right]

                if curr_sum == target:
                    return [arr_sorted[i], arr_sorted[j], arr_sorted[left], arr_sorted[right]]
                elif curr_sum < target:
                    left += 1
                else:
                    right -= 1

    return []


def k_sum(arr: List[int], target: int, k: int) -> List[List[int]]:
    """
    Generalized k-sum problem.

    Recursively reduces k-sum to (k-1)-sum, with base case of 2-sum.

    Time: O(n^(k-1))
    """
    def k_sum_recursive(arr, target, k, start):
        result = []

        if k == 2:
            # Two pointer approach for 2-sum
            left, right = start, len(arr) - 1
            while left < right:
                s = arr[left] + arr[right]
                if s == target:
                    result.append([arr[left], arr[right]])
                    while left < right and arr[left] == arr[left + 1]:
                        left += 1
                    while left < right and arr[right] == arr[right - 1]:
                        right -= 1
                    left += 1
                    right -= 1
                elif s < target:
                    left += 1
                else:
                    right -= 1
            return result

        # General case: reduce to (k-1)-sum
        for i in range(start, len(arr) - k + 1):
            if i > start and arr[i] == arr[i - 1]:
                continue

            sub_results = k_sum_recursive(arr, target - arr[i], k - 1, i + 1)
            for sub in sub_results:
                result.append([arr[i]] + sub)

        return result

    arr.sort()
    return k_sum_recursive(arr, target, k, 0)


# ==================== TEST CASES ====================

def test_four_sum():
    """Test all approaches."""

    print("=" * 60)
    print("FOUR ELEMENTS SUM")
    print("=" * 60)

    test_cases = [
        ([10, 2, 3, 4, 5, 9, 7, 8], 23),
        ([1, 2, 3, 4], 10),
        ([1, 0, -1, 0, -2, 2], 0),
        ([2, 2, 2, 2, 2], 8),
        ([1, 2, 3, 4, 5], 100),  # No solution
    ]

    for arr, X in test_cases:
        print(f"\nArray: {arr}, Target: {X}")

        result_brute = four_sum_brute(arr.copy(), X)
        result_hash = four_sum_hash(arr.copy(), X)
        result_optimal = four_sum(arr.copy(), X)

        print(f"  Brute:   {result_brute}")
        print(f"  Hash:    {result_hash}")
        print(f"  Optimal: {result_optimal}")

        # Verify results
        def verify(quads, arr, X):
            for q in quads:
                if sum(q) != X:
                    return False
            return True

        all_valid = (verify(result_brute, arr, X) and
                     verify(result_hash, arr, X) and
                     verify(result_optimal, arr, X))
        print(f"  All results valid: {all_valid}")


def visualize_algorithm(arr: List[int], X: int):
    """Visualize the two pointer approach."""

    print(f"\n{'='*60}")
    print(f"VISUALIZATION: {arr}, Target={X}")
    print("=" * 60)

    n = len(arr)
    arr = sorted(arr)
    print(f"Sorted: {arr}")

    found = False
    for i in range(n - 3):
        if i > 0 and arr[i] == arr[i-1]:
            continue

        for j in range(i + 1, n - 2):
            if j > i + 1 and arr[j] == arr[j-1]:
                continue

            target = X - arr[i] - arr[j]
            print(f"\nFix arr[{i}]={arr[i]}, arr[{j}]={arr[j]}")
            print(f"Need remaining two to sum to: {X} - {arr[i]} - {arr[j]} = {target}")

            left, right = j + 1, n - 1
            while left < right:
                curr = arr[left] + arr[right]
                print(f"  left={left}({arr[left]}), right={right}({arr[right]}): {arr[left]}+{arr[right]}={curr}", end="")

                if curr == target:
                    print(f" == {target} -> FOUND!")
                    print(f"\nResult: [{arr[i]}, {arr[j]}, {arr[left]}, {arr[right]}]")
                    found = True
                    return
                elif curr < target:
                    print(f" < {target}, left++")
                    left += 1
                else:
                    print(f" > {target}, right--")
                    right -= 1

    if not found:
        print("\nNo valid quadruple found!")


if __name__ == "__main__":
    test_four_sum()

    visualize_algorithm([10, 2, 3, 4, 5, 9, 7, 8], 23)
    visualize_algorithm([1, 0, -1, 0, -2, 2], 0)
