# Find Four Elements That Sum to a Given Value

## Problem Statement

Given an array of integers, find four elements whose sum equals a target value X.

**Example 1:**
```
Input: arr = [10, 2, 3, 4, 5, 9, 7, 8], X = 23
Output: [3, 5, 7, 8] (or any valid quadruple)
```

**Example 2:**
```
Input: arr = [1, 2, 3, 4], X = 10
Output: [1, 2, 3, 4]
```

---

## Multiple Approaches

### Approach 1: Brute Force O(n^4)

Check all possible quadruples.

```python
def four_sum_brute(arr, X):
    n = len(arr)
    for i in range(n-3):
        for j in range(i+1, n-2):
            for k in range(j+1, n-1):
                for l in range(k+1, n):
                    if arr[i] + arr[j] + arr[k] + arr[l] == X:
                        return [arr[i], arr[j], arr[k], arr[l]]
    return None
```

---

### Approach 2: Hash Map O(n^2) time and space

Store all pair sums in a hash map, then find complementary pairs.

```python
def four_sum_hash(arr, X):
    n = len(arr)
    pair_sums = {}
    
    # Store all pair sums
    for i in range(n-1):
        for j in range(i+1, n):
            s = arr[i] + arr[j]
            if s not in pair_sums:
                pair_sums[s] = []
            pair_sums[s].append((i, j))
    
    # Find complementary pairs
    for i in range(n-1):
        for j in range(i+1, n):
            complement = X - arr[i] - arr[j]
            if complement in pair_sums:
                for (p, q) in pair_sums[complement]:
                    if p > j:  # Ensure no overlap
                        return [arr[i], arr[j], arr[p], arr[q]]
    return None
```

---

### Approach 3: Sort + Two Pointers O(n^3)

1. Sort the array
2. Fix first two elements (two nested loops)
3. Use two pointers for remaining two elements

### Visualization

```
Array: [10, 2, 3, 4, 5, 9, 7, 8], X = 23
Sorted: [2, 3, 4, 5, 7, 8, 9, 10]

Fix arr[0]=2, arr[1]=3:
  Need remaining two to sum to: 23 - 2 - 3 = 18
  Two pointers on [4, 5, 7, 8, 9, 10]
  
  left=4, right=10: 4+10=14 < 18, left++
  left=5, right=10: 5+10=15 < 18, left++
  left=7, right=10: 7+10=17 < 18, left++
  left=8, right=10: 8+10=18 == 18, FOUND!
  
Result: [2, 3, 8, 10]
```

---

### Code Implementation

```python
def four_sum(arr, X):
    """
    Find four elements that sum to X using sort + two pointers.
    
    Time: O(n^3)
    Space: O(1) excluding result storage
    """
    n = len(arr)
    if n < 4:
        return []
    
    arr.sort()
    result = []
    
    for i in range(n - 3):
        # Skip duplicates for first element
        if i > 0 and arr[i] == arr[i-1]:
            continue
            
        for j in range(i + 1, n - 2):
            # Skip duplicates for second element
            if j > i + 1 and arr[j] == arr[j-1]:
                continue
            
            # Two pointers for remaining elements
            left = j + 1
            right = n - 1
            target = X - arr[i] - arr[j]
            
            while left < right:
                curr_sum = arr[left] + arr[right]
                
                if curr_sum == target:
                    result.append([arr[i], arr[j], arr[left], arr[right]])
                    
                    # Skip duplicates
                    while left < right and arr[left] == arr[left+1]:
                        left += 1
                    while left < right and arr[right] == arr[right-1]:
                        right -= 1
                    
                    left += 1
                    right -= 1
                elif curr_sum < target:
                    left += 1
                else:
                    right -= 1
    
    return result
```

---

## Finding All Unique Quadruples

The above implementation already handles duplicates by:
1. Sorting the array first
2. Skipping duplicate values for each position

---

## Time and Space Complexity

| Approach | Time | Space |
|----------|------|-------|
| Brute Force | O(n^4) | O(1) |
| Hash Map | O(n^2) | O(n^2) |
| Sort + Two Pointers | O(n^3) | O(1) |

---

## Key Takeaways

1. **Reduce dimensions**: Four sum -> Fix two + Two sum
2. **Sorting enables two pointers**: After sorting, use two pointers for linear search
3. **Handle duplicates**: Skip same values to get unique quadruples
4. **Generalization**: k-sum problem can use recursion with base case of two-sum
