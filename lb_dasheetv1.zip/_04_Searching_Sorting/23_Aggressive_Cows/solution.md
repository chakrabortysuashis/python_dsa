# Aggressive Cows

## Problem Statement

Given `n` stalls at positions `x1, x2, ..., xn` and `c` cows, place the cows in stalls such that the **minimum distance** between any two cows is **maximized**.

**Example 1:**
```
Input: stalls = [1, 2, 4, 8, 9], c = 3
Output: 3
Explanation: Place cows at positions 1, 4, 9
             Distances: 4-1=3, 9-4=5
             Minimum distance = 3 (maximized)
```

**Example 2:**
```
Input: stalls = [1, 2, 3], c = 2
Output: 2
Explanation: Place at 1 and 3, distance = 2
```

---

## Approach Intuition

### Key Insight: Binary Search on Answer
Instead of searching for positions, **binary search on the answer** (the minimum distance).

For each candidate distance `d`:
- Check if we can place all `c` cows such that each pair is at least `d` apart
- If yes, try larger distance
- If no, try smaller distance

### Why Binary Search Works
- Minimum possible answer: 1 (adjacent stalls)
- Maximum possible answer: `(max_position - min_position) / (c - 1)`
- If we can place cows with distance `d`, we can also place with distance `d-1`
- **Monotonic property** enables binary search

---

## Brute Force Approach

### Algorithm
Try all possible placements and find maximum minimum distance.

### Complexity
- Exponentially many placements
- Not practical for large inputs

---

## Optimal Approach: Binary Search on Answer

### Algorithm
1. Sort stall positions
2. Binary search on distance `d` from 1 to `(max - min) / (c - 1)`
3. For each `d`, greedily check if `c` cows can be placed
4. Greedy: Place first cow at first stall, then each next cow at first valid stall

### Visualization

```
Stalls: [1, 2, 4, 8, 9], c = 3
Sorted: [1, 2, 4, 8, 9]

low = 1, high = (9 - 1) / (3 - 1) = 4

=== Binary Search ===

Step 1: mid = 2
  Can we place 3 cows with min distance 2?
  
  Cow 1 at stall 1
  Cow 2: Next stall >= 1+2=3 -> stall 4 (position 4)
  Cow 3: Next stall >= 4+2=6 -> stall 8 (position 8)
  
  Placed 3 cows! YES
  Try larger: low = mid + 1 = 3

Step 2: mid = 3
  Can we place 3 cows with min distance 3?
  
  Cow 1 at stall 1
  Cow 2: Next stall >= 1+3=4 -> stall 4 (position 4)
  Cow 3: Next stall >= 4+3=7 -> stall 8 (position 8)
  
  Placed 3 cows! YES
  Try larger: low = mid + 1 = 4

Step 3: mid = 4
  Can we place 3 cows with min distance 4?
  
  Cow 1 at stall 1
  Cow 2: Next stall >= 1+4=5 -> stall 8 (position 8)
  Cow 3: Next stall >= 8+4=12 -> No stall available!
  
  Only 2 cows placed. NO
  Try smaller: high = mid - 1 = 3

Step 4: low=4, high=3 -> low > high, stop!
  Answer = 3
```

### Search Space Reduction

```
Stalls: n = 5, Cows: c = 3

Brute force: C(5,3) = 10 combinations
Binary search: log2(4) = 2 iterations
Each check: O(n) greedy placement

Total: O(n log(max_distance))
```

---

## Greedy Placement Check

```python
def can_place(stalls, c, min_dist):
    """
    Check if c cows can be placed with at least min_dist apart.
    Greedy: Place each cow at first valid position.
    """
    count = 1  # Place first cow at first stall
    last_position = stalls[0]
    
    for i in range(1, len(stalls)):
        if stalls[i] - last_position >= min_dist:
            count += 1
            last_position = stalls[i]
            
            if count == c:
                return True
    
    return count >= c
```

---

## Code Implementation

```python
def aggressive_cows(stalls, c):
    """
    Find maximum possible minimum distance between cows.
    Binary search on the answer with greedy validation.
    """
    stalls.sort()
    n = len(stalls)
    
    # Binary search bounds
    low = 1
    high = (stalls[n - 1] - stalls[0]) // (c - 1)
    
    result = 0
    
    while low <= high:
        mid = (low + high) // 2
        
        if can_place(stalls, c, mid):
            result = mid  # This distance works, try larger
            low = mid + 1
        else:
            high = mid - 1  # Distance too large, try smaller
    
    return result
```

---

## Dry Run with Different Example

```
Stalls: [4, 2, 1, 3, 6], c = 2
Sorted: [1, 2, 3, 4, 6]

low = 1, high = (6-1)/(2-1) = 5

mid = 3: Can place 2 cows with dist >= 3?
  Cow 1 at 1
  Cow 2: >= 1+3=4 -> position 4
  YES! result = 3, low = 4

mid = 4: Can place 2 cows with dist >= 4?
  Cow 1 at 1
  Cow 2: >= 1+4=5 -> position 6
  YES! result = 4, low = 5

mid = 5: Can place 2 cows with dist >= 5?
  Cow 1 at 1
  Cow 2: >= 1+5=6 -> position 6
  YES! result = 5, low = 6

low > high, stop!
Answer = 5 (place at 1 and 6)
```

---

## Time and Space Complexity

### Optimal Approach
- **Time**: O(n log n + n log(max_dist))
  - Sorting: O(n log n)
  - Binary search: O(log(max_dist)) iterations
  - Each validation: O(n)
  
- **Space**: O(1) extra (sorting in-place)

### Comparison
| Approach | Time | Space |
|----------|------|-------|
| Brute Force | O(C(n,c) * c) | O(c) |
| Binary Search | O(n log n + n log D) | O(1) |

Where D = max_position - min_position

---

## Key Takeaways

1. **Binary search on answer**: When asked to maximize/minimize something, consider searching on the answer

2. **Greedy validation**: For each candidate answer, use greedy approach to check feasibility

3. **Monotonicity**: If distance `d` is achievable, so is any smaller distance

4. **Sort first**: Essential for greedy placement to work

5. **Search bounds**:
   - low = 1 (minimum possible distance)
   - high = range / (c - 1) (maximum if evenly distributed)

6. **Related problems**:
   - Book Allocation
   - Painter's Partition
   - Minimize maximum load
