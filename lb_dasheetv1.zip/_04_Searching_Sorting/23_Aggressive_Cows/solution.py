"""
Aggressive Cows
===============

Problem: Place c cows in n stalls to maximize the minimum distance
between any two cows.

Solution: Binary search on the answer (minimum distance)
- For each candidate distance, greedily check if placement is possible
- If possible, try larger distance; else try smaller

Time Complexity: O(n log n + n log D) where D = max - min position
Space Complexity: O(1) extra
"""


def can_place_cows(stalls: list, c: int, min_dist: int) -> bool:
    """
    Check if c cows can be placed with at least min_dist apart.

    Greedy approach: Place each cow at the first valid position.
    """
    count = 1  # Place first cow at first stall
    last_position = stalls[0]

    for i in range(1, len(stalls)):
        if stalls[i] - last_position >= min_dist:
            count += 1
            last_position = stalls[i]

            if count == c:
                return True

    return count >= c


def aggressive_cows(stalls: list, c: int) -> int:
    """
    Find maximum possible minimum distance between cows.

    Binary search on the answer with greedy validation.
    """
    if len(stalls) < c:
        return -1

    stalls = sorted(stalls)
    n = len(stalls)

    # Binary search bounds
    low = 1  # Minimum possible distance
    high = (stalls[n - 1] - stalls[0]) // (c - 1)  # Maximum possible

    result = 0

    while low <= high:
        mid = (low + high) // 2

        if can_place_cows(stalls, c, mid):
            result = mid  # This distance works, try larger
            low = mid + 1
        else:
            high = mid - 1  # Distance too large, try smaller

    return result


def aggressive_cows_with_positions(stalls: list, c: int) -> tuple:
    """
    Return maximum min distance AND the actual positions.
    """
    if len(stalls) < c:
        return -1, []

    stalls = sorted(stalls)
    max_dist = aggressive_cows(stalls, c)

    # Find actual positions with this distance
    positions = [stalls[0]]
    last = stalls[0]

    for i in range(1, len(stalls)):
        if stalls[i] - last >= max_dist and len(positions) < c:
            positions.append(stalls[i])
            last = stalls[i]

    return max_dist, positions


# ==================== TEST CASES ====================

def test_aggressive_cows():
    """Comprehensive test cases."""

    print("=" * 60)
    print("AGGRESSIVE COWS")
    print("=" * 60)

    test_cases = [
        # (stalls, cows, expected_max_min_distance)
        ([1, 2, 4, 8, 9], 3, 3),
        ([1, 2, 3], 2, 2),
        ([4, 2, 1, 3, 6], 2, 5),
        ([1, 2, 8, 4, 9], 3, 3),
        ([0, 3, 4, 7, 10, 9], 4, 3),
        ([1, 5], 2, 4),
        ([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 3, 4),
        ([1, 10], 2, 9),
    ]

    all_passed = True

    for i, (stalls, c, expected) in enumerate(test_cases, 1):
        result = aggressive_cows(stalls.copy(), c)
        dist, positions = aggressive_cows_with_positions(stalls.copy(), c)

        status = "PASS" if result == expected else "FAIL"
        if result != expected:
            all_passed = False

        print(f"\nTest {i}: {status}")
        print(f"  Stalls: {stalls}")
        print(f"  Cows: {c}")
        print(f"  Expected max min distance: {expected}")
        print(f"  Got: {result}")
        print(f"  Positions: {positions}")

    print("\n" + "=" * 60)
    print(f"All tests passed: {all_passed}")
    print("=" * 60)


def visualize_algorithm(stalls: list, c: int):
    """Visualize the binary search process."""

    print(f"\nVisualizing Aggressive Cows")
    print(f"Stalls: {stalls}")
    print(f"Cows: {c}")
    print("=" * 60)

    stalls = sorted(stalls)
    n = len(stalls)

    print(f"Sorted stalls: {stalls}")

    low = 1
    high = (stalls[n - 1] - stalls[0]) // (c - 1)

    print(f"Search range: low={low}, high={high}")

    result = 0
    step = 1

    while low <= high:
        mid = (low + high) // 2

        print(f"\n--- Step {step}: Try distance {mid} ---")

        # Check placement
        count = 1
        last = stalls[0]
        positions = [stalls[0]]

        print(f"  Place cow 1 at position {stalls[0]}")

        for i in range(1, n):
            if stalls[i] - last >= mid:
                count += 1
                positions.append(stalls[i])
                print(f"  Place cow {count} at position {stalls[i]} (distance from prev: {stalls[i] - last})")
                last = stalls[i]

                if count == c:
                    break

        if count >= c:
            print(f"  SUCCESS! Placed {count} cows with min distance {mid}")
            print(f"  Positions: {positions}")
            result = mid
            low = mid + 1
            print(f"  Try larger: low = {low}")
        else:
            print(f"  FAILED! Only placed {count} cows (need {c})")
            high = mid - 1
            print(f"  Try smaller: high = {high}")

        step += 1

    print(f"\n{'=' * 60}")
    print(f"Maximum minimum distance: {result}")

    dist, final_positions = aggressive_cows_with_positions(stalls, c)
    print(f"Final positions: {final_positions}")


if __name__ == "__main__":
    test_aggressive_cows()

    # Visualize
    visualize_algorithm([1, 2, 4, 8, 9], 3)
