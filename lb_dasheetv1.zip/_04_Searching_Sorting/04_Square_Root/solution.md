# Square Root of an Integer

## Problem Statement

Given a non-negative integer `n`, find the square root of `n` rounded down to the nearest integer. You cannot use built-in sqrt functions.

**Example 1:**
```
Input: n = 8
Output: 2
Explanation: sqrt(8) = 2.828..., rounded down is 2
```

**Example 2:**
```
Input: n = 4
Output: 2
Explanation: sqrt(4) = 2 exactly
```

**Example 3:**
```
Input: n = 0
Output: 0
```

---

## Binary Search Intuition

We're looking for the largest integer `x` such that `x * x <= n`.

**Search Space**: All integers from 0 to n (actually 0 to n//2 + 1 is sufficient)

**Binary Search Condition**:
- If `mid * mid <= n`: mid could be the answer, search RIGHT for larger
- If `mid * mid > n`: mid is too big, search LEFT

This is a classic **Binary Search on Answer** problem!

---

## Brute Force Approach

### Algorithm
Start from 0, increment until `i * i > n`.

### Code
```python
def sqrt_brute(n):
    if n < 2:
        return n
    
    i = 1
    while i * i <= n:
        i += 1
    
    return i - 1
```

### Complexity
- **Time**: O(sqrt(n))
- **Space**: O(1)

---

## Optimal Approach: Binary Search

### Algorithm
1. Search space: `[0, n]` (can optimize to `[0, n//2 + 1]`)
2. For each `mid`, check if `mid * mid <= n`
3. If yes, record answer and search RIGHT for larger
4. If no, search LEFT for smaller

### Visualization of Pointer Movement

```
Find sqrt(8)

Search space: [0, 8]

Step 1: low=0, high=8, mid=4
        Is 4*4 = 16 <= 8? NO
        4 is too big, search LEFT
        high = mid - 1 = 3

Step 2: low=0, high=3, mid=1
        Is 1*1 = 1 <= 8? YES
        1 could be answer, record it
        Search RIGHT for larger: low = mid + 1 = 2

Step 3: low=2, high=3, mid=2
        Is 2*2 = 4 <= 8? YES
        2 could be answer (better than 1), record it
        Search RIGHT for larger: low = mid + 1 = 3

Step 4: low=3, high=3, mid=3
        Is 3*3 = 9 <= 8? NO
        3 is too big, search LEFT
        high = mid - 1 = 2

Step 5: low=3, high=2
        low > high, STOP!
        Answer = 2
```

### Another Example: Perfect Square

```
Find sqrt(16)

Step 1: low=0, high=16, mid=8
        Is 8*8 = 64 <= 16? NO
        high = 7

Step 2: low=0, high=7, mid=3
        Is 3*3 = 9 <= 16? YES
        result = 3, low = 4

Step 3: low=4, high=7, mid=5
        Is 5*5 = 25 <= 16? NO
        high = 4

Step 4: low=4, high=4, mid=4
        Is 4*4 = 16 <= 16? YES!
        result = 4, low = 5

Step 5: low=5, high=4
        STOP! Answer = 4

Verification: 4 * 4 = 16 = n (perfect square!)
```

---

## Search Space Visualization

```
n = 8
Looking for: largest x where x*x <= 8

x:     0  1  2  3  4  5  6  7  8
x*x:   0  1  4  9  16 25 36 49 64
<=8?   Y  Y  Y  N  N  N  N  N  N
            ^
       Answer: 2 (last Y)

Binary search finds this transition point in O(log n) instead of O(sqrt(n))!
```

---

## Code Implementation

```python
def mySqrt(n):
    if n < 2:
        return n
    
    low, high = 1, n // 2 + 1
    result = 0
    
    while low <= high:
        mid = low + (high - low) // 2
        
        if mid * mid <= n:
            result = mid      # mid could be answer
            low = mid + 1     # search for larger
        else:
            high = mid - 1    # mid too big
    
    return result
```

---

## Alternative: Newton's Method

Newton-Raphson method for faster convergence:

```python
def sqrt_newton(n):
    if n < 2:
        return n
    
    x = n
    while x * x > n:
        x = (x + n // x) // 2
    
    return x
```

This converges in O(log log n) time!

---

## Time and Space Complexity

### Binary Search Approach
- **Time Complexity**: O(log n)
  - Binary search on range [0, n]

- **Space Complexity**: O(1)
  - Only using constant extra space

### Comparison
| Approach | Time | Space |
|----------|------|-------|
| Brute Force | O(sqrt(n)) | O(1) |
| Binary Search | O(log n) | O(1) |
| Newton's Method | O(log log n) | O(1) |

---

## Edge Cases

1. **n = 0**: Return 0
2. **n = 1**: Return 1
3. **Perfect square**: n = 4, 9, 16, etc. - return exact root
4. **Large n**: Use `mid <= n // mid` instead of `mid * mid <= n` to avoid overflow

---

## Avoiding Overflow

For large numbers, `mid * mid` might overflow. Use division instead:

```python
def mySqrt_safe(n):
    if n < 2:
        return n
    
    low, high = 1, n
    
    while low <= high:
        mid = low + (high - low) // 2
        
        if mid <= n // mid:  # Avoids overflow
            if (mid + 1) > n // (mid + 1):
                return mid  # mid is the answer
            low = mid + 1
        else:
            high = mid - 1
    
    return low - 1
```

---

## Key Takeaways

1. **Binary Search on Answer**: When looking for a value satisfying a condition, binary search the answer space!

2. **Search space optimization**: Can reduce from `[0, n]` to `[0, n//2 + 1]` since sqrt(n) <= n/2 for n >= 4

3. **Monotonic property**: `x*x` is monotonically increasing, so binary search works

4. **Record and continue**: When `mid*mid <= n`, record mid but keep searching for larger values

5. **Overflow handling**: Use `mid <= n/mid` instead of `mid*mid <= n` for large inputs

6. **This pattern applies to**:
   - Finding nth root
   - Finding smallest x such that f(x) >= target
   - Minimizing/maximizing when function is monotonic
