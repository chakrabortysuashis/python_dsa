"""
Square Root of an Integer
==========================

Problem: Given a non-negative integer n, find the square root of n
rounded down to the nearest integer without using built-in sqrt functions.

This is a classic "Binary Search on Answer" problem!

Time Complexity: O(log n)
Space Complexity: O(1)
"""


def my_sqrt(n: int) -> int:
    """
    Find integer square root using binary search.

    We're looking for the largest integer x such that x * x <= n.

    Key insight: The function f(x) = x*x is monotonically increasing,
    so we can binary search for the transition point where x*x goes from <= n to > n.

    Args:
        n: Non-negative integer

    Returns:
        Floor of square root of n
    """
    if n < 2:
        return n

    # Search space: [1, n//2 + 1]
    # sqrt(n) <= n/2 for n >= 4
    low, high = 1, n // 2 + 1
    result = 0

    while low <= high:
        mid = low + (high - low) // 2

        # Check if mid could be the square root
        if mid * mid <= n:
            result = mid      # mid is a valid candidate
            low = mid + 1     # but there might be a larger one
        else:
            high = mid - 1    # mid is too big

    return result


def my_sqrt_safe(n: int) -> int:
    """
    Square root with overflow protection.

    Uses mid <= n // mid instead of mid * mid <= n
    to avoid integer overflow for very large numbers.
    """
    if n < 2:
        return n

    low, high = 1, n

    while low <= high:
        mid = low + (high - low) // 2

        # Use division to avoid overflow
        if mid <= n // mid:
            # Check if mid+1 would be too big
            if (mid + 1) > n // (mid + 1):
                return mid
            low = mid + 1
        else:
            high = mid - 1

    return low - 1


def my_sqrt_brute(n: int) -> int:
    """
    Brute force approach: Linear search.

    Time Complexity: O(sqrt(n))
    Space Complexity: O(1)
    """
    if n < 2:
        return n

    i = 1
    while i * i <= n:
        i += 1

    return i - 1


def my_sqrt_newton(n: int) -> int:
    """
    Newton-Raphson method for square root.

    The iteration formula: x_new = (x + n/x) / 2

    This method converges very quickly - O(log log n)!

    Time Complexity: O(log log n)
    Space Complexity: O(1)
    """
    if n < 2:
        return n

    x = n
    while x * x > n:
        x = (x + n // x) // 2

    return x


def sqrt_with_precision(n: int, precision: int = 6) -> float:
    """
    Find square root with decimal precision using binary search.

    Args:
        n: Non-negative integer
        precision: Number of decimal places

    Returns:
        Square root with specified precision
    """
    if n < 0:
        raise ValueError("Cannot compute square root of negative number")

    if n == 0:
        return 0.0

    low, high = 0.0, float(n)

    # For numbers less than 1, high should be 1
    if n < 1:
        high = 1.0

    # Binary search with floating point
    epsilon = 10 ** (-precision - 1)

    while high - low > epsilon:
        mid = (low + high) / 2

        if mid * mid <= n:
            low = mid
        else:
            high = mid

    return round(low, precision)


def nth_root(n: int, k: int) -> int:
    """
    Find the kth root of n, rounded down.

    Generalization of square root (k=2).

    Time Complexity: O(log n)
    """
    if n < 2:
        return n

    low, high = 1, n

    while low <= high:
        mid = low + (high - low) // 2

        # Calculate mid^k (with overflow protection)
        power = 1
        overflow = False
        for _ in range(k):
            if power > n // mid:
                overflow = True
                break
            power *= mid

        if overflow or power > n:
            high = mid - 1
        else:
            low = mid + 1

    return high


# ==================== TEST CASES ====================

def test_sqrt():
    """Comprehensive test cases."""

    print("=" * 60)
    print("SQUARE ROOT OF INTEGER")
    print("=" * 60)

    test_cases = [
        # (n, expected)
        (0, 0),
        (1, 1),
        (4, 2),
        (8, 2),
        (9, 3),
        (15, 3),
        (16, 4),
        (17, 4),
        (100, 10),
        (99, 9),
        (101, 10),
        (2147395599, 46339),  # Large number test
    ]

    all_passed = True

    for n, expected in test_cases:
        result = my_sqrt(n)
        status = "PASS" if result == expected else "FAIL"

        if result != expected:
            all_passed = False

        print(f"  sqrt({n}) = {result} [{status}]")
        if result != expected:
            print(f"    Expected: {expected}")

    # Test all methods give same result
    print("\n" + "-" * 60)
    print("Comparing All Methods:")
    print("-" * 60)

    test_values = [0, 1, 2, 8, 9, 15, 16, 100, 1000]

    for n in test_values:
        bs = my_sqrt(n)
        brute = my_sqrt_brute(n)
        newton = my_sqrt_newton(n)

        all_same = bs == brute == newton
        status = "PASS" if all_same else "FAIL"

        print(f"  n={n:4}: binary={bs}, brute={brute}, newton={newton} [{status}]")

    # Test precision version
    print("\n" + "-" * 60)
    print("Square Root with Precision:")
    print("-" * 60)

    precision_tests = [(2, 1.414214), (3, 1.732051), (5, 2.236068), (10, 3.162278)]

    for n, expected in precision_tests:
        result = sqrt_with_precision(n, 6)
        diff = abs(result - expected)
        status = "PASS" if diff < 0.00001 else "FAIL"
        print(f"  sqrt({n}) = {result} (expected ~{expected}) [{status}]")

    print("\n" + "=" * 60)
    print(f"All tests passed: {all_passed}")
    print("=" * 60)


def visualize_search(n: int):
    """Visualize the binary search process."""

    print(f"\nFinding sqrt({n})")
    print("-" * 40)

    if n < 2:
        print(f"  n < 2, return {n}")
        return n

    low, high = 1, n // 2 + 1
    result = 0
    step = 1

    print(f"Search space: [{low}, {high}]")
    print()

    while low <= high:
        mid = low + (high - low) // 2
        square = mid * mid

        print(f"Step {step}:")
        print(f"  low={low}, high={high}, mid={mid}")
        print(f"  mid*mid = {mid}*{mid} = {square}")

        if square <= n:
            result = mid
            print(f"  {square} <= {n}? YES!")
            print(f"  {mid} could be answer (recorded), search RIGHT")
            print(f"  low = {mid + 1}")
            low = mid + 1
        else:
            print(f"  {square} <= {n}? NO!")
            print(f"  {mid} is too big, search LEFT")
            print(f"  high = {mid - 1}")
            high = mid - 1

        step += 1
        print()

    print(f"RESULT: sqrt({n}) = {result}")
    print(f"Verification: {result}*{result} = {result*result} <= {n}")
    if result + 1 <= n:
        print(f"             {result+1}*{result+1} = {(result+1)**2} > {n}")

    return result


def show_search_space(n: int):
    """Show the complete search space to understand the pattern."""

    print(f"\nSearch Space Visualization for sqrt({n})")
    print("-" * 50)

    max_check = min(n + 1, 20)

    print("x:     ", end="")
    for x in range(max_check):
        print(f"{x:4}", end="")
    print()

    print("x*x:   ", end="")
    for x in range(max_check):
        print(f"{x*x:4}", end="")
    print()

    print(f"<={n}?  ", end="")
    answer = 0
    for x in range(max_check):
        if x * x <= n:
            print("   Y", end="")
            answer = x
        else:
            print("   N", end="")
    print()

    print()
    print(f"Answer: {answer} (last position with Y)")
    print(f"Binary search finds this in O(log n) = O({len(bin(n))-2}) steps")


if __name__ == "__main__":
    test_sqrt()

    # Visualize examples
    print("\n" + "=" * 60)
    print("VISUALIZATION")
    print("=" * 60)

    visualize_search(8)
    visualize_search(16)
    visualize_search(10)

    # Show search space
    show_search_space(15)
