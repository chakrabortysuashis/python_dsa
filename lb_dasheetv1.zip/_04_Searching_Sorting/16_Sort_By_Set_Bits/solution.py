"""
Sort Array by Number of Set Bits
================================

Problem: Sort array in decreasing order of set bit count (1s in binary).
If two elements have same set bits, maintain their relative order (stable).

Time Complexity: O(n log n) using comparison sort
Space Complexity: O(n)
"""


def count_set_bits(n: int) -> int:
    """
    Brian Kernighan's Algorithm to count set bits.
    n & (n-1) removes the rightmost set bit.

    Time: O(number of set bits) - very efficient!
    """
    count = 0
    n = abs(n)  # Handle negative numbers
    while n:
        n &= (n - 1)  # Remove rightmost set bit
        count += 1
    return count


def count_set_bits_simple(n: int) -> int:
    """
    Simple bit counting - check each bit.
    Time: O(log n) - checks all bits
    """
    count = 0
    n = abs(n)
    while n:
        count += n & 1
        n >>= 1
    return count


def sort_by_set_bits(arr: list) -> list:
    """
    Sort by set bits in descending order using Python's stable sort.

    Key insight: Python's sort is stable (Timsort), so elements with
    equal keys maintain their relative order.
    """
    return sorted(arr, key=lambda x: -count_set_bits(x))


def sort_by_set_bits_explicit_stable(arr: list) -> list:
    """
    Explicitly maintain stability using enumeration.
    Sort by (-set_bits, original_index) to guarantee stability.
    """
    decorated = [(-count_set_bits(x), i, x) for i, x in enumerate(arr)]
    decorated.sort()
    return [x[2] for x in decorated]


def sort_by_set_bits_bucket(arr: list) -> list:
    """
    Bucket sort approach - O(n) time.
    Works because set bit count is bounded (0-64 for 64-bit integers).
    """
    # Create buckets for each possible set bit count
    max_bits = 65  # Support up to 64-bit integers
    buckets = [[] for _ in range(max_bits)]

    # Place each element in its bucket
    for num in arr:
        bits = count_set_bits(num)
        buckets[bits].append(num)

    # Concatenate buckets in decreasing order of set bits
    result = []
    for i in range(max_bits - 1, -1, -1):
        result.extend(buckets[i])

    return result


def sort_ascending_set_bits(arr: list) -> list:
    """Sort in ascending order of set bits."""
    return sorted(arr, key=count_set_bits)


# ==================== TEST CASES ====================

def test_sort_by_set_bits():
    """Comprehensive test cases."""

    print("=" * 60)
    print("SORT BY SET BITS COUNT")
    print("=" * 60)

    test_cases = [
        # (array, expected)
        ([5, 2, 3, 9, 4, 6, 7, 15, 32],
         [15, 7, 5, 3, 9, 6, 2, 4, 32]),
        ([1, 2, 3, 4, 5, 6],
         [3, 5, 6, 1, 2, 4]),
        ([8, 4, 2, 1],
         [8, 4, 2, 1]),  # All have 1 bit, maintain order
        ([7, 7, 7],
         [7, 7, 7]),  # All same
        ([0, 0, 0],
         [0, 0, 0]),  # All zeros
        ([1],
         [1]),  # Single element
        ([],
         []),  # Empty
        ([255, 128, 64, 32, 16, 8, 4, 2, 1],
         [255, 128, 64, 32, 16, 8, 4, 2, 1]),  # Already sorted by bits
    ]

    all_passed = True

    for i, (arr, expected) in enumerate(test_cases, 1):
        result = sort_by_set_bits(arr.copy())
        status = "PASS" if result == expected else "FAIL"

        if result != expected:
            all_passed = False

        print(f"\nTest {i}: {status}")
        print(f"  Input: {arr}")
        print(f"  Expected: {expected}")
        print(f"  Got: {result}")

        # Show set bit counts
        if len(arr) <= 10:
            bits_info = [(x, count_set_bits(x)) for x in arr]
            print(f"  Bits: {bits_info}")

    # Compare implementations
    print("\n" + "-" * 60)
    print("Comparing Implementations:")
    print("-" * 60)

    for arr, expected in test_cases[:4]:
        r1 = sort_by_set_bits(arr.copy())
        r2 = sort_by_set_bits_explicit_stable(arr.copy())
        r3 = sort_by_set_bits_bucket(arr.copy())

        all_same = r1 == r2 == r3 == expected
        print(f"  {arr[:5]}{'...' if len(arr) > 5 else ''} -> All match: {all_same}")

    # Test Brian Kernighan vs simple counting
    print("\n" + "-" * 60)
    print("Bit Counting Methods:")
    print("-" * 60)

    test_numbers = [0, 1, 7, 15, 16, 255, 1023, 1024]
    for n in test_numbers:
        bk = count_set_bits(n)
        simple = count_set_bits_simple(n)
        builtin = bin(n).count('1')
        print(f"  {n:4d} ({bin(n):>12s}): BK={bk}, Simple={simple}, Builtin={builtin}")

    print("\n" + "=" * 60)
    print(f"All tests passed: {all_passed}")
    print("=" * 60)


def visualize_algorithm(arr: list):
    """Visualize the sorting process."""

    print(f"\nVisualizing Sort by Set Bits")
    print(f"Input: {arr}")
    print("=" * 60)

    # Show binary and set bit count for each
    print("\nStep 1: Count set bits")
    data = []
    for i, num in enumerate(arr):
        bits = count_set_bits(num)
        binary = bin(num)[2:].zfill(8)
        data.append((num, bits, i, binary))
        print(f"  {num:4d} = {binary} -> {bits} set bits")

    # Group by set bits
    print("\nStep 2: Group by set bit count")
    from collections import defaultdict
    groups = defaultdict(list)
    for num, bits, idx, binary in data:
        groups[bits].append((num, idx))

    for bits in sorted(groups.keys(), reverse=True):
        elements = groups[bits]
        print(f"  {bits} bits: {[e[0] for e in elements]} (indices: {[e[1] for e in elements]})")

    # Final result
    result = sort_by_set_bits(arr)
    print(f"\nFinal result: {result}")

    # Verify stability
    print("\nStability check:")
    prev_bits = float('inf')
    prev_indices = {}
    is_stable = True

    for num in result:
        bits = count_set_bits(num)
        if bits < prev_bits:
            prev_bits = bits
            prev_indices[bits] = []
        # Track original indices for same bit count
        orig_idx = arr.index(num)
        if bits in prev_indices:
            if prev_indices[bits] and orig_idx < max(prev_indices[bits]):
                is_stable = False
            prev_indices[bits].append(orig_idx)

    print(f"  Stable sort maintained: {is_stable}")


if __name__ == "__main__":
    test_sort_by_set_bits()

    # Visualize specific examples
    visualize_algorithm([5, 2, 3, 9, 4, 6, 7, 15, 32])
    visualize_algorithm([3, 8, 3, 1, 5])
