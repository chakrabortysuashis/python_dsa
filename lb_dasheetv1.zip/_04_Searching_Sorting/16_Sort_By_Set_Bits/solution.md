# Sort Array by Number of Set Bits

## Problem Statement

Given an array of integers, sort the array in **decreasing order** of the count of set bits (1s in binary representation). If two elements have the same number of set bits, maintain their **relative order** (stable sort).

**Example 1:**
```
Input: arr = [5, 2, 3, 9, 4, 6, 7, 15, 32]
Output: [15, 7, 5, 3, 6, 9, 2, 4, 32]

Binary representations:
  15 = 1111 (4 bits)
  7  = 0111 (3 bits)
  5  = 0101 (2 bits), 3 = 0011 (2 bits), 6 = 0110 (2 bits), 9 = 1001 (2 bits)
  2  = 0010 (1 bit),  4 = 0100 (1 bit), 32 = 100000 (1 bit)
```

**Example 2:**
```
Input: arr = [1, 2, 3, 4, 5, 6]
Output: [3, 5, 6, 1, 2, 4]
```

---

## Approach Intuition

### Counting Set Bits
```
Number: 13
Binary: 1101
Set bits: 3 (count of 1s)

Method 1: Brian Kernighan's Algorithm
  n & (n-1) removes rightmost set bit
  Count iterations until n = 0

Method 2: Built-in
  bin(n).count('1')
```

### Stable Sort Requirement
Elements with equal set bits should maintain their original order.
- Python's sort is stable (Timsort)
- Use `sorted()` with custom key

---

## Brute Force Approach

### Algorithm
1. Create pairs of (set_bit_count, original_value)
2. Sort by set_bit_count (descending)
3. Extract values

### Code
```python
def sort_by_set_bits_brute(arr):
    def count_bits(n):
        count = 0
        while n:
            count += n & 1
            n >>= 1
        return count
    
    # Create (count, index, value) tuples
    decorated = [(count_bits(x), i, x) for i, x in enumerate(arr)]
    # Sort by count descending, then by index (for stability)
    decorated.sort(key=lambda x: (-x[0], x[1]))
    return [x[2] for x in decorated]
```

### Complexity
- **Time**: O(n log n) for sorting + O(n * log(max_val)) for bit counting
- **Space**: O(n)

---

## Optimal Approach: Custom Comparator

### Algorithm
Use Python's stable sort with a key function that returns negative of set bit count.

### Visualization

```
Array: [5, 2, 3, 9, 4, 6, 7, 15, 32]

Step 1: Count set bits for each element
  5  = 0101  -> 2 bits
  2  = 0010  -> 1 bit
  3  = 0011  -> 2 bits
  9  = 1001  -> 2 bits
  4  = 0100  -> 1 bit
  6  = 0110  -> 2 bits
  7  = 0111  -> 3 bits
  15 = 1111  -> 4 bits
  32 = 100000 -> 1 bit

Step 2: Sort by set bits (descending), maintaining stability
  4 bits: [15]
  3 bits: [7]
  2 bits: [5, 3, 9, 6]  (original order maintained!)
  1 bit:  [2, 4, 32]    (original order maintained!)

Result: [15, 7, 5, 3, 9, 6, 2, 4, 32]
```

### Search Space Reduction (Counting Sort Variant)

```
For small range of set bits (0 to 32 for 32-bit integers):

1. Group elements by set bit count: O(n)
2. Concatenate groups in decreasing order: O(n)

This achieves O(n) time but uses O(n) space for buckets.
```

---

## Brian Kernighan's Algorithm

```
Key insight: n & (n-1) removes the rightmost set bit

Example: n = 12 (1100 in binary)
  Step 1: 12 & 11 = 1100 & 1011 = 1000 (removed rightmost 1)
  Step 2: 8 & 7 = 1000 & 0111 = 0000 (removed last 1)
  Count = 2

Why it works:
  n-1 flips all bits after the rightmost 1 (including that 1)
  n & (n-1) zeros out that rightmost 1
```

---

## Dry Run

```
Array: [3, 8, 3, 1, 5]

Count set bits:
  3 = 011 -> 2 bits
  8 = 1000 -> 1 bit
  3 = 011 -> 2 bits
  1 = 001 -> 1 bit
  5 = 101 -> 2 bits

Decorated: [(-2, 0, 3), (-1, 1, 8), (-2, 2, 3), (-1, 3, 1), (-2, 4, 5)]

After stable sort by first element (negative count):
  (-2, 0, 3), (-2, 2, 3), (-2, 4, 5), (-1, 1, 8), (-1, 3, 1)

Result: [3, 3, 5, 8, 1]

Verify:
  3, 3, 5 have 2 set bits (original order: indices 0, 2, 4)
  8, 1 have 1 set bit (original order: indices 1, 3)
```

---

## Code Implementation

```python
def count_set_bits(n):
    """Brian Kernighan's algorithm - O(number of set bits)"""
    count = 0
    while n:
        n &= (n - 1)  # Remove rightmost set bit
        count += 1
    return count

def sort_by_set_bits(arr):
    """
    Sort by set bits in descending order.
    Python's sort is stable, so equal elements maintain order.
    """
    return sorted(arr, key=lambda x: -count_set_bits(x))

def sort_by_set_bits_bucket(arr):
    """
    Bucket sort approach - O(n) time for limited bit range.
    """
    # Max set bits for 32-bit integer is 32
    buckets = [[] for _ in range(33)]
    
    for num in arr:
        bits = count_set_bits(num)
        buckets[bits].append(num)
    
    # Concatenate in decreasing order of set bits
    result = []
    for i in range(32, -1, -1):
        result.extend(buckets[i])
    
    return result
```

---

## Time and Space Complexity

### Comparison-based Sort
- **Time**: O(n log n)
  - Sorting dominates
  - Bit counting: O(log(max_value)) per element
  
- **Space**: O(n) for Timsort

### Bucket Sort Approach
- **Time**: O(n)
- **Space**: O(n) for buckets

### Comparison
| Approach | Time | Space | Stable? |
|----------|------|-------|---------|
| Custom Comparator | O(n log n) | O(n) | Yes |
| Bucket Sort | O(n) | O(n) | Yes |

---

## Key Takeaways

1. **Brian Kernighan's Algorithm**: `n & (n-1)` removes rightmost set bit
   - Much faster than checking each bit

2. **Stable sort importance**: Python's `sorted()` and `list.sort()` are stable

3. **Negative key trick**: Sort descending by using `-count_set_bits(x)`

4. **Bucket sort for limited range**: When range is small (32 possible set bit counts), bucket sort achieves O(n)

5. **Built-in alternative**: `bin(n).count('1')` works but is slower

6. **Related problems**:
   - Count set bits in range
   - Hamming distance
   - Power of 2 check (`n & (n-1) == 0`)
