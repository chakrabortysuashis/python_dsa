# Find a Pair with Given Difference

## Problem Statement

Given an unsorted array and a value `n`, find if there exists a pair of elements (a, b) such that `a - b = n`.

**Example 1:**
```
Input: arr = [5, 20, 3, 2, 50, 80], n = 78
Output: Yes (80, 2)
```

**Example 2:**
```
Input: arr = [1, 5, 3], n = 2
Output: Yes (5, 3) or (3, 1)
```

---

## Multiple Approaches

### Approach 1: Brute Force O(n^2)

Check all pairs.

```python
def find_pair_brute(arr, n):
    for i in range(len(arr)):
        for j in range(len(arr)):
            if i != j and arr[i] - arr[j] == n:
                return (arr[i], arr[j])
    return None
```

---

### Approach 2: Hash Set O(n)

For each element x, check if x + n or x - n exists.

```python
def find_pair_hash(arr, n):
    elements = set(arr)
    for x in arr:
        if (x + n) in elements:
            return (x + n, x)
    return None
```

---

### Approach 3: Two Pointers (After Sorting) O(n log n)

1. Sort the array
2. Use two pointers i, j starting at 0, 1
3. If arr[j] - arr[i] == n: found!
4. If arr[j] - arr[i] < n: increment j
5. If arr[j] - arr[i] > n: increment i

### Visualization

```
Array: [5, 20, 3, 2, 50, 80], n = 78
Sorted: [2, 3, 5, 20, 50, 80]

i=0, j=1: arr[j] - arr[i] = 3 - 2 = 1 < 78, j++
i=0, j=2: 5 - 2 = 3 < 78, j++
i=0, j=3: 20 - 2 = 18 < 78, j++
i=0, j=4: 50 - 2 = 48 < 78, j++
i=0, j=5: 80 - 2 = 78 == 78, FOUND! (80, 2)
```

### Another Example

```
Array: [1, 5, 3], n = 2
Sorted: [1, 3, 5]

i=0, j=1: 3 - 1 = 2 == 2, FOUND! (3, 1)
```

---

## Pointer Movement Logic

```
diff = arr[j] - arr[i]

Case 1: diff < n
  -> Need larger difference
  -> Increase j (makes arr[j] larger)

Case 2: diff > n
  -> Need smaller difference
  -> Increase i (makes arr[i] larger, reducing diff)

Case 3: diff == n
  -> Found the pair!

Note: Always keep j > i to avoid same element
```

---

## Code Implementation

```python
def find_pair_with_difference(arr, n):
    """
    Find pair (a, b) where a - b = n using two pointers.
    
    Time: O(n log n) for sorting
    Space: O(1) if in-place sort
    """
    if len(arr) < 2:
        return None
    
    # Handle negative difference
    n = abs(n)
    
    arr = sorted(arr)
    i, j = 0, 1
    
    while i < len(arr) and j < len(arr):
        diff = arr[j] - arr[i]
        
        if i != j and diff == n:
            return (arr[j], arr[i])
        elif diff < n:
            j += 1
        else:
            i += 1
            if i == j:  # Ensure j > i
                j += 1
    
    return None
```

---

## Finding All Pairs

```python
def find_all_pairs(arr, n):
    """Find all pairs with given difference."""
    result = []
    elements = set(arr)
    seen = set()
    
    for x in arr:
        if (x + n) in elements:
            pair = (max(x + n, x), min(x + n, x))
            if pair not in seen:
                result.append(pair)
                seen.add(pair)
    
    return result
```

---

## Time and Space Complexity

| Approach | Time | Space |
|----------|------|-------|
| Brute Force | O(n^2) | O(1) |
| Hash Set | O(n) | O(n) |
| Two Pointers | O(n log n) | O(1) |

---

## Key Takeaways

1. **Two pointers on sorted array**: Classic technique for pair problems
2. **Hash set for O(n)**: When space is available, hash set gives best time
3. **Handle edge cases**: 
   - Negative difference
   - Same element twice
   - Empty/single element array
4. **Pointer movement direction**: Based on whether we need larger or smaller difference
