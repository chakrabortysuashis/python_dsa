"""
Find a Pair with Given Difference
=================================

Problem: Find pair (a, b) such that a - b = n.

Multiple approaches: Brute force, Hash set, Two pointers.
"""

from typing import List, Tuple, Optional


def find_pair_brute(arr: List[int], n: int) -> Optional[Tuple[int, int]]:
    """
    Brute force: Check all pairs.

    Time: O(n^2)
    Space: O(1)
    """
    for i in range(len(arr)):
        for j in range(len(arr)):
            if i != j and arr[i] - arr[j] == n:
                return (arr[i], arr[j])
    return None


def find_pair_hash(arr: List[int], n: int) -> Optional[Tuple[int, int]]:
    """
    Hash set approach.

    For each element x, we need x - y = n, so y = x - n.
    Or we can look for x + n.

    Time: O(n)
    Space: O(n)
    """
    elements = set(arr)

    for x in arr:
        # Looking for y where x - y = n, so y = x - n
        if (x - n) in elements:
            return (x, x - n)

    return None


def find_pair_two_pointers(arr: List[int], n: int) -> Optional[Tuple[int, int]]:
    """
    Two pointers on sorted array.

    Time: O(n log n) for sorting
    Space: O(1) excluding sort space
    """
    if len(arr) < 2:
        return None

    # Handle negative difference
    n = abs(n)

    arr = sorted(arr)
    i, j = 0, 1

    while i < len(arr) and j < len(arr):
        # Ensure j > i
        if i == j:
            j += 1
            continue

        diff = arr[j] - arr[i]

        if diff == n:
            return (arr[j], arr[i])
        elif diff < n:
            j += 1
        else:
            i += 1

    return None


def find_all_pairs(arr: List[int], n: int) -> List[Tuple[int, int]]:
    """
    Find ALL pairs with given difference.

    Time: O(n)
    Space: O(n)
    """
    result = []
    elements = set(arr)
    seen = set()

    n = abs(n)  # Handle negative

    for x in arr:
        # Check for x - y = n (where y = x - n)
        if (x - n) in elements:
            pair = (x, x - n)
            if pair not in seen:
                result.append(pair)
                seen.add(pair)

        # For n != 0, also check x + n (where x - y = -n)
        if n != 0 and (x + n) in elements:
            pair = (x + n, x)
            if pair not in seen:
                result.append(pair)
                seen.add(pair)

    return result


def count_pairs(arr: List[int], n: int) -> int:
    """
    Count number of pairs with given difference.

    Time: O(n)
    Space: O(n)
    """
    from collections import Counter

    freq = Counter(arr)
    count = 0
    n = abs(n)

    if n == 0:
        # Count pairs of same elements
        for f in freq.values():
            count += f * (f - 1) // 2
    else:
        for x in freq:
            if (x + n) in freq:
                count += freq[x] * freq[x + n]

    return count


# ==================== TEST CASES ====================

def test_find_pair():
    """Test all approaches."""

    print("=" * 60)
    print("FIND PAIR WITH GIVEN DIFFERENCE")
    print("=" * 60)

    test_cases = [
        ([5, 20, 3, 2, 50, 80], 78),
        ([1, 5, 3], 2),
        ([1, 8, 30, 40, 100], 60),
        ([1, 2, 3, 4, 5], 0),
        ([1, 2, 3, 4, 5], 10),  # Not found
        ([-10, 5, -5, 0, 15], 10),
    ]

    for arr, n in test_cases:
        print(f"\nArray: {arr}, n = {n}")

        result_brute = find_pair_brute(arr.copy(), n)
        result_hash = find_pair_hash(arr.copy(), n)
        result_two_ptr = find_pair_two_pointers(arr.copy(), n)
        all_pairs = find_all_pairs(arr.copy(), n)

        print(f"  Brute force: {result_brute}")
        print(f"  Hash set:    {result_hash}")
        print(f"  Two pointers: {result_two_ptr}")
        print(f"  All pairs:   {all_pairs}")

        # Verify results
        def verify(pair, arr, n):
            if pair is None:
                return True
            a, b = pair
            return (a - b == n or a - b == -n) and a in arr and b in arr

        all_valid = all(verify(r, arr, n) for r in [result_brute, result_hash, result_two_ptr])
        print(f"  Results valid: {all_valid}")


def visualize_two_pointers(arr: List[int], n: int):
    """Visualize two pointer approach."""

    print(f"\n{'='*60}")
    print(f"TWO POINTERS VISUALIZATION")
    print(f"Array: {arr}, n = {n}")
    print("=" * 60)

    n = abs(n)
    sorted_arr = sorted(arr)
    print(f"Sorted: {sorted_arr}")
    print()

    i, j = 0, 1
    step = 1

    while i < len(sorted_arr) and j < len(sorted_arr):
        if i == j:
            j += 1
            continue

        diff = sorted_arr[j] - sorted_arr[i]

        # Create visualization
        vis = ["  "] * len(sorted_arr)
        vis[i] = " i"
        vis[j] = " j" if j != i else vis[j]

        arr_str = " ".join(f"{sorted_arr[k]:3}" for k in range(len(sorted_arr)))
        ptr_str = " ".join(f"{vis[k]:>3}" for k in range(len(sorted_arr)))

        print(f"Step {step}:")
        print(f"  Array: {arr_str}")
        print(f"  Ptrs:  {ptr_str}")
        print(f"  diff = arr[{j}] - arr[{i}] = {sorted_arr[j]} - {sorted_arr[i]} = {diff}")

        if diff == n:
            print(f"  {diff} == {n} -> FOUND! ({sorted_arr[j]}, {sorted_arr[i]})")
            return
        elif diff < n:
            print(f"  {diff} < {n} -> Need larger diff, j++")
            j += 1
        else:
            print(f"  {diff} > {n} -> Need smaller diff, i++")
            i += 1

        step += 1
        print()

    print("No pair found!")


if __name__ == "__main__":
    test_find_pair()

    visualize_two_pointers([5, 20, 3, 2, 50, 80], 78)
    visualize_two_pointers([1, 5, 3], 2)
