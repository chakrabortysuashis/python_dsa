# Searching and Sorting - Comprehensive Guide

## Table of Contents
1. [Searching Algorithms](#searching-algorithms)
2. [Sorting Algorithms](#sorting-algorithms)
3. [Time Complexity Comparison](#time-complexity-comparison)
4. [When to Use Which Algorithm](#when-to-use-which-algorithm)
5. [Stable vs Unstable Sorting](#stable-vs-unstable-sorting)

---

## Searching Algorithms

### 1. Linear Search

**Concept**: Traverse the array element by element until the target is found.

```
Array: [5, 3, 8, 1, 9, 2]
Target: 8

Step 1: Check 5 != 8
Step 2: Check 3 != 8
Step 3: Check 8 == 8 -> Found at index 2!
```

**Time Complexity**: O(n)
**Space Complexity**: O(1)

**When to Use**:
- Unsorted arrays
- Small arrays (< 20 elements)
- One-time search
- Linked lists

---

### 2. Binary Search

**Concept**: Divide and conquer - eliminate half of the search space in each step.

**Prerequisite**: Array MUST be sorted!

```
Sorted Array: [1, 3, 5, 7, 9, 11, 13, 15]
Target: 7

Initial: low=0, high=7
         [1, 3, 5, 7, 9, 11, 13, 15]
          L           M            H

Step 1: mid = (0+7)//2 = 3
        arr[3] = 7 == target
        Found at index 3!
```

**The Binary Search Template**:
```python
def binary_search(arr, target):
    low, high = 0, len(arr) - 1
    
    while low <= high:
        mid = low + (high - low) // 2  # Avoid overflow
        
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            low = mid + 1   # Search right half
        else:
            high = mid - 1  # Search left half
    
    return -1  # Not found
```

**Time Complexity**: O(log n)
**Space Complexity**: O(1) iterative, O(log n) recursive

**Key Insight**: Each comparison eliminates half the search space!
```
n -> n/2 -> n/4 -> n/8 -> ... -> 1
After k steps: n/2^k = 1
Therefore: k = log2(n)
```

---

### Binary Search Variations

#### 1. Find First Occurrence
```python
def first_occurrence(arr, target):
    low, high = 0, len(arr) - 1
    result = -1
    
    while low <= high:
        mid = low + (high - low) // 2
        if arr[mid] == target:
            result = mid      # Store result
            high = mid - 1    # Continue searching left
        elif arr[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
    
    return result
```

#### 2. Find Last Occurrence
```python
def last_occurrence(arr, target):
    low, high = 0, len(arr) - 1
    result = -1
    
    while low <= high:
        mid = low + (high - low) // 2
        if arr[mid] == target:
            result = mid      # Store result
            low = mid + 1     # Continue searching right
        elif arr[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
    
    return result
```

#### 3. Lower Bound (First element >= target)
```python
def lower_bound(arr, target):
    low, high = 0, len(arr)
    
    while low < high:
        mid = low + (high - low) // 2
        if arr[mid] < target:
            low = mid + 1
        else:
            high = mid
    
    return low
```

#### 4. Upper Bound (First element > target)
```python
def upper_bound(arr, target):
    low, high = 0, len(arr)
    
    while low < high:
        mid = low + (high - low) // 2
        if arr[mid] <= target:
            low = mid + 1
        else:
            high = mid
    
    return low
```

---

## Sorting Algorithms

### 1. Bubble Sort

**Concept**: Repeatedly swap adjacent elements if they're in wrong order. Largest elements "bubble up" to the end.

```
Array: [5, 3, 8, 1]

Pass 1: [3, 5, 1, 8]  <- 8 bubbled to end
Pass 2: [3, 1, 5, 8]  <- 5 bubbled
Pass 3: [1, 3, 5, 8]  <- 3 bubbled
Sorted!
```

**Time Complexity**: O(n^2)
**Space Complexity**: O(1)
**Stable**: Yes

```python
def bubble_sort(arr):
    n = len(arr)
    for i in range(n):
        swapped = False
        for j in range(n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True
        if not swapped:  # Optimization: already sorted
            break
    return arr
```

---

### 2. Selection Sort

**Concept**: Find minimum element and place it at the beginning. Repeat for remaining elements.

```
Array: [5, 3, 8, 1]

Pass 1: Find min=1, swap with index 0 -> [1, 3, 8, 5]
Pass 2: Find min=3 in [3,8,5], already at position -> [1, 3, 8, 5]
Pass 3: Find min=5 in [8,5], swap -> [1, 3, 5, 8]
Sorted!
```

**Time Complexity**: O(n^2)
**Space Complexity**: O(1)
**Stable**: No (can be made stable)

```python
def selection_sort(arr):
    n = len(arr)
    for i in range(n):
        min_idx = i
        for j in range(i + 1, n):
            if arr[j] < arr[min_idx]:
                min_idx = j
        arr[i], arr[min_idx] = arr[min_idx], arr[i]
    return arr
```

---

### 3. Insertion Sort

**Concept**: Build sorted array one element at a time by inserting each element into its correct position.

```
Array: [5, 3, 8, 1]

Start: [5] | 3, 8, 1     <- 5 is "sorted"
Step 1: [3, 5] | 8, 1    <- Insert 3 before 5
Step 2: [3, 5, 8] | 1    <- Insert 8 after 5
Step 3: [1, 3, 5, 8]     <- Insert 1 at beginning
Sorted!
```

**Time Complexity**: O(n^2) worst, O(n) best (nearly sorted)
**Space Complexity**: O(1)
**Stable**: Yes

```python
def insertion_sort(arr):
    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1
        while j >= 0 and arr[j] > key:
            arr[j + 1] = arr[j]  # Shift elements right
            j -= 1
        arr[j + 1] = key  # Insert key at correct position
    return arr
```

---

### 4. Merge Sort

**Concept**: Divide array into halves, recursively sort each half, then merge the sorted halves.

```
Array: [5, 3, 8, 1]

Divide:    [5, 3, 8, 1]
          /            \
       [5, 3]        [8, 1]
       /    \        /    \
      [5]  [3]      [8]  [1]

Merge:    [5]  [3]      [8]  [1]
           \  /          \  /
          [3, 5]        [1, 8]
              \        /
           [1, 3, 5, 8]
```

**Time Complexity**: O(n log n) - always
**Space Complexity**: O(n)
**Stable**: Yes

```python
def merge_sort(arr):
    if len(arr) <= 1:
        return arr
    
    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])
    
    return merge(left, right)

def merge(left, right):
    result = []
    i = j = 0
    
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1
    
    result.extend(left[i:])
    result.extend(right[j:])
    return result
```

---

### 5. Quick Sort

**Concept**: Pick a pivot, partition array so all elements < pivot are left and all elements > pivot are right. Recursively sort partitions.

```
Array: [5, 3, 8, 1, 4]  (pivot = 4)

Partition: [3, 1] [4] [5, 8]
           < pivot    > pivot

Recursively sort each partition:
[1, 3] [4] [5, 8]
Final: [1, 3, 4, 5, 8]
```

**Time Complexity**: O(n log n) average, O(n^2) worst
**Space Complexity**: O(log n) average
**Stable**: No

```python
def quick_sort(arr, low=0, high=None):
    if high is None:
        high = len(arr) - 1
    
    if low < high:
        pivot_idx = partition(arr, low, high)
        quick_sort(arr, low, pivot_idx - 1)
        quick_sort(arr, pivot_idx + 1, high)
    
    return arr

def partition(arr, low, high):
    pivot = arr[high]  # Choose last element as pivot
    i = low - 1
    
    for j in range(low, high):
        if arr[j] <= pivot:
            i += 1
            arr[i], arr[j] = arr[j], arr[i]
    
    arr[i + 1], arr[high] = arr[high], arr[i + 1]
    return i + 1
```

---

### 6. Heap Sort

**Concept**: Build a max-heap from the array, then repeatedly extract the maximum element to sort.

```
Array: [5, 3, 8, 1]

Build Max-Heap:
        8
       / \
      3   5
     /
    1

Extract max (8), heapify: [5, 3, 1] | [8]
Extract max (5), heapify: [3, 1] | [5, 8]
Extract max (3), heapify: [1] | [3, 5, 8]
Final: [1, 3, 5, 8]
```

**Time Complexity**: O(n log n)
**Space Complexity**: O(1)
**Stable**: No

```python
def heap_sort(arr):
    n = len(arr)
    
    # Build max-heap
    for i in range(n // 2 - 1, -1, -1):
        heapify(arr, n, i)
    
    # Extract elements one by one
    for i in range(n - 1, 0, -1):
        arr[0], arr[i] = arr[i], arr[0]  # Move max to end
        heapify(arr, i, 0)
    
    return arr

def heapify(arr, n, i):
    largest = i
    left = 2 * i + 1
    right = 2 * i + 2
    
    if left < n and arr[left] > arr[largest]:
        largest = left
    if right < n and arr[right] > arr[largest]:
        largest = right
    
    if largest != i:
        arr[i], arr[largest] = arr[largest], arr[i]
        heapify(arr, n, largest)
```

---

## Time Complexity Comparison

| Algorithm      | Best       | Average    | Worst      | Space   | Stable |
|----------------|------------|------------|------------|---------|--------|
| Bubble Sort    | O(n)       | O(n^2)     | O(n^2)     | O(1)    | Yes    |
| Selection Sort | O(n^2)     | O(n^2)     | O(n^2)     | O(1)    | No     |
| Insertion Sort | O(n)       | O(n^2)     | O(n^2)     | O(1)    | Yes    |
| Merge Sort     | O(n log n) | O(n log n) | O(n log n) | O(n)    | Yes    |
| Quick Sort     | O(n log n) | O(n log n) | O(n^2)     | O(log n)| No     |
| Heap Sort      | O(n log n) | O(n log n) | O(n log n) | O(1)    | No     |

### Search Algorithms

| Algorithm      | Best | Average  | Worst    | Space |
|----------------|------|----------|----------|-------|
| Linear Search  | O(1) | O(n)     | O(n)     | O(1)  |
| Binary Search  | O(1) | O(log n) | O(log n) | O(1)  |

---

## When to Use Which Algorithm

### Use Bubble Sort When:
- Teaching sorting concepts
- Array is nearly sorted (with optimization)
- Very small arrays (< 10 elements)
- Memory is extremely limited

### Use Selection Sort When:
- Memory writes are expensive (makes minimum swaps)
- Simple implementation needed
- Small arrays

### Use Insertion Sort When:
- Array is nearly sorted (O(n) performance)
- Small arrays (< 50 elements)
- Online sorting (data arrives incrementally)
- As a base case in hybrid sorts

### Use Merge Sort When:
- Stable sort is required
- Guaranteed O(n log n) is needed
- Sorting linked lists (no extra space needed)
- External sorting (large files)
- Parallelization is possible

### Use Quick Sort When:
- Average case performance matters
- In-place sorting preferred
- Cache performance is important
- General-purpose sorting

### Use Heap Sort When:
- Guaranteed O(n log n) with O(1) space needed
- Partial sorting (find k largest/smallest)
- Priority queue implementation

### Use Linear Search When:
- Array is unsorted
- Array is very small
- Single search operation
- Data structure is not random access (linked list)

### Use Binary Search When:
- Array is sorted
- Multiple searches on same array
- Large arrays
- Finding boundaries (first/last occurrence)

---

## Stable vs Unstable Sorting

### What is Stability?

A sorting algorithm is **stable** if elements with equal keys maintain their relative order after sorting.

```
Original: [(A, 2), (B, 1), (C, 2), (D, 1)]
         (sorted by number)

Stable Sort:   [(B, 1), (D, 1), (A, 2), (C, 2)]
               B before D (original order), A before C (original order)

Unstable Sort: [(D, 1), (B, 1), (C, 2), (A, 2)]
               Order of equal elements may change
```

### Why Stability Matters

1. **Multi-key sorting**: Sort by name, then by age. Stable sort preserves name order within same age.

2. **Preserving original order**: When elements are equal by the sort key, you might want to keep their original sequence.

3. **Database operations**: Sorting records while maintaining secondary ordering.

### Stable Algorithms:
- Bubble Sort
- Insertion Sort
- Merge Sort
- Counting Sort
- Radix Sort

### Unstable Algorithms:
- Selection Sort
- Quick Sort
- Heap Sort

### Making Unstable Algorithms Stable

You can make any unstable algorithm stable by:
1. Storing original indices with elements
2. Using original index as tiebreaker when elements are equal

```python
# Making Quick Sort stable
indexed_arr = [(val, idx) for idx, val in enumerate(arr)]
# Sort by (value, original_index)
indexed_arr.sort(key=lambda x: (x[0], x[1]))
stable_result = [val for val, idx in indexed_arr]
```

---

## Summary

### Key Takeaways

1. **Binary Search** is powerful but requires sorted data. Master its variations!

2. **O(n^2) sorts** (Bubble, Selection, Insertion) are simple but slow for large data.

3. **O(n log n) sorts** (Merge, Quick, Heap) are efficient for large datasets.

4. **No single best algorithm** - choice depends on:
   - Data size
   - Nearly sorted?
   - Stability required?
   - Memory constraints
   - Average vs worst case importance

5. **Hybrid approaches** work best in practice:
   - Python's Timsort: Merge Sort + Insertion Sort
   - Introsort: Quick Sort + Heap Sort + Insertion Sort

### Practice Tips

1. Implement each algorithm from scratch
2. Trace through small examples by hand
3. Understand why each step is necessary
4. Know the invariants (what's true at each step)
5. Practice identifying which algorithm to use for different scenarios
