"""
Find First and Last Positions of Element in Sorted Array
=========================================================

Problem: Given a sorted array and a target, find the starting and ending
position of the target value. Return [-1, -1] if not found.

Time Complexity: O(log n)
Space Complexity: O(1)
"""


def find_first(arr: list, target: int) -> int:
    """
    Find the FIRST occurrence of target using binary search.

    Key insight: When we find target, don't stop!
    Continue searching in the LEFT half for an earlier occurrence.
    """
    low, high = 0, len(arr) - 1
    result = -1

    while low <= high:
        mid = low + (high - low) // 2

        if arr[mid] == target:
            result = mid      # Store this position
            high = mid - 1    # But keep searching LEFT for earlier occurrence
        elif arr[mid] < target:
            low = mid + 1     # Target is in right half
        else:
            high = mid - 1    # Target is in left half

    return result


def find_last(arr: list, target: int) -> int:
    """
    Find the LAST occurrence of target using binary search.

    Key insight: When we find target, don't stop!
    Continue searching in the RIGHT half for a later occurrence.
    """
    low, high = 0, len(arr) - 1
    result = -1

    while low <= high:
        mid = low + (high - low) // 2

        if arr[mid] == target:
            result = mid      # Store this position
            low = mid + 1     # But keep searching RIGHT for later occurrence
        elif arr[mid] < target:
            low = mid + 1     # Target is in right half
        else:
            high = mid - 1    # Target is in left half

    return result


def search_range(arr: list, target: int) -> list:
    """
    Main function to find first and last positions.

    Args:
        arr: Sorted array of integers
        target: Value to search for

    Returns:
        [first_position, last_position] or [-1, -1] if not found
    """
    return [find_first(arr, target), find_last(arr, target)]


def search_range_single_pass(arr: list, target: int) -> list:
    """
    Alternative: Find both positions in conceptually one search direction.
    Uses lower_bound and upper_bound approach.
    """
    def lower_bound(arr, target):
        """Find first position where arr[i] >= target"""
        low, high = 0, len(arr)
        while low < high:
            mid = low + (high - low) // 2
            if arr[mid] < target:
                low = mid + 1
            else:
                high = mid
        return low

    def upper_bound(arr, target):
        """Find first position where arr[i] > target"""
        low, high = 0, len(arr)
        while low < high:
            mid = low + (high - low) // 2
            if arr[mid] <= target:
                low = mid + 1
            else:
                high = mid
        return low

    first = lower_bound(arr, target)

    # Check if target exists
    if first == len(arr) or arr[first] != target:
        return [-1, -1]

    # Last occurrence is just before upper bound
    last = upper_bound(arr, target) - 1

    return [first, last]


def count_occurrences(arr: list, target: int) -> int:
    """
    Bonus: Count how many times target appears in sorted array.
    Uses the first and last position to calculate count.
    """
    positions = search_range(arr, target)

    if positions[0] == -1:
        return 0

    return positions[1] - positions[0] + 1


# ==================== TEST CASES ====================

def test_search_range():
    """Comprehensive test cases."""

    print("=" * 60)
    print("FIND FIRST AND LAST POSITIONS")
    print("=" * 60)

    test_cases = [
        # (array, target, expected)
        ([5, 7, 7, 8, 8, 10], 8, [3, 4]),
        ([5, 7, 7, 8, 8, 10], 6, [-1, -1]),
        ([1], 1, [0, 0]),
        ([], 0, [-1, -1]),
        ([1, 2, 2, 2, 2, 3, 4, 5], 2, [1, 4]),
        ([1, 1, 1, 1, 1], 1, [0, 4]),
        ([1, 2, 3, 4, 5], 3, [2, 2]),
        ([1, 2, 3, 4, 5], 0, [-1, -1]),
        ([1, 2, 3, 4, 5], 6, [-1, -1]),
        ([2, 2], 2, [0, 1]),
    ]

    all_passed = True

    for i, (arr, target, expected) in enumerate(test_cases, 1):
        result = search_range(arr, target)
        status = "PASS" if result == expected else "FAIL"

        if result != expected:
            all_passed = False

        print(f"\nTest {i}: {status}")
        print(f"  Array: {arr}")
        print(f"  Target: {target}")
        print(f"  Expected: {expected}")
        print(f"  Got: {result}")

    # Test alternative implementation
    print("\n" + "-" * 60)
    print("Testing Alternative Implementation (Lower/Upper Bound):")
    print("-" * 60)

    for arr, target, expected in test_cases:
        result = search_range_single_pass(arr, target)
        status = "PASS" if result == expected else "FAIL"
        print(f"  Array: {arr}, Target: {target} -> {result} [{status}]")

    # Test count occurrences
    print("\n" + "-" * 60)
    print("Testing Count Occurrences:")
    print("-" * 60)

    count_tests = [
        ([1, 2, 2, 2, 3, 4], 2, 3),
        ([1, 1, 1, 1, 1], 1, 5),
        ([1, 2, 3, 4, 5], 3, 1),
        ([1, 2, 3, 4, 5], 6, 0),
    ]

    for arr, target, expected in count_tests:
        result = count_occurrences(arr, target)
        status = "PASS" if result == expected else "FAIL"
        print(f"  Count of {target} in {arr}: {result} [{status}]")

    print("\n" + "=" * 60)
    print(f"All tests passed: {all_passed}")
    print("=" * 60)


def visualize_search(arr: list, target: int):
    """Visualize the binary search process step by step."""

    print(f"\nVisualizing search for {target} in {arr}")
    print("=" * 50)

    def search_with_trace(arr, target, find_first=True):
        """Binary search with step-by-step visualization."""
        low, high = 0, len(arr) - 1
        result = -1
        step = 1

        direction = "FIRST" if find_first else "LAST"
        print(f"\nFinding {direction} occurrence:")

        while low <= high:
            mid = low + (high - low) // 2

            # Visualize current state
            arr_str = "["
            for i, val in enumerate(arr):
                if i == low == mid == high:
                    arr_str += f"(L,M,H){val}"
                elif i == low and i == mid:
                    arr_str += f"(L,M){val}"
                elif i == mid and i == high:
                    arr_str += f"(M,H){val}"
                elif i == low:
                    arr_str += f"(L){val}"
                elif i == mid:
                    arr_str += f"(M){val}"
                elif i == high:
                    arr_str += f"(H){val}"
                else:
                    arr_str += f"{val}"
                if i < len(arr) - 1:
                    arr_str += ", "
            arr_str += "]"

            print(f"  Step {step}: {arr_str}")
            print(f"          low={low}, mid={mid}, high={high}, arr[mid]={arr[mid]}")

            if arr[mid] == target:
                result = mid
                if find_first:
                    print(f"          Found! result={mid}, search LEFT (high = {mid-1})")
                    high = mid - 1
                else:
                    print(f"          Found! result={mid}, search RIGHT (low = {mid+1})")
                    low = mid + 1
            elif arr[mid] < target:
                print(f"          {arr[mid]} < {target}, search RIGHT (low = {mid+1})")
                low = mid + 1
            else:
                print(f"          {arr[mid]} > {target}, search LEFT (high = {mid-1})")
                high = mid - 1

            step += 1

        print(f"  Result: {result}")
        return result

    first = search_with_trace(arr, target, find_first=True)
    last = search_with_trace(arr, target, find_first=False)

    print(f"\nFinal Answer: [{first}, {last}]")


if __name__ == "__main__":
    test_search_range()

    # Visualize a specific example
    visualize_search([5, 7, 7, 8, 8, 10], 8)
    visualize_search([1, 2, 2, 2, 2, 3, 4, 5], 2)
