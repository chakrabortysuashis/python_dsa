# Find First and Last Positions of Element in Sorted Array

## Problem Statement

Given a sorted array of integers `arr` and a target value `target`, find the starting and ending position of the target value in the array. If the target is not found, return `[-1, -1]`.

**Example 1:**
```
Input: arr = [5, 7, 7, 8, 8, 10], target = 8
Output: [3, 4]
Explanation: 8 first appears at index 3 and last appears at index 4
```

**Example 2:**
```
Input: arr = [5, 7, 7, 8, 8, 10], target = 6
Output: [-1, -1]
Explanation: 6 is not present in the array
```

**Example 3:**
```
Input: arr = [1], target = 1
Output: [0, 0]
```

---

## Binary Search Intuition

Since the array is **sorted**, we can use binary search! But the twist is:
- A regular binary search returns ANY occurrence of target
- We need the FIRST and LAST occurrence

**Key Insight**: Modify binary search to "keep searching" even after finding target:
- For first occurrence: After finding target, continue searching LEFT
- For last occurrence: After finding target, continue searching RIGHT

---

## Brute Force Approach

### Algorithm
1. Traverse array from left, find first occurrence
2. Traverse array from right, find last occurrence

### Code
```python
def find_first_last_brute(arr, target):
    first = -1
    last = -1
    
    # Find first occurrence
    for i in range(len(arr)):
        if arr[i] == target:
            first = i
            break
    
    # Find last occurrence
    for i in range(len(arr) - 1, -1, -1):
        if arr[i] == target:
            last = i
            break
    
    return [first, last]
```

### Complexity
- **Time**: O(n) - traverse entire array
- **Space**: O(1)

---

## Optimal Approach: Binary Search

### Algorithm
Use two separate binary searches:
1. **Find First Position**: When target is found, record position and search LEFT
2. **Find Last Position**: When target is found, record position and search RIGHT

### Visualization of Pointer Movement

```
Array: [5, 7, 7, 8, 8, 10]
Target: 8

=== Finding FIRST occurrence of 8 ===

Step 1: low=0, high=5
        [5, 7, 7, 8, 8, 10]
         L        M        H
        mid = 2, arr[2] = 7 < 8
        7 < 8, search right: low = mid + 1 = 3

Step 2: low=3, high=5
        [5, 7, 7, 8, 8, 10]
                  L  M     H
        mid = 4, arr[4] = 8 == 8
        Found! Record result = 4
        For FIRST occurrence, continue searching LEFT: high = mid - 1 = 3

Step 3: low=3, high=3
        [5, 7, 7, 8, 8, 10]
                  LMH
        mid = 3, arr[3] = 8 == 8
        Found earlier occurrence! Update result = 3
        Continue searching LEFT: high = mid - 1 = 2

Step 4: low=3, high=2
        low > high, stop!
        First position = 3


=== Finding LAST occurrence of 8 ===

Step 1: low=0, high=5
        [5, 7, 7, 8, 8, 10]
         L        M        H
        mid = 2, arr[2] = 7 < 8
        7 < 8, search right: low = mid + 1 = 3

Step 2: low=3, high=5
        [5, 7, 7, 8, 8, 10]
                  L  M     H
        mid = 4, arr[4] = 8 == 8
        Found! Record result = 4
        For LAST occurrence, continue searching RIGHT: low = mid + 1 = 5

Step 3: low=5, high=5
        [5, 7, 7, 8, 8, 10]
                          LMH
        mid = 5, arr[5] = 10 > 8
        Search left: high = mid - 1 = 4

Step 4: low=5, high=4
        low > high, stop!
        Last position = 4

RESULT: [3, 4]
```

### Search Space Reduction

```
Original search space: [0, 1, 2, 3, 4, 5] - 6 elements

Finding first 8:
  After step 1: [3, 4, 5] - 3 elements (eliminated 50%)
  After step 2: [3] - 1 element (eliminated 67%)
  Total comparisons: 3

Without binary search: 6 comparisons worst case
```

---

## Dry Run with Different Example

```
Array: [1, 2, 2, 2, 2, 3, 4, 5]
Target: 2

=== Finding FIRST ===
low=0, high=7, mid=3: arr[3]=2, found! result=3, high=2
low=0, high=2, mid=1: arr[1]=2, found! result=1, high=0
low=0, high=0, mid=0: arr[0]=1 < 2, low=1
low=1, high=0: STOP
First = 1

=== Finding LAST ===
low=0, high=7, mid=3: arr[3]=2, found! result=3, low=4
low=4, high=7, mid=5: arr[5]=3 > 2, high=4
low=4, high=4, mid=4: arr[4]=2, found! result=4, low=5
low=5, high=4: STOP
Last = 4

RESULT: [1, 4]
```

---

## Code Implementation

```python
def find_first(arr, target):
    low, high = 0, len(arr) - 1
    result = -1
    
    while low <= high:
        mid = low + (high - low) // 2
        
        if arr[mid] == target:
            result = mid      # Record position
            high = mid - 1    # Keep searching LEFT
        elif arr[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
    
    return result

def find_last(arr, target):
    low, high = 0, len(arr) - 1
    result = -1
    
    while low <= high:
        mid = low + (high - low) // 2
        
        if arr[mid] == target:
            result = mid      # Record position
            low = mid + 1     # Keep searching RIGHT
        elif arr[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
    
    return result

def searchRange(arr, target):
    return [find_first(arr, target), find_last(arr, target)]
```

---

## Time and Space Complexity

### Optimal Approach
- **Time Complexity**: O(log n)
  - Two binary searches, each O(log n)
  - Total: 2 * O(log n) = O(log n)

- **Space Complexity**: O(1)
  - Only using a few variables

### Comparison
| Approach | Time | Space |
|----------|------|-------|
| Brute Force | O(n) | O(1) |
| Binary Search | O(log n) | O(1) |

---

## Key Takeaways

1. **Don't stop at first match**: For first/last occurrence, continue searching after finding target

2. **Direction of continuation**:
   - First occurrence: Search LEFT after match (high = mid - 1)
   - Last occurrence: Search RIGHT after match (low = mid + 1)

3. **Store result before continuing**: Record the found position before narrowing search

4. **Two separate searches**: Keep the logic clean by using two separate functions

5. **Pattern recognition**: This pattern applies to many problems:
   - Count occurrences = last - first + 1
   - Find range of values
   - Lower bound / Upper bound
