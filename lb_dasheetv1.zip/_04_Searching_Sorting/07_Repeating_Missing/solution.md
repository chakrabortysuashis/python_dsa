# Find the Repeating and the Missing Element

## Problem Statement

Given an array of size n containing numbers from 1 to n with one number occurring twice and one missing, find both the repeating and missing numbers.

**Example 1:**
```
Input: arr = [1, 3, 3]
Output: Repeating = 3, Missing = 2
```

**Example 2:**
```
Input: arr = [4, 3, 6, 2, 1, 1]
Output: Repeating = 1, Missing = 5
```

---

## Multiple Approaches

### Approach 1: Brute Force (Counting)

Count occurrences of each number.

```python
def find_repeating_missing_count(arr):
    n = len(arr)
    count = [0] * (n + 1)
    
    for num in arr:
        count[num] += 1
    
    repeating = missing = -1
    for i in range(1, n + 1):
        if count[i] == 2:
            repeating = i
        elif count[i] == 0:
            missing = i
    
    return repeating, missing
```

**Time**: O(n), **Space**: O(n)

---

### Approach 2: Mathematical (Sum and Sum of Squares)

Using mathematical equations:
- Let X = repeating, Y = missing
- Sum difference: X - Y = Sum(arr) - Sum(1 to n)
- Square sum difference: X² - Y² = Sum(arr²) - Sum(1² to n²)

```
From X² - Y² = (X-Y)(X+Y)
We get: X + Y = (X² - Y²) / (X - Y)

Then solve:
X - Y = known
X + Y = known
X = (sum1 + sum2) / 2
Y = X - sum1
```

### Visualization

```
Array: [4, 3, 6, 2, 1, 1]
n = 6

Expected sum = 1+2+3+4+5+6 = 21
Actual sum = 4+3+6+2+1+1 = 17

X - Y = 17 - 21 = -4  ... (1)

Expected square sum = 1+4+9+16+25+36 = 91
Actual square sum = 16+9+36+4+1+1 = 67

X² - Y² = 67 - 91 = -24
X + Y = -24 / -4 = 6  ... (2)

From (1) and (2):
2X = -4 + 6 = 2 => X = 1 (repeating)
Y = 6 - 1 = 5 (missing)
```

---

### Approach 3: XOR Method (Optimal Space)

Using XOR properties:
- a ^ a = 0
- a ^ 0 = a

**Algorithm**:
1. XOR all array elements with 1 to n
2. Result = X ^ Y (repeating XOR missing)
3. Find a set bit in the result
4. Divide numbers into two groups based on that bit
5. XOR each group to find X and Y

### XOR Visualization

```
Array: [1, 3, 3]
Numbers 1 to 3: 1, 2, 3

Step 1: XOR all
        1 ^ 3 ^ 3 ^ 1 ^ 2 ^ 3
      = (1^1) ^ (3^3^3) ^ 2
      = 0 ^ 3 ^ 2
      = 1 (binary: 01)

        Result = X ^ Y = 3 ^ 2 = 1

Step 2: Find rightmost set bit
        1 has bit 0 set

Step 3: Divide numbers
        Bit 0 = 0: 2
        Bit 0 = 1: 1, 3, 3, 1, 3

Step 4: XOR each group
        Group 0: 2 ^ 2 = 0? No wait...
        
Let me recalculate:
        Array elements: 1, 3, 3
        Expected: 1, 2, 3
        
        All XORed: 1^3^3 ^ 1^2^3 = 3^2 = 1
        
        Rightmost set bit = 1 (position 0)
        
        Set 1 (bit 0 = 1): from array: 1,3,3; from expected: 1,3
                          XOR: 1^3^3^1^3 = 3
        Set 2 (bit 0 = 0): from array: (none); from expected: 2
                          XOR: 2
        
        One is repeating (3), one is missing (2)
        Verify which is which by checking array.
```

---

### Approach 4: Index Marking (Modify Array)

Mark visited indices by making elements negative.

```python
def find_using_index(arr):
    n = len(arr)
    repeating = missing = -1
    
    # Mark visited
    for i in range(n):
        idx = abs(arr[i]) - 1
        if arr[idx] < 0:
            repeating = abs(arr[i])
        else:
            arr[idx] = -arr[idx]
    
    # Find missing
    for i in range(n):
        if arr[i] > 0:
            missing = i + 1
            break
    
    return repeating, missing
```

**Time**: O(n), **Space**: O(1) but modifies array

---

## Code Implementation (All Methods)

```python
def find_repeating_missing_math(arr):
    """Mathematical approach using sum and sum of squares."""
    n = len(arr)
    
    # Calculate sums
    S = sum(arr)
    Sn = n * (n + 1) // 2
    
    S2 = sum(x * x for x in arr)
    S2n = n * (n + 1) * (2 * n + 1) // 6
    
    # X - Y
    diff = S - Sn
    
    # X + Y = (X² - Y²) / (X - Y)
    sum_xy = (S2 - S2n) // diff
    
    # Solve
    X = (diff + sum_xy) // 2  # Repeating
    Y = sum_xy - X            # Missing
    
    return X, Y


def find_repeating_missing_xor(arr):
    """XOR approach - optimal space without modifying array."""
    n = len(arr)
    
    # XOR all elements and 1 to n
    xor_all = 0
    for i in range(n):
        xor_all ^= arr[i]
        xor_all ^= (i + 1)
    
    # Find rightmost set bit
    set_bit = xor_all & (-xor_all)
    
    # Divide into two groups
    x, y = 0, 0
    for i in range(n):
        if arr[i] & set_bit:
            x ^= arr[i]
        else:
            y ^= arr[i]
        
        if (i + 1) & set_bit:
            x ^= (i + 1)
        else:
            y ^= (i + 1)
    
    # Determine which is repeating
    for num in arr:
        if num == x:
            return x, y  # x is repeating
    return y, x  # y is repeating
```

---

## Time and Space Complexity

| Approach | Time | Space | Notes |
|----------|------|-------|-------|
| Counting | O(n) | O(n) | Simple but extra space |
| Mathematical | O(n) | O(1) | May overflow for large n |
| XOR | O(n) | O(1) | Optimal, no modification |
| Index Marking | O(n) | O(1) | Modifies input array |

---

## Key Takeaways

1. **Multiple approaches**: This problem has many valid solutions with different trade-offs

2. **Mathematical insight**: Using sum equations can solve two unknowns

3. **XOR properties**: Powerful for finding paired elements

4. **Index as hash**: When range is [1, n], use index marking

5. **Overflow caution**: Sum of squares can overflow for large arrays - use long/BigInt
