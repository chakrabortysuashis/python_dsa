"""
Find the Repeating and the Missing Element
==========================================

Problem: Array of size n contains numbers 1 to n. One number occurs twice,
one is missing. Find both.

Multiple approaches with different space/time trade-offs.
"""

from typing import List, Tuple


def find_repeating_missing_count(arr: List[int]) -> Tuple[int, int]:
    """
    Approach 1: Counting frequency.

    Time: O(n)
    Space: O(n)
    """
    n = len(arr)
    count = [0] * (n + 1)

    for num in arr:
        count[num] += 1

    repeating = missing = -1
    for i in range(1, n + 1):
        if count[i] == 2:
            repeating = i
        elif count[i] == 0:
            missing = i

    return repeating, missing


def find_repeating_missing_math(arr: List[int]) -> Tuple[int, int]:
    """
    Approach 2: Mathematical using sum and sum of squares.

    Let X = repeating, Y = missing

    Equation 1: X - Y = Sum(arr) - Sum(1..n)
    Equation 2: X² - Y² = Sum(arr²) - Sum(1²..n²)

    From X² - Y² = (X-Y)(X+Y), we get X+Y
    Then solve the system.

    Time: O(n)
    Space: O(1)
    """
    n = len(arr)

    # Calculate actual sums
    S = sum(arr)
    S2 = sum(x * x for x in arr)

    # Calculate expected sums
    Sn = n * (n + 1) // 2
    S2n = n * (n + 1) * (2 * n + 1) // 6

    # X - Y = diff
    diff = S - Sn

    # X² - Y² = (X+Y)(X-Y) = diff2
    diff2 = S2 - S2n

    # X + Y = diff2 / diff
    sum_xy = diff2 // diff

    # Solve system
    X = (diff + sum_xy) // 2  # Repeating
    Y = sum_xy - X             # Missing

    return X, Y


def find_repeating_missing_xor(arr: List[int]) -> Tuple[int, int]:
    """
    Approach 3: XOR method.

    1. XOR all array elements with 1 to n
    2. Result = X ^ Y (X xor Y)
    3. Find a set bit (where X and Y differ)
    4. Divide all numbers into two groups by that bit
    5. XOR each group to separate X and Y

    Time: O(n)
    Space: O(1)
    """
    n = len(arr)

    # Step 1: XOR all elements and 1 to n
    xor_all = 0
    for i in range(n):
        xor_all ^= arr[i]
        xor_all ^= (i + 1)

    # xor_all = X ^ Y (where X is repeating, Y is missing)

    # Step 2: Find rightmost set bit (where X and Y differ)
    set_bit = xor_all & (-xor_all)

    # Step 3: Divide into two groups and XOR
    x, y = 0, 0

    # Process array elements
    for num in arr:
        if num & set_bit:
            x ^= num
        else:
            y ^= num

    # Process expected elements 1 to n
    for i in range(1, n + 1):
        if i & set_bit:
            x ^= i
        else:
            y ^= i

    # Step 4: Determine which is repeating
    # Count occurrences of x in array
    count_x = sum(1 for num in arr if num == x)

    if count_x == 2:
        return x, y  # x is repeating, y is missing
    else:
        return y, x  # y is repeating, x is missing


def find_repeating_missing_index(arr: List[int]) -> Tuple[int, int]:
    """
    Approach 4: Index marking (modifies array).

    Use sign of elements to mark visited indices.

    Time: O(n)
    Space: O(1) but modifies input
    """
    n = len(arr)
    arr = arr.copy()  # Don't modify original

    repeating = missing = -1

    # Mark visited indices
    for i in range(n):
        idx = abs(arr[i]) - 1

        if arr[idx] < 0:
            # Already visited, this is the repeating element
            repeating = abs(arr[i])
        else:
            # Mark as visited
            arr[idx] = -arr[idx]

    # Find missing (unmarked index)
    for i in range(n):
        if arr[i] > 0:
            missing = i + 1
            break

    return repeating, missing


def find_repeating_missing_set(arr: List[int]) -> Tuple[int, int]:
    """
    Approach 5: Using set.

    Time: O(n)
    Space: O(n)
    """
    n = len(arr)
    seen = set()
    repeating = -1

    for num in arr:
        if num in seen:
            repeating = num
        seen.add(num)

    # Find missing
    for i in range(1, n + 1):
        if i not in seen:
            return repeating, i

    return repeating, -1


def find_repeating_missing_sort(arr: List[int]) -> Tuple[int, int]:
    """
    Approach 6: Sort and scan.

    Time: O(n log n)
    Space: O(1) if in-place sort
    """
    arr = sorted(arr)
    n = len(arr)

    repeating = missing = -1

    # Check for repeating
    for i in range(1, n):
        if arr[i] == arr[i-1]:
            repeating = arr[i]
            break

    # Check for missing
    expected = 1
    for num in arr:
        if num != expected and num != repeating:
            missing = expected
            break
        if num == expected:
            expected += 1

    if missing == -1:
        missing = n  # Missing is the last number

    return repeating, missing


# ==================== TEST CASES ====================

def test_all_methods():
    """Test all approaches with various test cases."""

    print("=" * 70)
    print("FIND REPEATING AND MISSING ELEMENT")
    print("=" * 70)

    test_cases = [
        ([1, 3, 3], (3, 2)),
        ([4, 3, 6, 2, 1, 1], (1, 5)),
        ([2, 2], (2, 1)),
        ([1, 1], (1, 2)),
        ([2, 3, 1, 5, 1], (1, 4)),
        ([1, 2, 3, 4, 4], (4, 5)),
        ([5, 4, 3, 2, 5], (5, 1)),
    ]

    methods = [
        ("Counting", find_repeating_missing_count),
        ("Mathematical", find_repeating_missing_math),
        ("XOR", find_repeating_missing_xor),
        ("Index Marking", find_repeating_missing_index),
        ("Set", find_repeating_missing_set),
    ]

    for arr, expected in test_cases:
        print(f"\nArray: {arr}")
        print(f"Expected: Repeating={expected[0]}, Missing={expected[1]}")

        for name, method in methods:
            result = method(arr.copy())
            status = "PASS" if result == expected else "FAIL"
            print(f"  {name:15}: Rep={result[0]}, Miss={result[1]} [{status}]")


def visualize_xor_method(arr: List[int]):
    """Visualize how XOR method works step by step."""

    print(f"\n{'='*60}")
    print(f"XOR METHOD VISUALIZATION for {arr}")
    print("=" * 60)

    n = len(arr)

    # Step 1: XOR all
    print("\nStep 1: XOR all elements with expected 1 to n")
    xor_all = 0

    print("  Array elements:", end=" ")
    for num in arr:
        print(f"{num:3}", end="")
        xor_all ^= num
    print(f"  -> XOR = {bin(xor_all)}")

    for i in range(1, n + 1):
        xor_all ^= i

    print(f"  Expected 1 to {n}:", end=" ")
    for i in range(1, n + 1):
        print(f"{i:3}", end="")
    print()

    # Recalculate for display
    xor_all = 0
    for num in arr:
        xor_all ^= num
    for i in range(1, n + 1):
        xor_all ^= i

    print(f"\n  X ^ Y = {xor_all} (binary: {bin(xor_all)})")

    # Step 2: Find set bit
    set_bit = xor_all & (-xor_all)
    print(f"\nStep 2: Rightmost set bit = {set_bit} (binary: {bin(set_bit)})")

    # Step 3: Divide groups
    print("\nStep 3: Divide into groups by that bit")

    group1_arr = [num for num in arr if num & set_bit]
    group0_arr = [num for num in arr if not (num & set_bit)]
    group1_exp = [i for i in range(1, n+1) if i & set_bit]
    group0_exp = [i for i in range(1, n+1) if not (i & set_bit)]

    print(f"  Bit set group (from arr): {group1_arr}")
    print(f"  Bit set group (expected): {group1_exp}")
    print(f"  Bit clear group (from arr): {group0_arr}")
    print(f"  Bit clear group (expected): {group0_exp}")

    # Step 4: XOR each group
    x = 0
    for num in group1_arr:
        x ^= num
    for num in group1_exp:
        x ^= num

    y = 0
    for num in group0_arr:
        y ^= num
    for num in group0_exp:
        y ^= num

    print(f"\nStep 4: XOR each group")
    print(f"  Group 1 XOR result: {x}")
    print(f"  Group 0 XOR result: {y}")

    # Determine which is repeating
    count_x = sum(1 for num in arr if num == x)

    if count_x == 2:
        print(f"\n  {x} appears twice -> Repeating = {x}, Missing = {y}")
    else:
        print(f"\n  {y} appears twice -> Repeating = {y}, Missing = {x}")


def visualize_math_method(arr: List[int]):
    """Visualize the mathematical approach."""

    print(f"\n{'='*60}")
    print(f"MATHEMATICAL METHOD for {arr}")
    print("=" * 60)

    n = len(arr)

    S = sum(arr)
    Sn = n * (n + 1) // 2

    S2 = sum(x * x for x in arr)
    S2n = n * (n + 1) * (2 * n + 1) // 6

    print(f"\nActual sum: {S}")
    print(f"Expected sum (1 to {n}): {Sn}")
    print(f"Difference (X - Y): {S - Sn}")

    print(f"\nActual square sum: {S2}")
    print(f"Expected square sum: {S2n}")
    print(f"Difference (X² - Y²): {S2 - S2n}")

    diff = S - Sn
    sum_xy = (S2 - S2n) // diff

    print(f"\nFrom X² - Y² = (X-Y)(X+Y):")
    print(f"X + Y = {S2 - S2n} / {diff} = {sum_xy}")

    X = (diff + sum_xy) // 2
    Y = sum_xy - X

    print(f"\nSolving:")
    print(f"X = ({diff} + {sum_xy}) / 2 = {X}")
    print(f"Y = {sum_xy} - {X} = {Y}")
    print(f"\nRepeating = {X}, Missing = {Y}")


if __name__ == "__main__":
    test_all_methods()

    # Visualizations
    visualize_xor_method([1, 3, 3])
    visualize_xor_method([4, 3, 6, 2, 1, 1])

    visualize_math_method([4, 3, 6, 2, 1, 1])
