"""
K-th Element of Two Sorted Arrays
=================================

Problem: Given two sorted arrays, find the k-th element of merged array
without actually merging.

Solution: Binary search on partition point
- Pick cut1 elements from arr1, cut2 = k - cut1 from arr2
- Check if partition is valid (left elements <= right elements)

Time Complexity: O(log(min(m, n)))
Space Complexity: O(1)
"""


def kth_element_brute(arr1: list, arr2: list, k: int) -> int:
    """
    Brute force: Merge and return k-th element.
    Time: O(m + n)
    Space: O(m + n)
    """
    merged = []
    i, j = 0, 0
    m, n = len(arr1), len(arr2)

    while i < m and j < n:
        if arr1[i] <= arr2[j]:
            merged.append(arr1[i])
            i += 1
        else:
            merged.append(arr2[j])
            j += 1

    merged.extend(arr1[i:])
    merged.extend(arr2[j:])

    return merged[k - 1] if k <= len(merged) else -1


def kth_element_count(arr1: list, arr2: list, k: int) -> int:
    """
    Count while merging, stop at k.
    Time: O(k)
    Space: O(1)
    """
    i, j = 0, 0
    m, n = len(arr1), len(arr2)
    count = 0
    result = -1

    while i < m and j < n:
        if arr1[i] <= arr2[j]:
            count += 1
            result = arr1[i]
            if count == k:
                return result
            i += 1
        else:
            count += 1
            result = arr2[j]
            if count == k:
                return result
            j += 1

    while i < m:
        count += 1
        result = arr1[i]
        if count == k:
            return result
        i += 1

    while j < n:
        count += 1
        result = arr2[j]
        if count == k:
            return result
        j += 1

    return -1


def kth_element(arr1: list, arr2: list, k: int) -> int:
    """
    Optimal: Binary search on partition point.

    Partition both arrays such that left side has exactly k elements.
    Binary search to find valid partition where max(left) <= min(right).

    Time: O(log(min(m, n)))
    Space: O(1)
    """
    m, n = len(arr1), len(arr2)

    # Ensure arr1 is the smaller array for efficiency
    if m > n:
        return kth_element(arr2, arr1, k)

    # Binary search bounds
    # We need cut1 + cut2 = k
    # cut1 ranges from max(0, k-n) to min(k, m)
    low = max(0, k - n)  # Minimum elements from arr1
    high = min(k, m)     # Maximum elements from arr1

    while low <= high:
        cut1 = (low + high) // 2  # Elements from arr1
        cut2 = k - cut1            # Elements from arr2

        # Get boundary elements
        left1 = arr1[cut1 - 1] if cut1 > 0 else float('-inf')
        left2 = arr2[cut2 - 1] if cut2 > 0 else float('-inf')
        right1 = arr1[cut1] if cut1 < m else float('inf')
        right2 = arr2[cut2] if cut2 < n else float('inf')

        # Check if partition is valid
        if left1 <= right2 and left2 <= right1:
            # Found valid partition
            # k-th element is max of left elements
            return max(left1, left2)
        elif left1 > right2:
            # Too many elements from arr1, reduce
            high = cut1 - 1
        else:
            # Too few elements from arr1, increase
            low = cut1 + 1

    return -1


# ==================== TEST CASES ====================

def test_kth_element():
    """Comprehensive test cases."""

    print("=" * 60)
    print("K-TH ELEMENT OF TWO SORTED ARRAYS")
    print("=" * 60)

    test_cases = [
        # (arr1, arr2, k, expected)
        ([2, 3, 6, 7, 9], [1, 4, 8, 10], 5, 6),
        ([1, 3, 5], [2, 4, 6], 4, 4),
        ([1, 2, 3], [4, 5, 6], 3, 3),
        ([1, 2, 3], [4, 5, 6], 4, 4),
        ([1], [2], 1, 1),
        ([1], [2], 2, 2),
        ([1, 3], [2], 2, 2),
        ([], [1, 2, 3], 2, 2),
        ([1, 2, 3], [], 2, 2),
        ([100, 112, 256, 349, 770], [72, 86, 113, 119, 265], 7, 256),
    ]

    all_passed = True

    for i, (arr1, arr2, k, expected) in enumerate(test_cases, 1):
        result_bs = kth_element(arr1, arr2, k)
        result_brute = kth_element_brute(arr1, arr2, k)
        result_count = kth_element_count(arr1, arr2, k)

        status = "PASS" if result_bs == expected else "FAIL"
        if result_bs != expected:
            all_passed = False

        print(f"\nTest {i}: {status}")
        print(f"  arr1: {arr1}")
        print(f"  arr2: {arr2}")
        print(f"  k: {k}")
        print(f"  Expected: {expected}")
        print(f"  Binary Search: {result_bs}")
        print(f"  Brute: {result_brute}, Count: {result_count}")

    print("\n" + "=" * 60)
    print(f"All tests passed: {all_passed}")
    print("=" * 60)


def visualize_algorithm(arr1: list, arr2: list, k: int):
    """Visualize the binary search process."""

    print(f"\nVisualizing K-th Element Search")
    print(f"arr1: {arr1} (m={len(arr1)})")
    print(f"arr2: {arr2} (n={len(arr2)})")
    print(f"k: {k}")
    print("=" * 60)

    m, n = len(arr1), len(arr2)

    # Swap if needed
    if m > n:
        arr1, arr2 = arr2, arr1
        m, n = n, m
        print(f"Swapped to search on smaller array")
        print(f"arr1: {arr1}, arr2: {arr2}")

    low = max(0, k - n)
    high = min(k, m)
    print(f"\nSearch bounds: low={low}, high={high}")

    step = 1
    while low <= high:
        cut1 = (low + high) // 2
        cut2 = k - cut1

        left1 = arr1[cut1 - 1] if cut1 > 0 else float('-inf')
        left2 = arr2[cut2 - 1] if cut2 > 0 else float('-inf')
        right1 = arr1[cut1] if cut1 < m else float('inf')
        right2 = arr2[cut2] if cut2 < n else float('inf')

        print(f"\nStep {step}:")
        print(f"  cut1={cut1}, cut2={cut2}")

        # Visualize partition
        arr1_left = arr1[:cut1] if cut1 > 0 else []
        arr1_right = arr1[cut1:] if cut1 < m else []
        arr2_left = arr2[:cut2] if cut2 > 0 else []
        arr2_right = arr2[cut2:] if cut2 < n else []

        print(f"  arr1: {arr1_left} | {arr1_right}")
        print(f"  arr2: {arr2_left} | {arr2_right}")
        print(f"  left1={left1}, right1={right1}")
        print(f"  left2={left2}, right2={right2}")

        if left1 <= right2 and left2 <= right1:
            result = max(left1, left2)
            print(f"  Valid partition! max(left1, left2) = {result}")
            print(f"\nResult: {result}")
            return
        elif left1 > right2:
            print(f"  left1={left1} > right2={right2}: Need fewer from arr1")
            high = cut1 - 1
        else:
            print(f"  left2={left2} > right1={right1}: Need more from arr1")
            low = cut1 + 1

        step += 1

    print("No valid partition found!")


if __name__ == "__main__":
    test_kth_element()

    # Visualize
    visualize_algorithm([2, 3, 6, 7, 9], [1, 4, 8, 10], 5)
    visualize_algorithm([1, 3, 5], [2, 4, 6], 4)
