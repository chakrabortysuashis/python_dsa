# K-th Element of Two Sorted Arrays

## Problem Statement

Given two sorted arrays `arr1[]` of size `m` and `arr2[]` of size `n`, find the **k-th element** of the merged sorted array WITHOUT actually merging them.

**Example 1:**
```
Input: arr1 = [2, 3, 6, 7, 9], arr2 = [1, 4, 8, 10], k = 5
Output: 6
Explanation: Merged = [1, 2, 3, 4, 6, 7, 8, 9, 10]
             5th element = 6
```

**Example 2:**
```
Input: arr1 = [100, 112, 256, 349, 770], arr2 = [72, 86, 113, 119, 265], k = 7
Output: 256
```

---

## Approach Intuition

### Key Insight
Instead of merging, use **binary search** to find a partition point in both arrays such that:
- Left half contains exactly `k` elements
- All elements in left half <= all elements in right half

### Partitioning Logic
If we pick `cut1` elements from arr1 and `cut2 = k - cut1` from arr2:
- Left half: arr1[0..cut1-1] + arr2[0..cut2-1]
- Right half: arr1[cut1..] + arr2[cut2..]

For valid partition:
- `max(left1, left2) <= min(right1, right2)`

---

## Brute Force Approach

### Algorithm
Merge both arrays and return k-th element.

### Code
```python
def kth_element_brute(arr1, arr2, k):
    merged = []
    i, j = 0, 0
    
    while i < len(arr1) and j < len(arr2):
        if arr1[i] <= arr2[j]:
            merged.append(arr1[i])
            i += 1
        else:
            merged.append(arr2[j])
            j += 1
    
    merged.extend(arr1[i:])
    merged.extend(arr2[j:])
    
    return merged[k - 1]
```

### Complexity
- **Time**: O(m + n)
- **Space**: O(m + n)

---

## Optimal Approach: Binary Search

### Algorithm
1. Binary search on the smaller array for partition point `cut1`
2. Calculate `cut2 = k - cut1`
3. Get left and right elements for both arrays
4. Check if partition is valid
5. Adjust search range based on comparison

### Visualization

```
arr1 = [2, 3, 6, 7, 9]  (m=5)
arr2 = [1, 4, 8, 10]    (n=4)
k = 5

Binary search on smaller array (arr2, n=4)

=== Step 1 ===
low=max(0, k-m)=0, high=min(k,n)=4

cut2 = (0+4)/2 = 2  (take 2 from arr2)
cut1 = k - cut2 = 5 - 2 = 3  (take 3 from arr1)

arr1: [2, 3, 6 | 7, 9]
       left1=6   right1=7

arr2: [1, 4 | 8, 10]
      left2=4  right2=8

Check: max(left1=6, left2=4) <= min(right1=7, right2=8)?
       6 <= 7? YES!

Answer = max(left1, left2) = max(6, 4) = 6
```

### Search Space Reduction

```
Array sizes: m=5, n=4
k = 5

Brute force: Merge 9 elements
Binary search: O(log(min(m,n))) = O(log 4) = 2 steps max
```

---

## Dry Run with Different Example

```
arr1 = [1, 3, 5]  (m=3)
arr2 = [2, 4, 6]  (n=3)
k = 4

Search on arr2 (smaller or equal)
low = max(0, 4-3) = 1
high = min(4, 3) = 3

Step 1: cut2 = 2, cut1 = 4-2 = 2
  arr1: [1, 3 | 5]  left1=3, right1=5
  arr2: [2, 4 | 6]  left2=4, right2=6
  max(3,4)=4 <= min(5,6)=5? YES!
  Answer = max(3, 4) = 4

Verify: Merged = [1, 2, 3, 4, 5, 6], k=4 is 4. Correct!
```

---

## Code Implementation

```python
def kth_element(arr1, arr2, k):
    """
    Find k-th element using binary search on partitions.
    Time: O(log(min(m, n)))
    Space: O(1)
    """
    m, n = len(arr1), len(arr2)
    
    # Ensure arr1 is the smaller array
    if m > n:
        return kth_element(arr2, arr1, k)
    
    # Binary search bounds
    low = max(0, k - n)  # At least k-n from arr1 (if arr2 can't provide enough)
    high = min(k, m)     # At most k from arr1
    
    while low <= high:
        cut1 = (low + high) // 2
        cut2 = k - cut1
        
        # Left elements (use -inf if cut is 0)
        left1 = arr1[cut1 - 1] if cut1 > 0 else float('-inf')
        left2 = arr2[cut2 - 1] if cut2 > 0 else float('-inf')
        
        # Right elements (use inf if cut is at end)
        right1 = arr1[cut1] if cut1 < m else float('inf')
        right2 = arr2[cut2] if cut2 < n else float('inf')
        
        if left1 <= right2 and left2 <= right1:
            # Valid partition found
            return max(left1, left2)
        elif left1 > right2:
            # Too many from arr1, need fewer
            high = cut1 - 1
        else:
            # Too few from arr1, need more
            low = cut1 + 1
    
    return -1
```

---

## Time and Space Complexity

### Optimal Approach
- **Time**: O(log(min(m, n)))
  - Binary search on smaller array
  
- **Space**: O(1)
  - Only using pointers

### Comparison
| Approach | Time | Space |
|----------|------|-------|
| Merge | O(m + n) | O(m + n) |
| Count while merging | O(k) | O(1) |
| Binary Search | O(log(min(m,n))) | O(1) |

---

## Key Takeaways

1. **Binary search on smaller array**: Reduces time complexity

2. **Partition thinking**: Split both arrays such that left has exactly k elements

3. **Boundary conditions**:
   - `low = max(0, k-n)`: Need at least this many from arr1
   - `high = min(k, m)`: Can take at most this many from arr1

4. **Handle edge cases**: Use -inf/inf when partition is at boundaries

5. **Valid partition check**: `max(left1, left2) <= min(right1, right2)`

6. **Related problems**:
   - Median of two sorted arrays
   - Merge k sorted arrays
