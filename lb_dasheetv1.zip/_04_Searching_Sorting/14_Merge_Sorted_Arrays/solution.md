# Merge Two Sorted Arrays Without Extra Space

## Problem Statement

Given two sorted arrays `arr1[]` of size `n` and `arr2[]` of size `m`, merge `arr2` into `arr1` such that the final result is sorted. Do this **without using extra space**.

After merging, `arr1` should contain the first `n` smallest elements and `arr2` should contain the remaining elements, both in sorted order.

**Example 1:**
```
Input: arr1 = [1, 5, 9, 10, 15], arr2 = [2, 3, 8, 12]
Output: arr1 = [1, 2, 3, 5, 8], arr2 = [9, 10, 12, 15]
```

**Example 2:**
```
Input: arr1 = [1, 2, 3], arr2 = [4, 5, 6]
Output: arr1 = [1, 2, 3], arr2 = [4, 5, 6]
(Already in correct order)
```

---

## Approach Intuition

### Key Challenge
- Normal merge uses O(n+m) extra space
- We need O(1) space - modify arrays in-place!

### Key Insight
Compare elements from:
- End of arr1 (largest in arr1)
- Start of arr2 (smallest in arr2)

If `arr1[end] > arr2[start]`, swap them! Then re-sort both arrays.

---

## Approach 1: Insertion Sort Style

### Algorithm
1. Compare `arr1[n-1]` with `arr2[0]`
2. If `arr1[n-1] > arr2[0]`, swap them
3. Place swapped element in correct position (like insertion sort)
4. Repeat

### Code
```python
def merge_insertion(arr1, arr2):
    n, m = len(arr1), len(arr2)
    
    for i in range(n - 1, -1, -1):
        if arr1[i] > arr2[0]:
            # Swap
            arr1[i], arr2[0] = arr2[0], arr1[i]
            
            # Place arr2[0] in correct position
            first = arr2[0]
            k = 1
            while k < m and arr2[k] < first:
                arr2[k - 1] = arr2[k]
                k += 1
            arr2[k - 1] = first
```

### Complexity
- **Time**: O(n * m) - for each swap, may need to shift m elements
- **Space**: O(1)

---

## Approach 2: Gap Method (Shell Sort Based)

### Algorithm
1. Start with gap = ceil((n + m) / 2)
2. Compare elements that are `gap` apart
3. If left > right, swap them
4. Reduce gap: gap = ceil(gap / 2)
5. Repeat until gap = 0

### Visualization of Gap Method

```
arr1 = [1, 5, 9, 10, 15], arr2 = [2, 3, 8, 12]
Combined view: [1, 5, 9, 10, 15 | 2, 3, 8, 12]
Total length = 9

=== Gap = ceil(9/2) = 5 ===

Compare indices: (0,5), (1,6), (2,7), (3,8)
[1, 5, 9, 10, 15 | 2, 3, 8, 12]
 ^              ^
 0              5
Compare arr1[0]=1 with arr2[0]=2: No swap (1 < 2)

[1, 5, 9, 10, 15 | 2, 3, 8, 12]
    ^               ^
    1               6
Compare arr1[1]=5 with arr2[1]=3: SWAP! (5 > 3)
[1, 3, 9, 10, 15 | 2, 5, 8, 12]

[1, 3, 9, 10, 15 | 2, 5, 8, 12]
       ^               ^
       2               7
Compare arr1[2]=9 with arr2[2]=8: SWAP! (9 > 8)
[1, 3, 8, 10, 15 | 2, 5, 9, 12]

[1, 3, 8, 10, 15 | 2, 5, 9, 12]
          ^               ^
          3               8
Compare arr1[3]=10 with arr2[3]=12: No swap (10 < 12)

=== Gap = ceil(5/2) = 3 ===

Compare: (0,3), (1,4), (2,5), (3,6), (4,7), (5,8)
... continue until sorted

=== Gap = 1 ===
Final pass ensures complete sorting

Final: arr1 = [1, 2, 3, 5, 8], arr2 = [9, 10, 12, 15]
```

### Search Space Reduction

```
Gap sequence: 5 -> 3 -> 2 -> 1

Each gap pass:
  - Compares elements far apart first
  - Quickly moves small elements left
  - Moves large elements right

After gap=5: Major elements in approximate position
After gap=3: Medium adjustments
After gap=1: Final fine-tuning
```

---

## Dry Run with Different Example

```
arr1 = [1, 4, 7], arr2 = [2, 3]
n = 3, m = 2, total = 5

Gap = 3:
  Compare (0,3): arr1[0]=1 vs arr2[0]=2, no swap
  Compare (1,4): arr1[1]=4 vs arr2[1]=3, SWAP!
  arr1 = [1, 3, 7], arr2 = [2, 4]

Gap = 2:
  Compare (0,2): arr1[0]=1 vs arr1[2]=7, no swap
  Compare (1,3): arr1[1]=3 vs arr2[0]=2, SWAP!
  arr1 = [1, 2, 7], arr2 = [3, 4]
  Compare (2,4): arr1[2]=7 vs arr2[1]=4, SWAP!
  arr1 = [1, 2, 4], arr2 = [3, 7]

Gap = 1:
  Compare (0,1): 1 vs 2, no swap
  Compare (1,2): 2 vs 4, no swap
  Compare (2,3): 4 vs 3, SWAP!
  arr1 = [1, 2, 3], arr2 = [4, 7]
  Compare (3,4): 4 vs 7, no swap

Final: arr1 = [1, 2, 3], arr2 = [4, 7]
```

---

## Code Implementation

```python
import math

def merge_gap_method(arr1, arr2):
    n, m = len(arr1), len(arr2)
    gap = math.ceil((n + m) / 2)
    
    while gap > 0:
        # Compare within arr1
        i = 0
        while i + gap < n:
            if arr1[i] > arr1[i + gap]:
                arr1[i], arr1[i + gap] = arr1[i + gap], arr1[i]
            i += 1
        
        # Compare arr1 and arr2
        j = gap - n if gap > n else 0
        while i < n and j < m:
            if arr1[i] > arr2[j]:
                arr1[i], arr2[j] = arr2[j], arr1[i]
            i += 1
            j += 1
        
        # Compare within arr2
        if j < m:
            j = 0
            while j + gap < m:
                if arr2[j] > arr2[j + gap]:
                    arr2[j], arr2[j + gap] = arr2[j + gap], arr2[j]
                j += 1
        
        # Reduce gap
        if gap == 1:
            break
        gap = math.ceil(gap / 2)
```

---

## Time and Space Complexity

### Gap Method
- **Time Complexity**: O((n+m) * log(n+m))
  - log(n+m) gap iterations
  - Each iteration: O(n+m) comparisons
  
- **Space Complexity**: O(1)
  - Only using variables for indices

### Comparison
| Approach | Time | Space |
|----------|------|-------|
| Extra Array | O(n+m) | O(n+m) |
| Insertion Style | O(n*m) | O(1) |
| Gap Method | O((n+m)log(n+m)) | O(1) |

---

## Key Takeaways

1. **Gap method from Shell Sort**: Use decreasing gaps to sort with O(1) space

2. **Three regions to compare**:
   - Within arr1
   - Between arr1 and arr2 (boundary)
   - Within arr2

3. **Gap reduction**: ceil(gap/2) ensures we eventually reach gap=1

4. **Why it works**: Large gaps quickly move elements to approximate positions; small gaps do fine adjustments

5. **Trade-off**: O((n+m)log(n+m)) time vs O(n+m) with extra space
