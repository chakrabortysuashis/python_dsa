"""
Merge Two Sorted Arrays Without Extra Space
============================================

Problem: Given two sorted arrays, merge them in-place such that arr1 contains
first n smallest elements and arr2 contains remaining elements, both sorted.

Time Complexity: O((n+m) * log(n+m)) using Gap method
Space Complexity: O(1)
"""

import math


def merge_with_extra_space(arr1: list, arr2: list) -> tuple:
    """
    Standard merge with O(n+m) extra space.
    Used for verification.
    """
    result = []
    i, j = 0, 0
    n, m = len(arr1), len(arr2)

    while i < n and j < m:
        if arr1[i] <= arr2[j]:
            result.append(arr1[i])
            i += 1
        else:
            result.append(arr2[j])
            j += 1

    result.extend(arr1[i:])
    result.extend(arr2[j:])

    return result[:n], result[n:]


def merge_insertion_style(arr1: list, arr2: list) -> None:
    """
    Insertion sort style merge - O(n*m) time, O(1) space.

    Compare last of arr1 with first of arr2.
    If arr1's element is larger, swap and re-position.
    """
    n, m = len(arr1), len(arr2)

    for i in range(n - 1, -1, -1):
        # Compare arr1's last with arr2's first
        if arr1[i] > arr2[0]:
            # Swap
            arr1[i], arr2[0] = arr2[0], arr1[i]

            # Place arr2[0] in correct position in arr2
            first = arr2[0]
            k = 1
            while k < m and arr2[k] < first:
                arr2[k - 1] = arr2[k]
                k += 1
            arr2[k - 1] = first


def merge_gap_method(arr1: list, arr2: list) -> None:
    """
    Gap method (Shell sort based) - O((n+m)log(n+m)) time, O(1) space.

    Use decreasing gaps to compare and swap elements.
    This efficiently moves elements to their correct arrays.
    """
    n, m = len(arr1), len(arr2)
    total = n + m
    gap = (total + 1) // 2  # ceil(total / 2)

    while gap > 0:
        i = 0

        # Compare within arr1
        while i + gap < n:
            if arr1[i] > arr1[i + gap]:
                arr1[i], arr1[i + gap] = arr1[i + gap], arr1[i]
            i += 1

        # Compare between arr1 and arr2
        j = max(0, gap - n)  # Start of arr2 index
        while i < n and j < m:
            if arr1[i] > arr2[j]:
                arr1[i], arr2[j] = arr2[j], arr1[i]
            i += 1
            j += 1

        # Compare within arr2
        if j < m:
            k = 0
            while k + gap < m:
                if arr2[k] > arr2[k + gap]:
                    arr2[k], arr2[k + gap] = arr2[k + gap], arr2[k]
                k += 1

        # Reduce gap
        if gap == 1:
            break
        gap = (gap + 1) // 2


def merge_gap_method_simple(arr1: list, arr2: list) -> None:
    """
    Simplified gap method treating both arrays as one.
    Cleaner logic but same complexity.
    """
    n, m = len(arr1), len(arr2)
    total = n + m

    def get_val(idx):
        return arr1[idx] if idx < n else arr2[idx - n]

    def set_val(idx, val):
        if idx < n:
            arr1[idx] = val
        else:
            arr2[idx - n] = val

    def swap_if_needed(i, j):
        val_i, val_j = get_val(i), get_val(j)
        if val_i > val_j:
            set_val(i, val_j)
            set_val(j, val_i)

    gap = (total + 1) // 2

    while gap > 0:
        i = 0
        while i + gap < total:
            swap_if_needed(i, i + gap)
            i += 1

        if gap == 1:
            break
        gap = (gap + 1) // 2


# ==================== TEST CASES ====================

def test_merge_arrays():
    """Comprehensive test cases."""

    print("=" * 60)
    print("MERGE TWO SORTED ARRAYS WITHOUT EXTRA SPACE")
    print("=" * 60)

    test_cases = [
        # (arr1, arr2, expected_arr1, expected_arr2)
        ([1, 5, 9, 10, 15], [2, 3, 8, 12], [1, 2, 3, 5, 8], [9, 10, 12, 15]),
        ([1, 2, 3], [4, 5, 6], [1, 2, 3], [4, 5, 6]),
        ([4, 5, 6], [1, 2, 3], [1, 2, 3], [4, 5, 6]),
        ([1], [2], [1], [2]),
        ([2], [1], [1], [2]),
        ([1, 4, 7], [2, 3], [1, 2, 3], [4, 7]),
        ([10, 20, 30], [5, 15, 25, 35], [5, 10, 15], [20, 25, 30, 35]),
        ([1, 2, 3, 4], [5], [1, 2, 3, 4], [5]),
    ]

    all_passed = True

    for i, (arr1, arr2, exp1, exp2) in enumerate(test_cases, 1):
        # Test gap method
        a1, a2 = arr1.copy(), arr2.copy()
        merge_gap_method(a1, a2)

        status = "PASS" if a1 == exp1 and a2 == exp2 else "FAIL"
        if a1 != exp1 or a2 != exp2:
            all_passed = False

        print(f"\nTest {i}: {status}")
        print(f"  Input arr1: {arr1}")
        print(f"  Input arr2: {arr2}")
        print(f"  Expected: {exp1}, {exp2}")
        print(f"  Got: {a1}, {a2}")

    # Compare methods
    print("\n" + "-" * 60)
    print("Comparing All Methods:")
    print("-" * 60)

    for arr1, arr2, exp1, exp2 in test_cases[:4]:
        # Insertion style
        a1_ins, a2_ins = arr1.copy(), arr2.copy()
        merge_insertion_style(a1_ins, a2_ins)

        # Gap method
        a1_gap, a2_gap = arr1.copy(), arr2.copy()
        merge_gap_method(a1_gap, a2_gap)

        # Simple gap
        a1_simple, a2_simple = arr1.copy(), arr2.copy()
        merge_gap_method_simple(a1_simple, a2_simple)

        all_same = (a1_ins == a1_gap == a1_simple == exp1 and
                    a2_ins == a2_gap == a2_simple == exp2)

        print(f"\n  Input: {arr1}, {arr2}")
        print(f"  Insertion: {a1_ins}, {a2_ins}")
        print(f"  Gap: {a1_gap}, {a2_gap}")
        print(f"  Simple Gap: {a1_simple}, {a2_simple}")
        print(f"  All correct: {all_same}")

    print("\n" + "=" * 60)
    print(f"All tests passed: {all_passed}")
    print("=" * 60)


def visualize_gap_method(arr1: list, arr2: list):
    """Visualize the gap method step by step."""

    print(f"\nVisualizing Gap Method")
    print(f"arr1 = {arr1}")
    print(f"arr2 = {arr2}")
    print("=" * 60)

    arr1 = arr1.copy()
    arr2 = arr2.copy()
    n, m = len(arr1), len(arr2)
    total = n + m
    gap = (total + 1) // 2

    def get_val(idx):
        return arr1[idx] if idx < n else arr2[idx - n]

    def set_val(idx, val):
        if idx < n:
            arr1[idx] = val
        else:
            arr2[idx - n] = val

    iteration = 1
    while gap > 0:
        print(f"\n--- Gap = {gap} ---")
        print(f"Current: arr1={arr1}, arr2={arr2}")

        i = 0
        while i + gap < total:
            val_i = get_val(i)
            val_j = get_val(i + gap)

            i_in = "arr1" if i < n else "arr2"
            j_in = "arr1" if i + gap < n else "arr2"
            i_idx = i if i < n else i - n
            j_idx = (i + gap) if i + gap < n else (i + gap - n)

            if val_i > val_j:
                print(f"  Compare {i_in}[{i_idx}]={val_i} with {j_in}[{j_idx}]={val_j}: SWAP!")
                set_val(i, val_j)
                set_val(i + gap, val_i)
            else:
                print(f"  Compare {i_in}[{i_idx}]={val_i} with {j_in}[{j_idx}]={val_j}: OK")

            i += 1

        print(f"After gap {gap}: arr1={arr1}, arr2={arr2}")

        if gap == 1:
            break
        gap = (gap + 1) // 2
        iteration += 1

    print(f"\nFinal result:")
    print(f"  arr1 = {arr1}")
    print(f"  arr2 = {arr2}")


if __name__ == "__main__":
    test_merge_arrays()

    # Visualize specific examples
    visualize_gap_method([1, 5, 9, 10, 15], [2, 3, 8, 12])
    visualize_gap_method([1, 4, 7], [2, 3])
