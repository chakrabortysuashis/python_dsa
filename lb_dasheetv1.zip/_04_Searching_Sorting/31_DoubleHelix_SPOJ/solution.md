# Double Helix SPOJ

## Problem Statement

Two sorted sequences with common elements (intersection points). Find maximum sum path starting from either sequence's beginning, where you can switch sequences at intersection points.

**Example:**
```
Seq1: [3, 5, 7, 9, 20, 25, 30, 40, 55, 56, 57, 60, 62]
Seq2: [1, 4, 7, 11, 14, 25, 44, 47, 55, 57, 100]

Intersection points: 7, 25, 55, 57
Max sum path: Start from Seq2, switch at optimal points
```

---

## Approach: Two Pointers

### Algorithm
1. Use two pointers to traverse both sequences
2. At each intersection point, choose path with larger sum
3. After intersection, reset both sums to 0

---

## Code

```python
def double_helix(seq1, seq2):
    i, j = 0, 0
    sum1, sum2 = 0, 0
    total = 0
    
    while i < len(seq1) and j < len(seq2):
        if seq1[i] < seq2[j]:
            sum1 += seq1[i]
            i += 1
        elif seq1[i] > seq2[j]:
            sum2 += seq2[j]
            j += 1
        else:  # Intersection point
            total += max(sum1, sum2) + seq1[i]
            sum1 = sum2 = 0
            i += 1
            j += 1
    
    # Add remaining elements
    while i < len(seq1):
        sum1 += seq1[i]
        i += 1
    while j < len(seq2):
        sum2 += seq2[j]
        j += 1
    
    total += max(sum1, sum2)
    return total
```

---

## Complexity

- **Time**: O(m + n)
- **Space**: O(1)

---

## Key Insight

At each intersection, choose the segment that gave higher sum. This greedy choice is optimal because paths can only switch at intersections.
