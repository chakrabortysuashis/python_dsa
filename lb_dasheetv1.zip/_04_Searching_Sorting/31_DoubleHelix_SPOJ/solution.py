"""
Double Helix SPOJ
=================

Problem: Two sorted sequences with intersection points.
Find max sum path switching at intersections.

Solution: Two pointers, track sums between intersections,
take max at each intersection.

Time: O(m + n)
Space: O(1)
"""


def double_helix(seq1: list, seq2: list) -> int:
    """Find maximum sum path through two sequences."""
    i, j = 0, 0
    n, m = len(seq1), len(seq2)
    sum1, sum2 = 0, 0
    total = 0

    while i < n and j < m:
        if seq1[i] < seq2[j]:
            sum1 += seq1[i]
            i += 1
        elif seq1[i] > seq2[j]:
            sum2 += seq2[j]
            j += 1
        else:  # Intersection point
            total += max(sum1, sum2) + seq1[i]
            sum1 = sum2 = 0
            i += 1
            j += 1

    # Add remaining elements
    while i < n:
        sum1 += seq1[i]
        i += 1
    while j < m:
        sum2 += seq2[j]
        j += 1

    total += max(sum1, sum2)
    return total


def test_double_helix():
    print("=" * 50)
    print("DOUBLE HELIX SPOJ")
    print("=" * 50)

    test_cases = [
        ([3, 5, 7, 9, 20, 25, 30, 40, 55, 56, 57, 60, 62],
         [1, 4, 7, 11, 14, 25, 44, 47, 55, 57, 100],
         450),
        ([1, 2, 3], [4, 5, 6], 15),  # No intersection
        ([1, 5, 10], [5, 10, 15], 35),
    ]

    for seq1, seq2, expected in test_cases:
        result = double_helix(seq1, seq2)
        print(f"\nSeq1: {seq1[:5]}...")
        print(f"Seq2: {seq2[:5]}...")
        print(f"Max sum: {result}")
        print(f"Expected: {expected}, {'PASS' if result == expected else 'FAIL'}")


if __name__ == "__main__":
    test_double_helix()
