# Search in a Rotated Sorted Array

## Problem Statement

Given a sorted array that has been rotated at some pivot point, search for a target value. Return the index if found, otherwise return -1.

A rotated array is one where elements have been shifted: `[1,2,3,4,5,6,7]` rotated by 3 becomes `[4,5,6,7,1,2,3]`.

**Example 1:**
```
Input: arr = [4, 5, 6, 7, 0, 1, 2], target = 0
Output: 4
```

**Example 2:**
```
Input: arr = [4, 5, 6, 7, 0, 1, 2], target = 3
Output: -1
```

**Example 3:**
```
Input: arr = [1], target = 0
Output: -1
```

---

## Binary Search Intuition

Even though the array is rotated, it still has a special property:
- **At least one half is always sorted!**

```
Original: [0, 1, 2, 3, 4, 5, 6]
Rotated:  [4, 5, 6, 7, 0, 1, 2]
           |sorted|  |sorted|
```

At any `mid`:
- Either left half `[low...mid]` is sorted, OR
- Right half `[mid...high]` is sorted

**Strategy**: 
1. Identify which half is sorted
2. Check if target lies in the sorted half
3. Eliminate the other half

---

## Brute Force Approach

### Algorithm
Linear scan through the array.

### Code
```python
def search_brute(arr, target):
    for i in range(len(arr)):
        if arr[i] == target:
            return i
    return -1
```

### Complexity
- **Time**: O(n)
- **Space**: O(1)

---

## Optimal Approach: Modified Binary Search

### Algorithm
1. Find `mid`
2. Check if `arr[mid] == target` (found!)
3. Determine which half is sorted:
   - If `arr[low] <= arr[mid]`: LEFT half is sorted
   - Otherwise: RIGHT half is sorted
4. Check if target is in the sorted half:
   - If yes: search that half
   - If no: search the other half

### Visualization of Pointer Movement

```
Array: [4, 5, 6, 7, 0, 1, 2]
Target: 0

Step 1: low=0, high=6, mid=3
        [4, 5, 6, 7, 0, 1, 2]
         L        M        H

        arr[low]=4 <= arr[mid]=7
        LEFT half [4,5,6,7] is SORTED

        Is target=0 in [4,5,6,7]? 
        4 <= 0 <= 7? NO!
        
        Search RIGHT: low = mid + 1 = 4

Step 2: low=4, high=6, mid=5
        [4, 5, 6, 7, 0, 1, 2]
                     L  M  H

        arr[low]=0 <= arr[mid]=1
        LEFT half [0,1] is SORTED

        Is target=0 in [0,1]?
        0 <= 0 <= 1? YES!
        
        Search LEFT: high = mid - 1 = 4

Step 3: low=4, high=4, mid=4
        [4, 5, 6, 7, 0, 1, 2]
                    LMH

        arr[mid] = 0 == target = 0
        FOUND at index 4!
```

### Another Example

```
Array: [6, 7, 0, 1, 2, 4, 5]
Target: 4

Step 1: low=0, high=6, mid=3
        [6, 7, 0, 1, 2, 4, 5]
         L        M        H

        arr[low]=6 > arr[mid]=1
        RIGHT half [1,2,4,5] is SORTED

        Is target=4 in [1,2,4,5]?
        1 <= 4 <= 5? YES!
        
        Search RIGHT: low = mid + 1 = 4

Step 2: low=4, high=6, mid=5
        [6, 7, 0, 1, 2, 4, 5]
                     L  M  H

        arr[low]=2 <= arr[mid]=4
        LEFT half [2,4] is SORTED

        Is target=4 in [2,4]?
        2 <= 4 <= 4? YES!
        
        Search LEFT: high = mid - 1 = 5
        (Actually mid=5, arr[5]=4 == target!)
        
        FOUND at index 5!
```

---

## Key Decision Table

```
| Condition              | Sorted Half | Target in Sorted Half?        | Action           |
|------------------------|-------------|-------------------------------|------------------|
| arr[low] <= arr[mid]   | LEFT        | arr[low] <= target < arr[mid] | Search LEFT      |
| arr[low] <= arr[mid]   | LEFT        | Otherwise                     | Search RIGHT     |
| arr[low] > arr[mid]    | RIGHT       | arr[mid] < target <= arr[high]| Search RIGHT     |
| arr[low] > arr[mid]    | RIGHT       | Otherwise                     | Search LEFT      |
```

---

## Dry Run: Target Not Found

```
Array: [4, 5, 6, 7, 0, 1, 2]
Target: 3

Step 1: low=0, high=6, mid=3
        arr[mid]=7, LEFT [4,5,6,7] sorted
        Is 3 in [4,7]? 4 <= 3? NO
        Search RIGHT: low=4

Step 2: low=4, high=6, mid=5
        arr[mid]=1, LEFT [0,1] sorted
        Is 3 in [0,1]? 0 <= 3 <= 1? NO
        Search RIGHT: low=6

Step 3: low=6, high=6, mid=6
        arr[mid]=2, 2 != 3
        arr[low]=2 <= arr[mid]=2
        LEFT sorted, Is 3 in [2,2]? NO
        Search RIGHT: low=7

Step 4: low=7, high=6
        low > high, STOP!
        Return -1 (not found)
```

---

## Code Implementation

```python
def search_rotated(arr, target):
    low, high = 0, len(arr) - 1
    
    while low <= high:
        mid = low + (high - low) // 2
        
        # Found target
        if arr[mid] == target:
            return mid
        
        # Check which half is sorted
        if arr[low] <= arr[mid]:
            # LEFT half is sorted
            if arr[low] <= target < arr[mid]:
                # Target is in sorted left half
                high = mid - 1
            else:
                # Target is in right half
                low = mid + 1
        else:
            # RIGHT half is sorted
            if arr[mid] < target <= arr[high]:
                # Target is in sorted right half
                low = mid + 1
            else:
                # Target is in left half
                high = mid - 1
    
    return -1
```

---

## Finding the Rotation Point (Bonus)

```python
def find_rotation_point(arr):
    """Find the index of minimum element (rotation point)."""
    low, high = 0, len(arr) - 1
    
    # Array not rotated
    if arr[low] <= arr[high]:
        return 0
    
    while low <= high:
        mid = low + (high - low) // 2
        
        # Check if mid is rotation point
        if arr[mid] > arr[mid + 1]:
            return mid + 1
        if arr[mid - 1] > arr[mid]:
            return mid
        
        # Decide which half to search
        if arr[mid] >= arr[low]:
            low = mid + 1
        else:
            high = mid - 1
    
    return 0
```

---

## Time and Space Complexity

### Optimal Approach
- **Time Complexity**: O(log n)
  - Binary search, halving search space each iteration

- **Space Complexity**: O(1)
  - Only using constant extra space

### Comparison
| Approach | Time | Space |
|----------|------|-------|
| Brute Force | O(n) | O(1) |
| Binary Search | O(log n) | O(1) |

---

## Edge Cases

1. **Array not rotated**: `[1, 2, 3, 4, 5]` - works like normal binary search
2. **Single element**: `[1]` - check if equals target
3. **Two elements**: `[2, 1]` - handle carefully
4. **Target at rotation point**: `[4, 5, 1, 2, 3]`, target=1
5. **Target at boundaries**: First or last element

---

## Key Takeaways

1. **One half is always sorted**: This is the key insight that enables binary search

2. **Identify sorted half**: Compare `arr[low]` with `arr[mid]`
   - `arr[low] <= arr[mid]`: Left half sorted
   - Otherwise: Right half sorted

3. **Check target in sorted half**: Use range check on sorted portion

4. **Eliminate half**: Based on whether target is in sorted half or not

5. **Handle duplicates**: If duplicates exist, this approach needs modification (shrink from both ends when `arr[low] == arr[mid] == arr[high]`)
