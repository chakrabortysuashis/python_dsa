"""
Search in a Rotated Sorted Array
=================================

Problem: Given a sorted array that has been rotated at some pivot point,
search for a target value and return its index. Return -1 if not found.

Key Insight: At least one half of the array is always sorted!

Time Complexity: O(log n)
Space Complexity: O(1)
"""


def search_rotated(arr: list, target: int) -> int:
    """
    Search for target in a rotated sorted array using binary search.

    The key insight is that at any mid point, at least one half is sorted.
    We can determine which half is sorted and check if target lies there.

    Args:
        arr: Rotated sorted array of distinct integers
        target: Value to search for

    Returns:
        Index of target if found, -1 otherwise
    """
    if not arr:
        return -1

    low, high = 0, len(arr) - 1

    while low <= high:
        mid = low + (high - low) // 2

        # Found the target
        if arr[mid] == target:
            return mid

        # Determine which half is sorted
        if arr[low] <= arr[mid]:
            # LEFT half [low...mid] is sorted
            if arr[low] <= target < arr[mid]:
                # Target is in the sorted left half
                high = mid - 1
            else:
                # Target is in the right half
                low = mid + 1
        else:
            # RIGHT half [mid...high] is sorted
            if arr[mid] < target <= arr[high]:
                # Target is in the sorted right half
                low = mid + 1
            else:
                # Target is in the left half
                high = mid - 1

    return -1


def search_rotated_brute(arr: list, target: int) -> int:
    """
    Brute force approach: Linear scan.

    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    for i in range(len(arr)):
        if arr[i] == target:
            return i
    return -1


def find_rotation_pivot(arr: list) -> int:
    """
    Find the index of the minimum element (rotation pivot).

    The pivot is where the sorted order "breaks".
    Example: [4,5,6,7,0,1,2] -> pivot is at index 4 (value 0)

    Time Complexity: O(log n)
    Space Complexity: O(1)
    """
    if not arr:
        return -1

    low, high = 0, len(arr) - 1

    # Array is not rotated
    if arr[low] <= arr[high]:
        return 0

    while low <= high:
        mid = low + (high - low) // 2

        # Check if mid+1 is the pivot
        if mid < len(arr) - 1 and arr[mid] > arr[mid + 1]:
            return mid + 1

        # Check if mid is the pivot
        if mid > 0 and arr[mid - 1] > arr[mid]:
            return mid

        # Decide which half contains the pivot
        if arr[mid] >= arr[low]:
            # Pivot is in the right half
            low = mid + 1
        else:
            # Pivot is in the left half
            high = mid - 1

    return 0


def search_using_pivot(arr: list, target: int) -> int:
    """
    Alternative approach: Find pivot first, then do standard binary search.

    Time Complexity: O(log n)
    Space Complexity: O(1)
    """
    if not arr:
        return -1

    n = len(arr)
    pivot = find_rotation_pivot(arr)

    # Decide which half to search based on target
    if pivot == 0:
        # Array is not rotated, standard binary search
        return binary_search(arr, target, 0, n - 1)
    elif target >= arr[0]:
        # Target is in the left portion (before pivot)
        return binary_search(arr, target, 0, pivot - 1)
    else:
        # Target is in the right portion (after pivot)
        return binary_search(arr, target, pivot, n - 1)


def binary_search(arr: list, target: int, low: int, high: int) -> int:
    """Standard binary search in a range."""
    while low <= high:
        mid = low + (high - low) // 2
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
    return -1


def search_rotated_with_duplicates(arr: list, target: int) -> bool:
    """
    Search in rotated sorted array WITH duplicates.

    When arr[low] == arr[mid] == arr[high], we can't determine
    which half is sorted, so we shrink from both ends.

    Time Complexity: O(n) worst case, O(log n) average
    Space Complexity: O(1)

    Returns:
        True if target exists, False otherwise
    """
    if not arr:
        return False

    low, high = 0, len(arr) - 1

    while low <= high:
        mid = low + (high - low) // 2

        if arr[mid] == target:
            return True

        # When we can't determine which half is sorted
        if arr[low] == arr[mid] == arr[high]:
            low += 1
            high -= 1
        elif arr[low] <= arr[mid]:
            # Left half is sorted
            if arr[low] <= target < arr[mid]:
                high = mid - 1
            else:
                low = mid + 1
        else:
            # Right half is sorted
            if arr[mid] < target <= arr[high]:
                low = mid + 1
            else:
                high = mid - 1

    return False


def find_min_rotated(arr: list) -> int:
    """
    Find the minimum element in a rotated sorted array.

    Time Complexity: O(log n)
    Space Complexity: O(1)
    """
    if not arr:
        return -1

    low, high = 0, len(arr) - 1

    # Array is not rotated
    if arr[low] <= arr[high]:
        return arr[low]

    while low < high:
        mid = low + (high - low) // 2

        if arr[mid] > arr[high]:
            # Minimum is in right half
            low = mid + 1
        else:
            # Minimum is in left half (including mid)
            high = mid

    return arr[low]


# ==================== TEST CASES ====================

def test_search_rotated():
    """Comprehensive test cases."""

    print("=" * 60)
    print("SEARCH IN ROTATED SORTED ARRAY")
    print("=" * 60)

    test_cases = [
        # (array, target, expected)
        ([4, 5, 6, 7, 0, 1, 2], 0, 4),
        ([4, 5, 6, 7, 0, 1, 2], 3, -1),
        ([4, 5, 6, 7, 0, 1, 2], 4, 0),
        ([4, 5, 6, 7, 0, 1, 2], 2, 6),
        ([1], 0, -1),
        ([1], 1, 0),
        ([1, 3], 3, 1),
        ([3, 1], 1, 1),
        ([3, 1], 3, 0),
        ([2, 3, 4, 5, 1], 1, 4),
        ([6, 7, 0, 1, 2, 4, 5], 4, 5),
        ([1, 2, 3, 4, 5], 3, 2),  # Not rotated
        ([], 5, -1),
    ]

    all_passed = True

    for i, (arr, target, expected) in enumerate(test_cases, 1):
        result = search_rotated(arr, target)
        status = "PASS" if result == expected else "FAIL"

        if result != expected:
            all_passed = False

        print(f"\nTest {i}: {status}")
        print(f"  Array: {arr}")
        print(f"  Target: {target}")
        print(f"  Expected: {expected}, Got: {result}")

    # Test pivot finding
    print("\n" + "-" * 60)
    print("Testing Pivot Finding:")
    print("-" * 60)

    pivot_tests = [
        ([4, 5, 6, 7, 0, 1, 2], 4),
        ([2, 3, 4, 5, 1], 4),
        ([1, 2, 3, 4, 5], 0),
        ([5, 1, 2, 3, 4], 1),
    ]

    for arr, expected in pivot_tests:
        result = find_rotation_pivot(arr)
        status = "PASS" if result == expected else "FAIL"
        print(f"  {arr} -> pivot index: {result} [{status}]")

    # Test minimum finding
    print("\n" + "-" * 60)
    print("Testing Find Minimum:")
    print("-" * 60)

    min_tests = [
        ([4, 5, 6, 7, 0, 1, 2], 0),
        ([2, 3, 4, 5, 1], 1),
        ([1, 2, 3, 4, 5], 1),
        ([3, 4, 5, 1, 2], 1),
    ]

    for arr, expected in min_tests:
        result = find_min_rotated(arr)
        status = "PASS" if result == expected else "FAIL"
        print(f"  {arr} -> min: {result} [{status}]")

    print("\n" + "=" * 60)
    print(f"All tests passed: {all_passed}")
    print("=" * 60)


def visualize_search(arr: list, target: int):
    """Visualize the binary search process."""

    print(f"\nSearching for {target} in {arr}")
    print("-" * 50)

    low, high = 0, len(arr) - 1
    step = 1

    while low <= high:
        mid = low + (high - low) // 2

        # Create visualization
        vis = []
        for i in range(len(arr)):
            if i == low and i == mid and i == high:
                vis.append(f"[LMH]{arr[i]}")
            elif i == low and i == mid:
                vis.append(f"[LM]{arr[i]}")
            elif i == mid and i == high:
                vis.append(f"[MH]{arr[i]}")
            elif i == low:
                vis.append(f"[L]{arr[i]}")
            elif i == mid:
                vis.append(f"[M]{arr[i]}")
            elif i == high:
                vis.append(f"[H]{arr[i]}")
            else:
                vis.append(f"{arr[i]}")

        print(f"Step {step}: {', '.join(vis)}")
        print(f"        low={low}, mid={mid}, high={high}")

        if arr[mid] == target:
            print(f"        arr[{mid}] = {target} -> FOUND!")
            return mid

        if arr[low] <= arr[mid]:
            print(f"        LEFT half [{arr[low]}..{arr[mid]}] is sorted")
            if arr[low] <= target < arr[mid]:
                print(f"        {target} is in left half -> high = {mid - 1}")
                high = mid - 1
            else:
                print(f"        {target} is NOT in left half -> low = {mid + 1}")
                low = mid + 1
        else:
            print(f"        RIGHT half [{arr[mid]}..{arr[high]}] is sorted")
            if arr[mid] < target <= arr[high]:
                print(f"        {target} is in right half -> low = {mid + 1}")
                low = mid + 1
            else:
                print(f"        {target} is NOT in right half -> high = {mid - 1}")
                high = mid - 1

        step += 1

    print("NOT FOUND!")
    return -1


if __name__ == "__main__":
    test_search_rotated()

    # Visualize examples
    print("\n" + "=" * 60)
    print("VISUALIZATION")
    print("=" * 60)

    visualize_search([4, 5, 6, 7, 0, 1, 2], 0)
    visualize_search([4, 5, 6, 7, 0, 1, 2], 3)
    visualize_search([6, 7, 0, 1, 2, 4, 5], 4)
