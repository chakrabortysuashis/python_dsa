# Smallest Number with N Trailing Zeros

## Problem Statement

Find the smallest positive integer whose factorial has exactly `n` trailing zeros.

**Example:**
```
Input: n = 1
Output: 5
Explanation: 5! = 120 has 1 trailing zero

Input: n = 6
Output: 25
Explanation: 25! has 6 trailing zeros
```

---

## Approach: Binary Search

### Key Insight
Trailing zeros in n! = count of factor 5 (since there are always more 2s)

`trailing_zeros(n) = n/5 + n/25 + n/125 + ...`

Binary search for smallest number with >= n zeros.

### Note
Not all values of n are achievable (e.g., n=5 is impossible since 24! has 4 zeros, 25! has 6).

---

## Code

```python
def count_trailing_zeros(n):
    """Count trailing zeros in n!"""
    count = 0
    power = 5
    while power <= n:
        count += n // power
        power *= 5
    return count

def smallest_with_n_zeros(n):
    """Binary search for smallest number with n trailing zeros."""
    if n == 0:
        return 1
    
    low, high = 1, 5 * n  # Upper bound: 5n guarantees >= n zeros
    result = -1
    
    while low <= high:
        mid = (low + high) // 2
        zeros = count_trailing_zeros(mid)
        
        if zeros >= n:
            if zeros == n:
                result = mid
            high = mid - 1
        else:
            low = mid + 1
    
    return result
```

---

## Complexity

- **Time**: O(log(5n) * log(n))
- **Space**: O(1)
