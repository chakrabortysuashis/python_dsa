"""
Smallest Number with N Trailing Zeros
=====================================

Problem: Find smallest n where n! has exactly k trailing zeros.

Solution: Binary search on n, count zeros using n/5 + n/25 + ...

Time: O(log(5k) * log(n))
Space: O(1)
"""


def count_trailing_zeros(n: int) -> int:
    """Count trailing zeros in n! using Legendre's formula."""
    count = 0
    power = 5
    while power <= n:
        count += n // power
        power *= 5
    return count


def smallest_with_n_zeros(k: int) -> int:
    """Find smallest n where n! has exactly k trailing zeros."""
    if k == 0:
        return 1

    low, high = 1, 5 * k  # 5k guarantees >= k zeros
    result = -1

    while low <= high:
        mid = (low + high) // 2
        zeros = count_trailing_zeros(mid)

        if zeros == k:
            result = mid
            high = mid - 1  # Try smaller
        elif zeros < k:
            low = mid + 1
        else:
            high = mid - 1

    return result


def test_trailing_zeros():
    print("=" * 50)
    print("SMALLEST NUMBER WITH N TRAILING ZEROS")
    print("=" * 50)

    test_cases = [(0, 1), (1, 5), (2, 10), (3, 15), (6, 25), (5, -1)]

    for k, expected in test_cases:
        result = smallest_with_n_zeros(k)
        zeros = count_trailing_zeros(result) if result > 0 else 0
        print(f"\nk={k}: smallest={result} (has {zeros} zeros)")
        print(f"Expected: {expected}, {'PASS' if result == expected else 'FAIL'}")


if __name__ == "__main__":
    test_trailing_zeros()
