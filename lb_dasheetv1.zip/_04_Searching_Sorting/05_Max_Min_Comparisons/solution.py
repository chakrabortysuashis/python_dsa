"""
Maximum and Minimum of Array Using Minimum Comparisons
======================================================

Problem: Find both max and min elements using the minimum number of comparisons.

Key Insight: Compare elements in pairs - this reduces comparisons from 2(n-1) to 3n/2-2!

Time Complexity: O(n)
Comparisons: 3n/2 - 2 (optimal)
Space Complexity: O(1)
"""


def find_max_min_optimal(arr: list) -> tuple:
    """
    Find max and min using pair comparison technique.

    Strategy: Compare elements in pairs, then compare:
    - Larger of pair with current max
    - Smaller of pair with current min

    This uses 3 comparisons per pair instead of 4!

    Args:
        arr: Non-empty list of integers

    Returns:
        Tuple of (min, max)
    """
    if not arr:
        raise ValueError("Array cannot be empty")

    n = len(arr)

    if n == 1:
        return arr[0], arr[0]

    # Initialize max and min using first pair
    if arr[0] > arr[1]:
        max_val, min_val = arr[0], arr[1]
    else:
        max_val, min_val = arr[1], arr[0]
    # 1 comparison used

    # Process remaining elements in pairs
    i = 2
    comparisons = 1

    while i < n - 1:
        # Compare pair elements with each other
        if arr[i] > arr[i + 1]:
            larger, smaller = arr[i], arr[i + 1]
        else:
            larger, smaller = arr[i + 1], arr[i]
        comparisons += 1

        # Compare larger with current max
        if larger > max_val:
            max_val = larger
        comparisons += 1

        # Compare smaller with current min
        if smaller < min_val:
            min_val = smaller
        comparisons += 1

        i += 2

    # Handle odd element (if n is odd)
    if i == n - 1:
        if arr[i] > max_val:
            max_val = arr[i]
        comparisons += 1
        if arr[i] < min_val:
            min_val = arr[i]
        comparisons += 1

    return min_val, max_val


def find_max_min_with_count(arr: list) -> tuple:
    """
    Same as optimal but also returns comparison count for verification.
    """
    if not arr:
        raise ValueError("Array cannot be empty")

    n = len(arr)

    if n == 1:
        return arr[0], arr[0], 0

    # Initialize with first pair
    if arr[0] > arr[1]:
        max_val, min_val = arr[0], arr[1]
    else:
        max_val, min_val = arr[1], arr[0]
    comparisons = 1

    # Process pairs
    i = 2
    while i < n - 1:
        if arr[i] > arr[i + 1]:
            larger, smaller = arr[i], arr[i + 1]
        else:
            larger, smaller = arr[i + 1], arr[i]
        comparisons += 1

        if larger > max_val:
            max_val = larger
        comparisons += 1

        if smaller < min_val:
            min_val = smaller
        comparisons += 1

        i += 2

    # Handle odd element
    if i == n - 1:
        if arr[i] > max_val:
            max_val = arr[i]
        comparisons += 1
        if arr[i] < min_val:
            min_val = arr[i]
        comparisons += 1

    return min_val, max_val, comparisons


def find_max_min_naive(arr: list) -> tuple:
    """
    Naive approach: Two separate passes.

    Comparisons: 2(n-1) = 2n - 2
    """
    if not arr:
        raise ValueError("Array cannot be empty")

    max_val = arr[0]
    min_val = arr[0]
    comparisons = 0

    # Find max
    for i in range(1, len(arr)):
        if arr[i] > max_val:
            max_val = arr[i]
        comparisons += 1

    # Find min
    for i in range(1, len(arr)):
        if arr[i] < min_val:
            min_val = arr[i]
        comparisons += 1

    return min_val, max_val, comparisons


def find_max_min_single_pass(arr: list) -> tuple:
    """
    Single pass approach (still 2n-2 comparisons worst case).
    """
    if not arr:
        raise ValueError("Array cannot be empty")

    max_val = arr[0]
    min_val = arr[0]
    comparisons = 0

    for i in range(1, len(arr)):
        if arr[i] > max_val:
            max_val = arr[i]
            comparisons += 1
        elif arr[i] < min_val:
            min_val = arr[i]
            comparisons += 2  # Both comparisons made
        else:
            comparisons += 2  # Both comparisons made

    return min_val, max_val, comparisons


def find_max_min_divide_conquer(arr: list, low: int = None, high: int = None) -> tuple:
    """
    Divide and Conquer approach.

    Recurrence: T(n) = 2T(n/2) + 2
    Solution: 3n/2 - 2 comparisons

    Time Complexity: O(n)
    Space Complexity: O(log n) for recursion stack
    """
    if low is None:
        low = 0
    if high is None:
        high = len(arr) - 1

    # Base case: single element
    if low == high:
        return arr[low], arr[low]

    # Base case: two elements
    if high == low + 1:
        if arr[low] > arr[high]:
            return arr[high], arr[low]
        else:
            return arr[low], arr[high]

    # Divide
    mid = (low + high) // 2
    min1, max1 = find_max_min_divide_conquer(arr, low, mid)
    min2, max2 = find_max_min_divide_conquer(arr, mid + 1, high)

    # Conquer (2 comparisons)
    final_min = min1 if min1 < min2 else min2
    final_max = max1 if max1 > max2 else max2

    return final_min, final_max


def theoretical_comparison_count(n: int) -> dict:
    """
    Calculate theoretical comparison counts for different methods.
    """
    naive = 2 * (n - 1)

    # For optimal: 3n/2 - 2 for even n, slightly adjusted for odd
    if n % 2 == 0:
        optimal = 3 * (n // 2) - 2
    else:
        optimal = 3 * (n // 2)

    return {
        'naive': naive,
        'optimal': optimal,
        'savings': naive - optimal,
        'savings_percent': round((naive - optimal) / naive * 100, 1)
    }


# ==================== TEST CASES ====================

def test_max_min():
    """Comprehensive test cases."""

    print("=" * 70)
    print("MAX AND MIN WITH MINIMUM COMPARISONS")
    print("=" * 70)

    test_cases = [
        [3, 5, 4, 1, 9],
        [22, 14, 8, 17, 35, 3],
        [1, 2, 3, 4, 5, 6, 7, 8],
        [8, 7, 6, 5, 4, 3, 2, 1],
        [5],
        [3, 1],
        [1, 3],
        [7, 2, 9, 1, 5, 8],
        list(range(100)),
    ]

    for arr in test_cases:
        min_opt, max_opt = find_max_min_optimal(arr)
        min_dc, max_dc = find_max_min_divide_conquer(arr)

        # Verify against built-in
        expected_min, expected_max = min(arr), max(arr)
        correct = (min_opt == expected_min == min_dc and
                   max_opt == expected_max == max_dc)

        print(f"\nArray: {arr[:10]}{'...' if len(arr) > 10 else ''} (n={len(arr)})")
        print(f"  Min = {min_opt}, Max = {max_opt}")
        print(f"  Correct: {correct}")

    # Test comparison counts
    print("\n" + "=" * 70)
    print("COMPARISON COUNT ANALYSIS")
    print("=" * 70)

    print(f"\n{'n':<6} {'Naive (2n-2)':<15} {'Optimal (3n/2-2)':<18} {'Savings':<10} {'%':<8}")
    print("-" * 60)

    for n in [4, 6, 8, 10, 20, 50, 100, 1000]:
        stats = theoretical_comparison_count(n)
        print(f"{n:<6} {stats['naive']:<15} {stats['optimal']:<18} {stats['savings']:<10} {stats['savings_percent']}%")

    # Verify actual comparison counts
    print("\n" + "=" * 70)
    print("ACTUAL COMPARISON COUNT VERIFICATION")
    print("=" * 70)

    test_arrays = [
        [1, 2, 3, 4, 5, 6],        # n=6
        [1, 2, 3, 4, 5, 6, 7, 8],  # n=8
        [7, 2, 9, 1, 5, 8, 3, 4],  # n=8 random
    ]

    for arr in test_arrays:
        n = len(arr)
        min_val, max_val, count = find_max_min_with_count(arr)
        theory = theoretical_comparison_count(n)

        print(f"\nArray (n={n}): {arr}")
        print(f"  Result: min={min_val}, max={max_val}")
        print(f"  Actual comparisons: {count}")
        print(f"  Theoretical optimal: {theory['optimal']}")
        print(f"  Naive would use: {theory['naive']}")


def visualize_pair_comparison(arr: list):
    """Visualize the pair comparison process step by step."""

    print(f"\nPair Comparison Visualization for {arr}")
    print("=" * 50)

    n = len(arr)
    if n < 2:
        print("Array too small for visualization")
        return

    # Initialize
    print(f"\nStep 1: Initialize with first pair ({arr[0]}, {arr[1]})")
    if arr[0] > arr[1]:
        max_val, min_val = arr[0], arr[1]
    else:
        max_val, min_val = arr[1], arr[0]
    print(f"  Compare {arr[0]} vs {arr[1]}")
    print(f"  max = {max_val}, min = {min_val}")
    print("  Comparisons: 1")

    total_comp = 1
    step = 2

    # Process pairs
    i = 2
    while i < n - 1:
        print(f"\nStep {step}: Pair ({arr[i]}, {arr[i+1]})")

        if arr[i] > arr[i + 1]:
            larger, smaller = arr[i], arr[i + 1]
        else:
            larger, smaller = arr[i + 1], arr[i]
        print(f"  Compare {arr[i]} vs {arr[i+1]}: larger={larger}, smaller={smaller}")

        old_max, old_min = max_val, min_val
        if larger > max_val:
            max_val = larger
        if smaller < min_val:
            min_val = smaller

        print(f"  Compare {larger} vs max({old_max}): max = {max_val}")
        print(f"  Compare {smaller} vs min({old_min}): min = {min_val}")
        print("  Comparisons: 3")

        total_comp += 3
        i += 2
        step += 1

    # Odd element
    if i == n - 1:
        print(f"\nStep {step}: Odd element ({arr[i]})")
        old_max, old_min = max_val, min_val
        if arr[i] > max_val:
            max_val = arr[i]
        if arr[i] < min_val:
            min_val = arr[i]
        print(f"  Compare {arr[i]} vs max({old_max}): max = {max_val}")
        print(f"  Compare {arr[i]} vs min({old_min}): min = {min_val}")
        print("  Comparisons: 2")
        total_comp += 2

    print(f"\n{'='*50}")
    print(f"RESULT: min = {min_val}, max = {max_val}")
    print(f"Total Comparisons: {total_comp}")
    print(f"Theoretical: {theoretical_comparison_count(n)['optimal']}")
    print(f"Naive would use: {theoretical_comparison_count(n)['naive']}")


if __name__ == "__main__":
    test_max_min()

    # Visualize examples
    print("\n" + "=" * 70)
    print("VISUALIZATION")
    print("=" * 70)

    visualize_pair_comparison([7, 2, 9, 1, 5, 8])
    visualize_pair_comparison([3, 5, 4, 1, 9])
