# Maximum and Minimum of Array Using Minimum Comparisons

## Problem Statement

Given an array of integers, find both the maximum and minimum elements using the minimum number of comparisons possible.

**Example 1:**
```
Input: arr = [3, 5, 4, 1, 9]
Output: min = 1, max = 9
```

**Example 2:**
```
Input: arr = [22, 14, 8, 17, 35, 3]
Output: min = 3, max = 35
```

---

## Comparison Analysis

### Naive Approach: 2(n-1) comparisons
- Traverse once for max: (n-1) comparisons
- Traverse once for min: (n-1) comparisons
- Total: 2(n-1) = 2n - 2 comparisons

### Tournament Method: 3n/2 - 2 comparisons
Using a divide and conquer or pair comparison approach, we can do better!

---

## Brute Force Approach

### Algorithm
Use two separate loops to find max and min.

### Code
```python
def find_max_min_brute(arr):
    max_val = arr[0]
    min_val = arr[0]
    
    # Find max: n-1 comparisons
    for i in range(1, len(arr)):
        if arr[i] > max_val:
            max_val = arr[i]
    
    # Find min: n-1 comparisons
    for i in range(1, len(arr)):
        if arr[i] < min_val:
            min_val = arr[i]
    
    return min_val, max_val
```

### Complexity
- **Time**: O(n)
- **Comparisons**: 2(n-1) = 2n - 2
- **Space**: O(1)

---

## Optimal Approach 1: Single Pass (Still 2n-2)

### Algorithm
Find max and min in a single traversal.

```python
def find_max_min_single_pass(arr):
    max_val = arr[0]
    min_val = arr[0]
    
    for i in range(1, len(arr)):
        if arr[i] > max_val:      # Comparison 1
            max_val = arr[i]
        elif arr[i] < min_val:    # Comparison 2
            min_val = arr[i]
    
    return min_val, max_val
```

**Note**: This still uses 2(n-1) comparisons in the worst case (when array is sorted in ascending or descending order).

---

## Optimal Approach 2: Pair Comparison (3n/2 - 2)

### Key Insight
Instead of comparing each element with both max and min (2 comparisons per element), compare elements in pairs first!

**Strategy**:
1. Compare elements in pairs with each other
2. Compare the larger with current max
3. Compare the smaller with current min

**Per pair**: 3 comparisons instead of 4!

### Visualization

```
Array: [3, 5, 4, 1, 9, 2]

Pair 1: Compare 3 vs 5
        5 is larger, 3 is smaller
        Compare 5 with max (max = 5)
        Compare 3 with min (min = 3)
        Comparisons: 3

Pair 2: Compare 4 vs 1
        4 is larger, 1 is smaller
        Compare 4 with max: 4 < 5 (max stays 5)
        Compare 1 with min: 1 < 3 (min = 1)
        Comparisons: 3

Pair 3: Compare 9 vs 2
        9 is larger, 2 is smaller
        Compare 9 with max: 9 > 5 (max = 9)
        Compare 2 with min: 2 > 1 (min stays 1)
        Comparisons: 3

Total: 9 comparisons for n=6
Formula: 3 * (n/2) = 3n/2 = 9

Without this optimization: 2(n-1) = 10 comparisons
```

### Algorithm

```python
def find_max_min_optimal(arr):
    n = len(arr)
    
    if n == 1:
        return arr[0], arr[0]
    
    # Initialize based on first two elements
    if arr[0] > arr[1]:
        max_val, min_val = arr[0], arr[1]
    else:
        max_val, min_val = arr[1], arr[0]
    # 1 comparison used
    
    # Process remaining elements in pairs
    i = 2
    while i < n - 1:
        # Compare pair elements with each other
        if arr[i] > arr[i + 1]:
            larger, smaller = arr[i], arr[i + 1]
        else:
            larger, smaller = arr[i + 1], arr[i]
        
        # Compare larger with max
        if larger > max_val:
            max_val = larger
        
        # Compare smaller with min
        if smaller < min_val:
            min_val = smaller
        
        i += 2
        # 3 comparisons per pair
    
    # Handle odd element if n is odd
    if i == n - 1:
        if arr[i] > max_val:
            max_val = arr[i]
        if arr[i] < min_val:
            min_val = arr[i]
    
    return min_val, max_val
```

---

## Optimal Approach 3: Divide and Conquer

### Algorithm
Recursively find max-min of left half and right half, then combine.

```python
def find_max_min_dc(arr, low, high):
    # Base case: single element
    if low == high:
        return arr[low], arr[low]
    
    # Two elements
    if high == low + 1:
        if arr[low] > arr[high]:
            return arr[high], arr[low]  # min, max
        else:
            return arr[low], arr[high]
    
    # Divide
    mid = (low + high) // 2
    min1, max1 = find_max_min_dc(arr, low, mid)
    min2, max2 = find_max_min_dc(arr, mid + 1, high)
    
    # Conquer
    return min(min1, min2), max(max1, max2)
```

### Recurrence Relation
```
T(n) = 2T(n/2) + 2
T(2) = 1
T(1) = 0

Solution: T(n) = 3n/2 - 2 comparisons
```

---

## Comparison Count Analysis

| n (elements) | Naive (2n-2) | Optimal (3n/2 - 2) | Savings |
|--------------|--------------|---------------------|---------|
| 4            | 6            | 4                   | 33%     |
| 6            | 10           | 7                   | 30%     |
| 8            | 14           | 10                  | 29%     |
| 100          | 198          | 148                 | 25%     |
| 1000         | 1998         | 1498                | 25%     |

**Asymptotic savings: ~25%**

---

## Dry Run: Pair Comparison

```
Array: [7, 2, 9, 1, 5, 8]
n = 6

Step 1: Initialize with first pair
        Compare 7 vs 2: 7 > 2
        max = 7, min = 2
        Comparisons: 1

Step 2: Pair (9, 1)
        Compare 9 vs 1: 9 > 1
        larger = 9, smaller = 1
        Compare 9 vs max(7): 9 > 7, max = 9
        Compare 1 vs min(2): 1 < 2, min = 1
        Comparisons: 3

Step 3: Pair (5, 8)
        Compare 5 vs 8: 5 < 8
        larger = 8, smaller = 5
        Compare 8 vs max(9): 8 < 9, max stays 9
        Compare 5 vs min(1): 5 > 1, min stays 1
        Comparisons: 3

Total Comparisons: 1 + 3 + 3 = 7
Formula: 3*(6/2) - 2 = 9 - 2 = 7 (matches!)

Result: min = 1, max = 9
```

---

## Time and Space Complexity

### Pair Comparison Approach
- **Time Complexity**: O(n)
- **Comparisons**: 3n/2 - 2 (optimal!)
- **Space Complexity**: O(1)

### Divide and Conquer
- **Time Complexity**: O(n)
- **Comparisons**: 3n/2 - 2
- **Space Complexity**: O(log n) for recursion stack

---

## Key Takeaways

1. **Comparison count matters**: In some applications (e.g., comparing complex objects), minimizing comparisons is crucial

2. **Pair comparison insight**: Compare elements in pairs first, then only compare larger with max and smaller with min

3. **25% improvement**: Optimal approach saves ~25% comparisons over naive method

4. **Lower bound**: 3n/2 - 2 is the theoretical minimum for finding both max and min

5. **Trade-offs**:
   - Pair method: Simple, O(1) space, but code is more complex
   - Divide and conquer: Elegant, but O(log n) space for recursion

6. **When does this matter?**
   - Comparing complex objects (strings, files)
   - Tournament/bracket scenarios
   - When comparison operation is expensive
