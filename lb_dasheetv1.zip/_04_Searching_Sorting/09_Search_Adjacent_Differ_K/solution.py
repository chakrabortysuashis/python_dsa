"""
Searching in Array Where Adjacent Elements Differ by At Most K
==============================================================

Problem: Given an array where adjacent elements differ by at most k,
find the index of target x efficiently.

Key Insight: If |arr[i] - x| = diff, then x is at least diff/k positions away.
We can jump by max(1, diff/k) positions!

Time: O(n) worst case, but typically much faster
Space: O(1)
"""

from typing import List


def search_adjacent_diff_k(arr: List[int], k: int, x: int) -> int:
    """
    Search for x in array where adjacent elements differ by at most k.

    Uses intelligent jumping based on difference from target.

    Args:
        arr: Array where |arr[i] - arr[i+1]| <= k
        k: Maximum difference between adjacent elements
        x: Target value to find

    Returns:
        Index of x if found, -1 otherwise
    """
    if not arr or k <= 0:
        return -1

    n = len(arr)
    i = 0

    while i < n:
        # Found target
        if arr[i] == x:
            return i

        # Calculate minimum distance to target
        diff = abs(arr[i] - x)

        # Jump by at least 1, at most diff/k
        # This is safe because we need at least diff/k steps to change value by diff
        jump = max(1, diff // k)
        i += jump

    return -1


def search_adjacent_diff_k_all(arr: List[int], k: int, x: int) -> List[int]:
    """
    Find ALL occurrences of x in the array.

    Returns:
        List of all indices where x is found
    """
    if not arr or k <= 0:
        return []

    n = len(arr)
    result = []
    i = 0

    while i < n:
        if arr[i] == x:
            result.append(i)
            i += 1  # Move to next position to find other occurrences
        else:
            diff = abs(arr[i] - x)
            i += max(1, diff // k)

    return result


def search_linear(arr: List[int], x: int) -> int:
    """
    Simple linear search for comparison.

    Time: O(n)
    """
    for i, val in enumerate(arr):
        if val == x:
            return i
    return -1


def search_adjacent_diff_k_trace(arr: List[int], k: int, x: int) -> tuple:
    """
    Search with tracing to show the jumps made.

    Returns:
        (index, list of (position, value, jump) tuples)
    """
    if not arr or k <= 0:
        return -1, []

    n = len(arr)
    i = 0
    trace = []

    while i < n:
        diff = abs(arr[i] - x)
        jump = max(1, diff // k) if arr[i] != x else 0

        trace.append({
            'index': i,
            'value': arr[i],
            'diff': diff,
            'jump': jump
        })

        if arr[i] == x:
            return i, trace

        i += jump

    return -1, trace


def verify_k_adjacent(arr: List[int], k: int) -> bool:
    """Verify that array satisfies the k-adjacent property."""
    for i in range(len(arr) - 1):
        if abs(arr[i] - arr[i + 1]) > k:
            return False
    return True


# ==================== TEST CASES ====================

def test_search():
    """Test the search algorithm."""

    print("=" * 70)
    print("SEARCH IN ARRAY WITH ADJACENT DIFFER BY K")
    print("=" * 70)

    test_cases = [
        # (arr, k, x, expected)
        ([4, 5, 6, 7, 6], 1, 6, [2, 4]),  # Multiple occurrences
        ([20, 40, 50, 70, 70, 60], 20, 60, [5]),
        ([2, 4, 5, 7, 7, 9], 2, 9, [5]),
        ([4, 5, 6, 7, 6, 5, 4, 3, 4, 5], 1, 3, [7]),
        ([10, 12, 14, 16, 18, 16, 14], 2, 18, [4]),
        ([1, 2, 3, 4, 5], 1, 6, []),  # Not found
        ([5], 1, 5, [0]),  # Single element
    ]

    for arr, k, x, expected_indices in test_cases:
        # Verify k-adjacent property
        is_valid = verify_k_adjacent(arr, k)

        # Search
        result = search_adjacent_diff_k(arr, k, x)
        all_results = search_adjacent_diff_k_all(arr, k, x)

        # Check result
        is_correct = (result in expected_indices) if expected_indices else (result == -1)
        all_correct = sorted(all_results) == sorted(expected_indices)

        print(f"\nArray: {arr}")
        print(f"k={k}, target={x}")
        print(f"Valid k-adjacent: {is_valid}")
        print(f"First occurrence: {result} ({'PASS' if is_correct else 'FAIL'})")
        print(f"All occurrences: {all_results} ({'PASS' if all_correct else 'FAIL'})")


def visualize_jumps(arr: List[int], k: int, x: int):
    """Visualize how the algorithm jumps through the array."""

    print(f"\n{'='*60}")
    print(f"JUMP VISUALIZATION: arr={arr}, k={k}, target={x}")
    print("=" * 60)

    result, trace = search_adjacent_diff_k_trace(arr, k, x)

    # Print array with indices
    print("\nArray visualization:")
    print("Index: ", end="")
    for i in range(len(arr)):
        print(f"{i:5}", end="")
    print()
    print("Value: ", end="")
    for val in arr:
        print(f"{val:5}", end="")
    print()

    # Print jumps
    print("\nJump sequence:")
    positions_visited = []

    for step in trace:
        i, val, diff, jump = step['index'], step['value'], step['diff'], step['jump']
        positions_visited.append(i)

        if val == x:
            print(f"  i={i}: arr[{i}]={val} == {x} -> FOUND!")
        else:
            print(f"  i={i}: arr[{i}]={val}, diff=|{val}-{x}|={diff}, jump=max(1,{diff}//{k})={jump}")
            print(f"         -> Jump to index {i + jump}")

    # Visual representation of jumps
    print("\nVisual jump path:")
    jump_line = [" "] * len(arr)
    for i, pos in enumerate(positions_visited):
        if pos < len(arr):
            jump_line[pos] = "^" if i < len(positions_visited) - 1 else "*"

    print("      ", end="")
    for i in range(len(arr)):
        print(f"{jump_line[i]:5}", end="")
    print()

    print(f"\nPositions visited: {positions_visited}")
    print(f"Total visits: {len(positions_visited)}")
    print(f"Linear search would visit: {result + 1 if result != -1 else len(arr)}")


def compare_efficiency():
    """Compare efficiency of smart jump vs linear search."""

    print("\n" + "=" * 60)
    print("EFFICIENCY COMPARISON")
    print("=" * 60)

    import random

    # Generate array with k-adjacent property
    def generate_k_adjacent(n, k, start=0):
        arr = [start]
        for _ in range(n - 1):
            change = random.randint(-k, k)
            arr.append(arr[-1] + change)
        return arr

    for n in [20, 50, 100]:
        for k in [1, 5, 10]:
            arr = generate_k_adjacent(n, k)
            target = arr[random.randint(0, n - 1)]

            # Count visits for smart jump
            _, trace = search_adjacent_diff_k_trace(arr, k, target)
            smart_visits = len(trace)

            # Linear would visit result+1 elements
            linear_idx = search_linear(arr, target)
            linear_visits = linear_idx + 1 if linear_idx != -1 else n

            savings = (1 - smart_visits / linear_visits) * 100 if linear_visits > 0 else 0

            print(f"n={n:3}, k={k:2}: Smart={smart_visits:3} visits, Linear={linear_visits:3} visits, Savings={savings:.1f}%")


if __name__ == "__main__":
    test_search()

    # Visualize specific examples
    visualize_jumps([4, 5, 6, 7, 6, 5, 4, 3, 4, 5], 1, 3)
    visualize_jumps([20, 40, 50, 70, 70, 60], 20, 60)
    visualize_jumps([2, 4, 5, 7, 7, 9], 2, 9)

    # Compare efficiency
    compare_efficiency()
