# Searching in Array Where Adjacent Elements Differ by At Most K

## Problem Statement

Given an array where the difference between adjacent elements is at most k, and a target value x, find the index of x in the array. If x is not present, return -1.

**Example 1:**
```
Input: arr = [4, 5, 6, 7, 6], k = 1, x = 6
Output: 2 (or 4)
```

**Example 2:**
```
Input: arr = [20, 40, 50, 70, 70, 60], k = 20, x = 60
Output: 5
```

---

## Key Insight: Smart Jump

Since adjacent elements differ by at most k, we can make intelligent jumps!

**Core Idea**: 
- If `|arr[i] - x| = diff`, then x can be at most `diff/k` positions away
- Jump by `max(1, diff/k)` positions

```
arr = [2, 4, 5, 7, 7, 9], k = 2, x = 9

At index 0: arr[0] = 2
            diff = |2 - 9| = 7
            Can jump: 7/2 = 3 positions
            
At index 3: arr[3] = 7
            diff = |7 - 9| = 2
            Can jump: 2/2 = 1 position
            
At index 4: arr[4] = 7
            diff = |7 - 9| = 2
            Can jump: 1 position
            
At index 5: arr[5] = 9 = x
            FOUND!
```

---

## Why Does This Work?

Since adjacent elements differ by at most k:
- To go from value A to value B, we need at least `ceil(|A-B|/k)` steps
- So if current value differs from target by `diff`, target is at least `diff/k` positions away
- We can safely jump that many positions!

```
Example: arr = [10, 12, 14, 16, 18], k = 2, target = 18

At index 0, value = 10:
  diff = |10 - 18| = 8
  Min steps to reach 18: 8/2 = 4
  We can jump 4 positions safely!
  
  Why? Because even if we always increase by k=2:
  10 -> 12 -> 14 -> 16 -> 18
  We need exactly 4 steps.
```

---

## Algorithm

```python
def search_with_diff_k(arr, k, x):
    n = len(arr)
    i = 0
    
    while i < n:
        # Found target
        if arr[i] == x:
            return i
        
        # Calculate jump distance
        diff = abs(arr[i] - x)
        jump = max(1, diff // k)
        
        i += jump
    
    return -1  # Not found
```

---

## Dry Run

```
arr = [4, 5, 6, 7, 6, 5, 4, 3, 4, 5], k = 1, x = 3

i=0: arr[0]=4, diff=|4-3|=1, jump=max(1,1/1)=1
     i = 0 + 1 = 1

i=1: arr[1]=5, diff=|5-3|=2, jump=max(1,2/1)=2
     i = 1 + 2 = 3

i=3: arr[3]=7, diff=|7-3|=4, jump=max(1,4/1)=4
     i = 3 + 4 = 7

i=7: arr[7]=3, diff=0
     FOUND! Return 7
```

---

## Visual Representation

```
Array: [20, 40, 50, 70, 70, 60]
k = 20
target = 60

Index:  0    1    2    3    4    5
Value: 20   40   50   70   70   60

Start at i=0:
  arr[0] = 20
  diff = |20 - 60| = 40
  jump = 40/20 = 2
  
  [20]--jump 2-->[50]
   ^

At i=2:
  arr[2] = 50
  diff = |50 - 60| = 10
  jump = max(1, 10/20) = 1
  
         [50]--jump 1-->[70]
          ^

At i=3:
  arr[3] = 70
  diff = |70 - 60| = 10
  jump = 1
  
              [70]--jump 1-->[70]
               ^

At i=4:
  arr[4] = 70
  diff = 10
  jump = 1
  
                   [70]--jump 1-->[60]
                    ^

At i=5:
  arr[5] = 60 == target
  FOUND at index 5!
```

---

## Time Complexity Analysis

**Worst Case**: O(n)
- When target doesn't exist and we jump by 1 each time

**Best Case**: O(1)
- When target is at first position

**Average Case**: Better than O(n)
- We often skip multiple elements
- For uniformly distributed values, expected O(n/k)

---

## Finding All Occurrences

```python
def find_all_occurrences(arr, k, x):
    n = len(arr)
    result = []
    i = 0
    
    while i < n:
        if arr[i] == x:
            result.append(i)
            i += 1  # Move to next position
        else:
            diff = abs(arr[i] - x)
            i += max(1, diff // k)
    
    return result
```

---

## Code Implementation

```python
def search_adjacent_diff_k(arr, k, x):
    """
    Search in array where adjacent elements differ by at most k.
    
    Key insight: If |arr[i] - x| = diff, then x is at least diff/k positions away.
    
    Time: O(n) worst case, but typically much faster
    Space: O(1)
    """
    n = len(arr)
    i = 0
    
    while i < n:
        # Check if found
        if arr[i] == x:
            return i
        
        # Calculate minimum distance to target
        diff = abs(arr[i] - x)
        
        # Jump by at least 1, at most diff/k
        jump = max(1, diff // k)
        i += jump
    
    return -1
```

---

## Key Takeaways

1. **Constraint as advantage**: The "adjacent differ by k" constraint allows smart jumping

2. **Lower bound on distance**: `|arr[i] - x| / k` gives minimum positions away

3. **Jump optimization**: Instead of checking every element, jump intelligently

4. **Still O(n) worst case**: But practically much faster for most inputs

5. **Similar problems**:
   - Jump search in sorted array
   - Searching with bounded differences
