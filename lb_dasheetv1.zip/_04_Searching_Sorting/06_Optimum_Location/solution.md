# Optimum Location to Minimize Total Distance

## Problem Statement

Given N points on a 2D plane, find a point on the X-axis such that the sum of distances from all points to this chosen point is minimized.

**Example:**
```
Input: points = [(1, 1), (2, 3), (4, 2)]
Output: x = 2.28 (approximately)
The optimal point on X-axis minimizes total distance to all points.
```

---

## Binary Search Intuition

The sum of distances function is **unimodal** (convex) - it has a single minimum.

**Key Insight**: When dealing with a unimodal function, we can use **Ternary Search** or binary search on the derivative to find the minimum!

```
Total Distance
     |
     |   *
     |  * *
     | *   *
     |*     *
     *       *
    *         *
   *           *------ function is convex
   |--------------|
   x_min         x_max
         ^
      optimum
```

---

## Mathematical Background

### Distance Formula
Distance from point (px, py) to a point (x, 0) on X-axis:
```
d = sqrt((x - px)^2 + py^2)
```

### Total Distance Function
```
f(x) = sum of sqrt((x - px_i)^2 + py_i^2) for all points
```

This function is convex, so it has a unique minimum!

---

## Approach 1: Ternary Search

### Algorithm
1. Define search range [left, right] covering all x-coordinates
2. Divide into three parts using mid1 and mid2
3. If f(mid1) < f(mid2): answer is in [left, mid2]
4. If f(mid1) > f(mid2): answer is in [mid1, right]
5. Continue until range is small enough

### Visualization

```
Search range: [0, 10]

Iteration 1:
    [0----------------10]
       mid1=3.33  mid2=6.67
    
    f(3.33) = 8.5
    f(6.67) = 9.2
    
    f(mid1) < f(mid2), so search [0, 6.67]

Iteration 2:
    [0--------6.67]
       mid1=2.22  mid2=4.45
    
    f(2.22) = 7.8
    f(4.45) = 8.1
    
    f(mid1) < f(mid2), so search [0, 4.45]

... continue until precision is met
```

### Code

```python
import math

def calculate_distance(x, points):
    """Calculate total distance from x on X-axis to all points."""
    total = 0
    for px, py in points:
        total += math.sqrt((x - px) ** 2 + py ** 2)
    return total

def optimum_location_ternary(points, precision=1e-9):
    """Find x on X-axis that minimizes total distance."""
    # Define search range
    left = min(p[0] for p in points) - 1
    right = max(p[0] for p in points) + 1
    
    while right - left > precision:
        mid1 = left + (right - left) / 3
        mid2 = right - (right - left) / 3
        
        if calculate_distance(mid1, points) < calculate_distance(mid2, points):
            right = mid2
        else:
            left = mid1
    
    return (left + right) / 2
```

---

## Approach 2: Binary Search on Derivative

### Mathematical Insight
The derivative of total distance with respect to x:
```
f'(x) = sum of (x - px_i) / sqrt((x - px_i)^2 + py_i^2)
```

At the minimum, f'(x) = 0.

We can binary search for where the derivative equals zero!

### Algorithm
1. Find range where derivative changes sign
2. Binary search for the zero crossing
3. That's our optimal point

### Code

```python
def derivative(x, points):
    """Calculate derivative of total distance at x."""
    result = 0
    for px, py in points:
        dist = math.sqrt((x - px) ** 2 + py ** 2)
        if dist > 1e-10:  # Avoid division by zero
            result += (x - px) / dist
    return result

def optimum_location_derivative(points, precision=1e-9):
    """Binary search for where derivative equals zero."""
    left = min(p[0] for p in points) - 100
    right = max(p[0] for p in points) + 100
    
    # Binary search for derivative = 0
    while right - left > precision:
        mid = (left + right) / 2
        
        if derivative(mid, points) < 0:
            # Derivative negative means we're left of minimum
            left = mid
        else:
            # Derivative positive or zero means we're at or right of minimum
            right = mid
    
    return (left + right) / 2
```

---

## Dry Run

```
Points: [(1, 1), (3, 2), (5, 1)]

Step 1: Search range [0, 6]
        mid1 = 2, mid2 = 4
        f(2) = sqrt(1+1) + sqrt(1+4) + sqrt(9+1) = 1.41 + 2.24 + 3.16 = 6.81
        f(4) = sqrt(9+1) + sqrt(1+4) + sqrt(1+1) = 3.16 + 2.24 + 1.41 = 6.81
        
        Equal! Choose either direction. Let's go [0, 4]

Step 2: Search range [0, 4]
        mid1 = 1.33, mid2 = 2.67
        f(1.33) = 1.05 + 2.49 + 3.82 = 7.36
        f(2.67) = 1.94 + 2.05 + 2.56 = 6.55
        
        f(mid1) > f(mid2), search [1.33, 4]

Step 3: Continue...

Final: x ≈ 3.0
Total distance at x=3: sqrt(4+1) + sqrt(0+4) + sqrt(4+1) = 2.24 + 2 + 2.24 = 6.48
```

---

## Time and Space Complexity

### Ternary Search
- **Time Complexity**: O(n * log(range/precision))
  - Each iteration: O(n) to calculate distance
  - Number of iterations: O(log(range/precision))

- **Space Complexity**: O(1)

### Comparison
| Approach | Time | Space |
|----------|------|-------|
| Brute Force | O(n * range/step) | O(1) |
| Ternary Search | O(n * log(range/eps)) | O(1) |
| Gradient Descent | O(n * iterations) | O(1) |

---

## Variants

### 1. Finding Point on Y-axis
Same approach, just optimize y instead of x.

### 2. Finding Point Anywhere on Plane (Geometric Median)
More complex - requires Weiszfeld's algorithm or gradient descent.

### 3. Minimizing Sum of Squared Distances
This has a closed-form solution: the centroid (average of all points).

---

## Key Takeaways

1. **Unimodal functions**: Can be optimized with ternary search
2. **Convexity**: Sum of distances is convex, guaranteeing single minimum
3. **Ternary vs Binary**: Use ternary search on function value, binary search on derivative
4. **Precision matters**: Set appropriate precision based on problem requirements
5. **Pattern recognition**: Many optimization problems have convex objective functions
