"""
Optimum Location to Minimize Total Distance
============================================

Problem: Given N points on a 2D plane, find a point on the X-axis
such that the sum of distances from all points to this point is minimized.

The sum of distances function is convex (unimodal), so we can use
Ternary Search to find the minimum.

Time Complexity: O(n * log(range/precision))
Space Complexity: O(1)
"""

import math
from typing import List, Tuple


def calculate_total_distance(x: float, points: List[Tuple[float, float]]) -> float:
    """
    Calculate total distance from a point (x, 0) on X-axis to all given points.

    Distance from (x, 0) to (px, py) = sqrt((x-px)^2 + py^2)
    """
    total = 0.0
    for px, py in points:
        total += math.sqrt((x - px) ** 2 + py ** 2)
    return total


def optimum_location_ternary(points: List[Tuple[float, float]],
                             precision: float = 1e-9) -> float:
    """
    Find the x-coordinate on X-axis that minimizes total distance using Ternary Search.

    Ternary search works because the total distance function is unimodal (convex).

    Args:
        points: List of (x, y) coordinates
        precision: Required precision for the answer

    Returns:
        x-coordinate that minimizes total distance
    """
    if not points:
        return 0.0

    # Define search range
    left = min(p[0] for p in points) - 1
    right = max(p[0] for p in points) + 1

    while right - left > precision:
        # Divide into three parts
        mid1 = left + (right - left) / 3
        mid2 = right - (right - left) / 3

        # Calculate distances at mid points
        dist1 = calculate_total_distance(mid1, points)
        dist2 = calculate_total_distance(mid2, points)

        # Narrow search range
        if dist1 < dist2:
            right = mid2  # Minimum is in left 2/3
        else:
            left = mid1   # Minimum is in right 2/3

    return (left + right) / 2


def derivative(x: float, points: List[Tuple[float, float]]) -> float:
    """
    Calculate derivative of total distance function at x.

    f(x) = sum of sqrt((x - px_i)^2 + py_i^2)
    f'(x) = sum of (x - px_i) / sqrt((x - px_i)^2 + py_i^2)
    """
    result = 0.0
    for px, py in points:
        dist = math.sqrt((x - px) ** 2 + py ** 2)
        if dist > 1e-10:  # Avoid division by zero
            result += (x - px) / dist
    return result


def optimum_location_binary_derivative(points: List[Tuple[float, float]],
                                       precision: float = 1e-9) -> float:
    """
    Find optimal x using binary search on the derivative.

    At the minimum, the derivative equals zero.
    """
    if not points:
        return 0.0

    # Define search range
    left = min(p[0] for p in points) - 100
    right = max(p[0] for p in points) + 100

    # Binary search for where derivative = 0
    while right - left > precision:
        mid = (left + right) / 2

        if derivative(mid, points) < 0:
            # Derivative negative: we're left of minimum
            left = mid
        else:
            # Derivative positive: we're right of minimum
            right = mid

    return (left + right) / 2


def optimum_location_brute(points: List[Tuple[float, float]],
                           step: float = 0.01) -> float:
    """
    Brute force approach: Try all x values with small step.

    Time Complexity: O(n * range/step)
    """
    if not points:
        return 0.0

    left = min(p[0] for p in points) - 1
    right = max(p[0] for p in points) + 1

    best_x = left
    best_dist = float('inf')

    x = left
    while x <= right:
        dist = calculate_total_distance(x, points)
        if dist < best_dist:
            best_dist = dist
            best_x = x
        x += step

    return best_x


def optimum_location_gradient_descent(points: List[Tuple[float, float]],
                                      learning_rate: float = 0.1,
                                      iterations: int = 1000) -> float:
    """
    Find optimal x using gradient descent.

    Start from a point and iteratively move in direction of steepest descent.
    """
    if not points:
        return 0.0

    # Start from average x
    x = sum(p[0] for p in points) / len(points)

    for _ in range(iterations):
        grad = derivative(x, points)
        x -= learning_rate * grad

        # Adaptive learning rate
        if abs(grad) < 1e-10:
            break

    return x


# ==================== TEST CASES ====================

def test_optimum_location():
    """Comprehensive test cases."""

    print("=" * 70)
    print("OPTIMUM LOCATION TO MINIMIZE TOTAL DISTANCE")
    print("=" * 70)

    test_cases = [
        # (points, description)
        ([(1, 1), (2, 3), (4, 2)], "Three points"),
        ([(0, 1), (0, 2), (0, 3)], "Vertical line (x=0)"),
        ([(1, 1), (3, 1), (5, 1)], "Same y-coordinate"),
        ([(0, 0), (2, 0), (4, 0)], "Points on X-axis"),
        ([(1, 2), (1, 3)], "Same x-coordinate"),
        ([(0, 1), (1, 0), (2, 1)], "Triangle"),
    ]

    for points, desc in test_cases:
        print(f"\n{desc}: {points}")

        # Run all methods
        x_ternary = optimum_location_ternary(points)
        x_derivative = optimum_location_binary_derivative(points)
        x_gradient = optimum_location_gradient_descent(points)

        dist_ternary = calculate_total_distance(x_ternary, points)
        dist_derivative = calculate_total_distance(x_derivative, points)
        dist_gradient = calculate_total_distance(x_gradient, points)

        print(f"  Ternary Search:    x = {x_ternary:.4f}, distance = {dist_ternary:.4f}")
        print(f"  Binary Derivative: x = {x_derivative:.4f}, distance = {dist_derivative:.4f}")
        print(f"  Gradient Descent:  x = {x_gradient:.4f}, distance = {dist_gradient:.4f}")

        # Verify they're close
        all_close = abs(x_ternary - x_derivative) < 0.01 and abs(x_ternary - x_gradient) < 0.1
        print(f"  All methods agree: {all_close}")

    print("\n" + "=" * 70)


def visualize_function(points: List[Tuple[float, float]]):
    """Visualize the distance function to show its convex nature."""

    print(f"\nDistance Function Visualization for points: {points}")
    print("=" * 60)

    left = min(p[0] for p in points) - 2
    right = max(p[0] for p in points) + 2

    # Sample the function
    samples = 40
    x_values = [left + i * (right - left) / samples for i in range(samples + 1)]
    distances = [calculate_total_distance(x, points) for x in x_values]

    min_dist = min(distances)
    max_dist = max(distances)
    range_dist = max_dist - min_dist if max_dist > min_dist else 1

    # Find optimal
    optimal_x = optimum_location_ternary(points)
    optimal_dist = calculate_total_distance(optimal_x, points)

    # ASCII visualization
    height = 15

    print(f"\nTotal Distance vs X position:")
    print(f"Optimal: x = {optimal_x:.2f}, distance = {optimal_dist:.2f}\n")

    for h in range(height, -1, -1):
        line = f"{min_dist + h * range_dist / height:6.1f} |"
        for x, d in zip(x_values, distances):
            normalized = (d - min_dist) / range_dist * height
            if abs(normalized - h) < 0.5:
                if abs(x - optimal_x) < (right - left) / samples:
                    line += "*"  # Mark optimal
                else:
                    line += "o"
            else:
                line += " "
        print(line)

    print("       +" + "-" * (samples + 1))
    print(f"        {left:.1f}" + " " * (samples // 2 - 3) + f"x" + " " * (samples // 2 - 1) + f"{right:.1f}")
    print(f"\n* = optimal point at x = {optimal_x:.2f}")


def verify_convexity(points: List[Tuple[float, float]], num_samples: int = 100):
    """Verify that the distance function is convex."""

    left = min(p[0] for p in points) - 2
    right = max(p[0] for p in points) + 2

    x_values = [left + i * (right - left) / num_samples for i in range(num_samples + 1)]
    derivatives = [derivative(x, points) for x in x_values]

    # Check if derivative is monotonically increasing (convexity)
    is_convex = all(derivatives[i] <= derivatives[i + 1] + 1e-6
                    for i in range(len(derivatives) - 1))

    print(f"\nConvexity check for {points}:")
    print(f"  Function is convex: {is_convex}")

    # Find zero crossing (minimum)
    for i in range(len(derivatives) - 1):
        if derivatives[i] <= 0 <= derivatives[i + 1]:
            print(f"  Derivative zero crossing near x = {x_values[i]:.2f}")
            break

    return is_convex


if __name__ == "__main__":
    test_optimum_location()

    # Visualize
    print("\n" + "=" * 70)
    print("VISUALIZATION")
    print("=" * 70)

    visualize_function([(1, 1), (3, 2), (5, 1)])
    verify_convexity([(1, 1), (3, 2), (5, 1)])

    visualize_function([(0, 1), (2, 2), (4, 1)])
