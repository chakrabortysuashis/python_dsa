# Kth Smallest Number Again

## Problem Statement

Given `N` ranges `[L, R]`, find the **Kth smallest** integer that lies in at least one of the ranges.

**Example 1:**
```
Input: ranges = [(1, 5), (10, 14)], K = 7
Output: 12
Explanation: 
  Union of ranges: {1, 2, 3, 4, 5, 10, 11, 12, 13, 14}
  Sorted: [1, 2, 3, 4, 5, 10, 11, 12, 13, 14]
  K=7 means 7th smallest = 12
```

**Example 2:**
```
Input: ranges = [(1, 5), (3, 8)], K = 4
Output: 4
Explanation:
  Overlapping ranges merge to [1, 8]
  Union: {1, 2, 3, 4, 5, 6, 7, 8}
  4th smallest = 4
```

---

## Approach Intuition

### Key Insight
1. **Merge overlapping ranges** first to avoid counting duplicates
2. After merging, ranges are **disjoint** and sorted
3. Count elements in each range until we reach K

### Why Merge?
```
Ranges: [(1, 5), (3, 8), (10, 12)]

Without merging: Would count 3, 4, 5 twice!

After merging: [(1, 8), (10, 12)]
Now each element is in exactly one range.
```

---

## Algorithm

### Step 1: Merge Overlapping Ranges
```python
def merge_ranges(ranges):
    if not ranges:
        return []
    
    # Sort by start point
    ranges.sort()
    merged = [ranges[0]]
    
    for start, end in ranges[1:]:
        if start <= merged[-1][1] + 1:  # Overlapping or adjacent
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))
    
    return merged
```

### Step 2: Find Kth Element
```python
def find_kth(merged_ranges, k):
    count = 0
    
    for start, end in merged_ranges:
        range_size = end - start + 1
        
        if count + range_size >= k:
            # Kth element is in this range
            return start + (k - count - 1)
        
        count += range_size
    
    return -1  # K is larger than total elements
```

---

## Visualization

```
Ranges: [(1, 5), (10, 14), (3, 7)]
K = 9

=== Step 1: Merge Ranges ===

Sort by start: [(1, 5), (3, 7), (10, 14)]

Merge process:
  Start with [(1, 5)]
  
  (3, 7): 3 <= 5+1? Yes, overlapping!
    Merge: (1, 5) + (3, 7) = (1, max(5,7)) = (1, 7)
    Result: [(1, 7)]
  
  (10, 14): 10 <= 7+1? No, disjoint
    Append: [(1, 7), (10, 14)]

Merged: [(1, 7), (10, 14)]

=== Step 2: Find Kth Element ===

K = 9

Range (1, 7): size = 7
  count = 0, count + 7 = 7 < 9
  Not in this range
  count = 7

Range (10, 14): size = 5
  count = 7, count + 5 = 12 >= 9
  Kth element IS in this range!
  Position within range = K - count - 1 = 9 - 7 - 1 = 1
  Answer = 10 + 1 = 11

Result: 11
```

### Search Space Reduction

```
Total elements across merged ranges: 7 + 5 = 12

Without optimization: Enumerate all 12 elements
With counting: Check only 2 ranges

For ranges with millions of elements:
  Enumeration: O(total elements)
  Counting: O(number of ranges)
```

---

## Dry Run with Different Example

```
Ranges: [(1, 3), (5, 7), (6, 9), (12, 15)]
K = 10

Sort: [(1, 3), (5, 7), (6, 9), (12, 15)]

Merge:
  [(1, 3)] 
  (5, 7): 5 > 3+1, append -> [(1, 3), (5, 7)]
  (6, 9): 6 <= 7+1, merge -> [(1, 3), (5, 9)]
  (12, 15): 12 > 9+1, append -> [(1, 3), (5, 9), (12, 15)]

Find K=10:
  (1, 3): size=3, count=3 < 10
  (5, 9): size=5, count=3+5=8 < 10
  (12, 15): size=4, count=8+4=12 >= 10
    Position = 10 - 8 - 1 = 1
    Answer = 12 + 1 = 13

Result: 13
```

---

## Code Implementation

```python
def kth_smallest_in_ranges(ranges, k):
    """
    Find Kth smallest integer in union of ranges.
    
    Steps:
    1. Merge overlapping/adjacent ranges
    2. Count through merged ranges to find Kth element
    """
    if not ranges:
        return -1
    
    # Sort ranges by start point
    ranges = sorted(ranges)
    
    # Merge overlapping ranges
    merged = [list(ranges[0])]
    
    for start, end in ranges[1:]:
        if start <= merged[-1][1] + 1:
            # Overlapping or adjacent - merge
            merged[-1][1] = max(merged[-1][1], end)
        else:
            # Disjoint - add new range
            merged.append([start, end])
    
    # Find Kth element by counting
    count = 0
    
    for start, end in merged:
        range_size = end - start + 1
        
        if count + range_size >= k:
            # Kth element is in this range
            return start + (k - count - 1)
        
        count += range_size
    
    # K exceeds total elements
    return -1
```

---

## Time and Space Complexity

### Time Complexity
- **Sorting**: O(N log N) where N = number of ranges
- **Merging**: O(N)
- **Finding Kth**: O(N)
- **Total**: O(N log N)

### Space Complexity
- **O(N)** for merged ranges

### Comparison
| Approach | Time | Space |
|----------|------|-------|
| Enumerate all | O(N log N + total elements) | O(total elements) |
| Counting | O(N log N) | O(N) |

---

## Key Takeaways

1. **Merge intervals first**: Critical for handling overlaps correctly

2. **Sort before merging**: Sort by start point to process in order

3. **Adjacent ranges**: `[1,5]` and `[6,10]` should merge to `[1,10]` (check `start <= prev_end + 1`)

4. **Count don't enumerate**: For large ranges, counting is much faster

5. **Position formula**: `answer = range_start + (k - count_before - 1)`

6. **Edge cases**:
   - K larger than total elements
   - Single range
   - All ranges overlapping
   - Ranges with single element

7. **Related problems**:
   - Merge Intervals (LeetCode 56)
   - Insert Interval
   - Meeting Rooms
