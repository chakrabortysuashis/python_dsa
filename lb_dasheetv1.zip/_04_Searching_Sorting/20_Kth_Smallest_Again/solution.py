"""
Kth Smallest Number Again
=========================

Problem: Given N ranges [L, R], find the Kth smallest integer
that lies in at least one of the ranges.

Solution:
1. Merge overlapping/adjacent ranges
2. Count through merged ranges to find Kth element

Time Complexity: O(N log N)
Space Complexity: O(N)
"""


def merge_ranges(ranges: list) -> list:
    """
    Merge overlapping or adjacent ranges.
    Returns list of disjoint, sorted ranges.
    """
    if not ranges:
        return []

    # Sort by start point
    ranges = sorted(ranges)

    merged = [list(ranges[0])]

    for start, end in ranges[1:]:
        # Check if overlapping or adjacent with last merged range
        if start <= merged[-1][1] + 1:
            # Merge: extend the end if needed
            merged[-1][1] = max(merged[-1][1], end)
        else:
            # Disjoint: add as new range
            merged.append([start, end])

    return merged


def kth_smallest(ranges: list, k: int) -> int:
    """
    Find Kth smallest integer in union of ranges.

    Args:
        ranges: List of (start, end) tuples
        k: 1-indexed position

    Returns:
        Kth smallest integer, or -1 if K exceeds total elements
    """
    if not ranges or k <= 0:
        return -1

    # Merge overlapping ranges
    merged = merge_ranges(ranges)

    # Count through ranges to find Kth element
    count = 0

    for start, end in merged:
        range_size = end - start + 1

        if count + range_size >= k:
            # Kth element is in this range
            # Position within range = k - count - 1 (0-indexed)
            return start + (k - count - 1)

        count += range_size

    # K exceeds total elements
    return -1


def kth_smallest_brute(ranges: list, k: int) -> int:
    """
    Brute force: Generate all elements and sort.
    Time: O(total elements * log(total elements))
    """
    if not ranges or k <= 0:
        return -1

    elements = set()
    for start, end in ranges:
        for x in range(start, end + 1):
            elements.add(x)

    if k > len(elements):
        return -1

    sorted_elements = sorted(elements)
    return sorted_elements[k - 1]


def total_elements(ranges: list) -> int:
    """Count total unique elements across all ranges."""
    merged = merge_ranges(ranges)
    return sum(end - start + 1 for start, end in merged)


def list_all_elements(ranges: list) -> list:
    """List all elements (for verification)."""
    merged = merge_ranges(ranges)
    result = []
    for start, end in merged:
        result.extend(range(start, end + 1))
    return result


# ==================== TEST CASES ====================

def test_kth_smallest():
    """Comprehensive test cases."""

    print("=" * 60)
    print("KTH SMALLEST NUMBER AGAIN")
    print("=" * 60)

    test_cases = [
        # (ranges, k, expected)
        ([(1, 5), (10, 14)], 7, 12),
        ([(1, 5), (3, 8)], 4, 4),
        ([(1, 3), (5, 7), (6, 9), (12, 15)], 10, 13),
        ([(1, 5)], 3, 3),
        ([(1, 5)], 6, -1),  # K too large
        ([(1, 1), (2, 2), (3, 3)], 2, 2),
        ([(5, 10), (1, 3)], 5, 6),  # Unsorted input
        ([(1, 100)], 50, 50),
        ([(1, 5), (6, 10)], 7, 7),  # Adjacent ranges
    ]

    all_passed = True

    for i, (ranges, k, expected) in enumerate(test_cases, 1):
        result = kth_smallest(ranges, k)
        brute = kth_smallest_brute(ranges, k)

        status = "PASS" if result == expected and brute == expected else "FAIL"
        if result != expected:
            all_passed = False

        print(f"\nTest {i}: {status}")
        print(f"  Ranges: {ranges}")
        print(f"  K: {k}")
        print(f"  Expected: {expected}")
        print(f"  Optimized: {result}, Brute: {brute}")

    # Show merge process for some examples
    print("\n" + "-" * 60)
    print("Merge Process Examples:")
    print("-" * 60)

    examples = [
        [(1, 5), (3, 8), (10, 14)],
        [(1, 3), (5, 7), (6, 9)],
        [(1, 5), (6, 10), (15, 20)],
    ]

    for ranges in examples:
        merged = merge_ranges(ranges)
        total = total_elements(ranges)
        print(f"\n  Input: {ranges}")
        print(f"  Merged: {merged}")
        print(f"  Total elements: {total}")

    print("\n" + "=" * 60)
    print(f"All tests passed: {all_passed}")
    print("=" * 60)


def visualize_algorithm(ranges: list, k: int):
    """Visualize the merge and find process."""

    print(f"\nVisualizing Kth Smallest")
    print(f"Ranges: {ranges}")
    print(f"K: {k}")
    print("=" * 60)

    # Step 1: Sort
    sorted_ranges = sorted(ranges)
    print(f"\nStep 1: Sort by start")
    print(f"  Sorted: {sorted_ranges}")

    # Step 2: Merge
    print(f"\nStep 2: Merge overlapping ranges")
    merged = [list(sorted_ranges[0])]
    print(f"  Start with: {merged}")

    for start, end in sorted_ranges[1:]:
        if start <= merged[-1][1] + 1:
            old = merged[-1].copy()
            merged[-1][1] = max(merged[-1][1], end)
            print(f"  ({start}, {end}): overlaps with {old} -> merge to {merged[-1]}")
        else:
            merged.append([start, end])
            print(f"  ({start}, {end}): disjoint -> append")

    print(f"  Merged: {merged}")

    # Step 3: Find Kth
    print(f"\nStep 3: Find {k}th element")
    count = 0

    for start, end in merged:
        size = end - start + 1
        print(f"\n  Range ({start}, {end}): size = {size}")
        print(f"    count = {count}, count + size = {count + size}")

        if count + size >= k:
            pos = k - count - 1
            answer = start + pos
            print(f"    K={k} is in this range!")
            print(f"    Position within range = {k} - {count} - 1 = {pos}")
            print(f"    Answer = {start} + {pos} = {answer}")
            print(f"\n  Result: {answer}")
            return

        count += size
        print(f"    K={k} not here, continue...")

    print(f"\n  K={k} exceeds total elements ({count})")
    print(f"  Result: -1")


if __name__ == "__main__":
    test_kth_smallest()

    # Visualize
    visualize_algorithm([(1, 5), (10, 14), (3, 7)], 9)
    visualize_algorithm([(1, 5), (3, 8)], 4)
