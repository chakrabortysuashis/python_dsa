# Rasta and Kheshtak (Maximum XOR Pair)

## Problem Statement

Given an array of `N` integers, find the **maximum XOR** of any two elements in the array.

**Example 1:**
```
Input: arr = [25, 10, 2, 8, 5, 3]
Output: 28
Explanation: Maximum XOR is 25 XOR 5 = 28
  25 = 11001
   5 = 00101
XOR  = 11100 = 28
```

**Example 2:**
```
Input: arr = [1, 2, 3, 4, 5]
Output: 7
Explanation: 3 XOR 4 = 7
  3 = 011
  4 = 100
XOR = 111 = 7
```

---

## Approach Intuition

### XOR Properties
- `a XOR a = 0`
- `a XOR 0 = a`
- XOR is bitwise: each bit position is independent
- To maximize XOR, we want **different bits** in higher positions

### Key Insight
To maximize XOR, for each bit position from MSB to LSB:
- Try to make the result bit = 1
- This happens when the two numbers have different bits at that position

---

## Brute Force Approach

### Algorithm
Try all pairs and find maximum XOR.

### Code
```python
def max_xor_brute(arr):
    n = len(arr)
    max_xor = 0
    
    for i in range(n):
        for j in range(i + 1, n):
            max_xor = max(max_xor, arr[i] ^ arr[j])
    
    return max_xor
```

### Complexity
- **Time**: O(n^2)
- **Space**: O(1)

---

## Optimal Approach: Trie-based Solution

### Algorithm
1. Build a **binary trie** of all numbers (MSB to LSB)
2. For each number, traverse trie choosing **opposite bits** when possible
3. This greedy approach maximizes XOR

### Trie Structure

```
For array [3, 10, 5, 25, 2]:
Binary (5 bits): 3=00011, 10=01010, 5=00101, 25=11001, 2=00010

Trie:
                    root
                   /    \
                  0      1
                 / \      \
                0   1      1
               /   /        \
              0   0          0
             / \   \          \
            1   1   1          0
           /     \   \          \
          0       0   0          1
          |       |   |          |
         (2)    (3) (10)       (25)
          |
         (5) branching from 00101

Note: Actual trie merges common prefixes
```

### Finding Max XOR

```
For number 3 (00011):

Traverse trie, at each bit, try to go OPPOSITE direction:
  Bit 4 (MSB): 3 has 0, try to go 1 -> YES! (25's path)
  Bit 3: 3 has 0, try to go 1 -> YES!
  Bit 2: 3 has 0, try to go 0 -> must take 0
  Bit 1: 3 has 1, try to go 0 -> YES!
  Bit 0: 3 has 1, try to go 0 -> must take 1

Path taken leads to 25 (11001)
XOR = 00011 XOR 11001 = 11010 = 26

Actually, 3 XOR 25 = 26, but max is 25 XOR 5 = 28!
Let's check for 25:
  25 = 11001
  Try opposite: want 00110 area
  Best match: 5 = 00101
  25 XOR 5 = 11100 = 28
```

---

## Bit Manipulation Approach

### Algorithm
1. Build answer bit by bit, from MSB to LSB
2. At each bit, check if setting it to 1 is achievable
3. Use property: if `a XOR b = c`, then `a XOR c = b`

### Visualization

```
Array: [25, 10, 2, 8, 5, 3]
Binary (5 bits):
  25 = 11001
  10 = 01010
   2 = 00010
   8 = 01000
   5 = 00101
   3 = 00011

Build max_xor bit by bit:

Bit 4 (16): Can we get max_xor with bit 4 = 1?
  Current: max_xor = 00000
  Try: candidate = 10000
  For each prefix:
    25 prefix = 1, need 0 in set? 10 has 0! YES!
  max_xor = 10000

Bit 3 (8): Can we get bit 3 = 1?
  Try: candidate = 11000
  For prefix 25(11), need 00 -> 10(01), 2(00), 8(01), 5(00), 3(00)
  25(11) XOR 2(00) = 11, 25(11) XOR 5(00) = 11 YES!
  max_xor = 11000

Bit 2 (4): Try candidate = 11100
  Need pairs whose 3-bit prefixes XOR to 111
  25(110) XOR 5(001) = 111 YES!
  max_xor = 11100

Bit 1 (2): Try candidate = 11110
  Need 4-bit prefix XOR = 1111
  No such pair exists
  max_xor stays 11100

Bit 0 (1): Try candidate = 11101
  No pair achieves this
  max_xor stays 11100

Final max_xor = 11100 = 28
```

---

## Code Implementation

```python
class TrieNode:
    def __init__(self):
        self.children = {}  # 0 and 1

def insert(root, num, bits=32):
    node = root
    for i in range(bits - 1, -1, -1):
        bit = (num >> i) & 1
        if bit not in node.children:
            node.children[bit] = TrieNode()
        node = node.children[bit]

def find_max_xor(root, num, bits=32):
    node = root
    xor_val = 0
    for i in range(bits - 1, -1, -1):
        bit = (num >> i) & 1
        opposite = 1 - bit
        
        if opposite in node.children:
            xor_val |= (1 << i)
            node = node.children[opposite]
        else:
            node = node.children[bit]
    
    return xor_val

def max_xor_trie(arr):
    if len(arr) < 2:
        return 0
    
    root = TrieNode()
    
    # Insert first number
    insert(root, arr[0])
    max_xor = 0
    
    # For each number, find max XOR with existing numbers
    for num in arr[1:]:
        max_xor = max(max_xor, find_max_xor(root, num))
        insert(root, num)
    
    return max_xor
```

---

## Time and Space Complexity

### Trie Approach
- **Time**: O(n * B) where B = number of bits (32)
- **Space**: O(n * B) for trie nodes

### Bit Manipulation Approach
- **Time**: O(n * B)
- **Space**: O(n) for prefix sets

### Comparison
| Approach | Time | Space |
|----------|------|-------|
| Brute Force | O(n^2) | O(1) |
| Trie | O(n * 32) = O(n) | O(n * 32) |
| Bit Manipulation | O(n * 32) = O(n) | O(n) |

---

## Key Takeaways

1. **Greedy for XOR**: To maximize XOR, prefer opposite bits at higher positions

2. **Trie for binary numbers**: Efficient structure for bit-by-bit decisions

3. **XOR property**: If `a XOR b = c`, then `a XOR c = b` and `b XOR c = a`

4. **Build answer bit by bit**: Check if each bit position can be 1

5. **MSB first**: Higher bits contribute more to the value

6. **Related problems**:
   - Maximum XOR subarray
   - XOR of all pairs
   - Count pairs with XOR in range
