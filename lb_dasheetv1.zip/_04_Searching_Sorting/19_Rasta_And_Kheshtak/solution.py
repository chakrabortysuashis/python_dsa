"""
Rasta and Kheshtak - Maximum XOR Pair
=====================================

Problem: Given an array of integers, find the maximum XOR of any two elements.

Solution: Trie-based approach or Bit manipulation
- Build binary trie and greedily choose opposite bits
- Or use property: a XOR b = c implies a XOR c = b

Time Complexity: O(n * 32) = O(n)
Space Complexity: O(n * 32)
"""


def max_xor_brute(arr: list) -> int:
    """
    Brute Force: Check all pairs.
    Time: O(n^2)
    """
    if len(arr) < 2:
        return 0

    max_xor = 0
    n = len(arr)

    for i in range(n):
        for j in range(i + 1, n):
            max_xor = max(max_xor, arr[i] ^ arr[j])

    return max_xor


class TrieNode:
    """Binary Trie node with children for 0 and 1."""

    def __init__(self):
        self.children = {}  # Keys: 0 or 1


class BinaryTrie:
    """Trie for storing binary representations of numbers."""

    def __init__(self, bits: int = 32):
        self.root = TrieNode()
        self.bits = bits

    def insert(self, num: int) -> None:
        """Insert number into trie (MSB to LSB)."""
        node = self.root
        for i in range(self.bits - 1, -1, -1):
            bit = (num >> i) & 1
            if bit not in node.children:
                node.children[bit] = TrieNode()
            node = node.children[bit]

    def find_max_xor(self, num: int) -> int:
        """
        Find maximum XOR of num with any number in trie.
        Greedy: at each bit, try to go opposite direction.
        """
        node = self.root
        xor_val = 0

        for i in range(self.bits - 1, -1, -1):
            bit = (num >> i) & 1
            opposite = 1 - bit

            # Try to take opposite bit for maximum XOR
            if opposite in node.children:
                xor_val |= (1 << i)  # This bit contributes 1 to XOR
                node = node.children[opposite]
            elif bit in node.children:
                node = node.children[bit]
            else:
                break  # No more paths

        return xor_val


def max_xor_trie(arr: list) -> int:
    """
    Trie-based solution.
    For each number, find max XOR with numbers already in trie.

    Time: O(n * bits)
    Space: O(n * bits)
    """
    if len(arr) < 2:
        return 0

    # Determine number of bits needed
    max_val = max(arr)
    bits = max_val.bit_length() if max_val > 0 else 1

    trie = BinaryTrie(bits)
    trie.insert(arr[0])
    max_xor = 0

    for num in arr[1:]:
        # Find max XOR with existing numbers
        max_xor = max(max_xor, trie.find_max_xor(num))
        # Add current number to trie
        trie.insert(num)

    return max_xor


def max_xor_bit_manipulation(arr: list) -> int:
    """
    Bit manipulation approach.
    Build answer bit by bit using XOR property.

    Key insight: If a XOR b = c, then a XOR c = b
    So if we can achieve prefix p, check if any two prefixes XOR to p.

    Time: O(n * bits)
    Space: O(n)
    """
    if len(arr) < 2:
        return 0

    max_val = max(arr)
    bits = max_val.bit_length() if max_val > 0 else 1

    max_xor = 0
    mask = 0

    for i in range(bits - 1, -1, -1):
        # Add current bit to mask
        mask |= (1 << i)

        # Get all prefixes up to current bit
        prefixes = set()
        for num in arr:
            prefixes.add(num & mask)

        # Try to set this bit in answer
        candidate = max_xor | (1 << i)

        # Check if any two prefixes XOR to candidate
        # a XOR b = candidate => a XOR candidate = b
        for prefix in prefixes:
            if (prefix ^ candidate) in prefixes:
                max_xor = candidate
                break

    return max_xor


def find_max_xor_pair(arr: list) -> tuple:
    """
    Find the actual pair that gives maximum XOR.
    Returns (max_xor, num1, num2).
    """
    if len(arr) < 2:
        return (0, None, None)

    max_xor = 0
    pair = (None, None)

    n = len(arr)
    for i in range(n):
        for j in range(i + 1, n):
            xor_val = arr[i] ^ arr[j]
            if xor_val > max_xor:
                max_xor = xor_val
                pair = (arr[i], arr[j])

    return (max_xor, pair[0], pair[1])


# ==================== TEST CASES ====================

def test_max_xor():
    """Comprehensive test cases."""

    print("=" * 60)
    print("MAXIMUM XOR PAIR (RASTA AND KHESHTAK)")
    print("=" * 60)

    test_cases = [
        # (array, expected_max_xor)
        ([25, 10, 2, 8, 5, 3], 28),
        ([1, 2, 3, 4, 5], 7),
        ([5, 25, 10], 30),
        ([14, 70, 53, 83], 119),
        ([1, 1, 1], 0),
        ([0, 1], 1),
        ([15, 15], 0),
        ([4, 6, 7], 3),
    ]

    all_passed = True

    for i, (arr, expected) in enumerate(test_cases, 1):
        brute = max_xor_brute(arr.copy())
        trie = max_xor_trie(arr.copy())
        bit_manip = max_xor_bit_manipulation(arr.copy())

        status = "PASS" if brute == trie == bit_manip == expected else "FAIL"
        if brute != expected:
            all_passed = False

        print(f"\nTest {i}: {status}")
        print(f"  Array: {arr}")
        print(f"  Expected: {expected}")
        print(f"  Brute: {brute}, Trie: {trie}, BitManip: {bit_manip}")

        # Show the pair
        xor_val, a, b = find_max_xor_pair(arr)
        if a is not None:
            print(f"  Pair: {a} XOR {b} = {xor_val}")
            print(f"    {a:>5d} = {bin(a)}")
            print(f"    {b:>5d} = {bin(b)}")
            print(f"    XOR   = {bin(xor_val)} = {xor_val}")

    print("\n" + "=" * 60)
    print(f"All tests passed: {all_passed}")
    print("=" * 60)


def visualize_trie(arr: list):
    """Visualize trie construction and search."""

    print(f"\nVisualizing Trie for: {arr}")
    print("=" * 60)

    if len(arr) < 2:
        print("Need at least 2 elements!")
        return

    max_val = max(arr)
    bits = max_val.bit_length()

    print(f"\nBinary representations ({bits} bits):")
    for num in arr:
        print(f"  {num:>4d} = {bin(num)[2:].zfill(bits)}")

    print(f"\nBuilding trie and finding max XOR:")

    trie = BinaryTrie(bits)
    trie.insert(arr[0])
    print(f"  Inserted {arr[0]} ({bin(arr[0])[2:].zfill(bits)})")

    max_xor = 0
    best_pair = None

    for num in arr[1:]:
        xor_val = trie.find_max_xor(num)
        print(f"\n  For {num} ({bin(num)[2:].zfill(bits)}):")
        print(f"    Best XOR in trie: {xor_val}")

        if xor_val > max_xor:
            max_xor = xor_val
            # Find the pair
            for prev in arr[:arr.index(num) + 1]:
                if prev ^ num == xor_val:
                    best_pair = (prev, num)
                    break
            print(f"    New max! Pair: {best_pair}")

        trie.insert(num)
        print(f"    Inserted {num} into trie")

    print(f"\nFinal max XOR: {max_xor}")
    if best_pair:
        print(f"Pair: {best_pair[0]} XOR {best_pair[1]} = {max_xor}")


if __name__ == "__main__":
    test_max_xor()

    # Visualize
    visualize_trie([25, 10, 2, 8, 5, 3])
