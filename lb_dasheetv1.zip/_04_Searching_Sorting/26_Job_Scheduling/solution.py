"""
Job Scheduling Problem
======================

Problem: Schedule jobs with deadlines to maximize profit.

Solution: Greedy - sort by profit, assign latest available slot

Time: O(n^2) naive, O(n log n) with DSU
Space: O(n)
"""


def job_scheduling_naive(jobs: list) -> tuple:
    """
    Greedy approach with O(n^2) slot finding.
    jobs: list of (deadline, profit)
    """
    if not jobs:
        return 0, 0

    # Sort by profit descending
    jobs = sorted(jobs, key=lambda x: -x[1])

    max_deadline = max(j[0] for j in jobs)
    slots = [-1] * (max_deadline + 1)

    profit = 0
    count = 0

    for deadline, p in jobs:
        # Find latest available slot before deadline
        for slot in range(deadline, 0, -1):
            if slots[slot] == -1:
                slots[slot] = p
                profit += p
                count += 1
                break

    return count, profit


class DSU:
    """Disjoint Set Union for O(1) slot finding."""

    def __init__(self, n):
        self.parent = list(range(n + 1))

    def find(self, x):
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])
        return self.parent[x]

    def union(self, x, y):
        self.parent[self.find(x)] = self.find(y)


def job_scheduling_dsu(jobs: list) -> tuple:
    """
    Optimized with DSU for O(n log n) total.
    """
    if not jobs:
        return 0, 0

    jobs = sorted(jobs, key=lambda x: -x[1])
    max_deadline = max(j[0] for j in jobs)

    dsu = DSU(max_deadline)
    profit = 0
    count = 0

    for deadline, p in jobs:
        slot = dsu.find(deadline)
        if slot > 0:
            profit += p
            count += 1
            dsu.union(slot, slot - 1)

    return count, profit


def test_job_scheduling():
    print("=" * 50)
    print("JOB SCHEDULING")
    print("=" * 50)

    test_cases = [
        ([(1, 20), (2, 15), (1, 10), (3, 5), (3, 1)], (2, 35)),
        ([(4, 20), (1, 10), (1, 40), (1, 30)], (2, 60)),
        ([(2, 100), (1, 19), (2, 27), (1, 25), (3, 15)], (3, 142)),
    ]

    for jobs, expected in test_cases:
        result = job_scheduling_naive(jobs)
        result_dsu = job_scheduling_dsu(jobs)
        print(f"\nJobs: {jobs}")
        print(f"Expected: {expected}")
        print(f"Naive: {result}, DSU: {result_dsu}")


if __name__ == "__main__":
    test_job_scheduling()
