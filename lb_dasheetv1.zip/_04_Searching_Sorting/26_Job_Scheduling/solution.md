# Job Scheduling Problem

## Problem Statement

Given `n` jobs with deadlines and profits, schedule jobs to **maximize total profit**. Each job takes 1 unit of time, and a job must be completed before its deadline.

**Example:**
```
Input: jobs = [(1,20), (2,15), (1,10), (3,5), (3,1)]  # (deadline, profit)
Output: 35
Explanation: Do job 1 (profit 20) at slot 1, job 2 (profit 15) at slot 2 = 35
```

---

## Approach

### Greedy Algorithm
1. **Sort jobs by profit** (descending)
2. For each job, find the **latest available slot** before deadline
3. Use Union-Find or simple array to track slots

### Binary Search Optimization
For finding available slot, can use binary search on occupied slots.

---

## Code

```python
def job_scheduling(jobs):
    # Sort by profit descending
    jobs = sorted(jobs, key=lambda x: -x[1])
    
    max_deadline = max(j[0] for j in jobs)
    slots = [-1] * (max_deadline + 1)  # slot[i] = job assigned
    
    profit = 0
    count = 0
    
    for deadline, p in jobs:
        # Find slot from deadline down to 1
        for slot in range(deadline, 0, -1):
            if slots[slot] == -1:
                slots[slot] = p
                profit += p
                count += 1
                break
    
    return count, profit
```

---

## Complexity

- **Time**: O(n^2) naive, O(n log n) with Union-Find
- **Space**: O(max_deadline)

---

## Key Insight

Greedy: Always pick highest profit job first, assign to latest possible slot to keep earlier slots free for other jobs.
