"""
Find Pivot in Sorted Rotated Array
==================================

Problem: Given a sorted array that has been rotated, find the index of
the minimum element (pivot point).

Solution: Binary search comparing mid with high
- If arr[mid] > arr[high]: pivot in right half
- If arr[mid] < arr[high]: pivot at mid or left half

Time Complexity: O(log n) without duplicates, O(n) worst with duplicates
Space Complexity: O(1)
"""


def find_pivot_linear(arr: list) -> int:
    """
    Linear scan to find where array breaks.
    Time: O(n)
    """
    n = len(arr)
    if n == 0:
        return -1

    for i in range(n - 1):
        if arr[i] > arr[i + 1]:
            return i + 1

    return 0  # Not rotated


def find_pivot(arr: list) -> int:
    """
    Binary search to find pivot (minimum element index).
    Assumes no duplicates.

    Time: O(log n)
    Space: O(1)
    """
    if not arr:
        return -1

    n = len(arr)
    low, high = 0, n - 1

    # If array is not rotated
    if arr[low] < arr[high]:
        return 0

    while low < high:
        mid = low + (high - low) // 2

        if arr[mid] > arr[high]:
            # Minimum must be in right half
            # arr[mid] is definitely not the minimum
            low = mid + 1
        else:
            # Minimum could be at mid or in left half
            # Don't exclude mid
            high = mid

    return low  # low == high


def find_pivot_with_duplicates(arr: list) -> int:
    """
    Handle arrays with duplicate elements.

    When arr[mid] == arr[high], we can't determine direction.
    Solution: Reduce search space by high -= 1

    Time: O(n) worst case, O(log n) average
    """
    if not arr:
        return -1

    n = len(arr)
    low, high = 0, n - 1

    while low < high:
        mid = low + (high - low) // 2

        if arr[mid] > arr[high]:
            low = mid + 1
        elif arr[mid] < arr[high]:
            high = mid
        else:
            # arr[mid] == arr[high]
            # Can't decide, safely reduce search space
            high -= 1

    return low


def find_rotation_count(arr: list) -> int:
    """
    Find how many times the array was rotated.
    This equals the index of the minimum element.
    """
    return find_pivot(arr)


def find_maximum_index(arr: list) -> int:
    """
    Find the maximum element index in rotated sorted array.
    Maximum is just before the pivot (or last element if not rotated).
    """
    if not arr:
        return -1

    pivot = find_pivot(arr)
    if pivot == 0:
        return len(arr) - 1
    return pivot - 1


# ==================== TEST CASES ====================

def test_find_pivot():
    """Comprehensive test cases."""

    print("=" * 60)
    print("FIND PIVOT IN ROTATED SORTED ARRAY")
    print("=" * 60)

    test_cases = [
        # (array, expected_pivot_index)
        ([4, 5, 6, 7, 0, 1, 2], 4),
        ([3, 4, 5, 1, 2], 3),
        ([1, 2, 3, 4, 5], 0),  # Not rotated
        ([2, 1], 1),
        ([1], 0),
        ([5, 1, 2, 3, 4], 1),
        ([2, 3, 4, 5, 1], 4),
        ([6, 7, 8, 1, 2, 3, 4, 5], 3),
    ]

    all_passed = True

    for i, (arr, expected) in enumerate(test_cases, 1):
        result_bs = find_pivot(arr)
        result_linear = find_pivot_linear(arr)

        status = "PASS" if result_bs == expected else "FAIL"
        if result_bs != expected:
            all_passed = False

        print(f"\nTest {i}: {status}")
        print(f"  Array: {arr}")
        print(f"  Expected pivot index: {expected}")
        print(f"  Binary search: {result_bs}")
        print(f"  Linear: {result_linear}")
        print(f"  Minimum value: {arr[result_bs] if result_bs >= 0 else 'N/A'}")

    # Test with duplicates
    print("\n" + "-" * 60)
    print("Tests with Duplicates:")
    print("-" * 60)

    dup_cases = [
        ([2, 2, 2, 0, 1, 2], 3),
        ([3, 3, 1, 3], 2),
        ([1, 1, 1, 1], 0),
        ([2, 2, 2, 2, 1], 4),
    ]

    for arr, expected in dup_cases:
        result = find_pivot_with_duplicates(arr)
        status = "PASS" if result == expected else "FAIL"
        print(f"  {arr} -> pivot={result}, min={arr[result]} [{status}]")

    # Test rotation count
    print("\n" + "-" * 60)
    print("Rotation Count:")
    print("-" * 60)

    for arr, expected in test_cases[:5]:
        count = find_rotation_count(arr)
        print(f"  {arr} -> rotated {count} times")

    print("\n" + "=" * 60)
    print(f"All tests passed: {all_passed}")
    print("=" * 60)


def visualize_search(arr: list):
    """Visualize the binary search process."""

    print(f"\nVisualizing pivot search")
    print(f"Array: {arr}")
    print("=" * 60)

    if not arr:
        print("Empty array!")
        return

    n = len(arr)
    low, high = 0, n - 1

    # Check if not rotated
    if arr[low] < arr[high]:
        print(f"arr[{low}]={arr[low]} < arr[{high}]={arr[high]}")
        print("Array is not rotated. Pivot at index 0")
        return

    step = 1
    while low < high:
        mid = low + (high - low) // 2

        # Visualize
        visual = "["
        for i, val in enumerate(arr):
            markers = []
            if i == low:
                markers.append("L")
            if i == mid:
                markers.append("M")
            if i == high:
                markers.append("H")

            if markers:
                visual += f"({','.join(markers)}){val}"
            else:
                visual += f"{val}"

            if i < n - 1:
                visual += ", "
        visual += "]"

        print(f"\nStep {step}: {visual}")
        print(f"  low={low}, mid={mid}, high={high}")
        print(f"  arr[mid]={arr[mid]}, arr[high]={arr[high]}")

        if arr[mid] > arr[high]:
            print(f"  {arr[mid]} > {arr[high]}: Pivot in right half")
            print(f"  low = mid + 1 = {mid + 1}")
            low = mid + 1
        else:
            print(f"  {arr[mid]} <= {arr[high]}: Pivot at mid or left")
            print(f"  high = mid = {mid}")
            high = mid

        step += 1

    print(f"\nFound! Pivot index = {low}")
    print(f"Minimum element = {arr[low]}")
    print(f"Array was rotated {low} times")


if __name__ == "__main__":
    test_find_pivot()

    # Visualize
    visualize_search([4, 5, 6, 7, 0, 1, 2])
    visualize_search([3, 4, 5, 1, 2])
