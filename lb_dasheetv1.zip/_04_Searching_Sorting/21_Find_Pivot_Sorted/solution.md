# Find Pivot in Sorted Rotated Array

## Problem Statement

Given a sorted array that has been **rotated** at some pivot point, find the index of the **minimum element** (the pivot point).

The pivot is where the rotation happened - elements before it are larger than it.

**Example 1:**
```
Input: arr = [4, 5, 6, 7, 0, 1, 2]
Output: 4
Explanation: Minimum element is 0 at index 4
             Array was rotated at index 4
```

**Example 2:**
```
Input: arr = [3, 4, 5, 1, 2]
Output: 3
Explanation: Minimum element is 1 at index 3
```

**Example 3:**
```
Input: arr = [1, 2, 3, 4, 5]
Output: 0
Explanation: Array is not rotated, minimum at index 0
```

---

## Approach Intuition

### Key Insight
In a rotated sorted array:
- There's exactly **one point** where order breaks (larger -> smaller)
- Left part is sorted AND all elements > all elements in right part
- Right part is sorted AND contains the minimum

### Binary Search Strategy
Compare `arr[mid]` with `arr[high]`:
- If `arr[mid] > arr[high]`: Pivot is in right half (rotation point is to the right)
- If `arr[mid] < arr[high]`: Pivot might be mid or in left half
- If `arr[mid] == arr[high]`: Can't determine, reduce search space

---

## Brute Force Approach

### Algorithm
Scan for the point where `arr[i] > arr[i+1]`.

### Code
```python
def find_pivot_brute(arr):
    n = len(arr)
    if n == 0:
        return -1
    
    for i in range(n - 1):
        if arr[i] > arr[i + 1]:
            return i + 1
    
    return 0  # Not rotated
```

### Complexity
- **Time**: O(n)
- **Space**: O(1)

---

## Optimal Approach: Binary Search

### Algorithm
1. If `arr[low] < arr[high]`: Array is sorted, pivot at low
2. Calculate mid
3. Compare `arr[mid]` with `arr[high]`:
   - If `arr[mid] > arr[high]`: Pivot in `[mid+1, high]`
   - Else: Pivot in `[low, mid]`

### Visualization

```
Array: [4, 5, 6, 7, 0, 1, 2]
Index:  0  1  2  3  4  5  6

Step 1: low=0, high=6
        [4, 5, 6, 7, 0, 1, 2]
         L        M        H
        mid = 3, arr[3] = 7
        arr[mid]=7 > arr[high]=2
        Pivot is in RIGHT half: low = mid + 1 = 4

Step 2: low=4, high=6
        [4, 5, 6, 7, 0, 1, 2]
                     L  M  H
        mid = 5, arr[5] = 1
        arr[mid]=1 < arr[high]=2
        Pivot might be mid or LEFT: high = mid = 5

Step 3: low=4, high=5
        [4, 5, 6, 7, 0, 1, 2]
                     L  M  H
        mid = 4, arr[4] = 0
        arr[mid]=0 < arr[high]=1
        high = mid = 4

Step 4: low=4, high=4
        low == high, found pivot!
        Pivot index = 4, minimum value = 0
```

### Search Space Reduction

```
Array size: 7

Step 1: Search space [0, 6] -> eliminated [0, 3]
Step 2: Search space [4, 6] -> narrowed to [4, 5]
Step 3: Search space [4, 5] -> narrowed to [4, 4]

Total comparisons: 3 (vs 6 for linear scan)
```

---

## Handling Duplicates

```
Array: [2, 2, 2, 0, 1, 2, 2]

When arr[mid] == arr[high], we can't decide direction!

Solution: Reduce search space by high--

Step 1: mid=3, arr[mid]=0 < arr[high]=2
        high = mid = 3

Step 2: mid=1, arr[mid]=2 > arr[high]=0
        low = mid + 1 = 2

Step 3: mid=2, arr[mid]=2 > arr[high]=0
        low = mid + 1 = 3

Step 4: low=3, high=3
        Pivot = 3
```

---

## Dry Run with Different Example

```
Array: [3, 4, 5, 1, 2]
Index:  0  1  2  3  4

low=0, high=4, mid=2
  arr[2]=5 > arr[4]=2 -> low = 3

low=3, high=4, mid=3
  arr[3]=1 < arr[4]=2 -> high = 3

low=3, high=3
  Pivot = 3, minimum = 1
```

---

## Code Implementation

```python
def find_pivot(arr):
    """
    Find pivot (minimum element) in rotated sorted array.
    Returns index of minimum element.
    """
    if not arr:
        return -1
    
    low, high = 0, len(arr) - 1
    
    # If array is not rotated
    if arr[low] < arr[high]:
        return 0
    
    while low < high:
        mid = low + (high - low) // 2
        
        if arr[mid] > arr[high]:
            # Minimum is in right half
            low = mid + 1
        else:
            # Minimum is at mid or in left half
            high = mid
    
    return low  # low == high == pivot index

def find_pivot_with_duplicates(arr):
    """Handle arrays with duplicate elements."""
    if not arr:
        return -1
    
    low, high = 0, len(arr) - 1
    
    while low < high:
        mid = low + (high - low) // 2
        
        if arr[mid] > arr[high]:
            low = mid + 1
        elif arr[mid] < arr[high]:
            high = mid
        else:
            # arr[mid] == arr[high], can't decide
            # Safely reduce search space
            high -= 1
    
    return low
```

---

## Time and Space Complexity

### Without Duplicates
- **Time**: O(log n)
- **Space**: O(1)

### With Duplicates
- **Time**: O(n) worst case (all same elements)
- **Average**: O(log n)
- **Space**: O(1)

### Comparison
| Approach | Time | Space |
|----------|------|-------|
| Linear Scan | O(n) | O(1) |
| Binary Search | O(log n) | O(1) |
| With Duplicates | O(n) worst | O(1) |

---

## Key Takeaways

1. **Compare with arr[high]**: Not arr[low], because we want to find where values drop

2. **high = mid, not mid - 1**: When `arr[mid] < arr[high]`, mid itself might be the minimum

3. **low = mid + 1**: When `arr[mid] > arr[high]`, mid definitely isn't minimum

4. **Not rotated check**: If `arr[low] < arr[high]`, minimum is at low

5. **Duplicates complicate things**: When `arr[mid] == arr[high]`, safely do `high--`

6. **Related problems**:
   - Search in rotated sorted array
   - Find rotation count
   - Find maximum in rotated array (just use `pivot - 1`)
