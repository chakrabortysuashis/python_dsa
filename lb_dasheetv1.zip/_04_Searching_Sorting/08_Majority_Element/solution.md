# Find Majority Element

## Problem Statement

Given an array of size n, find the majority element. The majority element is the element that appears more than n/2 times. Assume the majority element always exists.

**Example 1:**
```
Input: arr = [3, 2, 3]
Output: 3
Explanation: 3 appears 2 times out of 3 (2 > 3/2)
```

**Example 2:**
```
Input: arr = [2, 2, 1, 1, 1, 2, 2]
Output: 2
Explanation: 2 appears 4 times out of 7 (4 > 7/2)
```

---

## Key Insight: Boyer-Moore Voting Algorithm

The majority element appears MORE than n/2 times. This means:
- If we pair each majority element with a different element, we'll still have majority elements left over!

**Intuition**: Imagine a "battle" where each element fights with a different element:
- Same elements: reinforce (count++)
- Different elements: cancel out (count--)
- The survivor is the majority!

---

## Brute Force Approach

### Algorithm
For each element, count its occurrences.

```python
def majority_brute(arr):
    n = len(arr)
    for candidate in arr:
        count = sum(1 for x in arr if x == candidate)
        if count > n // 2:
            return candidate
    return -1
```

**Time**: O(n^2), **Space**: O(1)

---

## Better Approach: Hash Map

```python
def majority_hashmap(arr):
    count = {}
    n = len(arr)
    
    for num in arr:
        count[num] = count.get(num, 0) + 1
        if count[num] > n // 2:
            return num
    
    return -1
```

**Time**: O(n), **Space**: O(n)

---

## Optimal: Boyer-Moore Voting Algorithm

### Algorithm
1. Find a candidate using voting
2. (Optional) Verify the candidate

### Visualization

```
Array: [2, 2, 1, 1, 1, 2, 2]

Phase 1: Find Candidate

Index:  0   1   2   3   4   5   6
Value:  2   2   1   1   1   2   2
        
i=0: candidate=2, count=1   (new candidate)
i=1: 2==2, count=2          (reinforce)
i=2: 1!=2, count=1          (cancel one)
i=3: 1!=2, count=0          (cancel one)
i=4: candidate=1, count=1   (new candidate since count was 0)
i=5: 2!=1, count=0          (cancel)
i=6: candidate=2, count=1   (new candidate)

Candidate = 2

Phase 2: Verify (if needed)
Count of 2 = 4 > 7/2 = 3 -> 2 IS majority element
```

### Another Example

```
Array: [3, 3, 4, 2, 4, 4, 2, 4, 4]

i=0: candidate=3, count=1
i=1: 3==3, count=2
i=2: 4!=3, count=1
i=3: 2!=3, count=0
i=4: candidate=4, count=1   (new candidate)
i=5: 4==4, count=2
i=6: 2!=4, count=1
i=7: 4==4, count=2
i=8: 4==4, count=3

Candidate = 4
Count of 4 = 5 > 9/2 = 4 -> 4 IS majority element
```

---

## Why Does This Work?

**Key Property**: The majority element appears > n/2 times.

Think of it as a "battle":
- Every time majority meets non-majority, they cancel (count stays same or increases net)
- Since majority has > n/2, after all cancellations, majority survives

```
Majority: M M M M M (5 times, n=9)
Others:   X X X X   (4 times)

Even if each X cancels one M:
M M M M M     After pairing: M
X X X X       still survives!
```

---

## Code Implementation

```python
def majority_element(arr):
    """
    Boyer-Moore Voting Algorithm
    
    Time: O(n)
    Space: O(1)
    """
    # Phase 1: Find candidate
    candidate = None
    count = 0
    
    for num in arr:
        if count == 0:
            candidate = num
            count = 1
        elif num == candidate:
            count += 1
        else:
            count -= 1
    
    # Phase 2: Verify (if majority might not exist)
    # count = sum(1 for x in arr if x == candidate)
    # if count > len(arr) // 2:
    #     return candidate
    # return -1
    
    return candidate  # If guaranteed to exist
```

---

## Finding Elements Appearing > n/3 Times

For finding elements appearing more than n/3 times, we need at most 2 candidates:

```python
def majority_n3(arr):
    """Find all elements appearing more than n/3 times."""
    candidate1, candidate2 = None, None
    count1, count2 = 0, 0
    
    for num in arr:
        if candidate1 == num:
            count1 += 1
        elif candidate2 == num:
            count2 += 1
        elif count1 == 0:
            candidate1, count1 = num, 1
        elif count2 == 0:
            candidate2, count2 = num, 1
        else:
            count1 -= 1
            count2 -= 1
    
    # Verify
    result = []
    n = len(arr)
    for cand in [candidate1, candidate2]:
        if cand is not None and sum(1 for x in arr if x == cand) > n // 3:
            result.append(cand)
    
    return result
```

---

## Time and Space Complexity

| Approach | Time | Space |
|----------|------|-------|
| Brute Force | O(n^2) | O(1) |
| Hash Map | O(n) | O(n) |
| Sorting | O(n log n) | O(1) |
| Boyer-Moore | O(n) | O(1) |

Boyer-Moore is optimal in both time and space!

---

## Key Takeaways

1. **Voting intuition**: Think of elements "voting" - majority wins
2. **Cancellation principle**: Different elements cancel out
3. **Two phases**: Find candidate, then verify (if needed)
4. **Generalization**: For n/k majority, need k-1 candidates
5. **Assumption matters**: If majority doesn't exist, verify phase is essential
