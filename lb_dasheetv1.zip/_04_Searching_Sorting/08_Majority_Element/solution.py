"""
Find Majority Element
=====================

Problem: Find the element that appears more than n/2 times.

Boyer-Moore Voting Algorithm - the optimal O(n) time, O(1) space solution.

Key Insight: If we pair each majority with a different element, majority survives!
"""

from typing import List, Optional
from collections import Counter


def majority_element_boyer_moore(arr: List[int]) -> int:
    """
    Boyer-Moore Voting Algorithm.

    Phase 1: Find a candidate
    - Maintain a count. When count is 0, pick new candidate.
    - Same as candidate: count++
    - Different: count--

    Phase 2: Verify (if majority might not exist)

    Time: O(n)
    Space: O(1)
    """
    if not arr:
        return -1

    # Phase 1: Find candidate
    candidate = arr[0]
    count = 0

    for num in arr:
        if count == 0:
            candidate = num
            count = 1
        elif num == candidate:
            count += 1
        else:
            count -= 1

    return candidate


def majority_element_verified(arr: List[int]) -> Optional[int]:
    """
    Boyer-Moore with verification phase.
    Returns None if no majority exists.
    """
    if not arr:
        return None

    # Phase 1: Find candidate
    candidate = arr[0]
    count = 0

    for num in arr:
        if count == 0:
            candidate = num
            count = 1
        elif num == candidate:
            count += 1
        else:
            count -= 1

    # Phase 2: Verify
    actual_count = sum(1 for x in arr if x == candidate)
    if actual_count > len(arr) // 2:
        return candidate

    return None


def majority_element_hashmap(arr: List[int]) -> int:
    """
    Hash map approach.

    Time: O(n)
    Space: O(n)
    """
    count = {}
    n = len(arr)

    for num in arr:
        count[num] = count.get(num, 0) + 1
        if count[num] > n // 2:
            return num

    return -1


def majority_element_sorting(arr: List[int]) -> int:
    """
    Sorting approach.

    If majority exists, the middle element must be it!

    Time: O(n log n)
    Space: O(1) if in-place sort
    """
    arr = sorted(arr)
    return arr[len(arr) // 2]


def majority_element_brute(arr: List[int]) -> int:
    """
    Brute force: Count each element.

    Time: O(n^2)
    Space: O(1)
    """
    n = len(arr)

    for candidate in arr:
        count = sum(1 for x in arr if x == candidate)
        if count > n // 2:
            return candidate

    return -1


def majority_elements_n3(arr: List[int]) -> List[int]:
    """
    Find all elements appearing more than n/3 times.

    There can be at most 2 such elements.
    Uses extended Boyer-Moore with 2 candidates.

    Time: O(n)
    Space: O(1)
    """
    if not arr:
        return []

    # Phase 1: Find up to 2 candidates
    candidate1, candidate2 = None, None
    count1, count2 = 0, 0

    for num in arr:
        if candidate1 is not None and num == candidate1:
            count1 += 1
        elif candidate2 is not None and num == candidate2:
            count2 += 1
        elif count1 == 0:
            candidate1, count1 = num, 1
        elif count2 == 0:
            candidate2, count2 = num, 1
        else:
            count1 -= 1
            count2 -= 1

    # Phase 2: Verify
    result = []
    n = len(arr)
    threshold = n // 3

    for cand in [candidate1, candidate2]:
        if cand is not None:
            actual_count = sum(1 for x in arr if x == cand)
            if actual_count > threshold and cand not in result:
                result.append(cand)

    return result


def majority_elements_nk(arr: List[int], k: int) -> List[int]:
    """
    Find all elements appearing more than n/k times.

    There can be at most k-1 such elements.

    Time: O(n*k)
    Space: O(k)
    """
    if not arr or k < 2:
        return []

    # Phase 1: Find up to k-1 candidates
    candidates = {}

    for num in arr:
        if num in candidates:
            candidates[num] += 1
        elif len(candidates) < k - 1:
            candidates[num] = 1
        else:
            # Decrement all counts
            to_remove = []
            for cand in candidates:
                candidates[cand] -= 1
                if candidates[cand] == 0:
                    to_remove.append(cand)
            for cand in to_remove:
                del candidates[cand]

    # Phase 2: Verify
    result = []
    n = len(arr)
    threshold = n // k

    for cand in candidates:
        if sum(1 for x in arr if x == cand) > threshold:
            result.append(cand)

    return result


# ==================== TEST CASES ====================

def test_majority_element():
    """Test all approaches."""

    print("=" * 60)
    print("MAJORITY ELEMENT")
    print("=" * 60)

    test_cases = [
        ([3, 2, 3], 3),
        ([2, 2, 1, 1, 1, 2, 2], 2),
        ([1], 1),
        ([1, 1, 2], 1),
        ([3, 3, 4, 2, 4, 4, 2, 4, 4], 4),
        ([1, 1, 1, 1, 2, 2, 2], 1),
    ]

    methods = [
        ("Boyer-Moore", majority_element_boyer_moore),
        ("Hash Map", majority_element_hashmap),
        ("Sorting", majority_element_sorting),
    ]

    for arr, expected in test_cases:
        print(f"\nArray: {arr}")
        print(f"Expected majority: {expected}")

        for name, method in methods:
            result = method(arr.copy())
            status = "PASS" if result == expected else "FAIL"
            print(f"  {name:12}: {result} [{status}]")

    # Test n/3 majority
    print("\n" + "=" * 60)
    print("MAJORITY > n/3")
    print("=" * 60)

    n3_tests = [
        ([3, 2, 3], [3]),
        ([1, 1, 1, 3, 3, 2, 2, 2], [1, 2]),
        ([1, 2, 3, 4], []),
        ([1, 1, 1, 2, 2, 2, 3], [1, 2]),
    ]

    for arr, expected in n3_tests:
        result = majority_elements_n3(arr)
        status = "PASS" if sorted(result) == sorted(expected) else "FAIL"
        print(f"Array: {arr}")
        print(f"  Elements > n/3: {result} (expected {expected}) [{status}]")


def visualize_boyer_moore(arr: List[int]):
    """Visualize Boyer-Moore algorithm step by step."""

    print(f"\n{'='*60}")
    print(f"BOYER-MOORE VISUALIZATION for {arr}")
    print("=" * 60)

    candidate = None
    count = 0

    print("\nPhase 1: Finding Candidate")
    print(f"{'Index':<6} {'Value':<8} {'Action':<25} {'Candidate':<12} {'Count':<6}")
    print("-" * 60)

    for i, num in enumerate(arr):
        if count == 0:
            candidate = num
            count = 1
            action = f"New candidate (count=0)"
        elif num == candidate:
            count += 1
            action = f"{num} == {candidate}, reinforce"
        else:
            count -= 1
            action = f"{num} != {candidate}, cancel"

        print(f"{i:<6} {num:<8} {action:<25} {candidate:<12} {count:<6}")

    print(f"\nCandidate: {candidate}")

    # Verify
    actual_count = sum(1 for x in arr if x == candidate)
    n = len(arr)
    is_majority = actual_count > n // 2

    print(f"\nPhase 2: Verification")
    print(f"Count of {candidate}: {actual_count}")
    print(f"Required (> {n}//2 = {n//2}): {is_majority}")
    print(f"\nResult: {candidate if is_majority else 'No majority exists'}")


def explain_intuition():
    """Explain why Boyer-Moore works."""

    print("\n" + "=" * 60)
    print("WHY BOYER-MOORE WORKS")
    print("=" * 60)

    print("""
    The majority element appears MORE than n/2 times.

    Think of it as a "battle":
    - When same elements meet: They team up (count++)
    - When different elements meet: They cancel out (count--)

    Example: n=9, Majority appears 5 times

    Array:   M  X  M  X  M  M  X  X  M
             |--|  |--|  |--|  |--|  |
              0     0     +1    0    +1

    After all pairings:
    - 4 majority cancelled with 4 non-majority
    - 1 majority element survives!

    Key insight: Since majority > n/2, it will ALWAYS survive
    because there aren't enough other elements to cancel all of them.

    Mathematical proof:
    - Majority count: M > n/2
    - Other count: O = n - M < n/2
    - After cancellation: M - O > 0 (majority survives!)
    """)


if __name__ == "__main__":
    test_majority_element()

    visualize_boyer_moore([2, 2, 1, 1, 1, 2, 2])
    visualize_boyer_moore([3, 3, 4, 2, 4, 4, 2, 4, 4])

    explain_intuition()
