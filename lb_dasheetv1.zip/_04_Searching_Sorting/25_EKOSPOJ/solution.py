"""
EKOSPOJ - Wood Cutting Problem
==============================

Problem: Find maximum sawblade height H to get at least M meters of wood.

Solution: Binary search on height H

Time: O(n log(max_height))
Space: O(1)
"""


def calculate_wood(trees: list, height: int) -> int:
    """Calculate total wood cut at given height."""
    return sum(max(0, t - height) for t in trees)


def max_cutting_height(trees: list, M: int) -> int:
    """Find maximum height that yields at least M wood."""
    if not trees:
        return 0

    low, high = 0, max(trees)
    result = 0

    while low <= high:
        mid = (low + high) // 2
        wood = calculate_wood(trees, mid)

        if wood >= M:
            result = mid
            low = mid + 1  # Try higher cut
        else:
            high = mid - 1  # Need lower cut for more wood

    return result


def test_ekospoj():
    print("=" * 50)
    print("EKOSPOJ - WOOD CUTTING")
    print("=" * 50)

    test_cases = [
        ([20, 15, 10, 17], 7, 15),
        ([4, 42, 40, 26, 46], 20, 36),
        ([1, 2, 3, 4, 5], 10, 0),
        ([10, 10, 10, 10], 10, 7),
    ]

    for trees, M, expected in test_cases:
        result = max_cutting_height(trees, M)
        wood = calculate_wood(trees, result)
        print(f"\nTrees: {trees}, Need: {M}")
        print(f"Height: {result}, Wood: {wood}")
        print(f"Expected: {expected}, {'PASS' if result == expected else 'FAIL'}")


if __name__ == "__main__":
    test_ekospoj()
