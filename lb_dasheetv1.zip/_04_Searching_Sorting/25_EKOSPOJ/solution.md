# EKOSPOJ - Wood Cutting Problem

## Problem Statement

Lumberjack needs `M` meters of wood. Given `N` trees with heights, find the **maximum height H** to set the sawblade such that cutting all trees at height H yields at least M meters of wood.

Trees shorter than H are not cut. For each tree taller than H, the amount cut is `height - H`.

**Example:**
```
Input: trees = [20, 15, 10, 17], M = 7
Output: 15
Explanation: 
  Cut at H=15: (20-15) + (17-15) = 5 + 2 = 7 meters
  H=15 is maximum that gives >= 7 meters
```

---

## Approach: Binary Search on Answer

### Search Space
- **Low**: 0 (cut everything)
- **High**: max(trees) (cut nothing)

### Validation
For height H, calculate total wood: `sum(max(0, tree - H) for tree in trees)`

### Visualization

```
Trees: [20, 15, 10, 17], M = 7

low=0, high=20

mid=10: wood = 10+5+0+7 = 22 >= 7. Try higher.
mid=15: wood = 5+0+0+2 = 7 >= 7. Try higher.
mid=17: wood = 3+0+0+0 = 3 < 7. Try lower.
mid=16: wood = 4+0+0+1 = 5 < 7. Try lower.

Answer: 15
```

---

## Code

```python
def max_cutting_height(trees, M):
    low, high = 0, max(trees)
    result = 0
    
    while low <= high:
        mid = (low + high) // 2
        wood = sum(max(0, t - mid) for t in trees)
        
        if wood >= M:
            result = mid
            low = mid + 1  # Try higher cut
        else:
            high = mid - 1  # Need more wood
    
    return result
```

---

## Complexity

- **Time**: O(n log(max_height))
- **Space**: O(1)

---

## Key Insight

Binary search on the sawblade height. Higher blade = less wood but we want maximum height that still gives enough wood.
