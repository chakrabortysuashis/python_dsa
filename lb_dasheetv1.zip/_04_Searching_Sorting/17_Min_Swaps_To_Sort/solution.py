"""
Minimum Swaps to Sort Array
============================

Problem: Given an array of n distinct elements, find the minimum number
of swaps required to sort the array.

Key Insight: This is a graph cycle problem. Elements form cycles based on
where they need to move. Swaps needed for a cycle of length k = k - 1.

Time Complexity: O(n log n)
Space Complexity: O(n)
"""


def min_swaps_brute(arr: list) -> int:
    """
    Brute Force: Simulate selection sort.
    For each position, find correct element and swap.

    Time: O(n^2)
    Space: O(n)
    """
    n = len(arr)
    arr = arr.copy()
    sorted_arr = sorted(arr)
    swaps = 0

    for i in range(n):
        if arr[i] != sorted_arr[i]:
            # Find where the correct element is
            j = i + 1
            while arr[j] != sorted_arr[i]:
                j += 1
            # Swap
            arr[i], arr[j] = arr[j], arr[i]
            swaps += 1

    return swaps


def min_swaps_to_sort(arr: list) -> int:
    """
    Optimal: Cycle detection approach.

    1. Create (value, original_index) pairs
    2. Sort to find target positions
    3. Count cycles - each cycle of length k needs k-1 swaps

    Time: O(n log n) for sorting
    Space: O(n)
    """
    n = len(arr)

    # Create pairs of (value, original_index)
    arr_pos = [(val, idx) for idx, val in enumerate(arr)]

    # Sort by value
    arr_pos.sort(key=lambda x: x[0])

    visited = [False] * n
    swaps = 0

    for i in range(n):
        # Skip if visited or already in correct position
        if visited[i] or arr_pos[i][1] == i:
            continue

        # Find cycle length starting from i
        cycle_length = 0
        j = i

        while not visited[j]:
            visited[j] = True
            # Move to the original index of current element
            j = arr_pos[j][1]
            cycle_length += 1

        # Cycle of length k needs k-1 swaps
        if cycle_length > 0:
            swaps += (cycle_length - 1)

    return swaps


def min_swaps_hashmap(arr: list) -> int:
    """
    Alternative using hashmap for position lookup.
    Same complexity but different implementation.
    """
    n = len(arr)
    sorted_arr = sorted(arr)

    # Map value to its target (sorted) position
    pos_map = {val: idx for idx, val in enumerate(sorted_arr)}

    visited = [False] * n
    swaps = 0

    for i in range(n):
        if visited[i] or arr[i] == sorted_arr[i]:
            continue

        cycle_length = 0
        j = i

        while not visited[j]:
            visited[j] = True
            # Find where arr[j] should go
            val = arr[j]
            j = pos_map[val]
            cycle_length += 1

        swaps += (cycle_length - 1)

    return swaps


def min_swaps_with_cycles(arr: list) -> tuple:
    """
    Return swaps count AND the actual cycles found.
    Useful for understanding and visualization.
    """
    n = len(arr)
    arr_pos = [(val, idx) for idx, val in enumerate(arr)]
    arr_pos.sort(key=lambda x: x[0])

    visited = [False] * n
    cycles = []
    swaps = 0

    for i in range(n):
        if visited[i] or arr_pos[i][1] == i:
            if arr_pos[i][1] == i and not visited[i]:
                cycles.append([i])  # Self-loop
            continue

        cycle = []
        j = i

        while not visited[j]:
            visited[j] = True
            cycle.append(j)
            j = arr_pos[j][1]

        cycles.append(cycle)
        swaps += (len(cycle) - 1)

    return swaps, cycles


# ==================== TEST CASES ====================

def test_min_swaps():
    """Comprehensive test cases."""

    print("=" * 60)
    print("MINIMUM SWAPS TO SORT")
    print("=" * 60)

    test_cases = [
        # (array, expected_swaps)
        ([4, 3, 2, 1], 2),
        ([1, 5, 4, 3, 2], 2),
        ([2, 4, 5, 1, 3], 3),
        ([1, 2, 3, 4, 5], 0),  # Already sorted
        ([5, 4, 3, 2, 1], 2),  # Reverse sorted
        ([1, 3, 2], 1),
        ([2, 1], 1),
        ([1], 0),  # Single element
        ([7, 1, 3, 2, 4, 5, 6], 5),
        ([4, 3, 1, 2], 3),
    ]

    all_passed = True

    for i, (arr, expected) in enumerate(test_cases, 1):
        result = min_swaps_to_sort(arr.copy())
        brute_result = min_swaps_brute(arr.copy())
        hashmap_result = min_swaps_hashmap(arr.copy())

        status = "PASS" if result == expected else "FAIL"
        if result != expected:
            all_passed = False

        print(f"\nTest {i}: {status}")
        print(f"  Array: {arr}")
        print(f"  Expected: {expected}")
        print(f"  Cycle method: {result}")
        print(f"  Brute force: {brute_result}")
        print(f"  HashMap: {hashmap_result}")

    # Show cycles for some examples
    print("\n" + "-" * 60)
    print("Cycle Analysis:")
    print("-" * 60)

    for arr, expected in test_cases[:5]:
        swaps, cycles = min_swaps_with_cycles(arr.copy())
        print(f"\n  Array: {arr}")
        print(f"  Cycles: {cycles}")
        print(f"  Swaps calculation: ", end="")
        calc = " + ".join(f"({len(c)}-1)" for c in cycles if len(c) > 1)
        if calc:
            print(f"{calc} = {swaps}")
        else:
            print(f"0 (no swaps needed)")

    print("\n" + "=" * 60)
    print(f"All tests passed: {all_passed}")
    print("=" * 60)


def visualize_algorithm(arr: list):
    """Visualize the cycle detection process."""

    print(f"\nVisualizing Min Swaps for: {arr}")
    print("=" * 60)

    n = len(arr)
    sorted_arr = sorted(arr)

    print(f"\nOriginal: {arr}")
    print(f"Target:   {sorted_arr}")

    # Create mapping
    print(f"\nStep 1: Create (value, original_index) pairs")
    pairs = [(val, idx) for idx, val in enumerate(arr)]
    print(f"  {pairs}")

    # Sort
    print(f"\nStep 2: Sort by value")
    pairs_sorted = sorted(pairs, key=lambda x: x[0])
    print(f"  {pairs_sorted}")
    print(f"  This shows: sorted_position -> (value, original_index)")

    # Find cycles
    print(f"\nStep 3: Find cycles")
    visited = [False] * n
    total_swaps = 0

    for i in range(n):
        if visited[i]:
            continue

        if pairs_sorted[i][1] == i:
            print(f"  Index {i}: Element {pairs_sorted[i][0]} already in place (self-loop)")
            visited[i] = True
            continue

        print(f"\n  Start cycle from index {i}:")
        cycle = []
        j = i

        while not visited[j]:
            visited[j] = True
            val, orig_idx = pairs_sorted[j]
            cycle.append((j, val, orig_idx))
            print(f"    Position {j}: value={val}, came from index {orig_idx}")
            j = orig_idx

        swaps = len(cycle) - 1
        total_swaps += swaps
        print(f"  Cycle length: {len(cycle)}, Swaps needed: {swaps}")
        print(f"  Cycle path: {' -> '.join(str(c[0]) for c in cycle)} -> {cycle[0][0]}")

    print(f"\nTotal swaps: {total_swaps}")


if __name__ == "__main__":
    test_min_swaps()

    # Visualize specific examples
    visualize_algorithm([4, 3, 2, 1])
    visualize_algorithm([1, 5, 4, 3, 2])
    visualize_algorithm([2, 4, 5, 1, 3])
