# Minimum Swaps to Sort Array

## Problem Statement

Given an array of `n` distinct elements, find the minimum number of swaps required to sort the array.

**Example 1:**
```
Input: arr = [4, 3, 2, 1]
Output: 2
Explanation: 
  Swap 4 and 1: [1, 3, 2, 4]
  Swap 3 and 2: [1, 2, 3, 4]
```

**Example 2:**
```
Input: arr = [1, 5, 4, 3, 2]
Output: 2
Explanation:
  Swap 5 and 2: [1, 2, 4, 3, 5]
  Swap 4 and 3: [1, 2, 3, 4, 5]
```

---

## Approach Intuition

### Key Insight: Graph Cycles
Think of each element as needing to move to its correct position. This creates a **directed graph** where:
- Each node is an index
- Edge from `i` to `j` means: element at index `i` should go to index `j`

**Swaps needed for a cycle of length k = k - 1**

### Why Cycles?
```
Array: [4, 3, 2, 1]
Sorted: [1, 2, 3, 4]

Index 0 has 4, should have 1. Where is 1? At index 3.
Index 3 has 1, should have 4. Where is 4? At index 0.

This forms a cycle: 0 -> 3 -> 0
Similarly: 1 -> 2 -> 1

Two cycles of length 2: swaps = (2-1) + (2-1) = 2
```

---

## Brute Force Approach

### Algorithm
Simulate sorting: for each position, find correct element and swap.

### Code
```python
def min_swaps_brute(arr):
    n = len(arr)
    arr = arr.copy()
    sorted_arr = sorted(arr)
    swaps = 0
    
    for i in range(n):
        if arr[i] != sorted_arr[i]:
            # Find index of correct element
            j = arr.index(sorted_arr[i])
            arr[i], arr[j] = arr[j], arr[i]
            swaps += 1
    
    return swaps
```

### Complexity
- **Time**: O(n^2) - finding element takes O(n)
- **Space**: O(n)

---

## Optimal Approach: Cycle Detection

### Algorithm
1. Create array of (value, original_index) pairs
2. Sort by value
3. Find cycles by following where each element should go
4. Sum up (cycle_length - 1) for each cycle

### Visualization

```
Array: [4, 3, 2, 1]
Index:  0  1  2  3

Step 1: Create pairs (value, original_index)
  [(4, 0), (3, 1), (2, 2), (1, 3)]

Step 2: Sort by value
  [(1, 3), (2, 2), (3, 1), (4, 0)]
  
  Interpretation: 
    Sorted position 0 should get element from original index 3
    Sorted position 1 should get element from original index 2
    etc.

Step 3: Find cycles
  
  Start at index 0: visited[0] = True
    Sorted pos 0 has (1, 3) -> go to original index 3
    Index 3: visited[3] = True
    Sorted pos 3 has (4, 0) -> go to original index 0
    Index 0 already visited -> Cycle complete!
    Cycle 1: 0 -> 3 -> 0, length = 2
  
  Start at index 1: visited[1] = True
    Sorted pos 1 has (2, 2) -> go to original index 2
    Index 2: visited[2] = True
    Sorted pos 2 has (3, 1) -> go to original index 1
    Index 1 already visited -> Cycle complete!
    Cycle 2: 1 -> 2 -> 1, length = 2

Step 4: Calculate swaps
  Cycle 1: length 2, swaps = 2 - 1 = 1
  Cycle 2: length 2, swaps = 2 - 1 = 1
  Total = 2
```

### Search Space Reduction

```
Array size: n
Without cycle detection: Try all permutations O(n!)
With cycle detection: Visit each element once O(n)

For n = 10:
  Brute force: up to 100 operations
  Cycle method: exactly 10 operations
```

---

## Dry Run with Different Example

```
Array: [1, 5, 4, 3, 2]
Index:  0  1  2  3  4

Pairs: [(1,0), (5,1), (4,2), (3,3), (2,4)]
Sorted: [(1,0), (2,4), (3,3), (4,2), (5,1)]

Find cycles:
  Index 0: (1,0) -> original 0 (self-loop, no swap needed)
  
  Index 1: (2,4) -> go to 4
    Index 4: (5,1) -> go to 1
    Cycle: 1 -> 4 -> 1, length = 2, swaps = 1
  
  Index 2: (3,3) -> go to 3
    Index 3: (4,2) -> go to 2
    Cycle: 2 -> 3 -> 2, length = 2, swaps = 1

Total swaps = 1 + 1 = 2
```

---

## Code Implementation

```python
def min_swaps_to_sort(arr):
    n = len(arr)
    
    # Create pairs of (value, original_index)
    arr_pos = [(val, idx) for idx, val in enumerate(arr)]
    
    # Sort by value to get target positions
    arr_pos.sort(key=lambda x: x[0])
    
    visited = [False] * n
    swaps = 0
    
    for i in range(n):
        # Skip if already visited or in correct position
        if visited[i] or arr_pos[i][1] == i:
            continue
        
        # Find cycle length
        cycle_length = 0
        j = i
        
        while not visited[j]:
            visited[j] = True
            # Move to the original index of current element
            j = arr_pos[j][1]
            cycle_length += 1
        
        # Swaps needed for cycle = cycle_length - 1
        if cycle_length > 0:
            swaps += (cycle_length - 1)
    
    return swaps
```

---

## Alternative: Using HashMap

```python
def min_swaps_hashmap(arr):
    n = len(arr)
    sorted_arr = sorted(arr)
    
    # Map value to its sorted position
    pos_map = {val: idx for idx, val in enumerate(sorted_arr)}
    
    visited = [False] * n
    swaps = 0
    
    for i in range(n):
        if visited[i] or arr[i] == sorted_arr[i]:
            continue
        
        cycle_length = 0
        j = i
        
        while not visited[j]:
            visited[j] = True
            # Find where current element should go
            j = pos_map[arr[j]]
            cycle_length += 1
        
        swaps += (cycle_length - 1)
    
    return swaps
```

---

## Time and Space Complexity

### Optimal Approach
- **Time Complexity**: O(n log n)
  - Sorting takes O(n log n)
  - Cycle detection takes O(n)
  
- **Space Complexity**: O(n)
  - For sorted pairs and visited array

### Comparison
| Approach | Time | Space |
|----------|------|-------|
| Brute Force | O(n^2) | O(n) |
| Cycle Detection | O(n log n) | O(n) |
| If array is permutation of 1..n | O(n) | O(n) |

---

## Key Takeaways

1. **Graph perspective**: Each element forms an edge to its correct position

2. **Cycle insight**: Elements in a cycle of length k need exactly k-1 swaps

3. **Why k-1?**: In a cycle, we can fix one element with each swap, but the last element falls into place automatically

4. **Self-loops**: Elements already in correct position have cycle length 1, need 0 swaps

5. **Sum of all cycles**: Total swaps = sum of (cycle_length - 1) for all cycles

6. **Related problems**:
   - Minimum swaps to make sequences increasing
   - Couples holding hands
   - Sort array by swapping adjacent elements
