"""
Book Allocation Problem
=======================

Problem: Allocate n books to m students such that:
- Each student gets at least one book
- Books are allocated contiguously
- Maximum pages any student reads is minimized

Solution: Binary search on maximum pages allowed

Time: O(n log(sum))
Space: O(1)
"""


def is_valid_allocation(pages: list, m: int, max_pages: int) -> bool:
    """
    Check if books can be allocated to m students
    with no student getting more than max_pages.
    """
    students_needed = 1
    current_sum = 0

    for p in pages:
        if current_sum + p <= max_pages:
            current_sum += p
        else:
            students_needed += 1
            current_sum = p

            if students_needed > m:
                return False

    return True


def allocate_books(pages: list, m: int) -> int:
    """
    Find minimum possible value of maximum pages.
    Binary search on the answer.
    """
    n = len(pages)

    if m > n:
        return -1  # Not enough books for all students

    low = max(pages)    # At least max book (can't split)
    high = sum(pages)   # One student takes all
    result = high

    while low <= high:
        mid = (low + high) // 2

        if is_valid_allocation(pages, m, mid):
            result = mid
            high = mid - 1  # Try smaller max
        else:
            low = mid + 1   # Need larger max

    return result


def allocate_with_assignment(pages: list, m: int) -> tuple:
    """Return min max pages and actual allocation."""
    n = len(pages)
    if m > n:
        return -1, []

    max_pages = allocate_books(pages, m)

    # Reconstruct allocation
    allocation = []
    current_student = []
    current_sum = 0

    for p in pages:
        if current_sum + p <= max_pages:
            current_student.append(p)
            current_sum += p
        else:
            allocation.append(current_student)
            current_student = [p]
            current_sum = p

    if current_student:
        allocation.append(current_student)

    return max_pages, allocation


# ==================== TEST CASES ====================

def test_book_allocation():
    print("=" * 60)
    print("BOOK ALLOCATION PROBLEM")
    print("=" * 60)

    test_cases = [
        ([12, 34, 67, 90], 2, 113),
        ([10, 20, 30, 40], 2, 60),
        ([10, 20, 30], 1, 60),
        ([10, 20, 30], 3, 30),
        ([12, 34, 67, 90], 4, 90),
        ([5, 10, 30, 20, 15], 3, 30),
    ]

    for i, (pages, m, expected) in enumerate(test_cases, 1):
        result = allocate_books(pages, m)
        max_p, alloc = allocate_with_assignment(pages, m)

        status = "PASS" if result == expected else "FAIL"
        print(f"\nTest {i}: {status}")
        print(f"  Pages: {pages}, Students: {m}")
        print(f"  Expected: {expected}, Got: {result}")
        print(f"  Allocation: {alloc}")


if __name__ == "__main__":
    test_book_allocation()
