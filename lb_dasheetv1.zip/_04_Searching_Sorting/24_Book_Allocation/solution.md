# Book Allocation Problem

## Problem Statement

Given `n` books with pages `arr[0..n-1]` and `m` students, allocate books to students such that:
1. Each student gets at least one book
2. Books are allocated in **contiguous** manner
3. **Minimize the maximum** number of pages any student has to read

**Example 1:**
```
Input: pages = [12, 34, 67, 90], students = 2
Output: 113
Explanation: 
  Allocation: [12, 34, 67] to student 1 (113 pages)
              [90] to student 2 (90 pages)
  Maximum = 113 (minimized)
```

**Example 2:**
```
Input: pages = [10, 20, 30, 40], students = 2
Output: 60
Explanation: [10, 20, 30] (60) and [40] (40), max = 60
```

---

## Approach Intuition

### Key Insight: Binary Search on Answer
We binary search on the **maximum pages** a student can be assigned.

For each candidate max `M`:
- Check if all books can be allocated to `m` students with no student getting > M pages
- If yes, try smaller M
- If no, try larger M

### Search Space
- **Minimum possible**: `max(arr)` - at least one book must be assigned
- **Maximum possible**: `sum(arr)` - one student takes all

---

## Algorithm

### Binary Search + Greedy Validation

```python
def is_valid(pages, m, max_pages):
    """
    Check if books can be allocated to m students
    with no student getting more than max_pages.
    
    Greedy: Assign books to current student until limit,
    then move to next student.
    """
    students_needed = 1
    current_sum = 0
    
    for p in pages:
        if current_sum + p <= max_pages:
            current_sum += p
        else:
            students_needed += 1
            current_sum = p
            
            if students_needed > m:
                return False
    
    return True
```

---

## Visualization

```
Pages: [12, 34, 67, 90], Students: 2

Search space: low = max(90) = 90, high = sum = 203

=== Step 1: mid = 146 ===
Can allocate with max 146 pages per student?

Student 1: 12 -> 12+34=46 -> 46+67=113 -> 113+90=203 > 146, STOP
Student 2: 90

Students needed = 2 <= 2. YES!
Try smaller: high = 145

=== Step 2: mid = 117 ===
Student 1: 12 -> 46 -> 113 (add 90? 203 > 117, no)
Student 2: 90

Students = 2 <= 2. YES!
Try smaller: high = 116

=== Step 3: mid = 103 ===
Student 1: 12 -> 46 (add 67? 113 > 103, no)
Student 2: 67 (add 90? 157 > 103, no)
Student 3: 90

Students = 3 > 2. NO!
Try larger: low = 104

=== Continue until convergence ===

Final answer: 113
```

---

## Code Implementation

```python
def allocate_books(pages, m):
    """
    Allocate books to minimize maximum pages per student.
    Binary search on the answer.
    """
    n = len(pages)
    
    if m > n:
        return -1  # Not enough books
    
    low = max(pages)    # At least one book per student
    high = sum(pages)   # One student takes all
    result = high
    
    while low <= high:
        mid = (low + high) // 2
        
        if is_valid(pages, m, mid):
            result = mid
            high = mid - 1  # Try smaller max
        else:
            low = mid + 1   # Need larger max
    
    return result

def is_valid(pages, m, max_pages):
    students = 1
    current = 0
    
    for p in pages:
        if current + p <= max_pages:
            current += p
        else:
            students += 1
            current = p
    
    return students <= m
```

---

## Time and Space Complexity

- **Time**: O(n log(sum - max))
  - Binary search: O(log(sum - max)) iterations
  - Each validation: O(n)
  
- **Space**: O(1)

---

## Key Takeaways

1. **Contiguous allocation**: Books must be in order, can't skip

2. **Binary search on answer**: Classic pattern for min-max optimization

3. **Greedy validation**: Fill current student until limit, then next

4. **Search bounds**:
   - low = max element (can't split a book)
   - high = total sum (worst case)

5. **Related**: Aggressive Cows, Painter's Partition, SPOJ PRATA
