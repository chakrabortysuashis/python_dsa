# Painter's Partition Problem

## Problem Statement

Given `n` boards with lengths and `k` painters, each painter paints contiguous boards. Find minimum time to paint all boards (minimize maximum time any painter takes).

**Example:**
```
Input: boards = [10, 20, 30, 40], k = 2
Output: 60
Explanation: Painter 1: [10,20,30]=60, Painter 2: [40]=40
             Max = 60 (minimized)
```

---

## Approach: Binary Search on Answer

Same as Book Allocation problem!

- **Low**: max(boards) - at least one board
- **High**: sum(boards) - one painter does all
- **Check**: Can we paint with max time = mid?

---

## Code

```python
def can_paint(boards, k, max_time):
    painters = 1
    current = 0
    for b in boards:
        if current + b <= max_time:
            current += b
        else:
            painters += 1
            current = b
    return painters <= k

def painters_partition(boards, k):
    low, high = max(boards), sum(boards)
    result = high
    
    while low <= high:
        mid = (low + high) // 2
        if can_paint(boards, k, mid):
            result = mid
            high = mid - 1
        else:
            low = mid + 1
    
    return result
```

---

## Complexity

- **Time**: O(n log(sum))
- **Space**: O(1)
