"""
Painter's Partition Problem
===========================

Problem: Minimize maximum painting time when k painters paint n boards contiguously.

Identical to Book Allocation problem.

Time: O(n log(sum))
Space: O(1)
"""


def can_paint(boards: list, k: int, max_time: int) -> bool:
    """Check if k painters can paint all boards with max_time limit."""
    painters = 1
    current = 0
    for b in boards:
        if current + b <= max_time:
            current += b
        else:
            painters += 1
            current = b
    return painters <= k


def painters_partition(boards: list, k: int) -> int:
    """Find minimum possible maximum painting time."""
    if k > len(boards):
        return max(boards)

    low, high = max(boards), sum(boards)
    result = high

    while low <= high:
        mid = (low + high) // 2
        if can_paint(boards, k, mid):
            result = mid
            high = mid - 1
        else:
            low = mid + 1

    return result


def test_painters():
    print("=" * 50)
    print("PAINTER'S PARTITION")
    print("=" * 50)

    test_cases = [
        ([10, 20, 30, 40], 2, 60),
        ([10, 10, 10, 10], 2, 20),
        ([1, 2, 3, 4, 5, 6, 7, 8, 9], 3, 17),
    ]

    for boards, k, expected in test_cases:
        result = painters_partition(boards, k)
        print(f"\nBoards: {boards}, Painters: {k}")
        print(f"Min max time: {result}")
        print(f"Expected: {expected}, {'PASS' if result == expected else 'FAIL'}")


if __name__ == "__main__":
    test_painters()
