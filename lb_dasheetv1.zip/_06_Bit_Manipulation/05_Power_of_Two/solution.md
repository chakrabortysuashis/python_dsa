# Check if Number is Power of Two

## Problem Statement
Given a positive integer n, check whether n is a power of 2.

### Examples
```
Input: n = 8
Output: True
Explanation: 8 = 2^3

Input: n = 6
Output: False
Explanation: 6 is not a power of 2

Input: n = 1
Output: True
Explanation: 1 = 2^0
```

---

## Binary Representation Visualization

```
Powers of 2 have exactly ONE set bit!

Number | Binary   | Power of 2?
-------|----------|------------
  1    | 00000001 |    Yes (2^0)
  2    | 00000010 |    Yes (2^1)
  4    | 00000100 |    Yes (2^2)
  8    | 00001000 |    Yes (2^3)
 16    | 00010000 |    Yes (2^4)
  3    | 00000011 |    No (2 set bits)
  6    | 00000110 |    No (2 set bits)
  7    | 00000111 |    No (3 set bits)
```

---

## Intuition

### Key Insight: Powers of 2 have exactly one set bit

```
2^0 = 1   = 00000001
2^1 = 2   = 00000010
2^2 = 4   = 00000100
2^3 = 8   = 00001000
2^4 = 16  = 00010000

Each has exactly ONE '1' bit!
```

### The Magic of n & (n-1)

When we subtract 1 from a power of 2:
```
n     = 8 = 1000
n - 1 = 7 = 0111

n & (n-1) = 1000 & 0111 = 0000 = 0

For a power of 2, n & (n-1) is ALWAYS 0!
```

Why? Because n-1 flips the single 1-bit to 0 and sets all lower bits to 1. ANDing them gives 0.

### Non-power of 2 example:
```
n     = 6 = 0110
n - 1 = 5 = 0101

n & (n-1) = 0110 & 0101 = 0100 = 4 ≠ 0

Not a power of 2!
```

---

## Algorithm

### Optimal Solution: n & (n-1) == 0

```python
def is_power_of_two(n):
    return n > 0 and (n & (n - 1)) == 0
```

**Why n > 0?**
- 0 is not a power of 2
- Negative numbers are not powers of 2

---

## Dry Run

### Example 1: n = 16 (Power of 2)

```
Step 1: Check n > 0
  16 > 0 ✓

Step 2: Calculate n & (n-1)
  n     = 16 = 00010000
  n - 1 = 15 = 00001111
  ----------------------
  AND        = 00000000 = 0

Step 3: Check if result == 0
  0 == 0 ✓

Result: TRUE (16 is a power of 2)
```

### Example 2: n = 12 (Not a Power of 2)

```
Step 1: Check n > 0
  12 > 0 ✓

Step 2: Calculate n & (n-1)
  n     = 12 = 00001100
  n - 1 = 11 = 00001011
  ----------------------
  AND        = 00001000 = 8

Step 3: Check if result == 0
  8 == 0 ✗

Result: FALSE (12 is not a power of 2)
```

---

## Visual Proof

```
For n = 2^k (any power of 2):

n has the form: 0...010...0 (single 1 at position k)
                     ^
                  position k

n - 1 has form: 0...001...1 (0 at position k, 1s below)

When ANDed:
  n     = 0...010...0
  n-1   = 0...001...1
  ------------------
  AND   = 0...000...0 = 0

The single 1 in n aligns with 0 in (n-1), giving 0!
```

---

## Alternative Approaches

### Approach 1: Count Set Bits
```python
def is_power_of_two_count(n):
    if n <= 0:
        return False
    count = 0
    while n:
        count += n & 1
        n >>= 1
    return count == 1
```
Time: O(log n)

### Approach 2: Divide by 2 repeatedly
```python
def is_power_of_two_divide(n):
    if n <= 0:
        return False
    while n > 1:
        if n % 2 != 0:
            return False
        n //= 2
    return True
```
Time: O(log n)

### Approach 3: Using log (not recommended due to float precision)
```python
import math
def is_power_of_two_log(n):
    if n <= 0:
        return False
    log_val = math.log2(n)
    return log_val == int(log_val)
```

---

## Complexity Analysis

| Approach | Time | Space |
|----------|------|-------|
| n & (n-1) | O(1) | O(1) |
| Count bits | O(log n) | O(1) |
| Divide by 2 | O(log n) | O(1) |

**The bit manipulation approach is optimal!**

---

## Edge Cases

| Input | Output | Reason |
|-------|--------|--------|
| 0 | False | 0 is not 2^k for any k |
| 1 | True | 1 = 2^0 |
| -8 | False | Negative numbers are not powers of 2 |
| 2^30 | True | Large power of 2 |

---

## Common Variations

1. **Find next power of 2** greater than n
2. **Find previous power of 2** less than or equal to n
3. **Count powers of 2** up to n
4. **Check if power of 4** (additional condition needed)

---

## Related Bit Tricks

```python
# Next power of 2
def next_power_of_2(n):
    n -= 1
    n |= n >> 1
    n |= n >> 2
    n |= n >> 4
    n |= n >> 8
    n |= n >> 16
    return n + 1

# Previous power of 2
def prev_power_of_2(n):
    n |= n >> 1
    n |= n >> 2
    n |= n >> 4
    n |= n >> 8
    n |= n >> 16
    return (n + 1) >> 1
```

---

## Key Takeaway

> **A number is a power of 2 if and only if it has exactly one set bit.**
> 
> Check: `n > 0 and (n & (n-1)) == 0`
