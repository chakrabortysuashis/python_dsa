"""
Check if Number is Power of Two
===============================

Problem: Given a positive integer n, check whether n is a power of 2.

Key Insight: Powers of 2 have exactly ONE set bit in binary.
             n & (n-1) clears the rightmost set bit.
             For powers of 2, this results in 0.

Example:
    Input: n = 8
    Output: True (8 = 2^3 = 1000 in binary)
"""


def to_binary(n: int, bits: int = 8) -> str:
    """Convert integer to binary string for visualization."""
    if n >= 0:
        return bin(n)[2:].zfill(bits)
    return bin(n & ((1 << bits) - 1))[2:]


# =============================================================================
# APPROACH 1: Bit Manipulation - n & (n-1) (Optimal)
# =============================================================================

def is_power_of_two(n: int) -> bool:
    """
    Check if n is a power of 2 using bit manipulation.

    Key Insight:
        - Powers of 2 have exactly one set bit
        - n & (n-1) clears the rightmost set bit
        - For powers of 2, this results in 0

    Time Complexity: O(1)
    Space Complexity: O(1)

    Args:
        n: Integer to check

    Returns:
        True if n is a power of 2, False otherwise

    Example:
        >>> is_power_of_two(8)
        True
        >>> is_power_of_two(6)
        False
        >>> is_power_of_two(1)
        True
    """
    return n > 0 and (n & (n - 1)) == 0


def is_power_of_two_verbose(n: int) -> bool:
    """Check with detailed visualization."""
    print(f"\nChecking if {n} is a power of 2")
    print("=" * 50)

    # Check positive
    if n <= 0:
        print(f"  {n} <= 0, so NOT a power of 2")
        return False

    print(f"  Step 1: {n} > 0 ✓")

    # Binary representations
    bits = max(8, n.bit_length())
    n_binary = to_binary(n, bits)
    n_minus_1 = n - 1
    n_minus_1_binary = to_binary(n_minus_1, bits)
    result = n & n_minus_1
    result_binary = to_binary(result, bits)

    print(f"\n  Step 2: Calculate n & (n-1)")
    print(f"    n     = {n:4d} = {n_binary}")
    print(f"    n - 1 = {n_minus_1:4d} = {n_minus_1_binary}")
    print(f"    " + "-" * (12 + bits))
    print(f"    AND        = {result_binary} = {result}")

    print(f"\n  Step 3: Check if result == 0")
    is_power = result == 0
    print(f"    {result} == 0 ? {is_power}")

    print("\n" + "=" * 50)
    if is_power:
        # Find the power
        power = 0
        temp = n
        while temp > 1:
            temp >>= 1
            power += 1
        print(f"  RESULT: {n} IS a power of 2 (2^{power})")
    else:
        print(f"  RESULT: {n} is NOT a power of 2")

    return is_power


# =============================================================================
# APPROACH 2: Count Set Bits
# =============================================================================

def is_power_of_two_count_bits(n: int) -> bool:
    """
    Check if n is a power of 2 by counting set bits.

    A power of 2 has exactly one set bit.

    Time Complexity: O(log n)
    Space Complexity: O(1)

    Example:
        >>> is_power_of_two_count_bits(8)
        True
    """
    if n <= 0:
        return False

    count = 0
    while n:
        count += n & 1
        n >>= 1
        if count > 1:  # Early exit
            return False

    return count == 1


# =============================================================================
# APPROACH 3: Repeated Division
# =============================================================================

def is_power_of_two_divide(n: int) -> bool:
    """
    Check if n is a power of 2 by repeatedly dividing by 2.

    Time Complexity: O(log n)
    Space Complexity: O(1)

    Example:
        >>> is_power_of_two_divide(8)
        True
    """
    if n <= 0:
        return False

    while n > 1:
        if n % 2 != 0:
            return False
        n //= 2

    return True


# =============================================================================
# APPROACH 4: Using Isolate Rightmost Bit
# =============================================================================

def is_power_of_two_isolate(n: int) -> bool:
    """
    Check if n is a power of 2 by isolating rightmost bit.

    For powers of 2, n & (-n) equals n itself.

    Time Complexity: O(1)
    Space Complexity: O(1)

    Example:
        >>> is_power_of_two_isolate(8)
        True
    """
    return n > 0 and (n & (-n)) == n


# =============================================================================
# RELATED FUNCTIONS
# =============================================================================

def next_power_of_two(n: int) -> int:
    """
    Find the next power of 2 greater than or equal to n.

    Example:
        >>> next_power_of_two(5)
        8
        >>> next_power_of_two(8)
        8
    """
    if n <= 0:
        return 1
    if is_power_of_two(n):
        return n

    n -= 1
    n |= n >> 1
    n |= n >> 2
    n |= n >> 4
    n |= n >> 8
    n |= n >> 16
    return n + 1


def previous_power_of_two(n: int) -> int:
    """
    Find the largest power of 2 less than or equal to n.

    Example:
        >>> previous_power_of_two(10)
        8
        >>> previous_power_of_two(8)
        8
    """
    if n <= 0:
        return 0

    n |= n >> 1
    n |= n >> 2
    n |= n >> 4
    n |= n >> 8
    n |= n >> 16
    return (n + 1) >> 1


def get_power(n: int) -> int:
    """
    If n is a power of 2, return the exponent k where n = 2^k.
    Otherwise return -1.

    Example:
        >>> get_power(8)
        3
        >>> get_power(6)
        -1
    """
    if not is_power_of_two(n):
        return -1

    power = 0
    while n > 1:
        n >>= 1
        power += 1
    return power


# =============================================================================
# VISUALIZATION
# =============================================================================

def visualize_powers_of_two(limit: int = 32) -> None:
    """Visualize powers of 2 and their binary representations."""
    print("\nPowers of 2 Visualization")
    print("=" * 60)
    print(f"{'n':>6} | {'Binary':>16} | {'Set Bits':>8} | {'Power of 2':>10}")
    print("-" * 60)

    power = 0
    n = 1
    while n <= limit:
        bits = max(8, limit.bit_length())
        binary = to_binary(n, bits)
        set_bits = bin(n).count('1')
        print(f"{n:>6} | {binary:>16} | {set_bits:>8} | 2^{power}")
        n <<= 1
        power += 1


def visualize_non_powers(limit: int = 16) -> None:
    """Visualize non-powers of 2 and why they fail."""
    print("\nNon-Powers of 2")
    print("=" * 70)
    print(f"{'n':>4} | {'Binary':>10} | {'n-1':>4} | {'(n-1) Binary':>10} | {'n & (n-1)':>10}")
    print("-" * 70)

    for n in range(2, limit + 1):
        if not is_power_of_two(n):
            binary_n = to_binary(n, 8)
            binary_n_1 = to_binary(n - 1, 8)
            result = n & (n - 1)
            binary_result = to_binary(result, 8)
            print(f"{n:>4} | {binary_n:>10} | {n-1:>4} | {binary_n_1:>10} | {binary_result:>10} = {result}")


# =============================================================================
# DEMONSTRATION
# =============================================================================

def demonstrate():
    """Demonstrate all approaches with examples."""
    test_values = [1, 2, 3, 4, 6, 8, 15, 16, 32, 64, 100]

    print("=" * 70)
    print("CHECK IF NUMBER IS POWER OF TWO")
    print("=" * 70)

    # Quick comparison
    print("\n{:<8} {:<12} {:<10} {:<10} {:<10}".format(
        "n", "Binary", "n&(n-1)", "Divide", "Count"
    ))
    print("-" * 55)

    for n in test_values:
        m1 = is_power_of_two(n)
        m2 = is_power_of_two_divide(n)
        m3 = is_power_of_two_count_bits(n)
        power_str = f"2^{get_power(n)}" if m1 else "-"
        print(f"{n:<8} {to_binary(n):<12} {str(m1):<10} {str(m2):<10} {str(m3):<10} {power_str}")

    # Visualizations
    visualize_powers_of_two(64)
    visualize_non_powers(16)

    # Detailed walkthrough
    print("\n" + "=" * 70)
    print("DETAILED WALKTHROUGH")
    print("=" * 70)

    is_power_of_two_verbose(16)
    is_power_of_two_verbose(12)


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Run test cases."""
    test_cases = [
        (0, False),
        (1, True),   # 2^0
        (2, True),   # 2^1
        (3, False),
        (4, True),   # 2^2
        (6, False),
        (8, True),   # 2^3
        (16, True),  # 2^4
        (15, False),
        (64, True),  # 2^6
        (100, False),
        (1024, True),  # 2^10
    ]

    print("\n" + "=" * 50)
    print("RUNNING TEST CASES")
    print("=" * 50)

    all_passed = True
    for n, expected in test_cases:
        m1 = is_power_of_two(n)
        m2 = is_power_of_two_isolate(n)
        m3 = is_power_of_two_divide(n)

        status = "PASS" if m1 == m2 == m3 == expected else "FAIL"
        if status == "FAIL":
            all_passed = False

        print(f"n={n:5d} -> Expected: {str(expected):<6} Got: {str(m1):<6} [{status}]")

    print("-" * 50)
    print("All tests passed!" if all_passed else "Some tests failed!")


if __name__ == "__main__":
    demonstrate()
    run_tests()
