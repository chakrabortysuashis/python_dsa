# Calculate Square Without *, / and pow()

## Problem Statement
Given a number n, calculate n^2 (n squared) without using multiplication (*), division (/), or the pow() function.

### Examples
```
Input: n = 5
Output: 25

Input: n = 12
Output: 144

Input: n = -7
Output: 49
```

---

## Approaches

### Approach 1: Repeated Addition
n^2 = n + n + n + ... (n times)

```
5^2 = 5 + 5 + 5 + 5 + 5 = 25
```

Time: O(n) - Simple but slow for large n

---

### Approach 2: Bit Manipulation (Optimal)

**Key Insight:** Multiplication can be done using bit shifts and addition!

```
n * n can be computed by considering n as sum of powers of 2.

If n = 5 = 101 in binary = 2^2 + 2^0 = 4 + 1

Then n * n = n * (4 + 1) = n*4 + n*1 = (n << 2) + (n << 0)
           = (5 << 2) + (5 << 0)
           = 20 + 5
           = 25
```

---

## Algorithm

```python
def square(n):
    n = abs(n)  # Square of negative is positive
    result = 0
    temp = n    # This will be shifted
    
    while n > 0:
        if n & 1:  # If current bit is set
            result += temp  # Add shifted value
        temp <<= 1   # Double temp (equivalent to temp * 2)
        n >>= 1      # Move to next bit
    
    return result
```

---

## Dry Run: n = 5

```
n = 5 = 101 in binary
We want to compute 5 * 5 = 25

Initial: result = 0, temp = 5, n = 5

=== Iteration 1 ===
n = 5 = 101

Is bit 0 set? 5 & 1 = 1 (Yes)
  result = 0 + 5 = 5

Shift: temp = 5 << 1 = 10
Shift: n = 5 >> 1 = 2

=== Iteration 2 ===
n = 2 = 010

Is bit 0 set? 2 & 1 = 0 (No)
  result stays 5

Shift: temp = 10 << 1 = 20
Shift: n = 2 >> 1 = 1

=== Iteration 3 ===
n = 1 = 001

Is bit 0 set? 1 & 1 = 1 (Yes)
  result = 5 + 20 = 25

Shift: temp = 20 << 1 = 40
Shift: n = 1 >> 1 = 0

n = 0, stop!

RESULT: 25
```

---

## Mathematical Explanation

```
For n = 5 = 101 (binary):
  5 = 2^2 + 2^0 = 4 + 1

5^2 = 5 * 5
    = 5 * (2^2 + 2^0)
    = 5 * 2^2 + 5 * 2^0
    = (5 << 2) + (5 << 0)
    = 20 + 5
    = 25

In general:
If n = sum of 2^i for all set bits i
Then n * n = sum of (n << i) for all set bits i
```

---

## Approach 3: Using Math Identity

**Identity:** n^2 = 1 + 3 + 5 + 7 + ... (sum of first n odd numbers)

```
1^2 = 1 = 1
2^2 = 4 = 1 + 3
3^2 = 9 = 1 + 3 + 5
4^2 = 16 = 1 + 3 + 5 + 7
5^2 = 25 = 1 + 3 + 5 + 7 + 9
```

Time: O(n), but interesting mathematical approach!

---

## Binary Visualization

```
Computing 12^2:

12 = 1100 in binary = 8 + 4

12 * 12 = 12 * 8 + 12 * 4
        = (12 << 3) + (12 << 2)
        = 96 + 48
        = 144

Step by step:
  n = 12 = 1100

  Bit 0 (value 1): not set
  Bit 1 (value 2): not set
  Bit 2 (value 4): SET -> add 12 << 2 = 48
  Bit 3 (value 8): SET -> add 12 << 3 = 96

  Total = 48 + 96 = 144
```

---

## Complexity Analysis

| Approach | Time | Space |
|----------|------|-------|
| Repeated Addition | O(n) | O(1) |
| Bit Manipulation | O(log n) | O(1) |
| Odd Numbers Sum | O(n) | O(1) |

Bit manipulation is the most efficient!

---

## Edge Cases

1. **n = 0**: Return 0
2. **n = 1**: Return 1
3. **Negative n**: Square is always positive, use abs(n)
4. **Large n**: Watch for overflow in result

---

## Generalization: Multiply Two Numbers

The same technique works for multiplying any two numbers:

```python
def multiply(a, b):
    result = 0
    while b > 0:
        if b & 1:
            result += a
        a <<= 1
        b >>= 1
    return result
```

Square is just multiply(n, n)!

---

## Related Problems

1. **Multiply without *** - Same bit shifting technique
2. **Power of n** - Extend to n^k using repeated squaring
3. **Division without /** - Similar bit manipulation approach
