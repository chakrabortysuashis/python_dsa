"""
Calculate Square Without *, / and pow()
=======================================

Problem: Calculate n^2 without using multiplication, division, or pow().

Example:
    Input: n = 5
    Output: 25
"""


def to_binary(n: int, bits: int = 8) -> str:
    """Convert integer to binary string for visualization."""
    if n >= 0:
        return bin(n)[2:].zfill(bits)
    return bin(n & ((1 << bits) - 1))[2:]


# =============================================================================
# APPROACH 1: Repeated Addition
# =============================================================================

def square_repeated_addition(n: int) -> int:
    """
    Calculate square using repeated addition.

    n^2 = n + n + n + ... (n times)

    Time Complexity: O(n)
    Space Complexity: O(1)

    Example:
        >>> square_repeated_addition(5)
        25
    """
    n = abs(n)  # Square is always positive
    result = 0
    for _ in range(n):
        result += n
    return result


# =============================================================================
# APPROACH 2: Bit Manipulation (Optimal)
# =============================================================================

def square(n: int) -> int:
    """
    Calculate square using bit manipulation.

    Key Insight:
        If n = sum of 2^i for all set bits i
        Then n * n = sum of (n << i) for all set bits i

    Example:
        5 = 101 = 4 + 1
        5 * 5 = 5*4 + 5*1 = (5<<2) + (5<<0) = 20 + 5 = 25

    Time Complexity: O(log n)
    Space Complexity: O(1)

    Example:
        >>> square(5)
        25
        >>> square(-7)
        49
    """
    n = abs(n)  # Square is always positive
    result = 0
    temp = n    # Will be shifted left

    while n > 0:
        if n & 1:       # If current bit is set
            result += temp  # Add shifted value
        temp <<= 1      # Double temp (temp * 2)
        n >>= 1         # Move to next bit

    return result


def square_verbose(n: int) -> int:
    """Calculate square with detailed visualization."""
    print(f"\nCalculating {n}^2 using bit manipulation")
    print("=" * 60)

    original_n = n
    n = abs(n)
    bits = max(8, n.bit_length() + 1)

    print(f"\nn = {n} = {to_binary(n, bits)}")
    print(f"\nWe compute n * n by considering n as sum of powers of 2:")

    # Find set bits
    set_bits = []
    temp_n = n
    pos = 0
    while temp_n > 0:
        if temp_n & 1:
            set_bits.append(pos)
        temp_n >>= 1
        pos += 1

    print(f"n = {' + '.join([f'2^{b}' for b in set_bits])}")
    print(f"n * n = {' + '.join([f'(n << {b})' for b in set_bits])}")

    # Calculate
    result = 0
    temp = n
    current_n = n
    iteration = 0

    print(f"\nStep-by-step calculation:")
    print("-" * 50)

    while current_n > 0:
        iteration += 1
        bit_set = current_n & 1

        print(f"\nIteration {iteration}:")
        print(f"  n = {current_n} = {to_binary(current_n, bits)}")
        print(f"  Is bit 0 set? {current_n} & 1 = {bit_set}", end="")

        if bit_set:
            print(f" (YES)")
            print(f"    result = {result} + {temp} = {result + temp}")
            result += temp
        else:
            print(f" (NO)")
            print(f"    result stays {result}")

        print(f"  temp = {temp} << 1 = {temp << 1}")
        print(f"  n = {current_n} >> 1 = {current_n >> 1}")

        temp <<= 1
        current_n >>= 1

    print(f"\nn = 0, stop!")
    print(f"\n" + "=" * 60)
    print(f"RESULT: {original_n}^2 = {result}")
    return result


# =============================================================================
# APPROACH 3: Sum of Odd Numbers
# =============================================================================

def square_odd_numbers(n: int) -> int:
    """
    Calculate square using sum of first n odd numbers.

    Mathematical identity: n^2 = 1 + 3 + 5 + 7 + ... (n terms)

    Time Complexity: O(n)
    Space Complexity: O(1)

    Example:
        >>> square_odd_numbers(5)
        25
    """
    n = abs(n)
    result = 0
    odd = 1

    for _ in range(n):
        result += odd
        odd += 2  # Next odd number

    return result


# =============================================================================
# GENERALIZATION: Multiply Two Numbers
# =============================================================================

def multiply(a: int, b: int) -> int:
    """
    Multiply two numbers without using * operator.

    Same technique as square, but with two different numbers.

    Time Complexity: O(log(min(a, b)))
    Space Complexity: O(1)

    Example:
        >>> multiply(7, 8)
        56
    """
    # Handle signs
    negative = (a < 0) != (b < 0)
    a, b = abs(a), abs(b)

    result = 0
    while b > 0:
        if b & 1:
            result += a
        a <<= 1
        b >>= 1

    return -result if negative else result


def multiply_verbose(a: int, b: int) -> int:
    """Multiply with detailed visualization."""
    print(f"\nCalculating {a} * {b}")
    print("=" * 50)

    negative = (a < 0) != (b < 0)
    orig_a, orig_b = a, b
    a, b = abs(a), abs(b)
    bits = max(8, max(a.bit_length(), b.bit_length()) + 1)

    print(f"\na = {a} = {to_binary(a, bits)}")
    print(f"b = {b} = {to_binary(b, bits)}")

    result = 0
    iteration = 0

    while b > 0:
        iteration += 1
        bit_set = b & 1

        print(f"\nIteration {iteration}: b = {to_binary(b, bits)}")
        if bit_set:
            print(f"  Bit 0 is SET, add a = {a}")
            print(f"  result = {result} + {a} = {result + a}")
            result += a
        else:
            print(f"  Bit 0 is NOT set, skip")

        a <<= 1
        b >>= 1

    if negative:
        result = -result

    print(f"\n" + "=" * 50)
    print(f"RESULT: {orig_a} * {orig_b} = {result}")
    return result


# =============================================================================
# DEMONSTRATION
# =============================================================================

def demonstrate():
    """Demonstrate all approaches."""
    test_values = [0, 1, 5, 7, 12, -3, 10]

    print("=" * 70)
    print("CALCULATE SQUARE WITHOUT *, / AND pow()")
    print("=" * 70)

    print("\n{:<8} {:<15} {:<12} {:<12} {:<12}".format(
        "n", "Binary", "Repeated", "BitManip", "OddNums"
    ))
    print("-" * 60)

    for n in test_values:
        m1 = square_repeated_addition(n)
        m2 = square(n)
        m3 = square_odd_numbers(n)
        binary = to_binary(abs(n), 8)
        print(f"{n:<8} {binary:<15} {m1:<12} {m2:<12} {m3:<12}")

    # Detailed walkthrough
    print("\n" + "=" * 70)
    print("DETAILED WALKTHROUGH")
    print("=" * 70)

    square_verbose(5)
    square_verbose(12)

    # Multiplication example
    print("\n" + "=" * 70)
    print("BONUS: MULTIPLICATION WITHOUT *")
    print("=" * 70)

    multiply_verbose(7, 8)


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Run test cases."""
    test_cases = [
        (0, 0),
        (1, 1),
        (5, 25),
        (7, 49),
        (12, 144),
        (-3, 9),
        (-10, 100),
        (100, 10000),
    ]

    print("\n" + "=" * 50)
    print("RUNNING TEST CASES")
    print("=" * 50)

    all_passed = True
    for n, expected in test_cases:
        m1 = square(n)
        m2 = square_repeated_addition(n)
        m3 = square_odd_numbers(n)

        status = "PASS" if m1 == m2 == m3 == expected else "FAIL"
        if status == "FAIL":
            all_passed = False

        print(f"n={n:4d} -> Expected: {expected:6d}, Got: {m1:6d} [{status}]")

    print("-" * 50)
    print("All tests passed!" if all_passed else "Some tests failed!")


if __name__ == "__main__":
    demonstrate()
    run_tests()
