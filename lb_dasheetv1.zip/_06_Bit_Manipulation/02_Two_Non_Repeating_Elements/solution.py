"""
Find Two Non-Repeating Elements
===============================

Problem: Given an array where every element appears twice except for
two elements that appear only once, find those two non-repeating elements.

Example:
    Input: [1, 2, 3, 2, 1, 4]
    Output: (3, 4)
"""


def to_binary(n: int, bits: int = 8) -> str:
    """Convert integer to binary string for visualization."""
    if n >= 0:
        return bin(n)[2:].zfill(bits)
    return bin(n & ((1 << bits) - 1))[2:]


# =============================================================================
# APPROACH 1: Brute Force - Using Hash Map
# =============================================================================

def find_two_singles_bruteforce(arr: list) -> tuple:
    """
    Find two non-repeating elements using hash map.

    Algorithm:
        1. Count frequency of each element
        2. Return elements with frequency 1

    Time Complexity: O(n)
    Space Complexity: O(n)

    Args:
        arr: Array with two unique elements

    Returns:
        Tuple of two non-repeating elements

    Example:
        >>> find_two_singles_bruteforce([1, 2, 3, 2, 1, 4])
        (3, 4)
    """
    from collections import Counter
    count = Counter(arr)
    result = [num for num, freq in count.items() if freq == 1]
    return tuple(result)


# =============================================================================
# APPROACH 2: XOR with Bit Separation (Optimal)
# =============================================================================

def find_two_singles_xor(arr: list) -> tuple:
    """
    Find two non-repeating elements using XOR and bit manipulation.

    Algorithm:
        1. XOR all elements to get a ^ b (where a, b are the two singles)
        2. Find rightmost set bit (differentiating bit)
        3. Divide elements into two groups based on this bit
        4. XOR each group to find a and b

    Time Complexity: O(n)
    Space Complexity: O(1)

    Why it works:
        - Pairs of same numbers cancel out (a ^ a = 0)
        - a and b differ in at least one bit
        - That bit separates them into different groups

    Args:
        arr: Array with two unique elements

    Returns:
        Tuple of two non-repeating elements

    Example:
        >>> find_two_singles_xor([1, 2, 3, 2, 1, 4])
        (3, 4)
    """
    # Step 1: XOR all elements
    xor_all = 0
    for num in arr:
        xor_all ^= num
    # xor_all = a ^ b

    # Step 2: Find rightmost set bit
    # This bit is different in a and b
    rightmost_bit = xor_all & (-xor_all)

    # Step 3 & 4: Divide and XOR
    a, b = 0, 0
    for num in arr:
        if num & rightmost_bit:
            a ^= num  # Group with this bit set
        else:
            b ^= num  # Group with this bit not set

    return (a, b)


def find_two_singles_xor_verbose(arr: list) -> tuple:
    """XOR approach with detailed step-by-step visualization."""
    print(f"\nFinding two non-repeating elements in: {arr}")
    print("=" * 60)

    # Show binary representation of all elements
    print("\nBinary representations:")
    for num in arr:
        print(f"  {num:3d} = {to_binary(num)}")

    # Step 1: XOR all elements
    print("\n" + "-" * 60)
    print("STEP 1: XOR all elements")
    print("-" * 60)

    xor_all = 0
    xor_steps = []
    for i, num in enumerate(arr):
        prev_xor = xor_all
        xor_all ^= num
        xor_steps.append(f"  {to_binary(prev_xor)} ^ {to_binary(num)} = {to_binary(xor_all)}  ({prev_xor} ^ {num} = {xor_all})")

    for step in xor_steps:
        print(step)

    print(f"\nxor_all = {xor_all} = {to_binary(xor_all)}")
    print("This equals a ^ b (where a and b are the two unique elements)")

    # Step 2: Find rightmost set bit
    print("\n" + "-" * 60)
    print("STEP 2: Find rightmost set bit (differentiating bit)")
    print("-" * 60)

    rightmost_bit = xor_all & (-xor_all)
    print(f"  xor_all     = {xor_all:4d} = {to_binary(xor_all)}")
    print(f"  -xor_all    = {-xor_all & 255:4d} = {to_binary(-xor_all)}")
    print(f"  rightmost   = {rightmost_bit:4d} = {to_binary(rightmost_bit)}")

    # Find position of rightmost bit
    pos = 0
    temp = rightmost_bit
    while temp > 1:
        temp >>= 1
        pos += 1
    print(f"\nDifferentiating bit position: {pos}")

    # Step 3: Divide into groups
    print("\n" + "-" * 60)
    print("STEP 3: Divide elements into two groups based on bit", pos)
    print("-" * 60)

    group_a = []  # Bit is set
    group_b = []  # Bit is not set

    print(f"\n{'Number':^8} | {'Binary':^10} | {'Bit '+str(pos):^6} | {'Group':^8}")
    print("-" * 40)

    for num in arr:
        bit_value = 1 if num & rightmost_bit else 0
        group = "A (set)" if bit_value else "B (unset)"
        print(f"{num:^8} | {to_binary(num):^10} | {bit_value:^6} | {group:^8}")

        if num & rightmost_bit:
            group_a.append(num)
        else:
            group_b.append(num)

    print(f"\nGroup A (bit {pos} set): {group_a}")
    print(f"Group B (bit {pos} not set): {group_b}")

    # Step 4: XOR each group
    print("\n" + "-" * 60)
    print("STEP 4: XOR each group to find the unique elements")
    print("-" * 60)

    a, b = 0, 0
    print("\nGroup A XOR:")
    for num in group_a:
        print(f"  {a} ^ {num} = {a ^ num}")
        a ^= num

    print(f"Result a = {a}")

    print("\nGroup B XOR:")
    for num in group_b:
        print(f"  {b} ^ {num} = {b ^ num}")
        b ^= num

    print(f"Result b = {b}")

    print("\n" + "=" * 60)
    print(f"ANSWER: The two non-repeating elements are {a} and {b}")
    print("=" * 60)

    return (a, b)


# =============================================================================
# UNDERSTANDING THE KEY INSIGHT
# =============================================================================

def explain_rightmost_bit_trick(xor_all: int) -> None:
    """Explain why n & (-n) gives the rightmost set bit."""
    print(f"\nWhy does n & (-n) give the rightmost set bit?")
    print("=" * 50)
    print(f"\nn = {xor_all} = {to_binary(xor_all)}")
    print(f"\nIn two's complement, -n is computed as:")
    print("  1. Invert all bits of n")
    print("  2. Add 1")

    inverted = ~xor_all & 0xFF
    negated = (-xor_all) & 0xFF

    print(f"\n  n         = {to_binary(xor_all)}")
    print(f"  ~n        = {to_binary(inverted)}")
    print(f"  ~n + 1    = {to_binary(negated)} (this is -n)")

    result = xor_all & negated
    print(f"\n  n & (-n)  = {to_binary(xor_all)} & {to_binary(negated)}")
    print(f"            = {to_binary(result)} = {result}")

    print(f"\nThis isolates the rightmost set bit!")
    print("The rightmost 1 and all bits to its right flip in -n,")
    print("but AND preserves only the rightmost 1 position.")


# =============================================================================
# DEMONSTRATION
# =============================================================================

def demonstrate():
    """Demonstrate the algorithm with various examples."""
    test_cases = [
        [1, 2, 3, 2, 1, 4],
        [2, 4, 7, 9, 2, 4],
        [1, 2],
        [5, 3, 5, 7, 7, 8],
    ]

    print("=" * 70)
    print("FIND TWO NON-REPEATING ELEMENTS")
    print("=" * 70)

    # Quick comparison
    print("\n{:<25} {:<15} {:<15}".format("Array", "Hash Map", "XOR Method"))
    print("-" * 60)

    for arr in test_cases:
        hm = find_two_singles_bruteforce(arr)
        xor = find_two_singles_xor(arr)
        print(f"{str(arr):<25} {str(hm):<15} {str(xor):<15}")

    # Detailed walkthrough
    print("\n" + "=" * 70)
    print("DETAILED WALKTHROUGH")
    print("=" * 70)

    find_two_singles_xor_verbose([1, 2, 3, 2, 1, 4])

    # Explain the rightmost bit trick
    explain_rightmost_bit_trick(7)


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Run test cases."""
    test_cases = [
        ([1, 2, 3, 2, 1, 4], {3, 4}),
        ([2, 4, 7, 9, 2, 4], {7, 9}),
        ([1, 2], {1, 2}),
        ([5, 3, 5, 7, 7, 8], {3, 8}),
        ([10, 20, 30, 20, 10, 40], {30, 40}),
    ]

    print("\n" + "=" * 50)
    print("RUNNING TEST CASES")
    print("=" * 50)

    all_passed = True
    for arr, expected in test_cases:
        result = find_two_singles_xor(arr)
        result_set = set(result)

        status = "PASS" if result_set == expected else "FAIL"
        if status == "FAIL":
            all_passed = False

        print(f"Array: {arr}")
        print(f"  Expected: {expected}, Got: {result_set} [{status}]")

    print("-" * 50)
    print("All tests passed!" if all_passed else "Some tests failed!")


if __name__ == "__main__":
    demonstrate()
    run_tests()
