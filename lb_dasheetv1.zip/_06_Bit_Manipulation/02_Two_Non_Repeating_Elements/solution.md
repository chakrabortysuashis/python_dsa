# Find the Two Non-Repeating Elements

## Problem Statement
Given an array where every element appears **twice** except for **two elements** that appear only once, find those two non-repeating elements.

### Examples
```
Input: arr = [1, 2, 3, 2, 1, 4]
Output: 3, 4
Explanation: All elements appear twice except 3 and 4

Input: arr = [2, 4, 7, 9, 2, 4]
Output: 7, 9

Input: arr = [1, 2]
Output: 1, 2
```

---

## Binary Representation Visualization

```
Array: [1, 2, 3, 2, 1, 4]

Binary representations:
1 = 001
2 = 010
3 = 011  <- unique
2 = 010
1 = 001
4 = 100  <- unique

XOR of all: 001 ^ 010 ^ 011 ^ 010 ^ 001 ^ 100
         = (001 ^ 001) ^ (010 ^ 010) ^ 011 ^ 100
         = 0 ^ 0 ^ 011 ^ 100
         = 111 (= 7 = 3 ^ 4)
```

---

## Intuition

### Key XOR Properties
1. `a ^ a = 0` (same numbers cancel out)
2. `a ^ 0 = a` (XOR with 0 gives itself)
3. XOR is commutative and associative

### The Challenge
If we XOR all elements, we get `a ^ b` (where a and b are the two unique elements). But how do we separate them?

### Key Insight
Since `a != b`, there's at least one bit position where they differ. In `a ^ b`, this bit will be 1.

```
If a = 3 (011) and b = 4 (100):
a ^ b = 111

At position 0: a has 1, b has 0 (different)
At position 1: a has 1, b has 0 (different)
At position 2: a has 0, b has 1 (different)
```

We can use ANY of these differentiating bits to separate all numbers into two groups:
- Group 1: Numbers with this bit SET
- Group 2: Numbers with this bit NOT SET

Each unique element will be in a different group!

---

## Algorithm: XOR with Bit Separation

### Step-by-Step Algorithm
1. XOR all elements to get `xor_all = a ^ b`
2. Find rightmost set bit in `xor_all` (the differentiating bit)
3. Divide elements into two groups based on this bit
4. XOR each group separately to find a and b

### Detailed Walkthrough

```
Array: [1, 2, 3, 2, 1, 4]

Step 1: XOR all elements
-----------------------
1 ^ 2 ^ 3 ^ 2 ^ 1 ^ 4 = 7 (binary: 111)

This is 3 ^ 4 = 011 ^ 100 = 111


Step 2: Find rightmost set bit
------------------------------
xor_all = 7 = 111
rightmost_bit = 7 & (-7) = 7 & (...11111001)
              = 001 = 1

Position 0 is our differentiating bit!


Step 3: Divide into groups
--------------------------
Check bit 0 for each element:

Number | Binary | Bit 0 | Group
-------|--------|-------|-------
  1    |  001   |   1   | Group A (bit set)
  2    |  010   |   0   | Group B (bit not set)
  3    |  011   |   1   | Group A (bit set)
  2    |  010   |   0   | Group B (bit not set)
  1    |  001   |   1   | Group A (bit set)
  4    |  100   |   0   | Group B (bit not set)

Group A: [1, 3, 1]  -> contains unique element 3
Group B: [2, 2, 4]  -> contains unique element 4


Step 4: XOR each group
----------------------
Group A: 1 ^ 3 ^ 1 = (1^1) ^ 3 = 0 ^ 3 = 3
Group B: 2 ^ 2 ^ 4 = (2^2) ^ 4 = 0 ^ 4 = 4

Answer: 3 and 4
```

---

## Why Does This Work?

### Key Observations

1. **Pairs stay together**: If a number appears twice, both copies have the same bit value, so they go to the SAME group. When we XOR the group, they cancel out.

2. **Unique elements separate**: Since a and b differ at this bit position, they go to DIFFERENT groups.

3. **Each group has one unique**: After pairs cancel, each group's XOR gives its unique element.

```
Visual proof:

          All Elements
         /            \
    Bit=1              Bit=0
   (Group A)          (Group B)
   [1,3,1]            [2,2,4]
     |                   |
   1^3^1              2^2^4
     |                   |
   (1^1)^3            (2^2)^4
     |                   |
     3                   4
```

---

## Complexity Analysis

| Metric | Value | Explanation |
|--------|-------|-------------|
| Time | O(n) | Two passes through array |
| Space | O(1) | Only a few variables |

---

## Edge Cases

1. **Array with only 2 elements**: Direct XOR gives each element
2. **Large numbers**: Algorithm still works (bit operations are O(1))
3. **Negative numbers**: Two's complement handles this correctly

---

## Why Use Rightmost Set Bit?

We could use ANY set bit in `xor_all`, but rightmost is easiest to find:

```python
rightmost_bit = xor_all & (-xor_all)
```

This works because:
- `-xor_all` in two's complement flips all bits and adds 1
- AND with original isolates the rightmost 1

```
xor_all =  7 = 00000111
-xor_all = -7 = 11111001 (two's complement)
AND         = 00000001
```

---

## Related Problems

1. **Single non-repeating element** - Simple XOR of all
2. **Three non-repeating elements** - More complex approach needed
3. **Element appearing once in array of 3s** - Bit counting approach

---

## Common Mistakes

1. **Forgetting to initialize XOR to 0**
2. **Using wrong bit for separation** - Any set bit works, but must be consistent
3. **Not handling the case where xor_all is 0** - Impossible if two unique elements exist
