# Count Bits to Flip to Convert A to B

## Problem Statement
Given two integers A and B, count the number of bits that need to be flipped (changed from 0 to 1 or 1 to 0) to convert A to B.

**Also known as:** Hamming Distance

### Examples
```
Input: A = 10, B = 20
Output: 4
Explanation:
  A = 10 = 01010
  B = 20 = 10100
  Bits that differ: 4 positions

Input: A = 7, B = 10
Output: 3
Explanation:
  A = 7  = 0111
  B = 10 = 1010
  Bits that differ: 3 positions
```

---

## Binary Representation Visualization

```
A = 10, B = 20

A (10):  0 1 0 1 0
B (20):  1 0 1 0 0
         ^ ^ ^ ^
         |_|_|_|_____ 4 bits differ!

XOR:     1 1 1 1 0  = 30 (has 4 set bits)
```

---

## Intuition

### Key Insight: XOR reveals differences!

When we XOR two numbers:
- Same bits → 0
- Different bits → 1

```
A = 0 1 0 1 0
B = 1 0 1 0 0
    ---------
A^B= 1 1 1 1 0

The 1s in A^B mark positions where A and B differ!
```

Therefore: **Count of bits to flip = Count of set bits in A XOR B**

---

## Algorithm

### Step-by-Step
1. XOR A and B to get positions where they differ
2. Count set bits in the XOR result (using Brian Kernighan's algorithm)

```
Step 1: XOR
  A    = 01010
  B    = 10100
  XOR  = 11110 = 30

Step 2: Count set bits in 30
  30 = 11110 (4 set bits)

Answer: 4 bits need to be flipped
```

---

## Dry Run: A = 7, B = 10

```
Step 1: Calculate XOR
-----------------------
A = 7  = 0111
B = 10 = 1010
-----------
XOR    = 1101 = 13

Step 2: Count set bits in 13 using Brian Kernighan's
--------------------------------------------------------

n = 13 = 1101

Iteration 1:
  n     = 1101
  n - 1 = 1100
  n & (n-1) = 1100 = 12
  count = 1

Iteration 2:
  n     = 1100
  n - 1 = 1011
  n & (n-1) = 1000 = 8
  count = 2

Iteration 3:
  n     = 1000
  n - 1 = 0111
  n & (n-1) = 0000 = 0
  count = 3

n = 0, STOP!

Answer: 3 bits need to be flipped
```

---

## Visual Comparison

```
A = 7:   0 1 1 1
         │ │ │ │
B = 10:  1 0 1 0
         ↓ ↓   ↓
Change:  ✓ ✓   ✓   (3 changes needed)

Position: 3 2 1 0
A bit:    0 1 1 1
B bit:    1 0 1 0
Differ?   Y Y N Y  → 3 differences
```

---

## Complexity Analysis

| Metric | Value | Explanation |
|--------|-------|-------------|
| Time | O(k) | k = number of differing bits |
| Space | O(1) | Only using a few variables |

**Note:** Using naive bit counting would be O(log n), but Kernighan's algorithm gives O(k) where k is the number of set bits in XOR result.

---

## Edge Cases

1. **A = B**: XOR = 0, no bits to flip
2. **A = 0, B = all 1s**: Maximum bits to flip
3. **Negative numbers**: Algorithm works with two's complement

---

## Code Explanation

```python
def count_bits_to_flip(a, b):
    # Step 1: XOR to find differing positions
    xor = a ^ b
    
    # Step 2: Count set bits (Brian Kernighan's)
    count = 0
    while xor:
        xor = xor & (xor - 1)  # Clear rightmost set bit
        count += 1
    
    return count
```

---

## Why XOR Works

| A bit | B bit | A XOR B | Need to flip? |
|-------|-------|---------|---------------|
| 0 | 0 | 0 | No |
| 0 | 1 | 1 | Yes |
| 1 | 0 | 1 | Yes |
| 1 | 1 | 0 | No |

XOR gives 1 exactly when the bits are different (need flipping)!

---

## Related Problems

1. **Hamming Weight** - Count set bits in single number
2. **Minimum bit flips to make string palindrome**
3. **Edit distance for binary strings**
