"""
Count Bits to Flip to Convert A to B
====================================

Problem: Given two integers A and B, count the number of bits that need
to be flipped to convert A to B. Also known as Hamming Distance.

Example:
    Input: A = 10, B = 20
    Output: 4
    Explanation: 10 = 01010, 20 = 10100, differ at 4 positions
"""


def to_binary(n: int, bits: int = 8) -> str:
    """Convert integer to binary string for visualization."""
    if n >= 0:
        return bin(n)[2:].zfill(bits)
    return bin(n & ((1 << bits) - 1))[2:]


# =============================================================================
# APPROACH 1: Brute Force - Check Each Bit Position
# =============================================================================

def count_bits_to_flip_bruteforce(a: int, b: int) -> int:
    """
    Count differing bits by checking each position.

    Algorithm:
        1. For each bit position
        2. Check if bits at that position differ
        3. Count differences

    Time Complexity: O(max_bits) - typically 32 or 64
    Space Complexity: O(1)

    Args:
        a: First integer
        b: Second integer

    Returns:
        Number of bits that differ (Hamming distance)

    Example:
        >>> count_bits_to_flip_bruteforce(10, 20)
        4
    """
    count = 0
    # Check each bit position
    while a > 0 or b > 0:
        # Check if LSB differs
        if (a & 1) != (b & 1):
            count += 1
        a >>= 1
        b >>= 1
    return count


# =============================================================================
# APPROACH 2: XOR + Count Set Bits (Optimal)
# =============================================================================

def count_bits_to_flip(a: int, b: int) -> int:
    """
    Count bits to flip using XOR and Brian Kernighan's algorithm.

    Algorithm:
        1. XOR a and b to get positions where they differ
        2. Count set bits in XOR result

    Why XOR works:
        - XOR gives 1 where bits are different
        - XOR gives 0 where bits are same
        - So set bits in XOR = positions that need flipping

    Time Complexity: O(k) where k = number of differing bits
    Space Complexity: O(1)

    Args:
        a: First integer
        b: Second integer

    Returns:
        Number of bits that need to be flipped

    Example:
        >>> count_bits_to_flip(10, 20)
        4
        >>> count_bits_to_flip(7, 10)
        3
    """
    # Step 1: XOR to find differing positions
    xor = a ^ b

    # Step 2: Count set bits using Brian Kernighan's algorithm
    count = 0
    while xor:
        xor = xor & (xor - 1)  # Clear rightmost set bit
        count += 1

    return count


def count_bits_to_flip_verbose(a: int, b: int) -> int:
    """Count bits to flip with detailed step-by-step visualization."""
    print(f"\nCounting bits to flip from A={a} to B={b}")
    print("=" * 60)

    # Show binary representations
    max_bits = max(a.bit_length(), b.bit_length(), 1)
    bits = max(8, max_bits)

    print(f"\nBinary representations ({bits}-bit):")
    print(f"  A = {a:4d} = {to_binary(a, bits)}")
    print(f"  B = {b:4d} = {to_binary(b, bits)}")

    # Step 1: XOR
    print("\n" + "-" * 60)
    print("STEP 1: XOR A and B")
    print("-" * 60)

    xor = a ^ b
    print(f"  A     = {to_binary(a, bits)}")
    print(f"  B     = {to_binary(b, bits)}")
    print(f"  " + "-" * (bits + 8))
    print(f"  A ^ B = {to_binary(xor, bits)} = {xor}")

    # Show which bits differ
    diff_positions = []
    a_bin = to_binary(a, bits)
    b_bin = to_binary(b, bits)

    print("\n  Comparison:")
    print(f"  Position:  ", end="")
    for i in range(bits - 1, -1, -1):
        print(f"{i} ", end="")
    print()

    print(f"  A bits:    ", end="")
    for bit in a_bin:
        print(f"{bit} ", end="")
    print()

    print(f"  B bits:    ", end="")
    for bit in b_bin:
        print(f"{bit} ", end="")
    print()

    print(f"  Different: ", end="")
    for i in range(bits):
        if a_bin[i] != b_bin[i]:
            print("^ ", end="")
            diff_positions.append(bits - 1 - i)
        else:
            print("  ", end="")
    print()

    print(f"\n  Positions that differ: {diff_positions}")

    # Step 2: Count set bits
    print("\n" + "-" * 60)
    print("STEP 2: Count set bits in XOR result using Brian Kernighan's")
    print("-" * 60)

    count = 0
    iteration = 0
    current_xor = xor

    if current_xor == 0:
        print("  XOR is 0, no bits to flip!")
    else:
        while current_xor:
            iteration += 1
            prev = current_xor
            current_xor = current_xor & (current_xor - 1)
            count += 1

            print(f"\n  Iteration {iteration}:")
            print(f"    n     = {prev:4d} = {to_binary(prev, bits)}")
            print(f"    n - 1 = {prev - 1:4d} = {to_binary(prev - 1, bits)}")
            print(f"    n & (n-1) = {current_xor:4d} = {to_binary(current_xor, bits)}")
            print(f"    count = {count}")

    print("\n" + "=" * 60)
    print(f"ANSWER: {count} bits need to be flipped to convert {a} to {b}")
    print("=" * 60)

    return count


# =============================================================================
# APPROACH 3: Using Built-in
# =============================================================================

def count_bits_to_flip_builtin(a: int, b: int) -> int:
    """
    Count bits to flip using Python's built-in bin().count().

    Example:
        >>> count_bits_to_flip_builtin(10, 20)
        4
    """
    return bin(a ^ b).count('1')


# =============================================================================
# VISUALIZATION HELPER
# =============================================================================

def visualize_bit_comparison(a: int, b: int) -> None:
    """Visualize which bits need to be flipped."""
    bits = max(8, max(a.bit_length(), b.bit_length()))
    a_bin = to_binary(a, bits)
    b_bin = to_binary(b, bits)

    print(f"\nVisual bit comparison (A={a} vs B={b}):")
    print("-" * (bits * 4 + 10))

    # Print headers
    print("Position:", end=" ")
    for i in range(bits - 1, -1, -1):
        print(f"  {i} ", end="")
    print()

    # Print A
    print(f"A = {a:4d}:", end=" ")
    for bit in a_bin:
        print(f"  {bit} ", end="")
    print()

    # Print B
    print(f"B = {b:4d}:", end=" ")
    for bit in b_bin:
        print(f"  {bit} ", end="")
    print()

    # Print differences
    print("Need flip:", end=" ")
    flip_count = 0
    for i in range(bits):
        if a_bin[i] != b_bin[i]:
            print("  * ", end="")
            flip_count += 1
        else:
            print("    ", end="")
    print()

    print("-" * (bits * 4 + 10))
    print(f"Total bits to flip: {flip_count}")


# =============================================================================
# DEMONSTRATION
# =============================================================================

def demonstrate():
    """Demonstrate all approaches with examples."""
    test_cases = [
        (10, 20),
        (7, 10),
        (0, 15),
        (255, 0),
        (42, 42),
    ]

    print("=" * 70)
    print("COUNT BITS TO FLIP (HAMMING DISTANCE)")
    print("=" * 70)

    # Quick comparison
    print("\n{:<8} {:<8} {:<12} {:<12} {:<10} {:<10}".format(
        "A", "B", "A (binary)", "B (binary)", "XOR", "Flips"
    ))
    print("-" * 70)

    for a, b in test_cases:
        xor_val = a ^ b
        flips = count_bits_to_flip(a, b)
        print(f"{a:<8} {b:<8} {to_binary(a):<12} {to_binary(b):<12} {to_binary(xor_val):<10} {flips:<10}")

    # Detailed walkthrough
    print("\n" + "=" * 70)
    print("DETAILED WALKTHROUGH")
    print("=" * 70)

    count_bits_to_flip_verbose(10, 20)
    visualize_bit_comparison(10, 20)


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Run test cases."""
    test_cases = [
        (10, 20, 4),
        (7, 10, 3),
        (0, 0, 0),
        (0, 15, 4),
        (255, 0, 8),
        (42, 42, 0),
        (1, 4, 2),
    ]

    print("\n" + "=" * 50)
    print("RUNNING TEST CASES")
    print("=" * 50)

    all_passed = True
    for a, b, expected in test_cases:
        result = count_bits_to_flip(a, b)
        builtin_result = count_bits_to_flip_builtin(a, b)

        status = "PASS" if result == expected == builtin_result else "FAIL"
        if status == "FAIL":
            all_passed = False

        print(f"A={a:3d}, B={b:3d} -> Expected: {expected}, Got: {result} [{status}]")

    print("-" * 50)
    print("All tests passed!" if all_passed else "Some tests failed!")


if __name__ == "__main__":
    demonstrate()
    run_tests()
