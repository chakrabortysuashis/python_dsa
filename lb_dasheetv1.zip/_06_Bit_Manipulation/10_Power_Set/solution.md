# Power Set (Generate All Subsets)

## Problem Statement
Given a set of distinct elements, generate all possible subsets (the power set).

### Examples
```
Input: [1, 2, 3]
Output: [[], [1], [2], [1,2], [3], [1,3], [2,3], [1,2,3]]

Input: [a, b]
Output: [[], [a], [b], [a,b]]
```

**Note:** For a set of n elements, the power set has 2^n subsets.

---

## Intuition: Bit Masking

### Key Insight
Each subset can be represented by a binary number where:
- Bit i = 1 means element i is in the subset
- Bit i = 0 means element i is NOT in the subset

```
For [1, 2, 3] with indices [0, 1, 2]:

Mask | Binary | Bit 2 | Bit 1 | Bit 0 | Subset
-----|--------|-------|-------|-------|--------
  0  |  000   |   0   |   0   |   0   | []
  1  |  001   |   0   |   0   |   1   | [1]
  2  |  010   |   0   |   1   |   0   | [2]
  3  |  011   |   0   |   1   |   1   | [1, 2]
  4  |  100   |   1   |   0   |   0   | [3]
  5  |  101   |   1   |   0   |   1   | [1, 3]
  6  |  110   |   1   |   1   |   0   | [2, 3]
  7  |  111   |   1   |   1   |   1   | [1, 2, 3]
```

---

## Algorithm

```python
def power_set(arr):
    n = len(arr)
    subsets = []
    
    # Iterate through all 2^n possible masks
    for mask in range(1 << n):  # 0 to 2^n - 1
        subset = []
        for i in range(n):
            # Check if bit i is set in mask
            if mask & (1 << i):
                subset.append(arr[i])
        subsets.append(subset)
    
    return subsets
```

---

## Dry Run: arr = [1, 2, 3]

```
n = 3, total subsets = 2^3 = 8

Mask = 0 (000):
  Check bit 0: 000 & 001 = 0 (not set)
  Check bit 1: 000 & 010 = 0 (not set)
  Check bit 2: 000 & 100 = 0 (not set)
  Subset: []

Mask = 1 (001):
  Check bit 0: 001 & 001 = 1 (SET) -> include arr[0] = 1
  Check bit 1: 001 & 010 = 0 (not set)
  Check bit 2: 001 & 100 = 0 (not set)
  Subset: [1]

Mask = 2 (010):
  Check bit 0: 010 & 001 = 0 (not set)
  Check bit 1: 010 & 010 = 2 (SET) -> include arr[1] = 2
  Check bit 2: 010 & 100 = 0 (not set)
  Subset: [2]

Mask = 3 (011):
  Check bit 0: 011 & 001 = 1 (SET) -> include arr[0] = 1
  Check bit 1: 011 & 010 = 2 (SET) -> include arr[1] = 2
  Check bit 2: 011 & 100 = 0 (not set)
  Subset: [1, 2]

Mask = 4 (100):
  Check bit 0: 100 & 001 = 0 (not set)
  Check bit 1: 100 & 010 = 0 (not set)
  Check bit 2: 100 & 100 = 4 (SET) -> include arr[2] = 3
  Subset: [3]

Mask = 5 (101):
  Check bit 0: 101 & 001 = 1 (SET) -> include arr[0] = 1
  Check bit 1: 101 & 010 = 0 (not set)
  Check bit 2: 101 & 100 = 4 (SET) -> include arr[2] = 3
  Subset: [1, 3]

Mask = 6 (110):
  Check bit 0: 110 & 001 = 0 (not set)
  Check bit 1: 110 & 010 = 2 (SET) -> include arr[1] = 2
  Check bit 2: 110 & 100 = 4 (SET) -> include arr[2] = 3
  Subset: [2, 3]

Mask = 7 (111):
  Check bit 0: 111 & 001 = 1 (SET) -> include arr[0] = 1
  Check bit 1: 111 & 010 = 2 (SET) -> include arr[1] = 2
  Check bit 2: 111 & 100 = 4 (SET) -> include arr[2] = 3
  Subset: [1, 2, 3]

Result: [[], [1], [2], [1,2], [3], [1,3], [2,3], [1,2,3]]
```

---

## Binary Visualization

```
Array: [A, B, C]
Indices: [0, 1, 2]

Each mask represents a subset:

     C B A
     | | |
0 =  0 0 0  ->  [        ]  (empty)
1 =  0 0 1  ->  [      A ]
2 =  0 1 0  ->  [   B    ]
3 =  0 1 1  ->  [   B, A ]
4 =  1 0 0  ->  [C       ]
5 =  1 0 1  ->  [C,    A ]
6 =  1 1 0  ->  [C, B    ]
7 =  1 1 1  ->  [C, B, A ]

Total: 2^3 = 8 subsets
```

---

## Complexity Analysis

| Metric | Value | Explanation |
|--------|-------|-------------|
| Time | O(n * 2^n) | 2^n subsets, each takes O(n) to build |
| Space | O(n * 2^n) | Storing all subsets |

**Note:** This is optimal - you can't do better since there are 2^n subsets to generate.

---

## Alternative Approaches

### 1. Recursive (Cascading)
```python
def power_set_recursive(arr):
    subsets = [[]]
    for num in arr:
        subsets += [subset + [num] for subset in subsets]
    return subsets
```

### 2. Backtracking
```python
def power_set_backtrack(arr):
    result = []
    def backtrack(start, current):
        result.append(current[:])
        for i in range(start, len(arr)):
            current.append(arr[i])
            backtrack(i + 1, current)
            current.pop()
    backtrack(0, [])
    return result
```

---

## Why Bit Masking is Elegant

1. **Direct mapping:** Each subset has unique binary representation
2. **No recursion:** Simple iterative approach
3. **Easy iteration:** Just count from 0 to 2^n - 1
4. **Checking inclusion:** Simple AND operation

---

## Applications

1. **Subset Sum Problem:** Check if any subset sums to target
2. **Traveling Salesman (small n):** DP with bitmask
3. **Set Cover:** Find minimum subsets that cover all elements
4. **Feature Selection:** Try all feature combinations

---

## Subset with Given Sum

```python
def subsets_with_sum(arr, target):
    n = len(arr)
    result = []
    
    for mask in range(1 << n):
        subset = []
        subset_sum = 0
        for i in range(n):
            if mask & (1 << i):
                subset.append(arr[i])
                subset_sum += arr[i]
        if subset_sum == target:
            result.append(subset)
    
    return result
```

---

## Edge Cases

1. **Empty array:** Return [[]] (one empty subset)
2. **Single element:** Return [[], [element]]
3. **Large n (n > 20):** May be too slow, consider other approaches

---

## Key Takeaways

> **Every subset corresponds to a unique binary number from 0 to 2^n - 1**
>
> Bit i set = include element i
> Bit i not set = exclude element i
