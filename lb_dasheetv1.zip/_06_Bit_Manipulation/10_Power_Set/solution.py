"""
Power Set (Generate All Subsets)
================================

Problem: Given a set of distinct elements, generate all possible subsets.

Key Insight: Each subset can be represented by a binary mask where
bit i = 1 means element i is in the subset.

Example:
    Input: [1, 2, 3]
    Output: [[], [1], [2], [1,2], [3], [1,3], [2,3], [1,2,3]]
"""


def to_binary(n: int, bits: int = 8) -> str:
    """Convert integer to binary string for visualization."""
    return bin(n)[2:].zfill(bits)


# =============================================================================
# APPROACH 1: Bit Masking (Optimal)
# =============================================================================

def power_set(arr: list) -> list:
    """
    Generate all subsets using bit masking.

    Key Insight:
        For n elements, iterate through masks 0 to 2^n - 1.
        Each mask represents a subset:
        - Bit i set means include arr[i]
        - Bit i not set means exclude arr[i]

    Time Complexity: O(n * 2^n)
    Space Complexity: O(n * 2^n) for storing subsets

    Args:
        arr: List of distinct elements

    Returns:
        List of all subsets

    Example:
        >>> power_set([1, 2, 3])
        [[], [1], [2], [1, 2], [3], [1, 3], [2, 3], [1, 2, 3]]
    """
    n = len(arr)
    subsets = []

    # Iterate through all 2^n possible masks
    for mask in range(1 << n):  # 0 to 2^n - 1
        subset = []
        for i in range(n):
            # Check if bit i is set in mask
            if mask & (1 << i):
                subset.append(arr[i])
        subsets.append(subset)

    return subsets


def power_set_verbose(arr: list) -> list:
    """Generate power set with detailed visualization."""
    n = len(arr)
    total = 1 << n

    print(f"\nGenerating Power Set of {arr}")
    print("=" * 70)
    print(f"n = {n} elements, total subsets = 2^{n} = {total}")

    print(f"\n{'Mask':>6} | {'Binary':^{n+2}} | {'Subset':<20}")
    print("-" * 50)

    subsets = []

    for mask in range(total):
        subset = []
        binary = to_binary(mask, n)

        # Build subset and show bit checking
        details = []
        for i in range(n):
            if mask & (1 << i):
                subset.append(arr[i])
                details.append(f"bit{i}=1")
            else:
                details.append(f"bit{i}=0")

        subsets.append(subset)
        print(f"{mask:>6} | {binary:^{n+2}} | {str(subset):<20}")

    print("-" * 50)
    print(f"Total: {len(subsets)} subsets")

    return subsets


# =============================================================================
# APPROACH 2: Recursive (Cascading)
# =============================================================================

def power_set_recursive(arr: list) -> list:
    """
    Generate power set using cascading approach.

    Start with empty set, for each element, add it to all existing subsets.

    Example:
        [] -> start
        [1] -> add 1 to []
        [], [1], [2], [1,2] -> add 2 to each
        ... and so on

    Time Complexity: O(n * 2^n)
    Space Complexity: O(n * 2^n)

    Example:
        >>> power_set_recursive([1, 2])
        [[], [1], [2], [1, 2]]
    """
    subsets = [[]]  # Start with empty subset

    for num in arr:
        # Add current number to all existing subsets
        new_subsets = []
        for subset in subsets:
            new_subsets.append(subset + [num])
        subsets.extend(new_subsets)

    return subsets


# =============================================================================
# APPROACH 3: Backtracking
# =============================================================================

def power_set_backtrack(arr: list) -> list:
    """
    Generate power set using backtracking.

    Time Complexity: O(n * 2^n)
    Space Complexity: O(n) for recursion stack + O(n * 2^n) for results

    Example:
        >>> power_set_backtrack([1, 2])
        [[], [1], [1, 2], [2]]
    """
    result = []

    def backtrack(start: int, current: list):
        # Add current subset to result
        result.append(current[:])

        # Try adding each remaining element
        for i in range(start, len(arr)):
            current.append(arr[i])
            backtrack(i + 1, current)
            current.pop()

    backtrack(0, [])
    return result


# =============================================================================
# VARIATIONS
# =============================================================================

def subsets_with_sum(arr: list, target: int) -> list:
    """
    Find all subsets that sum to target.

    Example:
        >>> subsets_with_sum([1, 2, 3, 4], 5)
        [[1, 4], [2, 3]]
    """
    n = len(arr)
    result = []

    for mask in range(1 << n):
        subset = []
        subset_sum = 0
        for i in range(n):
            if mask & (1 << i):
                subset.append(arr[i])
                subset_sum += arr[i]
        if subset_sum == target:
            result.append(subset)

    return result


def count_subsets_with_sum(arr: list, target: int) -> int:
    """
    Count subsets that sum to target.

    Example:
        >>> count_subsets_with_sum([1, 2, 3, 4], 5)
        2
    """
    n = len(arr)
    count = 0

    for mask in range(1 << n):
        subset_sum = 0
        for i in range(n):
            if mask & (1 << i):
                subset_sum += arr[i]
        if subset_sum == target:
            count += 1

    return count


def subsets_of_size_k(arr: list, k: int) -> list:
    """
    Find all subsets of exactly size k.

    Example:
        >>> subsets_of_size_k([1, 2, 3], 2)
        [[1, 2], [1, 3], [2, 3]]
    """
    n = len(arr)
    result = []

    for mask in range(1 << n):
        # Count set bits (subset size)
        if bin(mask).count('1') == k:
            subset = [arr[i] for i in range(n) if mask & (1 << i)]
            result.append(subset)

    return result


# =============================================================================
# VISUALIZATION
# =============================================================================

def visualize_subset_mask(arr: list, mask: int) -> None:
    """Visualize how a mask corresponds to a subset."""
    n = len(arr)
    binary = to_binary(mask, n)

    print(f"\nMask {mask} = {binary}")
    print("-" * 40)
    print(f"{'Index':<8} {'Element':<10} {'Bit':<6} {'Include?':<10}")
    print("-" * 40)

    subset = []
    for i in range(n):
        bit = (mask >> i) & 1
        include = "YES" if bit else "No"
        if bit:
            subset.append(arr[i])
        print(f"{i:<8} {str(arr[i]):<10} {bit:<6} {include:<10}")

    print("-" * 40)
    print(f"Subset: {subset}")


# =============================================================================
# DEMONSTRATION
# =============================================================================

def demonstrate():
    """Demonstrate all power set approaches."""
    arr = [1, 2, 3]

    print("=" * 70)
    print("POWER SET (GENERATE ALL SUBSETS)")
    print("=" * 70)

    # Bit masking approach with visualization
    power_set_verbose(arr)

    # Compare approaches
    print("\n" + "=" * 70)
    print("COMPARISON OF APPROACHES")
    print("=" * 70)

    ps1 = power_set(arr)
    ps2 = power_set_recursive(arr)
    ps3 = power_set_backtrack(arr)

    print(f"\nBit Masking:  {len(ps1)} subsets")
    print(f"Recursive:    {len(ps2)} subsets")
    print(f"Backtracking: {len(ps3)} subsets")

    # Visualize specific mask
    print("\n" + "=" * 70)
    print("MASK VISUALIZATION")
    print("=" * 70)

    visualize_subset_mask(['A', 'B', 'C'], 5)  # 101 = [A, C]

    # Variations
    print("\n" + "=" * 70)
    print("VARIATIONS")
    print("=" * 70)

    arr = [1, 2, 3, 4]
    print(f"\nArray: {arr}")
    print(f"\nSubsets with sum 5: {subsets_with_sum(arr, 5)}")
    print(f"Subsets of size 2: {subsets_of_size_k(arr, 2)}")


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Run test cases."""
    test_cases = [
        ([], [[]]),
        ([1], [[], [1]]),
        ([1, 2], [[], [1], [2], [1, 2]]),
    ]

    print("\n" + "=" * 50)
    print("RUNNING TEST CASES")
    print("=" * 50)

    all_passed = True

    for arr, expected in test_cases:
        result = power_set(arr)

        # Sort for comparison
        result_sorted = sorted([sorted(s) for s in result])
        expected_sorted = sorted([sorted(s) for s in expected])

        status = "PASS" if result_sorted == expected_sorted else "FAIL"
        if status == "FAIL":
            all_passed = False

        print(f"Array: {arr}")
        print(f"  Expected: {len(expected)} subsets, Got: {len(result)} [{status}]")

    # Size check
    for n in range(1, 6):
        arr = list(range(1, n + 1))
        result = power_set(arr)
        expected_count = 2 ** n
        status = "PASS" if len(result) == expected_count else "FAIL"
        print(f"n={n}: Expected {expected_count} subsets, Got {len(result)} [{status}]")

    print("-" * 50)
    print("All tests passed!" if all_passed else "Some tests failed!")


if __name__ == "__main__":
    demonstrate()
    run_tests()
