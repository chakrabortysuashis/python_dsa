"""
Bit Manipulation - Complete Python Implementation
================================================

This module contains all common bit manipulation functions with detailed
explanations and examples.

Author: DSA Learning Course
"""


# =============================================================================
# SECTION 1: BINARY REPRESENTATION HELPERS
# =============================================================================

def to_binary(n: int, bits: int = 8) -> str:
    """
    Convert integer to binary string with specified number of bits.

    Args:
        n: Integer to convert (can be negative)
        bits: Number of bits to display

    Returns:
        Binary string representation

    Example:
        >>> to_binary(13, 8)
        '00001101'
        >>> to_binary(-1, 8)
        '11111111'
    """
    if n >= 0:
        return bin(n)[2:].zfill(bits)
    else:
        # Handle negative numbers (two's complement)
        return bin(n & ((1 << bits) - 1))[2:]


def from_binary(binary_str: str) -> int:
    """
    Convert binary string to integer.

    Args:
        binary_str: Binary string (e.g., '1101')

    Returns:
        Integer value

    Example:
        >>> from_binary('1101')
        13
    """
    return int(binary_str, 2)


def print_binary(n: int, label: str = "", bits: int = 8) -> None:
    """
    Pretty print a number with its binary representation.

    Args:
        n: Integer to print
        label: Optional label for the output
        bits: Number of bits to display

    Example:
        >>> print_binary(13, "n")
        n = 13 = 00001101
    """
    binary = to_binary(n, bits)
    if label:
        print(f"{label} = {n} = {binary}")
    else:
        print(f"{n} = {binary}")


# =============================================================================
# SECTION 2: BASIC BITWISE OPERATIONS
# =============================================================================

def bitwise_and(a: int, b: int) -> int:
    """
    Perform bitwise AND operation.
    Returns 1 only if BOTH bits are 1.

    Truth Table:
        0 & 0 = 0
        0 & 1 = 0
        1 & 0 = 0
        1 & 1 = 1

    Example:
        >>> bitwise_and(12, 10)  # 1100 & 1010 = 1000
        8
    """
    return a & b


def bitwise_or(a: int, b: int) -> int:
    """
    Perform bitwise OR operation.
    Returns 1 if AT LEAST ONE bit is 1.

    Truth Table:
        0 | 0 = 0
        0 | 1 = 1
        1 | 0 = 1
        1 | 1 = 1

    Example:
        >>> bitwise_or(12, 10)  # 1100 | 1010 = 1110
        14
    """
    return a | b


def bitwise_xor(a: int, b: int) -> int:
    """
    Perform bitwise XOR operation.
    Returns 1 if bits are DIFFERENT.

    Truth Table:
        0 ^ 0 = 0
        0 ^ 1 = 1
        1 ^ 0 = 1
        1 ^ 1 = 0

    Example:
        >>> bitwise_xor(12, 10)  # 1100 ^ 1010 = 0110
        6
    """
    return a ^ b


def bitwise_not(n: int) -> int:
    """
    Perform bitwise NOT (complement) operation.
    Inverts all bits.

    Note: In Python, ~n = -(n + 1) due to two's complement

    Example:
        >>> bitwise_not(5)  # ~5 = -6
        -6
    """
    return ~n


def left_shift(n: int, k: int) -> int:
    """
    Perform left shift operation.
    Shifts bits left by k positions, filling with 0s.
    Equivalent to multiplying by 2^k.

    Formula: n << k = n * 2^k

    Example:
        >>> left_shift(5, 2)  # 5 * 4 = 20
        20
    """
    return n << k


def right_shift(n: int, k: int) -> int:
    """
    Perform right shift operation.
    Shifts bits right by k positions.
    Equivalent to integer division by 2^k.

    Formula: n >> k = n // 2^k

    Example:
        >>> right_shift(20, 2)  # 20 // 4 = 5
        5
    """
    return n >> k


# =============================================================================
# SECTION 3: BIT MANIPULATION - CHECK OPERATIONS
# =============================================================================

def is_bit_set(n: int, i: int) -> bool:
    """
    Check if the i-th bit (0-indexed from right) is set.

    Algorithm:
        1. Create mask: 1 << i
        2. AND with n
        3. If result != 0, bit is set

    Example:
        >>> is_bit_set(13, 2)  # 13 = 1101, bit 2 is set
        True
        >>> is_bit_set(13, 1)  # 13 = 1101, bit 1 is not set
        False
    """
    return (n & (1 << i)) != 0


def is_odd(n: int) -> bool:
    """
    Check if number is odd using bit manipulation.

    Algorithm: Check LSB (bit 0)
        - If LSB is 1, number is odd
        - If LSB is 0, number is even

    Example:
        >>> is_odd(13)
        True
        >>> is_odd(12)
        False
    """
    return (n & 1) == 1


def is_even(n: int) -> bool:
    """
    Check if number is even using bit manipulation.

    Example:
        >>> is_even(12)
        True
        >>> is_even(13)
        False
    """
    return (n & 1) == 0


def is_power_of_two(n: int) -> bool:
    """
    Check if n is a power of 2.

    Algorithm:
        - Power of 2 has exactly one set bit
        - n & (n-1) clears the rightmost set bit
        - If result is 0 and n > 0, it's a power of 2

    Example:
        >>> is_power_of_two(8)   # 8 = 1000
        True
        >>> is_power_of_two(6)   # 6 = 0110
        False

    Visualization:
        8 = 1000
        7 = 0111
        8 & 7 = 0000 -> Power of 2!

        6 = 0110
        5 = 0101
        6 & 5 = 0100 != 0 -> Not power of 2
    """
    return n > 0 and (n & (n - 1)) == 0


# =============================================================================
# SECTION 4: BIT MANIPULATION - MODIFY OPERATIONS
# =============================================================================

def set_bit(n: int, i: int) -> int:
    """
    Set the i-th bit (make it 1).

    Algorithm: n | (1 << i)
        - Create mask with only i-th bit set
        - OR with n to set that bit

    Example:
        >>> set_bit(9, 2)  # 1001 | 0100 = 1101 = 13
        13
    """
    return n | (1 << i)


def clear_bit(n: int, i: int) -> int:
    """
    Clear the i-th bit (make it 0).

    Algorithm: n & ~(1 << i)
        - Create mask with only i-th bit set
        - Invert mask (all bits 1 except i-th)
        - AND with n to clear that bit

    Example:
        >>> clear_bit(13, 2)  # 1101 & 1011 = 1001 = 9
        9
    """
    return n & ~(1 << i)


def toggle_bit(n: int, i: int) -> int:
    """
    Toggle the i-th bit (flip 0 to 1 or 1 to 0).

    Algorithm: n ^ (1 << i)
        - Create mask with only i-th bit set
        - XOR with n to toggle that bit

    Example:
        >>> toggle_bit(13, 0)  # 1101 ^ 0001 = 1100 = 12
        12
        >>> toggle_bit(12, 0)  # 1100 ^ 0001 = 1101 = 13
        13
    """
    return n ^ (1 << i)


def clear_rightmost_set_bit(n: int) -> int:
    """
    Clear the rightmost set bit.

    Algorithm: n & (n - 1)
        - n-1 flips all bits from rightmost 1 to the end
        - AND clears the rightmost 1

    Example:
        >>> clear_rightmost_set_bit(12)  # 1100 & 1011 = 1000 = 8
        8
        >>> clear_rightmost_set_bit(8)   # 1000 & 0111 = 0000 = 0
        0

    Visualization:
        n   = 1100
        n-1 = 1011
        AND = 1000 (rightmost 1 at position 2 is cleared)
    """
    return n & (n - 1)


def isolate_rightmost_set_bit(n: int) -> int:
    """
    Isolate the rightmost set bit.

    Algorithm: n & (-n)
        - -n in two's complement flips bits and adds 1
        - AND gives only the rightmost set bit

    Example:
        >>> isolate_rightmost_set_bit(12)  # 12 = 1100, result = 0100 = 4
        4
        >>> isolate_rightmost_set_bit(10)  # 10 = 1010, result = 0010 = 2
        2
    """
    return n & (-n)


def turn_off_rightmost_consecutive_ones(n: int) -> int:
    """
    Turn off all consecutive 1s starting from the rightmost bit.

    Algorithm: n & (n + 1)

    Example:
        >>> turn_off_rightmost_consecutive_ones(7)   # 0111 & 1000 = 0
        0
        >>> turn_off_rightmost_consecutive_ones(23)  # 10111 & 11000 = 10000 = 16
        16
    """
    return n & (n + 1)


# =============================================================================
# SECTION 5: COUNTING BITS
# =============================================================================

def count_set_bits_naive(n: int) -> int:
    """
    Count number of set bits (1s) - Naive approach.

    Algorithm: Check each bit one by one
    Time Complexity: O(log n) or O(number of bits)

    Example:
        >>> count_set_bits_naive(13)  # 1101 has 3 ones
        3
    """
    count = 0
    while n:
        count += n & 1  # Check LSB
        n >>= 1         # Right shift
    return count


def count_set_bits_kernighan(n: int) -> int:
    """
    Count number of set bits - Brian Kernighan's Algorithm.

    Algorithm:
        - Clear rightmost set bit repeatedly
        - Count iterations until n becomes 0

    Time Complexity: O(number of set bits)

    Example:
        >>> count_set_bits_kernighan(13)  # 1101 has 3 ones
        3

    Step-by-step for n = 13 (1101):
        Iteration 1: 1101 & 1100 = 1100, count = 1
        Iteration 2: 1100 & 1011 = 1000, count = 2
        Iteration 3: 1000 & 0111 = 0000, count = 3
    """
    count = 0
    while n:
        n = n & (n - 1)  # Clear rightmost set bit
        count += 1
    return count


def count_different_bits(a: int, b: int) -> int:
    """
    Count number of bits that need to be flipped to convert a to b.
    Also known as Hamming Distance.

    Algorithm:
        - XOR a and b (gives 1 where bits differ)
        - Count set bits in XOR result

    Example:
        >>> count_different_bits(10, 20)  # How many bits differ?
        4

    Visualization:
        10 = 01010
        20 = 10100
        XOR= 11110 (4 bits differ)
    """
    xor = a ^ b
    return count_set_bits_kernighan(xor)


# =============================================================================
# SECTION 6: XOR TRICKS
# =============================================================================

def swap_without_temp(a: int, b: int) -> tuple:
    """
    Swap two numbers without using a temporary variable.

    Algorithm:
        a = a ^ b  # a now contains a XOR b
        b = a ^ b  # b = (a XOR b) XOR b = a
        a = a ^ b  # a = (a XOR b) XOR a = b

    Example:
        >>> swap_without_temp(5, 9)
        (9, 5)
    """
    a = a ^ b
    b = a ^ b
    a = a ^ b
    return a, b


def find_single_element(arr: list) -> int:
    """
    Find the element that appears once when all others appear twice.

    Algorithm:
        - XOR all elements
        - Pairs cancel out (a ^ a = 0)
        - Result is the single element

    Time Complexity: O(n)
    Space Complexity: O(1)

    Example:
        >>> find_single_element([4, 1, 2, 1, 2])
        4

    Visualization:
        4 ^ 1 ^ 2 ^ 1 ^ 2
        = 4 ^ (1 ^ 1) ^ (2 ^ 2)
        = 4 ^ 0 ^ 0
        = 4
    """
    result = 0
    for num in arr:
        result ^= num
    return result


def find_two_singles(arr: list) -> tuple:
    """
    Find two elements that appear once when all others appear twice.

    Algorithm:
        1. XOR all elements -> gives a ^ b
        2. Find rightmost set bit (differentiating bit)
        3. Divide elements into two groups based on this bit
        4. XOR each group separately

    Example:
        >>> find_two_singles([1, 2, 3, 2, 1, 4])
        (3, 4)  # or (4, 3)
    """
    # Step 1: XOR all elements
    xor_all = 0
    for num in arr:
        xor_all ^= num
    # xor_all = a ^ b

    # Step 2: Find rightmost set bit
    rightmost_bit = xor_all & (-xor_all)

    # Step 3 & 4: Divide and XOR
    a, b = 0, 0
    for num in arr:
        if num & rightmost_bit:
            a ^= num
        else:
            b ^= num

    return (a, b)


# =============================================================================
# SECTION 7: POWER OF 2 OPERATIONS
# =============================================================================

def next_power_of_two(n: int) -> int:
    """
    Find the next power of 2 greater than or equal to n.

    Algorithm:
        - Subtract 1 from n
        - Set all bits after the highest set bit to 1
        - Add 1 to get next power of 2

    Example:
        >>> next_power_of_two(5)
        8
        >>> next_power_of_two(8)
        8
    """
    if n == 0:
        return 1
    if is_power_of_two(n):
        return n

    n -= 1
    n |= n >> 1
    n |= n >> 2
    n |= n >> 4
    n |= n >> 8
    n |= n >> 16
    return n + 1


def previous_power_of_two(n: int) -> int:
    """
    Find the largest power of 2 less than or equal to n.

    Example:
        >>> previous_power_of_two(10)
        8
        >>> previous_power_of_two(8)
        8
    """
    if n <= 0:
        return 0

    n |= n >> 1
    n |= n >> 2
    n |= n >> 4
    n |= n >> 8
    n |= n >> 16
    return (n + 1) >> 1


def log2_floor(n: int) -> int:
    """
    Calculate floor of log base 2.
    Position of the highest set bit.

    Example:
        >>> log2_floor(8)   # 2^3 = 8
        3
        >>> log2_floor(10)  # 2^3 < 10 < 2^4
        3
    """
    if n <= 0:
        return -1

    result = 0
    while n > 1:
        n >>= 1
        result += 1
    return result


def multiply_by_power_of_two(n: int, k: int) -> int:
    """
    Multiply n by 2^k using left shift.

    Example:
        >>> multiply_by_power_of_two(5, 3)  # 5 * 8 = 40
        40
    """
    return n << k


def divide_by_power_of_two(n: int, k: int) -> int:
    """
    Divide n by 2^k using right shift.

    Example:
        >>> divide_by_power_of_two(40, 3)  # 40 / 8 = 5
        5
    """
    return n >> k


# =============================================================================
# SECTION 8: BIT MASKING
# =============================================================================

def create_mask(i: int) -> int:
    """
    Create a mask with bit i set.

    Example:
        >>> bin(create_mask(3))
        '0b1000'
    """
    return 1 << i


def create_mask_range(i: int, j: int) -> int:
    """
    Create a mask with bits from i to j (inclusive) set.

    Example:
        >>> bin(create_mask_range(2, 5))  # Bits 2,3,4,5 set
        '0b111100'
    """
    width = j - i + 1
    return ((1 << width) - 1) << i


def create_mask_rightmost_n(n: int) -> int:
    """
    Create a mask with rightmost n bits set.

    Example:
        >>> bin(create_mask_rightmost_n(4))  # 1111
        '0b1111'
    """
    return (1 << n) - 1


def extract_bits(num: int, i: int, j: int) -> int:
    """
    Extract bits from position i to j (inclusive).

    Example:
        >>> extract_bits(109, 1, 3)  # 109 = 1101101, bits 1-3 = 110 = 6
        6
    """
    mask = create_mask_range(i, j)
    return (num & mask) >> i


def set_bits_range(num: int, i: int, j: int) -> int:
    """
    Set all bits from position i to j.

    Example:
        >>> bin(set_bits_range(0, 2, 5))
        '0b111100'
    """
    mask = create_mask_range(i, j)
    return num | mask


def clear_bits_range(num: int, i: int, j: int) -> int:
    """
    Clear all bits from position i to j.

    Example:
        >>> clear_bits_range(255, 2, 5)  # 11111111 -> 11000011 = 195
        195
    """
    mask = create_mask_range(i, j)
    return num & ~mask


# =============================================================================
# SECTION 9: SUBSET GENERATION
# =============================================================================

def generate_subsets(arr: list) -> list:
    """
    Generate all subsets (power set) using bit masking.

    Algorithm:
        - For n elements, there are 2^n subsets
        - Each number from 0 to 2^n - 1 represents a subset
        - Bit i set means element i is in subset

    Time Complexity: O(n * 2^n)
    Space Complexity: O(2^n) for storing subsets

    Example:
        >>> generate_subsets([1, 2, 3])
        [[], [1], [2], [1, 2], [3], [1, 3], [2, 3], [1, 2, 3]]

    Visualization for [1, 2, 3]:
        mask = 0 (000): []
        mask = 1 (001): [1]
        mask = 2 (010): [2]
        mask = 3 (011): [1, 2]
        mask = 4 (100): [3]
        mask = 5 (101): [1, 3]
        mask = 6 (110): [2, 3]
        mask = 7 (111): [1, 2, 3]
    """
    n = len(arr)
    subsets = []

    for mask in range(1 << n):  # 0 to 2^n - 1
        subset = []
        for i in range(n):
            if mask & (1 << i):  # Check if bit i is set
                subset.append(arr[i])
        subsets.append(subset)

    return subsets


def count_subsets_with_given_sum(arr: list, target_sum: int) -> int:
    """
    Count subsets whose elements sum to target using bit masking.

    Note: Only efficient for small arrays (n <= 20)

    Example:
        >>> count_subsets_with_given_sum([1, 2, 3], 3)
        2  # Subsets: [1, 2] and [3]
    """
    n = len(arr)
    count = 0

    for mask in range(1 << n):
        subset_sum = 0
        for i in range(n):
            if mask & (1 << i):
                subset_sum += arr[i]
        if subset_sum == target_sum:
            count += 1

    return count


# =============================================================================
# SECTION 10: MISCELLANEOUS BIT TRICKS
# =============================================================================

def get_sign(n: int) -> int:
    """
    Get sign of number: -1 for negative, 0 for zero, 1 for positive.

    Example:
        >>> get_sign(-5)
        -1
        >>> get_sign(5)
        1
    """
    return (n > 0) - (n < 0)


def absolute_value(n: int) -> int:
    """
    Get absolute value using bit manipulation.

    Algorithm:
        - mask = n >> 31 (all 1s if negative, all 0s if positive)
        - (n + mask) ^ mask gives absolute value

    Example:
        >>> absolute_value(-5)
        5
        >>> absolute_value(5)
        5
    """
    mask = n >> 31  # Assumes 32-bit integer
    return (n + mask) ^ mask


def min_of_two(a: int, b: int) -> int:
    """
    Find minimum of two numbers using bit manipulation.

    Example:
        >>> min_of_two(5, 3)
        3
    """
    return b ^ ((a ^ b) & -(a < b))


def max_of_two(a: int, b: int) -> int:
    """
    Find maximum of two numbers using bit manipulation.

    Example:
        >>> max_of_two(5, 3)
        5
    """
    return a ^ ((a ^ b) & -(a < b))


def are_opposite_signs(a: int, b: int) -> bool:
    """
    Check if two numbers have opposite signs.

    Algorithm: XOR of two numbers with opposite signs is negative

    Example:
        >>> are_opposite_signs(5, -3)
        True
        >>> are_opposite_signs(5, 3)
        False
    """
    return (a ^ b) < 0


def add_one(n: int) -> int:
    """
    Add 1 to a number without using + operator.

    Algorithm: -~n
        - ~n = -(n + 1)
        - -~n = -( -(n + 1) ) = n + 1

    Example:
        >>> add_one(5)
        6
    """
    return -~n


def reverse_bits(n: int, bits: int = 32) -> int:
    """
    Reverse all bits in a number.

    Example:
        >>> bin(reverse_bits(0b1010, 4))
        '0b101'  # 5
    """
    result = 0
    for _ in range(bits):
        result = (result << 1) | (n & 1)
        n >>= 1
    return result


# =============================================================================
# DEMONSTRATION AND TESTING
# =============================================================================

def demonstrate_operations():
    """Demonstrate all bit manipulation operations with visual output."""

    print("=" * 60)
    print("BIT MANIPULATION DEMONSTRATION")
    print("=" * 60)

    # Binary representation
    print("\n--- Binary Representation ---")
    for n in [13, 8, 255, -5]:
        print_binary(n, f"n={n:3d}", 8 if n >= 0 else 8)

    # Basic operations
    print("\n--- Bitwise Operations ---")
    a, b = 12, 10
    print(f"a = {a} = {to_binary(a)}")
    print(f"b = {b} = {to_binary(b)}")
    print(f"a & b = {a & b} = {to_binary(a & b)}")
    print(f"a | b = {a | b} = {to_binary(a | b)}")
    print(f"a ^ b = {a ^ b} = {to_binary(a ^ b)}")
    print(f"~a = {~a}")
    print(f"a << 2 = {a << 2}")
    print(f"b >> 1 = {b >> 1}")

    # Bit manipulation
    print("\n--- Bit Manipulation ---")
    n = 13
    print(f"n = {n} = {to_binary(n)}")
    print(f"Is bit 2 set? {is_bit_set(n, 2)}")
    print(f"Set bit 1: {set_bit(n, 1)} = {to_binary(set_bit(n, 1))}")
    print(f"Clear bit 2: {clear_bit(n, 2)} = {to_binary(clear_bit(n, 2))}")
    print(f"Toggle bit 0: {toggle_bit(n, 0)} = {to_binary(toggle_bit(n, 0))}")

    # Counting bits
    print("\n--- Counting Bits ---")
    n = 13
    print(f"Set bits in {n} ({to_binary(n)}): {count_set_bits_kernighan(n)}")
    print(f"Bits to flip {10} to {20}: {count_different_bits(10, 20)}")

    # XOR tricks
    print("\n--- XOR Tricks ---")
    arr = [4, 1, 2, 1, 2]
    print(f"Single element in {arr}: {find_single_element(arr)}")
    a, b = 5, 9
    swapped = swap_without_temp(a, b)
    print(f"Swap {a} and {b}: {swapped}")

    # Power of 2
    print("\n--- Power of 2 ---")
    for n in [8, 6, 16, 15]:
        print(f"Is {n} power of 2? {is_power_of_two(n)}")
    print(f"Next power of 2 after 10: {next_power_of_two(10)}")

    # Subsets
    print("\n--- Subset Generation ---")
    arr = [1, 2, 3]
    subsets = generate_subsets(arr)
    print(f"Subsets of {arr}:")
    for i, subset in enumerate(subsets):
        print(f"  {to_binary(i, 3)}: {subset}")


if __name__ == "__main__":
    demonstrate_operations()

    # Run doctests
    import doctest
    print("\n" + "=" * 60)
    print("Running doctests...")
    doctest.testmod(verbose=True)
