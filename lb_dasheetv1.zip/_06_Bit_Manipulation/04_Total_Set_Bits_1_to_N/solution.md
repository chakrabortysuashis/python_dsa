# Count Total Set Bits from 1 to N

## Problem Statement
Given a positive integer N, count the total number of set bits (1s) in binary representation of all numbers from 1 to N.

### Examples
```
Input: N = 3
Output: 4
Explanation:
  1 = 01 -> 1 set bit
  2 = 10 -> 1 set bit
  3 = 11 -> 2 set bits
  Total = 1 + 1 + 2 = 4

Input: N = 7
Output: 12
Explanation:
  1 = 001 -> 1    5 = 101 -> 2
  2 = 010 -> 1    6 = 110 -> 2
  3 = 011 -> 2    7 = 111 -> 3
  4 = 100 -> 1
  Total = 1+1+2+1+2+2+3 = 12
```

---

## Binary Representation Visualization

```
N = 7

Num | Binary | Set Bits
----|--------|----------
  1 |  001   |    1
  2 |  010   |    1
  3 |  011   |    2
  4 |  100   |    1
  5 |  101   |    2
  6 |  110   |    2
  7 |  111   |    3
----|--------|----------
           Total = 12
```

---

## Intuition

### Observation: Pattern in Each Bit Position

Look at bit position 0 (rightmost):
```
1: 1    (set)
2: 0
3: 1    (set)
4: 0
5: 1    (set)
6: 0
7: 1    (set)
```
Pattern: alternates 1, 0, 1, 0, ... (period = 2)

Look at bit position 1:
```
1: 0
2: 1    (set)
3: 1    (set)
4: 0
5: 0
6: 1    (set)
7: 1    (set)
```
Pattern: 0, 1, 1, 0, 0, 1, 1, ... (period = 4)

Look at bit position 2:
```
1: 0
2: 0
3: 0
4: 1    (set)
5: 1    (set)
6: 1    (set)
7: 1    (set)
```
Pattern: 0, 0, 0, 0, 1, 1, 1, 1, ... (period = 8)

### Key Insight
For bit position i (0-indexed from right):
- Period = 2^(i+1)
- In each complete period: half are 0, half are 1
- Number of 1s in one period = 2^i

---

## Approach 1: Brute Force

### Algorithm
1. For each number from 1 to N
2. Count set bits using Brian Kernighan's algorithm
3. Sum all counts

### Time Complexity: O(N log N)

---

## Approach 2: Bit Position Analysis (Optimal)

### Algorithm
For each bit position i (from 0 to log N):
1. Calculate total groups = (N + 1) / 2^(i+1)
2. Each complete group contributes 2^i ones
3. Handle remaining partial group

### Formula for each bit position i:
```
complete_groups = (n + 1) / (2 * power)  // where power = 2^i
set_bits_from_complete = complete_groups * power

remaining = (n + 1) % (2 * power)
set_bits_from_partial = max(0, remaining - power)

total_for_position_i = set_bits_from_complete + set_bits_from_partial
```

### Visualization for N = 11, Bit Position 1 (power = 2)

```
Numbers 0-11 in binary (showing bit 1):
0:  0
1:  0
2:  1  <- group 0
3:  1  <-
4:  0
5:  0
6:  1  <- group 1
7:  1  <-
8:  0
9:  0
10: 1  <- group 2
11: 1  <-

Period = 4, each period has 2 ones
Complete groups = 12 / 4 = 3
Set bits = 3 * 2 = 6
```

---

## Dry Run: N = 7

```
Binary representations:
1 = 001, 2 = 010, 3 = 011, 4 = 100, 5 = 101, 6 = 110, 7 = 111

Analyzing each bit position:

Bit Position 0 (power = 1):
---------------------------
Period = 2
Numbers: 0 1 2 3 4 5 6 7
Bit 0:   0 1 0 1 0 1 0 1
                        
Complete groups = 8 / 2 = 4
Set bits from complete = 4 * 1 = 4
Remaining = 8 % 2 = 0
Set bits from partial = max(0, 0 - 1) = 0
Total for bit 0 = 4

Bit Position 1 (power = 2):
---------------------------
Period = 4
Numbers: 0 1 2 3 4 5 6 7
Bit 1:   0 0 1 1 0 0 1 1

Complete groups = 8 / 4 = 2
Set bits from complete = 2 * 2 = 4
Remaining = 8 % 4 = 0
Set bits from partial = max(0, 0 - 2) = 0
Total for bit 1 = 4

Bit Position 2 (power = 4):
---------------------------
Period = 8
Numbers: 0 1 2 3 4 5 6 7
Bit 2:   0 0 0 0 1 1 1 1

Complete groups = 8 / 8 = 1
Set bits from complete = 1 * 4 = 4
Remaining = 8 % 8 = 0
Set bits from partial = max(0, 0 - 4) = 0
Total for bit 2 = 4

TOTAL = 4 + 4 + 4 = 12
```

---

## Approach 3: Recursive Formula

### Key Observation
For numbers 0 to 2^k - 1:
- Total set bits = k * 2^(k-1)

For n = 2^k + r (where r < 2^k):
- Count(n) = Count(2^k - 1) + (r + 1) + Count(r)
- The (r + 1) accounts for the MSB being set for numbers 2^k to n

---

## Complexity Comparison

| Approach | Time | Space |
|----------|------|-------|
| Brute Force | O(N log N) | O(1) |
| Bit Position | O(log N) | O(1) |
| Recursive | O(log N) | O(log N) |

---

## Special Cases

1. **N = 0**: Return 0 (no numbers to count)
2. **N = power of 2**: All patterns complete
3. **Large N**: Use optimal approach to avoid TLE

---

## Pattern Summary

```
Bit 0: 1 0 1 0 1 0 1 0 ...  (period 2)
Bit 1: 0 1 1 0 0 1 1 0 ...  (period 4)
Bit 2: 0 0 0 1 1 1 1 0 ...  (period 8)
Bit 3: 0 0 0 0 0 0 0 1 ...  (period 16)

For bit position i:
- Period = 2^(i+1)
- 1s per period = 2^i
- Pattern: 2^i zeros, then 2^i ones
```

---

## Related Problems

1. **Count set bits in a single number** - Basic building block
2. **Range set bit queries** - Extension with range
3. **Digit DP problems** - Similar counting technique
