"""
Count Total Set Bits from 1 to N
================================

Problem: Given a positive integer N, count the total number of set bits
in binary representation of all numbers from 1 to N.

Example:
    Input: N = 7
    Output: 12
    Explanation: 1+1+2+1+2+2+3 = 12
"""


def to_binary(n: int, bits: int = 8) -> str:
    """Convert integer to binary string for visualization."""
    if n >= 0:
        return bin(n)[2:].zfill(bits)
    return bin(n & ((1 << bits) - 1))[2:]


def count_set_bits(n: int) -> int:
    """Count set bits in a single number using Brian Kernighan's algorithm."""
    count = 0
    while n:
        n = n & (n - 1)
        count += 1
    return count


# =============================================================================
# APPROACH 1: Brute Force
# =============================================================================

def count_total_set_bits_bruteforce(n: int) -> int:
    """
    Count total set bits from 1 to n using brute force.

    Algorithm:
        1. For each number from 1 to n
        2. Count set bits
        3. Sum all counts

    Time Complexity: O(n * log n)
    Space Complexity: O(1)

    Args:
        n: Upper limit

    Returns:
        Total count of set bits from 1 to n

    Example:
        >>> count_total_set_bits_bruteforce(7)
        12
    """
    total = 0
    for i in range(1, n + 1):
        total += count_set_bits(i)
    return total


# =============================================================================
# APPROACH 2: Bit Position Analysis (Optimal)
# =============================================================================

def count_total_set_bits_optimal(n: int) -> int:
    """
    Count total set bits using bit position analysis.

    Key Insight:
        For bit position i, the pattern of 0s and 1s repeats with period 2^(i+1).
        In each period, there are 2^i ones.

    Algorithm:
        For each bit position:
        1. Calculate complete groups
        2. Calculate contribution from complete groups
        3. Add contribution from partial group

    Time Complexity: O(log n)
    Space Complexity: O(1)

    Args:
        n: Upper limit

    Returns:
        Total count of set bits from 1 to n

    Example:
        >>> count_total_set_bits_optimal(7)
        12
        >>> count_total_set_bits_optimal(3)
        4
    """
    if n <= 0:
        return 0

    total = 0
    power = 1  # 2^i for current bit position

    while power <= n:
        # Period for this bit position
        period = power << 1  # 2 * power = 2^(i+1)

        # Number of complete periods in [0, n]
        complete_groups = (n + 1) // period

        # Set bits from complete groups
        # Each complete group contributes 'power' ones
        total += complete_groups * power

        # Handle partial group
        remaining = (n + 1) % period
        # In partial group, first 'power' numbers have bit=0, rest have bit=1
        total += max(0, remaining - power)

        power <<= 1  # Move to next bit position

    return total


def count_total_set_bits_optimal_verbose(n: int) -> int:
    """Optimal approach with detailed step-by-step visualization."""
    print(f"\nCounting total set bits from 1 to {n}")
    print("=" * 70)

    # Show all numbers and their binary representations
    bits = max(4, n.bit_length())
    print("\nNumbers and their binary representations:")
    print("-" * 40)

    individual_counts = []
    for i in range(1, min(n + 1, 17)):  # Limit display for large n
        count = count_set_bits(i)
        individual_counts.append(count)
        print(f"  {i:3d} = {to_binary(i, bits)} -> {count} set bit(s)")

    if n > 16:
        print(f"  ... (showing first 16 of {n})")

    print("-" * 40)
    if n <= 16:
        print(f"  Brute force total: {sum(individual_counts)}")

    # Optimal approach
    print("\n" + "=" * 70)
    print("OPTIMAL APPROACH: Bit Position Analysis")
    print("=" * 70)

    total = 0
    power = 1
    position = 0

    while power <= n:
        period = power << 1

        print(f"\nBit Position {position} (power = 2^{position} = {power}):")
        print(f"  Period = {period}")

        complete_groups = (n + 1) // period
        from_complete = complete_groups * power

        remaining = (n + 1) % period
        from_partial = max(0, remaining - power)

        position_total = from_complete + from_partial

        print(f"  Complete groups = ({n} + 1) / {period} = {complete_groups}")
        print(f"  Set bits from complete = {complete_groups} * {power} = {from_complete}")
        print(f"  Remaining = ({n} + 1) % {period} = {remaining}")
        print(f"  Set bits from partial = max(0, {remaining} - {power}) = {from_partial}")
        print(f"  Total for bit {position} = {position_total}")

        total += position_total
        power <<= 1
        position += 1

    print("\n" + "=" * 70)
    print(f"ANSWER: Total set bits from 1 to {n} = {total}")
    print("=" * 70)

    return total


# =============================================================================
# APPROACH 3: Recursive Formula
# =============================================================================

def count_total_set_bits_recursive(n: int) -> int:
    """
    Count total set bits using recursive formula.

    Key formula:
        For n = 2^k + r (where r < 2^k):
        count(n) = count(2^k - 1) + (r + 1) + count(r)

        For n = 2^k - 1:
        count(n) = k * 2^(k-1)

    Time Complexity: O(log n)
    Space Complexity: O(log n) due to recursion

    Args:
        n: Upper limit

    Returns:
        Total count of set bits from 1 to n

    Example:
        >>> count_total_set_bits_recursive(7)
        12
    """
    if n <= 0:
        return 0
    if n == 1:
        return 1

    # Find highest power of 2 <= n
    k = n.bit_length() - 1
    power = 1 << k  # 2^k

    if n == power - 1:
        # n = 2^k - 1 (all bits set)
        # Total = k * 2^(k-1)
        return k * (power >> 1)

    # n = 2^k + r, where r = n - 2^k
    r = n - power

    # count(2^k - 1): all numbers from 0 to 2^k - 1
    count_below_power = k * (power >> 1)

    # (r + 1): MSB contribution for numbers 2^k to n
    msb_contribution = r + 1

    # count(r): remaining bits for numbers 2^k to n
    count_remaining = count_total_set_bits_recursive(r)

    return count_below_power + msb_contribution + count_remaining


# =============================================================================
# VISUALIZATION HELPER
# =============================================================================

def visualize_bit_patterns(n: int) -> None:
    """Visualize the bit patterns for each position."""
    bits = max(4, n.bit_length())

    print(f"\nBit patterns from 0 to {n}:")
    print("=" * 60)

    # Header
    print("     ", end="")
    for i in range(bits - 1, -1, -1):
        print(f"Bit{i} ", end="")
    print()
    print("-" * 60)

    # Show each number
    for num in range(n + 1):
        binary = to_binary(num, bits)
        print(f"{num:3d}: ", end="")
        for bit in binary:
            print(f"  {bit}  ", end="")
        print()

    # Count set bits per position
    print("-" * 60)
    print("Sum: ", end="")
    for pos in range(bits - 1, -1, -1):
        count = sum(1 for num in range(n + 1) if (num >> pos) & 1)
        print(f"  {count}  ", end="")
    print()


# =============================================================================
# DEMONSTRATION
# =============================================================================

def demonstrate():
    """Demonstrate all approaches with examples."""
    test_cases = [3, 7, 10, 15, 16]

    print("=" * 70)
    print("COUNT TOTAL SET BITS FROM 1 TO N")
    print("=" * 70)

    # Quick comparison
    print("\n{:<6} {:<15} {:<15} {:<15}".format(
        "N", "Brute Force", "Optimal", "Recursive"
    ))
    print("-" * 55)

    for n in test_cases:
        bf = count_total_set_bits_bruteforce(n)
        opt = count_total_set_bits_optimal(n)
        rec = count_total_set_bits_recursive(n)
        print(f"{n:<6} {bf:<15} {opt:<15} {rec:<15}")

    # Detailed walkthrough
    print("\n" + "=" * 70)
    print("DETAILED WALKTHROUGH")
    print("=" * 70)

    visualize_bit_patterns(7)
    count_total_set_bits_optimal_verbose(7)


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Run test cases."""
    test_cases = [
        (0, 0),
        (1, 1),
        (3, 4),
        (7, 12),
        (10, 17),
        (15, 32),
        (16, 33),
        (100, 319),
    ]

    print("\n" + "=" * 50)
    print("RUNNING TEST CASES")
    print("=" * 50)

    all_passed = True
    for n, expected in test_cases:
        bf = count_total_set_bits_bruteforce(n)
        opt = count_total_set_bits_optimal(n)
        rec = count_total_set_bits_recursive(n)

        status = "PASS" if bf == opt == rec == expected else "FAIL"
        if status == "FAIL":
            all_passed = False

        print(f"N={n:3d} -> Expected: {expected:3d}, BF={bf:3d}, Opt={opt:3d}, Rec={rec:3d} [{status}]")

    print("-" * 50)
    print("All tests passed!" if all_passed else "Some tests failed!")


if __name__ == "__main__":
    demonstrate()
    run_tests()
