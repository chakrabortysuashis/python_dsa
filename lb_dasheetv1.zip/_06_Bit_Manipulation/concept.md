# Bit Manipulation - Complete Guide

## Table of Contents
1. [Binary Number System](#binary-number-system)
2. [Bitwise Operators](#bitwise-operators)
3. [Common Bit Tricks](#common-bit-tricks)
4. [Properties of XOR](#properties-of-xor)
5. [Power of 2 Tricks](#power-of-2-tricks)
6. [Bit Masking](#bit-masking)

---

## Binary Number System

### What is Binary?
Binary is a base-2 number system that uses only two digits: **0** and **1**. Each digit is called a **bit** (binary digit).

### Decimal to Binary Conversion
```
Decimal 13 to Binary:
13 ÷ 2 = 6 remainder 1
 6 ÷ 2 = 3 remainder 0
 3 ÷ 2 = 1 remainder 1
 1 ÷ 2 = 0 remainder 1

Read remainders bottom-up: 1101
So, 13₁₀ = 1101₂
```

### Binary to Decimal Conversion
```
Binary 1101 to Decimal:
Position:  3   2   1   0
Bits:      1   1   0   1
Values:    2³  2²  2¹  2⁰
         = 8 + 4 + 0 + 1
         = 13

So, 1101₂ = 13₁₀
```

### Bit Positions (0-indexed from right)
```
32-bit representation of 13:
Position: 31 30 29 28 ... 4  3  2  1  0
Bits:      0  0  0  0 ... 0  1  1  0  1
                           ↑        ↑
                          MSB      LSB
                    (Most Significant)  (Least Significant)
```

### Signed vs Unsigned Integers
- **Unsigned**: All bits represent magnitude (0 to 2ⁿ - 1)
- **Signed**: MSB represents sign (Two's complement)
  - Positive: MSB = 0
  - Negative: MSB = 1

```
Two's Complement for -5 (8-bit):
 5 in binary:  00000101
Invert bits:   11111010
Add 1:         11111011  ← This is -5
```

---

## Bitwise Operators

### 1. AND (&)
Returns 1 only if **both** bits are 1.

```
Truth Table:
A | B | A & B
0 | 0 |   0
0 | 1 |   0
1 | 0 |   0
1 | 1 |   1

Example: 12 & 10
  12 = 1100
  10 = 1010
  --------
       1000 = 8
```

**Use Cases:**
- Check if a bit is set: `n & (1 << i)`
- Clear bits: `n & mask`
- Check if number is even/odd: `n & 1`

### 2. OR (|)
Returns 1 if **at least one** bit is 1.

```
Truth Table:
A | B | A | B
0 | 0 |   0
0 | 1 |   1
1 | 0 |   1
1 | 1 |   1

Example: 12 | 10
  12 = 1100
  10 = 1010
  --------
       1110 = 14
```

**Use Cases:**
- Set a bit: `n | (1 << i)`
- Combine flags: `flag1 | flag2`

### 3. XOR (^)
Returns 1 if bits are **different**.

```
Truth Table:
A | B | A ^ B
0 | 0 |   0
0 | 1 |   1
1 | 0 |   1
1 | 1 |   0

Example: 12 ^ 10
  12 = 1100
  10 = 1010
  --------
       0110 = 6
```

**Use Cases:**
- Toggle a bit: `n ^ (1 << i)`
- Find unique element
- Swap without temp variable

### 4. NOT (~)
Inverts all bits (bitwise complement).

```
Example: ~5 (8-bit signed)
  5 = 00000101
 ~5 = 11111010 = -6 (Two's complement)

Formula: ~n = -(n + 1)
```

### 5. Left Shift (<<)
Shifts bits left, fills with 0s. Equivalent to multiplying by 2^k.

```
Example: 5 << 2
  5     = 00000101
  5<<1  = 00001010 = 10
  5<<2  = 00010100 = 20

Formula: n << k = n × 2^k
```

### 6. Right Shift (>>)
Shifts bits right. Equivalent to dividing by 2^k.

```
Example: 20 >> 2
  20    = 00010100
  20>>1 = 00001010 = 10
  20>>2 = 00000101 = 5

Formula: n >> k = n ÷ 2^k (integer division)
```

**Types of Right Shift:**
- **Logical shift**: Fills with 0s (for unsigned)
- **Arithmetic shift**: Preserves sign bit (for signed)

---

## Common Bit Tricks

### 1. Check if i-th bit is set
```python
def is_bit_set(n, i):
    return (n & (1 << i)) != 0

# Example: Is bit 2 set in 13?
# 13 = 1101
# 1 << 2 = 0100
# 1101 & 0100 = 0100 ≠ 0 → Yes!
```

### 2. Set the i-th bit
```python
def set_bit(n, i):
    return n | (1 << i)

# Example: Set bit 1 in 13
# 13 = 1101
# 1 << 1 = 0010
# 1101 | 0010 = 1111 = 15
```

### 3. Clear the i-th bit
```python
def clear_bit(n, i):
    return n & ~(1 << i)

# Example: Clear bit 2 in 13
# 13 = 1101
# 1 << 2 = 0100
# ~0100 = 1011
# 1101 & 1011 = 1001 = 9
```

### 4. Toggle the i-th bit
```python
def toggle_bit(n, i):
    return n ^ (1 << i)

# Example: Toggle bit 0 in 13
# 13 = 1101
# 1 << 0 = 0001
# 1101 ^ 0001 = 1100 = 12
```

### 5. Clear rightmost set bit
```python
def clear_rightmost_set_bit(n):
    return n & (n - 1)

# Example: n = 12 = 1100
# n - 1 = 11 = 1011
# 1100 & 1011 = 1000 = 8
```

### 6. Isolate rightmost set bit
```python
def isolate_rightmost_set_bit(n):
    return n & (-n)

# Example: n = 12 = 1100
# -12 = 0100 (two's complement: ...11110100)
# 1100 & 0100 = 0100 = 4
```

### 7. Check if number is odd or even
```python
def is_odd(n):
    return n & 1 == 1

def is_even(n):
    return n & 1 == 0

# LSB = 1 → Odd, LSB = 0 → Even
```

### 8. Swap two numbers without temp
```python
def swap(a, b):
    a = a ^ b  # a contains a XOR b
    b = a ^ b  # b = (a XOR b) XOR b = a
    a = a ^ b  # a = (a XOR b) XOR a = b
    return a, b
```

### 9. Count set bits (Brian Kernighan's Algorithm)
```python
def count_set_bits(n):
    count = 0
    while n:
        n = n & (n - 1)  # Clear rightmost set bit
        count += 1
    return count

# Example: n = 13 = 1101
# Iteration 1: 1101 & 1100 = 1100, count = 1
# Iteration 2: 1100 & 1011 = 1000, count = 2
# Iteration 3: 1000 & 0111 = 0000, count = 3
```

---

## Properties of XOR

### 1. Self-inverse Property
```
a ^ a = 0     (XOR with itself gives 0)
a ^ 0 = a     (XOR with 0 gives itself)
```

### 2. Commutative Property
```
a ^ b = b ^ a
```

### 3. Associative Property
```
(a ^ b) ^ c = a ^ (b ^ c)
```

### 4. Finding Single Non-repeating Element
```python
# All elements appear twice except one
def find_single(arr):
    result = 0
    for num in arr:
        result ^= num
    return result

# [4, 1, 2, 1, 2]
# 4 ^ 1 ^ 2 ^ 1 ^ 2 = 4 ^ (1^1) ^ (2^2) = 4 ^ 0 ^ 0 = 4
```

### 5. Finding Two Non-repeating Elements
```python
def find_two_singles(arr):
    xor_all = 0
    for num in arr:
        xor_all ^= num
    # xor_all = a ^ b (where a, b are the two singles)
    
    # Find rightmost set bit (differentiating bit)
    rightmost_bit = xor_all & (-xor_all)
    
    # Divide into two groups based on this bit
    a, b = 0, 0
    for num in arr:
        if num & rightmost_bit:
            a ^= num
        else:
            b ^= num
    return a, b
```

---

## Power of 2 Tricks

### 1. Check if n is power of 2
```python
def is_power_of_two(n):
    return n > 0 and (n & (n - 1)) == 0

# Power of 2 has exactly one set bit
# 8 = 1000, 8-1 = 0111
# 1000 & 0111 = 0000 ✓

# 6 = 0110, 6-1 = 0101
# 0110 & 0101 = 0100 ≠ 0 ✗
```

### 2. Find next power of 2
```python
def next_power_of_2(n):
    if n == 0:
        return 1
    n -= 1
    n |= n >> 1
    n |= n >> 2
    n |= n >> 4
    n |= n >> 8
    n |= n >> 16
    return n + 1

# This fills all bits after the highest set bit with 1s
# Then adds 1 to get the next power of 2
```

### 3. Multiply by power of 2
```python
n * 2^k = n << k

# 5 * 8 = 5 * 2³ = 5 << 3 = 40
```

### 4. Divide by power of 2
```python
n / 2^k = n >> k

# 40 / 8 = 40 / 2³ = 40 >> 3 = 5
```

### 5. Get log base 2 (position of highest set bit)
```python
def log2(n):
    result = 0
    while n > 1:
        n >>= 1
        result += 1
    return result
```

---

## Bit Masking

### What is a Bit Mask?
A bit mask is a binary pattern used to extract, set, or clear specific bits.

### Creating Masks

#### 1. Single bit mask at position i
```python
mask = 1 << i

# Position 3: 1 << 3 = 0...01000
```

#### 2. Mask with rightmost n bits set
```python
mask = (1 << n) - 1

# n = 4: (1 << 4) - 1 = 16 - 1 = 15 = 1111
```

#### 3. Mask with bits from i to j set (inclusive)
```python
mask = ((1 << (j - i + 1)) - 1) << i

# i=2, j=5: ((1 << 4) - 1) << 2 = 15 << 2 = 111100
```

### Using Masks

#### 1. Extract bits i to j
```python
def extract_bits(n, i, j):
    mask = ((1 << (j - i + 1)) - 1) << i
    return (n & mask) >> i

# Extract bits 1-3 from 109 (1101101)
# mask = 01110
# 1101101 & 0001110 = 0001100
# >> 1 = 0000110 = 6
```

#### 2. Set bits in range
```python
def set_bits_range(n, i, j):
    mask = ((1 << (j - i + 1)) - 1) << i
    return n | mask
```

#### 3. Clear bits in range
```python
def clear_bits_range(n, i, j):
    mask = ((1 << (j - i + 1)) - 1) << i
    return n & ~mask
```

### Subset Generation using Bit Masking
```python
def generate_subsets(arr):
    n = len(arr)
    subsets = []
    for mask in range(1 << n):  # 0 to 2^n - 1
        subset = []
        for i in range(n):
            if mask & (1 << i):  # Check if i-th bit is set
                subset.append(arr[i])
        subsets.append(subset)
    return subsets

# arr = [1, 2, 3]
# mask = 0 (000): []
# mask = 1 (001): [1]
# mask = 2 (010): [2]
# mask = 3 (011): [1, 2]
# mask = 4 (100): [3]
# mask = 5 (101): [1, 3]
# mask = 6 (110): [2, 3]
# mask = 7 (111): [1, 2, 3]
```

---

## Quick Reference Table

| Operation | Code | Example |
|-----------|------|---------|
| Check i-th bit | `n & (1 << i)` | `13 & 4 = 4` |
| Set i-th bit | `n \| (1 << i)` | `9 \| 4 = 13` |
| Clear i-th bit | `n & ~(1 << i)` | `13 & ~4 = 9` |
| Toggle i-th bit | `n ^ (1 << i)` | `13 ^ 1 = 12` |
| Clear rightmost set bit | `n & (n - 1)` | `12 & 11 = 8` |
| Isolate rightmost set bit | `n & (-n)` | `12 & -12 = 4` |
| Check power of 2 | `n & (n - 1) == 0` | `8 & 7 = 0` |
| Multiply by 2^k | `n << k` | `5 << 3 = 40` |
| Divide by 2^k | `n >> k` | `40 >> 3 = 5` |
| Check odd/even | `n & 1` | `13 & 1 = 1` |
| Turn off rightmost 1s | `n & (n + 1)` | `7 & 8 = 0` |
| Get lowest set bit | `n & -n` | `10 & -10 = 2` |

---

## Common Interview Patterns

1. **Single Number Problems**: Use XOR properties
2. **Counting Bits**: Brian Kernighan's algorithm or lookup table
3. **Power of 2 Checks**: n & (n-1) == 0
4. **Subset Generation**: Iterate through all 2^n masks
5. **Bit Manipulation in DP**: Use bitmask to represent state
6. **Division/Multiplication**: Use shifts for optimization

---

## Practice Problems Checklist

- [ ] Count set bits in an integer
- [ ] Find the two non-repeating elements
- [ ] Count bits to flip to convert A to B
- [ ] Count total set bits from 1 to n
- [ ] Check if number is power of two
- [ ] Find position of only set bit
- [ ] Copy set bits in a range
- [ ] Divide without *, / and mod
- [ ] Calculate square without *, / and pow()
- [ ] Power Set

---

*Master these concepts and you'll have a solid foundation for solving bit manipulation problems!*
