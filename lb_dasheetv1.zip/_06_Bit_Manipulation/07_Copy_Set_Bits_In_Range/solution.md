# Copy Set Bits in a Range

## Problem Statement
Given two numbers x and y, and a range [l, r], copy all set bits of y in the range [l, r] to x. Return the modified value of x.

**Note:** Positions are 1-indexed from the right.

### Examples
```
Input: x = 10, y = 13, l = 2, r = 3
Output: 14

Explanation:
  x = 10 = 1010
  y = 13 = 1101
  Range [2, 3]

  y's bits in range [2, 3]: bits 2=0, bit 3=1
  Copy bit 3 (which is 1) to x
  Result: 1110 = 14

Input: x = 8, y = 7, l = 1, r = 2
Output: 11

Explanation:
  x = 8 = 1000
  y = 7 = 0111
  Range [1, 2]: y has bits 1=1, 2=1
  Copy these to x: 1011 = 11
```

---

## Binary Representation Visualization

```
Example: x = 10, y = 13, l = 2, r = 3

Position: 4  3  2  1
          |  |  |  |
x = 10:   1  0  1  0
y = 13:   1  1  0  1
              ↑  ↑
          Range [2,3]

y's set bits in range: position 3 has 1
Copy to x: set bit 3 in x

Result:   1  1  1  0 = 14
             ↑
         Copied from y
```

---

## Intuition

### Step 1: Create a mask for the range
We need a mask that has 1s only in positions l to r.

```
For l=2, r=3 (4-bit):
mask = 0110

Creating mask:
1. Create mask with (r-l+1) ones: (1 << (r-l+1)) - 1 = (1<<2) - 1 = 3 = 11
2. Shift left by (l-1): 11 << 1 = 110 = 0110
```

### Step 2: Extract y's bits in range
```
y & mask = 1101 & 0110 = 0100
```

### Step 3: Set these bits in x
```
x | (y & mask) = 1010 | 0100 = 1110 = 14
```

---

## Algorithm

```python
def copy_set_bits_in_range(x, y, l, r):
    # Step 1: Create mask for range [l, r]
    # Number of bits in range
    num_bits = r - l + 1
    
    # Create mask with 'num_bits' ones
    mask = (1 << num_bits) - 1
    
    # Shift to position l
    mask = mask << (l - 1)
    
    # Step 2: Extract y's bits in range
    y_bits = y & mask
    
    # Step 3: Set these bits in x
    return x | y_bits
```

---

## Dry Run: x = 10, y = 13, l = 2, r = 3

```
Initial:
  x = 10 = 1010
  y = 13 = 1101
  l = 2, r = 3

Step 1: Create mask
-----------------------
  num_bits = r - l + 1 = 3 - 2 + 1 = 2
  
  mask = (1 << 2) - 1 = 4 - 1 = 3 = 0011
  
  mask = 0011 << (l - 1) = 0011 << 1 = 0110

  Mask visualization:
  Position: 4  3  2  1
  Mask:     0  1  1  0
               ↑  ↑
           Range covered

Step 2: Extract y's bits in range
----------------------------------
  y & mask = 1101 & 0110 = 0100

  y:        1  1  0  1
  mask:     0  1  1  0
  AND:      0  1  0  0  (only y's bits in range)

Step 3: Set bits in x
----------------------
  x | (y & mask) = 1010 | 0100 = 1110 = 14

  x:        1  0  1  0
  y&mask:   0  1  0  0
  OR:       1  1  1  0

RESULT: 14
```

---

## Complexity Analysis

| Metric | Value |
|--------|-------|
| Time | O(1) |
| Space | O(1) |

All operations are constant time bit manipulations.

---

## Edge Cases

1. **l = r**: Copy single bit
2. **l = 1**: Range starts from rightmost bit
3. **Range covers all bits**: Equivalent to x | y
4. **y has no set bits in range**: x remains unchanged

---

## Variations

### Copy and also clear x's bits in range first
```python
def copy_bits_in_range_replace(x, y, l, r):
    mask = ((1 << (r - l + 1)) - 1) << (l - 1)
    # Clear x's bits in range, then copy y's bits
    return (x & ~mask) | (y & mask)
```

This replaces x's bits in range with y's bits (not just sets them).

---

## Related Problems

1. **Extract bits in range** - Just return y & mask
2. **Set bits in range** - Set all bits in range to 1
3. **Clear bits in range** - Set all bits in range to 0
