"""
Copy Set Bits in a Range
========================

Problem: Given two numbers x and y, and a range [l, r], copy all set bits
of y in the range [l, r] to x.

Note: Positions are 1-indexed from the right.

Example:
    Input: x = 10, y = 13, l = 2, r = 3
    Output: 14
"""


def to_binary(n: int, bits: int = 8) -> str:
    """Convert integer to binary string for visualization."""
    if n >= 0:
        return bin(n)[2:].zfill(bits)
    return bin(n & ((1 << bits) - 1))[2:]


# =============================================================================
# MAIN SOLUTION
# =============================================================================

def copy_set_bits_in_range(x: int, y: int, l: int, r: int) -> int:
    """
    Copy set bits from y to x in the range [l, r].

    Algorithm:
        1. Create mask for range [l, r]
        2. Extract y's bits in that range
        3. OR with x to set those bits

    Time Complexity: O(1)
    Space Complexity: O(1)

    Args:
        x: Target number to modify
        y: Source number to copy bits from
        l: Left boundary (1-indexed, inclusive)
        r: Right boundary (1-indexed, inclusive)

    Returns:
        Modified x with y's set bits in range copied

    Example:
        >>> copy_set_bits_in_range(10, 13, 2, 3)
        14
    """
    # Create mask for range [l, r]
    # Number of bits in range
    num_bits = r - l + 1

    # Create mask with 'num_bits' ones, then shift to position
    mask = ((1 << num_bits) - 1) << (l - 1)

    # Extract y's bits in range and set them in x
    return x | (y & mask)


def copy_set_bits_in_range_verbose(x: int, y: int, l: int, r: int) -> int:
    """Copy set bits with detailed visualization."""
    print(f"\nCopying set bits from y to x in range [{l}, {r}]")
    print("=" * 60)

    bits = max(8, max(x.bit_length(), y.bit_length()) + 2)

    print(f"\nInput:")
    print(f"  x = {x:4d} = {to_binary(x, bits)}")
    print(f"  y = {y:4d} = {to_binary(y, bits)}")
    print(f"  Range: [{l}, {r}]")

    # Step 1: Create mask
    print(f"\nStep 1: Create mask for range [{l}, {r}]")
    num_bits = r - l + 1
    print(f"  Number of bits = r - l + 1 = {r} - {l} + 1 = {num_bits}")

    ones_mask = (1 << num_bits) - 1
    print(f"  Create {num_bits} ones: (1 << {num_bits}) - 1 = {ones_mask} = {to_binary(ones_mask, bits)}")

    mask = ones_mask << (l - 1)
    print(f"  Shift left by (l-1) = {l-1}: {to_binary(mask, bits)} = {mask}")

    # Show mask coverage
    print(f"\n  Mask visualization:")
    print(f"  Position: ", end="")
    for i in range(bits, 0, -1):
        print(f"{i:2d} ", end="")
    print()
    print(f"  Mask:     {to_binary(mask, bits).replace('0', ' 0').replace('1', ' 1')}")

    # Step 2: Extract y's bits
    print(f"\nStep 2: Extract y's bits in range")
    y_bits = y & mask
    print(f"  y & mask = {to_binary(y, bits)}")
    print(f"           & {to_binary(mask, bits)}")
    print(f"           = {to_binary(y_bits, bits)} = {y_bits}")

    # Step 3: Set in x
    print(f"\nStep 3: Set extracted bits in x")
    result = x | y_bits
    print(f"  x | (y & mask) = {to_binary(x, bits)}")
    print(f"                 | {to_binary(y_bits, bits)}")
    print(f"                 = {to_binary(result, bits)} = {result}")

    print(f"\n" + "=" * 60)
    print(f"RESULT: {result}")
    return result


# =============================================================================
# VARIATION: Replace bits (clear first, then copy)
# =============================================================================

def copy_bits_in_range_replace(x: int, y: int, l: int, r: int) -> int:
    """
    Replace x's bits in range [l, r] with y's bits.

    This clears x's bits in the range first, then copies y's bits.

    Example:
        >>> copy_bits_in_range_replace(15, 8, 1, 2)  # 1111 -> 1100
        12
    """
    num_bits = r - l + 1
    mask = ((1 << num_bits) - 1) << (l - 1)

    # Clear x's bits in range, then copy y's bits
    return (x & ~mask) | (y & mask)


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def create_range_mask(l: int, r: int, bits: int = 8) -> int:
    """
    Create a mask with bits set in range [l, r].

    Example:
        >>> bin(create_range_mask(2, 4, 8))
        '0b1110'
    """
    num_bits = r - l + 1
    return ((1 << num_bits) - 1) << (l - 1)


def extract_bits_in_range(n: int, l: int, r: int) -> int:
    """
    Extract bits from n in range [l, r].

    Example:
        >>> extract_bits_in_range(13, 2, 3)  # 1101 -> extract bits 2-3
        2
    """
    mask = create_range_mask(l, r)
    return (n & mask) >> (l - 1)


def set_bits_in_range(n: int, l: int, r: int) -> int:
    """
    Set all bits in range [l, r] to 1.

    Example:
        >>> set_bits_in_range(0, 2, 4)
        14  # 0000 -> 1110
    """
    mask = create_range_mask(l, r)
    return n | mask


def clear_bits_in_range(n: int, l: int, r: int) -> int:
    """
    Clear all bits in range [l, r] to 0.

    Example:
        >>> clear_bits_in_range(15, 2, 3)  # 1111 -> 1001
        9
    """
    mask = create_range_mask(l, r)
    return n & ~mask


# =============================================================================
# DEMONSTRATION
# =============================================================================

def demonstrate():
    """Demonstrate the algorithm with examples."""
    test_cases = [
        (10, 13, 2, 3),
        (8, 7, 1, 2),
        (0, 15, 1, 4),
        (15, 0, 2, 3),
    ]

    print("=" * 70)
    print("COPY SET BITS IN A RANGE")
    print("=" * 70)

    print("\n{:<6} {:<6} {:<8} {:<10} {:<10} {:<8}".format(
        "x", "y", "Range", "x (bin)", "y (bin)", "Result"
    ))
    print("-" * 60)

    for x, y, l, r in test_cases:
        result = copy_set_bits_in_range(x, y, l, r)
        print(f"{x:<6} {y:<6} [{l},{r}]    {to_binary(x, 8):<10} {to_binary(y, 8):<10} {result:<8}")

    # Detailed walkthrough
    print("\n" + "=" * 70)
    print("DETAILED WALKTHROUGH")
    print("=" * 70)

    copy_set_bits_in_range_verbose(10, 13, 2, 3)


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Run test cases."""
    test_cases = [
        # (x, y, l, r, expected)
        (10, 13, 2, 3, 14),
        (8, 7, 1, 2, 11),
        (0, 15, 1, 4, 15),
        (15, 0, 2, 3, 15),  # No bits to copy
        (0, 8, 4, 4, 8),    # Single bit
    ]

    print("\n" + "=" * 50)
    print("RUNNING TEST CASES")
    print("=" * 50)

    all_passed = True
    for x, y, l, r, expected in test_cases:
        result = copy_set_bits_in_range(x, y, l, r)
        status = "PASS" if result == expected else "FAIL"
        if status == "FAIL":
            all_passed = False

        print(f"x={x}, y={y}, [{l},{r}] -> Expected: {expected}, Got: {result} [{status}]")

    print("-" * 50)
    print("All tests passed!" if all_passed else "Some tests failed!")


if __name__ == "__main__":
    demonstrate()
    run_tests()
