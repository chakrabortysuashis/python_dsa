# Count Set Bits in an Integer

## Problem Statement
Given a positive integer `n`, count the number of set bits (1s) in its binary representation.

**Also known as:** Population Count, Hamming Weight

### Examples
```
Input: n = 13
Output: 3
Explanation: Binary of 13 = 1101, which has 3 set bits

Input: n = 128
Output: 1
Explanation: Binary of 128 = 10000000, which has 1 set bit

Input: n = 255
Output: 8
Explanation: Binary of 255 = 11111111, which has 8 set bits
```

---

## Binary Representation Visualization

```
n = 13 (Decimal)

Binary Representation (8-bit):
Position:  7   6   5   4   3   2   1   0
         +---+---+---+---+---+---+---+---+
   Bits: | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 1 |
         +---+---+---+---+---+---+---+---+
                         ^   ^       ^
                         |   |       |
                    Set bits (count = 3)
```

---

## Intuition

### Why Bit Manipulation?
- Checking if a bit is set: `n & (1 << i)` returns non-zero if bit i is 1
- Removing rightmost set bit: `n & (n-1)` clears the rightmost 1-bit
- These operations are O(1) and very efficient at hardware level

### Key Insight for Optimal Solution
```
n     = 1100  (12 in decimal)
n - 1 = 1011

n & (n-1) = 1100 & 1011 = 1000

Notice: The rightmost 1-bit in n is cleared!
```

This happens because:
- Subtracting 1 from n flips all bits from rightmost 1 to the end
- AND operation keeps only the bits before the rightmost 1

---

## Approach 1: Brute Force (Check Each Bit)

### Algorithm
1. Check each bit from position 0 to 31 (for 32-bit integers)
2. Use `n & 1` to check if LSB is set
3. Right shift n by 1 to check next bit
4. Count total 1s

### Visualization
```
n = 13 = 1101

Step 1: 1101 & 1 = 1 (bit 0 is set)     count = 1
        Shift: 1101 >> 1 = 110

Step 2: 110 & 1 = 0 (bit 1 is not set)  count = 1
        Shift: 110 >> 1 = 11

Step 3: 11 & 1 = 1 (bit 2 is set)       count = 2
        Shift: 11 >> 1 = 1

Step 4: 1 & 1 = 1 (bit 3 is set)        count = 3
        Shift: 1 >> 1 = 0

n becomes 0, stop!
Result: 3 set bits
```

### Complexity
- **Time:** O(log n) - number of bits
- **Space:** O(1)

---

## Approach 2: Brian Kernighan's Algorithm (Optimal)

### Algorithm
1. While n is not 0:
   - Clear rightmost set bit: `n = n & (n-1)`
   - Increment count
2. Return count

### Key Insight
The operation `n & (n-1)` always clears exactly one set bit - the rightmost one!

### Visualization
```
n = 13 = 1101

Iteration 1:
    n     = 1101
    n - 1 = 1100
    ---------------
    n & (n-1) = 1100
    
    Binary view:
    Before: 1 1 0 [1]  <- rightmost 1
    After:  1 1 0  0   <- cleared!
    
    count = 1

Iteration 2:
    n     = 1100
    n - 1 = 1011
    ---------------
    n & (n-1) = 1000
    
    Binary view:
    Before: 1 1 [0] 0
                 ^-- rightmost 1 is at position 2
    After:  1 0  0  0
    
    count = 2

Iteration 3:
    n     = 1000
    n - 1 = 0111
    ---------------
    n & (n-1) = 0000
    
    Binary view:
    Before: [1] 0 0 0  <- only one 1 left
    After:   0  0 0 0  <- all cleared!
    
    count = 3

n = 0, STOP!
Total set bits: 3
```

### Why is this better?
- Only iterates **number of set bits** times
- For n = 128 (10000000), only 1 iteration!
- Brute force would need 8 iterations

### Complexity
- **Time:** O(k) where k = number of set bits
- **Space:** O(1)

---

## Approach 3: Lookup Table (For Multiple Queries)

### Algorithm
1. Precompute count for all 8-bit values (0-255)
2. Split 32-bit number into four 8-bit chunks
3. Sum up the counts

### Use Case
When counting set bits for millions of numbers

### Complexity
- **Preprocessing:** O(256)
- **Query Time:** O(1) for 32-bit integers
- **Space:** O(256) for lookup table

---

## Comparison of Approaches

| Approach | Time | Space | Best For |
|----------|------|-------|----------|
| Brute Force | O(log n) | O(1) | Single number, simple |
| Kernighan | O(k) | O(1) | Numbers with few set bits |
| Lookup Table | O(1) | O(256) | Many queries |

---

## Common Variations

1. **Count set bits from 1 to n** - Dynamic programming approach
2. **Check if count is odd/even** - XOR all bits
3. **Count total set bits in array** - Sum individual counts

---

## Practice Tips

1. Understand why `n & (n-1)` clears rightmost bit
2. Visualize the binary representation
3. Practice converting decimal to binary mentally
4. Remember: powers of 2 have exactly 1 set bit

---

## Related Problems

- Count total set bits from 1 to n
- Check if number is power of 2
- Hamming distance between two numbers
