"""
Count Set Bits in an Integer
============================

Problem: Given a positive integer n, count the number of set bits (1s)
in its binary representation.

Also known as: Population Count, Hamming Weight

Example:
    Input: n = 13
    Output: 3
    Explanation: Binary of 13 = 1101, which has 3 set bits
"""


def to_binary(n: int, bits: int = 8) -> str:
    """Convert integer to binary string for visualization."""
    if n >= 0:
        return bin(n)[2:].zfill(bits)
    return bin(n & ((1 << bits) - 1))[2:]


def print_step(label: str, n: int, count: int, bits: int = 8) -> None:
    """Print a step in the algorithm with binary representation."""
    print(f"  {label}: {n:3d} = {to_binary(n, bits)}, count = {count}")


# =============================================================================
# APPROACH 1: Brute Force - Check Each Bit
# =============================================================================

def count_set_bits_brute_force(n: int) -> int:
    """
    Count set bits by checking each bit position.

    Algorithm:
        1. Check LSB using n & 1
        2. Right shift n
        3. Repeat until n becomes 0

    Time Complexity: O(log n) - number of bits
    Space Complexity: O(1)

    Args:
        n: Positive integer

    Returns:
        Number of set bits (1s) in binary representation

    Example:
        >>> count_set_bits_brute_force(13)
        3
        >>> count_set_bits_brute_force(128)
        1
    """
    count = 0
    while n > 0:
        count += n & 1  # Add 1 if LSB is set, 0 otherwise
        n >>= 1         # Right shift to check next bit
    return count


def count_set_bits_brute_force_verbose(n: int) -> int:
    """Brute force with step-by-step visualization."""
    print(f"\nBrute Force: Counting set bits in {n}")
    print(f"Binary: {to_binary(n)}")
    print("-" * 50)

    original = n
    count = 0
    position = 0

    while n > 0:
        bit = n & 1
        if bit:
            print(f"  Position {position}: {to_binary(n)} & 1 = 1 (SET)")
            count += 1
        else:
            print(f"  Position {position}: {to_binary(n)} & 1 = 0 (not set)")
        n >>= 1
        position += 1

    print("-" * 50)
    print(f"Total set bits in {original}: {count}")
    return count


# =============================================================================
# APPROACH 2: Brian Kernighan's Algorithm (Optimal)
# =============================================================================

def count_set_bits_kernighan(n: int) -> int:
    """
    Count set bits using Brian Kernighan's Algorithm.

    Key Insight: n & (n-1) clears the rightmost set bit!

    Algorithm:
        1. While n != 0:
           - Clear rightmost set bit: n = n & (n-1)
           - Increment count
        2. Return count

    Time Complexity: O(k) where k = number of set bits
    Space Complexity: O(1)

    Why it's optimal:
        - Only iterates once per set bit
        - For n = 128 (10000000), only 1 iteration
        - Brute force would need 8 iterations

    Args:
        n: Positive integer

    Returns:
        Number of set bits

    Example:
        >>> count_set_bits_kernighan(13)
        3
        >>> count_set_bits_kernighan(128)
        1
    """
    count = 0
    while n:
        n = n & (n - 1)  # Clear rightmost set bit
        count += 1
    return count


def count_set_bits_kernighan_verbose(n: int) -> int:
    """Brian Kernighan's algorithm with step-by-step visualization."""
    print(f"\nKernighan's Algorithm: Counting set bits in {n}")
    print(f"Binary: {to_binary(n)}")
    print("=" * 60)

    original = n
    count = 0
    iteration = 0

    while n:
        iteration += 1
        n_minus_1 = n - 1
        new_n = n & n_minus_1

        print(f"\nIteration {iteration}:")
        print(f"  n     = {n:3d} = {to_binary(n)}")
        print(f"  n - 1 = {n_minus_1:3d} = {to_binary(n_minus_1)}")
        print(f"  " + "-" * 20)
        print(f"  n & (n-1) = {new_n:3d} = {to_binary(new_n)}")

        # Highlight which bit was cleared
        for i in range(7, -1, -1):
            if (n >> i) & 1 and not ((new_n >> i) & 1):
                print(f"  --> Cleared bit at position {i}")
                break

        n = new_n
        count += 1
        print(f"  count = {count}")

    print("\n" + "=" * 60)
    print(f"Total set bits in {original}: {count}")
    return count


# =============================================================================
# APPROACH 3: Lookup Table (For Multiple Queries)
# =============================================================================

# Precompute set bit count for all 8-bit values
LOOKUP_TABLE = [bin(i).count('1') for i in range(256)]


def count_set_bits_lookup(n: int) -> int:
    """
    Count set bits using a precomputed lookup table.

    Algorithm:
        1. Precompute count for all 8-bit values (0-255)
        2. Split 32-bit number into four 8-bit chunks
        3. Sum up the counts

    Time Complexity: O(1) for 32-bit integers
    Space Complexity: O(256) for lookup table

    Best for: When counting set bits for millions of numbers

    Args:
        n: Non-negative integer

    Returns:
        Number of set bits

    Example:
        >>> count_set_bits_lookup(13)
        3
        >>> count_set_bits_lookup(255)
        8
    """
    count = 0
    while n:
        count += LOOKUP_TABLE[n & 0xFF]  # Get count for lowest 8 bits
        n >>= 8                           # Move to next 8 bits
    return count


# =============================================================================
# APPROACH 4: Using Built-in (Python)
# =============================================================================

def count_set_bits_builtin(n: int) -> int:
    """
    Count set bits using Python's built-in function.

    Example:
        >>> count_set_bits_builtin(13)
        3
    """
    return bin(n).count('1')


# =============================================================================
# DEMONSTRATION
# =============================================================================

def demonstrate():
    """Demonstrate all approaches with examples."""
    test_cases = [13, 128, 255, 7, 0, 1, 1023]

    print("=" * 70)
    print("COUNT SET BITS - COMPARISON OF APPROACHES")
    print("=" * 70)

    # Quick comparison
    print("\n{:<10} {:<15} {:<12} {:<12} {:<12} {:<12}".format(
        "Number", "Binary", "Brute Force", "Kernighan", "Lookup", "Built-in"
    ))
    print("-" * 70)

    for n in test_cases:
        bf = count_set_bits_brute_force(n)
        kg = count_set_bits_kernighan(n)
        lt = count_set_bits_lookup(n)
        bi = count_set_bits_builtin(n)
        print(f"{n:<10} {to_binary(n):<15} {bf:<12} {kg:<12} {lt:<12} {bi:<12}")

    # Detailed walkthrough
    print("\n" + "=" * 70)
    print("DETAILED WALKTHROUGH")
    print("=" * 70)

    count_set_bits_brute_force_verbose(13)
    count_set_bits_kernighan_verbose(13)


def visualize_kernighan_step_by_step(n: int) -> None:
    """Visualize exactly how n & (n-1) clears the rightmost bit."""
    print(f"\nVisualizing why n & (n-1) clears rightmost set bit:")
    print(f"n = {n} = {to_binary(n)}")
    print()

    # Show the bit pattern
    binary = to_binary(n)
    print("Position:  ", end="")
    for i in range(len(binary) - 1, -1, -1):
        print(f" {i} ", end="")
    print()

    print(f"n        = ", end="")
    for bit in binary:
        print(f" {bit} ", end="")
    print()

    # Find rightmost set bit position
    rightmost_pos = -1
    for i in range(len(binary)):
        if binary[len(binary) - 1 - i] == '1':
            rightmost_pos = i
            break

    if rightmost_pos >= 0:
        print(f"\nRightmost set bit is at position {rightmost_pos}")
        print(f"\nWhen we subtract 1:")
        print(f"  - All bits from position 0 to {rightmost_pos} flip")
        print(f"  - Bits after position {rightmost_pos} stay the same")

        n_minus_1 = n - 1
        result = n & n_minus_1

        print(f"\nn     = {to_binary(n)}")
        print(f"n - 1 = {to_binary(n_minus_1)}")
        print(f"AND   = {to_binary(result)}")
        print(f"\nThe rightmost 1 is now 0!")


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Run test cases for all approaches."""
    test_cases = [
        (0, 0),
        (1, 1),
        (7, 3),      # 111
        (13, 3),     # 1101
        (128, 1),    # 10000000
        (255, 8),    # 11111111
        (1023, 10),  # 1111111111
        (1024, 1),   # 10000000000
    ]

    print("\n" + "=" * 50)
    print("RUNNING TEST CASES")
    print("=" * 50)

    all_passed = True
    for n, expected in test_cases:
        bf = count_set_bits_brute_force(n)
        kg = count_set_bits_kernighan(n)
        lt = count_set_bits_lookup(n)

        status = "PASS" if bf == kg == lt == expected else "FAIL"
        if status == "FAIL":
            all_passed = False

        print(f"n={n:<6} expected={expected:<3} got BF={bf}, KG={kg}, LT={lt} [{status}]")

    print("-" * 50)
    print("All tests passed!" if all_passed else "Some tests failed!")


if __name__ == "__main__":
    demonstrate()
    visualize_kernighan_step_by_step(12)
    run_tests()
