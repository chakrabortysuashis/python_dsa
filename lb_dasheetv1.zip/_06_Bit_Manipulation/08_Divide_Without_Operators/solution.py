"""
Divide Two Integers Without *, / and mod
========================================

Problem: Divide two integers without using multiplication, division,
or modulo operators. Return the quotient truncated toward zero.

Example:
    Input: dividend = 43, divisor = 8
    Output: 5
"""


def to_binary(n: int, bits: int = 8) -> str:
    """Convert integer to binary string for visualization."""
    if n >= 0:
        return bin(n)[2:].zfill(bits)
    return bin(n & ((1 << bits) - 1))[2:]


# Constants for overflow handling
INT_MAX = 2**31 - 1
INT_MIN = -2**31


# =============================================================================
# APPROACH 1: Brute Force - Repeated Subtraction
# =============================================================================

def divide_brute_force(dividend: int, divisor: int) -> int:
    """
    Divide using repeated subtraction.

    Time Complexity: O(dividend / divisor) - Very slow!
    Space Complexity: O(1)

    Example:
        >>> divide_brute_force(43, 8)
        5
    """
    if divisor == 0:
        raise ValueError("Division by zero")

    # Handle signs
    negative = (dividend < 0) != (divisor < 0)
    dividend = abs(dividend)
    divisor = abs(divisor)

    quotient = 0
    while dividend >= divisor:
        dividend -= divisor
        quotient += 1

    return -quotient if negative else quotient


# =============================================================================
# APPROACH 2: Bit Manipulation - Exponential Subtraction (Optimal)
# =============================================================================

def divide(dividend: int, divisor: int) -> int:
    """
    Divide using bit manipulation (exponential subtraction).

    Key Insight:
        divisor << k = divisor * 2^k
        Instead of subtracting divisor one at a time,
        subtract divisor * 2^k for largest possible k.

    Time Complexity: O(log^2 n)
    Space Complexity: O(1)

    Args:
        dividend: Number to be divided
        divisor: Number to divide by

    Returns:
        Quotient truncated toward zero

    Example:
        >>> divide(43, 8)
        5
        >>> divide(-7, 2)
        -3
    """
    if divisor == 0:
        raise ValueError("Division by zero")

    # Handle overflow edge case
    if dividend == INT_MIN and divisor == -1:
        return INT_MAX

    # Handle signs
    negative = (dividend < 0) != (divisor < 0)
    dividend = abs(dividend)
    divisor = abs(divisor)

    quotient = 0

    while dividend >= divisor:
        # Find largest k where divisor << k <= dividend
        temp = divisor
        power = 1

        # Double temp while it fits
        while dividend >= (temp << 1) and (temp << 1) > 0:
            temp <<= 1
            power <<= 1

        # Subtract and add to quotient
        dividend -= temp
        quotient += power

    return -quotient if negative else quotient


def divide_verbose(dividend: int, divisor: int) -> int:
    """Divide with detailed step-by-step visualization."""
    print(f"\nDividing {dividend} by {divisor}")
    print("=" * 60)

    if divisor == 0:
        print("Error: Division by zero!")
        return 0

    # Handle signs
    negative = (dividend < 0) != (divisor < 0)
    orig_dividend = dividend
    orig_divisor = divisor
    dividend = abs(dividend)
    divisor = abs(divisor)

    print(f"\nWorking with absolute values: {dividend} / {divisor}")
    print(f"Result will be {'negative' if negative else 'positive'}")

    bits = max(8, max(dividend.bit_length(), divisor.bit_length()) + 2)

    quotient = 0
    iteration = 0

    while dividend >= divisor:
        iteration += 1
        print(f"\n--- Iteration {iteration} ---")
        print(f"Current dividend: {dividend} = {to_binary(dividend, bits)}")

        # Find largest k
        temp = divisor
        power = 1
        k = 0

        print(f"\nFinding largest k where {divisor} << k <= {dividend}:")
        while dividend >= (temp << 1) and (temp << 1) > 0:
            print(f"  k={k}: {divisor} << {k} = {temp} <= {dividend}? Yes")
            temp <<= 1
            power <<= 1
            k += 1

        print(f"  k={k}: {divisor} << {k} = {temp} <= {dividend}? Yes (final)")
        if dividend >= (temp << 1):
            print(f"  k={k+1}: {divisor} << {k+1} = {temp << 1} > {dividend}? Stop")
        else:
            print(f"  k={k+1}: Would overflow, stop")

        print(f"\nSubtracting: {dividend} - {temp} = {dividend - temp}")
        print(f"Adding to quotient: {quotient} + {power} = {quotient + power}")

        dividend -= temp
        quotient += power

    print(f"\n--- Final ---")
    print(f"Remaining dividend: {dividend} < {divisor}, stop!")
    print(f"Quotient: {quotient}")
    if negative:
        print(f"Applying sign: -{quotient}")
        quotient = -quotient

    print(f"\n" + "=" * 60)
    print(f"RESULT: {orig_dividend} / {orig_divisor} = {quotient}")
    print(f"Verification: {orig_divisor} * {quotient} = {orig_divisor * quotient}")
    print(f"Remainder: {orig_dividend - orig_divisor * quotient}")

    return quotient


# =============================================================================
# APPROACH 3: Using Logarithms (For reference, not recommended)
# =============================================================================

def divide_log(dividend: int, divisor: int) -> int:
    """
    Divide using logarithms. Not recommended due to floating point precision.

    Example:
        >>> divide_log(43, 8)
        5
    """
    import math

    if divisor == 0:
        raise ValueError("Division by zero")
    if dividend == 0:
        return 0

    negative = (dividend < 0) != (divisor < 0)
    dividend = abs(dividend)
    divisor = abs(divisor)

    # log(a/b) = log(a) - log(b)
    # a/b = e^(log(a) - log(b))
    log_dividend = math.log(dividend)
    log_divisor = math.log(divisor)

    quotient = int(math.exp(log_dividend - log_divisor))

    # Adjust for floating point errors
    while quotient * divisor > dividend:
        quotient -= 1

    return -quotient if negative else quotient


# =============================================================================
# BONUS: Modulo without %
# =============================================================================

def modulo(dividend: int, divisor: int) -> int:
    """
    Calculate modulo without using % operator.

    Example:
        >>> modulo(43, 8)
        3
    """
    quotient = divide(dividend, divisor)
    # dividend = divisor * quotient + remainder
    # remainder = dividend - divisor * quotient

    # Calculate divisor * quotient using addition
    product = 0
    abs_quotient = abs(quotient)
    abs_divisor = abs(divisor)

    while abs_quotient > 0:
        if abs_quotient & 1:
            product += abs_divisor
        abs_divisor <<= 1
        abs_quotient >>= 1

    if (dividend < 0) != (divisor < 0):
        product = -product

    return dividend - product


# =============================================================================
# DEMONSTRATION
# =============================================================================

def demonstrate():
    """Demonstrate the division algorithm."""
    test_cases = [
        (43, 8),
        (10, 3),
        (100, 7),
        (-7, 2),
        (7, -2),
        (-7, -2),
        (1, 1),
        (0, 5),
    ]

    print("=" * 70)
    print("DIVIDE WITHOUT *, / AND MOD")
    print("=" * 70)

    print("\n{:<12} {:<12} {:<12} {:<12} {:<12}".format(
        "Dividend", "Divisor", "Quotient", "Remainder", "Verify"
    ))
    print("-" * 60)

    for dividend, divisor in test_cases:
        quotient = divide(dividend, divisor)
        remainder = modulo(dividend, divisor)
        verify = divisor * quotient + remainder
        print(f"{dividend:<12} {divisor:<12} {quotient:<12} {remainder:<12} {verify:<12}")

    # Detailed walkthrough
    print("\n" + "=" * 70)
    print("DETAILED WALKTHROUGH")
    print("=" * 70)

    divide_verbose(43, 8)


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Run test cases."""
    test_cases = [
        (43, 8, 5),
        (10, 3, 3),
        (7, -3, -2),
        (-7, 3, -2),
        (-7, -3, 2),
        (0, 5, 0),
        (1, 1, 1),
        (100, 10, 10),
        (INT_MIN, -1, INT_MAX),  # Overflow case
    ]

    print("\n" + "=" * 50)
    print("RUNNING TEST CASES")
    print("=" * 50)

    all_passed = True
    for dividend, divisor, expected in test_cases:
        result = divide(dividend, divisor)
        status = "PASS" if result == expected else "FAIL"
        if status == "FAIL":
            all_passed = False

        print(f"{dividend:12d} / {divisor:4d} = {result:12d} (expected {expected:12d}) [{status}]")

    print("-" * 50)
    print("All tests passed!" if all_passed else "Some tests failed!")


if __name__ == "__main__":
    demonstrate()
    run_tests()
