# Divide Two Integers Without Using *, / and mod

## Problem Statement
Given two integers `dividend` and `divisor`, divide them without using multiplication (*), division (/), or modulo (%) operators. Return the quotient.

**Note:** Truncate toward zero (not floor division).

### Examples
```
Input: dividend = 10, divisor = 3
Output: 3
Explanation: 10 / 3 = 3.333... truncated to 3

Input: dividend = 43, divisor = 8
Output: 5
Explanation: 43 / 8 = 5.375 truncated to 5

Input: dividend = -7, divisor = 2
Output: -3
Explanation: -7 / 2 = -3.5 truncated to -3
```

---

## Intuition

### Basic Idea: Repeated Subtraction
The most basic approach is to subtract divisor from dividend until dividend becomes less than divisor. Count the subtractions.

```
43 / 8:
43 - 8 = 35 (count = 1)
35 - 8 = 27 (count = 2)
27 - 8 = 19 (count = 3)
19 - 8 = 11 (count = 4)
11 - 8 = 3  (count = 5)
3 < 8, stop!

Quotient = 5
```

**Problem:** This is O(dividend/divisor) - very slow for large numbers!

### Optimized: Bit Shifting (Exponential Subtraction)

**Key Insight:** `divisor << k` = `divisor * 2^k`

Instead of subtracting one divisor at a time, we can subtract `divisor * 2^k` for the largest possible k.

```
43 / 8:

Find largest k where 8 * 2^k <= 43:
  8 * 2^0 = 8  <= 43 ✓
  8 * 2^1 = 16 <= 43 ✓
  8 * 2^2 = 32 <= 43 ✓
  8 * 2^3 = 64 > 43  ✗

So k = 2: subtract 32, add 2^2 = 4 to quotient
  43 - 32 = 11, quotient = 4

Repeat with 11:
  8 * 2^0 = 8 <= 11 ✓
  8 * 2^1 = 16 > 11 ✗

k = 0: subtract 8, add 2^0 = 1 to quotient
  11 - 8 = 3, quotient = 4 + 1 = 5

3 < 8, stop!

Quotient = 5
```

---

## Algorithm

```python
def divide(dividend, divisor):
    # Handle signs
    negative = (dividend < 0) != (divisor < 0)
    
    # Work with positive numbers
    dividend = abs(dividend)
    divisor = abs(divisor)
    
    quotient = 0
    
    while dividend >= divisor:
        # Find largest k where divisor << k <= dividend
        temp = divisor
        power = 1
        
        while dividend >= (temp << 1):
            temp <<= 1
            power <<= 1
        
        # Subtract and add to quotient
        dividend -= temp
        quotient += power
    
    return -quotient if negative else quotient
```

---

## Dry Run: dividend = 43, divisor = 8

```
Initial: dividend = 43, divisor = 8, quotient = 0

=== Iteration 1 ===
dividend (43) >= divisor (8)? Yes, continue

Find largest k:
  temp = 8, power = 1
  43 >= 8 << 1 = 16? Yes
    temp = 16, power = 2
  43 >= 16 << 1 = 32? Yes
    temp = 32, power = 4
  43 >= 32 << 1 = 64? No, stop

Binary view:
  divisor     = 8   = 001000
  temp        = 32  = 100000  (divisor << 2)
  power       = 4   = 000100  (2^2)

Subtract: dividend = 43 - 32 = 11
Add to quotient: quotient = 0 + 4 = 4

=== Iteration 2 ===
dividend (11) >= divisor (8)? Yes, continue

Find largest k:
  temp = 8, power = 1
  11 >= 8 << 1 = 16? No, stop

Subtract: dividend = 11 - 8 = 3
Add to quotient: quotient = 4 + 1 = 5

=== Iteration 3 ===
dividend (3) >= divisor (8)? No, stop!

RESULT: quotient = 5
```

---

## Binary Visualization

```
43 in binary: 101011
8  in binary: 001000

Division as bit shifting:

43 = 32 + 8 + 3
   = (8 * 4) + (8 * 1) + 3
   = 8 * (4 + 1) + 3
   = 8 * 5 + 3

Quotient = 5 = 101 in binary
Remainder = 3
```

---

## Complexity Analysis

| Metric | Value | Explanation |
|--------|-------|-------------|
| Time | O(log^2 n) | Outer loop: O(log n), Inner loop: O(log n) |
| Space | O(1) | Only using a few variables |

Much better than O(n) for repeated subtraction!

---

## Edge Cases

1. **Divisor = 1**: Return dividend as is
2. **Divisor = -1**: Return -dividend (watch overflow!)
3. **Dividend = 0**: Return 0
4. **Overflow**: INT_MIN / -1 would overflow (return INT_MAX)
5. **Negative numbers**: Handle sign separately

---

## Handling Overflow (32-bit integers)

```python
INT_MAX = 2**31 - 1
INT_MIN = -2**31

def divide_safe(dividend, divisor):
    # Special case: overflow
    if dividend == INT_MIN and divisor == -1:
        return INT_MAX
    
    # ... rest of algorithm
```

---

## Why Bit Shifting Works

```
Left shift (<<) is multiplication by 2:
  8 << 1 = 16 = 8 * 2
  8 << 2 = 32 = 8 * 4
  8 << 3 = 64 = 8 * 8

So finding the largest k where divisor << k <= dividend
is equivalent to finding the largest power of 2 that
fits into the quotient at each step.

We're essentially building the quotient bit by bit
from the most significant bit to the least significant.
```

---

## Related Problems

1. **Modulo without %** - Similar approach, return remainder
2. **Multiply without *** - Use bit shifting and addition
3. **Integer square root** - Binary search with division
