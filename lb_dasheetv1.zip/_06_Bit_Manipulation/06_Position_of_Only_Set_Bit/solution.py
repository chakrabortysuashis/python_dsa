"""
Find Position of Only Set Bit
=============================

Problem: Given a number n that has exactly one set bit (power of 2),
find the position of that bit. Return -1 if n has multiple set bits.

Note: Position is 1-indexed from the right.

Example:
    Input: n = 8
    Output: 4
    Explanation: 8 = 1000, set bit at position 4
"""

import math


def to_binary(n: int, bits: int = 8) -> str:
    """Convert integer to binary string for visualization."""
    if n >= 0:
        return bin(n)[2:].zfill(bits)
    return bin(n & ((1 << bits) - 1))[2:]


# =============================================================================
# APPROACH 1: Iterative Right Shift
# =============================================================================

def find_position_shift(n: int) -> int:
    """
    Find position of only set bit using right shift.

    Algorithm:
        1. Check if exactly one bit is set (power of 2)
        2. Right shift until n becomes 1, counting shifts

    Time Complexity: O(log n)
    Space Complexity: O(1)

    Args:
        n: Integer to check (should be power of 2)

    Returns:
        Position (1-indexed) of the only set bit, or -1 if invalid

    Example:
        >>> find_position_shift(8)
        4
        >>> find_position_shift(16)
        5
        >>> find_position_shift(6)
        -1
    """
    # Check if n is a power of 2
    if n <= 0 or (n & (n - 1)) != 0:
        return -1

    # Count shifts until n becomes 1
    position = 1
    while n > 1:
        n >>= 1
        position += 1

    return position


def find_position_shift_verbose(n: int) -> int:
    """Find position with detailed visualization."""
    print(f"\nFinding position of only set bit in n = {n}")
    print("=" * 50)

    # Step 1: Check if power of 2
    print(f"\nStep 1: Check if n has exactly one set bit")

    if n <= 0:
        print(f"  n = {n} <= 0, returning -1")
        return -1

    bits = max(8, n.bit_length())
    print(f"  n     = {n:4d} = {to_binary(n, bits)}")
    print(f"  n - 1 = {n - 1:4d} = {to_binary(n - 1, bits)}")

    and_result = n & (n - 1)
    print(f"  n & (n-1) = {to_binary(and_result, bits)} = {and_result}")

    if and_result != 0:
        print(f"  Result is not 0, so n has multiple set bits")
        print(f"\nRESULT: -1 (not a valid input)")
        return -1

    print(f"  Result is 0, confirmed exactly one set bit!")

    # Step 2: Find position
    print(f"\nStep 2: Find position by shifting")
    position = 1
    current = n

    while current > 1:
        prev = current
        current >>= 1
        position += 1
        print(f"  {prev:4d} >> 1 = {current:4d} = {to_binary(current, bits)}, position = {position}")

    print(f"\n  n = 1, stop!")
    print(f"\n" + "=" * 50)
    print(f"RESULT: Position = {position}")
    return position


# =============================================================================
# APPROACH 2: Using bit_length (Python specific)
# =============================================================================

def find_position_bit_length(n: int) -> int:
    """
    Find position using Python's bit_length().

    Time Complexity: O(1)
    Space Complexity: O(1)

    Example:
        >>> find_position_bit_length(8)
        4
    """
    if n <= 0 or (n & (n - 1)) != 0:
        return -1
    return n.bit_length()


# =============================================================================
# APPROACH 3: Using log2
# =============================================================================

def find_position_log(n: int) -> int:
    """
    Find position using logarithm.

    Time Complexity: O(1)
    Space Complexity: O(1)

    Example:
        >>> find_position_log(8)
        4
    """
    if n <= 0 or (n & (n - 1)) != 0:
        return -1
    return int(math.log2(n)) + 1


# =============================================================================
# APPROACH 4: Using trailing zeros
# =============================================================================

def find_position_trailing_zeros(n: int) -> int:
    """
    Find position by counting trailing zeros + 1.

    For a power of 2, position = trailing_zeros + 1

    Example:
        >>> find_position_trailing_zeros(8)  # 8 = 1000, 3 trailing zeros
        4
    """
    if n <= 0 or (n & (n - 1)) != 0:
        return -1

    count = 0
    while (n & 1) == 0:
        n >>= 1
        count += 1

    return count + 1


# =============================================================================
# BONUS: Find rightmost set bit position (works for any number)
# =============================================================================

def find_rightmost_set_bit_position(n: int) -> int:
    """
    Find position of rightmost set bit in any number.

    Algorithm:
        1. Isolate rightmost set bit: n & (-n)
        2. Find position of that bit

    Example:
        >>> find_rightmost_set_bit_position(12)  # 12 = 1100
        3
        >>> find_rightmost_set_bit_position(6)   # 6 = 110
        2
    """
    if n <= 0:
        return -1

    # Isolate rightmost set bit
    rightmost = n & (-n)

    # Count position
    position = 1
    while rightmost > 1:
        rightmost >>= 1
        position += 1

    return position


# =============================================================================
# VISUALIZATION
# =============================================================================

def visualize_positions() -> None:
    """Visualize positions for powers of 2."""
    print("\nPowers of 2 and Their Set Bit Positions")
    print("=" * 55)
    print(f"{'n':>6} | {'Binary':>10} | {'Position':>10} | {'Verification':>12}")
    print("-" * 55)

    for power in range(8):
        n = 1 << power
        binary = to_binary(n, 8)
        position = find_position_shift(n)
        verification = f"2^{power} = {n}"
        print(f"{n:>6} | {binary:>10} | {position:>10} | {verification:>12}")


# =============================================================================
# DEMONSTRATION
# =============================================================================

def demonstrate():
    """Demonstrate all approaches with examples."""
    test_values = [1, 2, 4, 6, 8, 16, 32, 64, 12, 0]

    print("=" * 70)
    print("FIND POSITION OF ONLY SET BIT")
    print("=" * 70)

    # Quick comparison
    print("\n{:<8} {:<12} {:<10} {:<10} {:<10} {:<10}".format(
        "n", "Binary", "Shift", "BitLen", "Log", "TrailZero"
    ))
    print("-" * 60)

    for n in test_values:
        m1 = find_position_shift(n)
        m2 = find_position_bit_length(n) if n > 0 else -1
        m3 = find_position_log(n) if n > 0 else -1
        m4 = find_position_trailing_zeros(n) if n > 0 else -1
        binary = to_binary(n, 8) if n >= 0 else "N/A"
        print(f"{n:<8} {binary:<12} {m1:<10} {m2:<10} {m3:<10} {m4:<10}")

    # Visualization
    visualize_positions()

    # Detailed walkthrough
    print("\n" + "=" * 70)
    print("DETAILED WALKTHROUGH")
    print("=" * 70)

    find_position_shift_verbose(32)
    find_position_shift_verbose(6)


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Run test cases."""
    test_cases = [
        (1, 1),
        (2, 2),
        (4, 3),
        (8, 4),
        (16, 5),
        (32, 6),
        (64, 7),
        (128, 8),
        (0, -1),
        (6, -1),
        (12, -1),
    ]

    print("\n" + "=" * 50)
    print("RUNNING TEST CASES")
    print("=" * 50)

    all_passed = True
    for n, expected in test_cases:
        m1 = find_position_shift(n)
        m2 = find_position_bit_length(n)
        m3 = find_position_log(n)

        status = "PASS" if m1 == m2 == m3 == expected else "FAIL"
        if status == "FAIL":
            all_passed = False

        print(f"n={n:4d} -> Expected: {expected:2d}, Got: {m1:2d} [{status}]")

    print("-" * 50)
    print("All tests passed!" if all_passed else "Some tests failed!")


if __name__ == "__main__":
    demonstrate()
    run_tests()
