# Find Position of Only Set Bit

## Problem Statement
Given a number n that has exactly one set bit, find the position of that bit. Return -1 if the number doesn't have exactly one set bit (i.e., not a power of 2).

**Note:** Position is 1-indexed from the right.

### Examples
```
Input: n = 8
Output: 4
Explanation: 8 = 1000 in binary, set bit is at position 4

Input: n = 16
Output: 5
Explanation: 16 = 10000 in binary, set bit is at position 5

Input: n = 6
Output: -1
Explanation: 6 = 110 has multiple set bits
```

---

## Binary Representation Visualization

```
Powers of 2 (numbers with exactly one set bit):

n  | Binary   | Position
---|----------|----------
1  | 00000001 |    1
2  | 00000010 |    2
4  | 00000100 |    3
8  | 00001000 |    4
16 | 00010000 |    5
32 | 00100000 |    6
64 | 01000000 |    7
```

---

## Intuition

### Step 1: Check if n has exactly one set bit
A number has exactly one set bit if and only if it's a power of 2.
- Use: `n > 0 and (n & (n-1)) == 0`

### Step 2: Find the position
Once we confirm it's a power of 2, we need to find which position.

**Method 1: Right shift and count**
```
n = 16 = 10000

Shift right until n becomes 1:
16 >> 1 = 8    (count = 1)
8  >> 1 = 4    (count = 2)
4  >> 1 = 2    (count = 3)
2  >> 1 = 1    (count = 4)

Position = count + 1 = 5
```

**Method 2: Using log base 2**
```
Position = log2(n) + 1

log2(16) + 1 = 4 + 1 = 5
```

---

## Algorithm

### Approach 1: Iterative Right Shift

```python
def get_only_set_bit_position(n):
    # Step 1: Check if exactly one bit is set
    if n <= 0 or (n & (n - 1)) != 0:
        return -1
    
    # Step 2: Count shifts to reach 1
    position = 1
    while n > 1:
        n >>= 1
        position += 1
    
    return position
```

---

## Dry Run: n = 32

```
Step 1: Check if exactly one bit is set
-----------------------------------------
n = 32 = 100000
n > 0? Yes ✓

n & (n-1) = 32 & 31 = 100000 & 011111 = 000000 = 0 ✓
(Exactly one set bit confirmed)

Step 2: Find position by shifting
---------------------------------
n = 32 = 100000, position = 1

Iteration 1: 32 >> 1 = 16 = 010000, position = 2
Iteration 2: 16 >> 1 = 8  = 001000, position = 3
Iteration 3: 8  >> 1 = 4  = 000100, position = 4
Iteration 4: 4  >> 1 = 2  = 000010, position = 5
Iteration 5: 2  >> 1 = 1  = 000001, position = 6

n = 1, stop!

Result: Position = 6
```

---

## Dry Run: n = 6 (Not a power of 2)

```
Step 1: Check if exactly one bit is set
-----------------------------------------
n = 6 = 110
n > 0? Yes ✓

n & (n-1) = 6 & 5 = 110 & 101 = 100 = 4 ≠ 0 ✗
(Multiple set bits)

Result: -1
```

---

## Alternative Approaches

### Using bit_length() (Python-specific)
```python
def get_position_bit_length(n):
    if n <= 0 or (n & (n - 1)) != 0:
        return -1
    return n.bit_length()  # Returns position directly
```

### Using log2
```python
import math
def get_position_log(n):
    if n <= 0 or (n & (n - 1)) != 0:
        return -1
    return int(math.log2(n)) + 1
```

### Using lookup table (0-indexed positions)
```python
# For 32-bit integers, precompute position for each power of 2
# de Bruijn sequence method - O(1) lookup
```

---

## Complexity Analysis

| Approach | Time | Space |
|----------|------|-------|
| Iterative shift | O(log n) | O(1) |
| Using log2 | O(1) | O(1) |
| bit_length() | O(1) | O(1) |

---

## Edge Cases

| Input | Output | Reason |
|-------|--------|--------|
| 0 | -1 | No set bits |
| 1 | 1 | 1 = 2^0, position 1 |
| -8 | -1 | Negative numbers |
| 6 | -1 | Multiple set bits |

---

## Visual Summary

```
Position:  8  7  6  5  4  3  2  1
           |  |  |  |  |  |  |  |
Bit:       0  0  0  0  1  0  0  0  = 8  -> Position 4
Bit:       0  0  0  1  0  0  0  0  = 16 -> Position 5
Bit:       0  0  1  0  0  0  0  0  = 32 -> Position 6
Bit:       0  1  0  0  0  0  0  0  = 64 -> Position 7
```

---

## Related Problems

1. **Check if power of 2** - Prerequisite check
2. **Find rightmost set bit position** - Works for any number
3. **Count trailing zeros** - Same as (position - 1)
