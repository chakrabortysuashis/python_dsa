# Find the K-th Permutation Sequence

## Problem Statement

Given n and k, return the kth permutation sequence of numbers [1, 2, ..., n].

### Example
```
Input: n = 3, k = 3
Output: "213"

All permutations of [1,2,3]:
1. "123"
2. "132"
3. "213"  <- k=3
4. "231"
5. "312"
6. "321"
```

## Why Backtracking Works Here

1. **Generate Permutations**: Systematically generate in order
2. **Count to K**: Stop at kth permutation
3. **Early Exit**: Don't need all permutations

## Recursion Tree Diagram

```
                    ""
           /        |        \
          1         2         3
        / \       / \       / \
      12  13    21  23    31  32
       |   |     |   |     |   |
     123 132   213 231   312 321
      1   2     3   4     5   6

For k=3, we stop at "213"
```

## Backtracking Approach

```python
def get_kth_permutation_backtrack(n, k):
    count = [0]
    result = [None]
    
    def backtrack(current, remaining):
        if not remaining:
            count[0] += 1
            if count[0] == k:
                result[0] = current
            return
        
        for i, num in enumerate(remaining):
            if result[0]:  # Already found
                return
            backtrack(current + str(num), remaining[:i] + remaining[i+1:])
    
    backtrack("", list(range(1, n + 1)))
    return result[0]
```

## Mathematical Approach (More Efficient)

Key insight: There are (n-1)! permutations starting with each digit.

```python
def get_kth_permutation_math(n, k):
    from math import factorial
    
    numbers = list(range(1, n + 1))
    k -= 1  # Convert to 0-indexed
    result = []
    
    for i in range(n, 0, -1):
        fact = factorial(i - 1)
        idx = k // fact
        result.append(str(numbers[idx]))
        numbers.pop(idx)
        k %= fact
    
    return ''.join(result)
```

## Complexity Analysis

### Backtracking
- **Time**: O(n! * n) worst case (generates all permutations)
- **Space**: O(n)

### Mathematical
- **Time**: O(n^2) - n iterations with O(n) list operations
- **Space**: O(n)

## Step-by-Step for n=4, k=9

```
Numbers: [1, 2, 3, 4], k=9 (0-indexed: k=8)

Position 1: 3! = 6 permutations per first digit
  8 // 6 = 1 -> Choose numbers[1] = 2
  8 % 6 = 2
  Numbers: [1, 3, 4], result = "2"

Position 2: 2! = 2 permutations per second digit
  2 // 2 = 1 -> Choose numbers[1] = 3
  2 % 2 = 0
  Numbers: [1, 4], result = "23"

Position 3: 1! = 1
  0 // 1 = 0 -> Choose numbers[0] = 1
  Numbers: [4], result = "231"

Position 4:
  Choose remaining = 4
  result = "2314"

Answer: "2314"
```
