"""
All Paths from Top-Left to Bottom-Right - Backtracking
========================================================

Time: O(2^(M+N)), Space: O(M+N)
"""

from typing import List


def all_paths(matrix: List[List[int]]) -> List[List[int]]:
    """
    Find all paths from (0,0) to (M-1, N-1).
    Only right and down moves allowed.

    Recursion Tree:
            (0,0)
           /     \
       right    down
       (0,1)    (1,0)
         |        |
       ...      ...
    """
    if not matrix:
        return []

    rows, cols = len(matrix), len(matrix[0])
    result = []

    def backtrack(row: int, col: int, path: List[int]) -> None:
        path.append(matrix[row][col])

        # BASE CASE
        if row == rows - 1 and col == cols - 1:
            result.append(path[:])
            path.pop()
            return

        # Move right
        if col + 1 < cols:
            backtrack(row, col + 1, path)

        # Move down
        if row + 1 < rows:
            backtrack(row + 1, col, path)

        # Backtrack
        path.pop()

    backtrack(0, 0, [])
    return result


def all_paths_coordinates(rows: int, cols: int) -> List[List[tuple]]:
    """Return paths as coordinate sequences."""
    result = []

    def backtrack(row: int, col: int, path: List[tuple]) -> None:
        path.append((row, col))

        if row == rows - 1 and col == cols - 1:
            result.append(path[:])
            path.pop()
            return

        if col + 1 < cols:
            backtrack(row, col + 1, path)
        if row + 1 < rows:
            backtrack(row + 1, col, path)

        path.pop()

    backtrack(0, 0, [])
    return result


def count_paths(rows: int, cols: int) -> int:
    """Count paths using combinatorics: C(m+n-2, m-1)."""
    from math import comb
    return comb(rows + cols - 2, rows - 1)


# ============================================================================
# TEST CASES
# ============================================================================

if __name__ == "__main__":
    print("ALL PATHS TOP-LEFT TO BOTTOM-RIGHT")
    print("=" * 40)

    matrix = [
        [1, 2, 3],
        [4, 5, 6]
    ]

    print("Matrix:")
    for row in matrix:
        print(row)

    paths = all_paths(matrix)
    print(f"\nAll paths ({len(paths)}):")
    for p in paths:
        print(f"  {' -> '.join(map(str, p))}")

    print(f"\nUsing formula: C({2+3-2}, {2-1}) = {count_paths(2, 3)} paths")

    # 3x3 matrix
    print("\n" + "-" * 40)
    coord_paths = all_paths_coordinates(3, 3)
    print(f"3x3 matrix: {len(coord_paths)} paths")
    for p in coord_paths[:5]:
        print(f"  {p}")
    if len(coord_paths) > 5:
        print(f"  ... and {len(coord_paths) - 5} more")
