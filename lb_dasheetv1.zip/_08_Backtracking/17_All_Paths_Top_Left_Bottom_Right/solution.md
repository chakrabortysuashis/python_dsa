# Print All Possible Paths from Top Left to Bottom Right

## Problem Statement

Given an MxN matrix, find all possible paths from top-left (0,0) to bottom-right (M-1, N-1). You can only move right or down.

### Example
```
Matrix 2x3:
1 2 3
4 5 6

Paths:
1 -> 2 -> 3 -> 6
1 -> 2 -> 5 -> 6
1 -> 4 -> 5 -> 6
```

## Why Backtracking Works Here

1. **Two Choices**: At each cell, go right or down
2. **All Paths Needed**: Systematic exploration
3. **No Revisiting**: Each cell visited once per path

## Recursion Tree Diagram

```
For 2x2 matrix:
                (0,0)
               /     \
          right      down
          (0,1)      (1,0)
            |          |
          down       right
          (1,1)      (1,1)
            |          |
         PATH 1     PATH 2
```

## Code Template

```python
def all_paths(matrix):
    rows, cols = len(matrix), len(matrix[0])
    result = []
    
    def backtrack(row, col, path):
        # Add current cell to path
        path.append(matrix[row][col])
        
        # BASE CASE: Reached destination
        if row == rows - 1 and col == cols - 1:
            result.append(path[:])
            path.pop()
            return
        
        # Move right
        if col + 1 < cols:
            backtrack(row, col + 1, path)
        
        # Move down
        if row + 1 < rows:
            backtrack(row + 1, col, path)
        
        # Backtrack
        path.pop()
    
    backtrack(0, 0, [])
    return result
```

## Time & Space Complexity
- **Time**: O(2^(M+N)) - binary tree of depth M+N-1
- **Space**: O(M+N) - path length

## Number of Paths Formula
For MxN matrix (only right/down moves):
Total paths = C(M+N-2, M-1) = C(M+N-2, N-1)
