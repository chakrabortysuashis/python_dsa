# Find if There is a Path of More Than K Length

## Problem Statement

Given a weighted graph and two vertices u and v, find if there exists a simple path (no repeated vertices) of length more than K from u to v.

### Example
```
Graph: 0--1--2--3
       |  |     |
       4--+-----+

With weights on edges.
Check if path from 0 to 3 with length > K exists.
```

## Why Backtracking Works Here

1. **Multiple Paths**: Many possible paths in graph
2. **Length Tracking**: Sum edge weights along path
3. **No Repetition**: Can't revisit vertices (simple path)
4. **Early Termination**: Found path > K, stop

## Recursion Tree

```
From vertex u, target v, K=10:

            u (dist=0)
          / | \
        a   b   c  (neighbors of u)
        |   |
    dist+=w dist+=w
        |   |
    check  check
    >K?    >K?
```

## Code Template

```python
def path_more_than_k(graph, u, v, k):
    """
    graph: adjacency list with weights
           graph[u] = [(v1, w1), (v2, w2), ...]
    """
    visited = set()
    
    def backtrack(curr, target, curr_dist):
        if curr == target:
            return curr_dist > k
        
        visited.add(curr)
        
        for neighbor, weight in graph[curr]:
            if neighbor not in visited:
                if backtrack(neighbor, target, curr_dist + weight):
                    return True
        
        visited.remove(curr)  # Backtrack
        return False
    
    return backtrack(u, v, 0)
```

## Time & Space Complexity
- **Time**: O(V!) worst case - all simple paths
- **Space**: O(V) - visited set and recursion
