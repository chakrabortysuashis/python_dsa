"""
Path More Than K Length - Backtracking
=======================================

Time: O(V!), Space: O(V)
"""

from typing import List, Tuple, Dict


def path_more_than_k(graph: Dict[int, List[Tuple[int, int]]], u: int, v: int, k: int) -> bool:
    """
    Check if simple path from u to v with length > k exists.

    graph: adjacency list with weights
           graph[u] = [(neighbor, weight), ...]

    Recursion Tree:
            u (dist=0)
          /   |   \
        n1   n2   n3
         |
       dist+w1
         |
       continue...
    """
    visited = set()

    def backtrack(curr: int, target: int, curr_dist: int) -> bool:
        # Reached target
        if curr == target:
            return curr_dist > k

        visited.add(curr)

        for neighbor, weight in graph.get(curr, []):
            if neighbor not in visited:
                if backtrack(neighbor, target, curr_dist + weight):
                    return True

        visited.remove(curr)  # Backtrack
        return False

    return backtrack(u, v, 0)


def find_path_more_than_k(graph: Dict[int, List[Tuple[int, int]]],
                          u: int, v: int, k: int) -> List[int]:
    """Return the actual path if it exists."""
    visited = set()
    path = []

    def backtrack(curr, curr_dist):
        path.append(curr)

        if curr == v:
            if curr_dist > k:
                return True
            path.pop()
            return False

        visited.add(curr)

        for neighbor, weight in graph.get(curr, []):
            if neighbor not in visited:
                if backtrack(neighbor, curr_dist + weight):
                    return True

        visited.remove(curr)
        path.pop()
        return False

    if backtrack(u, 0):
        return path
    return []


# ============================================================================
# TEST CASES
# ============================================================================

if __name__ == "__main__":
    print("PATH MORE THAN K LENGTH")
    print("=" * 40)

    # Create weighted graph
    # 0 --(4)-- 1 --(8)-- 2 --(3)-- 3
    # |         |                   |
    # (3)      (2)                 (7)
    # |         |                   |
    # 4 --------+-------------------+

    graph = {
        0: [(1, 4), (4, 3)],
        1: [(0, 4), (2, 8), (4, 2)],
        2: [(1, 8), (3, 3)],
        3: [(2, 3), (4, 7)],
        4: [(0, 3), (1, 2), (3, 7)]
    }

    print("Graph edges:")
    for node, edges in graph.items():
        for neighbor, weight in edges:
            if node < neighbor:
                print(f"  {node} --({weight})-- {neighbor}")

    tests = [(0, 3, 15), (0, 3, 20), (0, 3, 10)]
    for u, v, k in tests:
        exists = path_more_than_k(graph, u, v, k)
        path = find_path_more_than_k(graph, u, v, k)
        print(f"\n{u} to {v}, k={k}: {'Yes' if exists else 'No'}, path={path}")
