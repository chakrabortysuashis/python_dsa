# Partition of a Set into K Subsets with Equal Sum

## Problem Statement

Given an integer array and a positive integer K, check whether it's possible to divide the array into K non-empty subsets with equal sum.

### Example
```
Input: nums = [4, 3, 2, 3, 5, 2, 1], K = 4
Output: True
Explanation: [5], [4,1], [3,2], [3,2] each sum to 5
```

## Why Backtracking Works Here

1. **K Buckets**: Distribute elements into K groups
2. **Sum Constraint**: Each group must equal target_sum = total/K
3. **Assignment Choices**: Each element can go to any incomplete bucket

## Recursion Tree Diagram

```
For nums=[1,2,3], K=2, target=3:

                    []
            Assign 1 to bucket:
            /            \
       B1:[1]           B2:[1]
           |                |
     Assign 2:         Assign 2:
       / \               / \
  B1:[1,2] B2:[2]   B1:[2] B2:[1,2]
      |        |        |       |
  sum=3!   continue   ...     sum=3!
  
Both buckets filled -> SUCCESS!
```

## Code Template

```python
def can_partition_k_subsets(nums, k):
    total = sum(nums)
    if total % k != 0:
        return False
    
    target = total // k
    nums.sort(reverse=True)  # Optimization
    
    if nums[0] > target:
        return False
    
    buckets = [0] * k
    
    def backtrack(index):
        if index == len(nums):
            return all(b == target for b in buckets)
        
        seen = set()  # Avoid trying same bucket value
        for i in range(k):
            if buckets[i] in seen:
                continue
            if buckets[i] + nums[index] <= target:
                seen.add(buckets[i])
                buckets[i] += nums[index]
                if backtrack(index + 1):
                    return True
                buckets[i] -= nums[index]
        
        return False
    
    return backtrack(0)
```

## Time & Space Complexity
- **Time**: O(k^n) worst case
- **Space**: O(n) for recursion

## Optimizations
1. Sort in descending order (fail fast with large elements)
2. Skip buckets with same current sum (avoid duplicate states)
3. Early termination if element > remaining capacity
