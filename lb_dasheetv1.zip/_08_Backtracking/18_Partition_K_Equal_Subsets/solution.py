"""
Partition into K Equal Sum Subsets - Backtracking
==================================================

Time: O(k^n), Space: O(n)
"""

from typing import List


def can_partition_k_subsets(nums: List[int], k: int) -> bool:
    """
    Check if array can be partitioned into k equal sum subsets.

    Recursion Tree:
        For each element, try adding to each bucket
        that doesn't exceed target.
    """
    total = sum(nums)
    if total % k != 0:
        return False

    target = total // k
    nums.sort(reverse=True)  # Optimization: try larger first

    if nums[0] > target:
        return False

    buckets = [0] * k

    def backtrack(index: int) -> bool:
        if index == len(nums):
            return all(b == target for b in buckets)

        seen = set()  # Skip duplicate bucket sums
        for i in range(k):
            if buckets[i] in seen:
                continue
            if buckets[i] + nums[index] <= target:
                seen.add(buckets[i])
                buckets[i] += nums[index]
                if backtrack(index + 1):
                    return True
                buckets[i] -= nums[index]

        return False

    return backtrack(0)


def partition_k_subsets(nums: List[int], k: int) -> List[List[int]]:
    """Return the actual partition if exists."""
    total = sum(nums)
    if total % k != 0:
        return []

    target = total // k
    nums.sort(reverse=True)

    if nums[0] > target:
        return []

    buckets = [[] for _ in range(k)]
    bucket_sums = [0] * k

    def backtrack(index):
        if index == len(nums):
            if all(s == target for s in bucket_sums):
                return [b[:] for b in buckets]
            return None

        seen = set()
        for i in range(k):
            if bucket_sums[i] in seen:
                continue
            if bucket_sums[i] + nums[index] <= target:
                seen.add(bucket_sums[i])
                buckets[i].append(nums[index])
                bucket_sums[i] += nums[index]
                result = backtrack(index + 1)
                if result:
                    return result
                bucket_sums[i] -= nums[index]
                buckets[i].pop()

        return None

    return backtrack(0) or []


# ============================================================================
# TEST CASES
# ============================================================================

if __name__ == "__main__":
    print("PARTITION INTO K EQUAL SUBSETS")
    print("=" * 40)

    nums = [4, 3, 2, 3, 5, 2, 1]
    k = 4

    print(f"nums = {nums}")
    print(f"k = {k}")
    print(f"Total = {sum(nums)}, Target per subset = {sum(nums)//k}")

    result = can_partition_k_subsets(nums, k)
    print(f"Can partition: {result}")

    partition = partition_k_subsets(nums, k)
    print(f"Partition: {partition}")
    if partition:
        for i, bucket in enumerate(partition):
            print(f"  Bucket {i+1}: {bucket} = {sum(bucket)}")

    # Test 2
    print("\n" + "-" * 40)
    nums2 = [1, 2, 3, 4]
    k2 = 3
    print(f"nums = {nums2}, k = {k2}")
    print(f"Can partition: {can_partition_k_subsets(nums2, k2)}")
