"""
Palindromic Partitions - Backtracking Solution
===============================================

Problem: Partition string so every part is a palindrome.
Time: O(n * 2^n)
Space: O(n)
"""

from typing import List


def palindrome_partition(s: str) -> List[List[str]]:
    """
    Find all palindrome partitions.

    Recursion Tree for "aab":
                "aab"
               /     \
          "a"|"ab"   "aa"|"b"
              |          |
         "a"|"b"      "b"|""
              |          |
         "b"|""      SOLUTION!
              |
         SOLUTION!
    """
    result = []

    def is_palindrome(sub: str) -> bool:
        return sub == sub[::-1]

    def backtrack(start: int, current: List[str]) -> None:
        # BASE CASE
        if start == len(s):
            result.append(current[:])
            return

        # Try each prefix
        for end in range(start + 1, len(s) + 1):
            prefix = s[start:end]
            if is_palindrome(prefix):
                current.append(prefix)
                backtrack(end, current)
                current.pop()

    backtrack(0, [])
    return result


def palindrome_partition_dp(s: str) -> List[List[str]]:
    """Optimized with DP palindrome precomputation."""
    n = len(s)
    # Precompute palindromes
    dp = [[False] * n for _ in range(n)]
    for i in range(n - 1, -1, -1):
        for j in range(i, n):
            if s[i] == s[j] and (j - i < 3 or dp[i + 1][j - 1]):
                dp[i][j] = True

    result = []

    def backtrack(start, current):
        if start == n:
            result.append(current[:])
            return
        for end in range(start, n):
            if dp[start][end]:
                current.append(s[start:end + 1])
                backtrack(end + 1, current)
                current.pop()

    backtrack(0, [])
    return result


# ============================================================================
# TEST CASES
# ============================================================================

if __name__ == "__main__":
    print("PALINDROME PARTITIONING")
    print("=" * 40)

    test_cases = ["aab", "nitin", "aaa", "abc"]
    for s in test_cases:
        print(f"\nInput: \"{s}\"")
        result = palindrome_partition(s)
        print(f"Partitions ({len(result)}):")
        for p in result:
            print(f"  {p}")
