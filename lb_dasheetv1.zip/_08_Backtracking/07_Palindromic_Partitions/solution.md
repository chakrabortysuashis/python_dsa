# Print All Palindromic Partitions of a String

## Problem Statement

Given a string, partition it such that every substring in the partition is a palindrome. Return all possible palindrome partitioning.

### Example

```
Input: "aab"
Output: [["a", "a", "b"], ["aa", "b"]]

Input: "nitin"
Output: [["n", "i", "t", "i", "n"], ["n", "iti", "n"], ["nitin"]]
```

## Why Backtracking Works Here

1. **Multiple Valid Partitions**: Many ways to partition string into palindromes
2. **Constraint at Each Cut**: Each partition must be palindrome
3. **All Solutions Needed**: Systematic exploration required
4. **Prefix-Based Decisions**: Try each valid palindromic prefix

## Recursion Tree Diagram

```
For "aab":

                        "aab"
                       /     \
              "a"|"ab"        "aa"|"b"
                 |               |
            "a"|"b"           "b"|""
               |                 |
          "b"|""            [aa, b] SOLUTION!
               |
        [a, a, b] SOLUTION!

Detailed:
                    partition("aab", 0, [])
                           /          \
            "a" is palindrome        "aa" is palindrome
                   |                        |
        partition("ab", 1, ["a"])    partition("b", 2, ["aa"])
               /        \                     |
        "a" palin    "ab" NOT palin    "b" is palindrome
             |                               |
    partition("b",2,["a","a"])    partition("",3,["aa","b"])
             |                               |
        "b" is palin                   BASE CASE!
             |                         SOLUTION: ["aa","b"]
    partition("",3,["a","a","b"])
             |
        BASE CASE!
        SOLUTION: ["a","a","b"]
```

## Base Case and Recursive Case

```python
def partition(s):
    result = []
    
    def is_palindrome(sub):
        return sub == sub[::-1]
    
    def backtrack(start, current):
        # BASE CASE: Processed entire string
        if start == len(s):
            result.append(current[:])
            return
        
        # Try all possible prefixes
        for end in range(start + 1, len(s) + 1):
            prefix = s[start:end]
            
            if is_palindrome(prefix):
                # DO: Add palindrome
                current.append(prefix)
                
                # RECURSE
                backtrack(end, current)
                
                # UNDO: Backtrack
                current.pop()
    
    backtrack(0, [])
    return result
```

## Time & Space Complexity

- **Time**: O(n * 2^n) - 2^n partitions, O(n) palindrome check
- **Space**: O(n) for recursion stack

## Optimization

Use DP to precompute palindrome status:
```python
# dp[i][j] = True if s[i:j+1] is palindrome
dp = [[False] * n for _ in range(n)]
for i in range(n-1, -1, -1):
    for j in range(i, n):
        if s[i] == s[j] and (j - i < 3 or dp[i+1][j-1]):
            dp[i][j] = True
```
