# Tug of War

## Problem Statement

Given a set of n integers, divide the set into two subsets of n/2 sizes each such that the absolute difference of the sums of two subsets is minimized.

### Example
```
Input: [23, 45, -34, 12, 0, 98, -99, 4, 189, -1]
Output: Subset 1: [45, -34, 12, 98, -1], Subset 2: [23, 0, -99, 4, 189]
Difference: 0
```

## Why Backtracking Works Here

1. **Include/Exclude Pattern**: Each element goes to one of two teams
2. **Size Constraint**: Each team must have n/2 elements
3. **Optimization**: Find minimum difference

## Recursion Tree

```
                  [] vs []
                 /        \
          [a] vs []     [] vs [a]
          /     \          /    \
    [a,b] vs [] [a] vs [b]  ...
        |
   continue until both teams have n/2 elements
```

## Code Template

```python
def tug_of_war(arr):
    n = len(arr)
    total = sum(arr)
    min_diff = [float('inf')]
    result = [None, None]
    
    def backtrack(index, team1, sum1):
        team1_size = len(team1)
        team2_size = index - team1_size
        
        # Pruning: Check if valid partition still possible
        remaining = n - index
        if team1_size + remaining < n // 2:
            return
        if team2_size + remaining < n // 2:
            return
        
        # BASE CASE
        if index == n:
            if team1_size == n // 2:
                diff = abs(2 * sum1 - total)
                if diff < min_diff[0]:
                    min_diff[0] = diff
                    result[0] = team1[:]
                    result[1] = [x for x in arr if x not in team1]
            return
        
        # Include in team 1
        team1.append(arr[index])
        backtrack(index + 1, team1, sum1 + arr[index])
        team1.pop()
        
        # Include in team 2 (exclude from team 1)
        backtrack(index + 1, team1, sum1)
    
    backtrack(0, [], 0)
    return result
```

## Time & Space Complexity
- **Time**: O(2^n) - each element has 2 choices
- **Space**: O(n) - recursion depth
