"""
Tug of War - Backtracking Solution
==================================

Divide array into two equal halves minimizing sum difference.
Time: O(2^n), Space: O(n)
"""

from typing import List, Tuple


def tug_of_war(arr: List[int]) -> Tuple[List[int], List[int], int]:
    """
    Divide into two teams minimizing sum difference.

    Recursion Tree:
            [] vs []
           /        \
      [a] vs []   [] vs [a]
         |
    Continue until n/2 in each
    """
    n = len(arr)
    total = sum(arr)
    min_diff = [float('inf')]
    best = [[], []]

    def backtrack(index: int, team1: List[int], sum1: int) -> None:
        t1_size = len(team1)
        t2_size = index - t1_size
        remaining = n - index

        # Pruning
        if t1_size > n // 2 or t2_size > (n + 1) // 2:
            return
        if t1_size + remaining < n // 2:
            return
        if t2_size + remaining < (n + 1) // 2:
            return

        # BASE CASE
        if index == n:
            if t1_size == n // 2:
                diff = abs(2 * sum1 - total)
                if diff < min_diff[0]:
                    min_diff[0] = diff
                    best[0] = team1[:]
                    best[1] = [arr[i] for i in range(n) if arr[i] not in team1 or team1.count(arr[i]) < [arr[j] for j in range(n)].count(arr[i])]
            return

        # Include in team 1
        team1.append(arr[index])
        backtrack(index + 1, team1, sum1 + arr[index])
        team1.pop()

        # Include in team 2
        backtrack(index + 1, team1, sum1)

    backtrack(0, [], 0)

    # Build team 2 properly
    t1_indices = set()
    team1_copy = best[0][:]
    for i in range(n):
        if arr[i] in team1_copy:
            t1_indices.add(i)
            team1_copy.remove(arr[i])
    team2 = [arr[i] for i in range(n) if i not in t1_indices]

    return best[0], team2, min_diff[0]


# ============================================================================
# TEST CASES
# ============================================================================

if __name__ == "__main__":
    print("TUG OF WAR")
    print("=" * 40)

    arr = [23, 45, -34, 12, 0, 98, -99, 4, 189, -1]
    print(f"Array: {arr}")

    t1, t2, diff = tug_of_war(arr)
    print(f"Team 1: {t1}, Sum: {sum(t1)}")
    print(f"Team 2: {t2}, Sum: {sum(t2)}")
    print(f"Difference: {diff}")

    # Test 2
    arr2 = [3, 4, 5, -3, 100, 1, 89, 54, 23, 20]
    print(f"\nArray: {arr2}")
    t1, t2, diff = tug_of_war(arr2)
    print(f"Team 1: {t1}, Sum: {sum(t1)}")
    print(f"Team 2: {t2}, Sum: {sum(t2)}")
    print(f"Difference: {diff}")
