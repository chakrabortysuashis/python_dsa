# Find Maximum Number Possible by Doing At-Most K Swaps

## Problem Statement

Given a positive integer represented as a string and a value K, find the maximum number possible by doing at most K swap operations on its digits.

### Example
```
Input: str = "7599", K = 2
Output: "9975"
Explanation: Swap 7 with 9 -> "9597", Swap 5 with 9 -> "9975"
```

## Why Backtracking Works Here

1. **Multiple Swap Choices**: At each step, many pairs to swap
2. **Limited Operations**: K swaps constraint
3. **Optimization**: Find maximum value

## Recursion Tree

```
For "129", K=1:
                "129"
            /     |      \
    swap(0,1)  swap(0,2)  swap(1,2)
       "219"    "921"      "192"
         |        |          |
       K=0      K=0        K=0
       
Maximum: "921"
```

## Code Template

```python
def find_max_k_swaps(num, k):
    max_num = [num]
    
    def backtrack(s, k):
        if k == 0:
            return
        
        n = len(s)
        for i in range(n - 1):
            for j in range(i + 1, n):
                # Only swap if it increases the number
                if s[j] > s[i]:
                    # Swap
                    new_s = list(s)
                    new_s[i], new_s[j] = new_s[j], new_s[i]
                    new_s = ''.join(new_s)
                    
                    if new_s > max_num[0]:
                        max_num[0] = new_s
                    
                    backtrack(new_s, k - 1)
    
    backtrack(num, k)
    return max_num[0]
```

## Optimization
- Only swap if digit at j > digit at i
- Start inner loop from rightmost maximum digit
- Prune when current can't exceed max

## Time & Space Complexity
- **Time**: O((n^2)^k) worst case, n = number of digits
- **Space**: O(k) - recursion depth
