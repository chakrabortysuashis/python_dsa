"""
Maximum Number with K Swaps - Backtracking
==========================================

Time: O((n^2)^k), Space: O(k)
"""


def find_max_k_swaps(num: str, k: int) -> str:
    """
    Find maximum number with at most K swaps.

    Recursion Tree for "129", K=1:
            "129"
          /   |   \
       "219" "921" "192"

    Only swap if it increases value.
    """
    max_num = [num]

    def backtrack(s: str, swaps_left: int) -> None:
        if swaps_left == 0:
            return

        n = len(s)
        for i in range(n - 1):
            for j in range(i + 1, n):
                # Only swap if beneficial
                if s[j] > s[i]:
                    # Swap
                    lst = list(s)
                    lst[i], lst[j] = lst[j], lst[i]
                    new_s = ''.join(lst)

                    if new_s > max_num[0]:
                        max_num[0] = new_s

                    backtrack(new_s, swaps_left - 1)

    backtrack(num, k)
    return max_num[0]


def find_max_k_swaps_optimized(num: str, k: int) -> str:
    """
    Optimized: For each position, find max digit to its right.
    """
    max_num = [num]

    def backtrack(s: str, pos: int, swaps_left: int) -> None:
        if swaps_left == 0 or pos == len(s):
            return

        n = len(s)
        # Find maximum digit from pos to end
        max_digit = s[pos]
        for i in range(pos + 1, n):
            if s[i] > max_digit:
                max_digit = s[i]

        # If current is already max, move to next position
        if s[pos] == max_digit:
            backtrack(s, pos + 1, swaps_left)
            return

        # Swap with all positions having max_digit
        for i in range(pos + 1, n):
            if s[i] == max_digit:
                lst = list(s)
                lst[pos], lst[i] = lst[i], lst[pos]
                new_s = ''.join(lst)

                if new_s > max_num[0]:
                    max_num[0] = new_s

                backtrack(new_s, pos + 1, swaps_left - 1)

    backtrack(num, 0, k)
    return max_num[0]


# ============================================================================
# TEST CASES
# ============================================================================

if __name__ == "__main__":
    print("MAXIMUM NUMBER WITH K SWAPS")
    print("=" * 40)

    tests = [
        ("7599", 2),
        ("129", 1),
        ("1234567", 3),
        ("4321", 2),
    ]

    for num, k in tests:
        result = find_max_k_swaps(num, k)
        optimized = find_max_k_swaps_optimized(num, k)
        print(f"num={num}, k={k} -> {result} (optimized: {optimized})")
