# Sudoku Solver

## Problem Statement

Solve a Sudoku puzzle by filling empty cells (marked as `.` or `0`) following these rules:
1. Each row must contain digits 1-9 without repetition
2. Each column must contain digits 1-9 without repetition  
3. Each of the nine 3x3 sub-boxes must contain digits 1-9 without repetition

## Why Backtracking Works Here

1. **Constraint Satisfaction**: Multiple constraints must be satisfied simultaneously
2. **Trial and Error**: Try a digit, if it violates constraints, try another
3. **Systematic Search**: Fill cells one by one, backtrack on conflicts
4. **Pruning**: Invalid placements detected early via constraint checking

## Recursion Tree Diagram

```
For partially filled Sudoku with empty cell at (0,0):

                    solve(board)
                         |
                 Find empty cell (0,0)
                         |
           +----+----+----+----+----+----+----+----+----+
           |    |    |    |    |    |    |    |    |    |
          1    2    3    4    5    6    7    8    9
           |    |    |    |    |    |    |    |    |
        valid? valid? ...  ...  ...  ...  ...  ...  ...
           |
     if valid, place 1
     find next empty (0,2)
           |
    +------+------+
    |      |      |
   try 1  try 2  try 3...
    |
  valid?
    |
  continue...

Tree structure:
                         []
                        /|\
                       1 2 3 ... (try digits for cell 1)
                      /|\
                     1 2 3 ... (try digits for cell 2)
                    /|\
                   ...
                   
If any branch reaches all cells filled -> SOLUTION
If all digits fail for a cell -> BACKTRACK
```

## Base Case Identification

```python
# BASE CASE 1: Find next empty cell
# If no empty cell exists, puzzle is solved!
if not find_empty_cell(board):
    return True  # Solution found!

# PRUNING: Number violates constraint
if not is_valid(board, row, col, num):
    continue  # Skip this number
```

## Recursive Case Explanation

```python
def solve(board):
    # Find an empty cell
    empty = find_empty_cell(board)
    if not empty:
        return True  # No empty cells = solved!
    
    row, col = empty
    
    # Try digits 1-9
    for num in range(1, 10):
        if is_valid(board, row, col, num):
            # DO: Place number
            board[row][col] = num
            
            # RECURSE: Try to solve rest
            if solve(board):
                return True  # Solution found!
            
            # UNDO: Backtrack
            board[row][col] = 0
    
    return False  # No valid number, backtrack
```

## Step-by-Step Dry Run

```
Initial Board:
5 3 . | . 7 . | . . .
6 . . | 1 9 5 | . . .
. 9 8 | . . . | . 6 .
------+-------+------
8 . . | . 6 . | . . 3
4 . . | 8 . 3 | . . 1
7 . . | . 2 . | . . 6
------+-------+------
. 6 . | . . . | 2 8 .
. . . | 4 1 9 | . . 5
. . . | . 8 . | . 7 9

Step 1: Find empty cell (0, 2)
        Try 1: Check row 0 - valid
               Check col 2 - has 8, no 1 - valid
               Check box - no 1 - valid
        Place 1
        
Step 2: Find next empty (0, 3)
        Try 1: Row has 1 at (0,2) - INVALID
        Try 2: valid? Check constraints...
        Continue...

... Backtracking occurs when no digit works ...

Final Solved:
5 3 4 | 6 7 8 | 9 1 2
6 7 2 | 1 9 5 | 3 4 8
1 9 8 | 3 4 2 | 5 6 7
------+-------+------
8 5 9 | 7 6 1 | 4 2 3
4 2 6 | 8 5 3 | 7 9 1
7 1 3 | 9 2 4 | 8 5 6
------+-------+------
9 6 1 | 5 3 7 | 2 8 4
2 8 7 | 4 1 9 | 6 3 5
3 4 5 | 2 8 6 | 1 7 9
```

## Time Complexity

**O(9^(n))** where n = number of empty cells
- Each empty cell has at most 9 choices
- In practice, constraints prune most branches

## Space Complexity

**O(n)** for recursion stack where n = number of empty cells

## Optimizations

1. **Constraint Propagation**: Reduce possibilities before guessing
2. **Choose Cell Wisely**: Fill cell with fewest valid options first (MRV heuristic)
3. **Use Sets for O(1) Lookup**: Track used numbers in rows/cols/boxes

## Key Validation Function

```python
def is_valid(board, row, col, num):
    # Check row
    if num in board[row]:
        return False
    
    # Check column
    if num in [board[i][col] for i in range(9)]:
        return False
    
    # Check 3x3 box
    box_row, box_col = 3 * (row // 3), 3 * (col // 3)
    for i in range(box_row, box_row + 3):
        for j in range(box_col, box_col + 3):
            if board[i][j] == num:
                return False
    
    return True
```

## Related Problems

- N-Queens
- Crossword Puzzle Solver
- Graph Coloring
- Constraint Satisfaction Problems (CSP)
