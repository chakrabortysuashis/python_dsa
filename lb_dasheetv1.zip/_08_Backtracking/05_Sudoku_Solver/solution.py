"""
Sudoku Solver - Backtracking Solution
======================================

Problem: Fill a 9x9 Sudoku board following constraints:
         - Each row has digits 1-9 without repetition
         - Each column has digits 1-9 without repetition
         - Each 3x3 box has digits 1-9 without repetition

Time Complexity: O(9^n) where n = empty cells
Space Complexity: O(n) for recursion stack
"""

from typing import List, Optional, Tuple, Set


def solve_sudoku(board: List[List[int]]) -> bool:
    """
    Solve Sudoku puzzle in-place using backtracking.

    Recursion Tree:
                    solve()
                       |
              find empty cell (r,c)
                       |
         +---+---+---+---+---+---+---+---+---+
         1   2   3   4   5   6   7   8   9
         |
    is_valid? -> place -> solve() -> backtrack

    Args:
        board: 9x9 grid (0 represents empty)

    Returns:
        True if solved, False if unsolvable
    """
    def find_empty() -> Optional[Tuple[int, int]]:
        """Find the next empty cell (value 0)."""
        for i in range(9):
            for j in range(9):
                if board[i][j] == 0:
                    return (i, j)
        return None

    def is_valid(row: int, col: int, num: int) -> bool:
        """Check if placing num at (row, col) is valid."""
        # Check row
        if num in board[row]:
            return False

        # Check column
        for i in range(9):
            if board[i][col] == num:
                return False

        # Check 3x3 box
        box_row, box_col = 3 * (row // 3), 3 * (col // 3)
        for i in range(box_row, box_row + 3):
            for j in range(box_col, box_col + 3):
                if board[i][j] == num:
                    return False

        return True

    # Find empty cell
    empty = find_empty()
    if not empty:
        return True  # No empty cells = solved!

    row, col = empty

    # Try digits 1-9
    for num in range(1, 10):
        if is_valid(row, col, num):
            # DO: Place number
            board[row][col] = num

            # RECURSE
            if solve_sudoku(board):
                return True

            # UNDO: Backtrack
            board[row][col] = 0

    return False


def solve_sudoku_optimized(board: List[List[int]]) -> bool:
    """
    Optimized version with sets for O(1) validation.
    """
    # Initialize tracking sets
    rows = [set() for _ in range(9)]
    cols = [set() for _ in range(9)]
    boxes = [set() for _ in range(9)]
    empty_cells = []

    # Fill initial state
    for i in range(9):
        for j in range(9):
            if board[i][j] != 0:
                num = board[i][j]
                rows[i].add(num)
                cols[j].add(num)
                boxes[(i // 3) * 3 + j // 3].add(num)
            else:
                empty_cells.append((i, j))

    def backtrack(idx: int) -> bool:
        if idx == len(empty_cells):
            return True

        row, col = empty_cells[idx]
        box_idx = (row // 3) * 3 + col // 3

        for num in range(1, 10):
            if num not in rows[row] and num not in cols[col] and num not in boxes[box_idx]:
                # Place
                board[row][col] = num
                rows[row].add(num)
                cols[col].add(num)
                boxes[box_idx].add(num)

                if backtrack(idx + 1):
                    return True

                # Backtrack
                board[row][col] = 0
                rows[row].remove(num)
                cols[col].remove(num)
                boxes[box_idx].remove(num)

        return False

    return backtrack(0)


def print_board(board: List[List[int]]) -> None:
    """Pretty print Sudoku board."""
    for i in range(9):
        if i % 3 == 0 and i != 0:
            print("-" * 21)
        row_str = ""
        for j in range(9):
            if j % 3 == 0 and j != 0:
                row_str += "| "
            val = board[i][j]
            row_str += (str(val) if val != 0 else ".") + " "
        print(row_str)


def solve_with_trace(board: List[List[int]]) -> bool:
    """Version with trace output."""
    steps = [0]

    def find_empty():
        for i in range(9):
            for j in range(9):
                if board[i][j] == 0:
                    return (i, j)
        return None

    def is_valid(row, col, num):
        if num in board[row]:
            return False
        for i in range(9):
            if board[i][col] == num:
                return False
        br, bc = 3 * (row // 3), 3 * (col // 3)
        for i in range(br, br + 3):
            for j in range(bc, bc + 3):
                if board[i][j] == num:
                    return False
        return True

    def backtrack(depth):
        steps[0] += 1
        indent = "  " * min(depth, 10)

        empty = find_empty()
        if not empty:
            print(f"{indent}SOLVED!")
            return True

        row, col = empty
        print(f"{indent}Cell ({row},{col}): trying digits...")

        for num in range(1, 10):
            if is_valid(row, col, num):
                print(f"{indent}  Place {num}")
                board[row][col] = num

                if backtrack(depth + 1):
                    return True

                print(f"{indent}  Backtrack from {num}")
                board[row][col] = 0

        return False

    result = backtrack(0)
    print(f"\nTotal steps: {steps[0]}")
    return result


# ============================================================================
# TEST CASES
# ============================================================================

def run_tests():
    print("=" * 60)
    print("SUDOKU SOLVER")
    print("=" * 60)

    # Test Case 1: Standard puzzle
    board1 = [
        [5, 3, 0, 0, 7, 0, 0, 0, 0],
        [6, 0, 0, 1, 9, 5, 0, 0, 0],
        [0, 9, 8, 0, 0, 0, 0, 6, 0],
        [8, 0, 0, 0, 6, 0, 0, 0, 3],
        [4, 0, 0, 8, 0, 3, 0, 0, 1],
        [7, 0, 0, 0, 2, 0, 0, 0, 6],
        [0, 6, 0, 0, 0, 0, 2, 8, 0],
        [0, 0, 0, 4, 1, 9, 0, 0, 5],
        [0, 0, 0, 0, 8, 0, 0, 7, 9]
    ]

    print("\nInitial Board:")
    print_board(board1)

    if solve_sudoku(board1):
        print("\nSolved Board:")
        print_board(board1)
    else:
        print("No solution exists")

    # Test Case 2: Easy puzzle with optimized solver
    print("\n" + "-" * 40)
    board2 = [
        [0, 0, 0, 2, 6, 0, 7, 0, 1],
        [6, 8, 0, 0, 7, 0, 0, 9, 0],
        [1, 9, 0, 0, 0, 4, 5, 0, 0],
        [8, 2, 0, 1, 0, 0, 0, 4, 0],
        [0, 0, 4, 6, 0, 2, 9, 0, 0],
        [0, 5, 0, 0, 0, 3, 0, 2, 8],
        [0, 0, 9, 3, 0, 0, 0, 7, 4],
        [0, 4, 0, 0, 5, 0, 0, 3, 6],
        [7, 0, 3, 0, 1, 8, 0, 0, 0]
    ]

    print("\nOptimized Solver Test:")
    print_board(board2)
    solve_sudoku_optimized(board2)
    print("\nSolved:")
    print_board(board2)

    print("\n" + "=" * 60)
    print("TESTS COMPLETED!")
    print("=" * 60)


if __name__ == "__main__":
    run_tests()
