"""
Subset Sum Problem - Backtracking Solution
==========================================

Time: O(2^n), Space: O(n)
"""

from typing import List


def subset_sum_exists(nums: List[int], target: int) -> bool:
    """Check if any subset sums to target."""
    def backtrack(index: int, curr_sum: int) -> bool:
        if curr_sum == target:
            return True
        if curr_sum > target or index >= len(nums):
            return False
        # Include or exclude
        return backtrack(index + 1, curr_sum + nums[index]) or backtrack(index + 1, curr_sum)

    return backtrack(0, 0)


def find_all_subset_sums(nums: List[int], target: int) -> List[List[int]]:
    """
    Find all subsets that sum to target.

    Recursion Tree:
                sum=0
               /     \
          +nums[0]  skip
             |        |
            ...      ...
    """
    result = []
    nums.sort()  # Sort for pruning

    def backtrack(index: int, current: List[int], curr_sum: int) -> None:
        if curr_sum == target:
            result.append(current[:])
            return

        if curr_sum > target or index >= len(nums):
            return

        # Include
        current.append(nums[index])
        backtrack(index + 1, current, curr_sum + nums[index])
        current.pop()

        # Exclude (skip duplicates)
        while index + 1 < len(nums) and nums[index] == nums[index + 1]:
            index += 1
        backtrack(index + 1, current, curr_sum)

    backtrack(0, [], 0)
    return result


def count_subset_sums(nums: List[int], target: int) -> int:
    """Count subsets that sum to target."""
    count = [0]

    def backtrack(index, curr_sum):
        if curr_sum == target:
            count[0] += 1
            return
        if curr_sum > target or index >= len(nums):
            return
        backtrack(index + 1, curr_sum + nums[index])
        backtrack(index + 1, curr_sum)

    backtrack(0, 0)
    return count[0]


# ============================================================================
# TEST CASES
# ============================================================================

if __name__ == "__main__":
    print("SUBSET SUM PROBLEM")
    print("=" * 40)

    nums = [3, 34, 4, 12, 5, 2]
    target = 9

    print(f"Array: {nums}")
    print(f"Target: {target}")
    print(f"Exists: {subset_sum_exists(nums, target)}")
    print(f"Subsets: {find_all_subset_sums(nums, target)}")
    print(f"Count: {count_subset_sums(nums, target)}")
