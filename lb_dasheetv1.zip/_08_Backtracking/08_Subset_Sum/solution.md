# Subset Sum Problem

## Problem Statement

Given a set of non-negative integers and a target sum, determine if there exists a subset whose sum equals the target. Find all such subsets.

### Example
```
Input: nums = [3, 34, 4, 12, 5, 2], target = 9
Output: True (subsets: [4, 5], [3, 4, 2])
```

## Why Backtracking Works Here

1. **Include/Exclude Decision**: For each element, choose to include or exclude
2. **Sum Constraint**: Track running sum, prune when exceeded
3. **Multiple Solutions**: May need all valid subsets

## Recursion Tree Diagram

```
For nums=[3,4,2], target=5:

                    sum=0, idx=0
                   /            \
           Include 3           Exclude 3
           sum=3, idx=1        sum=0, idx=1
          /        \            /        \
     Inc 4      Exc 4      Inc 4      Exc 4
     sum=7      sum=3      sum=4      sum=0
     PRUNE!    /    \     /    \     /    \
           Inc 2  Exc 2 Inc 2  Exc 2 ...
           sum=5  sum=3 sum=6  sum=4
           FOUND!       PRUNE!

Solution: [3, 2] and [4] (if target was 4)
```

## Code Template

```python
def subset_sum(nums, target):
    result = []
    
    def backtrack(index, current, curr_sum):
        # BASE CASE: Found target
        if curr_sum == target:
            result.append(current[:])
            return
        
        # PRUNING: Exceeded target or no more elements
        if curr_sum > target or index >= len(nums):
            return
        
        # Include nums[index]
        current.append(nums[index])
        backtrack(index + 1, current, curr_sum + nums[index])
        current.pop()
        
        # Exclude nums[index]
        backtrack(index + 1, current, curr_sum)
    
    backtrack(0, [], 0)
    return result
```

## Time & Space Complexity
- **Time**: O(2^n) - each element can be included or excluded
- **Space**: O(n) - recursion depth
