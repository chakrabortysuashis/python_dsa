"""
Combination Sum - Backtracking Solution
========================================

Time: O(N^(T/M)), Space: O(T/M)
"""

from typing import List


def combination_sum(candidates: List[int], target: int) -> List[List[int]]:
    """
    Find all combinations summing to target.
    Same number can be used multiple times.

    Recursion Tree for [2,3], target=5:
            sum=0
           /     \
      +2=2      +3=3
         |         |
      +2=4      +3=6 PRUNE
         |
      +3=7 PRUNE
    """
    result = []
    candidates.sort()

    def backtrack(start: int, current: List[int], curr_sum: int) -> None:
        if curr_sum == target:
            result.append(current[:])
            return

        if curr_sum > target:
            return

        for i in range(start, len(candidates)):
            if candidates[i] > target - curr_sum:
                break

            current.append(candidates[i])
            backtrack(i, current, curr_sum + candidates[i])  # i not i+1
            current.pop()

    backtrack(0, [], 0)
    return result


def combination_sum2(candidates: List[int], target: int) -> List[List[int]]:
    """
    Variation: Each number can only be used once.
    """
    result = []
    candidates.sort()

    def backtrack(start: int, current: List[int], curr_sum: int) -> None:
        if curr_sum == target:
            result.append(current[:])
            return

        for i in range(start, len(candidates)):
            if candidates[i] > target - curr_sum:
                break
            # Skip duplicates
            if i > start and candidates[i] == candidates[i - 1]:
                continue

            current.append(candidates[i])
            backtrack(i + 1, current, curr_sum + candidates[i])  # i+1 to avoid reuse
            current.pop()

    backtrack(0, [], 0)
    return result


# ============================================================================
# TEST CASES
# ============================================================================

if __name__ == "__main__":
    print("COMBINATION SUM")
    print("=" * 40)

    candidates = [2, 3, 6, 7]
    target = 7
    print(f"Candidates: {candidates}, Target: {target}")
    print(f"Combinations: {combination_sum(candidates, target)}")

    candidates2 = [10, 1, 2, 7, 6, 1, 5]
    target2 = 8
    print(f"\nCandidates: {candidates2}, Target: {target2}")
    print(f"Combinations (no repeat): {combination_sum2(candidates2, target2)}")
