# Combination Sum

## Problem Statement

Given an array of distinct integers candidates and a target integer target, return a list of all unique combinations of candidates where the chosen numbers sum to target. The same number may be chosen unlimited times.

### Example
```
Input: candidates = [2,3,6,7], target = 7
Output: [[2,2,3], [7]]
```

## Why Backtracking Works Here

1. **Multiple Combinations**: Many ways to reach target
2. **Repetition Allowed**: Can use same element multiple times
3. **Pruning**: Skip when sum exceeds target

## Recursion Tree Diagram

```
For candidates=[2,3], target=5:

                    sum=0
                   /     \
              +2=2      +3=3
             /    \        |
        +2=4    +3=5     +3=6
         |     FOUND!   PRUNE!
       +2=6
      PRUNE!
       +3=7
      PRUNE!

Solutions: [2,3] (sum=5)
          [2,2,...] etc.
```

## Code Template

```python
def combination_sum(candidates, target):
    result = []
    candidates.sort()
    
    def backtrack(start, current, curr_sum):
        if curr_sum == target:
            result.append(current[:])
            return
        
        if curr_sum > target:
            return  # Prune
        
        for i in range(start, len(candidates)):
            # Pruning: if candidate > remaining, skip rest (sorted)
            if candidates[i] > target - curr_sum:
                break
            
            current.append(candidates[i])
            # Start from i (not i+1) to allow repetition
            backtrack(i, current, curr_sum + candidates[i])
            current.pop()
    
    backtrack(0, [], 0)
    return result
```

## Time & Space Complexity
- **Time**: O(N^(T/M)) where T=target, M=min candidate
- **Space**: O(T/M) - max recursion depth
