"""
Shortest Safe Route with Landmines - Backtracking
==================================================

Time: O(4^(M*N)), Space: O(M*N)
"""

from typing import List, Tuple
from collections import deque


def shortest_safe_route_backtrack(field: List[List[int]]) -> int:
    """Find shortest safe path using backtracking."""
    if not field:
        return -1

    rows, cols = len(field), len(field[0])
    directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]

    # Mark unsafe cells
    safe = [[field[i][j] for j in range(cols)] for i in range(rows)]
    for i in range(rows):
        for j in range(cols):
            if field[i][j] == 0:
                for di, dj in directions:
                    ni, nj = i + di, j + dj
                    if 0 <= ni < rows and 0 <= nj < cols:
                        safe[ni][nj] = 0

    min_dist = [float('inf')]

    def backtrack(row: int, col: int, dist: int, visited: set) -> None:
        # Reached last column
        if col == cols - 1:
            min_dist[0] = min(min_dist[0], dist)
            return

        # Pruning
        if dist >= min_dist[0]:
            return

        for dr, dc in directions:
            nr, nc = row + dr, col + dc
            if 0 <= nr < rows and 0 <= nc < cols:
                if safe[nr][nc] and (nr, nc) not in visited:
                    visited.add((nr, nc))
                    backtrack(nr, nc, dist + 1, visited)
                    visited.remove((nr, nc))

    # Try all starting rows
    for r in range(rows):
        if safe[r][0]:
            visited = {(r, 0)}
            backtrack(r, 0, 0, visited)

    return min_dist[0] if min_dist[0] != float('inf') else -1


def shortest_safe_route_bfs(field: List[List[int]]) -> int:
    """BFS solution - more efficient for shortest path."""
    if not field:
        return -1

    rows, cols = len(field), len(field[0])
    directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]

    # Mark unsafe cells
    safe = [[field[i][j] for j in range(cols)] for i in range(rows)]
    for i in range(rows):
        for j in range(cols):
            if field[i][j] == 0:
                for di, dj in directions:
                    ni, nj = i + di, j + dj
                    if 0 <= ni < rows and 0 <= nj < cols:
                        safe[ni][nj] = 0

    # BFS from all valid starting positions
    queue = deque()
    visited = [[False] * cols for _ in range(rows)]

    for r in range(rows):
        if safe[r][0]:
            queue.append((r, 0, 0))
            visited[r][0] = True

    while queue:
        row, col, dist = queue.popleft()

        if col == cols - 1:
            return dist

        for dr, dc in directions:
            nr, nc = row + dr, col + dc
            if 0 <= nr < rows and 0 <= nc < cols:
                if safe[nr][nc] and not visited[nr][nc]:
                    visited[nr][nc] = True
                    queue.append((nr, nc, dist + 1))

    return -1


# ============================================================================
# TEST CASES
# ============================================================================

if __name__ == "__main__":
    print("SHORTEST SAFE ROUTE")
    print("=" * 40)

    field = [
        [1, 1, 1, 1, 1, 1, 1, 1, 1],
        [1, 0, 1, 1, 1, 1, 1, 1, 1],
        [1, 1, 1, 0, 1, 1, 1, 1, 1],
        [1, 1, 1, 1, 0, 1, 1, 1, 1]
    ]

    print("Field (0 = landmine):")
    for row in field:
        print(row)

    print(f"\nBacktracking: {shortest_safe_route_backtrack(field)}")
    print(f"BFS: {shortest_safe_route_bfs(field)}")
