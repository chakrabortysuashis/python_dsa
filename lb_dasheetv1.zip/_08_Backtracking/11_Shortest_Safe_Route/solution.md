# Find Shortest Safe Route in a Path with Landmines

## Problem Statement

Given an MxN matrix representing a field with landmines, find the shortest safe path from the first column to the last column. You cannot step on landmines or cells adjacent to landmines (4-directional).

### Example
```
Input:
1 1 1 1 1 1 1 1 1
1 0 1 1 1 1 1 1 1   (0 = landmine)
1 1 1 0 1 1 1 1 1
1 1 1 1 0 1 1 1 1

Output: Shortest path length = 12
```

## Why Backtracking Works Here

1. **Multiple Paths**: Many possible routes from start to end
2. **Constraint**: Can't step on unsafe cells
3. **Optimization**: Find minimum length path
4. **BFS Better**: For shortest path, but backtracking finds all paths

## Recursion Tree

```
                    (any row, col=0)
                   /     |     \
               right   down    up
                 |
            (r, col+1)
           /    |    \
        right  down  up
           |
         ...
           |
        col == last_col -> FOUND!
```

## Code Template

```python
def shortest_safe_route(field):
    rows, cols = len(field), len(field[0])
    
    # Mark unsafe cells (adjacent to landmines)
    safe = [[field[i][j] for j in range(cols)] for i in range(rows)]
    directions = [(0,1), (0,-1), (1,0), (-1,0)]
    
    for i in range(rows):
        for j in range(cols):
            if field[i][j] == 0:  # Landmine
                safe[i][j] = 0
                for di, dj in directions:
                    ni, nj = i + di, j + dj
                    if 0 <= ni < rows and 0 <= nj < cols:
                        safe[ni][nj] = 0
    
    min_dist = [float('inf')]
    
    def backtrack(row, col, dist, visited):
        if col == cols - 1:
            min_dist[0] = min(min_dist[0], dist)
            return
        
        if dist >= min_dist[0]:  # Pruning
            return
        
        for dr, dc in directions:
            nr, nc = row + dr, col + dc
            if 0 <= nr < rows and 0 <= nc < cols:
                if safe[nr][nc] and (nr, nc) not in visited:
                    visited.add((nr, nc))
                    backtrack(nr, nc, dist + 1, visited)
                    visited.remove((nr, nc))
    
    # Try all starting rows
    for r in range(rows):
        if safe[r][0]:
            visited = {(r, 0)}
            backtrack(r, 0, 0, visited)
    
    return min_dist[0] if min_dist[0] != float('inf') else -1
```

## Time & Space Complexity
- **Time**: O(4^(M*N)) worst case
- **Space**: O(M*N) for visited

## Note
BFS is more efficient for finding shortest path. Use backtracking when you need all paths or constraints are complex.
