# Rat in a Maze Problem

## Problem Statement

A rat starts from the **top-left corner (0, 0)** of an N x N maze and needs to reach the **bottom-right corner (N-1, N-1)**. The rat can move in four directions: **Down (D)**, **Left (L)**, **Right (R)**, and **Up (U)**.

The maze is represented as a binary matrix where:
- **1** = open path (rat can move here)
- **0** = blocked (rat cannot move here)

**Goal**: Find ALL possible paths from source to destination.

### Example

```
Input Maze (4x4):
1 0 0 0
1 1 0 1
1 1 0 0
0 1 1 1

Output: ["DDRDRR", "DRDDRR"]
```

## Why Backtracking Works Here

This is a **classic backtracking problem** because:

1. **Multiple Paths Exist**: We need to find ALL valid paths, not just one
2. **Constraints at Each Step**: Can only move to cells with value 1, can't revisit cells
3. **Dead Ends Require Backtracking**: When stuck, we must undo and try another direction
4. **Systematic Exploration**: Try all 4 directions from each cell

### The Decision at Each Cell

At every cell, the rat has up to 4 choices:
- Move Down (D)
- Move Left (L)
- Move Right (R)
- Move Up (U)

We try each valid direction, and if it leads to a dead end, we **backtrack**.

## Recursion Tree Diagram

```
                              Start (0,0)
                                  |
                    +-------------+-------------+
                    |             |             |
                 Down(1,0)    Right(0,1)    [blocked]
                    |          [blocked]
           +--------+--------+
           |        |        |
        Down(2,0) Right(1,1)  Up
          |         |       [visited]
         ...       ...

Full Tree for the example maze:

                                (0,0) path=""
                                   |
                            D: (1,0) path="D"
                                   |
                    +--------------+--------------+
                    |                             |
              D: (2,0) "DD"                 R: (1,1) "DR"
                    |                             |
              R: (2,1) "DDR"               +------+------+
                    |                      |             |
              +-----+-----+          D: (2,1) "DRD"  R: blocked
              |           |                |
        D: blocked   R: (2,2)        R: (2,2) "DRDR"
                    blocked                |
                                     R: (2,3) blocked
                                     D: (3,1) "DRDRD"
                                           |
                                     R: (3,2) "DRDRR"
                                           |
                                     R: (3,3) "DRDRRR" 
                                       SOLUTION!

Legend:
- D = Down, R = Right, L = Left, U = Up
- "blocked" = cell is 0 or already visited
- SOLUTION = reached destination (N-1, N-1)
```

## Base Case Identification

### When to Stop (Return)?

```python
# BASE CASE 1: Reached destination - SUCCESS!
if row == N-1 and col == N-1:
    save_path(current_path)
    return

# BASE CASE 2: Invalid cell - PRUNE!
if row < 0 or row >= N or col < 0 or col >= N:
    return  # Out of bounds

# BASE CASE 3: Blocked or visited - PRUNE!
if maze[row][col] == 0 or visited[row][col]:
    return  # Cannot proceed
```

## Recursive Case Explanation

```python
# Mark current cell as visited (DO)
visited[row][col] = True
path.append(direction)

# Try all 4 directions (RECURSE)
explore(row + 1, col, path + "D")  # Down
explore(row, col - 1, path + "L")  # Left
explore(row, col + 1, path + "R")  # Right
explore(row - 1, col, path + "U")  # Up

# Unmark current cell (UNDO - Backtrack!)
visited[row][col] = False
path.pop()
```

## The "Leap of Faith" Application

**Trust that `explore(next_cell)` will correctly find all paths from that cell to the destination.**

Don't trace through every recursive call. Instead:
1. If I'm at destination: record the path
2. If current cell is valid: mark it, explore all directions, unmark it
3. Trust recursion to handle the exploration of each direction

```python
def explore(row, col, path):
    # I trust that if I call explore(row+1, col, path+"D"),
    # it will find ALL paths from (row+1, col) to destination
    # and append them to our results.
    
    # My job is just to:
    # 1. Check if I'm at destination (base case)
    # 2. Mark current cell as visited
    # 3. Try all valid directions
    # 4. Unmark current cell (backtrack)
```

## Step-by-Step Dry Run

**Maze:**
```
1 0 0 0
1 1 0 1
1 1 0 0
0 1 1 1
```

### Finding First Path: "DDRDRR"

```
Step 1: Start at (0,0)
        visited[0][0] = True, path = ""
        Try Down -> (1,0) valid

Step 2: At (1,0)
        visited[1][0] = True, path = "D"
        Try Down -> (2,0) valid

Step 3: At (2,0)
        visited[2][0] = True, path = "DD"
        Try Down -> (3,0) = 0, invalid
        Try Right -> (2,1) valid

Step 4: At (2,1)
        visited[2][1] = True, path = "DDR"
        Try Down -> (3,1) valid

Step 5: At (3,1)
        visited[3][1] = True, path = "DDRD"
        Try Right -> (3,2) valid

Step 6: At (3,2)
        visited[3][2] = True, path = "DDRDR"
        Try Right -> (3,3) valid

Step 7: At (3,3) - DESTINATION!
        Record path "DDRDRR"
        Return (backtrack begins)

Backtracking...
Step 8: Back at (3,2), try other directions
        No valid unexplored directions
        visited[3][2] = False, path = "DDRD"
        Return

... continue backtracking and finding "DRDDRR" ...
```

### Visual State at Each Step

```
Step 1:         Step 3:         Step 5:         Step 7:
R . . .         R . . .         R . . .         R . . .
. . . .         R . . .         R R . .         R R . .
. . . .         R . . .         R R . .         R R . .
. . . .         . . . .         . R . .         . R R R(dest)

R = Rat's current/visited path
```

## Time Complexity

**Worst Case: O(4^(N^2))**

- At each cell, we can go in up to 4 directions
- There are N^2 cells in total
- Maximum recursion depth = N^2 (visiting all cells)

**Practical complexity** is much better due to:
- Walls blocking paths
- Visited cells preventing revisits
- Dead ends causing early backtracking

## Space Complexity

**O(N^2)**

- `visited` array: O(N^2)
- Recursion stack depth: O(N^2) in worst case
- Path string: O(N^2) maximum length

## Key Insights

1. **Alphabetical Order**: Trying directions in D, L, R, U order ensures lexicographically sorted paths

2. **Visited Array is Crucial**: Without it, we'd have infinite loops

3. **Starting Point Must Be Valid**: If maze[0][0] = 0, no paths exist

4. **Path Recording**: We record the path as a string of moves, not coordinates

## Common Mistakes

1. **Forgetting to unmark visited cells** - Leads to missing paths
2. **Not checking bounds before accessing maze** - Index out of bounds
3. **Modifying path directly** - Use path + "D" or backtrack properly
4. **Not handling the case when source is blocked** - Check maze[0][0] first

## Related Problems

- Knight's Tour
- Word Search in Grid
- Shortest Path in Maze (BFS is better)
- Unique Paths with Obstacles
