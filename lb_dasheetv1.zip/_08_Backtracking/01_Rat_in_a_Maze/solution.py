"""
Rat in a Maze Problem - Backtracking Solution
==============================================

Problem: Find all paths from top-left (0,0) to bottom-right (N-1, N-1)
         in a maze where 1 = open path and 0 = blocked.

Approach: Backtracking with 4 directions (D, L, R, U)

Time Complexity: O(4^(N^2)) worst case
Space Complexity: O(N^2) for visited array and recursion stack
"""

from typing import List


def find_all_paths(maze: List[List[int]]) -> List[str]:
    """
    Find all paths from (0,0) to (N-1, N-1) in the maze.

    Backtracking Approach:
    1. Start at (0, 0)
    2. At each cell, try all 4 directions: Down, Left, Right, Up
    3. If we reach destination, record the path
    4. If stuck (blocked or visited), backtrack

    Args:
        maze: NxN binary matrix (1 = open, 0 = blocked)

    Returns:
        List of all valid paths as direction strings (e.g., "DDRDRR")

    Recursion Tree (for a simple case):

                        (0,0) ""
                           |
                    D: (1,0) "D"
                           |
              +------------+------------+
              |                         |
         D: (2,0) "DD"            R: (1,1) "DR"
              |                         |
         R: (2,1) "DDR"           D: (2,1) "DRD"
              |                         |
            ...                       ...
    """
    if not maze or not maze[0]:
        return []

    n = len(maze)
    result = []

    # Check if start or end is blocked
    if maze[0][0] == 0 or maze[n-1][n-1] == 0:
        return []

    # Visited array to avoid revisiting cells
    visited = [[False] * n for _ in range(n)]

    # Directions in alphabetical order: Down, Left, Right, Up
    # This ensures lexicographically sorted output
    directions = [
        (1, 0, 'D'),   # Down
        (0, -1, 'L'),  # Left
        (0, 1, 'R'),   # Right
        (-1, 0, 'U')   # Up
    ]

    def is_valid(row: int, col: int) -> bool:
        """Check if cell is valid to visit."""
        return (0 <= row < n and
                0 <= col < n and
                maze[row][col] == 1 and
                not visited[row][col])

    def backtrack(row: int, col: int, path: str) -> None:
        """
        Explore all paths from current cell using backtracking.

        BASE CASE:
        - Reached destination (n-1, n-1) -> record path

        RECURSIVE CASE:
        - Try all 4 directions
        - For each valid direction: DO -> RECURSE -> UNDO

        Args:
            row, col: Current position
            path: Path taken so far (string of directions)
        """
        # BASE CASE: Reached destination
        if row == n - 1 and col == n - 1:
            result.append(path)
            return

        # Mark current cell as visited (DO)
        visited[row][col] = True

        # Try all 4 directions (RECURSE)
        for dr, dc, direction in directions:
            new_row = row + dr
            new_col = col + dc

            if is_valid(new_row, new_col):
                # Recurse with new position and extended path
                backtrack(new_row, new_col, path + direction)

        # Unmark current cell (UNDO - Backtrack!)
        visited[row][col] = False

    # Start backtracking from (0, 0)
    backtrack(0, 0, "")

    return result


def find_all_paths_iterative(maze: List[List[int]]) -> List[str]:
    """
    Iterative version using explicit stack.

    Demonstrates how recursion can be converted to iteration.
    """
    if not maze or not maze[0]:
        return []

    n = len(maze)

    if maze[0][0] == 0 or maze[n-1][n-1] == 0:
        return []

    result = []
    directions = [(1, 0, 'D'), (0, -1, 'L'), (0, 1, 'R'), (-1, 0, 'U')]

    # Stack: (row, col, path, visited_set)
    # We need to copy visited set for each branch
    stack = [(0, 0, "", {(0, 0)})]

    while stack:
        row, col, path, visited = stack.pop()

        # Check if reached destination
        if row == n - 1 and col == n - 1:
            result.append(path)
            continue

        # Try all directions (in reverse for correct order due to stack)
        for dr, dc, direction in reversed(directions):
            new_row = row + dr
            new_col = col + dc

            if (0 <= new_row < n and
                0 <= new_col < n and
                maze[new_row][new_col] == 1 and
                (new_row, new_col) not in visited):

                # Create new visited set with current cell
                new_visited = visited | {(new_row, new_col)}
                stack.append((new_row, new_col, path + direction, new_visited))

    return sorted(result)


def print_maze_with_path(maze: List[List[int]], path: str) -> None:
    """
    Visualize a path on the maze.

    Args:
        maze: The maze matrix
        path: Direction string (e.g., "DDRDRR")
    """
    n = len(maze)

    # Create display grid
    display = [['#' if maze[i][j] == 0 else '.' for j in range(n)] for i in range(n)]

    # Mark the path
    row, col = 0, 0
    display[row][col] = 'S'  # Start

    for direction in path:
        if direction == 'D':
            row += 1
        elif direction == 'U':
            row -= 1
        elif direction == 'R':
            col += 1
        elif direction == 'L':
            col -= 1

        if row == n - 1 and col == n - 1:
            display[row][col] = 'E'  # End
        else:
            display[row][col] = '*'  # Path

    print(f"\nPath: {path}")
    print("-" * (2 * n + 1))
    for row in display:
        print('|' + ' '.join(row) + '|')
    print("-" * (2 * n + 1))


def solve_with_trace(maze: List[List[int]]) -> List[str]:
    """
    Solve with detailed trace output for learning.
    """
    if not maze or not maze[0]:
        return []

    n = len(maze)
    result = []
    visited = [[False] * n for _ in range(n)]
    directions = [(1, 0, 'D'), (0, -1, 'L'), (0, 1, 'R'), (-1, 0, 'U')]

    def backtrack(row: int, col: int, path: str, depth: int) -> None:
        indent = "  " * depth
        print(f"{indent}Exploring ({row}, {col}), path=\"{path}\"")

        if row == n - 1 and col == n - 1:
            result.append(path)
            print(f"{indent}>>> SOLUTION FOUND: \"{path}\"")
            return

        visited[row][col] = True

        for dr, dc, direction in directions:
            new_row = row + dr
            new_col = col + dc

            if 0 <= new_row < n and 0 <= new_col < n:
                if maze[new_row][new_col] == 0:
                    print(f"{indent}  {direction} -> ({new_row}, {new_col}) BLOCKED")
                elif visited[new_row][new_col]:
                    print(f"{indent}  {direction} -> ({new_row}, {new_col}) VISITED")
                else:
                    print(f"{indent}  {direction} -> ({new_row}, {new_col}) valid, exploring...")
                    backtrack(new_row, new_col, path + direction, depth + 1)

        visited[row][col] = False
        print(f"{indent}Backtracking from ({row}, {col})")

    if maze[0][0] == 1:
        backtrack(0, 0, "", 0)

    return result


# ============================================================================
# TEST CASES
# ============================================================================

def run_tests():
    print("=" * 60)
    print("RAT IN A MAZE - BACKTRACKING SOLUTION")
    print("=" * 60)

    # Test Case 1: Standard 4x4 maze
    print("\n" + "-" * 40)
    print("Test 1: Standard 4x4 Maze")
    print("-" * 40)

    maze1 = [
        [1, 0, 0, 0],
        [1, 1, 0, 1],
        [1, 1, 0, 0],
        [0, 1, 1, 1]
    ]

    print("Maze:")
    for row in maze1:
        print(row)

    paths = find_all_paths(maze1)
    print(f"\nFound {len(paths)} path(s): {paths}")

    for path in paths:
        print_maze_with_path(maze1, path)

    # Test Case 2: No solution
    print("\n" + "-" * 40)
    print("Test 2: No Solution Possible")
    print("-" * 40)

    maze2 = [
        [1, 1, 1],
        [0, 0, 1],
        [1, 1, 1]
    ]

    print("Maze:")
    for row in maze2:
        print(row)

    paths = find_all_paths(maze2)
    print(f"\nFound {len(paths)} path(s): {paths}")

    if paths:
        for path in paths:
            print_maze_with_path(maze2, path)

    # Test Case 3: Multiple paths
    print("\n" + "-" * 40)
    print("Test 3: Multiple Paths")
    print("-" * 40)

    maze3 = [
        [1, 1, 1],
        [1, 1, 1],
        [1, 1, 1]
    ]

    print("Maze (all open):")
    for row in maze3:
        print(row)

    paths = find_all_paths(maze3)
    print(f"\nFound {len(paths)} path(s):")
    for path in paths:
        print(f"  {path}")

    # Test Case 4: Trace through small maze
    print("\n" + "-" * 40)
    print("Test 4: Trace Through 3x3 Maze")
    print("-" * 40)

    maze4 = [
        [1, 0, 0],
        [1, 1, 0],
        [0, 1, 1]
    ]

    print("Maze:")
    for row in maze4:
        print(row)

    print("\nTrace:")
    paths = solve_with_trace(maze4)
    print(f"\nAll paths: {paths}")

    # Test Case 5: Start blocked
    print("\n" + "-" * 40)
    print("Test 5: Start Blocked")
    print("-" * 40)

    maze5 = [
        [0, 1, 1],
        [1, 1, 1],
        [1, 1, 1]
    ]

    paths = find_all_paths(maze5)
    print(f"Paths when start is blocked: {paths}")

    print("\n" + "=" * 60)
    print("ALL TESTS COMPLETED!")
    print("=" * 60)


if __name__ == "__main__":
    run_tests()
