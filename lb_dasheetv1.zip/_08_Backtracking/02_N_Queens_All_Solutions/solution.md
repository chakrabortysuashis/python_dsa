# Printing All Solutions in N-Queen Problem

## Problem Statement

Place **N queens** on an **N x N chessboard** such that no two queens attack each other. A queen can attack any piece in the same **row**, **column**, or **diagonal**.

**Goal**: Find ALL possible valid configurations.

### Example (N=4)

```
Solution 1:         Solution 2:
. Q . .             . . Q .
. . . Q             Q . . .
Q . . .             . . . Q
. . Q .             . Q . .
```

For N=4, there are exactly **2 solutions**.

## Why Backtracking Works Here

This is a **constraint satisfaction problem** perfect for backtracking:

1. **One Queen Per Row**: We place queens row by row
2. **Column Constraint**: Only one queen per column
3. **Diagonal Constraint**: Only one queen per diagonal
4. **Systematic Exploration**: Try each column, backtrack if invalid

### Key Insight

Since we place ONE queen per row (moving row by row), we automatically satisfy the "no two queens in same row" constraint. We only need to check:
- Column conflicts
- Diagonal conflicts

## Recursion Tree Diagram

```
                              Row 0
                    /    |    |    \
               Col0   Col1  Col2   Col3
                 Q      Q     Q      Q
                 |      |     |      |
              Row 1:  Row 1: Row 1: Row 1:
              try    try   try    try
              cols   cols  cols   cols

Detailed for N=4, showing valid branches:

                           Row 0
            /        |          |         \
         Q...      .Q..       ..Q.       ...Q
        (0,0)     (0,1)      (0,2)      (0,3)
          |         |          |          |
       Row 1:    Row 1:     Row 1:     Row 1:
       X X . .   X X X .    X . X X    . X X X
         |         |          |          |
      (1,2)    (1,3)       (1,0)      (1,0)
      FAIL!    valid!       X          valid!
                 |          |            |
              Row 2:      Row 2:       Row 2:
              . X . X    X X X X      X X . X
                |         FAIL!         |
             (2,0)                   (2,2)
              valid!                  valid!
                |                       |
             Row 3:                  Row 3:
             . X X X                 X X X X
                |                     FAIL!
             (3,2)
              valid!
                |
            SOLUTION 1:
            . Q . .
            . . . Q
            Q . . .
            . . Q .

Legend:
- Q = Queen placed
- X = Under attack (invalid)
- . = Safe square
```

## Base Case Identification

```python
# BASE CASE: All N queens placed successfully
if row == N:
    save_solution(board)
    return  # Found one solution, continue to find more

# PRUNING: Column is under attack
if col in cols_used:
    continue  # Skip this column

# PRUNING: Diagonal is under attack
if (row - col) in diag1 or (row + col) in diag2:
    continue  # Skip this position
```

## Recursive Case Explanation

```python
def solve(row):
    # Try placing queen in each column of current row
    for col in range(N):
        if is_safe(row, col):
            # DO: Place queen
            place_queen(row, col)
            
            # RECURSE: Move to next row
            solve(row + 1)
            
            # UNDO: Remove queen (backtrack)
            remove_queen(row, col)
```

## The "Leap of Faith" Application

**Trust that `solve(row + 1)` will correctly find all valid configurations for rows `row+1` to `N-1`.**

Your job at row `row`:
1. Try each column
2. If placing queen is safe, place it and let recursion handle the rest
3. When recursion returns, backtrack to try other columns

```python
# I don't trace through all recursive calls.
# I trust that solve(row + 1) will:
#   - Find all valid placements for remaining rows
#   - Add complete solutions to result
#   - Return so I can try other columns

place_queen(row, col)
solve(row + 1)  # <-- LEAP OF FAITH: This handles everything below
remove_queen(row, col)
```

## Step-by-Step Dry Run

For N = 4:

```
Step 1: Row 0, try Col 0
        Place Q at (0,0)
        Board: Q . . .
               . . . .
               . . . .
               . . . .
        Mark: cols={0}, diag1={0}, diag2={0}

Step 2: Row 1, try columns
        Col 0: SKIP (column 0 used)
        Col 1: SKIP (diag1: 1-1=0 conflict)
        Col 2: Safe! Place Q at (1,2)
        Board: Q . . .
               . . Q .
               . . . .
               . . . .
        Mark: cols={0,2}, diag1={0,-1}, diag2={0,3}

Step 3: Row 2, try columns
        Col 0: SKIP (column 0 used)
        Col 1: SKIP (diag2: 2+1=3 conflict)
        Col 2: SKIP (column 2 used)
        Col 3: SKIP (diag1: 2-3=-1 conflict)
        ALL BLOCKED! Backtrack!

Step 4: Backtrack to Row 1
        Remove Q from (1,2)
        Try Col 3: Safe! Place Q at (1,3)
        Board: Q . . .
               . . . Q
               . . . .
               . . . .

Step 5: Row 2, try columns
        Col 1: Safe! Place Q at (2,1)
        Board: Q . . .
               . . . Q
               . Q . .
               . . . .

Step 6: Row 3, try columns
        Col 2: SKIP (diag2: 3+2=5 conflict with (2,1)?)
        Actually Col 2: Check diag1: 3-2=1, diag2: 3+2=5
        (2,1) has diag1: 2-1=1 CONFLICT!
        
        All columns fail. Backtrack to Row 2.

... Continue until finding both solutions ...
```

### Final Solutions for N=4:

```
Solution 1:           Solution 2:
. Q . .               . . Q .
. . . Q               Q . . .
Q . . .               . . . Q
. . Q .               . Q . .
```

## Time Complexity

**O(N!)** in the worst case

- First row: N choices
- Second row: at most N-1 choices (one column blocked)
- Third row: at most N-2 choices
- ...and so on

Total branches explored: N * (N-1) * (N-2) * ... * 1 = N!

In practice, diagonal constraints prune many more branches, making it much faster.

## Space Complexity

**O(N)**

- Recursion depth: O(N) - one call per row
- Column tracking set: O(N)
- Diagonal tracking sets: O(N) each
- Board representation: O(N^2) if storing full board, O(N) if storing column positions

## Tracking Attacks Efficiently

### Method 1: Check Every Queen (O(N) per check)
```python
def is_safe(row, col, queens):
    for qr, qc in queens:
        if qc == col:  # Same column
            return False
        if abs(qr - row) == abs(qc - col):  # Same diagonal
            return False
    return True
```

### Method 2: Use Sets (O(1) per check) - BETTER!
```python
cols = set()     # Columns with queens
diag1 = set()    # "\" diagonals: row - col
diag2 = set()    # "/" diagonals: row + col

def is_safe(row, col):
    return (col not in cols and
            (row - col) not in diag1 and
            (row + col) not in diag2)
```

**Why row - col and row + col?**

```
Diagonal "\" (row - col constant):
(0,0) -> 0    (0,2) -> -2
(1,1) -> 0    (1,3) -> -2
(2,2) -> 0    (2,4) -> -2
Same "\" diagonal = same (row - col) value

Diagonal "/" (row + col constant):
(0,2) -> 2    (0,0) -> 0
(1,1) -> 2    (1,1) -> 2
(2,0) -> 2    (2,2) -> 4
Same "/" diagonal = same (row + col) value
```

## Number of Solutions

| N | Solutions |
|---|-----------|
| 1 | 1 |
| 2 | 0 |
| 3 | 0 |
| 4 | 2 |
| 5 | 10 |
| 6 | 4 |
| 7 | 40 |
| 8 | 92 |
| 9 | 352 |
| 10 | 724 |

## Common Mistakes

1. **Only finding one solution**: Don't return after first solution; continue exploring
2. **Forgetting diagonal checks**: Both diagonals must be checked
3. **Not backtracking properly**: Must remove queen and update tracking sets
4. **Checking row conflicts**: Unnecessary since we place one queen per row

## Related Problems

- N-Queens (find any one solution)
- N-Queens II (count solutions only)
- Sudoku Solver
- Graph Coloring
