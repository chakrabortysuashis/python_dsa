"""
N-Queens Problem - Find All Solutions
======================================

Problem: Place N queens on an NxN chessboard such that no two queens
         attack each other. Find ALL valid configurations.

Approach: Backtracking with row-by-row placement

Time Complexity: O(N!)
Space Complexity: O(N)
"""

from typing import List, Set


def solve_n_queens(n: int) -> List[List[str]]:
    """
    Find all solutions to the N-Queens problem.

    Backtracking Approach:
    - Place one queen per row (automatically avoids row conflicts)
    - Track columns and diagonals to avoid conflicts
    - Use sets for O(1) conflict checking

    Recursion Tree for N=4:

                          Row 0
                /    |    |    \
             Col0  Col1  Col2  Col3
               |     |     |     |
             Row1  Row1  Row1  Row1
            (try  (try  (try  (try
            cols) cols) cols) cols)
               |
             ...
               |
            SOLUTION or BACKTRACK

    Args:
        n: Size of board and number of queens

    Returns:
        List of valid board configurations
    """
    result = []

    # Track occupied columns and diagonals for O(1) lookup
    cols: Set[int] = set()      # Columns with queens
    diag1: Set[int] = set()     # "\" diagonals: characterized by (row - col)
    diag2: Set[int] = set()     # "/" diagonals: characterized by (row + col)

    # Current board state
    board = [['.' for _ in range(n)] for _ in range(n)]

    def is_safe(row: int, col: int) -> bool:
        """
        Check if placing a queen at (row, col) is safe.

        O(1) check using sets instead of O(N) by checking all queens.
        """
        return (col not in cols and
                (row - col) not in diag1 and
                (row + col) not in diag2)

    def backtrack(row: int) -> None:
        """
        Place queens row by row using backtracking.

        BASE CASE:
        - row == n: All queens placed, record solution

        RECURSIVE CASE:
        - Try each column in current row
        - If safe: place queen, recurse, remove queen

        Args:
            row: Current row to place queen
        """
        # BASE CASE: All N queens placed successfully
        if row == n:
            # Create a copy of the current board
            solution = [''.join(r) for r in board]
            result.append(solution)
            return

        # Try each column in this row
        for col in range(n):
            if is_safe(row, col):
                # DO: Place queen
                board[row][col] = 'Q'
                cols.add(col)
                diag1.add(row - col)
                diag2.add(row + col)

                # RECURSE: Move to next row
                backtrack(row + 1)

                # UNDO: Remove queen (backtrack)
                board[row][col] = '.'
                cols.remove(col)
                diag1.remove(row - col)
                diag2.remove(row + col)

    backtrack(0)
    return result


def solve_n_queens_positions(n: int) -> List[List[int]]:
    """
    Return solutions as column positions for each row.

    More space-efficient: [1, 3, 0, 2] means queens at
    (0,1), (1,3), (2,0), (3,2)

    Args:
        n: Size of board

    Returns:
        List of solutions, each as list of column positions
    """
    result = []
    cols: Set[int] = set()
    diag1: Set[int] = set()
    diag2: Set[int] = set()
    positions = []

    def backtrack(row: int) -> None:
        if row == n:
            result.append(positions[:])
            return

        for col in range(n):
            if col not in cols and (row - col) not in diag1 and (row + col) not in diag2:
                positions.append(col)
                cols.add(col)
                diag1.add(row - col)
                diag2.add(row + col)

                backtrack(row + 1)

                positions.pop()
                cols.remove(col)
                diag1.remove(row - col)
                diag2.remove(row + col)

    backtrack(0)
    return result


def count_n_queens(n: int) -> int:
    """
    Count the number of solutions (more efficient, no board storage).

    Args:
        n: Size of board

    Returns:
        Number of valid configurations
    """
    count = [0]  # Use list to allow modification in nested function
    cols: Set[int] = set()
    diag1: Set[int] = set()
    diag2: Set[int] = set()

    def backtrack(row: int) -> None:
        if row == n:
            count[0] += 1
            return

        for col in range(n):
            if col not in cols and (row - col) not in diag1 and (row + col) not in diag2:
                cols.add(col)
                diag1.add(row - col)
                diag2.add(row + col)

                backtrack(row + 1)

                cols.remove(col)
                diag1.remove(row - col)
                diag2.remove(row + col)

    backtrack(0)
    return count[0]


def solve_with_trace(n: int) -> List[List[str]]:
    """
    Solve with detailed trace for learning.
    """
    result = []
    cols: Set[int] = set()
    diag1: Set[int] = set()
    diag2: Set[int] = set()
    board = [['.' for _ in range(n)] for _ in range(n)]

    def backtrack(row: int, depth: int) -> None:
        indent = "  " * depth
        print(f"{indent}Row {row}: cols={cols}, diag1={diag1}, diag2={diag2}")

        if row == n:
            result.append([''.join(r) for r in board])
            print(f"{indent}>>> SOLUTION #{len(result)} FOUND!")
            return

        for col in range(n):
            if col in cols:
                print(f"{indent}  Col {col}: SKIP (column conflict)")
                continue
            if (row - col) in diag1:
                print(f"{indent}  Col {col}: SKIP (diagonal \\ conflict)")
                continue
            if (row + col) in diag2:
                print(f"{indent}  Col {col}: SKIP (diagonal / conflict)")
                continue

            print(f"{indent}  Col {col}: SAFE - placing queen")

            board[row][col] = 'Q'
            cols.add(col)
            diag1.add(row - col)
            diag2.add(row + col)

            backtrack(row + 1, depth + 1)

            print(f"{indent}  Backtracking: removing queen from ({row}, {col})")
            board[row][col] = '.'
            cols.remove(col)
            diag1.remove(row - col)
            diag2.remove(row + col)

    backtrack(0, 0)
    return result


def print_board(board: List[str]) -> None:
    """Print a board configuration nicely."""
    n = len(board)
    print("+" + "-" * (2 * n - 1) + "+")
    for row in board:
        print("|" + " ".join(row) + "|")
    print("+" + "-" * (2 * n - 1) + "+")


def visualize_attacks(n: int, queens: List[int]) -> None:
    """
    Visualize which squares are under attack.

    Args:
        n: Board size
        queens: Column position for each row (partial solution)
    """
    # Create attack map
    attacked = [[False] * n for _ in range(n)]

    for row, col in enumerate(queens):
        # Mark entire row, column
        for i in range(n):
            attacked[row][i] = True
            attacked[i][col] = True

        # Mark diagonals
        for d in range(-n, n):
            if 0 <= row + d < n and 0 <= col + d < n:
                attacked[row + d][col + d] = True
            if 0 <= row + d < n and 0 <= col - d < n:
                attacked[row + d][col - d] = True

    # Print board
    print(f"\nQueens at columns: {queens}")
    for i in range(n):
        row_str = ""
        for j in range(n):
            if i < len(queens) and queens[i] == j:
                row_str += "Q "
            elif attacked[i][j]:
                row_str += "x "
            else:
                row_str += ". "
        print(row_str)


# ============================================================================
# TEST CASES
# ============================================================================

def run_tests():
    print("=" * 60)
    print("N-QUEENS - ALL SOLUTIONS")
    print("=" * 60)

    # Test 1: N=4
    print("\n" + "-" * 40)
    print("Test 1: N = 4")
    print("-" * 40)

    solutions = solve_n_queens(4)
    print(f"Found {len(solutions)} solutions:\n")

    for i, sol in enumerate(solutions):
        print(f"Solution {i + 1}:")
        print_board(sol)
        print()

    # Test 2: Count solutions for various N
    print("\n" + "-" * 40)
    print("Test 2: Solution Counts")
    print("-" * 40)

    for n in range(1, 11):
        count = count_n_queens(n)
        print(f"N = {n:2d}: {count:5d} solutions")

    # Test 3: Position representation
    print("\n" + "-" * 40)
    print("Test 3: Position Representation (N=5)")
    print("-" * 40)

    positions = solve_n_queens_positions(5)
    print(f"Found {len(positions)} solutions:")
    for i, pos in enumerate(positions[:5]):  # Show first 5
        print(f"  Solution {i + 1}: columns = {pos}")
    if len(positions) > 5:
        print(f"  ... and {len(positions) - 5} more")

    # Test 4: Trace small example
    print("\n" + "-" * 40)
    print("Test 4: Trace Through N=4")
    print("-" * 40)

    solve_with_trace(4)

    # Test 5: Visualize attacks
    print("\n" + "-" * 40)
    print("Test 5: Attack Visualization")
    print("-" * 40)

    print("After placing queens at columns [1, 3] (rows 0, 1):")
    visualize_attacks(4, [1, 3])

    print("\n" + "=" * 60)
    print("ALL TESTS COMPLETED!")
    print("=" * 60)


if __name__ == "__main__":
    run_tests()
