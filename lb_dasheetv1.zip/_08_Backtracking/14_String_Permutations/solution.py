"""
String Permutations - Backtracking
===================================

Time: O(n! * n), Space: O(n)
"""

from typing import List


def permutations(s: str) -> List[str]:
    """
    Generate all permutations of string.

    Recursion Tree for "AB":
            ""
          /    \
        "A"    "B"
         |      |
        "AB"  "BA"
    """
    result = []

    def backtrack(current: str, remaining: str) -> None:
        if not remaining:
            result.append(current)
            return

        seen = set()
        for i, char in enumerate(remaining):
            if char in seen:
                continue
            seen.add(char)
            backtrack(current + char, remaining[:i] + remaining[i+1:])

    backtrack("", s)
    return result


def permutations_swap(s: str) -> List[str]:
    """Swap-based approach - modifies array in place."""
    result = []
    arr = list(s)

    def backtrack(start: int) -> None:
        if start == len(arr):
            result.append(''.join(arr))
            return

        seen = set()
        for i in range(start, len(arr)):
            if arr[i] in seen:
                continue
            seen.add(arr[i])

            arr[start], arr[i] = arr[i], arr[start]
            backtrack(start + 1)
            arr[start], arr[i] = arr[i], arr[start]

    backtrack(0)
    return result


def permutations_with_trace(s: str) -> List[str]:
    """Version with trace output."""
    result = []

    def backtrack(current, remaining, depth):
        indent = "  " * depth
        print(f"{indent}current=\"{current}\", remaining=\"{remaining}\"")

        if not remaining:
            print(f"{indent}>>> PERMUTATION: \"{current}\"")
            result.append(current)
            return

        seen = set()
        for i, char in enumerate(remaining):
            if char in seen:
                print(f"{indent}Skip duplicate '{char}'")
                continue
            seen.add(char)
            print(f"{indent}Choose '{char}'")
            backtrack(current + char, remaining[:i] + remaining[i+1:], depth + 1)

    backtrack("", s, 0)
    return result


# ============================================================================
# TEST CASES
# ============================================================================

if __name__ == "__main__":
    print("STRING PERMUTATIONS")
    print("=" * 40)

    s1 = "ABC"
    print(f"\nInput: \"{s1}\"")
    result = permutations(s1)
    print(f"Permutations ({len(result)}): {result}")

    s2 = "AAB"
    print(f"\nInput: \"{s2}\" (with duplicates)")
    result = permutations(s2)
    print(f"Permutations ({len(result)}): {result}")

    print("\n" + "-" * 40)
    print("Trace for \"AB\":")
    permutations_with_trace("AB")
