# Print All Permutations of a String

## Problem Statement

Given a string, print all permutations of it. Handle duplicates if present.

### Example
```
Input: "ABC"
Output: ["ABC", "ACB", "BAC", "BCA", "CAB", "CBA"]

Input: "AAB"
Output: ["AAB", "ABA", "BAA"]
```

## Why Backtracking Works Here

1. **Choose from Remaining**: At each position, pick any unused character
2. **N! Permutations**: Each position reduces choices by 1
3. **Deduplication**: Skip repeated characters to avoid duplicates

## Recursion Tree Diagram

```
For "ABC":
                      ""
              /       |       \
            A         B         C
          / \       / \       / \
        AB  AC    BA  BC    CA  CB
        |    |    |    |    |    |
       ABC  ACB  BAC  BCA  CAB  CBA

Each leaf is a complete permutation.
```

## Code Template

```python
def permutations(s):
    result = []
    
    def backtrack(current, remaining):
        # BASE CASE
        if not remaining:
            result.append(current)
            return
        
        seen = set()  # For deduplication
        for i, char in enumerate(remaining):
            if char in seen:
                continue
            seen.add(char)
            
            # DO: Add char
            # RECURSE: With remaining chars
            # (remaining[:i] + remaining[i+1:] removes char at i)
            backtrack(current + char, remaining[:i] + remaining[i+1:])
            # Implicit UNDO (string immutability)
    
    backtrack("", s)
    return result
```

## Time & Space Complexity
- **Time**: O(n! * n) - n! permutations, O(n) to build each
- **Space**: O(n) - recursion depth

## Alternative: Swap-based Approach

```python
def permutations_swap(s):
    result = []
    arr = list(s)
    
    def backtrack(start):
        if start == len(arr):
            result.append(''.join(arr))
            return
        
        seen = set()
        for i in range(start, len(arr)):
            if arr[i] in seen:
                continue
            seen.add(arr[i])
            
            arr[start], arr[i] = arr[i], arr[start]  # DO
            backtrack(start + 1)  # RECURSE
            arr[start], arr[i] = arr[i], arr[start]  # UNDO
    
    backtrack(0)
    return result
```
