# M Coloring Problem

## Problem Statement

Given an undirected graph and a number `M`, determine if the graph can be colored with at most M colors such that no two adjacent vertices have the same color.

### Example

```
Graph:       M = 3
  0---1
  |\ /|
  | X |
  |/ \|
  2---3

Output: Yes, possible with 3 colors
Assignment: {0: Red, 1: Green, 2: Green, 3: Red}
```

## Why Backtracking Works Here

1. **Constraint Satisfaction**: Adjacent vertices must have different colors
2. **Multiple Valid Assignments**: Many possible colorings may exist
3. **Pruning**: Skip colors that conflict with neighbors
4. **Systematic Search**: Try colors vertex by vertex

## Recursion Tree Diagram

```
                        solve(vertex=0)
                       /      |      \
                   Color 1  Color 2  Color 3
                      |
              solve(vertex=1)
             /      |      \
         C1(X)    C2      C3     (C1 conflicts with vertex 0)
                   |
           solve(vertex=2)
          /      |      \
         C1     C2(X)   C3      (C2 conflicts with vertex 1)
          |
    solve(vertex=3)
   /      |      \
  C1(X)  C2      C3            (C1 conflicts with vertex 0)
          |
   All vertices colored!
   SOLUTION FOUND!

Legend: X = color conflicts with neighbor, skip
```

## Base Case and Recursive Case

```python
def solve(vertex):
    # BASE CASE: All vertices colored
    if vertex == num_vertices:
        return True
    
    # RECURSIVE CASE: Try each color
    for color in range(1, M + 1):
        if is_safe(vertex, color):
            # DO: Assign color
            colors[vertex] = color
            
            # RECURSE: Color next vertex
            if solve(vertex + 1):
                return True
            
            # UNDO: Backtrack
            colors[vertex] = 0
    
    return False

def is_safe(vertex, color):
    # Check if any adjacent vertex has same color
    for neighbor in graph[vertex]:
        if colors[neighbor] == color:
            return False
    return True
```

## Time & Space Complexity

- **Time**: O(M^V) where V = vertices, M = colors
- **Space**: O(V) for colors array and recursion stack

## Applications

- Map coloring
- Scheduling (exam, meetings)
- Register allocation in compilers
- Frequency assignment in wireless networks
