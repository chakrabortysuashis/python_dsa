"""
M Coloring Problem - Backtracking Solution
===========================================

Problem: Color a graph with M colors such that no adjacent vertices share a color.

Time Complexity: O(M^V)
Space Complexity: O(V)
"""

from typing import List, Dict, Set


def graph_coloring(graph: List[List[int]], m: int) -> List[int]:
    """
    Color graph vertices with at most m colors.

    Recursion Tree:
                solve(0)
               /   |   \
              C1  C2  C3
               |
          solve(1)
         /   |   \
       C1X  C2  C3
             |
        solve(2)
        ...

    Args:
        graph: Adjacency list representation
        m: Number of colors available

    Returns:
        List of color assignments (0 if impossible)
    """
    n = len(graph)
    colors = [0] * n

    def is_safe(vertex: int, color: int) -> bool:
        """Check if color assignment is valid."""
        for neighbor in graph[vertex]:
            if colors[neighbor] == color:
                return False
        return True

    def solve(vertex: int) -> bool:
        # BASE CASE: All vertices colored
        if vertex == n:
            return True

        # Try each color
        for color in range(1, m + 1):
            if is_safe(vertex, color):
                # DO: Assign color
                colors[vertex] = color

                # RECURSE
                if solve(vertex + 1):
                    return True

                # UNDO: Backtrack
                colors[vertex] = 0

        return False

    if solve(0):
        return colors
    return []


def find_all_colorings(graph: List[List[int]], m: int) -> List[List[int]]:
    """Find all valid m-colorings."""
    n = len(graph)
    colors = [0] * n
    result = []

    def is_safe(v, c):
        return all(colors[nb] != c for nb in graph[v])

    def solve(vertex):
        if vertex == n:
            result.append(colors[:])
            return

        for color in range(1, m + 1):
            if is_safe(vertex, color):
                colors[vertex] = color
                solve(vertex + 1)
                colors[vertex] = 0

    solve(0)
    return result


def chromatic_number(graph: List[List[int]]) -> int:
    """Find minimum colors needed (chromatic number)."""
    n = len(graph)
    for m in range(1, n + 1):
        if graph_coloring(graph, m):
            return m
    return n


# ============================================================================
# TEST CASES
# ============================================================================

def run_tests():
    print("=" * 50)
    print("M COLORING PROBLEM")
    print("=" * 50)

    # Test 1: Simple graph (square with diagonals)
    # 0 -- 1
    # |\ /|
    # | X |
    # |/ \|
    # 2 -- 3
    graph1 = [
        [1, 2, 3],  # 0 connects to 1, 2, 3
        [0, 2, 3],  # 1 connects to 0, 2, 3
        [0, 1, 3],  # 2 connects to 0, 1, 3
        [0, 1, 2]   # 3 connects to 0, 1, 2
    ]

    print("\nTest 1: Complete graph K4")
    print("Graph: Each vertex connected to all others")
    colors = graph_coloring(graph1, 4)
    print(f"Colors needed: 4")
    print(f"Coloring: {colors}")
    print(f"Chromatic number: {chromatic_number(graph1)}")

    # Test 2: Bipartite graph
    graph2 = [
        [1, 3],     # 0
        [0, 2],     # 1
        [1, 3],     # 2
        [0, 2]      # 3
    ]

    print("\nTest 2: Cycle graph (4 vertices)")
    colors = graph_coloring(graph2, 2)
    print(f"Can color with 2 colors: {bool(colors)}")
    print(f"Coloring: {colors}")

    # Test 3: Triangle
    graph3 = [[1, 2], [0, 2], [0, 1]]
    print("\nTest 3: Triangle")
    print(f"2 colors possible: {bool(graph_coloring(graph3, 2))}")
    print(f"3 colors: {graph_coloring(graph3, 3)}")

    print("\n" + "=" * 50)


if __name__ == "__main__":
    run_tests()
