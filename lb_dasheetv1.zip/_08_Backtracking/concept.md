# Backtracking - Complete Guide

## What is Backtracking?

**Backtracking** is an algorithmic technique for solving problems recursively by trying to build a solution incrementally, one piece at a time. If at any point the current solution cannot possibly lead to a valid complete solution, we **abandon (backtrack)** and try another possibility.

Think of it like exploring a maze:
- You walk down a path
- If you hit a dead end, you go BACK to the last junction
- You try a different path
- Repeat until you find the exit (or explore all paths)

```
                    START
                      |
            +---------+---------+
            |         |         |
          Path A    Path B    Path C
            |         |         |
         Dead End   +---+---+  Dead End
          (BACK!)   |   |   |  (BACK!)
                   B1  B2  B3
                    |   |   |
                   OK  Dead Dead
                       (BACK!) (BACK!)
```

## Core Concept: Explore All Possibilities with Pruning

```
Backtracking = Brute Force + Pruning (Smart Elimination)
```

### Without Pruning (Pure Brute Force):
- Try EVERY possible combination
- Extremely slow: O(n!) or O(2^n)

### With Pruning (Backtracking):
- Skip branches that CANNOT lead to valid solutions
- Much faster in practice (though worst case may be same)

## When to Use Backtracking?

Use backtracking when you see these patterns:

| Pattern | Examples |
|---------|----------|
| **"Find ALL solutions"** | All permutations, all subsets, all paths |
| **"Find ANY valid solution"** | Sudoku, N-Queens, maze solving |
| **"Constraint satisfaction"** | Sudoku, graph coloring, scheduling |
| **"Decision at each step"** | Include/exclude, place/don't place |
| **"Generate combinations"** | Combination sum, partition problems |

### Keywords that hint at backtracking:
- "Generate all..."
- "Find all possible..."
- "Count the number of ways..."
- "Solve this puzzle..."
- "Check if it's possible to..."

## The Universal Backtracking Template

```python
def backtrack(current_state, choices):
    # BASE CASE: When to stop?
    if is_complete(current_state):
        process_solution(current_state)
        return
    
    # RECURSIVE CASE: Try all valid choices
    for choice in get_choices(current_state):
        if is_valid(choice, current_state):
            # 1. MAKE the choice (DO)
            make_choice(choice, current_state)
            
            # 2. EXPLORE further (RECURSE)
            backtrack(new_state, remaining_choices)
            
            # 3. UNDO the choice (UNDO) - THIS IS BACKTRACKING!
            undo_choice(choice, current_state)
```

### The Three Steps (DO - RECURSE - UNDO):

```
┌─────────────────────────────────────────────────────────┐
│  1. DO: Make a choice (modify state)                    │
│     Example: path.append(current_node)                  │
│                                                         │
│  2. RECURSE: Explore with this choice                   │
│     Example: backtrack(next_state)                      │
│                                                         │
│  3. UNDO: Remove the choice (restore state)             │
│     Example: path.pop()                                 │
│                                                         │
│  This "undo" step is BACKTRACKING!                      │
└─────────────────────────────────────────────────────────┘
```

## Understanding Base Cases

The **base case** is crucial - it tells us when to STOP recursing.

### Common Base Case Patterns:

```python
# Pattern 1: Position reached the end
if index == len(array):
    # Process complete solution
    return

# Pattern 2: Solution is complete
if len(current_subset) == k:
    # We have k elements as required
    return

# Pattern 3: Goal achieved
if current_sum == target:
    # Found valid combination
    return

# Pattern 4: No more choices
if not remaining_choices:
    return

# Pattern 5: Invalid state (pruning)
if current_sum > target:  # PRUNE!
    return  # No need to explore further
```

## The "Leap of Faith" Concept

This is the KEY to understanding recursion and backtracking!

### What is Leap of Faith?

**Assume your recursive function ALREADY works correctly for smaller inputs.**

Don't trace through every recursive call mentally. Instead:
1. Define what your function does clearly
2. Trust it will do that for smaller problems
3. Focus only on: What do I do with the current element?

### Example: Generating All Subsets

```python
def generate_subsets(nums, index, current_subset, result):
    """Generate all subsets of nums starting from index."""
    
    # Base case: processed all elements
    if index == len(nums):
        result.append(current_subset[:])
        return
    
    # For current element nums[index], we have 2 choices:
    
    # Choice 1: INCLUDE current element
    current_subset.append(nums[index])
    generate_subsets(nums, index + 1, current_subset, result)  # LEAP OF FAITH!
    # Trust that this will correctly generate all subsets
    # that include nums[index]
    
    current_subset.pop()  # BACKTRACK!
    
    # Choice 2: EXCLUDE current element
    generate_subsets(nums, index + 1, current_subset, result)  # LEAP OF FAITH!
    # Trust that this will correctly generate all subsets
    # that exclude nums[index]
```

### Mental Model:

```
                        []
                       /  \
                      /    \
               Include 1    Exclude 1
                  [1]          []
                 /  \         /  \
          Inc 2   Exc 2   Inc 2   Exc 2
          [1,2]   [1]     [2]      []
          / \     / \     / \      / \
        ...  ... ...  ...  ... ... ... ...
```

**TRUST that the recursive call handles all the complexity below!**

## Visualizing the Recursion Tree

Every backtracking problem can be visualized as a **decision tree**:

```
                          START (root)
                             |
              +--------------+--------------+
              |              |              |
           Choice 1       Choice 2       Choice 3
              |              |              |
          +---+---+      +---+---+      +---+---+
          |       |      |       |      |       |
        C1a     C1b    C2a     C2b    C3a     C3b
         |       X      |       |      X       |
        ...   (prune)  ...     ...  (prune)   ...
                                              |
                                          SOLUTION!
```

- Each **node** = a state in our exploration
- Each **edge** = a decision/choice
- **Leaves** = base cases (solutions or dead ends)
- **X (pruned)** = branches we skip (constraint violated)

## Step-by-Step: How Backtracking Works

Let's trace through finding all permutations of [1, 2, 3]:

```
Step 1: Start with empty permutation []
        Choices available: [1, 2, 3]

Step 2: Pick 1 -> [1]
        Choices remaining: [2, 3]

Step 3: Pick 2 -> [1, 2]
        Choices remaining: [3]

Step 4: Pick 3 -> [1, 2, 3]
        Choices remaining: []
        BASE CASE! Record [1, 2, 3] as solution

Step 5: BACKTRACK! Remove 3 -> [1, 2]
        No more choices at this level

Step 6: BACKTRACK! Remove 2 -> [1]
        Try next choice: 3

Step 7: Pick 3 -> [1, 3]
        Choices remaining: [2]

Step 8: Pick 2 -> [1, 3, 2]
        BASE CASE! Record [1, 3, 2] as solution

... continue until all 6 permutations found ...
```

## Time Complexity Analysis

### General Formula:

```
Time = O(number_of_nodes * work_per_node)
```

### Common Complexities:

| Problem Type | Time Complexity | Explanation |
|--------------|-----------------|-------------|
| Permutations | O(n! * n) | n! leaves, O(n) to copy each |
| Subsets | O(2^n * n) | 2^n subsets, O(n) to copy |
| Combinations | O(C(n,k) * k) | C(n,k) combinations |
| N-Queens | O(n!) worst case | Pruning helps significantly |
| Sudoku | O(9^empty_cells) | 9 choices per empty cell |

### Why Backtracking is Faster than Brute Force:

```
Brute Force: Try ALL combinations, then filter
             O(all_possibilities)

Backtracking: Stop early when constraint violated
              O(valid_possibilities) << O(all_possibilities)
```

## Space Complexity

```
Space = O(maximum_recursion_depth + auxiliary_space)
```

- **Recursion depth** = longest path from root to leaf
- **Auxiliary space** = space for current state, visited arrays, etc.

### Examples:

| Problem | Space Complexity |
|---------|------------------|
| Permutations of n elements | O(n) recursion + O(n) current perm |
| Subsets | O(n) recursion + O(n) current subset |
| N-Queens | O(n) recursion + O(n) board state |
| Sudoku | O(81) = O(1) |

## Common Patterns and Techniques

### Pattern 1: Include/Exclude (Subset Pattern)
```python
# Include current element
include_choice()
backtrack(index + 1)
exclude_choice()  # Backtrack

# Exclude current element
backtrack(index + 1)
```

### Pattern 2: Choose from Remaining (Permutation Pattern)
```python
for i in range(start, end):
    swap(arr, start, i)
    backtrack(start + 1)
    swap(arr, start, i)  # Backtrack
```

### Pattern 3: Grid Exploration
```python
directions = [(0,1), (1,0), (0,-1), (-1,0)]
for dx, dy in directions:
    new_x, new_y = x + dx, y + dy
    if is_valid(new_x, new_y):
        mark_visited(new_x, new_y)
        backtrack(new_x, new_y)
        unmark_visited(new_x, new_y)  # Backtrack
```

### Pattern 4: Building String/Sequence
```python
for char in choices:
    current.append(char)
    backtrack(remaining_choices)
    current.pop()  # Backtrack
```

## Common Mistakes to Avoid

### Mistake 1: Forgetting to Backtrack
```python
# WRONG
current.append(choice)
backtrack(next_state)
# Missing: current.pop()

# CORRECT
current.append(choice)
backtrack(next_state)
current.pop()  # BACKTRACK!
```

### Mistake 2: Modifying Loop Variable
```python
# WRONG
for i in range(len(arr)):
    backtrack(arr.pop(i))  # Modifies arr during iteration!

# CORRECT
for i in range(len(arr)):
    chosen = arr[i]
    backtrack(arr[:i] + arr[i+1:])  # Create new list
```

### Mistake 3: Not Copying Results
```python
# WRONG - All results point to same list!
result.append(current)

# CORRECT - Make a copy!
result.append(current[:])  # or list(current)
```

## Summary: The Backtracking Mindset

```
1. Think: What are ALL possible choices at each step?
2. Think: What constraints must be satisfied?
3. Think: When is the solution complete? (Base case)
4. Code: For each valid choice:
         - Make the choice
         - Recurse to explore
         - Undo the choice (BACKTRACK!)
5. Trust: The "leap of faith" - recursion handles the rest
```

## Practice Problems (Increasing Difficulty)

1. **Easy**: Generate all subsets, permutations
2. **Medium**: N-Queens, Sudoku, combination sum
3. **Hard**: Word break, remove invalid parentheses
4. **Expert**: Graph coloring, longest path in matrix

---

**Remember**: Backtracking is just systematic trial and error with the intelligence to abandon paths that can't work!
