# Remove Invalid Parentheses

## Problem Statement

Given a string `s` containing parentheses and letters, remove the **minimum number** of invalid parentheses to make the string valid. Return **all possible results**.

### Example

```
Input: s = "()())()"
Output: ["(())()", "()()()", "(())()"]

Input: s = "(a)())()"
Output: ["(a())()", "(a)()()", "(a())()"]
```

## Why Backtracking Works Here

1. **Multiple Valid Results**: Multiple ways to remove minimum parentheses
2. **Decision at Each Character**: Keep or remove each parenthesis
3. **Constraint Checking**: Track open/close balance
4. **Pruning Possible**: Skip invalid states early

## Recursion Tree Diagram

```
For s = "())", we need to remove 1 ')':

                        "())"
                       /     \
                Keep '('    Remove '('
                    |            |
                  "()"         ")"
                 /    \         |
            Keep ')'  Rem ')'  invalid
                |        |
              "()"      "("
             /    \       |
         Keep ')' Rem ')' Need more
            |       |     chars
          "())"    "()"
         invalid  VALID!

More detailed for s = "(()":

                    "(()
                   /    \
              Keep '('  Remove '('
                 |          |
               "(("       "("
              /    \       |
          Keep '(' Rem '(' Keep '('
             |       |       |
           "((("   "(("    "(("
           (cont)  (cont)   ...

Result: Need to find minimum removals
        that make string valid.
```

## Base Case Identification

```python
# BASE CASE: Processed all characters
if index == len(s):
    if open_count == 0:  # All parentheses balanced
        if len(current) > len(best_result):
            best_result = current  # Found longer valid string
        results.add(current)
    return

# PRUNING: Too many close parens (can't be fixed)
if close_count > open_count:
    return  # Invalid state, backtrack
```

## Recursive Case Explanation

```python
def backtrack(index, current, open_count, close_count, removals):
    char = s[index]
    
    if char == '(':
        # Option 1: Keep '('
        backtrack(index + 1, current + '(', open_count + 1, close_count, removals)
        # Option 2: Remove '(' 
        if removals < max_removals:
            backtrack(index + 1, current, open_count, close_count, removals + 1)
    
    elif char == ')':
        # Option 1: Keep ')' (only if we have matching '(')
        if open_count > close_count:
            backtrack(index + 1, current + ')', open_count, close_count + 1, removals)
        # Option 2: Remove ')'
        if removals < max_removals:
            backtrack(index + 1, current, open_count, close_count, removals + 1)
    
    else:  # Letter
        # Must keep letters
        backtrack(index + 1, current + char, open_count, close_count, removals)
```

## The "Leap of Faith" Application

**Trust that `backtrack(index + 1, ...)` will correctly explore all valid continuations.**

```python
# At each position, I make a choice (keep or remove)
# I trust that recursion will:
#   - Explore all possibilities from this choice
#   - Find all valid strings
#   - Handle the complexity of remaining characters

backtrack(index + 1, current + '(', ...)  # LEAP OF FAITH
# After this returns, all valid strings that START with
# keeping '(' at position 'index' have been found
```

## Step-by-Step Dry Run

**Input**: s = "())"

```
Step 1: Calculate minimum removals needed
        Count: '(' = 1, ')' = 2
        Extra ')' = 1, so min_removals = 1

Step 2: index=0, char='(', current=""
        Choice: Keep '(' -> current="("
        Recurse...

Step 3: index=1, char=')', current="("
        open=1, close=0, so can keep ')'
        Choice: Keep ')' -> current="()"
        Recurse...

Step 4: index=2, char=')', current="()"
        open=1, close=1, so can keep ')'
        Keep ')' -> "())" BUT close > open after!
        Remove ')' -> "()" is valid!
        
Step 5: Backtrack and explore remove '(' option
        ... explore other branches ...

Result: "()" is the only valid result
```

## Time Complexity

**O(2^n)** where n = length of string
- At each parenthesis, we have 2 choices: keep or remove
- In practice, pruning reduces this significantly

## Space Complexity

**O(n)** for recursion stack and current string

## Optimization: BFS Approach

```python
# BFS finds minimum removals naturally (level by level)
def remove_invalid_bfs(s):
    queue = {s}
    while queue:
        valid = [x for x in queue if is_valid(x)]
        if valid:
            return valid
        # Generate next level (one more removal)
        next_queue = set()
        for string in queue:
            for i in range(len(string)):
                if string[i] in '()':
                    next_queue.add(string[:i] + string[i+1:])
        queue = next_queue
    return [""]
```

## Key Insights

1. **Calculate Min Removals First**: Count mismatched parentheses
2. **Use Set for Deduplication**: Same result can be reached multiple ways
3. **Prune Early**: If close > open, can't be valid
4. **BFS vs DFS**: BFS naturally finds minimum removal level

## Related Problems

- Valid Parentheses
- Generate Parentheses
- Longest Valid Parentheses
- Minimum Add to Make Parentheses Valid
