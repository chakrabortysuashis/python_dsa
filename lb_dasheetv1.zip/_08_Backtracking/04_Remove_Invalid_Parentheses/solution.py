"""
Remove Invalid Parentheses - Backtracking Solution
===================================================

Problem: Remove minimum number of invalid parentheses to make string valid.
         Return all possible results.

Time Complexity: O(2^n) worst case
Space Complexity: O(n) for recursion
"""

from typing import List, Set


def remove_invalid_parentheses(s: str) -> List[str]:
    """
    Remove minimum parentheses to make string valid.

    Approach:
    1. Calculate minimum removals needed
    2. Use backtracking to try all combinations
    3. Prune branches that can't lead to valid results

    Recursion Tree for s="())":

                    "())"
                   /     \
              Keep '('  Remove '('
                 |           |
               "()"        ")"
              /    \         |
          Keep ')' Rem ')' invalid
             |       |
           "())"   "()"
          invalid  VALID!

    Args:
        s: Input string with parentheses and letters

    Returns:
        List of valid strings with minimum removals
    """
    def calc_removals(s: str) -> tuple:
        """Calculate minimum '(' and ')' removals needed."""
        left_rem = right_rem = 0
        for c in s:
            if c == '(':
                left_rem += 1
            elif c == ')':
                if left_rem > 0:
                    left_rem -= 1
                else:
                    right_rem += 1
        return left_rem, right_rem

    left_rem, right_rem = calc_removals(s)
    result: Set[str] = set()

    def backtrack(index: int, current: str, left: int, right: int,
                  left_rem: int, right_rem: int) -> None:
        """
        Backtrack to find all valid strings.

        Args:
            index: Current position in string
            current: Current built string
            left: Count of '(' in current
            right: Count of ')' in current
            left_rem: Remaining '(' to remove
            right_rem: Remaining ')' to remove
        """
        # BASE CASE: End of string
        if index == len(s):
            if left_rem == 0 and right_rem == 0:
                result.add(current)
            return

        char = s[index]

        if char == '(':
            # Option 1: Remove '(' if we need to
            if left_rem > 0:
                backtrack(index + 1, current, left, right,
                         left_rem - 1, right_rem)
            # Option 2: Keep '('
            backtrack(index + 1, current + '(', left + 1, right,
                     left_rem, right_rem)

        elif char == ')':
            # Option 1: Remove ')' if we need to
            if right_rem > 0:
                backtrack(index + 1, current, left, right,
                         left_rem, right_rem - 1)
            # Option 2: Keep ')' only if we have matching '('
            if left > right:
                backtrack(index + 1, current + ')', left, right + 1,
                         left_rem, right_rem)

        else:
            # Letters: always keep
            backtrack(index + 1, current + char, left, right,
                     left_rem, right_rem)

    backtrack(0, "", 0, 0, left_rem, right_rem)
    return list(result) if result else [""]


def remove_invalid_bfs(s: str) -> List[str]:
    """
    BFS approach - naturally finds minimum removals.

    Each BFS level represents one more removal.
    Stop at first level with valid strings.
    """
    def is_valid(string: str) -> bool:
        count = 0
        for c in string:
            if c == '(':
                count += 1
            elif c == ')':
                count -= 1
            if count < 0:
                return False
        return count == 0

    # Start BFS
    level = {s}
    while level:
        valid = [x for x in level if is_valid(x)]
        if valid:
            return valid

        # Generate next level (one more removal)
        next_level = set()
        for string in level:
            for i in range(len(string)):
                if string[i] in '()':
                    # Remove character at position i
                    next_level.add(string[:i] + string[i+1:])
        level = next_level

    return [""]


def remove_invalid_trace(s: str) -> List[str]:
    """Version with trace output for learning."""
    def calc_removals(s):
        left_rem = right_rem = 0
        for c in s:
            if c == '(':
                left_rem += 1
            elif c == ')':
                if left_rem > 0:
                    left_rem -= 1
                else:
                    right_rem += 1
        return left_rem, right_rem

    left_rem, right_rem = calc_removals(s)
    print(f"String: \"{s}\"")
    print(f"Need to remove: {left_rem} '(' and {right_rem} ')'")

    result = set()

    def backtrack(index, current, left, right, lr, rr, depth):
        indent = "  " * depth
        print(f"{indent}pos={index}, curr=\"{current}\", left={left}, right={right}, lr={lr}, rr={rr}")

        if index == len(s):
            if lr == 0 and rr == 0:
                print(f"{indent}>>> VALID: \"{current}\"")
                result.add(current)
            return

        char = s[index]
        print(f"{indent}Processing '{char}'")

        if char == '(':
            if lr > 0:
                print(f"{indent}  Remove '('")
                backtrack(index + 1, current, left, right, lr - 1, rr, depth + 1)
            print(f"{indent}  Keep '('")
            backtrack(index + 1, current + '(', left + 1, right, lr, rr, depth + 1)
        elif char == ')':
            if rr > 0:
                print(f"{indent}  Remove ')'")
                backtrack(index + 1, current, left, right, lr, rr - 1, depth + 1)
            if left > right:
                print(f"{indent}  Keep ')'")
                backtrack(index + 1, current + ')', left, right + 1, lr, rr, depth + 1)
        else:
            print(f"{indent}  Keep letter '{char}'")
            backtrack(index + 1, current + char, left, right, lr, rr, depth + 1)

    backtrack(0, "", 0, 0, left_rem, right_rem, 0)
    return list(result)


# ============================================================================
# TEST CASES
# ============================================================================

def run_tests():
    print("=" * 60)
    print("REMOVE INVALID PARENTHESES")
    print("=" * 60)

    test_cases = [
        "()())()",
        "(a)())()",
        ")(",
        "(()",
        "()",
        "",
    ]

    for s in test_cases:
        print(f"\nInput: \"{s}\"")
        result = remove_invalid_parentheses(s)
        print(f"Output: {result}")

    print("\n" + "-" * 40)
    print("Trace Example:")
    print("-" * 40)
    remove_invalid_trace("())")

    print("\n" + "=" * 60)
    print("TESTS COMPLETED!")
    print("=" * 60)


if __name__ == "__main__":
    run_tests()
