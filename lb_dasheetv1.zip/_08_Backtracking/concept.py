"""
Backtracking Template Implementation
=====================================

This module provides universal backtracking templates and examples
to help understand the backtracking paradigm.

Key Concepts:
1. Explore all possibilities systematically
2. Prune invalid branches early (optimization)
3. DO -> RECURSE -> UNDO pattern
4. Base case identifies when solution is complete
"""

from typing import List, Any, Callable, Optional


# =============================================================================
# UNIVERSAL BACKTRACKING TEMPLATE
# =============================================================================

def backtracking_template(
    state: Any,
    choices: List[Any],
    is_complete: Callable,
    is_valid: Callable,
    make_choice: Callable,
    undo_choice: Callable,
    process_solution: Callable
) -> None:
    """
    Universal backtracking template.

    The Three Steps (DO - RECURSE - UNDO):
    1. DO: Make a choice (modify state)
    2. RECURSE: Explore further with this choice
    3. UNDO: Remove the choice (restore state) - THIS IS BACKTRACKING!

    Args:
        state: Current state of the solution being built
        choices: Available choices at current step
        is_complete: Function to check if solution is complete
        is_valid: Function to check if a choice is valid
        make_choice: Function to apply a choice to state
        undo_choice: Function to remove a choice from state
        process_solution: Function to handle a complete solution
    """
    # BASE CASE: Solution is complete
    if is_complete(state):
        process_solution(state)
        return

    # RECURSIVE CASE: Try all valid choices
    for choice in choices:
        if is_valid(choice, state):
            # 1. DO: Make the choice
            make_choice(choice, state)

            # 2. RECURSE: Explore further
            backtracking_template(
                state, choices, is_complete, is_valid,
                make_choice, undo_choice, process_solution
            )

            # 3. UNDO: Backtrack!
            undo_choice(choice, state)


# =============================================================================
# TEMPLATE 1: SUBSETS (Include/Exclude Pattern)
# =============================================================================

def generate_subsets(nums: List[int]) -> List[List[int]]:
    """
    Generate all subsets of a list using backtracking.

    Pattern: Include/Exclude for each element

    Decision Tree for [1, 2]:

                    []
                   /  \
           Include 1   Exclude 1
              [1]          []
             /  \         /  \
        Inc 2  Exc 2  Inc 2  Exc 2
        [1,2]   [1]    [2]    []

    Time Complexity: O(2^n * n) - 2^n subsets, O(n) to copy each
    Space Complexity: O(n) - recursion depth

    Args:
        nums: Input list of numbers

    Returns:
        List of all subsets
    """
    result = []

    def backtrack(index: int, current: List[int]) -> None:
        """
        Backtracking helper.

        Args:
            index: Current position in nums
            current: Current subset being built
        """
        # BASE CASE: Processed all elements
        if index == len(nums):
            # IMPORTANT: Make a copy! Don't append the reference
            result.append(current[:])
            return

        # CHOICE 1: Include nums[index]
        current.append(nums[index])  # DO
        backtrack(index + 1, current)  # RECURSE
        current.pop()  # UNDO (Backtrack!)

        # CHOICE 2: Exclude nums[index]
        backtrack(index + 1, current)  # RECURSE (no change to state)

    backtrack(0, [])
    return result


# =============================================================================
# TEMPLATE 2: PERMUTATIONS (Choose from Remaining Pattern)
# =============================================================================

def generate_permutations(nums: List[int]) -> List[List[int]]:
    """
    Generate all permutations of a list using backtracking.

    Pattern: Choose any unused element at each position

    Decision Tree for [1, 2, 3]:

                        []
              /          |          \
         Pick 1       Pick 2       Pick 3
           [1]          [2]          [3]
          /   \        /   \        /   \
       P2    P3     P1    P3     P1    P2
      [1,2] [1,3]  [2,1] [2,3]  [3,1] [3,2]
        |     |      |     |      |     |
       P3    P2     P3    P1     P2    P1
     [1,2,3][1,3,2][2,1,3][2,3,1][3,1,2][3,2,1]

    Time Complexity: O(n! * n) - n! permutations, O(n) to copy each
    Space Complexity: O(n) - recursion depth + used array

    Args:
        nums: Input list of numbers

    Returns:
        List of all permutations
    """
    result = []
    used = [False] * len(nums)  # Track which elements are used

    def backtrack(current: List[int]) -> None:
        """
        Backtracking helper.

        Args:
            current: Current permutation being built
        """
        # BASE CASE: Permutation is complete
        if len(current) == len(nums):
            result.append(current[:])
            return

        # Try each unused element
        for i in range(len(nums)):
            if used[i]:
                continue  # Skip already used elements

            # DO
            used[i] = True
            current.append(nums[i])

            # RECURSE
            backtrack(current)

            # UNDO (Backtrack!)
            current.pop()
            used[i] = False

    backtrack([])
    return result


# =============================================================================
# TEMPLATE 3: COMBINATIONS (Choose k from n Pattern)
# =============================================================================

def generate_combinations(n: int, k: int) -> List[List[int]]:
    """
    Generate all combinations of k numbers from 1 to n.

    Pattern: Choose k elements, maintaining order to avoid duplicates

    Key Insight: Start from current index to avoid duplicates

    Decision Tree for n=4, k=2:

                        []
           /      |      |      \
         1        2      3       4
        /|\      / \     |
       2 3 4    3   4    4
      [1,2][1,3][1,4][2,3][2,4][3,4]

    Time Complexity: O(C(n,k) * k) - C(n,k) combinations
    Space Complexity: O(k) - recursion depth

    Args:
        n: Range [1, n]
        k: Number of elements to choose

    Returns:
        List of all combinations
    """
    result = []

    def backtrack(start: int, current: List[int]) -> None:
        """
        Backtracking helper.

        Args:
            start: Starting number to consider (avoids duplicates)
            current: Current combination being built
        """
        # BASE CASE: Combination is complete
        if len(current) == k:
            result.append(current[:])
            return

        # PRUNING: Not enough elements left
        # If we need (k - len(current)) more elements,
        # but only (n - start + 1) are available, prune!
        if n - start + 1 < k - len(current):
            return

        # Try each number from start to n
        for num in range(start, n + 1):
            # DO
            current.append(num)

            # RECURSE: Start from num + 1 to maintain order
            backtrack(num + 1, current)

            # UNDO (Backtrack!)
            current.pop()

    backtrack(1, [])
    return result


# =============================================================================
# TEMPLATE 4: COMBINATION SUM (Reuse Elements Pattern)
# =============================================================================

def combination_sum(candidates: List[int], target: int) -> List[List[int]]:
    """
    Find all combinations that sum to target. Elements can be reused.

    Pattern: Include/Exclude with possibility of reuse

    Key Insight: Allow including same element multiple times

    Decision Tree for candidates=[2,3], target=5:

                    sum=0
                    /   \
               +2(=2)  +3(=3)
               /    \     |
           +2(=4) +3(=5) +3(=6) PRUNE!
            |       |
         +2(=6)   FOUND!
         PRUNE!

    Time Complexity: O(2^target) in worst case
    Space Complexity: O(target) - max recursion depth

    Args:
        candidates: Available numbers
        target: Target sum

    Returns:
        List of combinations that sum to target
    """
    result = []
    candidates.sort()  # Sort for pruning optimization

    def backtrack(start: int, current: List[int], remaining: int) -> None:
        """
        Backtracking helper.

        Args:
            start: Starting index in candidates
            current: Current combination being built
            remaining: Remaining sum needed
        """
        # BASE CASE: Found valid combination
        if remaining == 0:
            result.append(current[:])
            return

        # BASE CASE: Exceeded target (PRUNE!)
        if remaining < 0:
            return

        # Try each candidate from start
        for i in range(start, len(candidates)):
            # PRUNING: If current candidate > remaining, all following will too
            # (because array is sorted)
            if candidates[i] > remaining:
                break

            # DO
            current.append(candidates[i])

            # RECURSE: Start from i (not i+1) to allow reuse
            backtrack(i, current, remaining - candidates[i])

            # UNDO (Backtrack!)
            current.pop()

    backtrack(0, [], target)
    return result


# =============================================================================
# TEMPLATE 5: GRID EXPLORATION (Path Finding Pattern)
# =============================================================================

def find_all_paths(grid: List[List[int]],
                   start: tuple,
                   end: tuple) -> List[List[tuple]]:
    """
    Find all paths from start to end in a grid.

    Pattern: Try all 4 directions, mark visited, backtrack

    Grid Example:
    0 0 0
    0 1 0  (1 = obstacle)
    0 0 0

    Time Complexity: O(4^(m*n)) worst case
    Space Complexity: O(m*n) - visited array

    Args:
        grid: 2D grid (0 = open, 1 = obstacle)
        start: Starting position (row, col)
        end: Ending position (row, col)

    Returns:
        List of all valid paths
    """
    if not grid or not grid[0]:
        return []

    rows, cols = len(grid), len(grid[0])
    result = []

    # 4 directions: right, down, left, up
    directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]

    def is_valid(row: int, col: int, visited: set) -> bool:
        """Check if cell is valid to visit."""
        return (0 <= row < rows and
                0 <= col < cols and
                grid[row][col] == 0 and
                (row, col) not in visited)

    def backtrack(row: int, col: int, path: List[tuple], visited: set) -> None:
        """
        Backtracking helper.

        Args:
            row, col: Current position
            path: Current path being built
            visited: Set of visited cells
        """
        # BASE CASE: Reached destination
        if (row, col) == end:
            result.append(path[:])
            return

        # Try all 4 directions
        for dr, dc in directions:
            new_row, new_col = row + dr, col + dc

            if is_valid(new_row, new_col, visited):
                # DO
                visited.add((new_row, new_col))
                path.append((new_row, new_col))

                # RECURSE
                backtrack(new_row, new_col, path, visited)

                # UNDO (Backtrack!)
                path.pop()
                visited.remove((new_row, new_col))

    # Start backtracking
    start_row, start_col = start
    if grid[start_row][start_col] == 1:
        return []  # Start is blocked

    visited = {start}
    backtrack(start_row, start_col, [start], visited)

    return result


# =============================================================================
# TEMPLATE 6: CONSTRAINT SATISFACTION (N-Queens Pattern)
# =============================================================================

def solve_n_queens(n: int) -> List[List[str]]:
    """
    Solve the N-Queens problem: Place N queens on NxN board.
    No two queens can attack each other.

    Pattern: Place queen row by row, check column/diagonal constraints

    Constraints:
    - Only one queen per row
    - Only one queen per column
    - Only one queen per diagonal

    Decision Tree for N=4:

                     []
           /    |    |    \
        col0  col1  col2  col3   (row 0)
          X     .     .     X     (X = leads to solution)
               / \
            col0 col2 col3       (row 1)
             X    .    X

    Time Complexity: O(n!) - at most n choices for first row, n-1 for second, etc.
    Space Complexity: O(n) - board state

    Args:
        n: Size of board and number of queens

    Returns:
        List of valid board configurations
    """
    result = []

    # Track occupied columns and diagonals
    cols = set()       # Occupied columns
    diag1 = set()      # Occupied "\" diagonals (row - col)
    diag2 = set()      # Occupied "/" diagonals (row + col)

    board = [['.' for _ in range(n)] for _ in range(n)]

    def backtrack(row: int) -> None:
        """
        Place queens row by row.

        Args:
            row: Current row to place queen
        """
        # BASE CASE: All queens placed
        if row == n:
            # Convert board to required format
            result.append([''.join(r) for r in board])
            return

        # Try each column in current row
        for col in range(n):
            # Check constraints
            if col in cols or (row - col) in diag1 or (row + col) in diag2:
                continue  # PRUNE: This position is under attack

            # DO: Place queen
            board[row][col] = 'Q'
            cols.add(col)
            diag1.add(row - col)
            diag2.add(row + col)

            # RECURSE: Move to next row
            backtrack(row + 1)

            # UNDO (Backtrack!): Remove queen
            board[row][col] = '.'
            cols.remove(col)
            diag1.remove(row - col)
            diag2.remove(row + col)

    backtrack(0)
    return result


# =============================================================================
# TEMPLATE 7: STRING GENERATION (Build Character by Character)
# =============================================================================

def generate_parentheses(n: int) -> List[str]:
    """
    Generate all valid combinations of n pairs of parentheses.

    Pattern: Build string character by character with constraints

    Constraints:
    - Can add '(' if open_count < n
    - Can add ')' if close_count < open_count

    Decision Tree for n=2:

                    ""
                    |
                   "("
                  /   \
               "(("   "()"
                |      |
              "(()"  "()("
                |      |
             "(())"  "()()"

    Time Complexity: O(4^n / sqrt(n)) - Catalan number
    Space Complexity: O(n) - recursion depth

    Args:
        n: Number of pairs of parentheses

    Returns:
        List of valid parentheses combinations
    """
    result = []

    def backtrack(current: List[str], open_count: int, close_count: int) -> None:
        """
        Build parentheses string.

        Args:
            current: Current string being built
            open_count: Number of '(' used
            close_count: Number of ')' used
        """
        # BASE CASE: Used all parentheses
        if len(current) == 2 * n:
            result.append(''.join(current))
            return

        # CHOICE 1: Add '(' if we haven't used all
        if open_count < n:
            current.append('(')  # DO
            backtrack(current, open_count + 1, close_count)  # RECURSE
            current.pop()  # UNDO

        # CHOICE 2: Add ')' if valid (more '(' than ')')
        if close_count < open_count:
            current.append(')')  # DO
            backtrack(current, open_count, close_count + 1)  # RECURSE
            current.pop()  # UNDO

    backtrack([], 0, 0)
    return result


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Run all test cases."""
    print("=" * 60)
    print("BACKTRACKING TEMPLATE TESTS")
    print("=" * 60)

    # Test 1: Subsets
    print("\n1. SUBSETS of [1, 2, 3]:")
    print("-" * 40)
    subsets = generate_subsets([1, 2, 3])
    for s in subsets:
        print(f"   {s}")
    print(f"   Total: {len(subsets)} subsets")

    # Test 2: Permutations
    print("\n2. PERMUTATIONS of [1, 2, 3]:")
    print("-" * 40)
    perms = generate_permutations([1, 2, 3])
    for p in perms:
        print(f"   {p}")
    print(f"   Total: {len(perms)} permutations")

    # Test 3: Combinations
    print("\n3. COMBINATIONS C(4, 2):")
    print("-" * 40)
    combs = generate_combinations(4, 2)
    for c in combs:
        print(f"   {c}")
    print(f"   Total: {len(combs)} combinations")

    # Test 4: Combination Sum
    print("\n4. COMBINATION SUM (candidates=[2,3,5], target=8):")
    print("-" * 40)
    comb_sums = combination_sum([2, 3, 5], 8)
    for cs in comb_sums:
        print(f"   {cs} = {sum(cs)}")
    print(f"   Total: {len(comb_sums)} combinations")

    # Test 5: Grid Paths
    print("\n5. GRID PATHS (3x3 grid with obstacle):")
    print("-" * 40)
    grid = [
        [0, 0, 0],
        [0, 1, 0],
        [0, 0, 0]
    ]
    paths = find_all_paths(grid, (0, 0), (2, 2))
    print(f"   Found {len(paths)} paths from (0,0) to (2,2)")
    for i, path in enumerate(paths):
        print(f"   Path {i+1}: {path}")

    # Test 6: N-Queens
    print("\n6. N-QUEENS (N=4):")
    print("-" * 40)
    solutions = solve_n_queens(4)
    print(f"   Found {len(solutions)} solutions")
    for i, sol in enumerate(solutions):
        print(f"\n   Solution {i+1}:")
        for row in sol:
            print(f"   {row}")

    # Test 7: Generate Parentheses
    print("\n7. GENERATE PARENTHESES (n=3):")
    print("-" * 40)
    parens = generate_parentheses(3)
    for p in parens:
        print(f"   {p}")
    print(f"   Total: {len(parens)} valid combinations")

    print("\n" + "=" * 60)
    print("ALL TESTS COMPLETED!")
    print("=" * 60)


if __name__ == "__main__":
    run_tests()
