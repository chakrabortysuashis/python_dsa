# Word Break Problem using Backtracking

## Problem Statement

Given a string `s` and a dictionary of words `wordDict`, determine if `s` can be segmented into a space-separated sequence of one or more dictionary words.

**Variation**: Find ALL possible ways to break the string.

### Example

```
Input: s = "catsanddog", wordDict = ["cat", "cats", "and", "sand", "dog"]

Output: 
- "cats and dog"
- "cat sand dog"
```

## Why Backtracking Works Here

This problem exhibits the **optimal substructure** for backtracking:

1. **Multiple Valid Splits**: A string can often be broken in multiple ways
2. **Prefix Matching**: At each position, try all valid word prefixes
3. **Dependent Decisions**: Each word choice affects remaining string
4. **Need All Solutions**: Backtracking naturally finds all possibilities

### The Decision at Each Position

At position `i` in the string, we try every possible word that:
- Starts at position `i`
- Exists in the dictionary
- If found, recurse on the remaining substring

## Recursion Tree Diagram

```
For s = "catsanddog", dict = ["cat", "cats", "and", "sand", "dog"]

                            "catsanddog"
                           /            \
                      "cat"              "cats"
                         |                   |
                   "sanddog"              "anddog"
                   /      \                   |
               "sand"    (no match         "and"
                  |       for "s")            |
               "dog"                       "dog"
                  |                           |
                 ""                          ""
                  |                           |
            SOLUTION:                    SOLUTION:
         "cat sand dog"               "cats and dog"

Detailed Recursion Tree:

                    backtrack("catsanddog", [])
                           /              \
            +-------------+                +-------------+
            |                                            |
  word="cat" matches                          word="cats" matches
  backtrack("sanddog", ["cat"])              backtrack("anddog", ["cats"])
            |                                            |
      +-----+-----+                              word="and" matches
      |           |                              backtrack("dog", ["cats","and"])
  "sand"      "s..." no                                  |
  matches     match                              word="dog" matches
      |                                          backtrack("", ["cats","and","dog"])
  backtrack("dog", ["cat","sand"])                       |
      |                                          BASE CASE! 
  "dog" matches                                  SOLUTION: "cats and dog"
  backtrack("", ["cat","sand","dog"])
      |
  BASE CASE!
  SOLUTION: "cat sand dog"
```

## Base Case Identification

```python
# BASE CASE 1: Successfully segmented entire string
if start == len(s):
    # All characters processed - valid segmentation found!
    result.append(' '.join(current_words))
    return

# BASE CASE 2: No word matches at current position
# (Implicit - loop doesn't find any match, function returns)
```

## Recursive Case Explanation

```python
def backtrack(start, current_words):
    # Try all possible word endings from current position
    for end in range(start + 1, len(s) + 1):
        word = s[start:end]
        
        if word in word_set:
            # DO: Add this word to our segmentation
            current_words.append(word)
            
            # RECURSE: Process remaining string
            backtrack(end, current_words)
            
            # UNDO: Remove word to try other options
            current_words.pop()
```

## The "Leap of Faith" Application

**Trust that `backtrack(end, words)` will correctly find all valid segmentations of `s[end:]`.**

```python
# I found that s[start:end] is a valid word.
# I trust that backtrack(end, ...) will:
#   - Find all ways to segment the remaining string s[end:]
#   - Add complete solutions to the result
#   - Handle all the complexity of what comes after

current_words.append(word)
backtrack(end, current_words)  # <-- LEAP OF FAITH
current_words.pop()
```

## Step-by-Step Dry Run

**Input**: s = "leetcode", wordDict = ["leet", "code"]

```
Step 1: start=0, words=[]
        Try s[0:1]="l" - not in dict
        Try s[0:2]="le" - not in dict
        Try s[0:3]="lee" - not in dict
        Try s[0:4]="leet" - IN DICT!
        
Step 2: Add "leet", recurse with start=4
        start=4, words=["leet"]
        Try s[4:5]="c" - not in dict
        Try s[4:6]="co" - not in dict
        Try s[4:7]="cod" - not in dict
        Try s[4:8]="code" - IN DICT!

Step 3: Add "code", recurse with start=8
        start=8, words=["leet", "code"]
        start == len(s) -> BASE CASE!
        Record solution: "leet code"

Step 4: Backtrack: remove "code", words=["leet"]
        Continue trying: s[4:9] - out of bounds
        No more options, backtrack

Step 5: Backtrack: remove "leet", words=[]
        Try s[0:5]="leetc" - not in dict
        ... (continue until s[0:8]="leetcode")
        "leetcode" not in dict
        No more options

Result: ["leet code"]
```

## Time Complexity

**Worst Case: O(2^n * n)**

- At each position, we may or may not start a new word
- 2^n possible ways to partition string
- O(n) to build each solution string

**With Memoization**: O(n^2 * m) where m = number of words

## Space Complexity

**O(n)**

- Recursion depth: O(n) in worst case
- Current words list: O(n) words maximum
- Solution storage: O(number_of_solutions * n)

## Optimization: Memoization

```python
def word_break_memo(s, word_dict):
    word_set = set(word_dict)
    memo = {}  # Cache: start_index -> list of valid segmentations
    
    def backtrack(start):
        if start in memo:
            return memo[start]
        
        if start == len(s):
            return [[]]  # Empty segmentation (base case)
        
        results = []
        for end in range(start + 1, len(s) + 1):
            word = s[start:end]
            if word in word_set:
                # Get all segmentations of remaining string
                for rest in backtrack(end):
                    results.append([word] + rest)
        
        memo[start] = results
        return results
    
    return [' '.join(words) for words in backtrack(0)]
```

## Key Insights

1. **Use Set for Dictionary**: O(1) lookup vs O(n) for list

2. **Trie Optimization**: For large dictionaries, use Trie for prefix matching

3. **Early Termination**: If remaining string is shorter than shortest word, stop

4. **Pruning**: Track impossible starting positions to avoid redundant work

## Common Mistakes

1. **Modifying string directly**: Use indices, not string slicing for efficiency
2. **Not handling empty string**: Empty string should return valid (base case)
3. **Missing backtrack step**: Must pop() after recursive call
4. **Infinite recursion**: Ensure progress (end > start always)

## Variations

1. **Word Break I**: Just check if segmentation is possible (yes/no)
2. **Word Break II**: Find all possible segmentations (this problem)
3. **Word Break III**: Count number of ways
4. **Minimum Word Break**: Find segmentation with fewest words

## Related Problems

- Palindrome Partitioning
- Decode Ways
- Concatenated Words
- Sentence Screen Fitting
