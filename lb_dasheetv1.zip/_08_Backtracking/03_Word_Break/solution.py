"""
Word Break Problem - Backtracking Solution
============================================

Problem: Given a string s and a dictionary, find all ways to segment s
         into space-separated dictionary words.

Approach: Backtracking with prefix matching

Time Complexity: O(2^n * n) worst case, O(n^2 * m) with memoization
Space Complexity: O(n) for recursion stack
"""

from typing import List, Set, Dict


def word_break_all(s: str, word_dict: List[str]) -> List[str]:
    """
    Find all possible segmentations of string s using dictionary words.

    Backtracking Approach:
    - At each position, try all words that match as prefix
    - If match found, recurse on remaining string
    - Backtrack to try other words

    Recursion Tree for s="catsanddog":

                        "catsanddog"
                       /            \
                  "cat"             "cats"
                     |                 |
                "sanddog"          "anddog"
                   /                   |
              "sand"                "and"
                 |                     |
              "dog"                 "dog"
                 |                     |
                ""                    ""
            SOLUTION!             SOLUTION!

    Args:
        s: Input string to segment
        word_dict: List of valid words

    Returns:
        List of all valid segmentations
    """
    if not s:
        return []

    word_set: Set[str] = set(word_dict)
    result: List[str] = []

    def backtrack(start: int, current_words: List[str]) -> None:
        """
        Backtrack to find all segmentations.

        BASE CASE:
        - start == len(s): Found valid segmentation

        RECURSIVE CASE:
        - Try all possible words starting at 'start'

        Args:
            start: Current position in string
            current_words: Words chosen so far
        """
        # BASE CASE: Successfully segmented entire string
        if start == len(s):
            result.append(' '.join(current_words))
            return

        # Try all possible word endings from current position
        for end in range(start + 1, len(s) + 1):
            word = s[start:end]

            if word in word_set:
                # DO: Choose this word
                current_words.append(word)

                # RECURSE: Process remaining string
                backtrack(end, current_words)

                # UNDO: Backtrack to try other words
                current_words.pop()

    backtrack(0, [])
    return result


def word_break_memo(s: str, word_dict: List[str]) -> List[str]:
    """
    Optimized version with memoization.

    Caches results for each starting position to avoid redundant computation.

    Args:
        s: Input string to segment
        word_dict: List of valid words

    Returns:
        List of all valid segmentations
    """
    if not s:
        return []

    word_set: Set[str] = set(word_dict)
    memo: Dict[int, List[List[str]]] = {}

    def backtrack(start: int) -> List[List[str]]:
        """
        Return all segmentations of s[start:].

        Args:
            start: Starting position

        Returns:
            List of word lists representing segmentations
        """
        # Check cache
        if start in memo:
            return memo[start]

        # BASE CASE: End of string
        if start == len(s):
            return [[]]  # One valid segmentation: empty

        results: List[List[str]] = []

        # Try all possible word endings
        for end in range(start + 1, len(s) + 1):
            word = s[start:end]

            if word in word_set:
                # Get all segmentations of remaining string
                for rest in backtrack(end):
                    results.append([word] + rest)

        memo[start] = results
        return results

    # Convert word lists to strings
    return [' '.join(words) for words in backtrack(0)]


def word_break_check(s: str, word_dict: List[str]) -> bool:
    """
    Check if string can be segmented (no need to find all solutions).

    Uses DP for efficiency.

    Args:
        s: Input string
        word_dict: Dictionary of valid words

    Returns:
        True if segmentation is possible
    """
    word_set = set(word_dict)
    n = len(s)

    # dp[i] = True if s[0:i] can be segmented
    dp = [False] * (n + 1)
    dp[0] = True  # Empty string is valid

    for i in range(1, n + 1):
        for j in range(i):
            if dp[j] and s[j:i] in word_set:
                dp[i] = True
                break

    return dp[n]


def word_break_with_trace(s: str, word_dict: List[str]) -> List[str]:
    """
    Solve with detailed trace output for learning.
    """
    word_set = set(word_dict)
    result = []

    def backtrack(start: int, current_words: List[str], depth: int) -> None:
        indent = "  " * depth
        print(f"{indent}backtrack(start={start}, words={current_words})")

        if start == len(s):
            solution = ' '.join(current_words)
            result.append(solution)
            print(f"{indent}>>> SOLUTION: \"{solution}\"")
            return

        remaining = s[start:]
        print(f"{indent}Remaining string: \"{remaining}\"")

        for end in range(start + 1, len(s) + 1):
            word = s[start:end]

            if word in word_set:
                print(f"{indent}  Found word: \"{word}\" at positions [{start}:{end}]")

                current_words.append(word)
                backtrack(end, current_words, depth + 1)

                print(f"{indent}  Backtracking: removed \"{word}\"")
                current_words.pop()
            else:
                if end - start <= 5:  # Only print short failed attempts
                    print(f"{indent}  \"{word}\" not in dictionary")

    print(f"String: \"{s}\"")
    print(f"Dictionary: {word_dict}")
    print()

    backtrack(0, [], 0)
    return result


def word_break_trie(s: str, word_dict: List[str]) -> List[str]:
    """
    Trie-optimized version for large dictionaries.

    Uses Trie for efficient prefix matching.
    """
    # Build Trie
    class TrieNode:
        def __init__(self):
            self.children = {}
            self.is_word = False

    root = TrieNode()
    for word in word_dict:
        node = root
        for char in word:
            if char not in node.children:
                node.children[char] = TrieNode()
            node = node.children[char]
        node.is_word = True

    result = []

    def backtrack(start: int, current_words: List[str]) -> None:
        if start == len(s):
            result.append(' '.join(current_words))
            return

        # Use Trie for efficient prefix matching
        node = root
        for end in range(start, len(s)):
            char = s[end]
            if char not in node.children:
                break

            node = node.children[char]

            if node.is_word:
                word = s[start:end + 1]
                current_words.append(word)
                backtrack(end + 1, current_words)
                current_words.pop()

    backtrack(0, [])
    return result


# ============================================================================
# TEST CASES
# ============================================================================

def run_tests():
    print("=" * 60)
    print("WORD BREAK - BACKTRACKING SOLUTION")
    print("=" * 60)

    # Test Case 1: Multiple solutions
    print("\n" + "-" * 40)
    print("Test 1: Multiple Solutions")
    print("-" * 40)

    s1 = "catsanddog"
    dict1 = ["cat", "cats", "and", "sand", "dog"]

    print(f"String: \"{s1}\"")
    print(f"Dictionary: {dict1}")
    print()

    result = word_break_all(s1, dict1)
    print(f"Solutions ({len(result)}):")
    for sol in result:
        print(f"  \"{sol}\"")

    # Test Case 2: Single solution
    print("\n" + "-" * 40)
    print("Test 2: Single Solution")
    print("-" * 40)

    s2 = "leetcode"
    dict2 = ["leet", "code"]

    print(f"String: \"{s2}\"")
    print(f"Dictionary: {dict2}")

    result = word_break_all(s2, dict2)
    print(f"Solutions: {result}")

    # Test Case 3: No solution
    print("\n" + "-" * 40)
    print("Test 3: No Solution")
    print("-" * 40)

    s3 = "catsandog"
    dict3 = ["cats", "dog", "sand", "and", "cat"]

    print(f"String: \"{s3}\"")
    print(f"Dictionary: {dict3}")

    result = word_break_all(s3, dict3)
    print(f"Solutions: {result}")
    print(f"Can be segmented: {word_break_check(s3, dict3)}")

    # Test Case 4: Trace through
    print("\n" + "-" * 40)
    print("Test 4: Trace Through")
    print("-" * 40)

    s4 = "pineapplepenapple"
    dict4 = ["apple", "pen", "applepen", "pine", "pineapple"]

    result = word_break_with_trace(s4, dict4)
    print(f"\nAll solutions: {result}")

    # Test Case 5: Compare methods
    print("\n" + "-" * 40)
    print("Test 5: Compare Methods")
    print("-" * 40)

    s5 = "catsanddog"
    dict5 = ["cat", "cats", "and", "sand", "dog"]

    result_basic = word_break_all(s5, dict5)
    result_memo = word_break_memo(s5, dict5)
    result_trie = word_break_trie(s5, dict5)

    print(f"Basic: {sorted(result_basic)}")
    print(f"Memo:  {sorted(result_memo)}")
    print(f"Trie:  {sorted(result_trie)}")
    print(f"All methods match: {sorted(result_basic) == sorted(result_memo) == sorted(result_trie)}")

    print("\n" + "=" * 60)
    print("ALL TESTS COMPLETED!")
    print("=" * 60)


if __name__ == "__main__":
    run_tests()
