"""
Knight's Tour Problem - Backtracking Solution
=============================================

Time: O(8^(N^2)), Space: O(N^2)
"""

from typing import List, Tuple


def knights_tour(n: int) -> List[List[int]]:
    """
    Find a knight's tour on NxN board.

    Knight moves in L-shape:
        . 1 . 2 .
        3 . . . 4
        . . K . .
        5 . . . 6
        . 7 . 8 .
    """
    board = [[-1] * n for _ in range(n)]

    # 8 possible L-shaped moves
    moves = [(2, 1), (1, 2), (-1, 2), (-2, 1),
             (-2, -1), (-1, -2), (1, -2), (2, -1)]

    def is_valid(x: int, y: int) -> bool:
        return 0 <= x < n and 0 <= y < n and board[x][y] == -1

    def solve(x: int, y: int, move_count: int) -> bool:
        # BASE CASE: All squares visited
        if move_count == n * n:
            return True

        # Try all 8 moves
        for dx, dy in moves:
            nx, ny = x + dx, y + dy
            if is_valid(nx, ny):
                # DO
                board[nx][ny] = move_count

                # RECURSE
                if solve(nx, ny, move_count + 1):
                    return True

                # UNDO
                board[nx][ny] = -1

        return False

    # Start from (0, 0)
    board[0][0] = 0
    if solve(0, 0, 1):
        return board
    return []


def knights_tour_warnsdorff(n: int) -> List[List[int]]:
    """
    Optimized using Warnsdorff's heuristic:
    Move to square with fewest onward moves.
    """
    board = [[-1] * n for _ in range(n)]
    moves = [(2, 1), (1, 2), (-1, 2), (-2, 1),
             (-2, -1), (-1, -2), (1, -2), (2, -1)]

    def count_moves(x, y):
        count = 0
        for dx, dy in moves:
            nx, ny = x + dx, y + dy
            if 0 <= nx < n and 0 <= ny < n and board[nx][ny] == -1:
                count += 1
        return count

    def solve(x, y, move_count):
        if move_count == n * n:
            return True

        # Get all valid moves with their degree
        valid_moves = []
        for dx, dy in moves:
            nx, ny = x + dx, y + dy
            if 0 <= nx < n and 0 <= ny < n and board[nx][ny] == -1:
                valid_moves.append((count_moves(nx, ny), nx, ny))

        # Sort by degree (Warnsdorff's rule)
        valid_moves.sort()

        for _, nx, ny in valid_moves:
            board[nx][ny] = move_count
            if solve(nx, ny, move_count + 1):
                return True
            board[nx][ny] = -1

        return False

    board[0][0] = 0
    if solve(0, 0, 1):
        return board
    return []


def print_board(board: List[List[int]]) -> None:
    n = len(board)
    for row in board:
        print(' '.join(f'{x:2d}' for x in row))


# ============================================================================
# TEST CASES
# ============================================================================

if __name__ == "__main__":
    print("KNIGHT'S TOUR")
    print("=" * 40)

    # Small board
    n = 5
    print(f"\n{n}x{n} Board (Warnsdorff):")
    board = knights_tour_warnsdorff(n)
    if board:
        print_board(board)
    else:
        print("No solution found")

    # Larger board
    n = 8
    print(f"\n{n}x{n} Board (Warnsdorff):")
    board = knights_tour_warnsdorff(n)
    if board:
        print_board(board)
