# The Knight's Tour Problem

## Problem Statement

Given an N x N chessboard, find a path for a knight to visit every square exactly once.

### Knight's Movement
```
    . 1 . 2 .
    3 . . . 4
    . . K . .
    5 . . . 6
    . 7 . 8 .
```

## Why Backtracking Works Here

1. **8 Possible Moves**: At each position, knight has up to 8 moves
2. **Constraint**: Can't revisit squares
3. **Goal**: Visit all N^2 squares
4. **Systematic Search**: Try all moves, backtrack on dead ends

## Recursion Tree Diagram

```
                    Start (0,0)
                   /    |    \   ...
              Move1  Move2  Move3  (8 possible)
               |       |       |
            (2,1)   (1,2)    ...
           / | \ ...
         Try 8 moves from (2,1)
               |
            ...
               |
         All squares visited?
           YES -> SOLUTION
           NO  -> Continue/Backtrack
```

## Code Template

```python
def knights_tour(n):
    board = [[-1] * n for _ in range(n)]
    
    # 8 possible moves
    moves = [(2,1), (1,2), (-1,2), (-2,1),
             (-2,-1), (-1,-2), (1,-2), (2,-1)]
    
    def is_valid(x, y):
        return 0 <= x < n and 0 <= y < n and board[x][y] == -1
    
    def solve(x, y, move_count):
        # BASE CASE
        if move_count == n * n:
            return True
        
        # Try all 8 moves
        for dx, dy in moves:
            nx, ny = x + dx, y + dy
            if is_valid(nx, ny):
                board[nx][ny] = move_count  # DO
                if solve(nx, ny, move_count + 1):  # RECURSE
                    return True
                board[nx][ny] = -1  # UNDO
        
        return False
    
    board[0][0] = 0
    return solve(0, 0, 1)
```

## Time & Space Complexity
- **Time**: O(8^(N^2)) worst case
- **Space**: O(N^2) for board

## Warnsdorff's Heuristic
Move to the square with fewest onward moves (greedy optimization).
