# Longest Possible Route in a Matrix with Hurdles

## Problem Statement

Given an MxN matrix with hurdles (blocked cells), find the longest path from source to destination. Can only move right or down.

### Example
```
Matrix:
1 1 1 1 1
1 0 1 1 1
1 1 1 0 1
0 0 0 0 1
1 1 1 1 1

Source: (0,0), Dest: (4,4)
Find longest path avoiding 0s.
```

## Why Backtracking Works Here

1. **Multiple Paths**: Many ways to reach destination
2. **Hurdle Constraint**: Can't step on blocked cells
3. **Maximization**: Find path with most cells

## Recursion Tree

```
                (0,0)
               /     \
         right(0,1)  down(1,0)
            /  \        /  \
        right down   right down
           |    |       |    |
         ...  ...     ...  ...
            |
    Reach dest? Track max length
```

## Code Template

```python
def longest_route(matrix, src, dest):
    rows, cols = len(matrix), len(matrix[0])
    max_length = [0]
    
    def backtrack(row, col, length, visited):
        # Reached destination
        if (row, col) == dest:
            max_length[0] = max(max_length[0], length)
            return
        
        # Try all 4 directions (or just right/down)
        directions = [(0,1), (1,0), (0,-1), (-1,0)]
        
        for dr, dc in directions:
            nr, nc = row + dr, col + dc
            if (0 <= nr < rows and 0 <= nc < cols and
                matrix[nr][nc] == 1 and (nr, nc) not in visited):
                
                visited.add((nr, nc))
                backtrack(nr, nc, length + 1, visited)
                visited.remove((nr, nc))  # Backtrack
    
    sr, sc = src
    if matrix[sr][sc] == 0:
        return -1
    
    visited = {src}
    backtrack(sr, sc, 0, visited)
    
    return max_length[0] if max_length[0] > 0 else -1
```

## Time & Space Complexity
- **Time**: O(4^(M*N)) worst case
- **Space**: O(M*N) for visited
