"""
Longest Route in Matrix with Hurdles - Backtracking
====================================================

Time: O(4^(M*N)), Space: O(M*N)
"""

from typing import List, Tuple


def longest_route(matrix: List[List[int]],
                  src: Tuple[int, int],
                  dest: Tuple[int, int]) -> int:
    """
    Find longest path from src to dest avoiding hurdles (0s).

    Recursion Tree:
            (r,c)
           /  |  \  \
         R   D   L   U
         |
       continue to dest
       track max length
    """
    if not matrix:
        return -1

    rows, cols = len(matrix), len(matrix[0])
    sr, sc = src
    dr, dc = dest

    if matrix[sr][sc] == 0 or matrix[dr][dc] == 0:
        return -1

    max_length = [0]
    directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]

    def backtrack(row: int, col: int, length: int, visited: set) -> None:
        if (row, col) == dest:
            max_length[0] = max(max_length[0], length)
            return

        for d_row, d_col in directions:
            nr, nc = row + d_row, col + d_col
            if (0 <= nr < rows and 0 <= nc < cols and
                matrix[nr][nc] == 1 and (nr, nc) not in visited):

                visited.add((nr, nc))
                backtrack(nr, nc, length + 1, visited)
                visited.remove((nr, nc))

    visited = {src}
    backtrack(sr, sc, 0, visited)

    return max_length[0] if max_length[0] > 0 else -1


def longest_route_with_path(matrix: List[List[int]],
                            src: Tuple[int, int],
                            dest: Tuple[int, int]) -> Tuple[int, List[Tuple[int, int]]]:
    """Return both length and actual path."""
    if not matrix:
        return -1, []

    rows, cols = len(matrix), len(matrix[0])
    best_path = [[]]
    directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]

    def backtrack(row, col, path, visited):
        if (row, col) == dest:
            if len(path) > len(best_path[0]):
                best_path[0] = path[:]
            return

        for dr, dc in directions:
            nr, nc = row + dr, col + dc
            if (0 <= nr < rows and 0 <= nc < cols and
                matrix[nr][nc] == 1 and (nr, nc) not in visited):
                visited.add((nr, nc))
                path.append((nr, nc))
                backtrack(nr, nc, path, visited)
                path.pop()
                visited.remove((nr, nc))

    if matrix[src[0]][src[1]] == 0:
        return -1, []

    visited = {src}
    backtrack(src[0], src[1], [src], visited)

    if best_path[0]:
        return len(best_path[0]) - 1, best_path[0]
    return -1, []


# ============================================================================
# TEST CASES
# ============================================================================

if __name__ == "__main__":
    print("LONGEST ROUTE IN MATRIX")
    print("=" * 40)

    matrix = [
        [1, 1, 1, 1, 1],
        [1, 0, 1, 1, 1],
        [1, 1, 1, 0, 1],
        [0, 0, 0, 0, 1],
        [1, 1, 1, 1, 1]
    ]

    print("Matrix (0 = hurdle):")
    for row in matrix:
        print(row)

    src, dest = (0, 0), (4, 4)
    length, path = longest_route_with_path(matrix, src, dest)
    print(f"\nSource: {src}, Destination: {dest}")
    print(f"Longest path length: {length}")
    print(f"Path: {path}")
