"""
Sort a K-Sorted Doubly Linked List [Very Important]
===================================================

Problem: Sort a DLL where each node is at most K positions away
         from its target sorted position.

Example:
    Input:  3 <-> 6 <-> 2 <-> 12 <-> 56 <-> 8, K = 2
    Output: 2 <-> 3 <-> 6 <-> 8 <-> 12 <-> 56
"""

import heapq


class DLLNode:
    def __init__(self, val=0, prev=None, next=None):
        self.val = val
        self.prev = prev
        self.next = next

    def __lt__(self, other):
        return self.val < other.val


def sort_k_sorted_dll(head: DLLNode, k: int) -> DLLNode:
    """
    Sort K-sorted DLL using min-heap.

    Algorithm:
    1. Create min-heap with first K+1 elements
    2. Extract min, add to result, add next element
    3. Continue until heap is empty

    Time: O(n log K)
    Space: O(K)
    """
    if head is None or k == 0:
        return head

    # Min-heap (Python's heapq is min-heap by default)
    heap = []

    # Add first K+1 nodes to heap
    current = head
    for _ in range(k + 1):
        if current is None:
            break
        heapq.heappush(heap, current)
        current = current.next

    # New head for sorted list
    new_head = None
    new_tail = None

    # Process remaining nodes
    while heap:
        # Extract minimum
        min_node = heapq.heappop(heap)

        # Add to result list
        if new_head is None:
            new_head = min_node
            new_tail = min_node
            min_node.prev = None
        else:
            new_tail.next = min_node
            min_node.prev = new_tail
            new_tail = min_node

        # Add next element to heap
        if current:
            heapq.heappush(heap, current)
            current = current.next

    # Terminate the list
    if new_tail:
        new_tail.next = None

    return new_head


def sort_k_sorted_dll_values(head: DLLNode, k: int) -> DLLNode:
    """
    Alternative: Using values instead of nodes in heap.
    Simpler but creates new nodes.
    """
    if head is None:
        return head

    # Collect first K+1 values
    heap = []
    current = head
    for _ in range(k + 1):
        if current is None:
            break
        heapq.heappush(heap, current.val)
        current = current.next

    # Build sorted list
    new_head = None
    new_tail = None

    while heap:
        min_val = heapq.heappop(heap)

        new_node = DLLNode(min_val)
        if new_head is None:
            new_head = new_node
            new_tail = new_node
        else:
            new_tail.next = new_node
            new_node.prev = new_tail
            new_tail = new_node

        if current:
            heapq.heappush(heap, current.val)
            current = current.next

    return new_head


# Helper functions
def create_dll(values):
    if not values:
        return None
    head = DLLNode(values[0])
    curr = head
    for val in values[1:]:
        node = DLLNode(val, prev=curr)
        curr.next = node
        curr = node
    return head


def dll_to_list(head):
    result = []
    while head:
        result.append(head.val)
        head = head.next
    return result


def test_sort_k_sorted():
    print("=" * 50)
    print("SORT K-SORTED DLL - TEST CASES")
    print("=" * 50)

    # Test 1
    head = create_dll([3, 6, 2, 12, 56, 8])
    print(f"\nOriginal: {dll_to_list(head)}, K=2")
    head = sort_k_sorted_dll(head, 2)
    print(f"Sorted:   {dll_to_list(head)}")
    assert dll_to_list(head) == [2, 3, 6, 8, 12, 56]

    # Test 2
    head = create_dll([2, 6, 3, 12, 56, 8])
    print(f"\nOriginal: {dll_to_list(head)}, K=2")
    head = sort_k_sorted_dll(head, 2)
    print(f"Sorted:   {dll_to_list(head)}")

    # Test 3: Already sorted
    head = create_dll([1, 2, 3, 4, 5])
    print(f"\nOriginal: {dll_to_list(head)}, K=0")
    head = sort_k_sorted_dll(head, 0)
    print(f"Sorted:   {dll_to_list(head)}")
    assert dll_to_list(head) == [1, 2, 3, 4, 5]

    print("\nAll tests passed!")


if __name__ == "__main__":
    test_sort_k_sorted()
