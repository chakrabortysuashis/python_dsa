# Sort a K-Sorted Doubly Linked List [Very Important]

## Problem Statement

Given a doubly linked list where each node is at most K positions away from its target position, sort the list efficiently.

**Example:**
```
Input:  3 <-> 6 <-> 2 <-> 12 <-> 56 <-> 8, K = 2
Output: 2 <-> 3 <-> 6 <-> 8 <-> 12 <-> 56
```

---

## Intuition

### What is K-Sorted?

```
K-sorted means each element is at most K positions away from its sorted position.

Example with K=2:
Sorted:    2   3   6   8   12   56
Position:  0   1   2   3    4    5

K-sorted:  3   6   2   12   56   8
- 2 is at pos 2, should be at 0 (diff = 2, <= K)
- 3 is at pos 0, should be at 1 (diff = 1, <= K)
- etc.
```

### Key Insight: Use Min-Heap

```
Since elements are at most K away:
1. The minimum element is within first K+1 elements
2. Use a min-heap of size K+1
3. Extract minimum, add to result, add next element to heap

This gives O(n log K) instead of O(n log n)!
```

---

## Algorithm

```
1. Create a min-heap
2. Insert first K+1 elements into heap
3. For remaining elements:
   a. Extract min from heap -> add to sorted list
   b. Insert next element into heap
4. Extract remaining elements from heap
```

---

## Visual Walkthrough

```
Input: 3 <-> 6 <-> 2 <-> 12 <-> 56 <-> 8, K = 2

Step 1: Insert first K+1 = 3 elements into heap
        Heap: [2, 3, 6] (min-heap, 2 at top)
        Remaining: 12 <-> 56 <-> 8

Step 2: Extract min (2), add 12
        Result: 2
        Heap: [3, 6, 12]

Step 3: Extract min (3), add 56
        Result: 2 <-> 3
        Heap: [6, 12, 56]

Step 4: Extract min (6), add 8
        Result: 2 <-> 3 <-> 6
        Heap: [8, 12, 56]

Step 5: No more elements to add, extract remaining
        Extract 8:  Result: 2 <-> 3 <-> 6 <-> 8
        Extract 12: Result: 2 <-> 3 <-> 6 <-> 8 <-> 12
        Extract 56: Result: 2 <-> 3 <-> 6 <-> 8 <-> 12 <-> 56

Final: 2 <-> 3 <-> 6 <-> 8 <-> 12 <-> 56
```

---

## Complexity Analysis

| Aspect | Complexity |
|--------|------------|
| Time | O(n log K) |
| Space | O(K) |

```
Time: O(n log K)
- n elements to process
- Each heap operation: O(log K)
- Much better than O(n log n) when K << n

Space: O(K)
- Heap contains at most K+1 elements
```

---

## Why This Works

```
Key insight: In K-sorted list, the minimum element
is guaranteed to be in the first K+1 elements.

Proof:
- If min element should be at position 0
- It can be at most K positions away
- So it must be within positions 0 to K (K+1 elements)

Similarly, after extracting min, the next minimum
is in the next K+1 elements (already in heap + 1 new)
```

---

## Edge Cases

```
1. K = 0: List is already sorted
2. K >= n-1: Regular sorting needed
3. Empty list: Return empty
4. Single element: Return as is
```

---

## Key Takeaways

1. **Min-heap of size K+1** is the key
2. **O(n log K)** is much better than O(n log n) for small K
3. Works because **minimum is within first K+1 elements**
4. Common interview problem - understand the invariant!
