# Add Two Numbers Represented by Linked Lists

## Problem Statement

Given two numbers represented by linked lists (each node = one digit), return their sum as a linked list.

**Example:**
```
Input:  
  List1: 2 -> 4 -> 3 (represents 342)
  List2: 5 -> 6 -> 4 (represents 465)

Output: 7 -> 0 -> 8 (represents 807)
Explanation: 342 + 465 = 807
```

---

## Variations

### Variation 1: Digits in Reverse Order (LeetCode style)
- Least significant digit first
- Easy: Just traverse and add

### Variation 2: Digits in Normal Order
- Most significant digit first
- Need to reverse or use stack

---

## Approach: Reverse Order (Common)

### Algorithm

```
1. Traverse both lists simultaneously
2. Add corresponding digits + carry
3. Create new node with sum % 10
4. Update carry = sum / 10
5. Handle different lengths
6. Handle final carry
```

### Visual Walkthrough

```
List1: 2 -> 4 -> 3   (342)
List2: 5 -> 6 -> 4   (465)

Step 1: 2 + 5 = 7, carry = 0
Result: 7

Step 2: 4 + 6 = 10, carry = 1
Result: 7 -> 0

Step 3: 3 + 4 + 1(carry) = 8, carry = 0
Result: 7 -> 0 -> 8

Final: 7 -> 0 -> 8 (807)
```

---

## Handling Different Lengths

```
List1: 9 -> 9 -> 9 -> 9   (9999)
List2: 9 -> 9             (99)

Step 1: 9 + 9 = 18 -> 8, carry = 1
Step 2: 9 + 9 + 1 = 19 -> 9, carry = 1
Step 3: 9 + 0 + 1 = 10 -> 0, carry = 1
Step 4: 9 + 0 + 1 = 10 -> 0, carry = 1
Step 5: 0 + 0 + 1 = 1 -> 1, carry = 0

Result: 8 -> 9 -> 0 -> 0 -> 1 (10098)
```

---

## Edge Cases

1. **Different lengths:** Pad with 0
2. **Final carry:** Add extra node
3. **Single digit each:** Simple addition
4. **One list empty:** Return other list

---

## Complexity

- **Time:** O(max(m, n)) - traverse longer list
- **Space:** O(max(m, n)) - result list
