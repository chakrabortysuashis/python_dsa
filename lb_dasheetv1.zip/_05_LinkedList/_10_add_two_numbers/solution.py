"""
Add Two Numbers Represented by Linked Lists
============================================

Problem: Given two numbers represented by linked lists, return their sum
         as a linked list. Digits are stored in reverse order.

Example:
    Input:  2 -> 4 -> 3 (342)
            5 -> 6 -> 4 (465)
    Output: 7 -> 0 -> 8 (807)
"""


class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next


def add_two_numbers(l1: ListNode, l2: ListNode) -> ListNode:
    """
    Add two numbers represented as linked lists (reverse order).

    Algorithm:
    1. Traverse both lists simultaneously
    2. Add corresponding digits + carry
    3. Create result node with sum % 10
    4. Update carry = sum // 10
    5. Handle remaining nodes and final carry

    Time: O(max(m, n))
    Space: O(max(m, n))
    """
    dummy = ListNode(0)  # Dummy head for result
    current = dummy
    carry = 0

    # Process both lists
    while l1 or l2 or carry:
        # Get values (0 if list exhausted)
        val1 = l1.val if l1 else 0
        val2 = l2.val if l2 else 0

        # Calculate sum and carry
        total = val1 + val2 + carry
        carry = total // 10
        digit = total % 10

        # Create new node
        current.next = ListNode(digit)
        current = current.next

        # Move to next nodes
        l1 = l1.next if l1 else None
        l2 = l2.next if l2 else None

    return dummy.next


def add_two_numbers_forward(l1: ListNode, l2: ListNode) -> ListNode:
    """
    Add two numbers when digits are in forward order (MSB first).

    Approach: Reverse both, add, reverse result.
    """
    def reverse(head):
        prev = None
        while head:
            next_node = head.next
            head.next = prev
            prev = head
            head = next_node
        return prev

    # Reverse both lists
    l1 = reverse(l1)
    l2 = reverse(l2)

    # Add them (now in reverse order)
    result = add_two_numbers(l1, l2)

    # Reverse result back
    return reverse(result)


# =============================================================================
# HELPER FUNCTIONS AND TESTS
# =============================================================================

def create_linked_list(values):
    if not values:
        return None
    head = ListNode(values[0])
    curr = head
    for val in values[1:]:
        curr.next = ListNode(val)
        curr = curr.next
    return head


def linked_list_to_list(head):
    result = []
    while head:
        result.append(head.val)
        head = head.next
    return result


def test_add_two_numbers():
    print("=" * 60)
    print("ADD TWO NUMBERS - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal addition
    print("\n--- Test Case 1: 342 + 465 = 807 ---")
    l1 = create_linked_list([2, 4, 3])  # 342
    l2 = create_linked_list([5, 6, 4])  # 465
    result = add_two_numbers(l1, l2)
    print(f"Result: {linked_list_to_list(result)}")
    assert linked_list_to_list(result) == [7, 0, 8]
    print("Assertion passed!")

    # Test Case 2: Different lengths
    print("\n--- Test Case 2: 9999 + 99 = 10098 ---")
    l1 = create_linked_list([9, 9, 9, 9])  # 9999
    l2 = create_linked_list([9, 9])         # 99
    result = add_two_numbers(l1, l2)
    print(f"Result: {linked_list_to_list(result)}")
    assert linked_list_to_list(result) == [8, 9, 0, 0, 1]
    print("Assertion passed!")

    # Test Case 3: Single digits
    print("\n--- Test Case 3: 5 + 7 = 12 ---")
    l1 = create_linked_list([5])
    l2 = create_linked_list([7])
    result = add_two_numbers(l1, l2)
    print(f"Result: {linked_list_to_list(result)}")
    assert linked_list_to_list(result) == [2, 1]
    print("Assertion passed!")

    # Test Case 4: Zero
    print("\n--- Test Case 4: 0 + 0 = 0 ---")
    l1 = create_linked_list([0])
    l2 = create_linked_list([0])
    result = add_two_numbers(l1, l2)
    print(f"Result: {linked_list_to_list(result)}")
    assert linked_list_to_list(result) == [0]
    print("Assertion passed!")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


if __name__ == "__main__":
    test_add_two_numbers()
