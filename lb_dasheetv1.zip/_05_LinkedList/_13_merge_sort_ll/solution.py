"""
Merge Sort for Linked List [Very Important]
============================================

Problem: Sort a linked list using merge sort algorithm.

Example:
    Input:  4 -> 2 -> 1 -> 3 -> NULL
    Output: 1 -> 2 -> 3 -> 4 -> NULL

Why Merge Sort for Linked Lists?
- No random access needed (only sequential traversal)
- No extra space for merging (can relink nodes)
- O(n log n) time complexity
- Stable sort
"""


class ListNode:
    """Definition for singly-linked list node."""
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

    def __repr__(self):
        return f"ListNode({self.val})"


# =============================================================================
# MERGE SORT IMPLEMENTATION
# =============================================================================

def merge_sort(head: ListNode) -> ListNode:
    """
    Sort linked list using merge sort.

    Algorithm:
    1. Base case: if list is empty or has one node, return
    2. Find the middle of the list using slow-fast pointers
    3. Split the list into two halves
    4. Recursively sort both halves
    5. Merge the sorted halves

    Time Complexity: O(n log n)
    Space Complexity: O(log n) for recursion stack
    """
    # Base case: empty list or single node
    if head is None or head.next is None:
        return head

    # Step 1: Find middle and split
    # Use slow-fast pointer technique
    middle = get_middle(head)
    next_to_middle = middle.next

    # Split the list into two halves
    middle.next = None  # Terminate first half

    # Step 2: Recursively sort both halves
    left = merge_sort(head)
    right = merge_sort(next_to_middle)

    # Step 3: Merge sorted halves
    sorted_list = merge(left, right)

    return sorted_list


def get_middle(head: ListNode) -> ListNode:
    """
    Find the middle node of linked list using slow-fast pointers.

    For even length list, returns the node before the second half.
    This is important for proper splitting.

    Visual:
    [1] -> [2] -> [3] -> [4] -> NULL
     s,f

    [1] -> [2] -> [3] -> [4] -> NULL
           s      f

    [1] -> [2] -> [3] -> [4] -> NULL
           s             f(at NULL or last)

    Returns node 2 (middle for splitting)
    """
    if head is None:
        return head

    slow = head
    fast = head

    # Move fast 2 steps, slow 1 step
    # Stop when fast reaches end or second-to-last node
    while fast.next is not None and fast.next.next is not None:
        slow = slow.next
        fast = fast.next.next

    return slow


def merge(left: ListNode, right: ListNode) -> ListNode:
    """
    Merge two sorted linked lists into one sorted list.

    Algorithm:
    1. Use a dummy node to simplify head handling
    2. Compare nodes from both lists
    3. Attach smaller node to result
    4. Move the pointer forward in that list
    5. Attach any remaining nodes

    Visual:
    Left:  [1] -> [3] -> NULL
    Right: [2] -> [4] -> NULL

    Compare 1 vs 2: pick 1 -> Result: [1]
    Compare 3 vs 2: pick 2 -> Result: [1] -> [2]
    Compare 3 vs 4: pick 3 -> Result: [1] -> [2] -> [3]
    Right remains: attach 4 -> Result: [1] -> [2] -> [3] -> [4]

    Time: O(n + m) where n, m are lengths of lists
    Space: O(1) - only rearranging pointers
    """
    # Dummy node to simplify handling of head
    dummy = ListNode(0)
    tail = dummy

    # Compare and merge while both lists have nodes
    while left is not None and right is not None:
        if left.val <= right.val:
            tail.next = left
            left = left.next
        else:
            tail.next = right
            right = right.next
        tail = tail.next

    # Attach remaining nodes (one list might not be empty)
    if left is not None:
        tail.next = left
    else:
        tail.next = right

    return dummy.next


# =============================================================================
# ITERATIVE MERGE SORT (Bottom-Up)
# =============================================================================

def merge_sort_iterative(head: ListNode) -> ListNode:
    """
    Bottom-up merge sort without recursion.

    Algorithm:
    1. Start with sublists of size 1
    2. Merge adjacent sublists
    3. Double the sublist size
    4. Repeat until entire list is sorted

    Advantage: O(1) space (no recursion stack)

    Visual for [4, 2, 1, 3]:
    Size 1: Merge [4],[2] -> [2,4]  Merge [1],[3] -> [1,3]
    Size 2: Merge [2,4],[1,3] -> [1,2,3,4]
    Done!
    """
    if head is None or head.next is None:
        return head

    # Count total length
    length = 0
    current = head
    while current:
        length += 1
        current = current.next

    # Dummy node for easier head handling
    dummy = ListNode(0)
    dummy.next = head

    # Start with sublists of size 1, double each iteration
    size = 1
    while size < length:
        tail = dummy
        current = dummy.next

        while current:
            # Get left sublist of 'size' nodes
            left = current
            right = split(left, size)
            current = split(right, size)

            # Merge left and right, attach to tail
            merged = merge(left, right)
            tail.next = merged

            # Move tail to end of merged list
            while tail.next:
                tail = tail.next

        size *= 2

    return dummy.next


def split(head: ListNode, n: int) -> ListNode:
    """
    Split first n nodes from list, return head of remaining list.
    """
    if head is None:
        return None

    # Move n-1 steps (or until end)
    for _ in range(n - 1):
        if head.next is None:
            break
        head = head.next

    # Save and cut
    remaining = head.next
    head.next = None

    return remaining


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def create_linked_list(values: list) -> ListNode:
    """Create a linked list from a list of values."""
    if not values:
        return None

    head = ListNode(values[0])
    current = head

    for val in values[1:]:
        current.next = ListNode(val)
        current = current.next

    return head


def linked_list_to_list(head: ListNode) -> list:
    """Convert linked list to Python list."""
    result = []
    current = head

    while current:
        result.append(current.val)
        current = current.next

    return result


def print_linked_list(head: ListNode) -> str:
    """Print linked list in readable format."""
    values = linked_list_to_list(head)
    return " -> ".join(map(str, values)) + " -> NULL"


# =============================================================================
# TEST CASES
# =============================================================================

def test_merge_sort():
    """Test merge sort implementations."""
    print("=" * 60)
    print("MERGE SORT FOR LINKED LIST - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal unsorted list
    print("\n--- Test Case 1: [4, 2, 1, 3] ---")
    head = create_linked_list([4, 2, 1, 3])
    print(f"Original: {print_linked_list(head)}")
    sorted_head = merge_sort(head)
    print(f"Sorted:   {print_linked_list(sorted_head)}")
    assert linked_list_to_list(sorted_head) == [1, 2, 3, 4]
    print("Passed!")

    # Test Case 2: Already sorted
    print("\n--- Test Case 2: [1, 2, 3, 4, 5] (already sorted) ---")
    head = create_linked_list([1, 2, 3, 4, 5])
    print(f"Original: {print_linked_list(head)}")
    sorted_head = merge_sort(head)
    print(f"Sorted:   {print_linked_list(sorted_head)}")
    assert linked_list_to_list(sorted_head) == [1, 2, 3, 4, 5]
    print("Passed!")

    # Test Case 3: Reverse sorted
    print("\n--- Test Case 3: [5, 4, 3, 2, 1] (reverse sorted) ---")
    head = create_linked_list([5, 4, 3, 2, 1])
    print(f"Original: {print_linked_list(head)}")
    sorted_head = merge_sort(head)
    print(f"Sorted:   {print_linked_list(sorted_head)}")
    assert linked_list_to_list(sorted_head) == [1, 2, 3, 4, 5]
    print("Passed!")

    # Test Case 4: With duplicates
    print("\n--- Test Case 4: [3, 1, 2, 1, 3] (with duplicates) ---")
    head = create_linked_list([3, 1, 2, 1, 3])
    print(f"Original: {print_linked_list(head)}")
    sorted_head = merge_sort(head)
    print(f"Sorted:   {print_linked_list(sorted_head)}")
    assert linked_list_to_list(sorted_head) == [1, 1, 2, 3, 3]
    print("Passed!")

    # Test Case 5: Single node
    print("\n--- Test Case 5: [1] (single node) ---")
    head = create_linked_list([1])
    print(f"Original: {print_linked_list(head)}")
    sorted_head = merge_sort(head)
    print(f"Sorted:   {print_linked_list(sorted_head)}")
    assert linked_list_to_list(sorted_head) == [1]
    print("Passed!")

    # Test Case 6: Empty list
    print("\n--- Test Case 6: Empty list ---")
    head = None
    sorted_head = merge_sort(head)
    print(f"Original: NULL")
    print(f"Sorted:   NULL")
    assert sorted_head is None
    print("Passed!")

    # Test Case 7: Two nodes
    print("\n--- Test Case 7: [2, 1] (two nodes) ---")
    head = create_linked_list([2, 1])
    print(f"Original: {print_linked_list(head)}")
    sorted_head = merge_sort(head)
    print(f"Sorted:   {print_linked_list(sorted_head)}")
    assert linked_list_to_list(sorted_head) == [1, 2]
    print("Passed!")

    # Test iterative version
    print("\n--- Test Case 8: Iterative Merge Sort [4, 2, 1, 3] ---")
    head = create_linked_list([4, 2, 1, 3])
    print(f"Original: {print_linked_list(head)}")
    sorted_head = merge_sort_iterative(head)
    print(f"Sorted:   {print_linked_list(sorted_head)}")
    assert linked_list_to_list(sorted_head) == [1, 2, 3, 4]
    print("Passed!")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_step_by_step():
    """Demonstrate merge sort step by step."""
    print("\n" + "=" * 60)
    print("STEP-BY-STEP MERGE SORT DEMONSTRATION")
    print("=" * 60)

    print("\nInput: [4, 2, 1, 3]")
    print("\n--- DIVIDE PHASE ---")
    print("Level 0: [4] -> [2] -> [1] -> [3]")
    print("         Split at middle")
    print("         Left:  [4] -> [2]")
    print("         Right: [1] -> [3]")
    print()
    print("Level 1 (Left branch): [4] -> [2]")
    print("         Split at middle")
    print("         Left:  [4]")
    print("         Right: [2]")
    print()
    print("Level 1 (Right branch): [1] -> [3]")
    print("         Split at middle")
    print("         Left:  [1]")
    print("         Right: [3]")
    print()
    print("Level 2: All single nodes (base cases)")

    print("\n--- MERGE PHASE ---")
    print("Merge [4] and [2]:")
    print("  Compare 4 vs 2: pick 2")
    print("  Remaining: [4]")
    print("  Result: [2] -> [4]")
    print()
    print("Merge [1] and [3]:")
    print("  Compare 1 vs 3: pick 1")
    print("  Remaining: [3]")
    print("  Result: [1] -> [3]")
    print()
    print("Merge [2, 4] and [1, 3]:")
    print("  Compare 2 vs 1: pick 1 -> [1]")
    print("  Compare 2 vs 3: pick 2 -> [1] -> [2]")
    print("  Compare 4 vs 3: pick 3 -> [1] -> [2] -> [3]")
    print("  Remaining: [4]       -> [1] -> [2] -> [3] -> [4]")
    print()
    print("Final Result: [1] -> [2] -> [3] -> [4] -> NULL")


if __name__ == "__main__":
    test_merge_sort()
    demonstrate_step_by_step()
