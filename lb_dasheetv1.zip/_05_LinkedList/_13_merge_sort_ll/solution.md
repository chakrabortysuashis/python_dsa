# Merge Sort for Linked List [Very Important]

## Problem Statement

Sort a linked list using merge sort algorithm.

**Example:**
```
Input:  4 -> 2 -> 1 -> 3 -> NULL
Output: 1 -> 2 -> 3 -> 4 -> NULL
```

---

## Intuition

### Why Merge Sort for Linked Lists?

Merge Sort is **ideal** for linked lists because:
1. **No random access needed** - We only traverse sequentially
2. **No extra space for merging** - We can change pointers instead of copying elements
3. **Stable sort** - Maintains relative order of equal elements

```
Why NOT QuickSort for LL?
- QuickSort needs random access for efficient partitioning
- Linked lists don't support O(1) random access
- Picking pivot becomes O(n) operation

Why Merge Sort works well:
- Only needs sequential access
- Finding middle: O(n) with slow/fast pointers
- Merging: O(n) by relinking nodes
```

### Key Insight

Merge Sort has two main steps:
1. **Divide**: Split list into two halves (find middle)
2. **Conquer**: Recursively sort each half, then merge

```
Original:     [4] -> [2] -> [1] -> [3] -> NULL

Divide:       [4] -> [2]    |    [1] -> [3]
                    /   \            /   \
Divide:       [4]   [2]         [1]    [3]

Merge:        [2] -> [4]         [1] -> [3]

Merge:        [1] -> [2] -> [3] -> [4] -> NULL
```

---

## Algorithm

### Step 1: Find Middle (Slow-Fast Pointer)

```
Find middle using two pointers:
- slow moves 1 step
- fast moves 2 steps
When fast reaches end, slow is at middle

[4] -> [2] -> [1] -> [3] -> NULL
 s      
 f

[4] -> [2] -> [1] -> [3] -> NULL
        s      
               f

slow points to node before middle split point
```

### Step 2: Split the List

```
Before split:
[4] -> [2] -> [1] -> [3] -> NULL
        ^mid

After split:
Left:  [4] -> [2] -> NULL
Right: [1] -> [3] -> NULL
```

### Step 3: Recursively Sort Both Halves

### Step 4: Merge Two Sorted Lists

```
Merging [2] -> [4] and [1] -> [3]:

Compare 2 vs 1: Pick 1
Result: [1] ->

Compare 2 vs 3: Pick 2
Result: [1] -> [2] ->

Compare 4 vs 3: Pick 3
Result: [1] -> [2] -> [3] ->

Remaining: 4
Result: [1] -> [2] -> [3] -> [4] -> NULL
```

---

## Visual Walkthrough

### Complete Merge Sort Execution

```
                    [4] -> [2] -> [1] -> [3]
                            |
                     Find middle (slow-fast)
                            |
            +---------------+---------------+
            |                               |
      [4] -> [2]                      [1] -> [3]
            |                               |
      Find middle                     Find middle
            |                               |
      +-----+-----+                   +-----+-----+
      |           |                   |           |
     [4]        [2]                 [1]         [3]
      |           |                   |           |
   (base)     (base)              (base)      (base)
      |           |                   |           |
      +-----+-----+                   +-----+-----+
            |                               |
     Merge [4],[2]                   Merge [1],[3]
            |                               |
      [2] -> [4]                      [1] -> [3]
            |                               |
            +---------------+---------------+
                            |
                    Merge sorted halves
                            |
               [1] -> [2] -> [3] -> [4]
```

### Merge Process Detail

```
Merging Left: [2] -> [4] -> NULL
         Right: [1] -> [3] -> NULL

Step 1: Compare heads (2 vs 1)
        1 < 2, so pick 1
        Result: [1]
        Right: [3] -> NULL

Step 2: Compare heads (2 vs 3)
        2 < 3, so pick 2
        Result: [1] -> [2]
        Left: [4] -> NULL

Step 3: Compare heads (4 vs 3)
        3 < 4, so pick 3
        Result: [1] -> [2] -> [3]
        Right: NULL

Step 4: Right is empty, append remaining Left
        Result: [1] -> [2] -> [3] -> [4] -> NULL
```

---

## Dry Run

### Input: 4 -> 2 -> 1 -> 3

| Level | Action | Left Half | Right Half | Result |
|-------|--------|-----------|------------|--------|
| 0 | Split | 4->2 | 1->3 | - |
| 1 | Split left | 4 | 2 | - |
| 2 | Base case | - | - | 4, 2 |
| 1 | Merge | - | - | 2->4 |
| 1 | Split right | 1 | 3 | - |
| 2 | Base case | - | - | 1, 3 |
| 1 | Merge | - | - | 1->3 |
| 0 | Merge | 2->4 | 1->3 | 1->2->3->4 |

---

## Complexity Analysis

| Aspect | Complexity | Explanation |
|--------|------------|-------------|
| Time | O(n log n) | log n levels, O(n) work per level |
| Space | O(log n) | Recursion stack depth |

```
Time breakdown:
- Finding middle: O(n)
- Number of levels: O(log n)
- Merging at each level: O(n) total
- Total: O(n log n)

Space breakdown:
- No extra array needed (unlike array merge sort)
- Only recursion stack: O(log n)
```

---

## Edge Cases

```
1. Empty list:      NULL -> NULL
2. Single node:     [1] -> [1] (already sorted)
3. Two nodes:       [2]->[1] -> [1]->[2]
4. Already sorted:  [1]->[2]->[3] -> [1]->[2]->[3]
5. Reverse sorted:  [3]->[2]->[1] -> [1]->[2]->[3]
6. Duplicates:      [2]->[1]->[2] -> [1]->[2]->[2]
```

---

## Key Takeaways

1. **Merge Sort is preferred for Linked Lists** due to sequential access pattern
2. **Finding middle** uses the slow-fast pointer technique
3. **Merging is efficient** - just relinking nodes, no extra array
4. **Time: O(n log n)**, Space: O(log n) for recursion stack
5. **Stable sort** - maintains relative order of equal elements
