"""
Check if Linked List is Circular
================================

Problem: Given a linked list, check if it is circular (has a cycle).

Example:
    Circular:     1 -> 2 -> 3 -> 4 -> 2 (back to node 2)
    Non-circular: 1 -> 2 -> 3 -> 4 -> NULL
"""


class ListNode:
    """Definition for singly-linked list node."""
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

    def __repr__(self):
        return f"ListNode({self.val})"


# =============================================================================
# APPROACH 1: FLOYD'S CYCLE DETECTION (Optimal)
# =============================================================================

def has_cycle(head: ListNode) -> bool:
    """
    Detect cycle using Floyd's Tortoise and Hare algorithm.

    Algorithm:
    1. Use slow pointer (moves 1 step) and fast pointer (moves 2 steps)
    2. If they meet, there's a cycle
    3. If fast reaches NULL, no cycle

    Why it works:
    - If there's a cycle, fast will eventually catch up to slow
    - Like two runners on a track, faster one laps the slower one

    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    if head is None or head.next is None:
        return False

    slow = head
    fast = head

    # Move slow 1 step, fast 2 steps
    while fast is not None and fast.next is not None:
        slow = slow.next
        fast = fast.next.next

        # If they meet, there's a cycle
        if slow == fast:
            return True

    # fast reached NULL, no cycle
    return False


# =============================================================================
# APPROACH 2: HASH SET
# =============================================================================

def has_cycle_hashset(head: ListNode) -> bool:
    """
    Detect cycle using a hash set to track visited nodes.

    Algorithm:
    1. Traverse the list, adding each node to a set
    2. If we see a node we've visited before, there's a cycle
    3. If we reach NULL, no cycle

    Time Complexity: O(n)
    Space Complexity: O(n) for the hash set
    """
    visited = set()
    current = head

    while current is not None:
        # If we've seen this node before, cycle exists
        if current in visited:
            return True

        visited.add(current)
        current = current.next

    # Reached end of list, no cycle
    return False


# =============================================================================
# APPROACH 3: MARKING VISITED (Destructive)
# =============================================================================

def has_cycle_marking(head: ListNode) -> bool:
    """
    Detect cycle by marking visited nodes.

    WARNING: This modifies the list! Only use if list can be modified.

    Algorithm:
    1. Mark each visited node with a special value
    2. If we see a marked node, there's a cycle
    3. If we reach NULL, no cycle

    Time Complexity: O(n)
    Space Complexity: O(1) but modifies the list
    """
    VISITED_MARKER = float('inf')
    current = head

    while current is not None:
        # If marked, we've been here before
        if current.val == VISITED_MARKER:
            return True

        # Mark as visited
        current.val = VISITED_MARKER
        current = current.next

    return False


# =============================================================================
# ADDITIONAL: CHECK IF FULLY CIRCULAR (Head == Tail.next)
# =============================================================================

def is_fully_circular(head: ListNode) -> bool:
    """
    Check if the list is a complete circle (last node points to head).

    This is different from just having a cycle - specifically checks
    if the list forms a perfect ring back to the head.

    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    if head is None:
        return False

    current = head.next

    while current is not None:
        if current == head:
            return True
        current = current.next

    return False


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def create_linked_list(values: list) -> ListNode:
    """Create a linked list from a list of values."""
    if not values:
        return None

    head = ListNode(values[0])
    current = head

    for val in values[1:]:
        current.next = ListNode(val)
        current = current.next

    return head


def create_cycle(head: ListNode, position: int) -> ListNode:
    """
    Create a cycle in the list where the last node points to
    the node at 'position' (0-indexed).

    position = -1 means no cycle.
    """
    if head is None or position == -1:
        return head

    # Find the node at position
    cycle_start = head
    for _ in range(position):
        if cycle_start is None:
            return head
        cycle_start = cycle_start.next

    # Find the last node
    last = head
    while last.next is not None:
        last = last.next

    # Create cycle
    last.next = cycle_start

    return head


def linked_list_to_list(head: ListNode, max_nodes: int = 20) -> list:
    """
    Convert linked list to Python list.
    max_nodes prevents infinite loop if there's a cycle.
    """
    result = []
    current = head
    count = 0

    while current and count < max_nodes:
        result.append(current.val)
        current = current.next
        count += 1

    if count == max_nodes and current:
        result.append("...cycle detected")

    return result


# =============================================================================
# TEST CASES
# =============================================================================

def test_has_cycle():
    """Test cycle detection implementations."""
    print("=" * 60)
    print("CHECK CIRCULAR LINKED LIST - TEST CASES")
    print("=" * 60)

    # Test Case 1: List with cycle
    print("\n--- Test Case 1: [1,2,3,4,5] with cycle at position 2 ---")
    head = create_linked_list([1, 2, 3, 4, 5])
    create_cycle(head, 2)  # Last node points to node at index 2 (value 3)
    print(f"List: 1 -> 2 -> 3 -> 4 -> 5 -> (back to 3)")
    result = has_cycle(head)
    print(f"Has cycle (Floyd's): {result}")
    assert result == True
    print("Passed!")

    # Test Case 2: List without cycle
    print("\n--- Test Case 2: [1,2,3,4,5] without cycle ---")
    head = create_linked_list([1, 2, 3, 4, 5])
    print(f"List: 1 -> 2 -> 3 -> 4 -> 5 -> NULL")
    result = has_cycle(head)
    print(f"Has cycle (Floyd's): {result}")
    assert result == False
    print("Passed!")

    # Test Case 3: Fully circular (tail points to head)
    print("\n--- Test Case 3: Fully circular [1,2,3] -> back to 1 ---")
    head = create_linked_list([1, 2, 3])
    create_cycle(head, 0)  # Last node points to head
    print(f"List: 1 -> 2 -> 3 -> (back to 1)")
    result = has_cycle(head)
    print(f"Has cycle (Floyd's): {result}")
    assert result == True
    result2 = is_fully_circular(head)
    print(f"Is fully circular: {result2}")
    assert result2 == True
    print("Passed!")

    # Test Case 4: Single node with self-loop
    print("\n--- Test Case 4: Single node with self-loop ---")
    head = ListNode(1)
    head.next = head  # Points to itself
    print(f"List: 1 -> (back to 1)")
    result = has_cycle(head)
    print(f"Has cycle (Floyd's): {result}")
    assert result == True
    print("Passed!")

    # Test Case 5: Single node without cycle
    print("\n--- Test Case 5: Single node without cycle ---")
    head = ListNode(1)
    print(f"List: 1 -> NULL")
    result = has_cycle(head)
    print(f"Has cycle (Floyd's): {result}")
    assert result == False
    print("Passed!")

    # Test Case 6: Empty list
    print("\n--- Test Case 6: Empty list ---")
    head = None
    print(f"List: NULL")
    result = has_cycle(head)
    print(f"Has cycle (Floyd's): {result}")
    assert result == False
    print("Passed!")

    # Test Case 7: Two nodes with cycle
    print("\n--- Test Case 7: [1,2] with cycle ---")
    head = create_linked_list([1, 2])
    create_cycle(head, 0)
    print(f"List: 1 -> 2 -> (back to 1)")
    result = has_cycle(head)
    print(f"Has cycle (Floyd's): {result}")
    assert result == True
    print("Passed!")

    # Test Case 8: Hash set method
    print("\n--- Test Case 8: Hash set method [1,2,3,4] with cycle ---")
    head = create_linked_list([1, 2, 3, 4])
    create_cycle(head, 1)
    print(f"List: 1 -> 2 -> 3 -> 4 -> (back to 2)")
    result = has_cycle_hashset(head)
    print(f"Has cycle (Hash Set): {result}")
    assert result == True
    print("Passed!")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_floyd_algorithm():
    """Demonstrate Floyd's algorithm step by step."""
    print("\n" + "=" * 60)
    print("FLOYD'S ALGORITHM DEMONSTRATION")
    print("=" * 60)

    print("\nExample: List with cycle")
    print("1 -> 2 -> 3 -> 4 -> 5")
    print("          ^         |")
    print("          |_________|")
    print()
    print("Step 0: slow=1, fast=1 (both at head)")
    print("Step 1: slow=2, fast=3")
    print("Step 2: slow=3, fast=5")
    print("Step 3: slow=4, fast=4 (5->3->4)")
    print()
    print("slow == fast at value 4!")
    print("CYCLE DETECTED!")

    print("\n" + "-" * 40)
    print("\nExample: List without cycle")
    print("1 -> 2 -> 3 -> 4 -> NULL")
    print()
    print("Step 0: slow=1, fast=1")
    print("Step 1: slow=2, fast=3")
    print("Step 2: slow=3, fast=NULL (past end)")
    print()
    print("fast is NULL, NO CYCLE!")


if __name__ == "__main__":
    test_has_cycle()
    demonstrate_floyd_algorithm()
