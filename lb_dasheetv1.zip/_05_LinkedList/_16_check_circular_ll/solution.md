# Check if Linked List is Circular

## Problem Statement

Given a linked list, check if it is circular. A circular linked list is one where the last node points back to any node in the list (not necessarily the head).

**Example:**
```
Circular:
[1] -> [2] -> [3] -> [4] -> [5]
              ^               |
              |_______________|

Non-circular:
[1] -> [2] -> [3] -> [4] -> [5] -> NULL
```

---

## Intuition

### What makes a list circular?

```
A list is circular if:
- Following the next pointers, you eventually return to a previously visited node
- The list has NO end (no NULL pointer reachable)

Non-circular: has an endpoint (NULL)
Circular: traversal loops forever
```

### Approach 1: Hash Set

```
Store visited nodes in a set.
If we see a node twice, there's a cycle.
If we reach NULL, no cycle.

Time: O(n)
Space: O(n)
```

### Approach 2: Floyd's Cycle Detection (Optimal)

```
Use slow-fast pointers (Tortoise and Hare):
- Slow moves 1 step
- Fast moves 2 steps
- If they ever meet, there's a cycle
- If fast reaches NULL, no cycle

Why does this work?
If there's a cycle, fast will "lap" slow eventually.
Think of two runners on a circular track - the faster one will catch up.
```

---

## Algorithm

### Floyd's Cycle Detection

```
Visual of fast catching slow in a cycle:

[1] -> [2] -> [3] -> [4]
              ^       |
              |_______|

Start: slow=1, fast=1

Step 1: slow=2, fast=3
Step 2: slow=3, fast=3 (at 4, goes to 3)

slow == fast, CYCLE DETECTED!

Without cycle:
[1] -> [2] -> [3] -> NULL

Step 1: slow=2, fast=3
Step 2: fast.next is NULL, NO CYCLE
```

---

## Visual Walkthrough

### Case 1: Circular List

```
List with cycle at position 2 (0-indexed):
[1] -> [2] -> [3] -> [4] -> [5]
              ^               |
              |_______________|

Position: 0      1      2      3      4
                        ^cycle starts here

Initial:
slow = 1 (pos 0)
fast = 1 (pos 0)

Step 1:
slow = 2 (pos 1)
fast = 3 (pos 2)

Step 2:
slow = 3 (pos 2)
fast = 5 (pos 4)

Step 3:
slow = 4 (pos 3)
fast = 3 (pos 2) [5 -> 3, 3 -> 4, but we do 2 steps: 5->3->4]
Wait, let me redo: fast at 5 -> next is 3 -> next is 4
fast = 4 (pos 3)

slow == fast! CYCLE DETECTED!
```

### Case 2: Non-Circular List

```
[1] -> [2] -> [3] -> [4] -> NULL

Initial:
slow = 1 (pos 0)
fast = 1 (pos 0)

Step 1:
slow = 2 (pos 1)
fast = 3 (pos 2)

Step 2:
slow = 3 (pos 2)
fast = NULL (moved past 4)

fast is NULL, NO CYCLE!
```

---

## Dry Run

### Input: 1->2->3->4->5->3 (cycle back to node 3)

| Step | slow_pos | slow_val | fast_pos | fast_val | Meet? |
|------|----------|----------|----------|----------|-------|
| 0 | 0 | 1 | 0 | 1 | No |
| 1 | 1 | 2 | 2 | 3 | No |
| 2 | 2 | 3 | 4 | 5 | No |
| 3 | 3 | 4 | 2 | 3 | No |
| 4 | 4 | 5 | 4 | 5 | Yes! |

**Result: Cycle detected at step 4**

---

## Different Types of Circular

```
Type 1: Fully circular (tail points to head)
[1] -> [2] -> [3] -> [4]
 ^                    |
 |____________________|

Type 2: Partial cycle (tail points to middle)
[1] -> [2] -> [3] -> [4] -> [5]
              ^               |
              |_______________|

Type 3: Self-loop
[1] -> [2] -> [3]
              ^|
              ||
               
(node 3 points to itself)

All detected by Floyd's algorithm!
```

---

## Complexity Analysis

| Approach | Time | Space |
|----------|------|-------|
| Hash Set | O(n) | O(n) |
| Floyd's (slow-fast) | O(n) | O(1) |

```
Why Floyd's is O(n) time:

If there's a cycle:
- slow enters cycle after some steps
- fast is already in cycle
- fast catches slow within at most 'cycle_length' steps
- Total: O(n) steps

If no cycle:
- fast reaches NULL in n/2 steps
- Total: O(n) steps
```

---

## Edge Cases

```
1. Empty list:       NULL -> No cycle (return False)
2. Single node:      [1] -> NULL -> No cycle
3. Single node loop: [1] -+
                     ^    |
                     |____+  -> Cycle!
4. Two nodes loop:   [1] -> [2]
                     ^       |
                     |_______|  -> Cycle!
```

---

## Related Problems

1. **Find cycle start point** - Where does the cycle begin?
2. **Find cycle length** - How many nodes in the cycle?
3. **Remove cycle** - Delete the cycle-causing edge

---

## Key Takeaways

1. **Floyd's algorithm** is the optimal solution - O(1) space
2. If slow and fast **meet**, there's a cycle
3. If fast reaches **NULL**, no cycle
4. This technique is **foundation** for many linked list cycle problems
5. Also called **Tortoise and Hare** algorithm
