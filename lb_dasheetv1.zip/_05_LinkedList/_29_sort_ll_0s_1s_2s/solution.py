"""
Sort a Linked List of 0s, 1s, and 2s
====================================
"""


class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next


def sort_012_count(head: ListNode) -> ListNode:
    """
    Approach 1: Count and overwrite.
    Time: O(n), Space: O(1)
    """
    count = [0, 0, 0]  # counts for 0, 1, 2

    # Count occurrences
    curr = head
    while curr:
        count[curr.val] += 1
        curr = curr.next

    # Overwrite values
    curr = head
    for val in range(3):
        for _ in range(count[val]):
            curr.val = val
            curr = curr.next

    return head


def sort_012_lists(head: ListNode) -> ListNode:
    """
    Approach 2: Three separate lists, then concatenate.
    Time: O(n), Space: O(1)
    Preserves original nodes.
    """
    if head is None:
        return None

    # Dummy heads for three lists
    zero_head = ListNode(0)
    one_head = ListNode(0)
    two_head = ListNode(0)

    zero = zero_head
    one = one_head
    two = two_head

    # Distribute nodes
    curr = head
    while curr:
        if curr.val == 0:
            zero.next = curr
            zero = zero.next
        elif curr.val == 1:
            one.next = curr
            one = one.next
        else:
            two.next = curr
            two = two.next
        curr = curr.next

    # Concatenate lists
    # Connect zeros to ones (or twos if no ones)
    zero.next = one_head.next if one_head.next else two_head.next

    # Connect ones to twos
    one.next = two_head.next

    # Terminate the list
    two.next = None

    # Return head (skip dummy)
    return zero_head.next if zero_head.next else (one_head.next if one_head.next else two_head.next)


# Helper functions
def create_list(values):
    if not values:
        return None
    head = ListNode(values[0])
    curr = head
    for val in values[1:]:
        curr.next = ListNode(val)
        curr = curr.next
    return head


def list_to_array(head):
    result = []
    while head:
        result.append(head.val)
        head = head.next
    return result


def test_sort():
    print("SORT 0s, 1s, 2s - TESTS")

    # Test 1
    head = create_list([1, 1, 2, 0, 2, 0, 1])
    print(f"Input:  {list_to_array(head)}")
    head = sort_012_lists(head)
    print(f"Output: {list_to_array(head)}")
    assert list_to_array(head) == [0, 0, 1, 1, 1, 2, 2]

    # Test 2
    head = create_list([2, 2, 2, 0, 0, 0, 1, 1])
    head = sort_012_lists(head)
    print(f"Output: {list_to_array(head)}")
    assert list_to_array(head) == [0, 0, 0, 1, 1, 2, 2, 2]

    # Test 3: All same
    head = create_list([1, 1, 1])
    head = sort_012_lists(head)
    print(f"Output: {list_to_array(head)}")
    assert list_to_array(head) == [1, 1, 1]

    print("All tests passed!")


if __name__ == "__main__":
    test_sort()
