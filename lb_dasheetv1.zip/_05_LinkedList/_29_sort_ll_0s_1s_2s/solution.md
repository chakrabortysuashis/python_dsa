# Sort a Linked List of 0s, 1s, and 2s

## Problem Statement

Given a linked list containing only 0s, 1s, and 2s, sort the list.

**Example:**
```
Input:  1 -> 1 -> 2 -> 0 -> 2 -> 0 -> 1 -> NULL
Output: 0 -> 0 -> 1 -> 1 -> 1 -> 2 -> 2 -> NULL
```

---

## Approaches

### Approach 1: Count and Overwrite

```
1. Count 0s, 1s, and 2s
2. Overwrite list with counted values

Time: O(n), Space: O(1)
Simple but modifies data (may not be allowed)
```

### Approach 2: Three Separate Lists (Better)

```
1. Create three dummy heads for 0s, 1s, 2s
2. Traverse and append each node to appropriate list
3. Concatenate: 0s -> 1s -> 2s

Time: O(n), Space: O(1)
Maintains original nodes - just rearranges pointers
```

---

## Visual Walkthrough (Approach 2)

```
Input: 1 -> 1 -> 2 -> 0 -> 2 -> 0 -> 1

Create three lists:
zeros:  dummy0 ->
ones:   dummy1 ->
twos:   dummy2 ->

Process 1: ones list
Process 1: ones list
Process 2: twos list
Process 0: zeros list
Process 2: twos list
Process 0: zeros list
Process 1: ones list

After processing:
zeros: dummy0 -> 0 -> 0
ones:  dummy1 -> 1 -> 1 -> 1
twos:  dummy2 -> 2 -> 2

Concatenate:
0 -> 0 -> 1 -> 1 -> 1 -> 2 -> 2 -> NULL
```

---

## Complexity

| Approach | Time | Space |
|----------|------|-------|
| Count & Overwrite | O(n) | O(1) |
| Three Lists | O(n) | O(1) |

---

## Key Points

1. Three-list approach preserves node structure
2. Don't forget to set last node's next to NULL
3. Handle empty sublists (no 0s, no 1s, etc.)
