# Linked List - Complete Guide

## Table of Contents
1. [What is a Linked List?](#what-is-a-linked-list)
2. [Node Structure](#node-structure)
3. [Types of Linked Lists](#types-of-linked-lists)
4. [Linked List vs Array](#linked-list-vs-array)
5. [Basic Operations](#basic-operations)
6. [Time Complexity Analysis](#time-complexity-analysis)
7. [When to Use Linked Lists](#when-to-use-linked-lists)

---

## What is a Linked List?

A **Linked List** is a linear data structure where elements are stored in **nodes**. Unlike arrays, elements are **not stored in contiguous memory locations**. Instead, each node contains:
1. **Data** - The actual value stored
2. **Pointer(s)** - Reference to the next (and possibly previous) node

```
Visual Representation:
+------+------+    +------+------+    +------+------+
| Data | Next |--->| Data | Next |--->| Data | Next |--->NULL
+------+------+    +------+------+    +------+------+
   Node 1             Node 2             Node 3
```

### Key Concept: The Head Pointer
The **head** is a pointer that always points to the first node of the list. It's our entry point to access the entire list.

```
HEAD
  |
  v
+---+---+    +---+---+    +---+---+
| 1 | *-|--->| 2 | *-|--->| 3 | / |
+---+---+    +---+---+    +---+---+
```

---

## Node Structure

### Singly Linked List Node
```
+------------------+
|      NODE        |
+------------------+
|  data: value     |
|  next: pointer   |---> Points to next node
+------------------+
```

### Doubly Linked List Node
```
+----------------------+
|        NODE          |
+----------------------+
|  prev: pointer   <---|--- Points to previous node
|  data: value         |
|  next: pointer   ----|---> Points to next node
+----------------------+
```

---

## Types of Linked Lists

### 1. Singly Linked List
Each node points only to the **next** node. Traversal is **one-directional** (forward only).

```
HEAD
  |
  v
+---+---+    +---+---+    +---+---+    +---+---+
| A | *-|--->| B | *-|--->| C | *-|--->| D |NULL|
+---+---+    +---+---+    +---+---+    +---+---+
```

**Characteristics:**
- Simple structure, less memory per node
- Can only traverse forward
- No way to go back to previous node
- O(1) insertion at head, O(n) at tail (without tail pointer)

---

### 2. Doubly Linked List
Each node has pointers to **both** the next and previous nodes. Traversal is **bidirectional**.

```
NULL<---+---+---+---+<--->+---+---+---+<--->+---+---+---+--->NULL
        | A | * | * |     | B | * | * |     | C | * | * |
        +---+---+---+     +---+---+---+     +---+---+---+
             ^                                   ^
             |                                   |
           HEAD                                TAIL
```

**Detailed Node View:**
```
          prev  data  next           prev  data  next
         +----+-----+----+         +----+-----+----+
NULL <---| /  |  A  |  *-|-------->|  * |  B  |  / |---> NULL
         +----+-----+----+         +----+-----+----+
                          <--------|
```

**Characteristics:**
- More memory per node (extra pointer)
- Can traverse both forward and backward
- Easier deletion when node reference is given
- O(1) insertion/deletion at both ends (with head and tail pointers)

---

### 3. Circular Linked List
The **last node points back to the first node**, forming a circle.

#### Circular Singly Linked List:
```
HEAD
  |
  v
+---+---+    +---+---+    +---+---+
| A | *-|--->| B | *-|--->| C | *-|---+
+---+---+    +---+---+    +---+---+   |
  ^                                   |
  |___________________________________|
```

#### Circular Doubly Linked List:
```
        +----------------------------------------+
        |                                        |
        v                                        |
    +---+---+---+    +---+---+---+    +---+---+---+
<-->| A | * | * |<-->| B | * | * |<-->| C | * | * |<-->
    +---+---+---+    +---+---+---+    +---+---+---+
        ^                                    |
        |____________________________________|
```

**Characteristics:**
- No NULL at the end
- Useful for round-robin scheduling, circular buffers
- Any node can be a starting point
- Must be careful to avoid infinite loops

---

## Linked List vs Array

### Memory Layout Comparison

**Array (Contiguous Memory):**
```
Memory Address: 100   104   108   112   116
              +-----+-----+-----+-----+-----+
              |  1  |  2  |  3  |  4  |  5  |
              +-----+-----+-----+-----+-----+
```

**Linked List (Non-Contiguous Memory):**
```
Address 100        Address 250        Address 180
+---+------+       +---+------+       +---+------+
| 1 | 250  |------>| 2 | 180  |------>| 3 | NULL |
+---+------+       +---+------+       +---+------+
```

### Comparison Table

| Feature | Array | Linked List |
|---------|-------|-------------|
| **Memory Allocation** | Contiguous | Non-contiguous |
| **Size** | Fixed (static array) or resizable with copying | Dynamic, grows easily |
| **Memory Usage** | Only data | Data + pointer(s) |
| **Access Time** | O(1) - Direct indexing | O(n) - Must traverse |
| **Insert at Beginning** | O(n) - Shift all elements | O(1) - Just change head |
| **Insert at End** | O(1) amortized (dynamic array) | O(1) with tail pointer, O(n) without |
| **Insert in Middle** | O(n) - Shift elements | O(1) if position known, O(n) to find position |
| **Delete at Beginning** | O(n) - Shift all elements | O(1) - Just change head |
| **Delete at End** | O(1) | O(n) for singly linked, O(1) for doubly |
| **Delete in Middle** | O(n) - Shift elements | O(1) if node known, O(n) to find |
| **Cache Friendliness** | Excellent (contiguous) | Poor (scattered memory) |
| **Memory Overhead** | None | Extra pointer per node |

---

## Basic Operations

### 1. Traversal
Visit each node from head to end.

```
START at HEAD
     |
     v
+---+---+    +---+---+    +---+---+
| 1 | *-|--->| 2 | *-|--->| 3 |NULL|
+---+---+    +---+---+    +---+---+
  ^            ^            ^
  |            |            |
Visit 1    Visit 2      Visit 3     STOP (NULL reached)
```

### 2. Insertion at Beginning

**Step-by-step:**
```
Before: HEAD -> [1] -> [2] -> [3] -> NULL
Insert: [0]

Step 1: Create new node with data 0
        +---+---+
        | 0 |   |
        +---+---+

Step 2: Point new node's next to current HEAD
        +---+---+    +---+---+    +---+---+    +---+---+
        | 0 | *-|--->| 1 | *-|--->| 2 | *-|--->| 3 |NULL|
        +---+---+    +---+---+    +---+---+    +---+---+
          ^
          |
        HEAD (update)

After: HEAD -> [0] -> [1] -> [2] -> [3] -> NULL
```

### 3. Insertion at End

**Step-by-step:**
```
Before: HEAD -> [1] -> [2] -> [3] -> NULL
Insert: [4]

Step 1: Traverse to last node
        HEAD
          |
          v
        +---+---+    +---+---+    +---+---+
        | 1 | *-|--->| 2 | *-|--->| 3 |NULL|  <-- Current position
        +---+---+    +---+---+    +---+---+

Step 2: Create new node, update last node's next
        +---+---+    +---+---+    +---+---+    +---+---+
        | 1 | *-|--->| 2 | *-|--->| 3 | *-|--->| 4 |NULL|
        +---+---+    +---+---+    +---+---+    +---+---+
                                        ^
                                        |
                                  Updated pointer

After: HEAD -> [1] -> [2] -> [3] -> [4] -> NULL
```

### 4. Insertion at Position

**Insert at position 2 (0-indexed):**
```
Before: HEAD -> [1] -> [2] -> [4] -> NULL
Insert: [3] at position 2

Step 1: Traverse to node at position 1 (one before target)
        HEAD
          |
          v
        +---+---+    +---+---+    +---+---+
        | 1 | *-|--->| 2 | *-|--->| 4 |NULL|
        +---+---+    +---+---+    +---+---+
                       ^
                       |
                 Stop here (position 1)

Step 2: Create new node, adjust pointers
        +---+---+    +---+---+    +---+---+    +---+---+
        | 1 | *-|--->| 2 | *-|    | 3 | *-|--->| 4 |NULL|
        +---+---+    +---+---+ \  +---+---+    +---+---+
                                \     ^
                                 \____|

After: HEAD -> [1] -> [2] -> [3] -> [4] -> NULL
```

### 5. Deletion at Beginning

```
Before: HEAD -> [1] -> [2] -> [3] -> NULL

Step 1: Save reference to first node (to free memory)
Step 2: Move HEAD to second node

        HEAD ----+
          |      |
          v      v (new HEAD)
        +---+---+    +---+---+    +---+---+
        | 1 | *-|--->| 2 | *-|--->| 3 |NULL|
        +---+---+    +---+---+    +---+---+
          ^
          |
       Delete this

After: HEAD -> [2] -> [3] -> NULL
```

### 6. Deletion at End

```
Before: HEAD -> [1] -> [2] -> [3] -> NULL

Step 1: Traverse to second-to-last node
        HEAD
          |
          v
        +---+---+    +---+---+    +---+---+
        | 1 | *-|--->| 2 | *-|--->| 3 |NULL|
        +---+---+    +---+---+    +---+---+
                       ^            ^
                       |            |
                Stop here      Delete this

Step 2: Set second-to-last node's next to NULL
        +---+---+    +---+---+
        | 1 | *-|--->| 2 |NULL|
        +---+---+    +---+---+

After: HEAD -> [1] -> [2] -> NULL
```

### 7. Deletion at Position

**Delete at position 1:**
```
Before: HEAD -> [1] -> [2] -> [3] -> NULL

Step 1: Traverse to node before target (position 0)
        HEAD
          |
          v
        +---+---+    +---+---+    +---+---+
        | 1 | *-|--->| 2 | *-|--->| 3 |NULL|
        +---+---+    +---+---+    +---+---+
          ^            ^
          |            |
     Stop here    Delete this

Step 2: Adjust pointer to skip deleted node
        +---+---+    +---+---+    +---+---+
        | 1 | *-|----+| 2 | *-|--->| 3 |NULL|
        +---+---+    |+---+---+    +---+---+
                     |                ^
                     |________________|

After: HEAD -> [1] -> [3] -> NULL
```

### 8. Search

```
Search for value 3:

HEAD
  |
  v
+---+---+    +---+---+    +---+---+    +---+---+
| 1 | *-|--->| 2 | *-|--->| 3 | *-|--->| 4 |NULL|
+---+---+    +---+---+    +---+---+    +---+---+
  ^            ^            ^
  |            |            |
1 != 3      2 != 3      3 == 3 FOUND! (index 2)
```

---

## Time Complexity Analysis

### Singly Linked List

| Operation | Time Complexity | Explanation |
|-----------|-----------------|-------------|
| **Access by Index** | O(n) | Must traverse from head |
| **Search** | O(n) | Must traverse to find element |
| **Insert at Head** | O(1) | Just update head pointer |
| **Insert at Tail** | O(n) / O(1)* | O(n) without tail pointer, O(1) with |
| **Insert at Position** | O(n) | Must traverse to position |
| **Delete at Head** | O(1) | Just update head pointer |
| **Delete at Tail** | O(n) | Must find second-to-last node |
| **Delete at Position** | O(n) | Must traverse to position |
| **Delete by Value** | O(n) | Must search for value |

*With a tail pointer maintained

### Doubly Linked List

| Operation | Time Complexity | Explanation |
|-----------|-----------------|-------------|
| **Access by Index** | O(n) | Can start from head or tail |
| **Search** | O(n) | Can search from both ends |
| **Insert at Head** | O(1) | Update head and new node's pointers |
| **Insert at Tail** | O(1) | Update tail and new node's pointers |
| **Insert at Position** | O(n) | Must traverse to position |
| **Delete at Head** | O(1) | Update head pointer |
| **Delete at Tail** | O(1) | Update tail pointer |
| **Delete at Position** | O(n) | Must traverse, but deletion is O(1) |
| **Delete Given Node** | O(1) | Have reference to previous via prev pointer |

### Space Complexity

| Type | Space per Node | Total Space |
|------|----------------|-------------|
| Singly Linked List | data + 1 pointer | O(n) |
| Doubly Linked List | data + 2 pointers | O(n) |
| Circular (any) | Same as base type | O(n) |

---

## When to Use Linked Lists

### Use Linked Lists When:
1. **Frequent insertions/deletions at beginning** - O(1) vs O(n) for arrays
2. **Unknown size** - No need to pre-allocate or resize
3. **No random access needed** - Sequential access is sufficient
4. **Implementing stacks/queues** - Natural fit for LIFO/FIFO
5. **Memory is fragmented** - Non-contiguous allocation is fine

### Use Arrays When:
1. **Frequent random access** - O(1) indexing
2. **Cache efficiency matters** - Contiguous memory is faster
3. **Memory overhead concerns** - No pointer storage needed
4. **Known, fixed size** - Arrays are simpler
5. **Sorting frequently** - Better cache locality for comparisons

---

## Common Patterns and Techniques

### 1. Two Pointer Technique
Used for: Finding middle, detecting cycles, finding nth from end

```
Slow and Fast Pointers:

Start:    S,F
            |
            v
          +---+    +---+    +---+    +---+    +---+
          | 1 |--->| 2 |--->| 3 |--->| 4 |--->| 5 |
          +---+    +---+    +---+    +---+    +---+

Step 1:   S         F
          |         |
          v         v
          +---+    +---+    +---+    +---+    +---+
          | 1 |--->| 2 |--->| 3 |--->| 4 |--->| 5 |
          +---+    +---+    +---+    +---+    +---+

Step 2:            S                 F
                   |                 |
                   v                 v
          +---+    +---+    +---+    +---+    +---+
          | 1 |--->| 2 |--->| 3 |--->| 4 |--->| 5 |
          +---+    +---+    +---+    +---+    +---+

Step 3:                     S                       F (NULL)
                            |
                            v
          +---+    +---+    +---+    +---+    +---+
          | 1 |--->| 2 |--->| 3 |--->| 4 |--->| 5 |
          +---+    +---+    +---+    +---+    +---+
                              ^
                              |
                           MIDDLE!
```

### 2. Dummy Node Technique
Used for: Simplifying edge cases (empty list, single node)

```
Before operation (with dummy):

DUMMY -> HEAD -> [1] -> [2] -> [3] -> NULL

This eliminates special cases for:
- Empty list operations
- Insertion at head
- Deletion of head
```

### 3. Recursion
Used for: Reversal, merging, many linked list operations

```
Recursive structure of linked list:

LinkedList = Node + LinkedList (smaller)
           = Node + Node + LinkedList (even smaller)
           = Node + Node + Node + ... + NULL

This naturally fits recursive algorithms!
```

---

## Summary

Linked Lists are fundamental data structures that provide:
- **Dynamic size** without pre-allocation
- **Efficient insertions/deletions** at known positions
- **Foundation** for more complex structures (stacks, queues, graphs)

Understanding linked lists deeply prepares you for:
- Trees (nodes with multiple children pointers)
- Graphs (nodes with arbitrary connections)
- Hash tables with chaining (linked lists for collision handling)
- Memory management concepts

Master the pointer manipulation - it's the key to all linked list problems!
