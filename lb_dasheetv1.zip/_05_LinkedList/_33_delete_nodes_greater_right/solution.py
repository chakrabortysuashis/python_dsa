"""
Delete Nodes Having Greater Value on Right
==========================================
"""


class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next


def delete_nodes_greater_right(head: ListNode) -> ListNode:
    """
    Delete nodes that have a greater value on their right.

    Algorithm:
    1. Reverse the list
    2. Keep only nodes >= max_so_far
    3. Reverse back

    Time: O(n), Space: O(1)
    """
    if not head or not head.next:
        return head

    # Reverse the list
    head = reverse(head)

    # Process: keep nodes >= max_so_far
    max_so_far = head.val
    current = head

    while current.next:
        if current.next.val < max_so_far:
            # Delete this node
            current.next = current.next.next
        else:
            # Keep and update max
            max_so_far = current.next.val
            current = current.next

    # Reverse back
    return reverse(head)


def reverse(head: ListNode) -> ListNode:
    """Reverse linked list."""
    prev = None
    curr = head
    while curr:
        next_node = curr.next
        curr.next = prev
        prev = curr
        curr = next_node
    return prev


# Test
def create_list(vals):
    if not vals:
        return None
    head = ListNode(vals[0])
    curr = head
    for v in vals[1:]:
        curr.next = ListNode(v)
        curr = curr.next
    return head


def list_to_array(head):
    result = []
    while head:
        result.append(head.val)
        head = head.next
    return result


def test():
    print("DELETE NODES GREATER ON RIGHT - TESTS")

    head = create_list([12, 15, 10, 11, 5, 6, 2, 3])
    print(f"Input:  {list_to_array(head)}")
    head = delete_nodes_greater_right(head)
    print(f"Output: {list_to_array(head)}")
    assert list_to_array(head) == [15, 11, 6, 3]

    head = create_list([10, 20, 30, 40, 50])
    head = delete_nodes_greater_right(head)
    print(f"Ascending: {list_to_array(head)}")
    assert list_to_array(head) == [50]

    head = create_list([50, 40, 30, 20, 10])
    head = delete_nodes_greater_right(head)
    print(f"Descending: {list_to_array(head)}")
    assert list_to_array(head) == [50, 40, 30, 20, 10]

    print("All tests passed!")


if __name__ == "__main__":
    test()
