# Delete Nodes Having Greater Value on Right

## Problem Statement

Given a linked list, delete all nodes that have a greater value node on their right side.

**Example:**
```
Input:  12 -> 15 -> 10 -> 11 -> 5 -> 6 -> 2 -> 3 -> NULL
Output: 15 -> 11 -> 6 -> 3 -> NULL

Explanation:
- 12 deleted (15 > 12 on right)
- 15 kept (no greater on right)
- 10 deleted (11 > 10 on right)
- 11 kept (no greater on right in remaining)
- 5 deleted (6 > 5)
- 6 kept
- 2 deleted (3 > 2)
- 3 kept (last node)
```

---

## Approach

### Key Insight

```
Process from RIGHT to LEFT:
- Keep track of maximum seen so far from right
- If current node < max, delete it
- Otherwise, keep it and update max

Trick: Reverse the list, process, reverse back
```

---

## Algorithm

```
1. Reverse the list
2. Traverse and keep only nodes >= max_so_far
3. Reverse the result back
```

---

## Visual Walkthrough

```
Original: 12 -> 15 -> 10 -> 11 -> 5 -> 6 -> 2 -> 3

Reversed: 3 -> 2 -> 6 -> 5 -> 11 -> 10 -> 15 -> 12

Process (keep if >= max):
  3: max=3, keep
  2: 2 < 3, delete
  6: max=6, keep
  5: 5 < 6, delete
  11: max=11, keep
  10: 10 < 11, delete
  15: max=15, keep
  12: 12 < 15, delete

After: 3 -> 6 -> 11 -> 15

Reverse back: 15 -> 11 -> 6 -> 3
```

---

## Complexity

| Aspect | Complexity |
|--------|------------|
| Time | O(n) |
| Space | O(1) |

---

## Key Points

1. Reverse to process from right
2. Track maximum from right side
3. Keep only nodes >= maximum
4. Reverse result back
