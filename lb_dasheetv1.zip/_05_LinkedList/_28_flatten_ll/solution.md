# Flatten a Linked List

## Problem Statement

Given a linked list where each node has a next pointer and a down pointer, flatten the list so all nodes are in a single level sorted list.

**Example:**
```
5 -> 10 -> 19 -> 28
|    |     |     |
7    20    22    35
|          |     |
8          50    40
|                |
30               45

Output: 5 -> 7 -> 8 -> 10 -> 19 -> 20 -> 22 -> 28 -> 30 -> 35 -> 40 -> 45 -> 50
```

---

## Intuition

```
Each vertical list is already sorted.
The horizontal connections link sorted lists.

Approach: Merge sorted lists one by one
- Start from rightmost two lists
- Merge them into one sorted list
- Continue merging with next list to left
- Result is fully flattened sorted list
```

---

## Algorithm

```
1. Start from head
2. Recursively flatten the rest (head.next)
3. Merge current vertical list with flattened result
4. Return merged list

Base case: If head or head.next is NULL, return head
```

---

## Visual Walkthrough

```
Step 1: Flatten from right
        28 -> 35 -> 40 -> 45 (already flattened)

Step 2: Merge 19's list with step 1 result
        19 -> 22 -> 50
        Merged with 28 -> 35 -> 40 -> 45
        = 19 -> 22 -> 28 -> 35 -> 40 -> 45 -> 50

Step 3: Merge 10's list with step 2 result
        10 -> 20
        = 10 -> 19 -> 20 -> 22 -> 28 -> 35 -> 40 -> 45 -> 50

Step 4: Merge 5's list with step 3 result
        5 -> 7 -> 8 -> 30
        = 5 -> 7 -> 8 -> 10 -> 19 -> 20 -> 22 -> 28 -> 30 -> 35 -> 40 -> 45 -> 50
```

---

## Complexity

| Aspect | Complexity |
|--------|------------|
| Time | O(n*m) or O(total nodes) |
| Space | O(1) or O(n) for recursion |

Where n = number of horizontal nodes, m = average vertical length

---

## Key Points

1. Each vertical list is already sorted
2. Merge operation is similar to merge sort
3. Recursive approach: flatten right, then merge
4. Use 'down' pointer for merged list (next becomes NULL)
