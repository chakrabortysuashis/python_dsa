"""
Flatten a Linked List
=====================

Given a linked list with next and down pointers, flatten into sorted list.
"""


class Node:
    def __init__(self, val=0, next=None, down=None):
        self.val = val
        self.next = next
        self.down = down


def flatten(head: Node) -> Node:
    """
    Flatten the list using recursive merge approach.

    Algorithm:
    1. Recursively flatten the right part (head.next)
    2. Merge current vertical list with flattened right
    3. Return merged result

    Time: O(total nodes)
    Space: O(n) for recursion stack
    """
    if head is None or head.next is None:
        return head

    # Recursively flatten the right part
    head.next = flatten(head.next)

    # Merge current list with flattened right
    head = merge(head, head.next)

    return head


def merge(a: Node, b: Node) -> Node:
    """
    Merge two sorted lists (using down pointer).
    """
    if a is None:
        return b
    if b is None:
        return a

    # Use down pointer for result
    if a.val < b.val:
        result = a
        result.down = merge(a.down, b)
    else:
        result = b
        result.down = merge(a, b.down)

    result.next = None
    return result


def merge_iterative(a: Node, b: Node) -> Node:
    """Iterative merge for O(1) space."""
    dummy = Node(0)
    tail = dummy

    while a and b:
        if a.val < b.val:
            tail.down = a
            a = a.down
        else:
            tail.down = b
            b = b.down
        tail = tail.down
        tail.next = None

    tail.down = a if a else b
    return dummy.down


# Helper functions
def create_vertical_list(values):
    """Create a vertical list (using down pointers)."""
    if not values:
        return None
    head = Node(values[0])
    curr = head
    for val in values[1:]:
        curr.down = Node(val)
        curr = curr.down
    return head


def create_multi_level_list(lists):
    """Create multi-level list from list of lists."""
    if not lists:
        return None

    # Create vertical lists
    heads = [create_vertical_list(lst) for lst in lists]

    # Connect horizontally
    for i in range(len(heads) - 1):
        heads[i].next = heads[i + 1]

    return heads[0]


def flatten_to_list(head):
    """Convert flattened list to Python list."""
    result = []
    while head:
        result.append(head.val)
        head = head.down
    return result


def test_flatten():
    print("FLATTEN LINKED LIST - TESTS")

    # Create the example list
    lists = [
        [5, 7, 8, 30],
        [10, 20],
        [19, 22, 50],
        [28, 35, 40, 45]
    ]

    head = create_multi_level_list(lists)
    print(f"Input lists: {lists}")

    head = flatten(head)
    result = flatten_to_list(head)
    print(f"Flattened: {result}")

    expected = sorted([item for sublist in lists for item in sublist])
    assert result == expected, f"Expected {expected}, got {result}"
    print("Test passed!")


if __name__ == "__main__":
    test_flatten()
