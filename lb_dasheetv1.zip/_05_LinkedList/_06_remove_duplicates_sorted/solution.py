"""
Remove Duplicates in a Sorted Linked List
==========================================

Problem: Given a sorted linked list, delete all duplicates such that
         each element appears only once.

Example:
    Input:  1 -> 1 -> 2 -> 3 -> 3 -> 3 -> 4 -> NULL
    Output: 1 -> 2 -> 3 -> 4 -> NULL
"""


class ListNode:
    """Definition for singly-linked list node."""
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

    def __repr__(self):
        return f"ListNode({self.val})"


# =============================================================================
# APPROACH 1: ITERATIVE (OPTIMAL)
# =============================================================================

def delete_duplicates(head: ListNode) -> ListNode:
    """
    Remove duplicates from sorted linked list.

    Algorithm:
    1. Iterate through the list with a current pointer
    2. If current.val == current.next.val:
       - Skip next node (current.next = current.next.next)
       - Don't move current (there might be more duplicates)
    3. Else:
       - Move current forward

    Key insight: Since list is sorted, duplicates are adjacent!

    Visual Example:
    [1] -> [1] -> [2] -> [2] -> [2] -> [3]
     ^
    curr

    1 == 1? Yes! Skip next.
    [1] ---------> [2] -> [2] -> [2] -> [3]
     ^
    curr

    1 == 2? No. Move forward.
    [1] -> [2] -> [2] -> [2] -> [3]
            ^
           curr

    2 == 2? Yes! Skip.
    [1] -> [2] ---------> [2] -> [3]
            ^
           curr

    And so on...

    Time Complexity: O(n) - single pass
    Space Complexity: O(1) - in-place modification
    """
    if not head or not head.next:
        return head

    current = head

    while current and current.next:
        if current.val == current.next.val:
            # Skip the duplicate node
            # Don't move current - there might be more duplicates
            current.next = current.next.next
        else:
            # Move to next node
            current = current.next

    return head


# =============================================================================
# APPROACH 2: RECURSIVE
# =============================================================================

def delete_duplicates_recursive(head: ListNode) -> ListNode:
    """
    Remove duplicates using recursion.

    Recursion idea:
    1. If current.val == next.val, skip next and recurse on current
    2. Else, recurse on next

    Time Complexity: O(n)
    Space Complexity: O(n) - recursion stack
    """
    # Base cases
    if not head or not head.next:
        return head

    if head.val == head.next.val:
        # Skip duplicate, but stay at head (might be more)
        head.next = head.next.next
        return delete_duplicates_recursive(head)
    else:
        # Process rest of list
        head.next = delete_duplicates_recursive(head.next)
        return head


# =============================================================================
# VARIANT: DELETE ALL NODES WITH DUPLICATES
# =============================================================================

def delete_all_duplicates(head: ListNode) -> ListNode:
    """
    Remove ALL nodes that have duplicates (not just extra copies).

    Example:
        Input:  1 -> 1 -> 2 -> 3 -> 3 -> 4 -> NULL
        Output: 2 -> 4 -> NULL

    Algorithm:
    1. Use dummy node (head might be removed)
    2. Use predecessor pointer
    3. Skip all nodes with same value if duplicates found

    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    if not head or not head.next:
        return head

    # Dummy node to handle head removal
    dummy = ListNode(0)
    dummy.next = head

    # Predecessor pointer
    pred = dummy

    while head:
        # If this is the beginning of duplicates
        if head.next and head.val == head.next.val:
            # Skip all nodes with this value
            while head.next and head.val == head.next.val:
                head = head.next

            # Skip the last duplicate too
            pred.next = head.next
        else:
            # No duplicates, move predecessor
            pred = pred.next

        head = head.next

    return dummy.next


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def create_linked_list(values: list) -> ListNode:
    """Create a linked list from a list of values."""
    if not values:
        return None

    head = ListNode(values[0])
    current = head

    for val in values[1:]:
        current.next = ListNode(val)
        current = current.next

    return head


def linked_list_to_list(head: ListNode) -> list:
    """Convert linked list to Python list."""
    result = []
    current = head

    while current:
        result.append(current.val)
        current = current.next

    return result


def print_linked_list(head: ListNode) -> str:
    """Print linked list in readable format."""
    values = linked_list_to_list(head)
    return " -> ".join(map(str, values)) + " -> NULL"


# =============================================================================
# TEST CASES
# =============================================================================

def test_delete_duplicates():
    """Test remove duplicates implementations."""
    print("=" * 60)
    print("REMOVE DUPLICATES (SORTED LIST) - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal duplicates
    print("\n--- Test Case 1: Normal Duplicates ---")
    values = [1, 1, 2, 3, 3, 3, 4]
    head = create_linked_list(values)
    print(f"Input:  {print_linked_list(head)}")

    result = delete_duplicates(head)
    print(f"Output: {print_linked_list(result)}")

    assert linked_list_to_list(result) == [1, 2, 3, 4]
    print("Assertion passed!")

    # Test Case 2: All same
    print("\n--- Test Case 2: All Same Values ---")
    values = [1, 1, 1, 1]
    head = create_linked_list(values)
    print(f"Input:  {print_linked_list(head)}")

    result = delete_duplicates(head)
    print(f"Output: {print_linked_list(result)}")

    assert linked_list_to_list(result) == [1]
    print("Assertion passed!")

    # Test Case 3: No duplicates
    print("\n--- Test Case 3: No Duplicates ---")
    values = [1, 2, 3, 4, 5]
    head = create_linked_list(values)
    print(f"Input:  {print_linked_list(head)}")

    result = delete_duplicates(head)
    print(f"Output: {print_linked_list(result)}")

    assert linked_list_to_list(result) == [1, 2, 3, 4, 5]
    print("Assertion passed!")

    # Test Case 4: Single node
    print("\n--- Test Case 4: Single Node ---")
    head = create_linked_list([1])
    print(f"Input:  {print_linked_list(head)}")

    result = delete_duplicates(head)
    print(f"Output: {print_linked_list(result)}")

    assert linked_list_to_list(result) == [1]
    print("Assertion passed!")

    # Test Case 5: Empty list
    print("\n--- Test Case 5: Empty List ---")
    head = None
    result = delete_duplicates(head)
    print(f"Input:  NULL")
    print(f"Output: NULL")
    assert result is None
    print("Assertion passed!")

    # Test Case 6: Recursive approach
    print("\n--- Test Case 6: Recursive Approach ---")
    values = [1, 1, 2, 2, 3]
    head = create_linked_list(values)
    print(f"Input:  {print_linked_list(head)}")

    result = delete_duplicates_recursive(head)
    print(f"Output: {print_linked_list(result)}")

    assert linked_list_to_list(result) == [1, 2, 3]
    print("Assertion passed!")

    # Test Case 7: Delete ALL duplicates
    print("\n--- Test Case 7: Delete ALL Nodes with Duplicates ---")
    values = [1, 1, 2, 3, 3, 4]
    head = create_linked_list(values)
    print(f"Input:  {print_linked_list(head)}")

    result = delete_all_duplicates(head)
    print(f"Output: {print_linked_list(result)}")

    assert linked_list_to_list(result) == [2, 4]
    print("Assertion passed!")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_algorithm():
    """Demonstrate the algorithm step by step."""
    print("\n" + "=" * 60)
    print("ALGORITHM DEMONSTRATION")
    print("=" * 60)

    values = [1, 1, 2, 2, 2, 3]
    print(f"\nInput: {' -> '.join(map(str, values))} -> NULL")
    print("\nStep-by-step:")
    print("-" * 40)

    current_values = values.copy()
    idx = 0

    while idx < len(current_values) - 1:
        curr_val = current_values[idx]
        next_val = current_values[idx + 1]

        print(f"\ncurr at index {idx}, value = {curr_val}")
        print(f"next at index {idx + 1}, value = {next_val}")

        if curr_val == next_val:
            print(f"  {curr_val} == {next_val}: DUPLICATE! Skip next node.")
            current_values.pop(idx + 1)
            print(f"  List now: {' -> '.join(map(str, current_values))} -> NULL")
            # Don't increment idx
        else:
            print(f"  {curr_val} != {next_val}: Different. Move forward.")
            idx += 1

    print(f"\nFinal: {' -> '.join(map(str, current_values))} -> NULL")


if __name__ == "__main__":
    test_delete_duplicates()
    demonstrate_algorithm()
