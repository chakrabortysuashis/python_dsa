# Remove Duplicates in a Sorted Linked List

## Problem Statement

Given a sorted linked list, delete all duplicates such that each element appears only once.

**Example:**
```
Input:  1 -> 1 -> 2 -> 3 -> 3 -> 3 -> 4 -> NULL
Output: 1 -> 2 -> 3 -> 4 -> NULL
```

---

## Intuition

### Key Insight: List is Sorted!

Since the list is sorted, **all duplicates are adjacent**. This makes the problem much simpler.

```
Sorted:   [1] -> [1] -> [2] -> [3] -> [3] -> [4]
                  ^            duplicates      ^
                consecutive                consecutive

Unsorted: [1] -> [3] -> [1] -> [2] -> [3] -> [4]
                        ^            ^
              duplicates scattered - harder!
```

### Approach

Simply compare each node with its next. If they're equal, skip the next node.

---

## Visual Walkthrough

**Input:** 1 -> 1 -> 2 -> 3 -> 3 -> NULL

```
Step 1: curr at 1, next is 1
[1] -> [1] -> [2] -> [3] -> [3] -> NULL
 ^      ^
curr  curr.next

Values equal! Skip next node.
[1] ---------> [2] -> [3] -> [3] -> NULL
 ^              ^
curr        (new next)
```

```
Step 2: curr at 1, next is 2
[1] -> [2] -> [3] -> [3] -> NULL
 ^      ^
curr  curr.next

Values different. Move curr forward.
[1] -> [2] -> [3] -> [3] -> NULL
        ^
       curr
```

```
Step 3: curr at 2, next is 3
[1] -> [2] -> [3] -> [3] -> NULL
        ^      ^
       curr  curr.next

Values different. Move curr forward.
[1] -> [2] -> [3] -> [3] -> NULL
               ^
              curr
```

```
Step 4: curr at 3, next is 3
[1] -> [2] -> [3] -> [3] -> NULL
               ^      ^
              curr  curr.next

Values equal! Skip next node.
[1] -> [2] -> [3] ---------> NULL
               ^
              curr
```

**Result:** 1 -> 2 -> 3 -> NULL

---

## Algorithm

```
1. Start with curr = head
2. While curr and curr.next exist:
   a. If curr.val == curr.next.val:
      - Skip next node (curr.next = curr.next.next)
   b. Else:
      - Move curr forward (curr = curr.next)
3. Return head
```

---

## Dry Run

**Input:** 1 -> 1 -> 1 -> 2 -> 3 -> NULL

| Step | curr | curr.next | Action | List State |
|------|------|-----------|--------|------------|
| 1 | 1 | 1 | Skip (equal) | 1->1->2->3->NULL |
| 2 | 1 | 1 | Skip (equal) | 1->2->3->NULL |
| 3 | 1 | 2 | Move (different) | 1->2->3->NULL |
| 4 | 2 | 3 | Move (different) | 1->2->3->NULL |
| 5 | 3 | NULL | End | 1->2->3->NULL |

**Output:** 1 -> 2 -> 3 -> NULL

---

## Edge Cases

1. **Empty list:** Return NULL
2. **Single node:** No duplicates possible
3. **All same:** Keep only one
4. **No duplicates:** List unchanged

```
Empty:      NULL -> NULL

Single:     [1] -> NULL -> [1] -> NULL

All same:   [1] -> [1] -> [1] -> NULL
            becomes [1] -> NULL

No dups:    [1] -> [2] -> [3] -> NULL
            unchanged
```

---

## Complexity Analysis

- **Time:** O(n) - Single pass through the list
- **Space:** O(1) - Only one pointer used

---

## Variant: Remove All Nodes with Duplicates

A harder variant: Remove all nodes that have duplicates (not just extra copies).

```
Input:  1 -> 1 -> 2 -> 3 -> 3 -> 4 -> NULL
Output: 2 -> 4 -> NULL (removed 1 and 3 entirely)
```

This requires a dummy node and different logic.

---

## Key Takeaways

1. **Sorted = Adjacent duplicates** - simplifies the problem
2. **Skip vs Move** - skip if equal, move if different
3. **Don't move curr when skipping** - there might be more duplicates
4. **Single pass** - efficient O(n) solution
