"""
Delete Loop in a Linked List
=============================

Problem: Given a linked list that contains a loop, remove the loop
         without losing any nodes.

Example:
    Input:  1 -> 2 -> 3 -> 4 -> 5 -> 3 (cycle to node 3)
    Output: 1 -> 2 -> 3 -> 4 -> 5 -> NULL
"""


class ListNode:
    """Definition for singly-linked list node."""
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

    def __repr__(self):
        return f"ListNode({self.val})"


# =============================================================================
# APPROACH 1: FLOYD'S ALGORITHM (OPTIMAL)
# =============================================================================

def delete_loop(head: ListNode) -> ListNode:
    """
    Delete loop in linked list using Floyd's algorithm.

    Algorithm:
    1. Detect loop using Floyd's cycle detection
    2. Find the starting point of the loop
    3. Find the last node in the cycle (node before loop start)
    4. Set that node's next to NULL

    Visual Example:
    Before: 1 -> 2 -> 3 -> 4 -> 5 -> 3

    Phase 1 - Detect: Slow and Fast meet somewhere in cycle
    Phase 2 - Find start: Reset slow to head, move both by 1, they meet at 3
    Phase 3 - Find last: Traverse cycle to find node pointing to 3 (node 5)
    Phase 4 - Break: Set 5.next = NULL

    After: 1 -> 2 -> 3 -> 4 -> 5 -> NULL

    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    if not head or not head.next:
        return head

    # Phase 1: Detect loop using Floyd's algorithm
    slow = head
    fast = head

    # Find meeting point
    loop_exists = False
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next

        if slow == fast:
            loop_exists = True
            break

    # If no loop, return original list
    if not loop_exists:
        return head

    # Phase 2: Find the starting point of the loop
    # Reset slow to head, keep fast at meeting point
    slow = head

    # Special case: loop starts at head
    if slow == fast:
        # Find last node in cycle
        while fast.next != slow:
            fast = fast.next
        fast.next = None
        return head

    # Move both one step at a time until they meet
    while slow.next != fast.next:
        slow = slow.next
        fast = fast.next

    # Phase 3 & 4: fast.next is the loop start
    # fast is now the last node in the cycle
    # Set its next to NULL to break the loop
    fast.next = None

    return head


# =============================================================================
# APPROACH 2: HASH SET
# =============================================================================

def delete_loop_hashset(head: ListNode) -> ListNode:
    """
    Delete loop using hash set to track visited nodes.

    Algorithm:
    1. Traverse the list
    2. Store each visited node
    3. When we find a node whose next is already visited,
       we've found the last node of the cycle
    4. Set its next to NULL

    Time Complexity: O(n)
    Space Complexity: O(n) - for storing visited nodes
    """
    if not head or not head.next:
        return head

    visited = set()
    current = head

    while current:
        # If next node is already visited, this creates the loop
        if current.next in visited:
            current.next = None
            break

        visited.add(current)
        current = current.next

    return head


# =============================================================================
# APPROACH 3: COUNT NODES IN LOOP
# =============================================================================

def delete_loop_count(head: ListNode) -> ListNode:
    """
    Delete loop by counting nodes in the loop.

    Algorithm:
    1. Detect loop and find meeting point
    2. Count nodes in the loop (k nodes)
    3. Use two pointers with k distance apart
    4. Move both until fast.next meets slow (loop start)
    5. Set fast.next to NULL

    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    if not head or not head.next:
        return head

    # Detect loop
    slow = head
    fast = head

    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next

        if slow == fast:
            break
    else:
        return head  # No loop

    # Count nodes in loop
    loop_count = 1
    temp = slow.next
    while temp != slow:
        loop_count += 1
        temp = temp.next

    # Reset pointers
    # ptr1 starts at head
    # ptr2 starts loop_count nodes ahead
    ptr1 = head
    ptr2 = head

    for _ in range(loop_count):
        ptr2 = ptr2.next

    # Move both until ptr2.next meets ptr1
    while ptr1 != ptr2:
        ptr1 = ptr1.next
        ptr2 = ptr2.next

    # ptr2 is now at the last node of the cycle
    # Actually, we need to find the node BEFORE ptr1
    # Let's adjust: find the node whose next is ptr1
    temp = ptr1
    while temp.next != ptr1:
        temp = temp.next

    temp.next = None

    return head


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def create_linked_list_with_cycle(values: list, cycle_pos: int) -> ListNode:
    """
    Create a linked list with a cycle.

    Args:
        values: List of values for nodes
        cycle_pos: Index where the cycle starts (-1 for no cycle)
    """
    if not values:
        return None

    head = ListNode(values[0])
    current = head
    cycle_node = None

    if cycle_pos == 0:
        cycle_node = head

    for i, val in enumerate(values[1:], 1):
        current.next = ListNode(val)
        current = current.next

        if i == cycle_pos:
            cycle_node = current

    if cycle_node:
        current.next = cycle_node

    return head


def has_cycle(head: ListNode) -> bool:
    """Check if list has a cycle."""
    if not head:
        return False

    slow = head
    fast = head

    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next

        if slow == fast:
            return True

    return False


def print_list_safe(head: ListNode, max_nodes: int = 20) -> str:
    """Print list safely (handles cycles)."""
    if not head:
        return "NULL"

    result = []
    current = head
    visited = set()
    count = 0

    while current and count < max_nodes:
        if current in visited:
            result.append(f"[CYCLE to {current.val}]")
            break

        result.append(str(current.val))
        visited.add(current)
        current = current.next
        count += 1

    if current is None:
        result.append("NULL")

    return " -> ".join(result)


# =============================================================================
# TEST CASES
# =============================================================================

def test_delete_loop():
    """Test delete loop implementations."""
    print("=" * 60)
    print("DELETE LOOP IN LINKED LIST - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal cycle
    print("\n--- Test Case 1: Normal Cycle (5 -> 3) ---")
    head = create_linked_list_with_cycle([1, 2, 3, 4, 5], 2)
    print(f"Before: {print_list_safe(head)}")
    print(f"Has cycle: {has_cycle(head)}")

    head = delete_loop(head)
    print(f"After:  {print_list_safe(head)}")
    print(f"Has cycle: {has_cycle(head)}")

    assert not has_cycle(head)
    print("Assertion passed!")

    # Test Case 2: Self-loop
    print("\n--- Test Case 2: Self-loop ---")
    head = ListNode(1)
    head.next = head

    print(f"Before: 1 -> [CYCLE to 1]")
    print(f"Has cycle: {has_cycle(head)}")

    head = delete_loop(head)
    print(f"After:  {print_list_safe(head)}")
    print(f"Has cycle: {has_cycle(head)}")

    assert not has_cycle(head)
    print("Assertion passed!")

    # Test Case 3: Loop at head
    print("\n--- Test Case 3: Loop at Head ---")
    head = create_linked_list_with_cycle([1, 2, 3], 0)  # 3 -> 1
    print(f"Before: {print_list_safe(head)}")
    print(f"Has cycle: {has_cycle(head)}")

    head = delete_loop(head)
    print(f"After:  {print_list_safe(head)}")
    print(f"Has cycle: {has_cycle(head)}")

    assert not has_cycle(head)
    print("Assertion passed!")

    # Test Case 4: No cycle
    print("\n--- Test Case 4: No Cycle ---")
    head = create_linked_list_with_cycle([1, 2, 3, 4, 5], -1)
    print(f"Before: {print_list_safe(head)}")
    print(f"Has cycle: {has_cycle(head)}")

    head = delete_loop(head)
    print(f"After:  {print_list_safe(head)}")
    print(f"Has cycle: {has_cycle(head)}")

    assert not has_cycle(head)
    print("Assertion passed!")

    # Test Case 5: Two nodes in loop
    print("\n--- Test Case 5: Two Nodes Loop ---")
    head = create_linked_list_with_cycle([1, 2], 0)  # 2 -> 1
    print(f"Before: {print_list_safe(head)}")
    print(f"Has cycle: {has_cycle(head)}")

    head = delete_loop(head)
    print(f"After:  {print_list_safe(head)}")
    print(f"Has cycle: {has_cycle(head)}")

    assert not has_cycle(head)
    print("Assertion passed!")

    # Test Case 6: Using hash set approach
    print("\n--- Test Case 6: Hash Set Approach ---")
    head = create_linked_list_with_cycle([1, 2, 3, 4, 5], 2)
    print(f"Before: {print_list_safe(head)}")

    head = delete_loop_hashset(head)
    print(f"After (hashset): {print_list_safe(head)}")

    assert not has_cycle(head)
    print("Assertion passed!")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_algorithm():
    """Demonstrate the algorithm step by step."""
    print("\n" + "=" * 60)
    print("ALGORITHM DEMONSTRATION")
    print("=" * 60)

    print("\nList: 1 -> 2 -> 3 -> 4 -> 5 -> 3 (cycle)")
    print("\nPhase 1: Detecting Loop")
    print("-" * 40)
    print("Using Floyd's algorithm:")
    print("  - Slow moves 1 step")
    print("  - Fast moves 2 steps")
    print("  - They will meet inside the cycle")

    print("\nPhase 2: Finding Loop Start")
    print("-" * 40)
    print("Reset slow to head, keep fast at meeting point")
    print("Move both 1 step at a time")
    print("They meet at loop start (node 3)")

    print("\nPhase 3: Finding Last Node")
    print("-" * 40)
    print("Traverse from loop start (3) through cycle")
    print("Find node whose next is loop start")
    print("That's node 5 (5.next = 3)")

    print("\nPhase 4: Breaking Loop")
    print("-" * 40)
    print("Set node 5's next to NULL")
    print("Result: 1 -> 2 -> 3 -> 4 -> 5 -> NULL")


if __name__ == "__main__":
    test_delete_loop()
    demonstrate_algorithm()
