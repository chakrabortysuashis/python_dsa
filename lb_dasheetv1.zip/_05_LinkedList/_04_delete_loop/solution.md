# Delete Loop in a Linked List

## Problem Statement

Given a linked list that contains a loop, remove the loop without losing any nodes.

**Example:**
```
Input:  1 -> 2 -> 3 -> 4 -> 5
                  ^         |
                  |_________|

Output: 1 -> 2 -> 3 -> 4 -> 5 -> NULL
```

---

## Intuition

### Understanding the Problem

To delete a loop, we need to:
1. **Detect** that a loop exists
2. **Find** the node whose next pointer creates the loop
3. **Break** the loop by setting that pointer to NULL

```
Before:
[1] -> [2] -> [3] -> [4] -> [5]
               ^             |
               |_____________|
               Loop-creating pointer

After:
[1] -> [2] -> [3] -> [4] -> [5] -> NULL
                              ^
                        Set to NULL
```

### Key Insight

Once we find where the loop starts, we need to find the node **just before** it in the cycle to set its next to NULL.

---

## Approach: Floyd's Algorithm Extended

### Algorithm

1. **Detect the loop** using Floyd's cycle detection
2. **Find the loop starting point** using the mathematical property
3. **Find the node before loop start** in the cycle
4. **Break the loop** by setting its next to NULL

### Visual Walkthrough

**List:** 1 -> 2 -> 3 -> 4 -> 5 -> 3

```
Step 1: Detect Loop (Floyd's)

[1] -> [2] -> [3] -> [4] -> [5]
               ^             |
               |_____________|

Slow and Fast will meet somewhere in the cycle.
Let's say they meet at node 4.
```

```
Step 2: Find Loop Start

Reset slow to head, keep fast at meeting point.
Move both one step at a time.

slow = 1, fast = 4
slow = 2, fast = 5
slow = 3, fast = 3  <- MEET at loop start!
```

```
Step 3: Find Node Before Loop Start

We need to find the node whose next is the loop start (node 3).
Start from meeting point and traverse until we find it.

Current = 3, current.next = 4? No, 4 != 3
Current = 4, current.next = 5? No, 5 != 3
Current = 5, current.next = 3? YES! 3 == loop_start

Node 5's next points to loop start!
```

```
Step 4: Break the Loop

Set node 5's next to NULL.

[1] -> [2] -> [3] -> [4] -> [5] -> NULL
```

### Special Case: Loop at Head

When the loop starts at head, we need to traverse the entire cycle.

```
[1] -> [2] -> [3]
 ^             |
 |_____________|

Loop start = 1 (head)
Find node whose next is head.
That's node 3.
Set 3.next = NULL.
```

---

## Dry Run

**Input:** 1 -> 2 -> 3 -> 4 -> 5 -> 3

| Phase | Action | Result |
|-------|--------|--------|
| 1. Detect | Floyd's algorithm | Meet at some node in cycle |
| 2. Find start | Reset slow to head | Loop starts at 3 |
| 3. Find prev | Traverse cycle | Node 5 points to 3 |
| 4. Break | 5.next = NULL | Loop removed |

**Output:** 1 -> 2 -> 3 -> 4 -> 5 -> NULL

---

## Edge Cases

1. **No loop:** Nothing to delete, return as is
2. **Single node self-loop:** Node points to itself
3. **Loop at head:** Entire list is a cycle
4. **Two nodes in loop:** a -> b -> a

```
Self-loop:    [1] ↺     After: [1] -> NULL

Loop at head: [1] -> [2] -> [3] -> [1]
              After: [1] -> [2] -> [3] -> NULL

Two nodes:    [1] -> [2] -> [1]
              After: [1] -> [2] -> NULL
```

---

## Complexity Analysis

- **Time:** O(n) - Each phase is linear
- **Space:** O(1) - Only pointers used

---

## Alternative Approach: Using Hash Set

### Algorithm
1. Traverse the list, storing visited nodes
2. When we find a node whose next is already visited
3. Set that node's next to NULL

### Complexity
- **Time:** O(n)
- **Space:** O(n) - for the hash set

---

## Key Takeaways

1. **Delete loop = Find + Break** - First find the last node of cycle
2. **Floyd's extended** - Use the same algorithm to find loop start
3. **Handle edge cases** - Self-loops and head loops need care
4. **Preserve all nodes** - Don't lose any data while breaking loop
