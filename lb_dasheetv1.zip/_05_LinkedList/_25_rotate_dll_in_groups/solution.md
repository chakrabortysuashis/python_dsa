# Rotate Doubly Linked List in Groups [Very Important]

## Problem Statement

Given a doubly linked list, rotate it in groups of given size K.

**Example:**
```
Input:  1 <-> 2 <-> 3 <-> 4 <-> 5 <-> 6 <-> 7 <-> 8, K = 3
Output: 3 <-> 2 <-> 1 <-> 6 <-> 5 <-> 4 <-> 8 <-> 7

Explanation: Reverse each group of K nodes
```

---

## Intuition

```
This is essentially "Reverse DLL in groups of K"

For each group of K nodes:
1. Reverse the K nodes
2. Connect to previous group
3. Move to next group

Similar to reversing singly linked list in groups,
but with DLL we update both prev and next pointers.
```

---

## Algorithm

```
1. Process K nodes at a time
2. Reverse the group
3. Connect reversed group to previous part
4. Connect to next group
5. Handle last group (may have < K nodes)
```

---

## Visual Walkthrough

```
Input: 1 <-> 2 <-> 3 <-> 4 <-> 5 <-> 6 <-> 7 <-> 8, K=3

Group 1: [1, 2, 3]
  Reverse: 3 <-> 2 <-> 1

Group 2: [4, 5, 6]
  Reverse: 6 <-> 5 <-> 4
  Connect: 1 <-> 6

Group 3: [7, 8]
  Reverse: 8 <-> 7
  Connect: 4 <-> 8

Result: 3 <-> 2 <-> 1 <-> 6 <-> 5 <-> 4 <-> 8 <-> 7
```

---

## Complexity

| Aspect | Complexity |
|--------|------------|
| Time | O(n) |
| Space | O(1) |

---

## Key Points

1. Track group head/tail for connections
2. Handle last incomplete group
3. Update both prev and next pointers
4. New head is the last node of first group after reversal
