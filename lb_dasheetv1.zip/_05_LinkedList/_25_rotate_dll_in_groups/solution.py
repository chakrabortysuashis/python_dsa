"""
Rotate/Reverse Doubly Linked List in Groups of K [Very Important]
================================================================

Reverse DLL in groups of K nodes.
"""


class DLLNode:
    def __init__(self, val=0, prev=None, next=None):
        self.val = val
        self.prev = prev
        self.next = next


def reverse_in_groups(head: DLLNode, k: int) -> DLLNode:
    """
    Reverse DLL in groups of K.

    Time: O(n), Space: O(1)
    """
    if head is None or k <= 1:
        return head

    current = head
    new_head = None
    prev_group_tail = None

    while current:
        group_head = current
        group_tail = current
        count = 0

        # Reverse K nodes
        prev = None
        while current and count < k:
            next_node = current.next
            current.next = prev
            current.prev = next_node
            prev = current
            current = next_node
            count += 1

        # After reversal: prev is new head of this group
        # group_head is now the tail of reversed group
        reversed_head = prev
        reversed_tail = group_head

        # Set new_head if first group
        if new_head is None:
            new_head = reversed_head

        # Connect with previous group
        if prev_group_tail:
            prev_group_tail.next = reversed_head
            reversed_head.prev = prev_group_tail

        # Update for next iteration
        prev_group_tail = reversed_tail

    # Fix the tail's next pointer
    if prev_group_tail:
        prev_group_tail.next = None

    return new_head


# Helper functions
def create_dll(values):
    if not values:
        return None
    head = DLLNode(values[0])
    curr = head
    for val in values[1:]:
        node = DLLNode(val, prev=curr)
        curr.next = node
        curr = node
    return head


def dll_to_list(head):
    result = []
    while head:
        result.append(head.val)
        head = head.next
    return result


def test_reverse_groups():
    print("REVERSE DLL IN GROUPS - TESTS")

    head = create_dll([1, 2, 3, 4, 5, 6, 7, 8])
    print(f"Original: {dll_to_list(head)}")
    head = reverse_in_groups(head, 3)
    print(f"K=3: {dll_to_list(head)}")
    assert dll_to_list(head) == [3, 2, 1, 6, 5, 4, 8, 7]

    head = create_dll([1, 2, 3, 4, 5])
    head = reverse_in_groups(head, 2)
    print(f"K=2: {dll_to_list(head)}")
    assert dll_to_list(head) == [2, 1, 4, 3, 5]

    print("All tests passed!")


if __name__ == "__main__":
    test_reverse_groups()
