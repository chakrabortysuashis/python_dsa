# Remove Duplicates in an Unsorted Linked List

## Problem Statement

Given an unsorted linked list, remove all duplicate nodes such that each element appears only once.

**Example:**
```
Input:  5 -> 2 -> 2 -> 4 -> 5 -> 1 -> 2 -> NULL
Output: 5 -> 2 -> 4 -> 1 -> NULL
```

---

## Intuition

### The Challenge: Unsorted!

Unlike sorted lists where duplicates are adjacent, in an unsorted list duplicates can be **anywhere**.

```
Sorted:   [1] -> [1] -> [2] -> [3] -> [3]
                  ^      adjacent      ^

Unsorted: [5] -> [2] -> [4] -> [5] -> [2]
           ^                    ^      duplicates scattered
```

### Two Approaches

1. **Hash Set:** Track seen values, remove duplicates - O(n) time, O(n) space
2. **Two Pointers (No extra space):** For each node, remove all future duplicates - O(n^2) time, O(1) space

---

## Approach 1: Hash Set (Optimal Time)

### Concept

Use a set to track values we've seen. If we encounter a value already in the set, remove that node.

```
Process: 5 -> 2 -> 2 -> 4 -> 5 -> 1

Visit 5: Set = {5}       Keep 5
Visit 2: Set = {5,2}     Keep 2
Visit 2: 2 in set!       REMOVE
Visit 4: Set = {5,2,4}   Keep 4
Visit 5: 5 in set!       REMOVE
Visit 1: Set = {5,2,4,1} Keep 1

Result: 5 -> 2 -> 4 -> 1
```

### Complexity
- **Time:** O(n) - single pass
- **Space:** O(n) - hash set storage

---

## Approach 2: Two Pointers (Optimal Space)

### Concept

For each node, traverse the rest of the list and remove all nodes with the same value.

```
Fix node 5, scan rest for 5s:
[5] -> [2] -> [2] -> [4] -> [5] -> [1]
 ^                          found! remove

Fix node 2, scan rest for 2s:
[5] -> [2] -> [2] -> [4] -> [1]
        ^     found! remove

Continue...
```

### Complexity
- **Time:** O(n^2) - nested loops
- **Space:** O(1) - no extra storage

---

## Visual Walkthrough (Hash Set)

**Input:** 5 -> 2 -> 2 -> 4 -> 5 -> 1 -> NULL

```
Initial:
prev = None
curr = 5
seen = {}

Step 1: Process 5
[5] -> [2] -> [2] -> [4] -> [5] -> [1]
 ^
5 not in seen. Add to seen.
seen = {5}
Move forward.
```

```
Step 2: Process 2
[5] -> [2] -> [2] -> [4] -> [5] -> [1]
        ^
2 not in seen. Add to seen.
seen = {5, 2}
Move forward.
```

```
Step 3: Process 2 (duplicate!)
[5] -> [2] -> [2] -> [4] -> [5] -> [1]
               ^
2 IS in seen! Remove this node.
prev.next = curr.next
[5] -> [2] ---------> [4] -> [5] -> [1]
```

```
Step 4: Process 4
[5] -> [2] -> [4] -> [5] -> [1]
               ^
4 not in seen. Add to seen.
seen = {5, 2, 4}
```

```
Step 5: Process 5 (duplicate!)
[5] -> [2] -> [4] -> [5] -> [1]
                      ^
5 IS in seen! Remove this node.
[5] -> [2] -> [4] ---------> [1]
```

```
Step 6: Process 1
[5] -> [2] -> [4] -> [1]
                      ^
1 not in seen. Add to seen.
seen = {5, 2, 4, 1}
```

**Result:** 5 -> 2 -> 4 -> 1 -> NULL

---

## Dry Run (Two Pointers)

**Input:** 1 -> 2 -> 1 -> 3 -> 2

| Outer | Inner Scan | Action | List After |
|-------|------------|--------|------------|
| 1 | 2,1,3,2 | Remove 1 at pos 3 | 1->2->3->2 |
| 2 | 3,2 | Remove 2 at pos 4 | 1->2->3 |
| 3 | - | No more duplicates | 1->2->3 |

**Output:** 1 -> 2 -> 3 -> NULL

---

## Edge Cases

1. **Empty list:** Return NULL
2. **Single node:** No duplicates possible
3. **All same:** Keep only first
4. **No duplicates:** List unchanged

```
All same:   [2] -> [2] -> [2] -> NULL
            becomes [2] -> NULL

No dups:    [1] -> [2] -> [3] -> NULL
            unchanged
```

---

## Trade-off Analysis

| Approach | Time | Space | When to Use |
|----------|------|-------|-------------|
| Hash Set | O(n) | O(n) | When time matters, memory available |
| Two Pointers | O(n^2) | O(1) | Memory constrained, small lists |

---

## Key Takeaways

1. **Unsorted = Non-adjacent duplicates** - need different approach
2. **Hash Set** gives optimal time at cost of space
3. **Two Pointers** gives optimal space at cost of time
4. Choose based on constraints (memory vs speed)
