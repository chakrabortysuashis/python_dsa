"""
Remove Duplicates in an Unsorted Linked List
=============================================

Problem: Given an unsorted linked list, remove all duplicate nodes
         such that each element appears only once.

Example:
    Input:  5 -> 2 -> 2 -> 4 -> 5 -> 1 -> 2 -> NULL
    Output: 5 -> 2 -> 4 -> 1 -> NULL
"""


class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next


# =============================================================================
# APPROACH 1: HASH SET (OPTIMAL TIME)
# =============================================================================

def remove_duplicates_hashset(head: ListNode) -> ListNode:
    """
    Remove duplicates using hash set to track seen values.

    Algorithm:
    1. Use a set to track values we've seen
    2. Traverse list with prev and curr pointers
    3. If curr.val in seen, remove curr (prev.next = curr.next)
    4. Else, add curr.val to seen and move prev forward

    Time Complexity: O(n) - single pass
    Space Complexity: O(n) - hash set storage
    """
    if not head:
        return head

    seen = set()
    prev = None
    curr = head

    while curr:
        if curr.val in seen:
            # Duplicate found - remove current node
            prev.next = curr.next
        else:
            # New value - add to seen
            seen.add(curr.val)
            prev = curr  # Only move prev when we keep the node

        curr = curr.next

    return head


# =============================================================================
# APPROACH 2: TWO POINTERS (OPTIMAL SPACE)
# =============================================================================

def remove_duplicates_two_pointers(head: ListNode) -> ListNode:
    """
    Remove duplicates using two pointers (no extra space).

    Algorithm:
    1. For each node (outer pointer)
    2. Scan rest of list (inner pointer)
    3. Remove all nodes with same value as outer

    Time Complexity: O(n^2) - nested loops
    Space Complexity: O(1) - no extra storage
    """
    if not head:
        return head

    outer = head

    while outer:
        # For each node, remove all future duplicates
        inner = outer

        while inner.next:
            if inner.next.val == outer.val:
                # Remove inner.next
                inner.next = inner.next.next
            else:
                inner = inner.next

        outer = outer.next

    return head


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def create_linked_list(values):
    if not values:
        return None
    head = ListNode(values[0])
    curr = head
    for val in values[1:]:
        curr.next = ListNode(val)
        curr = curr.next
    return head


def linked_list_to_list(head):
    result = []
    while head:
        result.append(head.val)
        head = head.next
    return result


def print_linked_list(head):
    values = linked_list_to_list(head)
    return " -> ".join(map(str, values)) + " -> NULL"


# =============================================================================
# TEST CASES
# =============================================================================

def test_remove_duplicates():
    print("=" * 60)
    print("REMOVE DUPLICATES (UNSORTED LIST) - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal duplicates
    print("\n--- Test Case 1: Normal Duplicates ---")
    values = [5, 2, 2, 4, 5, 1, 2]
    head = create_linked_list(values)
    print(f"Input:  {print_linked_list(head)}")

    result = remove_duplicates_hashset(head)
    print(f"Output: {print_linked_list(result)}")
    assert linked_list_to_list(result) == [5, 2, 4, 1]
    print("Assertion passed!")

    # Test Case 2: Two pointers approach
    print("\n--- Test Case 2: Two Pointers Approach ---")
    values = [1, 2, 1, 3, 2]
    head = create_linked_list(values)
    print(f"Input:  {print_linked_list(head)}")

    result = remove_duplicates_two_pointers(head)
    print(f"Output: {print_linked_list(result)}")
    assert linked_list_to_list(result) == [1, 2, 3]
    print("Assertion passed!")

    # Test Case 3: All same
    print("\n--- Test Case 3: All Same Values ---")
    values = [3, 3, 3, 3]
    head = create_linked_list(values)
    print(f"Input:  {print_linked_list(head)}")

    result = remove_duplicates_hashset(head)
    print(f"Output: {print_linked_list(result)}")
    assert linked_list_to_list(result) == [3]
    print("Assertion passed!")

    # Test Case 4: No duplicates
    print("\n--- Test Case 4: No Duplicates ---")
    values = [1, 2, 3, 4, 5]
    head = create_linked_list(values)
    print(f"Input:  {print_linked_list(head)}")

    result = remove_duplicates_hashset(head)
    print(f"Output: {print_linked_list(result)}")
    assert linked_list_to_list(result) == [1, 2, 3, 4, 5]
    print("Assertion passed!")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


if __name__ == "__main__":
    test_remove_duplicates()
