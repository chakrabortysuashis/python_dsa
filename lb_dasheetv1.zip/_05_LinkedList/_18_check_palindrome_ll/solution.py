"""
Check if Linked List is Palindrome
==================================

Problem: Given a singly linked list, determine if it is a palindrome.

Example:
    Input:  1 -> 2 -> 2 -> 1 -> NULL
    Output: True

    Input:  1 -> 2 -> 3 -> NULL
    Output: False
"""


class ListNode:
    """Definition for singly-linked list node."""
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

    def __repr__(self):
        return f"ListNode({self.val})"


# =============================================================================
# APPROACH 1: REVERSE SECOND HALF (Optimal - O(1) Space)
# =============================================================================

def is_palindrome(head: ListNode) -> bool:
    """
    Check if linked list is palindrome by reversing second half.

    Algorithm:
    1. Find middle using slow-fast pointers
    2. Reverse the second half
    3. Compare first half with reversed second half
    4. (Optional) Restore the list

    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    if head is None or head.next is None:
        return True

    # Step 1: Find middle
    slow = head
    fast = head

    while fast.next and fast.next.next:
        slow = slow.next
        fast = fast.next.next

    # slow is now at middle (for odd) or end of first half (for even)
    # Second half starts at slow.next

    # Step 2: Reverse second half
    second_half = reverse_list(slow.next)

    # Step 3: Compare
    first_half = head
    second_ptr = second_half

    result = True
    while second_ptr:  # Only compare up to length of second half
        if first_half.val != second_ptr.val:
            result = False
            break
        first_half = first_half.next
        second_ptr = second_ptr.next

    # Step 4: (Optional) Restore the list
    slow.next = reverse_list(second_half)

    return result


def reverse_list(head: ListNode) -> ListNode:
    """Helper function to reverse a linked list."""
    prev = None
    curr = head

    while curr:
        next_node = curr.next
        curr.next = prev
        prev = curr
        curr = next_node

    return prev


# =============================================================================
# APPROACH 2: USING STACK (O(n) Space)
# =============================================================================

def is_palindrome_stack(head: ListNode) -> bool:
    """
    Check palindrome using a stack.

    Algorithm:
    1. Push all values to stack
    2. Traverse list and compare with popped values

    Time Complexity: O(n)
    Space Complexity: O(n)
    """
    if head is None:
        return True

    # Push all values to stack
    stack = []
    current = head
    while current:
        stack.append(current.val)
        current = current.next

    # Compare with stack (reverse order)
    current = head
    while current:
        if current.val != stack.pop():
            return False
        current = current.next

    return True


# =============================================================================
# APPROACH 3: USING STACK FOR HALF (Optimized Stack)
# =============================================================================

def is_palindrome_half_stack(head: ListNode) -> bool:
    """
    Check palindrome by pushing only first half to stack.

    Algorithm:
    1. Find middle using slow-fast
    2. Push first half to stack during traversal
    3. Compare second half with stack

    Time Complexity: O(n)
    Space Complexity: O(n/2) = O(n)
    """
    if head is None or head.next is None:
        return True

    slow = head
    fast = head
    stack = []

    # Push first half to stack while finding middle
    while fast and fast.next:
        stack.append(slow.val)
        slow = slow.next
        fast = fast.next.next

    # If odd length, skip middle element
    if fast:  # fast is not None means odd length
        slow = slow.next

    # Compare second half with stack
    while slow:
        if slow.val != stack.pop():
            return False
        slow = slow.next

    return True


# =============================================================================
# APPROACH 4: RECURSIVE (O(n) Space for call stack)
# =============================================================================

class PalindromeChecker:
    """Recursive palindrome checker using a class to maintain state."""

    def __init__(self):
        self.front = None

    def is_palindrome_recursive(self, head: ListNode) -> bool:
        """
        Check palindrome recursively.

        Uses recursion to reach the end, then compares while unwinding.

        Time Complexity: O(n)
        Space Complexity: O(n) for recursion stack
        """
        self.front = head
        return self._check(head)

    def _check(self, node: ListNode) -> bool:
        if node is None:
            return True

        # Recurse to end
        if not self._check(node.next):
            return False

        # Compare current (from back) with front
        if self.front.val != node.val:
            return False

        # Move front forward
        self.front = self.front.next
        return True


def is_palindrome_recursive(head: ListNode) -> bool:
    """Wrapper for recursive approach."""
    checker = PalindromeChecker()
    return checker.is_palindrome_recursive(head)


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def create_linked_list(values: list) -> ListNode:
    """Create a linked list from a list of values."""
    if not values:
        return None

    head = ListNode(values[0])
    current = head

    for val in values[1:]:
        current.next = ListNode(val)
        current = current.next

    return head


def linked_list_to_list(head: ListNode) -> list:
    """Convert linked list to Python list."""
    result = []
    current = head

    while current:
        result.append(current.val)
        current = current.next

    return result


def print_linked_list(head: ListNode) -> str:
    """Print linked list in readable format."""
    values = linked_list_to_list(head)
    if not values:
        return "NULL"
    return " -> ".join(map(str, values)) + " -> NULL"


# =============================================================================
# TEST CASES
# =============================================================================

def test_is_palindrome():
    """Test palindrome checking implementations."""
    print("=" * 60)
    print("CHECK PALINDROME LINKED LIST - TEST CASES")
    print("=" * 60)

    # Test Case 1: Even length palindrome
    print("\n--- Test Case 1: [1,2,2,1] (even palindrome) ---")
    head = create_linked_list([1, 2, 2, 1])
    print(f"List: {print_linked_list(head)}")
    result = is_palindrome(head)
    print(f"Is palindrome: {result}")
    assert result == True
    print("Passed!")

    # Test Case 2: Odd length palindrome
    print("\n--- Test Case 2: [1,2,3,2,1] (odd palindrome) ---")
    head = create_linked_list([1, 2, 3, 2, 1])
    print(f"List: {print_linked_list(head)}")
    result = is_palindrome(head)
    print(f"Is palindrome: {result}")
    assert result == True
    print("Passed!")

    # Test Case 3: Not a palindrome
    print("\n--- Test Case 3: [1,2,3] (not palindrome) ---")
    head = create_linked_list([1, 2, 3])
    print(f"List: {print_linked_list(head)}")
    result = is_palindrome(head)
    print(f"Is palindrome: {result}")
    assert result == False
    print("Passed!")

    # Test Case 4: Single node
    print("\n--- Test Case 4: [1] (single node) ---")
    head = create_linked_list([1])
    print(f"List: {print_linked_list(head)}")
    result = is_palindrome(head)
    print(f"Is palindrome: {result}")
    assert result == True
    print("Passed!")

    # Test Case 5: Two same nodes
    print("\n--- Test Case 5: [1,1] (two same) ---")
    head = create_linked_list([1, 1])
    print(f"List: {print_linked_list(head)}")
    result = is_palindrome(head)
    print(f"Is palindrome: {result}")
    assert result == True
    print("Passed!")

    # Test Case 6: Two different nodes
    print("\n--- Test Case 6: [1,2] (two different) ---")
    head = create_linked_list([1, 2])
    print(f"List: {print_linked_list(head)}")
    result = is_palindrome(head)
    print(f"Is palindrome: {result}")
    assert result == False
    print("Passed!")

    # Test Case 7: Empty list
    print("\n--- Test Case 7: Empty list ---")
    head = None
    result = is_palindrome(head)
    print(f"Is palindrome: {result}")
    assert result == True
    print("Passed!")

    # Test Case 8: Stack approach
    print("\n--- Test Case 8: Stack approach [1,2,3,2,1] ---")
    head = create_linked_list([1, 2, 3, 2, 1])
    result = is_palindrome_stack(head)
    print(f"Is palindrome (stack): {result}")
    assert result == True
    print("Passed!")

    # Test Case 9: Half stack approach
    print("\n--- Test Case 9: Half stack approach [1,2,2,1] ---")
    head = create_linked_list([1, 2, 2, 1])
    result = is_palindrome_half_stack(head)
    print(f"Is palindrome (half stack): {result}")
    assert result == True
    print("Passed!")

    # Test Case 10: Recursive approach
    print("\n--- Test Case 10: Recursive approach [1,2,1] ---")
    head = create_linked_list([1, 2, 1])
    result = is_palindrome_recursive(head)
    print(f"Is palindrome (recursive): {result}")
    assert result == True
    print("Passed!")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_algorithm():
    """Demonstrate the reverse half algorithm step by step."""
    print("\n" + "=" * 60)
    print("STEP-BY-STEP DEMONSTRATION")
    print("=" * 60)

    print("\nChecking if [1,2,2,1] is a palindrome:")
    print()
    print("Original: 1 -> 2 -> 2 -> 1 -> NULL")
    print()
    print("Step 1: Find middle using slow-fast")
    print("  slow=1, fast=1")
    print("  slow=2, fast=2(second)")
    print("  fast.next.next is NULL, stop")
    print("  Middle = node at position 1 (value 2)")
    print()
    print("Step 2: Second half starts at slow.next")
    print("  Second half: 2 -> 1 -> NULL")
    print()
    print("Step 3: Reverse second half")
    print("  Before: 2 -> 1 -> NULL")
    print("  After:  1 -> 2 -> NULL")
    print()
    print("Step 4: Compare first half with reversed second half")
    print("  First:    1 -> 2")
    print("  Reversed: 1 -> 2")
    print("  Compare: 1==1 (yes), 2==2 (yes)")
    print()
    print("Result: PALINDROME!")


if __name__ == "__main__":
    test_is_palindrome()
    demonstrate_algorithm()
