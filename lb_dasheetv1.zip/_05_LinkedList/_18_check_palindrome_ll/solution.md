# Check if Linked List is Palindrome

## Problem Statement

Given a singly linked list, determine if it is a palindrome.

**Example:**
```
Input:  1 -> 2 -> 2 -> 1 -> NULL
Output: True (reads same forward and backward)

Input:  1 -> 2 -> 3 -> NULL
Output: False
```

---

## Intuition

### What is a Palindrome?

```
A palindrome reads the same forwards and backwards.

Palindrome:     1 -> 2 -> 3 -> 2 -> 1
Forward:        1, 2, 3, 2, 1
Backward:       1, 2, 3, 2, 1
                Same!

Not palindrome: 1 -> 2 -> 3 -> 4 -> 5
Forward:        1, 2, 3, 4, 5
Backward:       5, 4, 3, 2, 1
                Different!
```

### Key Insight

```
To check palindrome, we need to compare:
- First half with reversed second half

Strategy:
1. Find middle of list
2. Reverse second half
3. Compare first half with reversed second half
4. (Optional) Restore list to original
```

---

## Approaches

### Approach 1: Using Stack (Extra Space)

```
Push all elements to stack, then compare:

List: 1 -> 2 -> 2 -> 1
Stack (after push): [1, 2, 2, 1] (top = 1)

Compare:
Position 0: list[0]=1, stack.pop()=1 -> match
Position 1: list[1]=2, stack.pop()=2 -> match
Position 2: list[2]=2, stack.pop()=2 -> match
Position 3: list[3]=1, stack.pop()=1 -> match

All match -> Palindrome!

Time: O(n), Space: O(n)
```

### Approach 2: Reverse Second Half (Optimal)

```
1. Find middle using slow-fast
2. Reverse second half
3. Compare both halves
4. Restore (optional)

List: 1 -> 2 -> 3 -> 2 -> 1

Step 1: Find middle (node 3)
First half:  1 -> 2 -> 3
Second half: 2 -> 1

Step 2: Reverse second half
Second half: 1 -> 2

Step 3: Compare
1 == 1? Yes
2 == 2? Yes
3 has no pair (middle, skip for odd length)

Palindrome!

Time: O(n), Space: O(1)
```

---

## Visual Walkthrough

### Example: 1 -> 2 -> 2 -> 1 (Even Length)

```
Original: [1] -> [2] -> [2] -> [1] -> NULL

Step 1: Find middle using slow-fast
        slow=1, fast=1
        slow=2, fast=2 (second one)
        fast.next is NULL, stop
        Middle = slow = node 2 (first occurrence)

Step 2: Split at middle
        First half:  [1] -> [2]
        Second half: [2] -> [1]

Step 3: Reverse second half
        Before: [2] -> [1] -> NULL
        After:  [1] -> [2] -> NULL

Step 4: Compare
        First:    [1] -> [2]
        Reversed: [1] -> [2]

        Compare node by node:
        1 == 1? Yes
        2 == 2? Yes

Result: PALINDROME!
```

### Example: 1 -> 2 -> 3 -> 2 -> 1 (Odd Length)

```
Original: [1] -> [2] -> [3] -> [2] -> [1] -> NULL

Step 1: Find middle (node 3)
        slow at 3 when fast reaches end

Step 2: Second half starts AFTER middle
        First half:  [1] -> [2] -> [3]
        Second half: [2] -> [1]

Step 3: Reverse second half
        Before: [2] -> [1] -> NULL
        After:  [1] -> [2] -> NULL

Step 4: Compare (only up to length of shorter half)
        First:    [1] -> [2]
        Reversed: [1] -> [2]

        1 == 1? Yes
        2 == 2? Yes

Result: PALINDROME!
```

### Example: 1 -> 2 -> 3 (Not Palindrome)

```
Original: [1] -> [2] -> [3] -> NULL

Step 1: Find middle (node 2)

Step 2: Second half: [3]

Step 3: Reverse second half: [3] (single node, same)

Step 4: Compare
        First:    [1]
        Reversed: [3]

        1 == 3? NO!

Result: NOT PALINDROME!
```

---

## Dry Run

### Input: [1, 2, 2, 1]

| Step | Action | State |
|------|--------|-------|
| 1 | Find middle | slow at index 1 (value 2) |
| 2 | Get second half | [2, 1] |
| 3 | Reverse second half | [1, 2] |
| 4 | Compare | 1==1, 2==2 |
| Result | All match | **PALINDROME** |

---

## Complexity Analysis

| Approach | Time | Space |
|----------|------|-------|
| Stack | O(n) | O(n) |
| Reverse half | O(n) | O(1) |
| Recursion | O(n) | O(n) |

```
Reverse half approach breakdown:
- Find middle: O(n/2)
- Reverse half: O(n/2)
- Compare: O(n/2)
- Total: O(n)
- Space: O(1) - only pointers
```

---

## Edge Cases

```
1. Empty list:      NULL -> True (vacuously palindrome)
2. Single node:     [1] -> True
3. Two same:        [1] -> [1] -> True
4. Two different:   [1] -> [2] -> False
5. Even palindrome: [1,2,2,1] -> True
6. Odd palindrome:  [1,2,1] -> True
```

---

## Key Takeaways

1. **Find middle** is the first step (slow-fast pointer)
2. **Reverse second half** allows O(1) space comparison
3. For **odd length**, middle element doesn't need comparison
4. Consider **restoring** list if modification not allowed
5. Stack approach is simpler but uses **O(n) space**
