# Intersection of Two Sorted Linked Lists

## Problem Statement

Given two sorted linked lists, find the intersection (common elements) and return as a new linked list.

**Example:**
```
Input:
  List1: 1 -> 2 -> 3 -> 4 -> 6 -> NULL
  List2: 2 -> 4 -> 6 -> 8 -> NULL

Output: 2 -> 4 -> 6 -> NULL
```

---

## Intuition

Since both lists are **sorted**, we can use a **two-pointer** approach similar to merging sorted arrays.

### Key Insight

At each step, compare current nodes:
- If equal: add to result, advance both
- If L1 < L2: advance L1 (L1's current can't match anything)
- If L1 > L2: advance L2 (L2's current can't match anything)

---

## Visual Walkthrough

```
L1: 1 -> 2 -> 3 -> 4 -> 6
    ^
L2: 2 -> 4 -> 6 -> 8
    ^

Step 1: 1 < 2, advance L1
L1: 1 -> 2 -> 3 -> 4 -> 6
         ^
L2: 2 -> 4 -> 6 -> 8
    ^

Step 2: 2 == 2, add to result, advance both
Result: 2
L1: 1 -> 2 -> 3 -> 4 -> 6
              ^
L2: 2 -> 4 -> 6 -> 8
         ^

Step 3: 3 < 4, advance L1
L1: 1 -> 2 -> 3 -> 4 -> 6
                   ^
L2: 2 -> 4 -> 6 -> 8
         ^

Step 4: 4 == 4, add to result, advance both
Result: 2 -> 4
L1: 1 -> 2 -> 3 -> 4 -> 6
                        ^
L2: 2 -> 4 -> 6 -> 8
              ^

Step 5: 6 == 6, add to result, advance both
Result: 2 -> 4 -> 6
```

---

## Algorithm

```
1. Initialize two pointers at heads
2. While both pointers are valid:
   - If values equal: add to result, move both
   - If L1 < L2: move L1
   - Else: move L2
3. Return result
```

---

## Complexity

- **Time:** O(m + n) - single pass through both lists
- **Space:** O(min(m, n)) - result list

---

## Edge Cases

1. **No common elements:** Return empty list
2. **One list empty:** Return empty list
3. **Identical lists:** Return copy of either list
4. **Duplicates:** Handle based on requirements
