"""
Intersection of Two Sorted Linked Lists
========================================

Problem: Given two sorted linked lists, find their intersection
         (common elements) and return as a new sorted linked list.

Example:
    Input:  List1: 1 -> 2 -> 3 -> 4 -> 6
            List2: 2 -> 4 -> 6 -> 8
    Output: 2 -> 4 -> 6
"""


class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next


def get_intersection(head1: ListNode, head2: ListNode) -> ListNode:
    """
    Find intersection of two sorted linked lists using two pointers.

    Algorithm:
    - Use two pointers, one for each list
    - If values equal: add to result, advance both
    - If L1 < L2: advance L1 (can't match)
    - If L1 > L2: advance L2 (can't match)

    Time: O(m + n)
    Space: O(min(m, n)) for result list
    """
    dummy = ListNode(0)
    tail = dummy

    ptr1 = head1
    ptr2 = head2

    while ptr1 and ptr2:
        if ptr1.val == ptr2.val:
            # Match found - add to result
            tail.next = ListNode(ptr1.val)
            tail = tail.next
            ptr1 = ptr1.next
            ptr2 = ptr2.next
        elif ptr1.val < ptr2.val:
            # L1's value is smaller, advance L1
            ptr1 = ptr1.next
        else:
            # L2's value is smaller, advance L2
            ptr2 = ptr2.next

    return dummy.next


def get_intersection_recursive(head1: ListNode, head2: ListNode) -> ListNode:
    """
    Recursive approach for intersection.

    Time: O(m + n)
    Space: O(m + n) for recursion stack
    """
    if not head1 or not head2:
        return None

    if head1.val == head2.val:
        node = ListNode(head1.val)
        node.next = get_intersection_recursive(head1.next, head2.next)
        return node
    elif head1.val < head2.val:
        return get_intersection_recursive(head1.next, head2)
    else:
        return get_intersection_recursive(head1, head2.next)


# =============================================================================
# HELPER FUNCTIONS AND TESTS
# =============================================================================

def create_linked_list(values):
    if not values:
        return None
    head = ListNode(values[0])
    curr = head
    for val in values[1:]:
        curr.next = ListNode(val)
        curr = curr.next
    return head


def linked_list_to_list(head):
    result = []
    while head:
        result.append(head.val)
        head = head.next
    return result


def test_intersection():
    print("=" * 60)
    print("INTERSECTION OF SORTED LISTS - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal intersection
    print("\n--- Test Case 1: Normal Intersection ---")
    l1 = create_linked_list([1, 2, 3, 4, 6])
    l2 = create_linked_list([2, 4, 6, 8])
    result = get_intersection(l1, l2)
    print(f"List1: [1, 2, 3, 4, 6]")
    print(f"List2: [2, 4, 6, 8]")
    print(f"Intersection: {linked_list_to_list(result)}")
    assert linked_list_to_list(result) == [2, 4, 6]
    print("Assertion passed!")

    # Test Case 2: No common elements
    print("\n--- Test Case 2: No Common Elements ---")
    l1 = create_linked_list([1, 3, 5])
    l2 = create_linked_list([2, 4, 6])
    result = get_intersection(l1, l2)
    print(f"Intersection: {linked_list_to_list(result)}")
    assert linked_list_to_list(result) == []
    print("Assertion passed!")

    # Test Case 3: Identical lists
    print("\n--- Test Case 3: Identical Lists ---")
    l1 = create_linked_list([1, 2, 3])
    l2 = create_linked_list([1, 2, 3])
    result = get_intersection(l1, l2)
    print(f"Intersection: {linked_list_to_list(result)}")
    assert linked_list_to_list(result) == [1, 2, 3]
    print("Assertion passed!")

    # Test Case 4: One empty list
    print("\n--- Test Case 4: One Empty List ---")
    l1 = create_linked_list([1, 2, 3])
    l2 = None
    result = get_intersection(l1, l2)
    print(f"Intersection: {linked_list_to_list(result)}")
    assert linked_list_to_list(result) == []
    print("Assertion passed!")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


if __name__ == "__main__":
    test_intersection()
