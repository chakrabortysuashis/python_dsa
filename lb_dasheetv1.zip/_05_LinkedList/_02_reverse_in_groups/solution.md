# Reverse a Linked List in Groups of Given Size

## Problem Statement

Given a linked list and an integer `k`, reverse the nodes of the linked list `k` at a time and return the modified list.

**Example:**
```
Input:  1 -> 2 -> 3 -> 4 -> 5 -> 6 -> 7 -> 8 -> NULL, k = 3
Output: 3 -> 2 -> 1 -> 6 -> 5 -> 4 -> 7 -> 8 -> NULL

Explanation:
- First group [1,2,3] reversed to [3,2,1]
- Second group [4,5,6] reversed to [6,5,4]
- Third group [7,8] has only 2 nodes (< k), left as is
```

---

## Intuition

### Understanding the Problem

We need to reverse the list in chunks of size `k`. Each chunk is reversed independently, then connected to the next chunk.

```
Original: [1] -> [2] -> [3] -> [4] -> [5] -> [6] -> [7] -> [8]
          |____Group 1____|   |____Group 2____|   |_Group 3_|

After:    [3] -> [2] -> [1] -> [6] -> [5] -> [4] -> [7] -> [8]
          |____Reversed___|   |____Reversed___|   |_Not enough_|
```

### Key Insight

1. We need to reverse `k` nodes at a time
2. Track where each group starts and ends
3. Connect reversed groups properly
4. Handle the case when remaining nodes < k

---

## Approach 1: Iterative

### Algorithm

```
1. Count nodes to check if we have at least k nodes
2. Reverse k nodes
3. Recursively/iteratively handle the rest
4. Connect the groups
```

### Visual Walkthrough

**Input:** 1 -> 2 -> 3 -> 4 -> 5 -> NULL, k = 2

```
Step 1: Identify first group (2 nodes)
[1] -> [2] -> [3] -> [4] -> [5]
|__group__|

Step 2: Reverse first group
Before: [1] -> [2] -> [3] -> [4] -> [5]
After:  [2] -> [1]    [3] -> [4] -> [5]
              |
         first_group_end (connects to rest)

Step 3: Process next group
[2] -> [1] -> [4] -> [3] -> [5]
              |__group__|

Step 4: Process last group (only 1 node, don't reverse)
[2] -> [1] -> [4] -> [3] -> [5]

Final: 2 -> 1 -> 4 -> 3 -> 5 -> NULL
```

### Detailed Pointer Manipulation

```
k = 3, List: 1 -> 2 -> 3 -> 4 -> 5 -> 6 -> NULL

Initial:
prev_group_end = None
current = head (1)

Processing Group 1 [1, 2, 3]:

Before reversal:
    NULL   [1] -> [2] -> [3] -> [4] -> ...
     ^      ^
   prev   curr
   
After reversing k nodes:
    [3] -> [2] -> [1]    [4] -> ...
     ^             ^      ^
  new_head   group_end  next_group

Connect:
- prev_group_end.next = new_head (for subsequent groups)
- group_end.next = next_group (will be updated later)

Update for next iteration:
    prev_group_end = [1]  (the end of reversed group)
    current = [4]
```

### Complexity
- **Time:** O(n) - each node is processed once
- **Space:** O(1) - iterative approach uses constant space

---

## Approach 2: Recursive

### Concept

1. Reverse first k nodes
2. Recursively reverse the rest
3. Connect them

### Recursion Tree

```
reverseKGroup([1,2,3,4,5], k=2)
    |
    +-- Reverse [1,2] -> [2,1]
    +-- reverseKGroup([3,4,5], k=2)
            |
            +-- Reverse [3,4] -> [4,3]
            +-- reverseKGroup([5], k=2)
                    |
                    +-- count < k, return [5]
            +-- Connect [4,3] -> [5]
            +-- Return [4,3,5]
    +-- Connect [2,1] -> [4,3,5]
    +-- Return [2,1,4,3,5]
```

### Complexity
- **Time:** O(n)
- **Space:** O(n/k) for recursion stack

---

## Dry Run

### Iterative Approach

**Input:** 1 -> 2 -> 3 -> 4 -> 5 -> NULL, k = 2

| Step | Current Group | Action | Result |
|------|--------------|--------|--------|
| 1 | [1, 2] | Reverse | 2 -> 1 |
| 2 | [3, 4] | Reverse | 4 -> 3 |
| 3 | [5] | count < k, keep | 5 |
| Connect | - | Link groups | 2->1->4->3->5->NULL |

**Output:** 2 -> 1 -> 4 -> 3 -> 5 -> NULL

### Pointer States

```
Initial:
dummy -> [1] -> [2] -> [3] -> [4] -> [5] -> NULL
  ^
prev_end

After reversing [1,2]:
dummy -> [2] -> [1] -> [3] -> [4] -> [5] -> NULL
                  ^
              prev_end

After reversing [3,4]:
dummy -> [2] -> [1] -> [4] -> [3] -> [5] -> NULL
                                ^
                            prev_end

[5] alone, count < k, stop.

Final: 2 -> 1 -> 4 -> 3 -> 5 -> NULL
```

---

## Edge Cases

1. **k = 1:** No reversal needed (each group is single node)
2. **k >= length:** Reverse entire list (or keep as is if "don't reverse when < k")
3. **Empty list:** Return NULL
4. **k = 0:** Invalid, typically return list as is

```
k = 1:  1 -> 2 -> 3  =>  1 -> 2 -> 3 (no change)
k = 5:  1 -> 2 -> 3  =>  1 -> 2 -> 3 (count < k, no change)
        OR  3 -> 2 -> 1 (if reversing partial groups)
```

---

## Variant: Reverse Even Partial Groups

Some versions require reversing even when fewer than k nodes remain.

```
Input: 1 -> 2 -> 3 -> 4 -> 5, k = 3
With partial reversal:    3 -> 2 -> 1 -> 5 -> 4
Without partial reversal: 3 -> 2 -> 1 -> 4 -> 5
```

---

## Key Takeaways

1. **Dummy node technique** simplifies handling the head
2. **Track group boundaries** - know where each group starts and ends
3. **Count before reverse** - check if k nodes exist
4. **Connect groups carefully** - the end of one group connects to the start of the next
