"""
Reverse a Linked List in Groups of Given Size
==============================================

Problem: Given a linked list and an integer k, reverse the nodes of the
         linked list k at a time and return the modified list.

Example:
    Input:  1 -> 2 -> 3 -> 4 -> 5 -> 6 -> 7 -> 8, k = 3
    Output: 3 -> 2 -> 1 -> 6 -> 5 -> 4 -> 7 -> 8

    Explanation:
    - [1,2,3] reversed to [3,2,1]
    - [4,5,6] reversed to [6,5,4]
    - [7,8] has < 3 nodes, left as is
"""


class ListNode:
    """Definition for singly-linked list node."""
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

    def __repr__(self):
        return f"ListNode({self.val})"


# =============================================================================
# APPROACH 1: ITERATIVE
# =============================================================================

def reverse_k_group_iterative(head: ListNode, k: int) -> ListNode:
    """
    Reverse linked list in groups of k nodes using iterative approach.

    Algorithm:
    1. Use a dummy node to simplify edge cases
    2. For each group:
       a. Check if k nodes exist
       b. Reverse those k nodes
       c. Connect with previous and next groups
    3. Repeat until end of list

    Visual Example (k=3):

    Initial:  dummy -> [1] -> [2] -> [3] -> [4] -> [5] -> [6] -> [7] -> [8]
                ^
           prev_group_end

    After 1st group:
              dummy -> [3] -> [2] -> [1] -> [4] -> [5] -> [6] -> [7] -> [8]
                                      ^
                                 prev_group_end

    After 2nd group:
              dummy -> [3] -> [2] -> [1] -> [6] -> [5] -> [4] -> [7] -> [8]
                                                          ^
                                                     prev_group_end

    Time Complexity: O(n) - each node visited at most twice
    Space Complexity: O(1) - only pointers used
    """
    if not head or k <= 1:
        return head

    # Dummy node to handle head changes easily
    dummy = ListNode(0)
    dummy.next = head

    # prev_group_end points to the node before the current group
    prev_group_end = dummy

    while True:
        # Step 1: Check if k nodes exist from current position
        kth_node = get_kth_node(prev_group_end, k)

        if not kth_node:
            # Less than k nodes remaining, we're done
            break

        # Save the start of next group
        next_group_start = kth_node.next

        # Step 2: Reverse k nodes
        # group_start is the first node of current group
        group_start = prev_group_end.next

        # Reverse nodes from group_start to kth_node
        prev, curr = kth_node.next, group_start

        while curr != next_group_start:
            next_temp = curr.next
            curr.next = prev
            prev = curr
            curr = next_temp

        # Step 3: Connect with previous group
        # After reversal:
        # - prev is now the new first node (was kth_node)
        # - group_start is now the last node of reversed group

        # Connect previous group to reversed group's new head
        temp = prev_group_end.next  # Save original group_start
        prev_group_end.next = kth_node  # Connect to new head (kth_node)

        # Move prev_group_end to end of current reversed group
        prev_group_end = temp  # temp is now at the end of reversed group

    return dummy.next


def get_kth_node(start: ListNode, k: int) -> ListNode:
    """Helper function to get the kth node from start."""
    curr = start
    for _ in range(k):
        if not curr:
            return None
        curr = curr.next
    return curr


# =============================================================================
# APPROACH 2: RECURSIVE
# =============================================================================

def reverse_k_group_recursive(head: ListNode, k: int) -> ListNode:
    """
    Reverse linked list in groups of k nodes using recursion.

    Algorithm:
    1. Check if k nodes exist
    2. Reverse first k nodes
    3. Recursively reverse the rest
    4. Connect first group to result of recursive call

    Recursion Tree for [1,2,3,4,5], k=2:

    reverseKGroup([1,2,3,4,5])
        |
        +-- Count: 5 >= 2, proceed
        +-- Reverse [1,2] -> [2,1]
        +-- reverseKGroup([3,4,5])
                |
                +-- Count: 3 >= 2, proceed
                +-- Reverse [3,4] -> [4,3]
                +-- reverseKGroup([5])
                        |
                        +-- Count: 1 < 2, return [5]
                +-- Connect: [4,3] -> [5]
                +-- Return [4,3,5]
        +-- Connect: [2,1] -> [4,3,5]
        +-- Return [2,1,4,3,5]

    Time Complexity: O(n)
    Space Complexity: O(n/k) for recursion stack
    """
    if not head or k <= 1:
        return head

    # Step 1: Count if we have k nodes
    count = 0
    curr = head
    while curr and count < k:
        curr = curr.next
        count += 1

    # If we don't have k nodes, return head as is
    if count < k:
        return head

    # Step 2: Reverse first k nodes
    # After this, prev will be the new head, head will be the tail
    prev = None
    curr = head
    for _ in range(k):
        next_temp = curr.next
        curr.next = prev
        prev = curr
        curr = next_temp

    # Step 3: Recursively reverse the rest
    # curr is now pointing to (k+1)th node
    # head is now the last node of the reversed group
    head.next = reverse_k_group_recursive(curr, k)

    # Step 4: Return prev (new head of this group)
    return prev


# =============================================================================
# APPROACH 3: REVERSE EVEN PARTIAL GROUPS
# =============================================================================

def reverse_k_group_with_partial(head: ListNode, k: int) -> ListNode:
    """
    Variant: Reverse all groups including partial groups at the end.

    Example:
        Input:  1 -> 2 -> 3 -> 4 -> 5, k = 3
        Output: 3 -> 2 -> 1 -> 5 -> 4 (partial group [4,5] also reversed)
    """
    if not head or k <= 1:
        return head

    # Count nodes in current group
    count = 0
    curr = head
    while curr and count < k:
        curr = curr.next
        count += 1

    # Reverse current group (even if less than k)
    prev = None
    curr = head
    nodes_to_reverse = count

    for _ in range(nodes_to_reverse):
        next_temp = curr.next
        curr.next = prev
        prev = curr
        curr = next_temp

    # Recursively handle rest
    if curr:
        head.next = reverse_k_group_with_partial(curr, k)

    return prev


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def create_linked_list(values: list) -> ListNode:
    """Create a linked list from a list of values."""
    if not values:
        return None

    head = ListNode(values[0])
    current = head

    for val in values[1:]:
        current.next = ListNode(val)
        current = current.next

    return head


def linked_list_to_list(head: ListNode) -> list:
    """Convert linked list to Python list."""
    result = []
    current = head

    while current:
        result.append(current.val)
        current = current.next

    return result


def print_linked_list(head: ListNode) -> str:
    """Print linked list in readable format."""
    values = linked_list_to_list(head)
    return " -> ".join(map(str, values)) + " -> NULL"


# =============================================================================
# TEST CASES
# =============================================================================

def test_reverse_k_group():
    """Test reverse k group implementations."""
    print("=" * 60)
    print("REVERSE LINKED LIST IN K GROUPS - TEST CASES")
    print("=" * 60)

    # Test Case 1: k = 3
    print("\n--- Test Case 1: k = 3 ---")
    values = [1, 2, 3, 4, 5, 6, 7, 8]
    k = 3

    head1 = create_linked_list(values)
    print(f"Original: {print_linked_list(head1)}")
    print(f"k = {k}")

    result1 = reverse_k_group_iterative(head1, k)
    print(f"Result (iterative): {print_linked_list(result1)}")

    head2 = create_linked_list(values)
    result2 = reverse_k_group_recursive(head2, k)
    print(f"Result (recursive): {print_linked_list(result2)}")

    expected = [3, 2, 1, 6, 5, 4, 7, 8]
    assert linked_list_to_list(result1) == expected
    assert linked_list_to_list(result2) == expected
    print("Assertions passed!")

    # Test Case 2: k = 2
    print("\n--- Test Case 2: k = 2 ---")
    values = [1, 2, 3, 4, 5]
    k = 2

    head = create_linked_list(values)
    print(f"Original: {print_linked_list(head)}")
    print(f"k = {k}")

    result = reverse_k_group_iterative(head, k)
    print(f"Result: {print_linked_list(result)}")

    expected = [2, 1, 4, 3, 5]
    assert linked_list_to_list(result) == expected
    print("Assertion passed!")

    # Test Case 3: k = 1 (no change)
    print("\n--- Test Case 3: k = 1 (no change) ---")
    values = [1, 2, 3]
    k = 1

    head = create_linked_list(values)
    print(f"Original: {print_linked_list(head)}")
    print(f"k = {k}")

    result = reverse_k_group_iterative(head, k)
    print(f"Result: {print_linked_list(result)}")

    expected = [1, 2, 3]
    assert linked_list_to_list(result) == expected
    print("Assertion passed!")

    # Test Case 4: k > length
    print("\n--- Test Case 4: k > length ---")
    values = [1, 2]
    k = 5

    head = create_linked_list(values)
    print(f"Original: {print_linked_list(head)}")
    print(f"k = {k}")

    result = reverse_k_group_iterative(head, k)
    print(f"Result: {print_linked_list(result)}")

    expected = [1, 2]  # No change since we don't have k nodes
    assert linked_list_to_list(result) == expected
    print("Assertion passed!")

    # Test Case 5: With partial group reversal
    print("\n--- Test Case 5: With Partial Group Reversal ---")
    values = [1, 2, 3, 4, 5]
    k = 3

    head = create_linked_list(values)
    print(f"Original: {print_linked_list(head)}")
    print(f"k = {k}")

    result = reverse_k_group_with_partial(head, k)
    print(f"Result (with partial): {print_linked_list(result)}")

    expected = [3, 2, 1, 5, 4]  # [4,5] also reversed
    assert linked_list_to_list(result) == expected
    print("Assertion passed!")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_step_by_step():
    """Show step-by-step execution."""
    print("\n" + "=" * 60)
    print("STEP-BY-STEP DEMONSTRATION")
    print("=" * 60)

    values = [1, 2, 3, 4, 5, 6, 7]
    k = 3

    print(f"\nOriginal list: {' -> '.join(map(str, values))} -> NULL")
    print(f"k = {k}")
    print("\nProcess:")

    # Group the list
    groups = []
    for i in range(0, len(values), k):
        group = values[i:i+k]
        groups.append(group)

    print(f"\nGroups identified: {groups}")

    result = []
    for i, group in enumerate(groups):
        print(f"\nGroup {i+1}: {group}")
        if len(group) == k:
            reversed_group = group[::-1]
            print(f"  Has {k} nodes -> Reverse: {reversed_group}")
            result.extend(reversed_group)
        else:
            print(f"  Has {len(group)} nodes (< {k}) -> Keep as is: {group}")
            result.extend(group)

    print(f"\nFinal result: {' -> '.join(map(str, result))} -> NULL")


if __name__ == "__main__":
    test_reverse_k_group()
    demonstrate_step_by_step()
