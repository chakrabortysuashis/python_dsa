# Split Circular Linked List into Two Halves

## Problem Statement

Given a circular linked list, split it into two halves. If the list has odd number of nodes, the first half should have one extra node.

**Example:**
```
Input:  1 -> 2 -> 3 -> 4 -> 5 -> (back to 1)

Output:
  First half:  1 -> 2 -> 3 -> (back to 1)
  Second half: 4 -> 5 -> (back to 4)

For even length:
Input:  1 -> 2 -> 3 -> 4 -> (back to 1)

Output:
  First half:  1 -> 2 -> (back to 1)
  Second half: 3 -> 4 -> (back to 3)
```

---

## Intuition

### Key Steps

```
1. Find the middle of the circular list
2. Find the last node (node before head in circular)
3. Split into two circular lists

Challenge: In circular list, there's no NULL to indicate end!
Solution: Use slow-fast pointers, stop when fast reaches head or node before head.
```

### Visual Understanding

```
Circular List: 1 -> 2 -> 3 -> 4 -> 5 -+
               ^                      |
               |______________________|

Find middle using slow-fast:
slow at 3, fast back at 1 (completed circle)

Find last node (5):
Traverse until node.next == head

Split:
First half:  1 -> 2 -> 3 -> (back to 1)
             Make node 3 point to node 1

Second half: 4 -> 5 -> (back to 4)
             Make node 5 point to node 4
```

---

## Algorithm

### Step-by-Step

```
1. Handle edge cases (empty or single node)

2. Find middle using slow-fast pointers:
   - slow moves 1 step
   - fast moves 2 steps
   - Stop when fast.next == head or fast.next.next == head

3. Set up second half:
   - head2 = slow.next (start of second half)

4. Find last node of original list:
   - Traverse from head2 until node.next == head

5. Split and make both circular:
   - slow.next = head (first half becomes circular)
   - last.next = head2 (second half becomes circular)

6. Return both heads
```

---

## Visual Walkthrough

### Example: [1, 2, 3, 4, 5] (Odd Length)

```
Initial circular list:
     +------------------------+
     |                        |
     v                        |
    [1] -> [2] -> [3] -> [4] -> [5]
     ^
    head

Step 1: Find middle with slow-fast
    slow = head, fast = head

    Iteration 1:
    slow = 2, fast = 3

    Iteration 2:
    slow = 3, fast = 5

    Check: fast.next == head (5.next == 1)? Yes, stop!
    Middle = slow = node 3

Step 2: Set up second half
    head2 = slow.next = node 4

Step 3: Find last node
    Start from head2 (node 4)
    4.next = 5, 5.next = head (1)
    Last = node 5

Step 4: Split and make circular
    slow.next = head (3 -> 1)
    last.next = head2 (5 -> 4)

Result:
    First half:  [1] -> [2] -> [3] -> (back to 1)
    Second half: [4] -> [5] -> (back to 4)
```

### Example: [1, 2, 3, 4] (Even Length)

```
Initial:
     +-------------------+
     |                   |
     v                   |
    [1] -> [2] -> [3] -> [4]

Slow-fast:
    Iteration 1: slow=2, fast=3
    Iteration 2: slow=3, fast=1 (fast.next.next == head)
    Wait, we need to stop earlier for even!

    Actually for even, stop when fast.next.next == head
    slow=2 is middle point for split

    head2 = slow.next = node 3
    Last = node 4

Result:
    First half:  [1] -> [2] -> (back to 1)
    Second half: [3] -> [4] -> (back to 3)
```

---

## Dry Run

### Input: Circular [1, 2, 3, 4, 5]

| Step | slow | fast | Action |
|------|------|------|--------|
| Init | 1 | 1 | Start |
| 1 | 2 | 3 | Move |
| 2 | 3 | 5 | 5.next = 1 = head, stop |
| Split | - | - | head2 = 4, last = 5 |
| Final | - | - | 3->1, 5->4 |

**Result:**
- First: 1 -> 2 -> 3 -> 1
- Second: 4 -> 5 -> 4

---

## Complexity Analysis

| Aspect | Complexity |
|--------|------------|
| Time | O(n) |
| Space | O(1) |

```
Time breakdown:
- Finding middle: O(n/2)
- Finding last node: O(n/2)
- Total: O(n)

Space: Only using pointers, no extra data structures
```

---

## Edge Cases

```
1. Empty list (head = NULL):
   Return NULL, NULL

2. Single node (1 -> back to 1):
   Cannot split meaningfully
   Return original, NULL (or handle specially)

3. Two nodes (1 -> 2 -> back to 1):
   First half: 1 -> back to 1
   Second half: 2 -> back to 2

4. Odd vs Even:
   Odd (5 nodes): First gets 3, Second gets 2
   Even (4 nodes): First gets 2, Second gets 2
```

---

## Key Takeaways

1. **Slow-fast works for circular** lists with modified stop condition
2. Stop when **fast reaches head** (not NULL)
3. Need to **find last node** separately to complete second circle
4. Both resulting lists must be **made circular**
5. Handle **odd/even** lengths correctly
