"""
Split Circular Linked List into Two Halves
==========================================

Problem: Given a circular linked list, split it into two halves.
         If odd number of nodes, first half gets the extra node.

Example:
    Input:  1 -> 2 -> 3 -> 4 -> 5 -> (back to 1)
    Output: First:  1 -> 2 -> 3 -> (back to 1)
            Second: 4 -> 5 -> (back to 4)
"""


class ListNode:
    """Definition for circular linked list node."""
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

    def __repr__(self):
        return f"ListNode({self.val})"


# =============================================================================
# MAIN SOLUTION
# =============================================================================

def split_circular_list(head: ListNode) -> tuple:
    """
    Split circular linked list into two halves.

    Algorithm:
    1. Use slow-fast pointers to find middle
    2. For circular list, stop when fast.next reaches head
    3. Split at middle and make both halves circular

    Time Complexity: O(n)
    Space Complexity: O(1)

    Returns:
        Tuple of (head1, head2) - heads of the two circular halves
    """
    # Edge case: empty or single node
    if head is None:
        return None, None

    if head.next == head:
        # Single node circular list - can't split
        return head, None

    # Find middle using slow-fast pointers
    slow = head
    fast = head

    # Move until fast completes the circle
    # For odd length: fast.next == head
    # For even length: fast.next.next == head
    while fast.next != head and fast.next.next != head:
        slow = slow.next
        fast = fast.next.next

    # For even length, move slow one more step
    # to get the correct split point
    if fast.next.next == head:
        slow = slow.next

    # Now slow is at the end of first half
    # head2 starts at slow.next
    head2 = slow.next

    # Find the last node (the one pointing to original head)
    last = head2
    while last.next != head:
        last = last.next

    # Split the list
    # First half: head to slow, make it circular
    slow.next = head

    # Second half: head2 to last, make it circular
    last.next = head2

    return head, head2


# =============================================================================
# ALTERNATIVE: MORE EXPLICIT VERSION
# =============================================================================

def split_circular_list_v2(head: ListNode) -> tuple:
    """
    Alternative implementation with clearer logic.

    Steps:
    1. Count total nodes
    2. Find middle point
    3. Traverse to middle
    4. Split and make circular
    """
    if head is None:
        return None, None

    if head.next == head:
        return head, None

    # Count nodes
    count = 1
    current = head.next
    while current != head:
        count += 1
        current = current.next

    # Calculate split point
    # For odd (5): first gets 3, second gets 2
    # For even (4): first gets 2, second gets 2
    first_half_size = (count + 1) // 2

    # Traverse to end of first half
    current = head
    for _ in range(first_half_size - 1):
        current = current.next

    # current is now the last node of first half
    head2 = current.next

    # Find last node (points back to head)
    last = head2
    while last.next != head:
        last = last.next

    # Make both halves circular
    current.next = head  # First half circular
    last.next = head2    # Second half circular

    return head, head2


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def create_circular_list(values: list) -> ListNode:
    """Create a circular linked list from values."""
    if not values:
        return None

    head = ListNode(values[0])
    current = head

    for val in values[1:]:
        current.next = ListNode(val)
        current = current.next

    # Make it circular
    current.next = head

    return head


def circular_list_to_list(head: ListNode, max_nodes: int = 20) -> list:
    """Convert circular list to regular list (for display)."""
    if head is None:
        return []

    result = [head.val]
    current = head.next
    count = 1

    while current != head and count < max_nodes:
        result.append(current.val)
        current = current.next
        count += 1

    return result


def print_circular_list(head: ListNode) -> str:
    """Print circular list in readable format."""
    if head is None:
        return "NULL"

    values = circular_list_to_list(head)
    if not values:
        return "NULL"

    return " -> ".join(map(str, values)) + f" -> (back to {values[0]})"


def get_circular_length(head: ListNode) -> int:
    """Get the length of a circular list."""
    if head is None:
        return 0

    count = 1
    current = head.next
    while current != head:
        count += 1
        current = current.next

    return count


# =============================================================================
# TEST CASES
# =============================================================================

def test_split_circular():
    """Test splitting circular linked list."""
    print("=" * 60)
    print("SPLIT CIRCULAR LINKED LIST - TEST CASES")
    print("=" * 60)

    # Test Case 1: Odd length
    print("\n--- Test Case 1: [1,2,3,4,5] (odd length) ---")
    head = create_circular_list([1, 2, 3, 4, 5])
    print(f"Original: {print_circular_list(head)}")
    head1, head2 = split_circular_list(head)
    print(f"First half:  {print_circular_list(head1)}")
    print(f"Second half: {print_circular_list(head2)}")
    assert get_circular_length(head1) == 3
    assert get_circular_length(head2) == 2
    print("Passed!")

    # Test Case 2: Even length
    print("\n--- Test Case 2: [1,2,3,4] (even length) ---")
    head = create_circular_list([1, 2, 3, 4])
    print(f"Original: {print_circular_list(head)}")
    head1, head2 = split_circular_list(head)
    print(f"First half:  {print_circular_list(head1)}")
    print(f"Second half: {print_circular_list(head2)}")
    assert get_circular_length(head1) == 2
    assert get_circular_length(head2) == 2
    print("Passed!")

    # Test Case 3: Two nodes
    print("\n--- Test Case 3: [1,2] (two nodes) ---")
    head = create_circular_list([1, 2])
    print(f"Original: {print_circular_list(head)}")
    head1, head2 = split_circular_list(head)
    print(f"First half:  {print_circular_list(head1)}")
    print(f"Second half: {print_circular_list(head2)}")
    assert get_circular_length(head1) == 1
    assert get_circular_length(head2) == 1
    print("Passed!")

    # Test Case 4: Single node
    print("\n--- Test Case 4: [1] (single node) ---")
    head = create_circular_list([1])
    print(f"Original: {print_circular_list(head)}")
    head1, head2 = split_circular_list(head)
    print(f"First half:  {print_circular_list(head1)}")
    print(f"Second half: {print_circular_list(head2)}")
    assert head2 is None
    print("Passed!")

    # Test Case 5: Empty list
    print("\n--- Test Case 5: Empty list ---")
    head = None
    head1, head2 = split_circular_list(head)
    print(f"First half:  {print_circular_list(head1)}")
    print(f"Second half: {print_circular_list(head2)}")
    assert head1 is None and head2 is None
    print("Passed!")

    # Test Case 6: Three nodes
    print("\n--- Test Case 6: [1,2,3] (three nodes) ---")
    head = create_circular_list([1, 2, 3])
    print(f"Original: {print_circular_list(head)}")
    head1, head2 = split_circular_list(head)
    print(f"First half:  {print_circular_list(head1)}")
    print(f"Second half: {print_circular_list(head2)}")
    assert get_circular_length(head1) == 2
    assert get_circular_length(head2) == 1
    print("Passed!")

    # Test Case 7: Six nodes (even)
    print("\n--- Test Case 7: [1,2,3,4,5,6] (six nodes) ---")
    head = create_circular_list([1, 2, 3, 4, 5, 6])
    print(f"Original: {print_circular_list(head)}")
    head1, head2 = split_circular_list(head)
    print(f"First half:  {print_circular_list(head1)}")
    print(f"Second half: {print_circular_list(head2)}")
    assert get_circular_length(head1) == 3
    assert get_circular_length(head2) == 3
    print("Passed!")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_split():
    """Demonstrate the split process step by step."""
    print("\n" + "=" * 60)
    print("STEP-BY-STEP DEMONSTRATION")
    print("=" * 60)

    print("\nSplitting circular list [1,2,3,4,5]:")
    print()
    print("Initial: 1 -> 2 -> 3 -> 4 -> 5 -> (back to 1)")
    print()
    print("Step 1: Find middle using slow-fast")
    print("  slow=1, fast=1")
    print("  slow=2, fast=3")
    print("  slow=3, fast=5 (fast.next = 1 = head, stop!)")
    print("  Middle = node 3")
    print()
    print("Step 2: Set up second half")
    print("  head2 = slow.next = node 4")
    print()
    print("Step 3: Find last node")
    print("  Start from node 4")
    print("  4.next = 5, 5.next = 1 (head)")
    print("  last = node 5")
    print()
    print("Step 4: Split and make circular")
    print("  slow.next = head: 3 -> 1")
    print("  last.next = head2: 5 -> 4")
    print()
    print("Result:")
    print("  First:  1 -> 2 -> 3 -> (back to 1)")
    print("  Second: 4 -> 5 -> (back to 4)")


if __name__ == "__main__":
    test_split_circular()
    demonstrate_split()
