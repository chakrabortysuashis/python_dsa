# Add 1 to a Number Represented as Linked List

## Problem Statement

Given a number represented as a linked list (each node contains a single digit), add 1 to the number.

**Example:**
```
Input:  1 -> 9 -> 9 -> NULL  (represents 199)
Output: 2 -> 0 -> 0 -> NULL  (represents 200)

Input:  9 -> 9 -> 9 -> NULL  (represents 999)
Output: 1 -> 0 -> 0 -> 0 -> NULL  (represents 1000)
```

---

## Intuition

### The Challenge

We add from the **rightmost digit** (units place), but linked list gives us access from the **leftmost digit** first!

```
Number: 1 -> 9 -> 9
        ^         ^
      head      need to add here first!
```

### Solutions

1. **Reverse the list** - reverse, add, reverse back
2. **Recursion** - use call stack to reach the end first
3. **Find rightmost non-9** - special optimization

---

## Approach 1: Reverse Method

```
Original: 1 -> 9 -> 9
Step 1: Reverse: 9 -> 9 -> 1
Step 2: Add 1 to first digit
        9 + 1 = 10, carry = 1, digit = 0
        0 -> 9 -> 1
Step 3: Process carry
        9 + 1 = 10, carry = 1, digit = 0
        0 -> 0 -> 1
Step 4: Still carry, process
        1 + 1 = 2, carry = 0
        0 -> 0 -> 2
Step 5: Reverse back: 2 -> 0 -> 0
```

---

## Approach 2: Recursion

Use the call stack to process from right to left.

```
Recursion tree for 1 -> 9 -> 9:

add_one(1)
    add_one(9)
        add_one(9)
            add_one(NULL) -> return carry = 1
        9 + 1 = 10 -> digit = 0, carry = 1
        return carry = 1
    9 + 1 = 10 -> digit = 0, carry = 1
    return carry = 1
1 + 1 = 2 -> digit = 2, carry = 0

Result: 2 -> 0 -> 0
```

---

## Approach 3: Find Rightmost Non-9

**Key insight:** When adding 1:
- All trailing 9s become 0
- The rightmost non-9 increases by 1
- If all 9s, add new node at front

```
Case 1: 1 -> 2 -> 9 -> 9
              ^
        rightmost non-9

Result: 1 -> 3 -> 0 -> 0

Case 2: 9 -> 9 -> 9
        All 9s! Add 1 at front.
        
Result: 1 -> 0 -> 0 -> 0
```

---

## Visual Walkthrough

**Input:** 1 -> 9 -> 9

```
Using Reverse Method:

Original:     [1] -> [9] -> [9] -> NULL

Reverse:      [9] -> [9] -> [1] -> NULL

Add 1:        
  First 9:    9 + 1 = 10
              [0] -> [9] -> [1]   carry = 1

  Second 9:   9 + 1 = 10
              [0] -> [0] -> [1]   carry = 1

  Node 1:     1 + 1 = 2
              [0] -> [0] -> [2]   carry = 0

Reverse:      [2] -> [0] -> [0] -> NULL
```

---

## Edge Cases

1. **Single digit:** 5 -> 6
2. **All 9s:** 999 -> 1000 (new node needed)
3. **Trailing 9s:** 129 -> 130

---

## Complexity

| Approach | Time | Space |
|----------|------|-------|
| Reverse | O(n) | O(1) |
| Recursion | O(n) | O(n) stack |
| Rightmost non-9 | O(n) | O(1) |
