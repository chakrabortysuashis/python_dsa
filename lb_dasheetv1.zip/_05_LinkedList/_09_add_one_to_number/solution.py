"""
Add 1 to a Number Represented as Linked List
=============================================

Problem: Given a number represented as a linked list (each node = one digit),
         add 1 to the number.

Example:
    Input:  1 -> 9 -> 9 -> NULL (199)
    Output: 2 -> 0 -> 0 -> NULL (200)
"""


class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next


# =============================================================================
# APPROACH 1: REVERSE METHOD
# =============================================================================

def add_one_reverse(head: ListNode) -> ListNode:
    """
    Add 1 by reversing the list, adding, then reversing back.

    Time: O(n), Space: O(1)
    """
    def reverse(node):
        prev = None
        while node:
            next_node = node.next
            node.next = prev
            prev = node
            node = next_node
        return prev

    # Reverse the list
    head = reverse(head)

    # Add 1
    current = head
    carry = 1

    while current and carry:
        total = current.val + carry
        current.val = total % 10
        carry = total // 10

        if carry and not current.next:
            current.next = ListNode(carry)
            carry = 0

        current = current.next

    # Reverse back
    return reverse(head)


# =============================================================================
# APPROACH 2: RECURSION
# =============================================================================

def add_one_recursive(head: ListNode) -> ListNode:
    """
    Add 1 using recursion to process from right to left.

    Time: O(n), Space: O(n) for recursion stack
    """
    def add_helper(node):
        # Base case: reached end, add 1
        if not node:
            return 1

        # Recursive case: process rest first
        carry = add_helper(node.next)

        # Add carry to current digit
        total = node.val + carry
        node.val = total % 10

        return total // 10

    carry = add_helper(head)

    # If there's still carry, add new node at front
    if carry:
        new_head = ListNode(carry)
        new_head.next = head
        return new_head

    return head


# =============================================================================
# APPROACH 3: FIND RIGHTMOST NON-9
# =============================================================================

def add_one_optimized(head: ListNode) -> ListNode:
    """
    Optimized approach: Find rightmost non-9 digit.

    Key insight:
    - All digits after rightmost non-9 become 0
    - Rightmost non-9 increases by 1
    - If all 9s, add 1 at front

    Time: O(n), Space: O(1)
    """
    # Find rightmost non-9
    rightmost_not_nine = None
    current = head

    while current:
        if current.val != 9:
            rightmost_not_nine = current
        current = current.next

    # Case 1: All digits are 9
    if not rightmost_not_nine:
        new_head = ListNode(1)
        new_head.next = head
        current = head
        while current:
            current.val = 0
            current = current.next
        return new_head

    # Case 2: Increment rightmost non-9
    rightmost_not_nine.val += 1

    # Set all following 9s to 0
    current = rightmost_not_nine.next
    while current:
        current.val = 0
        current = current.next

    return head


# =============================================================================
# HELPER FUNCTIONS AND TESTS
# =============================================================================

def create_linked_list(values):
    if not values:
        return None
    head = ListNode(values[0])
    curr = head
    for val in values[1:]:
        curr.next = ListNode(val)
        curr = curr.next
    return head


def linked_list_to_list(head):
    result = []
    while head:
        result.append(head.val)
        head = head.next
    return result


def test_add_one():
    print("=" * 60)
    print("ADD 1 TO NUMBER AS LINKED LIST - TEST CASES")
    print("=" * 60)

    test_cases = [
        ([1, 9, 9], [2, 0, 0]),      # 199 -> 200
        ([9, 9, 9], [1, 0, 0, 0]),   # 999 -> 1000
        ([1, 2, 3], [1, 2, 4]),      # 123 -> 124
        ([1, 2, 9], [1, 3, 0]),      # 129 -> 130
        ([5], [6]),                   # 5 -> 6
        ([9], [1, 0]),                # 9 -> 10
    ]

    for i, (input_vals, expected) in enumerate(test_cases, 1):
        print(f"\n--- Test Case {i} ---")
        head = create_linked_list(input_vals)
        print(f"Input:  {input_vals} (number: {''.join(map(str, input_vals))})")

        # Test recursive approach
        result = add_one_recursive(head)
        result_list = linked_list_to_list(result)
        print(f"Output: {result_list} (number: {''.join(map(str, result_list))})")

        assert result_list == expected, f"Expected {expected}, got {result_list}"
        print("Assertion passed!")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


if __name__ == "__main__":
    test_add_one()
