"""
Rotate Doubly Linked List by N Nodes
====================================

Rotate DLL counter-clockwise by N positions.
"""


class DLLNode:
    def __init__(self, val=0, prev=None, next=None):
        self.val = val
        self.prev = prev
        self.next = next


def rotate_dll(head: DLLNode, n: int) -> DLLNode:
    """
    Rotate DLL by N nodes counter-clockwise.

    Time: O(n), Space: O(1)
    """
    if head is None or head.next is None or n == 0:
        return head

    # Count length and find tail
    length = 1
    tail = head
    while tail.next:
        length += 1
        tail = tail.next

    # Normalize n
    n = n % length
    if n == 0:
        return head

    # Find Nth node (will be new tail)
    current = head
    for _ in range(n - 1):
        current = current.next

    # new_head is (N+1)th node
    new_head = current.next
    new_tail = current

    # Connect tail to old head (making it circular temporarily)
    tail.next = head
    head.prev = tail

    # Break at rotation point
    new_tail.next = None
    new_head.prev = None

    return new_head


# Helper functions
def create_dll(values):
    if not values:
        return None
    head = DLLNode(values[0])
    curr = head
    for val in values[1:]:
        node = DLLNode(val, prev=curr)
        curr.next = node
        curr = node
    return head


def dll_to_list(head):
    result = []
    while head:
        result.append(head.val)
        head = head.next
    return result


def test_rotate():
    print("ROTATE DLL - TESTS")

    head = create_dll([1, 2, 3, 4, 5])
    print(f"Original: {dll_to_list(head)}")
    head = rotate_dll(head, 2)
    print(f"Rotated by 2: {dll_to_list(head)}")
    assert dll_to_list(head) == [3, 4, 5, 1, 2]

    head = create_dll([1, 2, 3, 4, 5])
    head = rotate_dll(head, 0)
    print(f"Rotated by 0: {dll_to_list(head)}")
    assert dll_to_list(head) == [1, 2, 3, 4, 5]

    head = create_dll([1, 2, 3, 4, 5])
    head = rotate_dll(head, 5)
    print(f"Rotated by 5: {dll_to_list(head)}")
    assert dll_to_list(head) == [1, 2, 3, 4, 5]

    print("All tests passed!")


if __name__ == "__main__":
    test_rotate()
