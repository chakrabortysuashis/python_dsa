# Rotate Doubly Linked List by N Nodes

## Problem Statement

Given a doubly linked list, rotate it by N nodes counter-clockwise.

**Example:**
```
Input:  1 <-> 2 <-> 3 <-> 4 <-> 5, N = 2
Output: 3 <-> 4 <-> 5 <-> 1 <-> 2

Explanation: First N=2 nodes move to end
```

---

## Intuition

```
Rotation = Moving first N nodes to the end

Steps:
1. Find the Nth node (new tail of rotated list)
2. Find the (N+1)th node (new head)
3. Update pointers to rotate

Before: 1 <-> 2 <-> 3 <-> 4 <-> 5
             ^     ^
           Nth   (N+1)th

After:  3 <-> 4 <-> 5 <-> 1 <-> 2
        ^new_head         ^old_head (at end)
```

---

## Algorithm

```
1. Handle edge cases (N=0, N>=length)
2. Traverse to Nth node
3. new_head = Nth.next
4. Find tail of original list
5. Connect tail to old head
6. Set Nth node as new tail
7. Return new_head
```

---

## Visual Walkthrough

```
Input: 1 <-> 2 <-> 3 <-> 4 <-> 5, N = 2

Step 1: Find Nth node (node 2)
        1 <-> 2 <-> 3 <-> 4 <-> 5
              ^Nth

Step 2: new_head = 2.next = 3
        1 <-> 2    3 <-> 4 <-> 5
                   ^new_head

Step 3: Find tail (node 5)

Step 4: Connect tail to old head
        5.next = 1, 1.prev = 5

Step 5: Disconnect at N
        2.next = NULL, 3.prev = NULL

Result: 3 <-> 4 <-> 5 <-> 1 <-> 2
```

---

## Complexity

| Aspect | Complexity |
|--------|------------|
| Time | O(n) |
| Space | O(1) |

---

## Key Points

1. Handle N % length for N > length
2. N = 0 or N = length means no rotation
3. Update both prev and next pointers for DLL
