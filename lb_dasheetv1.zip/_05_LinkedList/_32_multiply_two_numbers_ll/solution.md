# Multiply Two Numbers Represented as Linked Lists

## Problem Statement

Given two numbers represented as linked lists (each node contains a single digit), multiply them and return the result as a linked list.

**Example:**
```
Input:
  Num1: 1 -> 2 -> 3 (represents 123)
  Num2: 4 -> 5     (represents 45)

Output: 5 -> 5 -> 3 -> 5 (represents 5535)
        123 * 45 = 5535
```

---

## Approach

### Method 1: Convert to Numbers

```
1. Convert each list to integer
2. Multiply
3. Convert result back to list

Simple but may overflow for large numbers
```

### Method 2: Grade School Multiplication

```
Similar to manual multiplication:
1. For each digit of num2 (from right)
2. Multiply with each digit of num1
3. Add to result with proper shift
4. Handle carries

Handles arbitrarily large numbers
```

---

## Visual Walkthrough

```
    1 2 3
  x   4 5
  -------
    6 1 5  (123 * 5)
  4 9 2 0  (123 * 4, shifted)
  -------
  5 5 3 5
```

---

## Complexity

| Approach | Time | Space |
|----------|------|-------|
| Convert | O(n+m) | O(1)* |
| Grade School | O(n*m) | O(n+m) |

*May overflow for large numbers

---

## Key Points

1. Handle carries properly
2. Consider different lengths
3. Reverse lists if stored in reverse order
4. Handle zeros (0 * anything = 0)
