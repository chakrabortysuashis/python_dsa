"""
Multiply Two Numbers Represented as Linked Lists
================================================
"""


class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next


def multiply_lists(head1: ListNode, head2: ListNode) -> ListNode:
    """
    Multiply two numbers represented as linked lists.
    Simple approach: Convert to numbers, multiply, convert back.
    """
    # Convert list to number
    def list_to_num(head):
        num = 0
        while head:
            num = num * 10 + head.val
            head = head.next
        return num

    num1 = list_to_num(head1)
    num2 = list_to_num(head2)
    result = num1 * num2

    # Convert number to list
    if result == 0:
        return ListNode(0)

    dummy = ListNode(0)
    while result > 0:
        digit = result % 10
        new_node = ListNode(digit)
        new_node.next = dummy.next
        dummy.next = new_node
        result //= 10

    return dummy.next


def multiply_large(head1: ListNode, head2: ListNode) -> ListNode:
    """
    Multiply using grade school method for arbitrarily large numbers.
    """
    # Convert lists to arrays (reversed for easier calculation)
    def list_to_array(head):
        arr = []
        while head:
            arr.append(head.val)
            head = head.next
        return arr[::-1]  # Reverse: least significant first

    arr1 = list_to_array(head1)
    arr2 = list_to_array(head2)

    # Result array
    result = [0] * (len(arr1) + len(arr2))

    # Grade school multiplication
    for i, d1 in enumerate(arr1):
        for j, d2 in enumerate(arr2):
            result[i + j] += d1 * d2
            result[i + j + 1] += result[i + j] // 10
            result[i + j] %= 10

    # Remove leading zeros and create list
    while len(result) > 1 and result[-1] == 0:
        result.pop()

    # Create linked list (reverse to get most significant first)
    dummy = ListNode(0)
    for digit in reversed(result):
        node = ListNode(digit)
        node.next = dummy.next
        dummy.next = node

    return dummy.next if dummy.next else ListNode(0)


# Test
def create_list(vals):
    if not vals:
        return None
    head = ListNode(vals[0])
    curr = head
    for v in vals[1:]:
        curr.next = ListNode(v)
        curr = curr.next
    return head


def list_to_array(head):
    result = []
    while head:
        result.append(head.val)
        head = head.next
    return result


def test():
    print("MULTIPLY TWO NUMBERS AS LL - TESTS")

    # 123 * 45 = 5535
    head1 = create_list([1, 2, 3])
    head2 = create_list([4, 5])
    result = multiply_lists(head1, head2)
    print(f"123 * 45 = {list_to_array(result)}")
    assert list_to_array(result) == [5, 5, 3, 5]

    # 99 * 99 = 9801
    head1 = create_list([9, 9])
    head2 = create_list([9, 9])
    result = multiply_lists(head1, head2)
    print(f"99 * 99 = {list_to_array(result)}")
    assert list_to_array(result) == [9, 8, 0, 1]

    print("All tests passed!")


if __name__ == "__main__":
    test()
