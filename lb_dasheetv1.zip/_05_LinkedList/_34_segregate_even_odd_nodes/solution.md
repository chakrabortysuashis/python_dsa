# Segregate Even and Odd Nodes in Linked List

## Problem Statement

Given a linked list, rearrange it so all even-valued nodes come before all odd-valued nodes while maintaining relative order.

**Example:**
```
Input:  17 -> 15 -> 8 -> 12 -> 10 -> 5 -> 4 -> NULL
Output: 8 -> 12 -> 10 -> 4 -> 17 -> 15 -> 5 -> NULL
        (even nodes)         (odd nodes)
```

---

## Approach

```
1. Create two separate lists: even_list and odd_list
2. Traverse original list:
   - Even values go to even_list
   - Odd values go to odd_list
3. Connect even_list tail to odd_list head
4. Return even_list head
```

---

## Visual Walkthrough

```
Input: 17 -> 15 -> 8 -> 12 -> 10 -> 5 -> 4

Processing:
  17 (odd)  -> odd_list
  15 (odd)  -> odd_list
  8 (even)  -> even_list
  12 (even) -> even_list
  10 (even) -> even_list
  5 (odd)   -> odd_list
  4 (even)  -> even_list

After:
  even_list: 8 -> 12 -> 10 -> 4
  odd_list:  17 -> 15 -> 5

Connect: 4 -> 17
Result: 8 -> 12 -> 10 -> 4 -> 17 -> 15 -> 5 -> NULL
```

---

## Complexity

| Aspect | Complexity |
|--------|------------|
| Time | O(n) |
| Space | O(1) |

---

## Key Points

1. Maintain relative order within even and odd groups
2. Handle all even or all odd cases
3. Don't forget to terminate the list (odd_tail.next = NULL)
4. Use dummy nodes for easier list building
