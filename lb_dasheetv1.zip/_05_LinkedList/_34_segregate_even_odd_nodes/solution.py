"""
Segregate Even and Odd Nodes in Linked List
==========================================
"""


class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next


def segregate_even_odd(head: ListNode) -> ListNode:
    """
    Segregate even and odd valued nodes.
    Even nodes first, then odd nodes.

    Time: O(n), Space: O(1)
    """
    if not head or not head.next:
        return head

    # Create two dummy heads
    even_dummy = ListNode(0)
    odd_dummy = ListNode(0)

    even_tail = even_dummy
    odd_tail = odd_dummy

    current = head
    while current:
        if current.val % 2 == 0:  # Even
            even_tail.next = current
            even_tail = even_tail.next
        else:  # Odd
            odd_tail.next = current
            odd_tail = odd_tail.next
        current = current.next

    # Connect even list to odd list
    even_tail.next = odd_dummy.next

    # Terminate odd list
    odd_tail.next = None

    # Return even list head (or odd if no evens)
    return even_dummy.next if even_dummy.next else odd_dummy.next


# Also: Segregate by position (odd/even indices)
def segregate_by_position(head: ListNode) -> ListNode:
    """
    Group nodes by their position (index).
    Odd-indexed nodes first, then even-indexed.
    Index starts from 1.
    """
    if not head or not head.next:
        return head

    odd = head
    even = head.next
    even_head = even

    while even and even.next:
        odd.next = even.next
        odd = odd.next
        even.next = odd.next
        even = even.next

    odd.next = even_head
    return head


# Test
def create_list(vals):
    if not vals:
        return None
    head = ListNode(vals[0])
    curr = head
    for v in vals[1:]:
        curr.next = ListNode(v)
        curr = curr.next
    return head


def list_to_array(head):
    result = []
    while head:
        result.append(head.val)
        head = head.next
    return result


def test():
    print("SEGREGATE EVEN ODD - TESTS")

    head = create_list([17, 15, 8, 12, 10, 5, 4])
    print(f"Input:  {list_to_array(head)}")
    head = segregate_even_odd(head)
    print(f"Output: {list_to_array(head)}")
    assert list_to_array(head) == [8, 12, 10, 4, 17, 15, 5]

    head = create_list([1, 2, 3, 4, 5])
    head = segregate_even_odd(head)
    print(f"Result: {list_to_array(head)}")
    assert list_to_array(head) == [2, 4, 1, 3, 5]

    print("All tests passed!")


if __name__ == "__main__":
    test()
