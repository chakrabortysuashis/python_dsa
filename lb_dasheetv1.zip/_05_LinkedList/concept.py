"""
Linked List - Complete Implementation in Python
================================================

This module provides comprehensive implementations of:
1. Singly Linked List
2. Doubly Linked List
3. Circular Linked List

Each implementation includes all standard operations with detailed comments.
"""


# =============================================================================
# SINGLY LINKED LIST
# =============================================================================

class SinglyNode:
    """
    Node for Singly Linked List

    Structure:
    +------+------+
    | data | next |---> points to next node
    +------+------+
    """
    def __init__(self, data):
        self.data = data      # Store the value
        self.next = None      # Pointer to next node (initially None)

    def __repr__(self):
        return f"Node({self.data})"


class SinglyLinkedList:
    """
    Singly Linked List Implementation

    Visual:
    HEAD -> [1|*] -> [2|*] -> [3|*] -> NULL

    Time Complexities:
    - Insert at head: O(1)
    - Insert at tail: O(n) without tail pointer, O(1) with tail pointer
    - Delete at head: O(1)
    - Delete at tail: O(n)
    - Search: O(n)
    - Access by index: O(n)
    """

    def __init__(self):
        self.head = None      # Pointer to first node
        self.size = 0         # Track number of nodes

    def is_empty(self):
        """Check if list is empty - O(1)"""
        return self.head is None

    def __len__(self):
        """Return number of nodes - O(1)"""
        return self.size

    # -------------------------------------------------------------------------
    # INSERTION OPERATIONS
    # -------------------------------------------------------------------------

    def insert_at_head(self, data):
        """
        Insert a new node at the beginning - O(1)

        Before: HEAD -> [1] -> [2] -> NULL
        After:  HEAD -> [NEW] -> [1] -> [2] -> NULL

        Steps:
        1. Create new node
        2. Point new node's next to current head
        3. Update head to new node
        """
        new_node = SinglyNode(data)     # Step 1: Create new node
        new_node.next = self.head       # Step 2: Link to current head
        self.head = new_node            # Step 3: Update head
        self.size += 1

    def insert_at_tail(self, data):
        """
        Insert a new node at the end - O(n)

        Before: HEAD -> [1] -> [2] -> NULL
        After:  HEAD -> [1] -> [2] -> [NEW] -> NULL

        Steps:
        1. Create new node
        2. If list is empty, make it head
        3. Otherwise, traverse to last node
        4. Link last node to new node
        """
        new_node = SinglyNode(data)     # Step 1: Create new node

        if self.is_empty():             # Step 2: Empty list case
            self.head = new_node
        else:
            # Step 3: Traverse to find last node
            current = self.head
            while current.next:         # Stop when next is None
                current = current.next
            # Step 4: Link last node to new node
            current.next = new_node

        self.size += 1

    def insert_at_position(self, data, position):
        """
        Insert at a specific position (0-indexed) - O(n)

        Before: HEAD -> [1] -> [3] -> [4] -> NULL
        Insert 2 at position 1:
        After:  HEAD -> [1] -> [2] -> [3] -> [4] -> NULL

        Steps:
        1. Handle position 0 (insert at head)
        2. Traverse to node at position-1
        3. Insert new node between current and current.next
        """
        if position < 0 or position > self.size:
            raise IndexError("Position out of bounds")

        if position == 0:               # Step 1: Insert at head
            self.insert_at_head(data)
            return

        new_node = SinglyNode(data)

        # Step 2: Traverse to position-1
        current = self.head
        for _ in range(position - 1):
            current = current.next

        # Step 3: Insert new node
        # Before: current -> current.next
        # After:  current -> new_node -> current.next
        new_node.next = current.next
        current.next = new_node
        self.size += 1

    # -------------------------------------------------------------------------
    # DELETION OPERATIONS
    # -------------------------------------------------------------------------

    def delete_at_head(self):
        """
        Delete the first node - O(1)

        Before: HEAD -> [1] -> [2] -> [3] -> NULL
        After:  HEAD -> [2] -> [3] -> NULL

        Steps:
        1. Store head node data
        2. Move head to second node
        3. Return deleted data
        """
        if self.is_empty():
            raise IndexError("Cannot delete from empty list")

        deleted_data = self.head.data   # Step 1: Store data
        self.head = self.head.next      # Step 2: Move head forward
        self.size -= 1
        return deleted_data             # Step 3: Return deleted data

    def delete_at_tail(self):
        """
        Delete the last node - O(n)

        Before: HEAD -> [1] -> [2] -> [3] -> NULL
        After:  HEAD -> [1] -> [2] -> NULL

        Steps:
        1. Handle single node case
        2. Traverse to second-to-last node
        3. Set its next to None
        """
        if self.is_empty():
            raise IndexError("Cannot delete from empty list")

        # Step 1: Single node case
        if self.head.next is None:
            deleted_data = self.head.data
            self.head = None
            self.size -= 1
            return deleted_data

        # Step 2: Traverse to second-to-last node
        current = self.head
        while current.next.next:        # Stop when next.next is None
            current = current.next

        # Step 3: Remove last node
        deleted_data = current.next.data
        current.next = None
        self.size -= 1
        return deleted_data

    def delete_at_position(self, position):
        """
        Delete node at specific position - O(n)

        Steps:
        1. Handle position 0
        2. Traverse to position-1
        3. Skip over the node to delete
        """
        if position < 0 or position >= self.size:
            raise IndexError("Position out of bounds")

        if position == 0:               # Step 1: Delete head
            return self.delete_at_head()

        # Step 2: Traverse to position-1
        current = self.head
        for _ in range(position - 1):
            current = current.next

        # Step 3: Skip over node to delete
        # Before: current -> node_to_delete -> next_node
        # After:  current -> next_node
        deleted_data = current.next.data
        current.next = current.next.next
        self.size -= 1
        return deleted_data

    def delete_by_value(self, value):
        """
        Delete first occurrence of a value - O(n)

        Returns True if deleted, False if not found
        """
        if self.is_empty():
            return False

        # Check head
        if self.head.data == value:
            self.delete_at_head()
            return True

        # Search in rest of list
        current = self.head
        while current.next:
            if current.next.data == value:
                current.next = current.next.next
                self.size -= 1
                return True
            current = current.next

        return False

    # -------------------------------------------------------------------------
    # SEARCH OPERATIONS
    # -------------------------------------------------------------------------

    def search(self, value):
        """
        Search for a value - O(n)

        Returns index if found, -1 if not found
        """
        current = self.head
        index = 0

        while current:
            if current.data == value:
                return index
            current = current.next
            index += 1

        return -1

    def get(self, index):
        """
        Get value at index - O(n)
        """
        if index < 0 or index >= self.size:
            raise IndexError("Index out of bounds")

        current = self.head
        for _ in range(index):
            current = current.next

        return current.data

    def __contains__(self, value):
        """Enable 'in' operator - O(n)"""
        return self.search(value) != -1

    # -------------------------------------------------------------------------
    # UTILITY METHODS
    # -------------------------------------------------------------------------

    def reverse(self):
        """
        Reverse the linked list in-place - O(n) time, O(1) space

        Before: HEAD -> [1] -> [2] -> [3] -> NULL
        After:  HEAD -> [3] -> [2] -> [1] -> NULL

        Approach: Three pointers (prev, current, next_node)

        Step by step:
        Initial: NULL <- [1] -> [2] -> [3] -> NULL
                  prev  curr

        Step 1:  NULL <- [1]    [2] -> [3] -> NULL
                  prev   curr   next
                        (reversed)

        Step 2:  NULL <- [1] <- [2]    [3] -> NULL
                         prev   curr   next
                               (reversed)

        Step 3:  NULL <- [1] <- [2] <- [3]    NULL
                               prev   curr   next
                                     (reversed)
        """
        prev = None
        current = self.head

        while current:
            next_node = current.next    # Save next node
            current.next = prev         # Reverse the pointer
            prev = current              # Move prev forward
            current = next_node         # Move current forward

        self.head = prev                # Update head to new first node

    def reverse_recursive(self, node=None, is_first_call=True):
        """
        Reverse using recursion - O(n) time, O(n) space (call stack)

        Recursion tree for [1] -> [2] -> [3]:

        reverse(1)
            reverse(2)
                reverse(3)
                    return 3 (base case: 3.next is None)
                3.next = 2, 2.next = None
                return 3
            2.next = 1, 1.next = None
            return 3
        head = 3

        Result: [3] -> [2] -> [1] -> NULL
        """
        if is_first_call:
            node = self.head

        # Base case: empty list or single node
        if node is None or node.next is None:
            if is_first_call:
                self.head = node
            return node

        # Recursive case
        new_head = self.reverse_recursive(node.next, False)

        # Reverse the pointer
        node.next.next = node
        node.next = None

        if is_first_call:
            self.head = new_head

        return new_head

    def find_middle(self):
        """
        Find middle element using slow-fast pointer - O(n)

        Technique: Tortoise and Hare
        - Slow pointer moves 1 step
        - Fast pointer moves 2 steps
        - When fast reaches end, slow is at middle

        Visual for [1, 2, 3, 4, 5]:
        Start: S,F at 1
        Step 1: S at 2, F at 3
        Step 2: S at 3, F at 5
        F.next is None, so S (at 3) is middle
        """
        if self.is_empty():
            return None

        slow = self.head
        fast = self.head

        while fast and fast.next:
            slow = slow.next            # Move 1 step
            fast = fast.next.next       # Move 2 steps

        return slow.data

    def has_cycle(self):
        """
        Detect if list has a cycle - O(n)

        Floyd's Cycle Detection Algorithm:
        - Use slow and fast pointers
        - If they meet, cycle exists
        - If fast reaches None, no cycle

        Visual (with cycle):
        [1] -> [2] -> [3] -> [4]
                ^             |
                |_____________|

        Slow: 1 -> 2 -> 3 -> 4 -> 3 -> 4 ...
        Fast: 1 -> 3 -> 4 -> 3 -> 4 -> 3 ...
        They will meet!
        """
        if self.is_empty():
            return False

        slow = self.head
        fast = self.head

        while fast and fast.next:
            slow = slow.next
            fast = fast.next.next

            if slow == fast:            # Pointers meet = cycle exists
                return True

        return False

    def get_nth_from_end(self, n):
        """
        Get nth node from end - O(n)

        Technique: Two pointers with n gap

        For n=2 in [1, 2, 3, 4, 5]:
        1. Move fast pointer n steps ahead
        2. Move both pointers until fast reaches end
        3. Slow pointer is at nth from end

        Visual:
        Start:     [1] [2] [3] [4] [5]
                    S       F
        Move both: [1] [2] [3] [4] [5]
                        S       F
        Move both: [1] [2] [3] [4] [5]
                            S       F
        F is at end, S is at 4 (2nd from end)
        """
        if n <= 0 or self.is_empty():
            return None

        fast = self.head
        slow = self.head

        # Move fast n steps ahead
        for _ in range(n):
            if fast is None:
                return None             # n is larger than list size
            fast = fast.next

        # Move both until fast reaches end
        while fast:
            slow = slow.next
            fast = fast.next

        return slow.data

    def to_list(self):
        """Convert linked list to Python list - O(n)"""
        result = []
        current = self.head
        while current:
            result.append(current.data)
            current = current.next
        return result

    def __str__(self):
        """String representation - O(n)"""
        if self.is_empty():
            return "HEAD -> NULL"

        nodes = []
        current = self.head
        while current:
            nodes.append(str(current.data))
            current = current.next

        return "HEAD -> " + " -> ".join(nodes) + " -> NULL"

    def __iter__(self):
        """Enable iteration - O(n)"""
        current = self.head
        while current:
            yield current.data
            current = current.next


# =============================================================================
# DOUBLY LINKED LIST
# =============================================================================

class DoublyNode:
    """
    Node for Doubly Linked List

    Structure:
    +------+------+------+
    | prev | data | next |
    +------+------+------+
       |             |
       v             v
    previous       next
      node         node
    """
    def __init__(self, data):
        self.data = data
        self.prev = None      # Pointer to previous node
        self.next = None      # Pointer to next node

    def __repr__(self):
        return f"DoublyNode({self.data})"


class DoublyLinkedList:
    """
    Doubly Linked List Implementation

    Visual:
    NULL <-> [1] <-> [2] <-> [3] <-> NULL
              ^                ^
            HEAD             TAIL

    Advantages over Singly Linked List:
    - Can traverse in both directions
    - O(1) deletion at tail (with tail pointer)
    - O(1) deletion when node reference is given
    """

    def __init__(self):
        self.head = None
        self.tail = None
        self.size = 0

    def is_empty(self):
        return self.head is None

    def __len__(self):
        return self.size

    # -------------------------------------------------------------------------
    # INSERTION OPERATIONS
    # -------------------------------------------------------------------------

    def insert_at_head(self, data):
        """
        Insert at beginning - O(1)

        Before: NULL <-> [1] <-> [2] <-> NULL
        After:  NULL <-> [NEW] <-> [1] <-> [2] <-> NULL
        """
        new_node = DoublyNode(data)

        if self.is_empty():
            # First node becomes both head and tail
            self.head = new_node
            self.tail = new_node
        else:
            # Link new node with current head
            new_node.next = self.head
            self.head.prev = new_node
            self.head = new_node

        self.size += 1

    def insert_at_tail(self, data):
        """
        Insert at end - O(1) with tail pointer!

        Before: NULL <-> [1] <-> [2] <-> NULL
        After:  NULL <-> [1] <-> [2] <-> [NEW] <-> NULL
        """
        new_node = DoublyNode(data)

        if self.is_empty():
            self.head = new_node
            self.tail = new_node
        else:
            # Link new node with current tail
            new_node.prev = self.tail
            self.tail.next = new_node
            self.tail = new_node

        self.size += 1

    def insert_at_position(self, data, position):
        """Insert at specific position - O(n)"""
        if position < 0 or position > self.size:
            raise IndexError("Position out of bounds")

        if position == 0:
            self.insert_at_head(data)
        elif position == self.size:
            self.insert_at_tail(data)
        else:
            new_node = DoublyNode(data)

            # Find node at position
            current = self.head
            for _ in range(position):
                current = current.next

            # Insert before current
            # Before: prev_node <-> current
            # After:  prev_node <-> new_node <-> current
            new_node.prev = current.prev
            new_node.next = current
            current.prev.next = new_node
            current.prev = new_node

            self.size += 1

    # -------------------------------------------------------------------------
    # DELETION OPERATIONS
    # -------------------------------------------------------------------------

    def delete_at_head(self):
        """Delete first node - O(1)"""
        if self.is_empty():
            raise IndexError("Cannot delete from empty list")

        deleted_data = self.head.data

        if self.head == self.tail:      # Single node
            self.head = None
            self.tail = None
        else:
            self.head = self.head.next
            self.head.prev = None

        self.size -= 1
        return deleted_data

    def delete_at_tail(self):
        """
        Delete last node - O(1) with tail pointer!

        This is O(1) in DLL vs O(n) in SLL because we have prev pointer
        """
        if self.is_empty():
            raise IndexError("Cannot delete from empty list")

        deleted_data = self.tail.data

        if self.head == self.tail:      # Single node
            self.head = None
            self.tail = None
        else:
            self.tail = self.tail.prev
            self.tail.next = None

        self.size -= 1
        return deleted_data

    def delete_node(self, node):
        """
        Delete a specific node - O(1)

        This is O(1) because we have prev pointer!
        In SLL, we would need O(n) to find previous node.
        """
        if node == self.head:
            self.delete_at_head()
        elif node == self.tail:
            self.delete_at_tail()
        else:
            # Unlink node from list
            node.prev.next = node.next
            node.next.prev = node.prev
            self.size -= 1

    def delete_by_value(self, value):
        """Delete first occurrence of value - O(n)"""
        current = self.head

        while current:
            if current.data == value:
                self.delete_node(current)
                return True
            current = current.next

        return False

    # -------------------------------------------------------------------------
    # TRAVERSAL OPERATIONS
    # -------------------------------------------------------------------------

    def traverse_forward(self):
        """Traverse from head to tail - O(n)"""
        result = []
        current = self.head
        while current:
            result.append(current.data)
            current = current.next
        return result

    def traverse_backward(self):
        """Traverse from tail to head - O(n)"""
        result = []
        current = self.tail
        while current:
            result.append(current.data)
            current = current.prev
        return result

    def __str__(self):
        """String representation"""
        if self.is_empty():
            return "NULL <-> NULL"

        nodes = []
        current = self.head
        while current:
            nodes.append(str(current.data))
            current = current.next

        return "NULL <-> " + " <-> ".join(nodes) + " <-> NULL"


# =============================================================================
# CIRCULAR LINKED LIST
# =============================================================================

class CircularLinkedList:
    """
    Circular Singly Linked List Implementation

    Visual:
         +---------------------------+
         |                           |
         v                           |
    HEAD -> [1] -> [2] -> [3] -------+

    The last node points back to the first node instead of NULL.

    Use cases:
    - Round-robin scheduling
    - Circular buffers
    - Games (turns going in circles)
    """

    def __init__(self):
        self.head = None
        self.size = 0

    def is_empty(self):
        return self.head is None

    def __len__(self):
        return self.size

    def insert_at_head(self, data):
        """Insert at beginning - O(n) to find last node, or O(1) with tail"""
        new_node = SinglyNode(data)

        if self.is_empty():
            new_node.next = new_node    # Point to itself
            self.head = new_node
        else:
            # Find last node
            last = self.head
            while last.next != self.head:
                last = last.next

            # Insert new node
            new_node.next = self.head
            last.next = new_node
            self.head = new_node

        self.size += 1

    def insert_at_tail(self, data):
        """Insert at end - O(n)"""
        new_node = SinglyNode(data)

        if self.is_empty():
            new_node.next = new_node
            self.head = new_node
        else:
            # Find last node
            last = self.head
            while last.next != self.head:
                last = last.next

            # Insert new node
            last.next = new_node
            new_node.next = self.head

        self.size += 1

    def delete_at_head(self):
        """Delete first node - O(n)"""
        if self.is_empty():
            raise IndexError("Cannot delete from empty list")

        deleted_data = self.head.data

        if self.head.next == self.head: # Single node
            self.head = None
        else:
            # Find last node
            last = self.head
            while last.next != self.head:
                last = last.next

            # Update pointers
            self.head = self.head.next
            last.next = self.head

        self.size -= 1
        return deleted_data

    def traverse(self):
        """
        Traverse the circular list - O(n)

        Important: Must check for completion to avoid infinite loop!
        """
        if self.is_empty():
            return []

        result = []
        current = self.head

        while True:
            result.append(current.data)
            current = current.next
            if current == self.head:    # Back to start
                break

        return result

    def __str__(self):
        """String representation"""
        if self.is_empty():
            return "Empty circular list"

        nodes = self.traverse()
        return " -> ".join(map(str, nodes)) + " -> (back to " + str(self.head.data) + ")"


# =============================================================================
# TEST CASES
# =============================================================================

def test_singly_linked_list():
    """Test Singly Linked List operations"""
    print("=" * 60)
    print("SINGLY LINKED LIST TESTS")
    print("=" * 60)

    sll = SinglyLinkedList()

    # Test insertions
    print("\n--- Insertions ---")
    sll.insert_at_head(3)
    sll.insert_at_head(2)
    sll.insert_at_head(1)
    print(f"After insert at head (1,2,3): {sll}")

    sll.insert_at_tail(4)
    sll.insert_at_tail(5)
    print(f"After insert at tail (4,5): {sll}")

    sll.insert_at_position(10, 2)
    print(f"After insert 10 at position 2: {sll}")

    # Test search
    print("\n--- Search ---")
    print(f"Search for 10: index {sll.search(10)}")
    print(f"Search for 99: index {sll.search(99)}")
    print(f"10 in list: {10 in sll}")

    # Test access
    print("\n--- Access ---")
    print(f"Element at index 2: {sll.get(2)}")

    # Test deletions
    print("\n--- Deletions ---")
    print(f"Delete at head: {sll.delete_at_head()}")
    print(f"After: {sll}")
    print(f"Delete at tail: {sll.delete_at_tail()}")
    print(f"After: {sll}")
    print(f"Delete at position 1: {sll.delete_at_position(1)}")
    print(f"After: {sll}")

    # Test reverse
    print("\n--- Reverse ---")
    sll.reverse()
    print(f"After reverse: {sll}")

    # Test middle
    print("\n--- Find Middle ---")
    sll2 = SinglyLinkedList()
    for i in [1, 2, 3, 4, 5]:
        sll2.insert_at_tail(i)
    print(f"List: {sll2}")
    print(f"Middle element: {sll2.find_middle()}")

    # Test nth from end
    print("\n--- Nth from End ---")
    print(f"2nd from end: {sll2.get_nth_from_end(2)}")
    print(f"3rd from end: {sll2.get_nth_from_end(3)}")

    print("\n" + "=" * 60)


def test_doubly_linked_list():
    """Test Doubly Linked List operations"""
    print("\nDOUBLY LINKED LIST TESTS")
    print("=" * 60)

    dll = DoublyLinkedList()

    # Test insertions
    print("\n--- Insertions ---")
    dll.insert_at_tail(1)
    dll.insert_at_tail(2)
    dll.insert_at_tail(3)
    print(f"After insert at tail (1,2,3): {dll}")

    dll.insert_at_head(0)
    print(f"After insert 0 at head: {dll}")

    dll.insert_at_position(1.5, 2)
    print(f"After insert 1.5 at position 2: {dll}")

    # Test traversal
    print("\n--- Traversal ---")
    print(f"Forward:  {dll.traverse_forward()}")
    print(f"Backward: {dll.traverse_backward()}")

    # Test deletions
    print("\n--- Deletions ---")
    print(f"Delete at head: {dll.delete_at_head()}")
    print(f"After: {dll}")
    print(f"Delete at tail: {dll.delete_at_tail()}")
    print(f"After: {dll}")

    print("\n" + "=" * 60)


def test_circular_linked_list():
    """Test Circular Linked List operations"""
    print("\nCIRCULAR LINKED LIST TESTS")
    print("=" * 60)

    cll = CircularLinkedList()

    # Test insertions
    print("\n--- Insertions ---")
    cll.insert_at_tail(1)
    cll.insert_at_tail(2)
    cll.insert_at_tail(3)
    print(f"After insert (1,2,3): {cll}")

    cll.insert_at_head(0)
    print(f"After insert 0 at head: {cll}")

    # Test traversal
    print("\n--- Traversal ---")
    print(f"Traverse: {cll.traverse()}")

    # Test deletion
    print("\n--- Deletion ---")
    print(f"Delete at head: {cll.delete_at_head()}")
    print(f"After: {cll}")

    print("\n" + "=" * 60)


if __name__ == "__main__":
    test_singly_linked_list()
    test_doubly_linked_list()
    test_circular_linked_list()

    print("\n" + "=" * 60)
    print("ALL TESTS COMPLETED!")
    print("=" * 60)
