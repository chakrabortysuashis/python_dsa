"""
Reverse a Doubly Linked List
============================

Problem: Given a doubly linked list, reverse it in-place.

Example:
    Input:  NULL <-> 1 <-> 2 <-> 3 <-> 4 <-> 5 <-> NULL
    Output: NULL <-> 5 <-> 4 <-> 3 <-> 2 <-> 1 <-> NULL
"""


class DLLNode:
    """Definition for doubly-linked list node."""
    def __init__(self, val=0, prev=None, next=None):
        self.val = val
        self.prev = prev
        self.next = next

    def __repr__(self):
        return f"DLLNode({self.val})"


# =============================================================================
# MAIN SOLUTION
# =============================================================================

def reverse_dll(head: DLLNode) -> DLLNode:
    """
    Reverse a doubly linked list by swapping prev and next pointers.

    Algorithm:
    1. For each node, swap its prev and next pointers
    2. Move to the next node (which is original prev after swap)
    3. The last processed node becomes the new head

    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    if head is None:
        return None

    current = head
    new_head = None

    while current:
        # Swap prev and next
        temp = current.prev
        current.prev = current.next
        current.next = temp

        # Update new_head to current (will be the last non-null node)
        new_head = current

        # Move to next node (which is now in prev due to swap)
        current = current.prev

    return new_head


# =============================================================================
# ALTERNATIVE: MORE EXPLICIT VERSION
# =============================================================================

def reverse_dll_explicit(head: DLLNode) -> DLLNode:
    """
    Alternative implementation with clearer variable names.

    This version keeps track of the original next before swapping.
    """
    if head is None:
        return None

    current = head

    while current:
        # Save original next before swapping
        original_next = current.next

        # Swap pointers
        current.next = current.prev
        current.prev = original_next

        # If original_next is None, current is the last node (new head)
        if original_next is None:
            return current

        # Move to original next
        current = original_next

    return head  # Should not reach here


# =============================================================================
# APPROACH 2: USING TWO POINTERS
# =============================================================================

def reverse_dll_two_pointers(head: DLLNode) -> DLLNode:
    """
    Reverse DLL using two pointers approach.

    Similar to singly linked list reversal but simpler
    because we have prev pointer.
    """
    if head is None or head.next is None:
        return head

    current = head
    prev_node = None

    while current:
        # Store next
        next_node = current.next

        # Reverse the links
        current.next = prev_node
        current.prev = next_node

        # Move pointers
        prev_node = current
        current = next_node

    return prev_node


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def create_dll(values: list) -> DLLNode:
    """Create a doubly linked list from values."""
    if not values:
        return None

    head = DLLNode(values[0])
    current = head

    for val in values[1:]:
        new_node = DLLNode(val, prev=current)
        current.next = new_node
        current = new_node

    return head


def dll_to_list(head: DLLNode) -> list:
    """Convert DLL to Python list (forward traversal)."""
    result = []
    current = head

    while current:
        result.append(current.val)
        current = current.next

    return result


def dll_to_list_reverse(head: DLLNode) -> list:
    """Convert DLL to Python list (backward traversal from tail)."""
    if head is None:
        return []

    # Go to tail
    current = head
    while current.next:
        current = current.next

    # Traverse backward
    result = []
    while current:
        result.append(current.val)
        current = current.prev

    return result


def print_dll(head: DLLNode) -> str:
    """Print DLL in readable format."""
    values = dll_to_list(head)
    if not values:
        return "NULL"
    return "NULL <-> " + " <-> ".join(map(str, values)) + " <-> NULL"


def verify_dll_integrity(head: DLLNode) -> bool:
    """Verify that prev and next pointers are correctly set."""
    if head is None:
        return True

    if head.prev is not None:
        return False  # Head should have prev = None

    current = head
    prev_node = None

    while current:
        if current.prev != prev_node:
            return False
        prev_node = current
        current = current.next

    return True


# =============================================================================
# TEST CASES
# =============================================================================

def test_reverse_dll():
    """Test DLL reversal implementations."""
    print("=" * 60)
    print("REVERSE DOUBLY LINKED LIST - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal list
    print("\n--- Test Case 1: [1, 2, 3, 4, 5] ---")
    head = create_dll([1, 2, 3, 4, 5])
    print(f"Before: {print_dll(head)}")
    head = reverse_dll(head)
    print(f"After:  {print_dll(head)}")
    assert dll_to_list(head) == [5, 4, 3, 2, 1]
    assert verify_dll_integrity(head)
    print("Passed!")

    # Test Case 2: Two nodes
    print("\n--- Test Case 2: [1, 2] ---")
    head = create_dll([1, 2])
    print(f"Before: {print_dll(head)}")
    head = reverse_dll(head)
    print(f"After:  {print_dll(head)}")
    assert dll_to_list(head) == [2, 1]
    assert verify_dll_integrity(head)
    print("Passed!")

    # Test Case 3: Single node
    print("\n--- Test Case 3: [1] (single node) ---")
    head = create_dll([1])
    print(f"Before: {print_dll(head)}")
    head = reverse_dll(head)
    print(f"After:  {print_dll(head)}")
    assert dll_to_list(head) == [1]
    assert verify_dll_integrity(head)
    print("Passed!")

    # Test Case 4: Empty list
    print("\n--- Test Case 4: Empty list ---")
    head = None
    head = reverse_dll(head)
    print(f"After:  {print_dll(head)}")
    assert head is None
    print("Passed!")

    # Test Case 5: Three nodes
    print("\n--- Test Case 5: [1, 2, 3] ---")
    head = create_dll([1, 2, 3])
    print(f"Before: {print_dll(head)}")
    head = reverse_dll(head)
    print(f"After:  {print_dll(head)}")
    assert dll_to_list(head) == [3, 2, 1]
    assert verify_dll_integrity(head)
    print("Passed!")

    # Test Case 6: Alternative method
    print("\n--- Test Case 6: Explicit method [1, 2, 3, 4] ---")
    head = create_dll([1, 2, 3, 4])
    head = reverse_dll_explicit(head)
    print(f"Result: {print_dll(head)}")
    assert dll_to_list(head) == [4, 3, 2, 1]
    print("Passed!")

    # Test Case 7: Two pointers method
    print("\n--- Test Case 7: Two pointers method [1, 2, 3, 4] ---")
    head = create_dll([1, 2, 3, 4])
    head = reverse_dll_two_pointers(head)
    print(f"Result: {print_dll(head)}")
    assert dll_to_list(head) == [4, 3, 2, 1]
    print("Passed!")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_step_by_step():
    """Demonstrate the reversal process step by step."""
    print("\n" + "=" * 60)
    print("STEP-BY-STEP DEMONSTRATION")
    print("=" * 60)

    print("\nReversing DLL: 1 <-> 2 <-> 3")
    print()
    print("Initial:")
    print("  NULL <- [1] <-> [2] <-> [3] -> NULL")
    print("           ^")
    print("         current")
    print()
    print("Step 1: At node 1")
    print("  Swap prev and next:")
    print("    1.prev = 1.next (was NULL, now 2)")
    print("    1.next = temp (was 2, now NULL)")
    print("  [1] now has: prev=2, next=NULL")
    print("  Move to original prev (now in current.prev) = 2")
    print()
    print("Step 2: At node 2")
    print("  Swap prev and next:")
    print("    2.prev = 2.next (was 1, now 3)")
    print("    2.next = temp (was 3, now 1)")
    print("  [2] now has: prev=3, next=1")
    print("  Move to original prev = 3")
    print()
    print("Step 3: At node 3")
    print("  Swap prev and next:")
    print("    3.prev = 3.next (was 2, now NULL)")
    print("    3.next = temp (was NULL, now 2)")
    print("  [3] now has: prev=NULL, next=2")
    print("  Move to original prev = NULL (stop)")
    print()
    print("Result: NULL <- [3] <-> [2] <-> [1] -> NULL")
    print("New head = 3")


if __name__ == "__main__":
    test_reverse_dll()
    demonstrate_step_by_step()
