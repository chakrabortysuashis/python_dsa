# Reverse a Doubly Linked List

## Problem Statement

Given a doubly linked list, reverse it in-place.

**Example:**
```
Input:  NULL <-> 1 <-> 2 <-> 3 <-> 4 <-> 5 <-> NULL
Output: NULL <-> 5 <-> 4 <-> 3 <-> 2 <-> 1 <-> NULL
```

---

## Intuition

### Doubly Linked List Structure

```
Each node in DLL has:
- val: the data
- next: pointer to next node
- prev: pointer to previous node

Before:
NULL <- [1] <-> [2] <-> [3] <-> [4] <-> [5] -> NULL
         ^                               |
        head                           tail

After reversal:
NULL <- [5] <-> [4] <-> [3] <-> [2] <-> [1] -> NULL
         ^                               |
        head                           tail
```

### Key Insight

```
To reverse a DLL, simply SWAP prev and next pointers for each node!

Original node 2:
  prev -> 1, next -> 3

After swap:
  prev -> 3, next -> 1

This is simpler than singly linked list because
we already have the prev pointer!
```

---

## Algorithm

### Approach: Swap prev and next

```
For each node:
1. Swap the prev and next pointers
2. Move to the original prev (which is now next)
3. Continue until reaching end

After processing all nodes:
- The last processed node becomes the new head
```

---

## Visual Walkthrough

```
Original:
NULL <- [1] <-> [2] <-> [3] -> NULL
        prev    next
        =null   =2

Step 1: Process node 1
        Swap: prev <-> next
        Node 1: prev=2, next=NULL

NULL -> [1] -> [2] <-> [3] -> NULL
        prev=2, next=NULL

Move to original prev (NULL)... wait, that's wrong!
We should move to original next (before swap)!

Let me redo:

Step 1: At node 1
        Save: temp = 1.next (which is 2)
        Swap: 1.next = 1.prev (NULL)
              1.prev = temp (2)
        Move to temp (2)

[1] now: prev=2, next=NULL

Step 2: At node 2
        Save: temp = 2.next (which is 3)
        Swap: 2.next = 2.prev (1)
              2.prev = temp (3)
        Move to temp (3)

[2] now: prev=3, next=1

Step 3: At node 3
        Save: temp = 3.next (which is NULL)
        Swap: 3.next = 3.prev (2)
              3.prev = temp (NULL)
        Move to temp (NULL) - stop!

[3] now: prev=NULL, next=2

Last processed node (3) is new head!

Final: NULL <- [3] <-> [2] <-> [1] -> NULL
```

---

## Dry Run

### Input: 1 <-> 2 <-> 3

| Step | Current | Original next | After Swap (prev, next) | Move to |
|------|---------|---------------|-------------------------|---------|
| 1 | 1 | 2 | (2, NULL) | 2 |
| 2 | 2 | 3 | (3, 1) | 3 |
| 3 | 3 | NULL | (NULL, 2) | NULL (stop) |

**New head = 3**

**Result: NULL <-> 3 <-> 2 <-> 1 <-> NULL**

---

## Complexity Analysis

| Aspect | Complexity |
|--------|------------|
| Time | O(n) |
| Space | O(1) |

```
Time: O(n) - visit each node exactly once
Space: O(1) - only using a temp pointer for swap
```

---

## Edge Cases

```
1. Empty list:       NULL -> NULL
2. Single node:      [1] -> [1] (no change needed)
3. Two nodes:        [1] <-> [2] -> [2] <-> [1]
```

---

## Key Takeaways

1. **DLL reversal is simpler** than SLL because prev pointer exists
2. **Swap prev and next** for each node
3. **Track the current node** before swapping to know where to move
4. **Last node** becomes new head
5. Works **in-place** with O(1) extra space
