"""
Intersection Point of Two Linked Lists
=======================================

Problem: Given two singly linked lists, find the node at which they
         intersect (merge). Return NULL if they don't intersect.

Example:
    A: 1 -> 2 -\
                -> 6 -> 7 -> NULL
    B: 3 -> 4 -> 5 -/

    Intersection: Node 6
"""


class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next


# =============================================================================
# APPROACH 1: TWO POINTERS (OPTIMAL)
# =============================================================================

def get_intersection_node(headA: ListNode, headB: ListNode) -> ListNode:
    """
    Find intersection using two pointers technique.

    Algorithm:
    1. Start two pointers at heads of both lists
    2. Traverse until end, then redirect to OTHER list's head
    3. They will meet at intersection or both become NULL

    Why it works:
    - A has length a + c (a unique, c common)
    - B has length b + c (b unique, c common)
    - Pointer from A travels: a + c + b
    - Pointer from B travels: b + c + a
    - Since a+c+b = b+c+a, they meet at intersection!

    Time: O(m + n)
    Space: O(1)
    """
    if not headA or not headB:
        return None

    pA = headA
    pB = headB

    # Traverse until they meet (or both become NULL)
    while pA != pB:
        # If pA reaches end, redirect to headB
        pA = pA.next if pA else headB

        # If pB reaches end, redirect to headA
        pB = pB.next if pB else headA

    # Either they met at intersection, or both are NULL
    return pA


# =============================================================================
# APPROACH 2: HASH SET
# =============================================================================

def get_intersection_hashset(headA: ListNode, headB: ListNode) -> ListNode:
    """
    Find intersection using hash set.

    Time: O(m + n)
    Space: O(m)
    """
    nodes_in_A = set()

    # Store all nodes from A
    current = headA
    while current:
        nodes_in_A.add(current)
        current = current.next

    # Check if any node in B is in the set
    current = headB
    while current:
        if current in nodes_in_A:
            return current
        current = current.next

    return None


# =============================================================================
# APPROACH 3: LENGTH DIFFERENCE
# =============================================================================

def get_intersection_length(headA: ListNode, headB: ListNode) -> ListNode:
    """
    Find intersection by aligning lists based on length difference.

    Time: O(m + n)
    Space: O(1)
    """
    def get_length(head):
        length = 0
        while head:
            length += 1
            head = head.next
        return length

    lenA = get_length(headA)
    lenB = get_length(headB)

    # Align the longer list
    pA, pB = headA, headB

    if lenA > lenB:
        for _ in range(lenA - lenB):
            pA = pA.next
    else:
        for _ in range(lenB - lenA):
            pB = pB.next

    # Now traverse together
    while pA and pB:
        if pA == pB:
            return pA
        pA = pA.next
        pB = pB.next

    return None


# =============================================================================
# HELPER FUNCTIONS AND TESTS
# =============================================================================

def create_intersecting_lists(a_vals, b_vals, common_vals):
    """
    Create two lists that intersect at a common tail.
    """
    # Create common part
    common_head = None
    common_tail = None
    for val in common_vals:
        node = ListNode(val)
        if not common_head:
            common_head = node
            common_tail = node
        else:
            common_tail.next = node
            common_tail = node

    # Create list A
    headA = None
    tailA = None
    for val in a_vals:
        node = ListNode(val)
        if not headA:
            headA = node
            tailA = node
        else:
            tailA.next = node
            tailA = node

    if tailA:
        tailA.next = common_head
    else:
        headA = common_head

    # Create list B
    headB = None
    tailB = None
    for val in b_vals:
        node = ListNode(val)
        if not headB:
            headB = node
            tailB = node
        else:
            tailB.next = node
            tailB = node

    if tailB:
        tailB.next = common_head
    else:
        headB = common_head

    return headA, headB, common_head


def test_intersection_point():
    print("=" * 60)
    print("INTERSECTION POINT - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal intersection
    print("\n--- Test Case 1: Normal Intersection ---")
    headA, headB, common = create_intersecting_lists([1, 2], [3, 4, 5], [6, 7])
    print("A: 1 -> 2 -> [6 -> 7]")
    print("B: 3 -> 4 -> 5 -> [6 -> 7]")

    result = get_intersection_node(headA, headB)
    print(f"Intersection: {result.val if result else 'None'}")
    assert result == common
    print("Assertion passed!")

    # Test Case 2: No intersection
    print("\n--- Test Case 2: No Intersection ---")
    headA, headB, _ = create_intersecting_lists([1, 2, 3], [4, 5, 6], [])
    # Actually create separate lists
    headA = ListNode(1, ListNode(2, ListNode(3)))
    headB = ListNode(4, ListNode(5, ListNode(6)))

    result = get_intersection_node(headA, headB)
    print(f"Intersection: {result.val if result else 'None'}")
    assert result is None
    print("Assertion passed!")

    # Test Case 3: Same list (intersect at head)
    print("\n--- Test Case 3: Same Starting Point ---")
    headA, headB, common = create_intersecting_lists([], [], [1, 2, 3])

    result = get_intersection_node(headA, headB)
    print(f"Intersection: {result.val if result else 'None'}")
    assert result == common
    print("Assertion passed!")

    # Test Case 4: Using different approaches
    print("\n--- Test Case 4: All Approaches ---")
    headA, headB, common = create_intersecting_lists([1], [2, 3], [4, 5])

    result1 = get_intersection_node(headA, headB)
    result2 = get_intersection_hashset(headA, headB)
    result3 = get_intersection_length(headA, headB)

    print(f"Two-pointer: {result1.val if result1 else 'None'}")
    print(f"Hash set: {result2.val if result2 else 'None'}")
    print(f"Length diff: {result3.val if result3 else 'None'}")

    assert result1 == result2 == result3 == common
    print("All approaches give same result!")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


if __name__ == "__main__":
    test_intersection_point()
