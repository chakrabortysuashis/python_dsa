# Intersection Point of Two Linked Lists

## Problem Statement

Given two singly linked lists, find the node where they merge (intersect). If they don't intersect, return NULL.

**Example:**
```
List A:     1 -> 2 -\
                     -> 6 -> 7 -> NULL
List B: 3 -> 4 -> 5 -/

Intersection Point: Node 6
```

---

## Intuition

### Understanding Intersection

Two linked lists **intersect** when they share the same physical node (same memory address), not just the same value.

```
A: [1] -> [2] ----+
                  |
                  v
                 [6] -> [7] -> NULL
                  ^
                  |
B: [3] -> [4] -> [5]

After node 5, B points to the SAME node 6 that A points to.
```

---

## Approach 1: Hash Set

1. Traverse List A, store all nodes in a set
2. Traverse List B, check if any node is in the set
3. First match is the intersection point

**Time:** O(m + n), **Space:** O(m)

---

## Approach 2: Two Pointers (Optimal)

### The Clever Trick

1. Start two pointers at heads of both lists
2. Traverse until reaching end
3. When one reaches end, redirect to OTHER list's head
4. They will meet at intersection (or both reach NULL)

### Why It Works

```
A has length: a + c (a before intersection, c common)
B has length: b + c

Pointer from A travels: a + c + b
Pointer from B travels: b + c + a

a + c + b = b + c + a

They meet after traveling the same distance!
```

### Visual

```
A: 1 -> 2 -> 6 -> 7 -> NULL
B: 3 -> 4 -> 5 -> 6 -> 7 -> NULL

pA: 1 -> 2 -> 6 -> 7 -> NULL -> 3 -> 4 -> 5 -> [6]
pB: 3 -> 4 -> 5 -> 6 -> 7 -> NULL -> 1 -> 2 -> [6]
                                               ↑
                                          They meet!
```

---

## Approach 3: Length Difference

1. Find lengths of both lists
2. Move longer list's pointer ahead by difference
3. Move both simultaneously until they meet

---

## Algorithm (Two Pointers)

```
1. Initialize pA = headA, pB = headB
2. While pA != pB:
   - If pA is NULL, set pA = headB, else pA = pA.next
   - If pB is NULL, set pB = headA, else pB = pB.next
3. Return pA (intersection or NULL)
```

---

## Dry Run

```
A: 1 -> 2 -> 3 (length 2 before common)
B: 4 -> 5 -> 3 (length 2 before common)
Common: 3 -> NULL

pA: 1, pB: 4
pA: 2, pB: 5
pA: 3, pB: 3  <- MEET! Return 3

If no intersection:
A: 1 -> 2 -> NULL
B: 3 -> 4 -> NULL

pA: 1, pB: 3
pA: 2, pB: 4
pA: NULL, pB: NULL <- Both NULL, no intersection
```

---

## Complexity

| Approach | Time | Space |
|----------|------|-------|
| Hash Set | O(m+n) | O(m) |
| Two Pointers | O(m+n) | O(1) |
| Length Diff | O(m+n) | O(1) |

---

## Edge Cases

1. **No intersection:** Return NULL
2. **Same list:** Return head
3. **One list empty:** Return NULL
4. **Different lengths:** Two-pointer handles this

---

## Key Takeaways

1. **Two-pointer trick** equalizes path lengths
2. **Physical node match**, not value match
3. **O(1) space** with clever pointer manipulation
