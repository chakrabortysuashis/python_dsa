"""
Merge K Sorted Linked Lists
===========================
"""

import heapq


class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

    def __lt__(self, other):
        return self.val < other.val


def merge_k_lists_heap(lists: list) -> ListNode:
    """
    Merge K sorted lists using min-heap.
    Time: O(N log k), Space: O(k)
    """
    heap = []

    # Add head of each list to heap
    for i, lst in enumerate(lists):
        if lst:
            heapq.heappush(heap, (lst.val, i, lst))

    dummy = ListNode(0)
    tail = dummy

    while heap:
        val, idx, node = heapq.heappop(heap)
        tail.next = node
        tail = tail.next

        if node.next:
            heapq.heappush(heap, (node.next.val, idx, node.next))

    return dummy.next


def merge_k_lists_divide(lists: list) -> ListNode:
    """
    Merge using divide and conquer.
    Time: O(N log k), Space: O(log k)
    """
    if not lists:
        return None
    if len(lists) == 1:
        return lists[0]

    mid = len(lists) // 2
    left = merge_k_lists_divide(lists[:mid])
    right = merge_k_lists_divide(lists[mid:])

    return merge_two(left, right)


def merge_two(l1: ListNode, l2: ListNode) -> ListNode:
    """Merge two sorted lists."""
    dummy = ListNode(0)
    tail = dummy

    while l1 and l2:
        if l1.val <= l2.val:
            tail.next = l1
            l1 = l1.next
        else:
            tail.next = l2
            l2 = l2.next
        tail = tail.next

    tail.next = l1 if l1 else l2
    return dummy.next


# Test
def create_list(vals):
    if not vals:
        return None
    head = ListNode(vals[0])
    curr = head
    for v in vals[1:]:
        curr.next = ListNode(v)
        curr = curr.next
    return head


def list_to_array(head):
    result = []
    while head:
        result.append(head.val)
        head = head.next
    return result


def test():
    print("MERGE K SORTED LISTS - TESTS")

    lists = [
        create_list([1, 4, 5]),
        create_list([1, 3, 4]),
        create_list([2, 6])
    ]

    result = merge_k_lists_heap(lists)
    print(f"Result: {list_to_array(result)}")
    assert list_to_array(result) == [1, 1, 2, 3, 4, 4, 5, 6]
    print("Test passed!")


if __name__ == "__main__":
    test()
