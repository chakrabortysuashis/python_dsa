# Merge K Sorted Linked Lists

## Problem Statement

Given K sorted linked lists, merge them into one sorted linked list.

**Example:**
```
Input:
  List1: 1 -> 4 -> 5
  List2: 1 -> 3 -> 4
  List3: 2 -> 6

Output: 1 -> 1 -> 2 -> 3 -> 4 -> 4 -> 5 -> 6
```

---

## Approaches

### Approach 1: Merge One by One - O(kN)

```
Merge first two lists, then merge result with third, and so on.
Time: O(kN) where N = total nodes
```

### Approach 2: Min-Heap - O(N log k) [Optimal]

```
1. Add head of each list to min-heap
2. Extract minimum, add to result
3. Add extracted node's next to heap
4. Repeat until heap empty

Time: O(N log k), Space: O(k)
```

### Approach 3: Divide and Conquer - O(N log k)

```
1. Pair up lists and merge each pair
2. Repeat until one list remains
Similar to merge sort's merge phase
```

---

## Visual Walkthrough (Min-Heap)

```
Lists:
  1 -> 4 -> 5
  1 -> 3 -> 4
  2 -> 6

Heap initially: [1, 1, 2] (heads)

Step 1: Extract 1 (from list1), add 4
        Result: 1
        Heap: [1, 2, 4]

Step 2: Extract 1 (from list2), add 3
        Result: 1 -> 1
        Heap: [2, 3, 4]

Step 3: Extract 2, add 6
        Result: 1 -> 1 -> 2
        Heap: [3, 4, 6]

Continue until heap empty...
```

---

## Complexity

| Approach | Time | Space |
|----------|------|-------|
| One by One | O(kN) | O(1) |
| Min-Heap | O(N log k) | O(k) |
| Divide & Conquer | O(N log k) | O(log k) |

---

## Key Points

1. Min-heap ensures smallest element always at top
2. Only k elements in heap at any time
3. Each element pushed/popped once: O(N) operations
4. Each heap operation: O(log k)
