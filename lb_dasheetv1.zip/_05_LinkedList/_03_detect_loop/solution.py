"""
Detect Loop in a Linked List
=============================

Problem: Given a linked list, determine if it has a cycle (loop) in it.

Example:
    List with cycle: 1 -> 2 -> 3 -> 4 -> 5 -> 3 (points back to 3)
    Output: True

    List without cycle: 1 -> 2 -> 3 -> 4 -> 5 -> NULL
    Output: False
"""


class ListNode:
    """Definition for singly-linked list node."""
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

    def __repr__(self):
        return f"ListNode({self.val})"


# =============================================================================
# APPROACH 1: HASH SET (BRUTE FORCE)
# =============================================================================

def has_cycle_hashset(head: ListNode) -> bool:
    """
    Detect cycle using a hash set to track visited nodes.

    Algorithm:
    1. Traverse the list
    2. Store each visited node in a set
    3. If we see a node already in the set, there's a cycle
    4. If we reach NULL, there's no cycle

    Visual:
    1 -> 2 -> 3 -> 4 -> 5 -> 3

    Visit 1: Set = {node1}
    Visit 2: Set = {node1, node2}
    Visit 3: Set = {node1, node2, node3}
    Visit 4: Set = {node1, node2, node3, node4}
    Visit 5: Set = {node1, node2, node3, node4, node5}
    Visit 3: node3 already in set! CYCLE!

    Time Complexity: O(n)
    Space Complexity: O(n) - storing all nodes in set
    """
    visited = set()
    current = head

    while current:
        # If we've seen this node before, there's a cycle
        if current in visited:
            return True

        # Mark this node as visited
        visited.add(current)

        # Move to next node
        current = current.next

    # Reached end (NULL), no cycle
    return False


# =============================================================================
# APPROACH 2: FLOYD'S CYCLE DETECTION (OPTIMAL)
# =============================================================================

def has_cycle_floyd(head: ListNode) -> bool:
    """
    Detect cycle using Floyd's Tortoise and Hare algorithm.

    Algorithm:
    1. Use two pointers: slow (moves 1 step) and fast (moves 2 steps)
    2. If there's a cycle, they will eventually meet
    3. If fast reaches NULL, there's no cycle

    Why it works:
    - In a cycle, fast gains 1 position per step on slow
    - Eventually fast will "lap" slow and they meet

    Visual for 1 -> 2 -> 3 -> 4 -> 5 -> 3:

    Step 0: S,F at 1
    Step 1: S at 2, F at 3
    Step 2: S at 3, F at 5
    Step 3: S at 4, F at 4 (F went 5->3->4)

    S == F at node 4! Cycle detected!

    Time Complexity: O(n)
    Space Complexity: O(1) - only two pointers
    """
    # Edge case: empty list or single node without cycle
    if not head or not head.next:
        return False

    # Initialize pointers
    # Slow pointer (tortoise): moves 1 step at a time
    slow = head
    # Fast pointer (hare): moves 2 steps at a time
    fast = head

    # Move pointers until they meet or fast reaches end
    while fast and fast.next:
        # Move slow one step
        slow = slow.next

        # Move fast two steps
        fast = fast.next.next

        # If they meet, there's a cycle
        # Check AFTER moving to handle the initial case where both start at head
        if slow == fast:
            return True

    # Fast reached NULL, no cycle
    return False


# =============================================================================
# VARIANT: RETURN THE NODE WHERE CYCLE BEGINS
# =============================================================================

def detect_cycle_start(head: ListNode) -> ListNode:
    """
    Find the node where the cycle begins (if exists).

    Algorithm (after detecting cycle with Floyd's):
    1. First detect if cycle exists using Floyd's algorithm
    2. Once slow and fast meet, reset one pointer to head
    3. Move both pointers one step at a time
    4. They will meet at the cycle start

    Mathematical proof:
    Let:
    - m = distance from head to cycle start
    - k = distance from cycle start to meeting point
    - L = cycle length

    At meeting point:
    - Slow traveled: m + k
    - Fast traveled: m + k + n*L (for some n >= 1)

    Since fast = 2 * slow:
    2(m + k) = m + k + n*L
    m + k = n*L
    m = n*L - k

    When we move one pointer from head and one from meeting point:
    - From head: travels m to reach cycle start
    - From meeting point: travels m = n*L - k
      = (n-1)*L + (L - k) = (n-1) full cycles + remaining distance to cycle start

    They meet at cycle start!

    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    if not head or not head.next:
        return None

    # Phase 1: Detect cycle
    slow = head
    fast = head

    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next

        if slow == fast:
            break
    else:
        # No cycle
        return None

    # Phase 2: Find cycle start
    # Reset one pointer to head
    slow = head

    # Move both one step at a time until they meet
    while slow != fast:
        slow = slow.next
        fast = fast.next

    # They meet at cycle start
    return slow


# =============================================================================
# VARIANT: FIND CYCLE LENGTH
# =============================================================================

def cycle_length(head: ListNode) -> int:
    """
    Find the length of the cycle (if exists).

    Algorithm:
    1. First detect cycle using Floyd's
    2. Once detected, keep one pointer fixed
    3. Move other pointer until it comes back
    4. Count the steps

    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    if not head or not head.next:
        return 0

    # Detect cycle
    slow = head
    fast = head

    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next

        if slow == fast:
            # Cycle detected, now count length
            length = 1
            current = slow.next

            while current != slow:
                length += 1
                current = current.next

            return length

    # No cycle
    return 0


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def create_linked_list_with_cycle(values: list, cycle_pos: int) -> ListNode:
    """
    Create a linked list with a cycle.

    Args:
        values: List of values for nodes
        cycle_pos: Index where the cycle starts (-1 for no cycle)

    Returns:
        Head of the linked list
    """
    if not values:
        return None

    head = ListNode(values[0])
    current = head
    cycle_node = None

    for i, val in enumerate(values[1:], 1):
        current.next = ListNode(val)
        current = current.next

        if i == cycle_pos:
            cycle_node = current

    if cycle_pos == 0:
        cycle_node = head

    # Create cycle
    if cycle_node:
        current.next = cycle_node

    return head


def print_list_safe(head: ListNode, max_nodes: int = 20) -> str:
    """Print list safely (handles cycles)."""
    if not head:
        return "NULL"

    result = []
    current = head
    visited = set()
    count = 0

    while current and count < max_nodes:
        if current in visited:
            result.append(f"[CYCLE to {current.val}]")
            break

        result.append(str(current.val))
        visited.add(current)
        current = current.next
        count += 1

    if count >= max_nodes and current:
        result.append("...")

    if current is None:
        result.append("NULL")

    return " -> ".join(result)


# =============================================================================
# TEST CASES
# =============================================================================

def test_detect_cycle():
    """Test cycle detection implementations."""
    print("=" * 60)
    print("DETECT LOOP IN LINKED LIST - TEST CASES")
    print("=" * 60)

    # Test Case 1: List with cycle
    print("\n--- Test Case 1: List with Cycle ---")
    head = create_linked_list_with_cycle([1, 2, 3, 4, 5], 2)  # 5 -> 3
    print(f"List: {print_list_safe(head)}")

    result_hash = has_cycle_hashset(head)
    result_floyd = has_cycle_floyd(head)
    print(f"Has cycle (HashSet): {result_hash}")
    print(f"Has cycle (Floyd's): {result_floyd}")

    assert result_hash == True
    assert result_floyd == True
    print("Assertions passed!")

    # Test Case 2: No cycle
    print("\n--- Test Case 2: No Cycle ---")
    head = create_linked_list_with_cycle([1, 2, 3, 4, 5], -1)
    print(f"List: {print_list_safe(head)}")

    result_hash = has_cycle_hashset(head)
    result_floyd = has_cycle_floyd(head)
    print(f"Has cycle (HashSet): {result_hash}")
    print(f"Has cycle (Floyd's): {result_floyd}")

    assert result_hash == False
    assert result_floyd == False
    print("Assertions passed!")

    # Test Case 3: Self-loop
    print("\n--- Test Case 3: Self-loop (single node) ---")
    head = ListNode(1)
    head.next = head  # Points to itself
    print(f"List: 1 -> [CYCLE to 1]")

    result_floyd = has_cycle_floyd(head)
    print(f"Has cycle (Floyd's): {result_floyd}")

    assert result_floyd == True
    print("Assertion passed!")

    # Test Case 4: Empty list
    print("\n--- Test Case 4: Empty List ---")
    head = None
    result = has_cycle_floyd(head)
    print(f"Has cycle: {result}")
    assert result == False
    print("Assertion passed!")

    # Test Case 5: Find cycle start
    print("\n--- Test Case 5: Find Cycle Start ---")
    head = create_linked_list_with_cycle([1, 2, 3, 4, 5], 2)  # 5 -> 3
    print(f"List: {print_list_safe(head)}")

    cycle_start = detect_cycle_start(head)
    print(f"Cycle starts at node: {cycle_start.val if cycle_start else 'None'}")
    assert cycle_start.val == 3
    print("Assertion passed!")

    # Test Case 6: Cycle length
    print("\n--- Test Case 6: Cycle Length ---")
    head = create_linked_list_with_cycle([1, 2, 3, 4, 5], 2)  # Cycle: 3->4->5->3
    print(f"List: {print_list_safe(head)}")

    length = cycle_length(head)
    print(f"Cycle length: {length}")
    assert length == 3  # Nodes 3, 4, 5 form the cycle
    print("Assertion passed!")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_floyd():
    """Demonstrate Floyd's algorithm step by step."""
    print("\n" + "=" * 60)
    print("FLOYD'S ALGORITHM - STEP BY STEP")
    print("=" * 60)

    # Create list with cycle: 1 -> 2 -> 3 -> 4 -> 5 -> 3
    print("\nList: 1 -> 2 -> 3 -> 4 -> 5 -> 3 (cycle)")
    print("\nSimulating pointer movements:")

    # Simulate the movement
    nodes = [1, 2, 3, 4, 5]
    cycle_start = 2  # Index of 3

    slow_pos = 0
    fast_pos = 0
    step = 0

    print(f"\nStep {step}: Slow at {nodes[slow_pos]}, Fast at {nodes[fast_pos]}")

    while True:
        step += 1

        # Move slow 1 step
        slow_pos = (slow_pos + 1) if slow_pos < len(nodes) - 1 else cycle_start

        # Move fast 2 steps
        fast_pos = (fast_pos + 1) if fast_pos < len(nodes) - 1 else cycle_start
        fast_pos = (fast_pos + 1) if fast_pos < len(nodes) - 1 else cycle_start

        print(f"Step {step}: Slow at {nodes[slow_pos]}, Fast at {nodes[fast_pos]}", end="")

        if slow_pos == fast_pos:
            print(" <- MEET! Cycle detected!")
            break
        else:
            print()

        if step > 20:  # Safety limit
            print("... (safety limit reached)")
            break


if __name__ == "__main__":
    test_detect_cycle()
    demonstrate_floyd()
