# Detect Loop in a Linked List

## Problem Statement

Given a linked list, determine if it has a cycle (loop) in it. A cycle exists if some node in the list can be reached again by continuously following the `next` pointer.

**Example:**
```
List with cycle:
1 -> 2 -> 3 -> 4 -> 5
          ^         |
          |_________|

Output: True (cycle exists, 5 points back to 3)

List without cycle:
1 -> 2 -> 3 -> 4 -> 5 -> NULL

Output: False (no cycle)
```

---

## Intuition

### Understanding Cycles

A cycle occurs when a node's `next` pointer points to a previously visited node, creating an infinite loop.

```
Normal list:
[1] -> [2] -> [3] -> [4] -> NULL
                            ↑
                      End (NULL)

Cycle:
[1] -> [2] -> [3] -> [4] -> [5]
               ↑             |
               |_____________|
               ↑
         Cycle start (node 3)
```

### The Challenge

If we simply traverse the list looking for NULL, we'll loop forever if a cycle exists!

---

## Approach 1: Hash Set (Brute Force)

### Concept

Store visited nodes in a hash set. If we encounter a node already in the set, there's a cycle.

```
Visit 1: Set = {1}
Visit 2: Set = {1, 2}
Visit 3: Set = {1, 2, 3}
Visit 4: Set = {1, 2, 3, 4}
Visit 5: Set = {1, 2, 3, 4, 5}
Visit 3 again: 3 is already in set! CYCLE DETECTED!
```

### Complexity
- **Time:** O(n)
- **Space:** O(n) - storing all visited nodes

---

## Approach 2: Floyd's Cycle Detection (Optimal)

### The Tortoise and Hare Algorithm

Use two pointers:
- **Slow (Tortoise):** Moves 1 step at a time
- **Fast (Hare):** Moves 2 steps at a time

**Key Insight:** If there's a cycle, the fast pointer will eventually catch up to the slow pointer (they will meet inside the cycle).

### Why Does This Work?

Think of it like two runners on a circular track:
- Fast runner is twice as fast as slow runner
- They start together
- Fast runner will eventually lap the slow runner

```
Imagine a cycle of length L:
- Each step, fast gains 1 position on slow
- After L steps, fast will have gained L positions
- They will meet!
```

### Visual Walkthrough

**List:** 1 -> 2 -> 3 -> 4 -> 5 -> 3 (cycle to node 3)

```
Initial:
[1] -> [2] -> [3] -> [4] -> [5]
               ↑             |
               |_____________|
S,F
 ↓
[1]

Step 1: S moves 1, F moves 2
[1] -> [2] -> [3] -> [4] -> [5]
        S      F

Step 2: S moves 1, F moves 2
[1] -> [2] -> [3] -> [4] -> [5]
               S             F

Step 3: S moves 1, F moves 2
[1] -> [2] -> [3] -> [4] -> [5]
                      S      |
               F <-----------|

Step 4: S moves 1, F moves 2
[1] -> [2] -> [3] -> [4] -> [5]
                             S
               ↑      F      |
               |_____________|

Step 5: S moves 1, F moves 2
[1] -> [2] -> [3] -> [4] -> [5]
               ↑       S,F   |
               |_____________|

S == F ! CYCLE DETECTED!
```

### Visual - No Cycle Case

**List:** 1 -> 2 -> 3 -> 4 -> 5 -> NULL

```
Step 1:
[1] -> [2] -> [3] -> [4] -> [5] -> NULL
        S      F

Step 2:
[1] -> [2] -> [3] -> [4] -> [5] -> NULL
               S             F

Step 3:
[1] -> [2] -> [3] -> [4] -> [5] -> NULL
                      S            F (NULL)

F is NULL! NO CYCLE.
```

### Complexity
- **Time:** O(n)
- **Space:** O(1) - only two pointers

---

## Dry Run

### Floyd's Algorithm

**Input:** 1 -> 2 -> 3 -> 4 -> 5 -> 3 (cycle)

| Step | Slow Position | Fast Position | Action |
|------|--------------|---------------|--------|
| 0 | 1 | 1 | Initialize |
| 1 | 2 | 3 | Move: S+1, F+2 |
| 2 | 3 | 5 | Move: S+1, F+2 |
| 3 | 4 | 4 | Move: F wraps to 3, then to 4 |
| 4 | 5 | 3 | Move |
| 5 | 3 | 5 | S wraps |
| 6 | 4 | 4 | MEET! Cycle detected |

**Output:** True

---

## Mathematical Proof

Let:
- `m` = distance from head to cycle start
- `k` = distance from cycle start to meeting point
- `L` = length of cycle

When they meet:
- Slow traveled: `m + k`
- Fast traveled: `m + k + nL` (for some n >= 1)

Since fast travels twice the distance:
```
2(m + k) = m + k + nL
m + k = nL
```

This proves they will meet after slow enters the cycle.

---

## Edge Cases

1. **Empty list:** No cycle (return False)
2. **Single node (no cycle):** Points to NULL
3. **Single node with cycle:** Points to itself
4. **Cycle at head:** First node points back to itself

```
Empty:         NULL -> False

Single:        [1] -> NULL -> False

Self-loop:     [1] ←→ (points to itself) -> True
                ↺

Cycle at 2nd:  [1] -> [2] ←→ (2 points to itself) -> True
```

---

## Comparison

| Approach | Time | Space | Pros | Cons |
|----------|------|-------|------|------|
| Hash Set | O(n) | O(n) | Simple | Extra memory |
| Floyd's | O(n) | O(1) | No extra memory | Slightly complex |

---

## Key Takeaways

1. **Floyd's Cycle Detection** is the optimal solution
2. **Two pointers with different speeds** will meet in a cycle
3. **No cycle** means fast pointer reaches NULL
4. This is a foundational algorithm for many linked list problems
