# QuickSort for Linked List [Very Important]

## Problem Statement

Sort a linked list using QuickSort algorithm.

**Example:**
```
Input:  3 -> 5 -> 2 -> 4 -> 1 -> NULL
Output: 1 -> 2 -> 3 -> 4 -> 5 -> NULL
```

---

## Intuition

### QuickSort Overview

QuickSort works by:
1. **Select a pivot** element
2. **Partition** list into elements smaller than pivot and greater than pivot
3. **Recursively** sort the partitions
4. **Combine** the sorted partitions with pivot in middle

```
For Linked Lists, we choose LAST node as pivot (easier to implement)

Original:    [3] -> [5] -> [2] -> [4] -> [1]
                                          ^pivot

Partition around 1:
  Less than 1:    (empty)
  Equal to 1:     [1]
  Greater than 1: [3] -> [5] -> [2] -> [4]

Combine: (empty) + [1] + (recursively sorted greater)
```

### Why QuickSort is NOT Preferred for Linked Lists

```
Arrays vs Linked Lists for QuickSort:

Arrays:
- O(1) random access for pivot selection
- O(1) swap operations
- Can use median-of-three for good pivot

Linked Lists:
- O(n) to access middle element
- Partitioning by changing pointers
- Usually use first or last as pivot (may cause O(n^2) worst case)

CONCLUSION: Merge Sort is generally better for linked lists!
```

---

## Algorithm

### Approach 1: Partition Around Last Element

```
QuickSort Steps for Linked List:

1. Find the last node (pivot)
2. Partition into three lists:
   - smaller: nodes < pivot
   - equal: nodes == pivot
   - greater: nodes > pivot
3. Recursively sort smaller and greater
4. Concatenate: sorted_smaller + equal + sorted_greater

Visual:
[3] -> [5] -> [2] -> [4] -> [1]
                              ^pivot = 1

After partition:
  smaller: (empty)
  equal:   [1]
  greater: [3] -> [5] -> [2] -> [4]

Recursively sort greater with pivot = 4:
  smaller: [3] -> [2]
  equal:   [4]
  greater: [5]

Continue until single elements...
```

### Partition Process

```
Partitioning [3] -> [5] -> [2] -> [4] around pivot 4:

Initialize:
  smaller_head = smaller_tail = dummy1
  equal_head = equal_tail = dummy2
  greater_head = greater_tail = dummy3

Process each node:
  3 < 4: add to smaller  -> smaller: [3]
  5 > 4: add to greater  -> greater: [5]
  2 < 4: add to smaller  -> smaller: [3] -> [2]
  4 == 4: add to equal   -> equal: [4]

Result:
  smaller: [3] -> [2]
  equal:   [4]
  greater: [5]
```

---

## Visual Walkthrough

### Complete QuickSort Execution

```
Original: [3] -> [5] -> [2] -> [4] -> [1]

Step 1: Pivot = 1 (last node)
        smaller: (empty)
        equal: [1]
        greater: [3] -> [5] -> [2] -> [4]

Step 2: Recursively sort greater: [3] -> [5] -> [2] -> [4]
        Pivot = 4
        smaller: [3] -> [2]
        equal: [4]
        greater: [5]

Step 3: Recursively sort smaller: [3] -> [2]
        Pivot = 2
        smaller: (empty)
        equal: [2]
        greater: [3]

Step 4: Base cases reached, combine:
        [2] + [3] = [2] -> [3]

Step 5: Combine with [4] and [5]:
        [2] -> [3] + [4] + [5] = [2] -> [3] -> [4] -> [5]

Step 6: Combine with [1]:
        [1] + [2] -> [3] -> [4] -> [5] = [1] -> [2] -> [3] -> [4] -> [5]

Final: [1] -> [2] -> [3] -> [4] -> [5] -> NULL
```

---

## Dry Run

### Input: [3, 5, 2, 4, 1]

| Step | List | Pivot | Smaller | Equal | Greater |
|------|------|-------|---------|-------|---------|
| 1 | [3,5,2,4,1] | 1 | [] | [1] | [3,5,2,4] |
| 2 | [3,5,2,4] | 4 | [3,2] | [4] | [5] |
| 3 | [3,2] | 2 | [] | [2] | [3] |
| 4 | Combine | - | - | - | [2,3] |
| 5 | Combine | - | - | - | [2,3,4,5] |
| 6 | Combine | - | - | - | [1,2,3,4,5] |

---

## Complexity Analysis

| Case | Time | Space | Description |
|------|------|-------|-------------|
| Best | O(n log n) | O(log n) | Balanced partitions |
| Average | O(n log n) | O(log n) | Random data |
| Worst | O(n^2) | O(n) | Already sorted (bad pivot) |

```
Why worst case happens:
- If we always pick smallest/largest as pivot
- One partition is empty, other has n-1 elements
- Example: Sorted list with last element as pivot

Already sorted: [1] -> [2] -> [3] -> [4] -> [5]
Pivot = 5: smaller = [1,2,3,4], equal = [5], greater = []
Pivot = 4: smaller = [1,2,3], equal = [4], greater = []
... continues for O(n) levels with O(n) work each = O(n^2)
```

---

## Comparison: QuickSort vs MergeSort for Linked Lists

| Aspect | QuickSort | MergeSort |
|--------|-----------|-----------|
| Time (Average) | O(n log n) | O(n log n) |
| Time (Worst) | O(n^2) | O(n log n) |
| Space | O(log n) to O(n) | O(log n) |
| Stability | Can be stable | Stable |
| Preferred? | No | **Yes** |

---

## Edge Cases

```
1. Empty list:      NULL -> NULL
2. Single node:     [1] -> [1]
3. Two nodes:       [2]->[1] -> [1]->[2]
4. Already sorted:  [1]->[2]->[3] -> [1]->[2]->[3] (worst case)
5. Reverse sorted:  [3]->[2]->[1] -> [1]->[2]->[3]
6. All same:        [2]->[2]->[2] -> [2]->[2]->[2]
```

---

## Key Takeaways

1. **QuickSort CAN be implemented** for linked lists, but **not ideal**
2. **Picking pivot** is tricky - usually use first or last node
3. **Worst case O(n^2)** for already sorted lists
4. **MergeSort is preferred** for linked lists (guaranteed O(n log n))
5. **Useful to understand** for interview discussions about tradeoffs
