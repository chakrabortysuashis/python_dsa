"""
QuickSort for Linked List [Very Important]
==========================================

Problem: Sort a linked list using QuickSort algorithm.

Example:
    Input:  3 -> 5 -> 2 -> 4 -> 1 -> NULL
    Output: 1 -> 2 -> 3 -> 4 -> 5 -> NULL

Note: While QuickSort works for linked lists, MergeSort is generally
preferred because QuickSort's random access advantage doesn't apply to LL.
"""


class ListNode:
    """Definition for singly-linked list node."""
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

    def __repr__(self):
        return f"ListNode({self.val})"


# =============================================================================
# QUICKSORT IMPLEMENTATION
# =============================================================================

def quicksort(head: ListNode) -> ListNode:
    """
    Sort linked list using QuickSort.

    Algorithm:
    1. Base case: if list has 0 or 1 nodes, return
    2. Choose last node as pivot
    3. Partition into three lists: smaller, equal, greater
    4. Recursively sort smaller and greater
    5. Concatenate: smaller + equal + greater

    Time Complexity: O(n log n) average, O(n^2) worst case
    Space Complexity: O(log n) average for recursion stack
    """
    if head is None or head.next is None:
        return head

    # Find end of list (to get last node as pivot)
    head, tail = quicksort_helper(head, get_tail(head))
    return head


def quicksort_helper(head: ListNode, tail: ListNode) -> tuple:
    """
    Helper function for quicksort.
    Returns (new_head, new_tail) of sorted portion.
    """
    # Base cases
    if head is None:
        return None, None
    if head == tail:
        return head, tail

    # Partition around tail (pivot)
    new_head, new_tail, pivot = partition(head, tail)

    # If smaller part exists, sort it
    if new_head != pivot:
        # Find node before pivot
        temp = new_head
        while temp.next != pivot:
            temp = temp.next
        temp.next = None  # Disconnect pivot

        # Sort smaller part
        new_head, temp_tail = quicksort_helper(new_head, temp)

        # Connect sorted smaller to pivot
        temp_tail.next = pivot

    # Sort greater part (nodes after pivot)
    pivot.next, new_tail = quicksort_helper(pivot.next, new_tail)

    if new_tail is None:
        new_tail = pivot

    return new_head, new_tail


def partition(head: ListNode, tail: ListNode) -> tuple:
    """
    Partition the list around tail node (pivot).

    Algorithm:
    - Use tail as pivot
    - Traverse list, move smaller nodes before pivot
    - Return (new_head, new_tail, pivot)

    Visual:
    [3] -> [5] -> [2] -> [4] -> [1]   pivot = 1
                                ^

    After partition:
    [1] -> [3] -> [5] -> [2] -> [4]
    ^pivot (moved to front since all others are larger)
    """
    pivot = tail
    prev = None
    curr = head
    new_tail = pivot

    while curr != pivot:
        if curr.val < pivot.val:
            # Keep this node in smaller section
            if prev is None:
                head = curr
            else:
                prev.next = curr
            prev = curr
            curr = curr.next
        else:
            # Move node to end (after pivot position tracking)
            if prev is None:
                head = curr.next
            else:
                prev.next = curr.next

            # Move curr to after new_tail
            temp = curr.next
            curr.next = None
            new_tail.next = curr
            new_tail = curr
            curr = temp

    # If all elements were >= pivot, pivot becomes head
    if prev is None:
        head = pivot
    else:
        prev.next = pivot

    return head, new_tail, pivot


def get_tail(head: ListNode) -> ListNode:
    """Get the last node of the list."""
    if head is None:
        return None
    while head.next:
        head = head.next
    return head


# =============================================================================
# ALTERNATIVE: CLEANER THREE-WAY PARTITION
# =============================================================================

def quicksort_clean(head: ListNode) -> ListNode:
    """
    Cleaner implementation using three-way partition.

    This version explicitly creates three separate lists:
    - smaller: nodes with value < pivot
    - equal: nodes with value == pivot
    - greater: nodes with value > pivot

    Then concatenates them after recursively sorting smaller and greater.
    """
    if head is None or head.next is None:
        return head

    # Use last node as pivot
    pivot_val = get_tail(head).val

    # Create three dummy heads for partition
    smaller_dummy = ListNode(0)
    equal_dummy = ListNode(0)
    greater_dummy = ListNode(0)

    smaller = smaller_dummy
    equal = equal_dummy
    greater = greater_dummy

    # Partition
    curr = head
    while curr:
        if curr.val < pivot_val:
            smaller.next = curr
            smaller = smaller.next
        elif curr.val > pivot_val:
            greater.next = curr
            greater = greater.next
        else:
            equal.next = curr
            equal = equal.next
        curr = curr.next

    # Terminate all lists
    smaller.next = None
    equal.next = None
    greater.next = None

    # Recursively sort smaller and greater
    sorted_smaller = quicksort_clean(smaller_dummy.next)
    sorted_greater = quicksort_clean(greater_dummy.next)

    # Concatenate: smaller + equal + greater
    return concatenate(sorted_smaller, equal_dummy.next, sorted_greater)


def concatenate(smaller: ListNode, equal: ListNode, greater: ListNode) -> ListNode:
    """
    Concatenate three lists: smaller + equal + greater.
    Returns the head of the combined list.
    """
    dummy = ListNode(0)
    tail = dummy

    # Add smaller part
    if smaller:
        tail.next = smaller
        while tail.next:
            tail = tail.next

    # Add equal part
    if equal:
        tail.next = equal
        while tail.next:
            tail = tail.next

    # Add greater part
    if greater:
        tail.next = greater

    return dummy.next


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def create_linked_list(values: list) -> ListNode:
    """Create a linked list from a list of values."""
    if not values:
        return None

    head = ListNode(values[0])
    current = head

    for val in values[1:]:
        current.next = ListNode(val)
        current = current.next

    return head


def linked_list_to_list(head: ListNode) -> list:
    """Convert linked list to Python list."""
    result = []
    current = head

    while current:
        result.append(current.val)
        current = current.next

    return result


def print_linked_list(head: ListNode) -> str:
    """Print linked list in readable format."""
    values = linked_list_to_list(head)
    if not values:
        return "NULL"
    return " -> ".join(map(str, values)) + " -> NULL"


# =============================================================================
# TEST CASES
# =============================================================================

def test_quicksort():
    """Test QuickSort implementations."""
    print("=" * 60)
    print("QUICKSORT FOR LINKED LIST - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal unsorted list
    print("\n--- Test Case 1: [3, 5, 2, 4, 1] ---")
    head = create_linked_list([3, 5, 2, 4, 1])
    print(f"Original: {print_linked_list(head)}")
    sorted_head = quicksort_clean(head)
    print(f"Sorted:   {print_linked_list(sorted_head)}")
    assert linked_list_to_list(sorted_head) == [1, 2, 3, 4, 5]
    print("Passed!")

    # Test Case 2: Already sorted (worst case for naive pivot)
    print("\n--- Test Case 2: [1, 2, 3, 4, 5] (already sorted) ---")
    head = create_linked_list([1, 2, 3, 4, 5])
    print(f"Original: {print_linked_list(head)}")
    sorted_head = quicksort_clean(head)
    print(f"Sorted:   {print_linked_list(sorted_head)}")
    assert linked_list_to_list(sorted_head) == [1, 2, 3, 4, 5]
    print("Passed!")

    # Test Case 3: Reverse sorted
    print("\n--- Test Case 3: [5, 4, 3, 2, 1] (reverse sorted) ---")
    head = create_linked_list([5, 4, 3, 2, 1])
    print(f"Original: {print_linked_list(head)}")
    sorted_head = quicksort_clean(head)
    print(f"Sorted:   {print_linked_list(sorted_head)}")
    assert linked_list_to_list(sorted_head) == [1, 2, 3, 4, 5]
    print("Passed!")

    # Test Case 4: With duplicates
    print("\n--- Test Case 4: [3, 1, 2, 1, 3] (with duplicates) ---")
    head = create_linked_list([3, 1, 2, 1, 3])
    print(f"Original: {print_linked_list(head)}")
    sorted_head = quicksort_clean(head)
    print(f"Sorted:   {print_linked_list(sorted_head)}")
    assert linked_list_to_list(sorted_head) == [1, 1, 2, 3, 3]
    print("Passed!")

    # Test Case 5: Single node
    print("\n--- Test Case 5: [1] (single node) ---")
    head = create_linked_list([1])
    print(f"Original: {print_linked_list(head)}")
    sorted_head = quicksort_clean(head)
    print(f"Sorted:   {print_linked_list(sorted_head)}")
    assert linked_list_to_list(sorted_head) == [1]
    print("Passed!")

    # Test Case 6: Empty list
    print("\n--- Test Case 6: Empty list ---")
    head = None
    sorted_head = quicksort_clean(head)
    print(f"Original: NULL")
    print(f"Sorted:   NULL")
    assert sorted_head is None
    print("Passed!")

    # Test Case 7: Two nodes
    print("\n--- Test Case 7: [2, 1] (two nodes) ---")
    head = create_linked_list([2, 1])
    print(f"Original: {print_linked_list(head)}")
    sorted_head = quicksort_clean(head)
    print(f"Sorted:   {print_linked_list(sorted_head)}")
    assert linked_list_to_list(sorted_head) == [1, 2]
    print("Passed!")

    # Test Case 8: All same elements
    print("\n--- Test Case 8: [2, 2, 2, 2] (all same) ---")
    head = create_linked_list([2, 2, 2, 2])
    print(f"Original: {print_linked_list(head)}")
    sorted_head = quicksort_clean(head)
    print(f"Sorted:   {print_linked_list(sorted_head)}")
    assert linked_list_to_list(sorted_head) == [2, 2, 2, 2]
    print("Passed!")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_partition():
    """Demonstrate the partition process."""
    print("\n" + "=" * 60)
    print("PARTITION DEMONSTRATION")
    print("=" * 60)

    print("\nInput: [3, 5, 2, 4, 1], Pivot = 1 (last element)")
    print("\nPartitioning process:")
    print("  Node 3: 3 > 1, goes to GREATER")
    print("  Node 5: 5 > 1, goes to GREATER")
    print("  Node 2: 2 > 1, goes to GREATER")
    print("  Node 4: 4 > 1, goes to GREATER")
    print("  Node 1: 1 == 1, goes to EQUAL")
    print()
    print("After partition:")
    print("  smaller: (empty)")
    print("  equal:   [1]")
    print("  greater: [3] -> [5] -> [2] -> [4]")
    print()
    print("Next: Recursively sort greater list...")


if __name__ == "__main__":
    test_quicksort()
    demonstrate_partition()
