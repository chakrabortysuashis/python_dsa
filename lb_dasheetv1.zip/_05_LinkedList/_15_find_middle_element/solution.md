# Find Middle Element of Linked List

## Problem Statement

Given a singly linked list, find the middle node. If there are two middle nodes (even length), return the second middle node.

**Example:**
```
Input:  1 -> 2 -> 3 -> 4 -> 5 -> NULL
Output: 3

Input:  1 -> 2 -> 3 -> 4 -> 5 -> 6 -> NULL
Output: 4 (second middle)
```

---

## Intuition

### Naive Approach: Two-Pass

```
Pass 1: Count total nodes (n)
Pass 2: Traverse to node at position n/2

Time: O(n) + O(n/2) = O(n)
Space: O(1)
```

### Optimal Approach: Slow-Fast Pointers (Tortoise and Hare)

```
Key Insight:
If slow moves 1 step and fast moves 2 steps,
when fast reaches the end, slow is at the middle!

Why it works:
- fast covers 2x distance of slow
- When fast finishes n nodes, slow has done n/2 nodes
- slow is exactly at the middle!

Visual for odd length [1, 2, 3, 4, 5]:

Step 0:  [1] -> [2] -> [3] -> [4] -> [5] -> NULL
          s
          f

Step 1:  [1] -> [2] -> [3] -> [4] -> [5] -> NULL
                 s
                        f

Step 2:  [1] -> [2] -> [3] -> [4] -> [5] -> NULL
                        s
                                      f

fast.next is NULL, stop! slow points to 3 (middle)
```

---

## Algorithm

### Slow-Fast Pointer Method

```python
def find_middle(head):
    slow = fast = head
    
    while fast and fast.next:
        slow = slow.next      # Move 1 step
        fast = fast.next.next # Move 2 steps
    
    return slow  # slow is at middle
```

---

## Visual Walkthrough

### Case 1: Odd Length List [1, 2, 3, 4, 5]

```
Initial:
[1] -> [2] -> [3] -> [4] -> [5] -> NULL
 ^
s,f

After iteration 1:
slow = slow.next  (move to 2)
fast = fast.next.next  (move to 3)

[1] -> [2] -> [3] -> [4] -> [5] -> NULL
        ^      ^
        s      f

After iteration 2:
slow = slow.next  (move to 3)
fast = fast.next.next  (move to 5)

[1] -> [2] -> [3] -> [4] -> [5] -> NULL
               ^             ^
               s             f

Check: fast.next is NULL, exit loop
Middle = slow = node with value 3
```

### Case 2: Even Length List [1, 2, 3, 4, 5, 6]

```
Initial:
[1] -> [2] -> [3] -> [4] -> [5] -> [6] -> NULL
 ^
s,f

After iteration 1:
[1] -> [2] -> [3] -> [4] -> [5] -> [6] -> NULL
        ^      ^
        s      f

After iteration 2:
[1] -> [2] -> [3] -> [4] -> [5] -> [6] -> NULL
               ^             ^
               s             f

After iteration 3:
[1] -> [2] -> [3] -> [4] -> [5] -> [6] -> NULL
                      ^                    ^
                      s                    f

Check: fast is at 6, fast.next is NULL, exit loop
Middle = slow = node with value 4 (second middle)
```

### Finding First Middle (for even length)

```
To get FIRST middle for even length, stop when fast.next.next is NULL:

Modified condition:
while fast.next and fast.next.next:
    slow = slow.next
    fast = fast.next.next

For [1, 2, 3, 4, 5, 6]:
Result: 3 (first middle)
```

---

## Dry Run

### Input: [1, 2, 3, 4, 5]

| Iteration | slow | fast | Condition |
|-----------|------|------|-----------|
| 0 (init) | 1 | 1 | - |
| 1 | 2 | 3 | fast=3, fast.next=4 (continue) |
| 2 | 3 | 5 | fast=5, fast.next=NULL (stop) |

**Result: Middle = 3**

### Input: [1, 2, 3, 4]

| Iteration | slow | fast | Condition |
|-----------|------|------|-----------|
| 0 (init) | 1 | 1 | - |
| 1 | 2 | 3 | fast=3, fast.next=4 (continue) |
| 2 | 3 | NULL | fast=NULL (stop) |

**Result: Middle = 3 (second middle)**

---

## Complexity Analysis

| Approach | Time | Space |
|----------|------|-------|
| Two-pass counting | O(n) | O(1) |
| Slow-fast pointers | O(n/2) = O(n) | O(1) |

```
Slow-fast is preferred because:
1. Single pass through the list
2. No need to know length beforehand
3. Works with streams (unknown total length)
```

---

## Edge Cases

```
1. Single node:     [1] -> returns 1
2. Two nodes:       [1] -> [2] -> returns 2
3. Three nodes:     [1] -> [2] -> [3] -> returns 2
4. Empty list:      NULL -> returns NULL

Visual:
Single: [1] -> NULL
         ^
        s,f (fast.next is NULL, return slow = 1)

Two: [1] -> [2] -> NULL
      ^
     s,f
     
After 1 iteration:
     [1] -> [2] -> NULL
             ^      ^
             s      f(NULL)
Return slow = 2
```

---

## Variations

### Get Middle Node for Splitting (Merge Sort Use Case)

For merge sort, we want the node **before** the middle to split:

```python
def get_middle_for_split(head):
    slow = head
    fast = head
    prev = None
    
    while fast and fast.next:
        prev = slow
        slow = slow.next
        fast = fast.next.next
    
    return prev  # Node before middle (for splitting)
```

---

## Key Takeaways

1. **Slow-fast pointer** is the optimal technique
2. **Single pass** - no need to count first
3. For **even length**, returns second middle by default
4. Adjust loop condition for first middle if needed
5. **Foundation technique** used in many LL problems (cycle detection, etc.)
