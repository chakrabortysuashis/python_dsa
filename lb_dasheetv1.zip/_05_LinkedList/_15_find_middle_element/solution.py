"""
Find Middle Element of Linked List
===================================

Problem: Given a singly linked list, find the middle node.
         If there are two middle nodes, return the second middle.

Example:
    Input:  1 -> 2 -> 3 -> 4 -> 5 -> NULL
    Output: 3

    Input:  1 -> 2 -> 3 -> 4 -> 5 -> 6 -> NULL
    Output: 4 (second middle)
"""


class ListNode:
    """Definition for singly-linked list node."""
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

    def __repr__(self):
        return f"ListNode({self.val})"


# =============================================================================
# APPROACH 1: SLOW-FAST POINTERS (Optimal)
# =============================================================================

def find_middle(head: ListNode) -> ListNode:
    """
    Find middle node using slow-fast (tortoise-hare) technique.

    Algorithm:
    1. Initialize slow and fast pointers at head
    2. Move slow 1 step, fast 2 steps each iteration
    3. When fast reaches end, slow is at middle

    Why it works:
    - fast covers 2x the distance of slow
    - When fast finishes n nodes, slow has done n/2
    - For even length, this returns the SECOND middle

    Visual for [1, 2, 3, 4, 5]:
    Init:  s,f at 1
    Step1: s at 2, f at 3
    Step2: s at 3, f at 5 (f.next is NULL, stop)
    Return: 3

    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    if head is None:
        return None

    slow = head
    fast = head

    # Move fast 2 steps, slow 1 step
    # Stop when fast reaches end or second-to-last node
    while fast is not None and fast.next is not None:
        slow = slow.next
        fast = fast.next.next

    # slow is now at middle
    return slow


# =============================================================================
# APPROACH 2: FIRST MIDDLE (for even length)
# =============================================================================

def find_first_middle(head: ListNode) -> ListNode:
    """
    Find the FIRST middle for even-length lists.

    For odd length: same as second middle
    For even length [1,2,3,4]: returns 2 (not 3)

    Algorithm:
    - Modified condition to stop one step earlier for even length

    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    if head is None or head.next is None:
        return head

    slow = head
    fast = head

    # Stop when fast.next.next becomes None
    while fast.next is not None and fast.next.next is not None:
        slow = slow.next
        fast = fast.next.next

    return slow


# =============================================================================
# APPROACH 3: TWO-PASS (Counting)
# =============================================================================

def find_middle_counting(head: ListNode) -> ListNode:
    """
    Find middle using two-pass counting method.

    Algorithm:
    1. First pass: Count total nodes
    2. Second pass: Traverse to n/2 position

    Less efficient than slow-fast but easier to understand.

    Time Complexity: O(n) + O(n/2) = O(n)
    Space Complexity: O(1)
    """
    if head is None:
        return None

    # First pass: count nodes
    count = 0
    current = head
    while current:
        count += 1
        current = current.next

    # Second pass: go to middle
    middle_pos = count // 2
    current = head
    for _ in range(middle_pos):
        current = current.next

    return current


# =============================================================================
# APPROACH 4: GET MIDDLE FOR SPLITTING (Merge Sort helper)
# =============================================================================

def get_middle_for_split(head: ListNode) -> ListNode:
    """
    Get the node BEFORE the middle (useful for splitting in merge sort).

    For [1,2,3,4,5]: returns 2 (so we can split: [1,2] | [3,4,5])
    For [1,2,3,4]: returns 2 (so we can split: [1,2] | [3,4])

    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    if head is None or head.next is None:
        return head

    slow = head
    fast = head
    prev = None

    while fast is not None and fast.next is not None:
        prev = slow
        slow = slow.next
        fast = fast.next.next

    return prev


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def create_linked_list(values: list) -> ListNode:
    """Create a linked list from a list of values."""
    if not values:
        return None

    head = ListNode(values[0])
    current = head

    for val in values[1:]:
        current.next = ListNode(val)
        current = current.next

    return head


def linked_list_to_list(head: ListNode) -> list:
    """Convert linked list to Python list."""
    result = []
    current = head

    while current:
        result.append(current.val)
        current = current.next

    return result


def print_linked_list(head: ListNode) -> str:
    """Print linked list in readable format."""
    values = linked_list_to_list(head)
    if not values:
        return "NULL"
    return " -> ".join(map(str, values)) + " -> NULL"


# =============================================================================
# TEST CASES
# =============================================================================

def test_find_middle():
    """Test all find middle implementations."""
    print("=" * 60)
    print("FIND MIDDLE ELEMENT - TEST CASES")
    print("=" * 60)

    # Test Case 1: Odd length list
    print("\n--- Test Case 1: [1, 2, 3, 4, 5] (odd length) ---")
    head = create_linked_list([1, 2, 3, 4, 5])
    print(f"List: {print_linked_list(head)}")
    middle = find_middle(head)
    print(f"Middle (slow-fast): {middle.val}")
    assert middle.val == 3
    print("Passed!")

    # Test Case 2: Even length list
    print("\n--- Test Case 2: [1, 2, 3, 4, 5, 6] (even length) ---")
    head = create_linked_list([1, 2, 3, 4, 5, 6])
    print(f"List: {print_linked_list(head)}")
    middle = find_middle(head)
    print(f"Second Middle (slow-fast): {middle.val}")
    assert middle.val == 4
    first_middle = find_first_middle(head)
    print(f"First Middle: {first_middle.val}")
    assert first_middle.val == 3
    print("Passed!")

    # Test Case 3: Single node
    print("\n--- Test Case 3: [1] (single node) ---")
    head = create_linked_list([1])
    print(f"List: {print_linked_list(head)}")
    middle = find_middle(head)
    print(f"Middle: {middle.val}")
    assert middle.val == 1
    print("Passed!")

    # Test Case 4: Two nodes
    print("\n--- Test Case 4: [1, 2] (two nodes) ---")
    head = create_linked_list([1, 2])
    print(f"List: {print_linked_list(head)}")
    middle = find_middle(head)
    print(f"Middle (second): {middle.val}")
    assert middle.val == 2
    first_middle = find_first_middle(head)
    print(f"Middle (first): {first_middle.val}")
    assert first_middle.val == 1
    print("Passed!")

    # Test Case 5: Three nodes
    print("\n--- Test Case 5: [1, 2, 3] (three nodes) ---")
    head = create_linked_list([1, 2, 3])
    print(f"List: {print_linked_list(head)}")
    middle = find_middle(head)
    print(f"Middle: {middle.val}")
    assert middle.val == 2
    print("Passed!")

    # Test Case 6: Empty list
    print("\n--- Test Case 6: Empty list ---")
    head = None
    middle = find_middle(head)
    print(f"Middle: {middle}")
    assert middle is None
    print("Passed!")

    # Test Case 7: Counting method verification
    print("\n--- Test Case 7: Counting method [1, 2, 3, 4, 5] ---")
    head = create_linked_list([1, 2, 3, 4, 5])
    middle = find_middle_counting(head)
    print(f"Middle (counting): {middle.val}")
    assert middle.val == 3
    print("Passed!")

    # Test Case 8: Middle for split
    print("\n--- Test Case 8: Middle for split [1, 2, 3, 4, 5] ---")
    head = create_linked_list([1, 2, 3, 4, 5])
    split_point = get_middle_for_split(head)
    print(f"Split point (node before middle): {split_point.val}")
    assert split_point.val == 2
    print("Passed!")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_step_by_step():
    """Demonstrate slow-fast pointer technique step by step."""
    print("\n" + "=" * 60)
    print("STEP-BY-STEP DEMONSTRATION")
    print("=" * 60)

    print("\nExample 1: [1, 2, 3, 4, 5] (odd length)")
    print("-" * 40)
    print("Initial: slow = 1, fast = 1")
    print()
    print("Iteration 1:")
    print("  slow = slow.next -> slow at 2")
    print("  fast = fast.next.next -> fast at 3")
    print("  fast (3) and fast.next (4) exist, continue")
    print()
    print("Iteration 2:")
    print("  slow = slow.next -> slow at 3")
    print("  fast = fast.next.next -> fast at 5")
    print("  fast (5) exists but fast.next is NULL, STOP")
    print()
    print("Result: slow points to 3 (middle)")

    print("\n" + "-" * 40)
    print("\nExample 2: [1, 2, 3, 4, 5, 6] (even length)")
    print("-" * 40)
    print("Initial: slow = 1, fast = 1")
    print()
    print("Iteration 1:")
    print("  slow = 2, fast = 3")
    print()
    print("Iteration 2:")
    print("  slow = 3, fast = 5")
    print()
    print("Iteration 3:")
    print("  slow = 4, fast = NULL (past end)")
    print("  fast is NULL, STOP")
    print()
    print("Result: slow points to 4 (second middle)")


if __name__ == "__main__":
    test_find_middle()
    demonstrate_step_by_step()
