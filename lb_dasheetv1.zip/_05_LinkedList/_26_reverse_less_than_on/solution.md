# Can We Reverse a Linked List in Less Than O(n)?

## Problem Statement

Is it possible to reverse a linked list in less than O(n) time complexity?

---

## Answer: NO

### Why O(n) is the Lower Bound

```
To reverse a linked list, we MUST:
1. Visit every node at least once
2. Change every pointer

With n nodes and n-1 pointers to change,
we cannot do better than O(n).
```

---

## Mathematical Proof

```
Theorem: Reversing a linked list requires Omega(n) time.

Proof:
1. In the original list: node[i].next = node[i+1]
2. In reversed list: node[i].next = node[i-1]

3. Every single pointer must be modified
4. There are exactly n-1 pointers to modify
5. Each modification is O(1)
6. Total: O(n) operations minimum

Therefore, O(n) is both upper and lower bound = Theta(n)
```

---

## What About Parallelization?

```
With parallel processing:
- Theoretical: O(1) with O(n) processors
- Practical: O(n/p) with p processors
- Still O(n) work total

For linked lists specifically:
- Sequential access pattern
- Limited parallelization opportunities
- Memory dependencies between nodes
```

---

## Comparison with Arrays

```
Arrays:
- Can reverse with O(n/2) swaps
- But still O(n) time
- Better cache performance

Linked Lists:
- Must traverse sequentially
- O(n) pointer changes
- Poor cache locality
```

---

## Common Interview Follow-ups

```
Q: Can we do better with extra space?
A: No, time is still O(n)

Q: What about tail-recursive reversal?
A: Still O(n) time, can be O(1) space with tail optimization

Q: Doubly linked list?
A: Same O(n), but simpler (swap prev/next)
```

---

## Key Takeaways

1. **O(n) is optimal** for reversing linked list
2. **Every node must be visited** - can't skip any
3. **Every pointer must change** - n-1 modifications
4. This is a **fundamental limit**, not algorithmic weakness
5. Understanding lower bounds is important for interviews
