"""
Can We Reverse a Linked List in Less Than O(n)?
===============================================

Answer: NO - O(n) is the theoretical lower bound.

This file demonstrates WHY O(n) is optimal.
"""


class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next


def reverse_linked_list(head: ListNode) -> ListNode:
    """
    Standard O(n) reversal - this IS optimal.

    Why we can't do better:
    1. Must visit every node (n visits)
    2. Must change every pointer (n-1 changes)
    3. No way to skip nodes - sequential structure

    Time: O(n) - optimal
    Space: O(1)
    """
    prev = None
    curr = head
    operations = 0

    while curr:
        operations += 1  # Count operations
        next_node = curr.next
        curr.next = prev
        prev = curr
        curr = next_node

    print(f"Total operations: {operations} (for {operations} nodes)")
    return prev


def count_operations_needed(n: int) -> int:
    """
    Calculate minimum operations needed to reverse n nodes.

    Each node needs:
    - 1 read (current pointer)
    - 1 write (reverse pointer)

    Total: 2n operations minimum
    Best case: O(n), no improvement possible
    """
    return 2 * n  # Read + Write for each node


def demonstrate_lower_bound():
    """
    Demonstrate why O(n) is the lower bound.
    """
    print("=" * 60)
    print("WHY O(n) IS OPTIMAL FOR LINKED LIST REVERSAL")
    print("=" * 60)

    print("\n1. Every pointer must be changed:")
    print("   Original:  A -> B -> C -> D -> NULL")
    print("   Reversed:  D -> C -> B -> A -> NULL")
    print("   Changes:   3 pointer modifications for 4 nodes")
    print()

    print("2. Sequential access is required:")
    print("   - Can't jump to middle (no random access)")
    print("   - Must follow next pointers")
    print("   - Each node visited exactly once")
    print()

    print("3. Lower bound proof:")
    print("   - n nodes = n-1 pointers to change")
    print("   - Each change is O(1)")
    print("   - Total: O(n-1) = O(n)")
    print()

    print("4. No parallel speedup helps:")
    print("   - Data dependencies between nodes")
    print("   - Can't know node[i+1] without reading node[i].next")
    print()

    # Demonstrate with actual list
    print("5. Demonstration:")
    values = [1, 2, 3, 4, 5]
    head = None
    for val in reversed(values):
        head = ListNode(val, head)

    reverse_linked_list(head)
    print(f"   For {len(values)} nodes, exactly {len(values)} loop iterations")
    print()

    print("=" * 60)
    print("CONCLUSION: O(n) is both upper and lower bound")
    print("           We cannot do better than O(n)")
    print("=" * 60)


def compare_theoretical_approaches():
    """
    Compare theoretical approaches to reversal.
    """
    print("\n" + "=" * 60)
    print("COMPARISON OF APPROACHES")
    print("=" * 60)

    approaches = [
        ("Iterative (3 pointers)", "O(n)", "O(1)", "Optimal"),
        ("Recursive", "O(n)", "O(n)", "Stack space"),
        ("Tail Recursive", "O(n)", "O(1)*", "*With TCO"),
        ("Using Stack", "O(n)", "O(n)", "Extra space"),
        ("Using Array", "O(n)", "O(n)", "Extra space"),
    ]

    print(f"\n{'Approach':<25} {'Time':<10} {'Space':<10} {'Notes'}")
    print("-" * 60)
    for name, time, space, notes in approaches:
        print(f"{name:<25} {time:<10} {space:<10} {notes}")

    print("\nAll approaches are O(n) time - this is unavoidable!")


if __name__ == "__main__":
    demonstrate_lower_bound()
    compare_theoretical_approaches()
