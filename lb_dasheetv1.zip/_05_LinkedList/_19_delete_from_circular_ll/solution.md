# Delete Node from Circular Linked List

## Problem Statement

Given a circular linked list and a key, delete the first occurrence of the key from the list.

**Example:**
```
Input:  2 -> 5 -> 7 -> 8 -> 10 -> (back to 2), key = 7
Output: 2 -> 5 -> 8 -> 10 -> (back to 2)

Input:  2 -> 5 -> 7 -> (back to 2), key = 2 (delete head)
Output: 5 -> 7 -> (back to 5)
```

---

## Intuition

### Special Cases in Circular List

```
Deleting from circular list has special cases:

1. Delete head node:
   - Need to update the last node's next pointer
   - Find new head

2. Delete any other node:
   - Find the node before the target
   - Update prev.next = target.next

3. Single node:
   - If deleting the only node, return NULL
```

### Key Insight

```
In circular list, we need to handle:
1. Finding the node BEFORE the target
2. Updating the cycle connection if head is deleted

Unlike regular list, we stop when we come back to head, not at NULL.
```

---

## Algorithm

### Case Analysis

```
Case 1: Empty list
  Return NULL

Case 2: Single node (head.next == head)
  If head.val == key: return NULL
  Else: key not found, return head

Case 3: Delete head node
  - Find the last node (the one pointing to head)
  - Update last.next = head.next
  - Return head.next as new head

Case 4: Delete non-head node
  - Traverse to find node before target
  - Update prev.next = target.next
  - Return original head
```

---

## Visual Walkthrough

### Example 1: Delete Middle Node (key = 7)

```
Before:
     +---------------------------+
     |                           |
     v                           |
    [2] -> [5] -> [7] -> [8] -> [10]
                   ^
                 delete

Step 1: Start from head, find node before 7
        curr = 2, curr.next = 5 (not 7)
        curr = 5, curr.next = 7 (found!)

Step 2: Delete node 7
        5.next = 7.next = 8

After:
     +----------------------+
     |                      |
     v                      |
    [2] -> [5] -> [8] -> [10]
```

### Example 2: Delete Head Node (key = 2)

```
Before:
     +---------------------------+
     |                           |
     v                           |
    [2] -> [5] -> [7] -> [8] -> [10]
     ^
   delete (head)

Step 1: Find last node (10, which points to 2)
        Start from head, traverse until node.next == head
        Last = 10

Step 2: Update last.next to new head
        10.next = 2.next = 5

Step 3: Return new head (5)

After:
     +----------------------+
     |                      |
     v                      |
    [5] -> [7] -> [8] -> [10]
     ^
   new head
```

### Example 3: Delete Last Node (key = 10)

```
Before:
     +---------------------------+
     |                           |
     v                           |
    [2] -> [5] -> [7] -> [8] -> [10]
                                  ^
                                delete

Step 1: Find node before 10
        curr = 8, curr.next = 10 (found!)

Step 2: Update 8.next to point to head
        8.next = 10.next = 2

After:
     +-------------------+
     |                   |
     v                   |
    [2] -> [5] -> [7] -> [8]
```

---

## Dry Run

### Input: 2 -> 5 -> 7 -> 8 -> 10 -> (back to 2), key = 7

| Step | curr | curr.next | Action |
|------|------|-----------|--------|
| 1 | 2 | 5 | 5 != 7, continue |
| 2 | 5 | 7 | 7 == 7, found! |
| 3 | - | - | 5.next = 8 |

**Result: 2 -> 5 -> 8 -> 10 -> (back to 2)**

---

## Edge Cases

```
1. Empty list:
   Input: NULL, key = 5
   Output: NULL

2. Single node, key matches:
   Input: [5] -> (back to 5), key = 5
   Output: NULL

3. Single node, key doesn't match:
   Input: [5] -> (back to 5), key = 3
   Output: [5] -> (back to 5)

4. Key not found:
   Input: [2,5,7], key = 10
   Output: [2,5,7] (unchanged)

5. Delete head:
   Input: [2,5,7], key = 2
   Output: [5,7] with new head = 5

6. Delete tail (last before head):
   Input: [2,5,7], key = 7
   Output: [2,5] with 5 pointing to 2
```

---

## Complexity Analysis

| Aspect | Complexity |
|--------|------------|
| Time | O(n) |
| Space | O(1) |

```
Time: O(n) - may need to traverse entire list to find key
Space: O(1) - only using pointer variables
```

---

## Key Takeaways

1. **Head deletion is special** - need to update last node's pointer
2. **Single node case** needs careful handling
3. **Loop termination** - stop when returning to head, not NULL
4. **Keep track of previous** node for deletion
5. **Return new head** if head was deleted
