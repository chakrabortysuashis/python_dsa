"""
Delete Node from Circular Linked List
=====================================

Problem: Given a circular linked list and a key, delete the first occurrence
         of the key from the list.

Example:
    Input:  2 -> 5 -> 7 -> 8 -> 10 -> (back to 2), key = 7
    Output: 2 -> 5 -> 8 -> 10 -> (back to 2)
"""


class ListNode:
    """Definition for circular linked list node."""
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

    def __repr__(self):
        return f"ListNode({self.val})"


# =============================================================================
# MAIN SOLUTION
# =============================================================================

def delete_node(head: ListNode, key: int) -> ListNode:
    """
    Delete first occurrence of key from circular linked list.

    Cases:
    1. Empty list - return NULL
    2. Single node matching key - return NULL
    3. Delete head - update last node's pointer
    4. Delete other node - standard deletion

    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    # Case 1: Empty list
    if head is None:
        return None

    # Case 2: Single node
    if head.next == head:
        if head.val == key:
            return None  # Delete the only node
        return head  # Key not found

    # Case 3: Delete head node
    if head.val == key:
        # Find the last node (points to head)
        last = head
        while last.next != head:
            last = last.next

        # Update last node to point to new head
        last.next = head.next
        return head.next  # Return new head

    # Case 4: Delete non-head node
    # Find the node before the target
    prev = head
    curr = head.next

    while curr != head:
        if curr.val == key:
            # Found the node, delete it
            prev.next = curr.next
            return head

        prev = curr
        curr = curr.next

    # Key not found
    return head


# =============================================================================
# ALTERNATIVE: UNIFIED APPROACH
# =============================================================================

def delete_node_unified(head: ListNode, key: int) -> ListNode:
    """
    Alternative implementation with unified logic.

    This version uses a slightly different approach:
    - First find the node to delete and the node before it
    - Then handle all cases based on what was found
    """
    if head is None:
        return None

    # Special case: single node
    if head.next == head:
        return None if head.val == key else head

    # Find the node to delete and the previous node
    prev = None
    curr = head
    found = False

    # Search for key
    while True:
        if curr.val == key:
            found = True
            break

        prev = curr
        curr = curr.next

        if curr == head:  # Completed one cycle
            break

    if not found:
        return head  # Key not found

    # Now curr is the node to delete, prev is before it
    # But if curr == head, prev might be None (we need to find last node)

    if curr == head:
        # Deleting head - find last node
        last = head
        while last.next != head:
            last = last.next

        last.next = head.next
        return head.next
    else:
        # Deleting non-head node
        prev.next = curr.next
        return head


# =============================================================================
# ADDITIONAL: DELETE ALL OCCURRENCES
# =============================================================================

def delete_all_occurrences(head: ListNode, key: int) -> ListNode:
    """
    Delete all occurrences of key from circular linked list.

    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    if head is None:
        return None

    # Handle single node
    if head.next == head:
        return None if head.val == key else head

    # First, handle head nodes that need deletion
    while head and head.val == key:
        if head.next == head:
            return None  # Only one node left and it matches

        # Find last node
        last = head
        while last.next != head:
            last = last.next

        # Delete head
        last.next = head.next
        head = head.next

        # Check if we're back to single node
        if head.next == head:
            return None if head.val == key else head

    # Now head is guaranteed to not have key value
    # Delete all other occurrences
    prev = head
    curr = head.next

    while curr != head:
        if curr.val == key:
            prev.next = curr.next
            curr = prev.next
        else:
            prev = curr
            curr = curr.next

    return head


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def create_circular_list(values: list) -> ListNode:
    """Create a circular linked list from values."""
    if not values:
        return None

    head = ListNode(values[0])
    current = head

    for val in values[1:]:
        current.next = ListNode(val)
        current = current.next

    # Make it circular
    current.next = head

    return head


def circular_list_to_list(head: ListNode, max_nodes: int = 20) -> list:
    """Convert circular list to regular list (for display)."""
    if head is None:
        return []

    result = [head.val]
    current = head.next
    count = 1

    while current != head and count < max_nodes:
        result.append(current.val)
        current = current.next
        count += 1

    return result


def print_circular_list(head: ListNode) -> str:
    """Print circular list in readable format."""
    if head is None:
        return "NULL"

    values = circular_list_to_list(head)
    if not values:
        return "NULL"

    return " -> ".join(map(str, values)) + f" -> (back to {values[0]})"


# =============================================================================
# TEST CASES
# =============================================================================

def test_delete_node():
    """Test deletion from circular linked list."""
    print("=" * 60)
    print("DELETE FROM CIRCULAR LINKED LIST - TEST CASES")
    print("=" * 60)

    # Test Case 1: Delete middle node
    print("\n--- Test Case 1: Delete middle node (key=7) ---")
    head = create_circular_list([2, 5, 7, 8, 10])
    print(f"Before: {print_circular_list(head)}")
    head = delete_node(head, 7)
    print(f"After:  {print_circular_list(head)}")
    assert circular_list_to_list(head) == [2, 5, 8, 10]
    print("Passed!")

    # Test Case 2: Delete head node
    print("\n--- Test Case 2: Delete head node (key=2) ---")
    head = create_circular_list([2, 5, 7, 8, 10])
    print(f"Before: {print_circular_list(head)}")
    head = delete_node(head, 2)
    print(f"After:  {print_circular_list(head)}")
    assert circular_list_to_list(head) == [5, 7, 8, 10]
    print("Passed!")

    # Test Case 3: Delete last node
    print("\n--- Test Case 3: Delete last node (key=10) ---")
    head = create_circular_list([2, 5, 7, 8, 10])
    print(f"Before: {print_circular_list(head)}")
    head = delete_node(head, 10)
    print(f"After:  {print_circular_list(head)}")
    assert circular_list_to_list(head) == [2, 5, 7, 8]
    print("Passed!")

    # Test Case 4: Single node, delete it
    print("\n--- Test Case 4: Single node, delete it ---")
    head = create_circular_list([5])
    print(f"Before: {print_circular_list(head)}")
    head = delete_node(head, 5)
    print(f"After:  {print_circular_list(head)}")
    assert head is None
    print("Passed!")

    # Test Case 5: Single node, key not found
    print("\n--- Test Case 5: Single node, key not found ---")
    head = create_circular_list([5])
    print(f"Before: {print_circular_list(head)}")
    head = delete_node(head, 3)
    print(f"After:  {print_circular_list(head)}")
    assert circular_list_to_list(head) == [5]
    print("Passed!")

    # Test Case 6: Key not found
    print("\n--- Test Case 6: Key not found (key=99) ---")
    head = create_circular_list([2, 5, 7])
    print(f"Before: {print_circular_list(head)}")
    head = delete_node(head, 99)
    print(f"After:  {print_circular_list(head)}")
    assert circular_list_to_list(head) == [2, 5, 7]
    print("Passed!")

    # Test Case 7: Empty list
    print("\n--- Test Case 7: Empty list ---")
    head = None
    head = delete_node(head, 5)
    print(f"After:  {print_circular_list(head)}")
    assert head is None
    print("Passed!")

    # Test Case 8: Two nodes, delete head
    print("\n--- Test Case 8: Two nodes, delete head ---")
    head = create_circular_list([1, 2])
    print(f"Before: {print_circular_list(head)}")
    head = delete_node(head, 1)
    print(f"After:  {print_circular_list(head)}")
    assert circular_list_to_list(head) == [2]
    print("Passed!")

    # Test Case 9: Delete all occurrences
    print("\n--- Test Case 9: Delete all occurrences (key=5) ---")
    head = create_circular_list([5, 2, 5, 7, 5])
    print(f"Before: {print_circular_list(head)}")
    head = delete_all_occurrences(head, 5)
    print(f"After:  {print_circular_list(head)}")
    assert circular_list_to_list(head) == [2, 7]
    print("Passed!")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


if __name__ == "__main__":
    test_delete_node()
