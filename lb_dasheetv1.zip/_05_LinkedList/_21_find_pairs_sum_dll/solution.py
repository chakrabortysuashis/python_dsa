"""
Find Pairs with Given Sum in Sorted Doubly Linked List
======================================================

Problem: Given a sorted DLL and target sum, find all pairs with that sum.

Example:
    Input:  1 <-> 2 <-> 4 <-> 5 <-> 6 <-> 8 <-> 9, target = 7
    Output: [(1, 6), (2, 5)]
"""


class DLLNode:
    """Definition for doubly-linked list node."""
    def __init__(self, val=0, prev=None, next=None):
        self.val = val
        self.prev = prev
        self.next = next


# =============================================================================
# MAIN SOLUTION: TWO POINTERS
# =============================================================================

def find_pairs_with_sum(head: DLLNode, target: int) -> list:
    """
    Find all pairs in sorted DLL that sum to target.

    Algorithm:
    1. Initialize left pointer at head, right pointer at tail
    2. While left is before right:
       - If sum == target: add pair, move both pointers
       - If sum < target: move left forward
       - If sum > target: move right backward

    Time Complexity: O(n)
    Space Complexity: O(1) excluding output
    """
    if head is None:
        return []

    pairs = []

    # Initialize pointers
    left = head
    right = head

    # Move right to tail
    while right.next:
        right = right.next

    # Two pointer approach
    while left != right and is_before(left, right):
        current_sum = left.val + right.val

        if current_sum == target:
            pairs.append((left.val, right.val))
            left = left.next
            right = right.prev

        elif current_sum < target:
            left = left.next

        else:  # current_sum > target
            right = right.prev

    return pairs


def is_before(left: DLLNode, right: DLLNode) -> bool:
    """Check if left node comes before right node in the list."""
    # Since they move towards each other, if left.next leads to right, left is before right
    # Simpler: compare their positions or just check they haven't crossed
    temp = left
    while temp and temp != right:
        temp = temp.next
    return temp == right


# =============================================================================
# ALTERNATIVE: WITHOUT HELPER FUNCTION
# =============================================================================

def find_pairs_with_sum_v2(head: DLLNode, target: int) -> list:
    """
    Alternative implementation without separate is_before check.

    We can check crossing by comparing the node addresses or
    tracking when left and right have crossed.
    """
    if head is None:
        return []

    pairs = []

    # Find head and tail
    left = head
    right = head
    while right.next:
        right = right.next

    # Two pointers moving towards each other
    while left and right and left != right:
        # Check if they've crossed (left is after right)
        if left.prev == right:
            break

        current_sum = left.val + right.val

        if current_sum == target:
            pairs.append((left.val, right.val))
            left = left.next
            right = right.prev
        elif current_sum < target:
            left = left.next
        else:
            right = right.prev

    return pairs


# =============================================================================
# FIND FIRST PAIR ONLY
# =============================================================================

def find_first_pair(head: DLLNode, target: int) -> tuple:
    """
    Find the first pair that sums to target.

    Returns None if no pair exists.
    """
    if head is None:
        return None

    left = head
    right = head
    while right.next:
        right = right.next

    while left != right:
        if left.prev == right:
            break

        current_sum = left.val + right.val

        if current_sum == target:
            return (left.val, right.val)
        elif current_sum < target:
            left = left.next
        else:
            right = right.prev

    return None


# =============================================================================
# COUNT PAIRS
# =============================================================================

def count_pairs_with_sum(head: DLLNode, target: int) -> int:
    """
    Count the number of pairs that sum to target.
    """
    pairs = find_pairs_with_sum(head, target)
    return len(pairs)


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def create_sorted_dll(values: list) -> DLLNode:
    """Create a sorted DLL from values (assumes values are sorted)."""
    if not values:
        return None

    head = DLLNode(values[0])
    current = head

    for val in values[1:]:
        new_node = DLLNode(val, prev=current)
        current.next = new_node
        current = new_node

    return head


def dll_to_list(head: DLLNode) -> list:
    """Convert DLL to Python list."""
    result = []
    current = head
    while current:
        result.append(current.val)
        current = current.next
    return result


def print_dll(head: DLLNode) -> str:
    """Print DLL in readable format."""
    values = dll_to_list(head)
    if not values:
        return "NULL"
    return " <-> ".join(map(str, values))


# =============================================================================
# TEST CASES
# =============================================================================

def test_find_pairs():
    """Test finding pairs with given sum."""
    print("=" * 60)
    print("FIND PAIRS WITH SUM IN SORTED DLL - TEST CASES")
    print("=" * 60)

    # Test Case 1: Multiple pairs
    print("\n--- Test Case 1: [1,2,4,5,6,8,9], target=7 ---")
    head = create_sorted_dll([1, 2, 4, 5, 6, 8, 9])
    print(f"List: {print_dll(head)}")
    pairs = find_pairs_with_sum(head, 7)
    print(f"Target: 7")
    print(f"Pairs: {pairs}")
    assert pairs == [(1, 6), (2, 5)]
    print("Passed!")

    # Test Case 2: Single pair
    print("\n--- Test Case 2: [1,2,3,4,5], target=9 ---")
    head = create_sorted_dll([1, 2, 3, 4, 5])
    print(f"List: {print_dll(head)}")
    pairs = find_pairs_with_sum(head, 9)
    print(f"Target: 9")
    print(f"Pairs: {pairs}")
    assert pairs == [(4, 5)]
    print("Passed!")

    # Test Case 3: No pairs
    print("\n--- Test Case 3: [1,2,3], target=10 ---")
    head = create_sorted_dll([1, 2, 3])
    print(f"List: {print_dll(head)}")
    pairs = find_pairs_with_sum(head, 10)
    print(f"Target: 10")
    print(f"Pairs: {pairs}")
    assert pairs == []
    print("Passed!")

    # Test Case 4: Two nodes forming pair
    print("\n--- Test Case 4: [3,4], target=7 ---")
    head = create_sorted_dll([3, 4])
    print(f"List: {print_dll(head)}")
    pairs = find_pairs_with_sum(head, 7)
    print(f"Target: 7")
    print(f"Pairs: {pairs}")
    assert pairs == [(3, 4)]
    print("Passed!")

    # Test Case 5: First and last form pair
    print("\n--- Test Case 5: [1,5,7,9], target=10 ---")
    head = create_sorted_dll([1, 5, 7, 9])
    print(f"List: {print_dll(head)}")
    pairs = find_pairs_with_sum(head, 10)
    print(f"Target: 10")
    print(f"Pairs: {pairs}")
    assert pairs == [(1, 9)]
    print("Passed!")

    # Test Case 6: Empty list
    print("\n--- Test Case 6: Empty list ---")
    head = None
    pairs = find_pairs_with_sum(head, 5)
    print(f"Pairs: {pairs}")
    assert pairs == []
    print("Passed!")

    # Test Case 7: Single node
    print("\n--- Test Case 7: [5] (single node) ---")
    head = create_sorted_dll([5])
    pairs = find_pairs_with_sum(head, 10)
    print(f"Pairs: {pairs}")
    assert pairs == []
    print("Passed!")

    # Test Case 8: Count pairs
    print("\n--- Test Case 8: Count pairs [1,2,4,5,6,8,9], target=7 ---")
    head = create_sorted_dll([1, 2, 4, 5, 6, 8, 9])
    count = count_pairs_with_sum(head, 7)
    print(f"Count of pairs: {count}")
    assert count == 2
    print("Passed!")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_algorithm():
    """Demonstrate the two-pointer algorithm step by step."""
    print("\n" + "=" * 60)
    print("STEP-BY-STEP DEMONSTRATION")
    print("=" * 60)

    print("\nList: 1 <-> 2 <-> 4 <-> 5 <-> 6 <-> 8 <-> 9")
    print("Target: 7")
    print()
    print("Step 1: left=1, right=9, sum=10 > 7")
    print("        Move right backward")
    print()
    print("Step 2: left=1, right=8, sum=9 > 7")
    print("        Move right backward")
    print()
    print("Step 3: left=1, right=6, sum=7 == 7")
    print("        FOUND PAIR: (1, 6)")
    print("        Move both pointers")
    print()
    print("Step 4: left=2, right=5, sum=7 == 7")
    print("        FOUND PAIR: (2, 5)")
    print("        Move both pointers")
    print()
    print("Step 5: left=4, right=4")
    print("        left == right, STOP")
    print()
    print("Result: [(1, 6), (2, 5)]")


if __name__ == "__main__":
    test_find_pairs()
    demonstrate_algorithm()
