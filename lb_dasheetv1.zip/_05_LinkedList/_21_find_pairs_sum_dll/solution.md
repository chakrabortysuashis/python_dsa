# Find Pairs with Given Sum in Sorted Doubly Linked List

## Problem Statement

Given a sorted doubly linked list and a target sum, find all pairs of nodes whose sum equals the target.

**Example:**
```
Input:  1 <-> 2 <-> 4 <-> 5 <-> 6 <-> 8 <-> 9, target = 7
Output: (1, 6), (2, 5)

Explanation:
1 + 6 = 7
2 + 5 = 7
```

---

## Intuition

### Why DLL Makes This Easier

```
In a sorted array, we use two pointers:
- left pointer at start
- right pointer at end

DLL advantage: We can traverse BOTH directions!
- Start from head (left)
- Start from tail (right)
- Move pointers based on sum comparison

This is the classic two-pointer technique!
```

### Key Insight

```
For sorted list with two pointers:

If left + right > target:
  Move right pointer backward (decrease sum)

If left + right < target:
  Move left pointer forward (increase sum)

If left + right == target:
  Found a pair! Record it, move both pointers.
```

---

## Algorithm

```
1. Initialize left = head, right = tail
2. While left comes before right (left != right and they haven't crossed):
   a. Calculate sum = left.val + right.val
   b. If sum == target:
      - Add (left.val, right.val) to result
      - Move left forward, right backward
   c. If sum < target:
      - Move left forward (need larger sum)
   d. If sum > target:
      - Move right backward (need smaller sum)
3. Return all pairs found
```

---

## Visual Walkthrough

```
List: 1 <-> 2 <-> 4 <-> 5 <-> 6 <-> 8 <-> 9
      ^                               ^
     left                           right
Target = 7

Step 1: left=1, right=9
        sum = 1 + 9 = 10 > 7
        Move right backward

Step 2: left=1, right=8
        sum = 1 + 8 = 9 > 7
        Move right backward

Step 3: left=1, right=6
        sum = 1 + 6 = 7 == target!
        FOUND PAIR: (1, 6)
        Move both: left forward, right backward

Step 4: left=2, right=5
        sum = 2 + 5 = 7 == target!
        FOUND PAIR: (2, 5)
        Move both: left forward, right backward

Step 5: left=4, right=4
        left == right, STOP

Result: [(1, 6), (2, 5)]
```

---

## Dry Run

### Input: 1 <-> 2 <-> 4 <-> 5 <-> 6 <-> 8 <-> 9, target = 7

| Step | left | right | sum | Action | Pairs Found |
|------|------|-------|-----|--------|-------------|
| 1 | 1 | 9 | 10 | > target, right-- | |
| 2 | 1 | 8 | 9 | > target, right-- | |
| 3 | 1 | 6 | 7 | == target! | (1, 6) |
| 4 | 2 | 5 | 7 | == target! | (2, 5) |
| 5 | 4 | 4 | - | left == right, stop | |

**Result: [(1, 6), (2, 5)]**

---

## Complexity Analysis

| Aspect | Complexity |
|--------|------------|
| Time | O(n) |
| Space | O(1) |

```
Time: O(n)
- Each node is visited at most once by either left or right pointer
- Total operations: at most n

Space: O(1)
- Only two pointers used
- Output space not counted (or O(k) for k pairs)
```

---

## Edge Cases

```
1. No pairs exist:
   Input: 1 <-> 2 <-> 3, target = 10
   Output: []

2. Single node:
   Input: 5, target = 10
   Output: [] (can't form pair with one node)

3. Two nodes forming pair:
   Input: 3 <-> 4, target = 7
   Output: [(3, 4)]

4. Duplicate values:
   Input: 2 <-> 2 <-> 4 <-> 4, target = 6
   Output: [(2, 4), (2, 4)] - depends on requirement
```

---

## Key Takeaways

1. **Two-pointer technique** works because list is sorted
2. **DLL allows bidirectional traversal** - can start from both ends
3. **O(n) time, O(1) space** - optimal solution
4. Similar to **two-sum in sorted array** problem
5. Key decision: move left forward OR right backward based on sum comparison
