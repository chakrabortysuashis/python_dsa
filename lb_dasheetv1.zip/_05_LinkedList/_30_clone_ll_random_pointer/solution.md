# Clone a Linked List with Random Pointer

## Problem Statement

Given a linked list where each node has a next pointer and a random pointer (can point to any node or NULL), create a deep copy of the list.

**Example:**
```
Original: 1 -> 2 -> 3 -> 4 -> NULL
          |    |    |    |
          v    v    v    v
          3    1   NULL   2
          (random pointers)

Clone: Exact copy with same structure
```

---

## Approaches

### Approach 1: Using HashMap - O(n) space

```
1. First pass: Create copy of each node, store mapping old->new in hash
2. Second pass: Set next and random pointers using the mapping
```

### Approach 2: Interleaving Nodes - O(1) space

```
1. Insert cloned nodes between original nodes
   Original: 1 -> 1' -> 2 -> 2' -> 3 -> 3' -> ...

2. Set random pointers for cloned nodes
   clone.random = original.random.next

3. Separate the two lists
```

---

## Visual Walkthrough (Approach 2)

```
Step 1: Interleave cloned nodes
Before: 1 -> 2 -> 3 -> NULL
After:  1 -> 1' -> 2 -> 2' -> 3 -> 3' -> NULL

Step 2: Set random pointers
If 1.random = 3, then 1'.random = 3.next = 3'

Step 3: Separate lists
Original: 1 -> 2 -> 3 -> NULL
Clone:    1' -> 2' -> 3' -> NULL
```

---

## Complexity

| Approach | Time | Space |
|----------|------|-------|
| HashMap | O(n) | O(n) |
| Interleaving | O(n) | O(1) |

---

## Key Points

1. Random pointer can point to any node or NULL
2. Must create deep copy (new nodes)
3. Interleaving trick avoids extra space
4. Be careful when separating lists
