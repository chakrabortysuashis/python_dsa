"""
Clone a Linked List with Random Pointer
=======================================
"""


class Node:
    def __init__(self, val=0, next=None, random=None):
        self.val = val
        self.next = next
        self.random = random


def clone_with_hashmap(head: Node) -> Node:
    """
    Clone using HashMap.
    Time: O(n), Space: O(n)
    """
    if not head:
        return None

    # Map original -> clone
    node_map = {}

    # First pass: create all cloned nodes
    curr = head
    while curr:
        node_map[curr] = Node(curr.val)
        curr = curr.next

    # Second pass: set next and random
    curr = head
    while curr:
        clone = node_map[curr]
        clone.next = node_map.get(curr.next)
        clone.random = node_map.get(curr.random)
        curr = curr.next

    return node_map[head]


def clone_interleaving(head: Node) -> Node:
    """
    Clone using interleaving trick.
    Time: O(n), Space: O(1)
    """
    if not head:
        return None

    # Step 1: Create cloned nodes and interleave
    curr = head
    while curr:
        clone = Node(curr.val)
        clone.next = curr.next
        curr.next = clone
        curr = clone.next

    # Step 2: Set random pointers
    curr = head
    while curr:
        clone = curr.next
        if curr.random:
            clone.random = curr.random.next
        curr = clone.next

    # Step 3: Separate the lists
    clone_head = head.next
    curr = head
    while curr:
        clone = curr.next
        curr.next = clone.next
        if clone.next:
            clone.next = clone.next.next
        curr = curr.next

    return clone_head


# Test
def test_clone():
    print("CLONE WITH RANDOM POINTER - TESTS")

    # Create: 1 -> 2 -> 3
    n1 = Node(1)
    n2 = Node(2)
    n3 = Node(3)
    n1.next = n2
    n2.next = n3
    n1.random = n3  # 1's random -> 3
    n2.random = n1  # 2's random -> 1
    n3.random = n2  # 3's random -> 2

    # Clone
    clone = clone_interleaving(n1)

    # Verify
    assert clone.val == 1
    assert clone.next.val == 2
    assert clone.next.next.val == 3
    assert clone.random.val == 3
    assert clone.next.random.val == 1
    assert clone != n1  # Different objects

    print("Clone successful!")
    print(f"Original: 1(r->3) -> 2(r->1) -> 3(r->2)")
    print(f"Clone:    {clone.val}(r->{clone.random.val}) -> {clone.next.val}(r->{clone.next.random.val}) -> {clone.next.next.val}(r->{clone.next.next.random.val})")


if __name__ == "__main__":
    test_clone()
