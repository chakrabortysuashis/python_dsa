# Nth Node from End of Linked List

## Problem Statement

Given a linked list, find the Nth node from the end.

**Example:**
```
Input:  1 -> 2 -> 3 -> 4 -> 5 -> NULL, N = 2
Output: 4 (2nd from end)

Position from end: 5(1st) -> 4(2nd) -> 3(3rd) -> 2(4th) -> 1(5th)
```

---

## Approaches

### Approach 1: Two Pass

```
1. First pass: Count total nodes (length)
2. Second pass: Go to (length - N + 1)th node

Time: O(n), Space: O(1)
```

### Approach 2: Two Pointers (Single Pass - Optimal)

```
1. Move 'first' pointer N nodes ahead
2. Move both 'first' and 'second' until first reaches end
3. 'second' is at Nth from end

Why it works:
- First is N nodes ahead of second
- When first reaches end, second is N nodes behind
- That's exactly Nth from end!
```

---

## Visual Walkthrough (Two Pointers)

```
List: 1 -> 2 -> 3 -> 4 -> 5 -> NULL, N = 2

Step 1: Move first N=2 nodes ahead
        1 -> 2 -> 3 -> 4 -> 5 -> NULL
        ^         ^
      second    first

Step 2: Move both until first reaches NULL
        1 -> 2 -> 3 -> 4 -> 5 -> NULL
             ^         ^
           second    first

        1 -> 2 -> 3 -> 4 -> 5 -> NULL
                  ^         ^
                second    first

        1 -> 2 -> 3 -> 4 -> 5 -> NULL
                       ^         ^
                     second    first (NULL)

Step 3: first is NULL, second points to 4
        Answer: 4 (2nd from end)
```

---

## Complexity

| Approach | Time | Space |
|----------|------|-------|
| Two Pass | O(n) | O(1) |
| Two Pointers | O(n) | O(1) |

Two pointers is better: single pass!

---

## Edge Cases

```
1. N = 1: Return last node
2. N = length: Return first node
3. N > length: Invalid, return NULL
4. Empty list: Return NULL
5. Single node, N = 1: Return that node
```

---

## Key Points

1. Two pointer technique: maintain N gap
2. Single pass solution
3. Handle edge cases (N too large)
4. Classic interview question
