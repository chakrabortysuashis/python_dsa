"""
Nth Node from End of Linked List
================================
"""


class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next


def nth_from_end(head: ListNode, n: int) -> ListNode:
    """
    Find Nth node from end using two pointers.
    Single pass solution.

    Time: O(n), Space: O(1)
    """
    if not head or n <= 0:
        return None

    first = head
    second = head

    # Move first N nodes ahead
    for _ in range(n):
        if first is None:
            return None  # N is larger than list length
        first = first.next

    # Move both until first reaches end
    while first:
        first = first.next
        second = second.next

    return second


def nth_from_end_two_pass(head: ListNode, n: int) -> ListNode:
    """
    Two pass approach: count length, then traverse.
    """
    if not head or n <= 0:
        return None

    # Count length
    length = 0
    curr = head
    while curr:
        length += 1
        curr = curr.next

    if n > length:
        return None

    # Go to (length - n + 1)th node
    target_pos = length - n
    curr = head
    for _ in range(target_pos):
        curr = curr.next

    return curr


# Also useful: Remove Nth from end
def remove_nth_from_end(head: ListNode, n: int) -> ListNode:
    """
    Remove Nth node from end.
    Uses dummy node to handle removing head.
    """
    dummy = ListNode(0, head)
    first = dummy
    second = dummy

    # Move first N+1 ahead
    for _ in range(n + 1):
        if first is None:
            return head
        first = first.next

    # Move both
    while first:
        first = first.next
        second = second.next

    # Remove node
    second.next = second.next.next

    return dummy.next


# Test
def create_list(vals):
    if not vals:
        return None
    head = ListNode(vals[0])
    curr = head
    for v in vals[1:]:
        curr.next = ListNode(v)
        curr = curr.next
    return head


def list_to_array(head):
    result = []
    while head:
        result.append(head.val)
        head = head.next
    return result


def test():
    print("NTH NODE FROM END - TESTS")

    head = create_list([1, 2, 3, 4, 5])
    print(f"List: {list_to_array(head)}")

    node = nth_from_end(head, 2)
    print(f"2nd from end: {node.val}")
    assert node.val == 4

    node = nth_from_end(head, 1)
    print(f"1st from end: {node.val}")
    assert node.val == 5

    node = nth_from_end(head, 5)
    print(f"5th from end: {node.val}")
    assert node.val == 1

    # Remove test
    head = create_list([1, 2, 3, 4, 5])
    head = remove_nth_from_end(head, 2)
    print(f"After removing 2nd from end: {list_to_array(head)}")
    assert list_to_array(head) == [1, 2, 3, 5]

    print("All tests passed!")


if __name__ == "__main__":
    test()
