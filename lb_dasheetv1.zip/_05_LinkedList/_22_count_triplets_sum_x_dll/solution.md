# Count Triplets with Sum X in Sorted Doubly Linked List

## Problem Statement

Given a sorted doubly linked list and a value X, count all triplets that sum to X.

**Example:**
```
Input:  1 <-> 2 <-> 4 <-> 5 <-> 6 <-> 8 <-> 9, X = 17
Output: 2
Triplets: (2, 6, 9) and (4, 5, 8)
```

---

## Intuition

### Extending Two-Pointer to Triplets

```
For pairs, we used two pointers from both ends.
For triplets, we:
1. Fix one element (iterate through list)
2. Find pairs that sum to (X - fixed element) in remaining list

This reduces triplet problem to multiple pair problems!
```

### Key Insight

```
For each node as first element:
  remaining_sum = X - first.val
  Find pairs with sum = remaining_sum in remaining list

Example: X = 17, first = 2
  remaining = 17 - 2 = 15
  Find pairs summing to 15 in [4, 5, 6, 8, 9]
  Found: (6, 9) -> Triplet (2, 6, 9)
```

---

## Algorithm

```
count = 0
for each node 'first' in list:
    remaining = X - first.val
    
    # Two pointers for pairs
    left = first.next
    right = tail
    
    while left != right and left is before right:
        pair_sum = left.val + right.val
        
        if pair_sum == remaining:
            count += 1
            left = left.next
            right = right.prev
        elif pair_sum < remaining:
            left = left.next
        else:
            right = right.prev

return count
```

---

## Visual Walkthrough

```
List: 1 <-> 2 <-> 4 <-> 5 <-> 6 <-> 8 <-> 9
X = 17

--- First = 1, need pairs summing to 16 ---
Remaining list: 2 <-> 4 <-> 5 <-> 6 <-> 8 <-> 9
left=2, right=9: 2+9=11 < 16, move left
left=4, right=9: 4+9=13 < 16, move left
left=5, right=9: 5+9=14 < 16, move left
left=6, right=9: 6+9=15 < 16, move left
left=8, right=9: 8+9=17 > 16, move right
left=8, right=8: left==right, stop
No pairs found for first=1

--- First = 2, need pairs summing to 15 ---
Remaining list: 4 <-> 5 <-> 6 <-> 8 <-> 9
left=4, right=9: 4+9=13 < 15, move left
left=5, right=9: 5+9=14 < 15, move left
left=6, right=9: 6+9=15 == 15, FOUND! (2, 6, 9)
Count = 1, move both

--- First = 4, need pairs summing to 13 ---
left=5, right=9: 5+9=14 > 13, move right
left=5, right=8: 5+8=13 == 13, FOUND! (4, 5, 8)
Count = 2

Continue for rest... (no more found)

Result: 2 triplets
```

---

## Complexity Analysis

| Aspect | Complexity |
|--------|------------|
| Time | O(n^2) |
| Space | O(1) |

```
Time: O(n^2)
- Outer loop: O(n) for each first element
- Inner two-pointer: O(n) for pair finding
- Total: O(n) * O(n) = O(n^2)

Space: O(1)
- Only using pointers
```

---

## Edge Cases

```
1. Less than 3 nodes: No triplets possible
2. No valid triplets: Return 0
3. All same values: Count based on combination
4. Negative numbers: Algorithm still works
```

---

## Key Takeaways

1. **Reduce triplet to pair problem** by fixing one element
2. **Two-pointer technique** for pair finding
3. **Time: O(n^2)** - can't do better for triplets in general
4. **Sorted list** enables two-pointer optimization
