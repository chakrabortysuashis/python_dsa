"""
Count Triplets with Sum X in Sorted Doubly Linked List
======================================================

Problem: Given a sorted DLL and X, count triplets that sum to X.

Example:
    Input:  1 <-> 2 <-> 4 <-> 5 <-> 6 <-> 8 <-> 9, X = 17
    Output: 2 (triplets: (2,6,9) and (4,5,8))
"""


class DLLNode:
    def __init__(self, val=0, prev=None, next=None):
        self.val = val
        self.prev = prev
        self.next = next


def count_triplets(head: DLLNode, X: int) -> int:
    """
    Count triplets in sorted DLL that sum to X.

    Algorithm:
    1. For each node as first element
    2. Find pairs in remaining list that sum to (X - first.val)
    3. Use two-pointer technique for pair finding

    Time: O(n^2), Space: O(1)
    """
    if head is None:
        return 0

    # Find tail
    tail = head
    while tail.next:
        tail = tail.next

    count = 0
    first = head

    # Fix first element and find pairs
    while first and first.next and first.next.next:
        remaining = X - first.val

        # Two pointers for pair
        left = first.next
        right = tail

        while left != right and is_before(left, right):
            pair_sum = left.val + right.val

            if pair_sum == remaining:
                count += 1
                left = left.next
                right = right.prev
            elif pair_sum < remaining:
                left = left.next
            else:
                right = right.prev

        first = first.next

    return count


def is_before(left: DLLNode, right: DLLNode) -> bool:
    """Check if left comes before right."""
    temp = left
    while temp and temp != right:
        temp = temp.next
    return temp == right


def find_triplets(head: DLLNode, X: int) -> list:
    """Return all triplets (not just count)."""
    if head is None:
        return []

    tail = head
    while tail.next:
        tail = tail.next

    triplets = []
    first = head

    while first and first.next and first.next.next:
        remaining = X - first.val
        left = first.next
        right = tail

        while left != right and is_before(left, right):
            pair_sum = left.val + right.val

            if pair_sum == remaining:
                triplets.append((first.val, left.val, right.val))
                left = left.next
                right = right.prev
            elif pair_sum < remaining:
                left = left.next
            else:
                right = right.prev

        first = first.next

    return triplets


# Helper functions
def create_dll(values):
    if not values:
        return None
    head = DLLNode(values[0])
    curr = head
    for val in values[1:]:
        node = DLLNode(val, prev=curr)
        curr.next = node
        curr = node
    return head


def test_count_triplets():
    print("=" * 50)
    print("COUNT TRIPLETS - TEST CASES")
    print("=" * 50)

    # Test 1
    head = create_dll([1, 2, 4, 5, 6, 8, 9])
    result = count_triplets(head, 17)
    triplets = find_triplets(head, 17)
    print(f"\nList: [1,2,4,5,6,8,9], X=17")
    print(f"Count: {result}")
    print(f"Triplets: {triplets}")
    assert result == 2

    # Test 2
    head = create_dll([1, 2, 3, 4, 5])
    result = count_triplets(head, 9)
    triplets = find_triplets(head, 9)
    print(f"\nList: [1,2,3,4,5], X=9")
    print(f"Count: {result}")
    print(f"Triplets: {triplets}")

    # Test 3: No triplets
    head = create_dll([1, 2, 3])
    result = count_triplets(head, 100)
    print(f"\nList: [1,2,3], X=100")
    print(f"Count: {result}")
    assert result == 0

    print("\nAll tests passed!")


if __name__ == "__main__":
    test_count_triplets()
