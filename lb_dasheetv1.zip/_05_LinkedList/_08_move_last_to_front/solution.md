# Move the Last Element to Front

## Problem Statement

Given a singly linked list, move the last element to the front of the list.

**Example:**
```
Input:  1 -> 2 -> 3 -> 4 -> 5 -> NULL
Output: 5 -> 1 -> 2 -> 3 -> 4 -> NULL
```

---

## Intuition

We need to:
1. Find the last node
2. Find the second-to-last node
3. Make the last node the new head
4. Make the second-to-last node point to NULL

```
Before:
HEAD -> [1] -> [2] -> [3] -> [4] -> [5] -> NULL
                             ^       ^
                        2nd last   last

After:
HEAD -> [5] -> [1] -> [2] -> [3] -> [4] -> NULL
         ^                           ^
        new                      new last
       head                    (points to NULL)
```

---

## Algorithm

```
1. Handle edge cases (empty, single node)
2. Traverse to find second-to-last node
3. Save last node
4. Set second-to-last.next = NULL
5. Set last.next = head
6. Return last as new head
```

---

## Visual Walkthrough

**Input:** 1 -> 2 -> 3 -> 4 -> 5 -> NULL

```
Step 1: Find second-to-last node
[1] -> [2] -> [3] -> [4] -> [5] -> NULL
                      ^       ^
                   secLast   last

Step 2: Store last node and disconnect
[1] -> [2] -> [3] -> [4] -> NULL    [5]
                      ^              ^
                   secLast         last

Step 3: Connect last to head
     +------------------------+
     |                        |
     v                        |
[5] -> [1] -> [2] -> [3] -> [4] -> NULL
 ^
new head
```

**Result:** 5 -> 1 -> 2 -> 3 -> 4 -> NULL

---

## Complexity

- **Time:** O(n) - single traversal to find second-to-last
- **Space:** O(1) - only a few pointers

---

## Edge Cases

1. **Empty list:** Return NULL
2. **Single node:** Already at front, return as is
3. **Two nodes:** Simple swap

```
Single:  [1] -> NULL  =>  [1] -> NULL (no change)

Two:     [1] -> [2] -> NULL  =>  [2] -> [1] -> NULL
```
