"""
Move the Last Element to Front
==============================

Problem: Given a singly linked list, move the last element to the front.

Example:
    Input:  1 -> 2 -> 3 -> 4 -> 5 -> NULL
    Output: 5 -> 1 -> 2 -> 3 -> 4 -> NULL
"""


class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next


def move_last_to_front(head: ListNode) -> ListNode:
    """
    Move the last element to the front of the list.

    Algorithm:
    1. Handle edge cases (empty, single node)
    2. Traverse to find second-to-last node
    3. Store last node
    4. Disconnect last from end
    5. Connect last to head
    6. Return last as new head

    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    # Edge cases
    if not head or not head.next:
        return head

    # Find second-to-last node
    second_last = head
    while second_last.next.next:
        second_last = second_last.next

    # Last node
    last = second_last.next

    # Disconnect last from end
    second_last.next = None

    # Connect last to head
    last.next = head

    # Return last as new head
    return last


# =============================================================================
# HELPER FUNCTIONS AND TESTS
# =============================================================================

def create_linked_list(values):
    if not values:
        return None
    head = ListNode(values[0])
    curr = head
    for val in values[1:]:
        curr.next = ListNode(val)
        curr = curr.next
    return head


def linked_list_to_list(head):
    result = []
    while head:
        result.append(head.val)
        head = head.next
    return result


def test_move_last_to_front():
    print("=" * 60)
    print("MOVE LAST TO FRONT - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal list
    print("\n--- Test Case 1: Normal List ---")
    head = create_linked_list([1, 2, 3, 4, 5])
    print(f"Input:  {linked_list_to_list(head)}")
    result = move_last_to_front(head)
    print(f"Output: {linked_list_to_list(result)}")
    assert linked_list_to_list(result) == [5, 1, 2, 3, 4]
    print("Assertion passed!")

    # Test Case 2: Two nodes
    print("\n--- Test Case 2: Two Nodes ---")
    head = create_linked_list([1, 2])
    print(f"Input:  {linked_list_to_list(head)}")
    result = move_last_to_front(head)
    print(f"Output: {linked_list_to_list(result)}")
    assert linked_list_to_list(result) == [2, 1]
    print("Assertion passed!")

    # Test Case 3: Single node
    print("\n--- Test Case 3: Single Node ---")
    head = create_linked_list([1])
    print(f"Input:  {linked_list_to_list(head)}")
    result = move_last_to_front(head)
    print(f"Output: {linked_list_to_list(result)}")
    assert linked_list_to_list(result) == [1]
    print("Assertion passed!")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


if __name__ == "__main__":
    test_move_last_to_front()
