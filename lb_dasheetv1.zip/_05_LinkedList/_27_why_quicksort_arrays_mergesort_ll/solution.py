"""
Why QuickSort for Arrays and MergeSort for Linked Lists?
========================================================

This file demonstrates the key differences.
"""


class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next


# =============================================================================
# DEMONSTRATION: Random Access Difference
# =============================================================================

def array_random_access(arr, index):
    """O(1) random access in array."""
    return arr[index]  # Instant!


def list_access(head, index):
    """O(n) access in linked list."""
    current = head
    count = 0
    while current and count < index:
        current = current.next
        count += 1
    return current  # Had to traverse!


# =============================================================================
# DEMONSTRATION: Pivot Selection
# =============================================================================

def quicksort_pivot_array(arr, low, high):
    """
    Array: O(1) to select middle element as pivot.
    Can use median-of-three easily.
    """
    mid = (low + high) // 2
    return arr[mid]  # O(1)


def quicksort_pivot_list(head):
    """
    List: O(n) to find middle element.
    Must traverse with slow-fast pointers.
    """
    slow = fast = head
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
    return slow  # O(n) traversal required


# =============================================================================
# DEMONSTRATION: Merge Step
# =============================================================================

def merge_arrays(arr, left, mid, right):
    """
    Array merge: REQUIRES O(n) extra space.
    Must copy elements to temporary array.
    """
    temp = []  # Extra space needed!

    i, j = left, mid + 1
    while i <= mid and j <= right:
        if arr[i] <= arr[j]:
            temp.append(arr[i])
            i += 1
        else:
            temp.append(arr[j])
            j += 1

    # Copy remaining
    while i <= mid:
        temp.append(arr[i])
        i += 1
    while j <= right:
        temp.append(arr[j])
        j += 1

    # Copy back
    for i, val in enumerate(temp):
        arr[left + i] = val


def merge_lists(left, right):
    """
    List merge: NO extra space needed!
    Just rearrange pointers.
    """
    dummy = ListNode(0)
    tail = dummy

    while left and right:
        if left.val <= right.val:
            tail.next = left  # Just change pointer
            left = left.next
        else:
            tail.next = right
            right = right.next
        tail = tail.next

    tail.next = left if left else right
    return dummy.next


# =============================================================================
# COMPARISON TABLE
# =============================================================================

def print_comparison():
    """Print comparison table."""
    print("=" * 70)
    print("WHY QUICKSORT FOR ARRAYS AND MERGESORT FOR LINKED LISTS?")
    print("=" * 70)

    print("\n" + "-" * 70)
    print(f"{'Aspect':<25} {'QuickSort (Array)':<22} {'MergeSort (List)'}")
    print("-" * 70)

    comparisons = [
        ("Random Access", "O(1) - excellent", "O(n) - poor"),
        ("Pivot Selection", "Easy, O(1)", "Hard, O(n)"),
        ("Partitioning", "In-place swap", "Pointer changes"),
        ("Merge Space", "O(n) extra needed", "O(1) - just pointers!"),
        ("Cache Performance", "Excellent", "Poor"),
        ("Worst Case", "O(n^2) possible", "Always O(n log n)"),
        ("Stability", "Not stable", "Stable"),
        ("Overall Best For", "Arrays", "Linked Lists"),
    ]

    for aspect, quick, merge in comparisons:
        print(f"{aspect:<25} {quick:<22} {merge}")

    print("-" * 70)

    print("\n" + "=" * 70)
    print("KEY REASONS:")
    print("=" * 70)
    print("""
1. RANDOM ACCESS:
   - Arrays have O(1) random access
   - Lists require O(n) traversal
   - QuickSort needs random access for good pivot

2. MERGE OPERATION:
   - Array merge needs O(n) extra space (copy elements)
   - List merge needs O(1) space (just change pointers)
   - MergeSort's weakness becomes strength for lists!

3. CACHE LOCALITY:
   - Arrays are contiguous in memory
   - Lists are scattered (poor cache performance)
   - QuickSort benefits from array's cache locality

4. GUARANTEED PERFORMANCE:
   - QuickSort can degrade to O(n^2)
   - MergeSort is always O(n log n)
   - For lists, guaranteed performance is preferred
""")


def demonstrate():
    """Run demonstrations."""
    print_comparison()

    print("\n" + "=" * 70)
    print("DEMONSTRATION")
    print("=" * 70)

    # Array random access
    arr = [3, 1, 4, 1, 5, 9, 2, 6]
    print(f"\nArray: {arr}")
    print(f"Access index 4: {array_random_access(arr, 4)} (O(1))")

    # List traversal
    head = ListNode(3)
    current = head
    for val in [1, 4, 1, 5, 9, 2, 6]:
        current.next = ListNode(val)
        current = current.next

    print(f"\nLinked List: 3 -> 1 -> 4 -> 1 -> 5 -> 9 -> 2 -> 6")
    node = list_access(head, 4)
    print(f"Access index 4: {node.val} (O(n) - had to traverse!)")


if __name__ == "__main__":
    demonstrate()
