# Why QuickSort for Arrays and MergeSort for Linked Lists?

## The Question

Why do we prefer QuickSort for Arrays but MergeSort for Linked Lists?

---

## Quick Answer

```
Arrays:  QuickSort preferred (better cache, in-place)
Lists:   MergeSort preferred (no random access needed, no extra space for merge)
```

---

## Detailed Analysis

### QuickSort for Arrays

**Advantages:**
```
1. In-place sorting - O(1) extra space
2. Cache-friendly - sequential memory access
3. Constant factors are small
4. Tail-call optimization possible

Performance:
- Average: O(n log n)
- Worst: O(n^2) but rare with good pivot
- Space: O(log n) for recursion
```

**Why NOT for Linked Lists:**
```
1. Random access needed for good pivot selection
   Array: arr[mid] = O(1)
   List:  traverse n/2 nodes = O(n)

2. Partitioning is expensive
   Array: swap elements O(1)
   List:  rearrange pointers O(1) but complex

3. Worst case more likely
   Can't use median-of-three easily
```

---

### MergeSort for Linked Lists

**Advantages:**
```
1. Only sequential access needed
   Finding middle: slow-fast pointers O(n)
   Splitting: O(1) pointer change

2. Merging is efficient
   No extra array needed!
   Just rearrange pointers

3. Guaranteed O(n log n)
   No worst case degradation

4. Stable sort
   Maintains relative order
```

**Why NOT for Arrays:**
```
1. Requires O(n) extra space for merging
2. Not in-place
3. More memory movement
4. Worse cache performance
```

---

## Visual Comparison

```
QUICKSORT PIVOT SELECTION:

Array:
[3, 1, 4, 1, 5, 9, 2, 6]
     ^random access O(1)

Linked List:
3 -> 1 -> 4 -> 1 -> 5 -> 9 -> 2 -> 6
          ^need to traverse O(n)


MERGESORT MERGE STEP:

Array (needs extra space):
[1, 3, 5] + [2, 4, 6] -> copy to temp array

Linked List (no extra space):
1 -> 3 -> 5    just change
2 -> 4 -> 6    pointers!
Result: 1 -> 2 -> 3 -> 4 -> 5 -> 6
```

---

## Complexity Comparison

| Aspect | QuickSort (Array) | MergeSort (List) |
|--------|-------------------|------------------|
| Time Average | O(n log n) | O(n log n) |
| Time Worst | O(n^2) | O(n log n) |
| Space | O(log n) | O(log n)* |
| Stability | No | Yes |
| Cache | Excellent | Poor for arrays |

*MergeSort for lists uses O(log n) for recursion, O(1) for merge

---

## Key Takeaways

1. **Random access** is the key differentiator
2. **Cache locality** favors QuickSort for arrays
3. **Pointer manipulation** favors MergeSort for lists
4. **Guaranteed performance** with MergeSort
5. This is a **classic interview question** - know the reasons!
