# Find the Starting Point of the Loop

## Problem Statement

Given a linked list that contains a cycle, find the node where the cycle begins.

**Example:**
```
Input:  1 -> 2 -> 3 -> 4 -> 5
                  ^         |
                  |_________|

Output: Node with value 3 (the cycle starts here)
```

---

## Intuition

### Understanding the Problem

We need to find the **exact node** where the cycle begins - the first node that is part of the loop.

```
[1] -> [2] -> [3] -> [4] -> [5]
               ^             |
               |_____________|
               ↑
        This is what we want to find
```

### Why Not Just Detect?

Detection only tells us if a cycle exists. Finding the starting point requires understanding the **mathematical relationship** between distances.

---

## Floyd's Algorithm Extended

### The Mathematical Insight

Let's define:
- `m` = distance from head to cycle start
- `k` = distance from cycle start to meeting point
- `L` = length of the cycle

```
HEAD                    CYCLE START          MEETING POINT
  |                          |                     |
  v                          v                     v
[H]--m steps-->[C1]---------[C2]-------...->[Cn]---+
                ^                                  |
                |____________L steps_______________|
                     ↑
              k steps from C1 to meeting point
```

### When Slow and Fast Meet

At the meeting point:
- **Slow traveled:** `m + k` steps
- **Fast traveled:** `m + k + n*L` steps (where n >= 1, fast went around the cycle n times)

Since fast moves twice as fast:
```
2(m + k) = m + k + n*L
m + k = n*L
m = n*L - k
m = (n-1)*L + (L - k)
```

### The Key Insight

`m = (n-1)*L + (L - k)`

This means:
- Distance from **head to cycle start** (m)
- Equals **(n-1) complete cycles** plus **distance from meeting point to cycle start** (L - k)

So if we start one pointer at **head** and one at **meeting point**, and move both by 1 step, they will meet at the **cycle start**!

---

## Visual Walkthrough

**List:** 1 -> 2 -> 3 -> 4 -> 5 -> 3

```
m = 2 (distance from 1 to 3)
L = 3 (cycle length: 3 -> 4 -> 5 -> 3)

Phase 1: Detect and find meeting point
-------------------------------------------
Step 0: S,F at 1
Step 1: S at 2, F at 3
Step 2: S at 3, F at 5
Step 3: S at 4, F at 4  <- MEET!

Meeting point: Node 4
k = 1 (distance from 3 to 4)
```

```
Phase 2: Find cycle start
-------------------------------------------
Reset slow to head (1), keep fast at meeting point (4)

Pointer1 at 1, Pointer2 at 4
Pointer1 at 2, Pointer2 at 5
Pointer1 at 3, Pointer2 at 3  <- MEET!

Cycle starts at: Node 3
```

---

## Algorithm

```
1. Use Floyd's algorithm to detect cycle and find meeting point
2. Reset one pointer to head
3. Move both pointers one step at a time
4. They will meet at the cycle start
```

---

## Dry Run

**Input:** 1 -> 2 -> 3 -> 4 -> 5 -> 3

| Phase | Slow | Fast | Action |
|-------|------|------|--------|
| Detect | 1 | 1 | Initialize |
| Detect | 2 | 3 | Move S+1, F+2 |
| Detect | 3 | 5 | Move S+1, F+2 |
| Detect | 4 | 4 | MEET! (F went 5->3->4) |
| Find | 1 | 4 | Reset slow to head |
| Find | 2 | 5 | Move both +1 |
| Find | 3 | 3 | MEET at cycle start! |

**Output:** Node 3

---

## Edge Cases

1. **Cycle at head:** Entire list is a cycle
2. **Self-loop:** Single node points to itself
3. **No cycle:** Return NULL
4. **Two-node cycle:** a -> b -> a

```
Cycle at head:  [1] -> [2] -> [3] -> [1]
                 ^                    |
                 |____________________|
                Start = 1

Self-loop:      [1] ↺
                Start = 1

Two nodes:      [1] -> [2] -> [1]
                 ^            |
                 |____________|
                Start = 1
```

---

## Complexity Analysis

- **Time:** O(n) - Linear in both phases
- **Space:** O(1) - Only two pointers

---

## Why This Works - Intuitive Explanation

Imagine two runners:
1. One starts at the **beginning of a track**
2. One starts **inside a circular part** of the track

If they run at the same speed, they will meet exactly at the **entrance to the circular part**.

This is because:
- The first runner covers the straight part
- The second runner covers the remaining distance in the circle
- These distances are mathematically equal!

---

## Key Takeaways

1. **Mathematical relationship** between distances is the key
2. **Reset one pointer to head** after finding meeting point
3. **Move both at same speed** - they meet at cycle start
4. This extends Floyd's detection algorithm elegantly
