"""
Find the Starting Point of the Loop
=====================================

Problem: Given a linked list that contains a cycle, find the node
         where the cycle begins.

Example:
    Input:  1 -> 2 -> 3 -> 4 -> 5 -> 3 (cycle to node 3)
    Output: Node with value 3
"""


class ListNode:
    """Definition for singly-linked list node."""
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

    def __repr__(self):
        return f"ListNode({self.val})"


# =============================================================================
# APPROACH 1: FLOYD'S ALGORITHM (OPTIMAL)
# =============================================================================

def detect_cycle_start(head: ListNode) -> ListNode:
    """
    Find the starting node of the cycle using Floyd's algorithm.

    Algorithm:
    1. Use slow/fast pointers to find meeting point inside cycle
    2. Reset one pointer to head
    3. Move both one step at a time
    4. They will meet at cycle start

    Mathematical Proof:
    Let m = distance from head to cycle start
        k = distance from cycle start to meeting point
        L = cycle length

    At meeting point:
    - Slow traveled: m + k
    - Fast traveled: m + k + n*L (n complete cycles)

    Since fast = 2 * slow:
    2(m + k) = m + k + n*L
    m = n*L - k

    This means: distance from head to cycle start (m) equals
    distance from meeting point to cycle start (n*L - k = multiple of L minus k)

    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    if not head or not head.next:
        return None

    # Phase 1: Find meeting point using Floyd's algorithm
    slow = head
    fast = head

    # Move pointers until they meet or fast reaches end
    while fast and fast.next:
        slow = slow.next          # Move 1 step
        fast = fast.next.next     # Move 2 steps

        if slow == fast:
            # Found meeting point
            break
    else:
        # No cycle
        return None

    # Phase 2: Find cycle start
    # Reset slow to head, keep fast at meeting point
    slow = head

    # Move both one step at a time
    while slow != fast:
        slow = slow.next
        fast = fast.next

    # They meet at cycle start
    return slow


# =============================================================================
# APPROACH 2: HASH SET
# =============================================================================

def detect_cycle_start_hashset(head: ListNode) -> ListNode:
    """
    Find cycle start using hash set.

    Algorithm:
    1. Traverse list, storing each node in a set
    2. First node we see twice is the cycle start

    Time Complexity: O(n)
    Space Complexity: O(n)
    """
    visited = set()
    current = head

    while current:
        if current in visited:
            return current
        visited.add(current)
        current = current.next

    return None  # No cycle


# =============================================================================
# APPROACH 3: MARKING NODES (MODIFYING DATA)
# =============================================================================

def detect_cycle_start_marking(head: ListNode) -> ListNode:
    """
    Find cycle start by marking visited nodes.

    Note: This modifies the list data, which may not be allowed.
    Using a special marker value.

    Time Complexity: O(n)
    Space Complexity: O(1) but modifies data
    """
    MARKER = float('inf')
    current = head

    while current:
        if current.val == MARKER:
            return current
        current.val = MARKER  # Mark as visited
        current = current.next

    return None


# =============================================================================
# VARIANT: FIND CYCLE LENGTH
# =============================================================================

def cycle_length_from_start(cycle_start: ListNode) -> int:
    """
    Given the cycle start node, find the cycle length.

    Time Complexity: O(L) where L is cycle length
    Space Complexity: O(1)
    """
    if not cycle_start:
        return 0

    length = 1
    current = cycle_start.next

    while current != cycle_start:
        length += 1
        current = current.next

    return length


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def create_linked_list_with_cycle(values: list, cycle_pos: int) -> ListNode:
    """
    Create a linked list with a cycle.

    Args:
        values: List of values for nodes
        cycle_pos: Index where the cycle starts (-1 for no cycle)
    """
    if not values:
        return None

    head = ListNode(values[0])
    current = head
    cycle_node = None

    if cycle_pos == 0:
        cycle_node = head

    for i, val in enumerate(values[1:], 1):
        current.next = ListNode(val)
        current = current.next

        if i == cycle_pos:
            cycle_node = current

    if cycle_node:
        current.next = cycle_node

    return head


def print_list_safe(head: ListNode, max_nodes: int = 20) -> str:
    """Print list safely (handles cycles)."""
    if not head:
        return "NULL"

    result = []
    current = head
    visited = set()
    count = 0

    while current and count < max_nodes:
        if current in visited:
            result.append(f"[CYCLE to {current.val}]")
            break

        result.append(str(current.val))
        visited.add(current)
        current = current.next
        count += 1

    if current is None:
        result.append("NULL")

    return " -> ".join(result)


# =============================================================================
# TEST CASES
# =============================================================================

def test_detect_cycle_start():
    """Test cycle start detection implementations."""
    print("=" * 60)
    print("FIND LOOP STARTING POINT - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal cycle
    print("\n--- Test Case 1: Normal Cycle (5 -> 3) ---")
    head = create_linked_list_with_cycle([1, 2, 3, 4, 5], 2)
    print(f"List: {print_list_safe(head)}")

    result = detect_cycle_start(head)
    print(f"Cycle starts at: {result.val if result else 'None'}")
    assert result.val == 3
    print("Assertion passed!")

    # Test Case 2: Self-loop
    print("\n--- Test Case 2: Self-loop ---")
    head = ListNode(1)
    head.next = head
    print(f"List: 1 -> [CYCLE to 1]")

    result = detect_cycle_start(head)
    print(f"Cycle starts at: {result.val if result else 'None'}")
    assert result.val == 1
    print("Assertion passed!")

    # Test Case 3: Cycle at head
    print("\n--- Test Case 3: Cycle at Head ---")
    head = create_linked_list_with_cycle([1, 2, 3], 0)
    print(f"List: {print_list_safe(head)}")

    result = detect_cycle_start(head)
    print(f"Cycle starts at: {result.val if result else 'None'}")
    assert result.val == 1
    print("Assertion passed!")

    # Test Case 4: No cycle
    print("\n--- Test Case 4: No Cycle ---")
    head = create_linked_list_with_cycle([1, 2, 3, 4, 5], -1)
    print(f"List: {print_list_safe(head)}")

    result = detect_cycle_start(head)
    print(f"Cycle starts at: {result.val if result else 'None'}")
    assert result is None
    print("Assertion passed!")

    # Test Case 5: Two-node cycle
    print("\n--- Test Case 5: Two-node Cycle ---")
    head = create_linked_list_with_cycle([1, 2], 0)
    print(f"List: {print_list_safe(head)}")

    result = detect_cycle_start(head)
    print(f"Cycle starts at: {result.val if result else 'None'}")
    assert result.val == 1
    print("Assertion passed!")

    # Test Case 6: Cycle length
    print("\n--- Test Case 6: Find Cycle Length ---")
    head = create_linked_list_with_cycle([1, 2, 3, 4, 5], 2)
    print(f"List: {print_list_safe(head)}")

    cycle_start = detect_cycle_start(head)
    length = cycle_length_from_start(cycle_start)
    print(f"Cycle start: {cycle_start.val}")
    print(f"Cycle length: {length}")
    assert length == 3  # 3 -> 4 -> 5 -> 3
    print("Assertion passed!")

    # Test Case 7: Hash set approach
    print("\n--- Test Case 7: Hash Set Approach ---")
    head = create_linked_list_with_cycle([1, 2, 3, 4, 5], 2)
    result = detect_cycle_start_hashset(head)
    print(f"Cycle starts at (hashset): {result.val if result else 'None'}")
    assert result.val == 3
    print("Assertion passed!")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_algorithm():
    """Demonstrate the algorithm step by step."""
    print("\n" + "=" * 60)
    print("ALGORITHM DEMONSTRATION")
    print("=" * 60)

    print("\nList: 1 -> 2 -> 3 -> 4 -> 5 -> 3 (cycle)")
    print("m = 2 (distance from head to cycle start)")
    print("L = 3 (cycle length: 3 -> 4 -> 5)")

    print("\n" + "-" * 40)
    print("PHASE 1: Find Meeting Point")
    print("-" * 40)

    # Simulate Phase 1
    nodes = [1, 2, 3, 4, 5]
    cycle_start_idx = 2

    slow = 0
    fast = 0
    step = 0

    def next_idx(idx):
        return idx + 1 if idx < len(nodes) - 1 else cycle_start_idx

    print(f"Step {step}: Slow at {nodes[slow]}, Fast at {nodes[fast]}")

    while True:
        step += 1
        slow = next_idx(slow)
        fast = next_idx(next_idx(fast))

        print(f"Step {step}: Slow at {nodes[slow]}, Fast at {nodes[fast]}", end="")

        if slow == fast:
            print(" <- MEET!")
            break
        print()

    meeting_point = slow
    print(f"\nMeeting point: Node {nodes[meeting_point]}")

    print("\n" + "-" * 40)
    print("PHASE 2: Find Cycle Start")
    print("-" * 40)

    # Reset ptr1 to head, ptr2 at meeting point
    ptr1 = 0
    ptr2 = meeting_point

    print(f"PTR1 at head ({nodes[ptr1]}), PTR2 at meeting ({nodes[ptr2]})")

    while ptr1 != ptr2:
        ptr1 = next_idx(ptr1)
        ptr2 = next_idx(ptr2)
        print(f"PTR1 at {nodes[ptr1]}, PTR2 at {nodes[ptr2]}", end="")

        if ptr1 == ptr2:
            print(" <- MEET! Cycle start found!")
        else:
            print()

    print(f"\nCycle starts at: Node {nodes[ptr1]}")


if __name__ == "__main__":
    test_detect_cycle_start()
    demonstrate_algorithm()
