# Reverse a Linked List

## Problem Statement

Given the head of a singly linked list, reverse the list and return the reversed list's head.

**Example:**
```
Input:  1 -> 2 -> 3 -> 4 -> 5 -> NULL
Output: 5 -> 4 -> 3 -> 2 -> 1 -> NULL
```

---

## Intuition

### Understanding the Problem

In a linked list, each node points to the **next** node. To reverse it, we need to make each node point to its **previous** node instead.

```
Original:
[1] ---> [2] ---> [3] ---> [4] ---> [5] ---> NULL
     next    next    next    next

Reversed:
NULL <--- [1] <--- [2] <--- [3] <--- [4] <--- [5]
      prev    prev    prev    prev
```

### Key Insight

We need to **change the direction of each arrow** (pointer) from pointing to the next node to pointing to the previous node.

The challenge: When we change a node's `next` pointer, we lose the reference to the next node! So we need to save it first.

---

## Approach 1: Iterative (Three Pointers)

### Concept

Use three pointers:
- `prev`: The previous node (starts as NULL)
- `curr`: The current node being processed
- `next_node`: Save the next node before we modify the pointer

### Visual Walkthrough

```
Initial State:
prev = NULL
curr = head

NULL     [1] --> [2] --> [3] --> [4] --> [5] --> NULL
 ^        ^
prev    curr
```

**Step 1: Process node 1**
```
1. Save next_node = curr.next (node 2)
2. Reverse pointer: curr.next = prev (1 now points to NULL)
3. Move prev to curr
4. Move curr to next_node

NULL <-- [1]     [2] --> [3] --> [4] --> [5] --> NULL
          ^       ^
        prev    curr
```

**Step 2: Process node 2**
```
1. Save next_node = curr.next (node 3)
2. Reverse pointer: curr.next = prev (2 now points to 1)
3. Move prev to curr
4. Move curr to next_node

NULL <-- [1] <-- [2]     [3] --> [4] --> [5] --> NULL
                  ^       ^
                prev    curr
```

**Step 3: Process node 3**
```
NULL <-- [1] <-- [2] <-- [3]     [4] --> [5] --> NULL
                          ^       ^
                        prev    curr
```

**Step 4: Process node 4**
```
NULL <-- [1] <-- [2] <-- [3] <-- [4]     [5] --> NULL
                                  ^       ^
                                prev    curr
```

**Step 5: Process node 5**
```
NULL <-- [1] <-- [2] <-- [3] <-- [4] <-- [5]     NULL
                                          ^       ^
                                        prev    curr

curr is NULL, so we stop!
prev is the new head.
```

### Algorithm

```
1. Initialize prev = NULL, curr = head
2. While curr is not NULL:
   a. Save next_node = curr.next
   b. Reverse: curr.next = prev
   c. Move prev = curr
   d. Move curr = next_node
3. Return prev (new head)
```

### Complexity
- **Time:** O(n) - visit each node once
- **Space:** O(1) - only use three pointers

---

## Approach 2: Recursive

### Concept

The recursive approach works by:
1. Recursively reverse the rest of the list
2. Make the next node point back to current node
3. Set current node's next to NULL

### Recursion Tree

For list: 1 -> 2 -> 3 -> NULL

```
reverse(1)
    |
    +-- reverse(2)
            |
            +-- reverse(3)
                    |
                    +-- reverse(NULL) --> returns NULL (base case)
                    |
                    3.next is NULL, return 3 as new_head
            |
            new_head = 3
            2.next.next = 2  (i.e., 3.next = 2)
            2.next = NULL
            return new_head (3)
    |
    new_head = 3
    1.next.next = 1  (i.e., 2.next = 1)
    1.next = NULL
    return new_head (3)
|
Final: 3 -> 2 -> 1 -> NULL
```

### Visual Step-by-Step

**Initial Call: reverse(1)**
```
[1] --> [2] --> [3] --> NULL
 ^
node
```

**Recursive call: reverse(2)**
```
[1] --> [2] --> [3] --> NULL
         ^
        node
```

**Recursive call: reverse(3)**
```
[1] --> [2] --> [3] --> NULL
                 ^
                node
node.next is NULL, so return node (3) as new_head
```

**Back to reverse(2):**
```
new_head = 3

Make 3 point to 2:
node.next.next = node
2.next.next = 2
3.next = 2

[1] --> [2] <-- [3]
         |
         v
        NULL (2.next = NULL)

Return new_head (3)
```

**Back to reverse(1):**
```
new_head = 3

Make 2 point to 1:
node.next.next = node
1.next.next = 1
2.next = 1

[1] <-- [2] <-- [3]
 |
 v
NULL (1.next = NULL)

Return new_head (3)
```

**Final Result:**
```
new_head
   |
   v
  [3] --> [2] --> [1] --> NULL
```

### Complexity
- **Time:** O(n) - visit each node once
- **Space:** O(n) - recursion call stack

---

## Dry Run

### Iterative Approach

**Input:** 1 -> 2 -> 3 -> NULL

| Step | prev | curr | next_node | Action | List State |
|------|------|------|-----------|--------|------------|
| Init | NULL | 1 | - | - | 1->2->3->NULL |
| 1 | NULL | 1 | 2 | 1.next = NULL | NULL<-1  2->3->NULL |
| 2 | 1 | 2 | 3 | 2.next = 1 | NULL<-1<-2  3->NULL |
| 3 | 2 | 3 | NULL | 3.next = 2 | NULL<-1<-2<-3 |
| End | 3 | NULL | - | Return prev | 3->2->1->NULL |

**Output:** 3 -> 2 -> 1 -> NULL

### Recursive Approach

**Input:** 1 -> 2 -> 3 -> NULL

```
Call Stack:
reverse(1) --> reverse(2) --> reverse(3) --> return 3

Unwinding:
reverse(3): return 3
reverse(2): 3.next = 2, 2.next = NULL, return 3
reverse(1): 2.next = 1, 1.next = NULL, return 3

Output: 3 -> 2 -> 1 -> NULL
```

---

## Edge Cases

1. **Empty List:** Return NULL
2. **Single Node:** Return the node itself (already reversed)
3. **Two Nodes:** Simple swap of pointers

```
Empty:     NULL --> NULL
Single:    [1] --> NULL  (no change)
Two:       [1] --> [2] --> NULL  becomes  [2] --> [1] --> NULL
```

---

## Comparison

| Aspect | Iterative | Recursive |
|--------|-----------|-----------|
| Time Complexity | O(n) | O(n) |
| Space Complexity | O(1) | O(n) |
| Easy to Understand | Yes | Moderate |
| Stack Overflow Risk | No | Yes (for large lists) |
| Interview Preference | Often preferred | Good to know |

---

## Key Takeaways

1. **Three-pointer technique** is fundamental for linked list manipulation
2. **Save before modifying** - always save the next reference before changing pointers
3. **Recursive solution** elegantly expresses the reversal but uses extra space
4. **Practice both** - interviewers may ask for either or both approaches
