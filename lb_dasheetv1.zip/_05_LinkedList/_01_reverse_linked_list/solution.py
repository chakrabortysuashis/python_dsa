"""
Reverse a Linked List
=====================

Problem: Given the head of a singly linked list, reverse the list and return
         the reversed list's head.

Example:
    Input:  1 -> 2 -> 3 -> 4 -> 5 -> NULL
    Output: 5 -> 4 -> 3 -> 2 -> 1 -> NULL
"""


class ListNode:
    """Definition for singly-linked list node."""
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

    def __repr__(self):
        return f"ListNode({self.val})"


# =============================================================================
# APPROACH 1: ITERATIVE (THREE POINTERS)
# =============================================================================

def reverse_iterative(head: ListNode) -> ListNode:
    """
    Reverse linked list using iterative approach with three pointers.

    Algorithm:
    1. Use three pointers: prev, curr, next_node
    2. For each node, reverse its pointer to point to previous node
    3. Move all pointers one step forward
    4. When curr becomes NULL, prev is the new head

    Visual:
    Before: NULL    [1] -> [2] -> [3] -> NULL
             ^       ^
            prev   curr

    After:  NULL <- [1]    [2] -> [3] -> NULL
             ^       ^       ^
           prev's  curr    next_node
           target  (reversed)

    Time Complexity: O(n) - traverse list once
    Space Complexity: O(1) - only use three pointers
    """
    # Initialize pointers
    # prev starts as NULL because first node should point to NULL after reversal
    prev = None
    curr = head

    # Process each node until we reach the end
    while curr:
        # Step 1: Save the next node before we change curr.next
        # This is crucial! Without this, we lose access to the rest of the list
        next_node = curr.next

        # Step 2: Reverse the pointer
        # Instead of pointing to next, curr now points to prev
        curr.next = prev

        # Step 3: Move prev forward
        # prev becomes current node (which we just processed)
        prev = curr

        # Step 4: Move curr forward
        # curr moves to the saved next_node
        curr = next_node

        # Visual state after each iteration:
        # Iteration 1: NULL <- [1]    [2] -> [3] -> NULL
        #                       ^       ^
        #                     prev    curr
        # Iteration 2: NULL <- [1] <- [2]    [3] -> NULL
        #                              ^       ^
        #                            prev    curr
        # And so on...

    # When loop ends, curr is NULL and prev is at the last node
    # prev is now the new head of the reversed list
    return prev


# =============================================================================
# APPROACH 2: RECURSIVE
# =============================================================================

def reverse_recursive(head: ListNode) -> ListNode:
    """
    Reverse linked list using recursion.

    Algorithm:
    1. Base case: If head is NULL or single node, return head
    2. Recursively reverse the rest of the list
    3. Make the next node point back to current node
    4. Set current node's next to NULL

    Recursion Tree for [1] -> [2] -> [3]:
    reverse(1)
        |
        +-- reverse(2)
                |
                +-- reverse(3)
                        |
                        +-- return 3 (base case: 3.next is NULL)
                |
                3.next = 2, 2.next = NULL
                return 3
        |
        2.next = 1, 1.next = NULL
        return 3
    |
    return 3

    Time Complexity: O(n) - visit each node once
    Space Complexity: O(n) - recursion call stack
    """
    # Base Case 1: Empty list
    # Base Case 2: Single node (nothing to reverse)
    if head is None or head.next is None:
        return head

    # Recursive case:
    # First, reverse everything after head
    # new_head will be the last node (which becomes the first after reversal)
    new_head = reverse_recursive(head.next)

    # Now, head.next is the node that was after head
    # We need to make it point back to head

    # Example: If we're at node 2, and [3] is already reversed to point to nothing
    # head = 2, head.next = 3
    # head.next.next = head means: 3.next = 2
    head.next.next = head

    # Break the forward pointer to avoid cycle
    # 2.next = NULL (instead of 3)
    head.next = None

    # Return the new head (which was passed up from base case)
    return new_head


# =============================================================================
# APPROACH 3: RECURSIVE (TAIL RECURSION STYLE)
# =============================================================================

def reverse_recursive_tail(head: ListNode, prev: ListNode = None) -> ListNode:
    """
    Reverse linked list using tail recursion.

    This is similar to iterative but expressed recursively.
    Some languages can optimize tail recursion to avoid stack overflow.

    Time Complexity: O(n)
    Space Complexity: O(n) in Python (no tail call optimization)
                      O(1) in languages with TCO
    """
    # Base case: reached the end
    if head is None:
        return prev

    # Save next node
    next_node = head.next

    # Reverse pointer
    head.next = prev

    # Recursive call with updated pointers
    # This is tail recursive because the recursive call is the last operation
    return reverse_recursive_tail(next_node, head)


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def create_linked_list(values: list) -> ListNode:
    """Create a linked list from a list of values."""
    if not values:
        return None

    head = ListNode(values[0])
    current = head

    for val in values[1:]:
        current.next = ListNode(val)
        current = current.next

    return head


def linked_list_to_list(head: ListNode) -> list:
    """Convert linked list to a Python list for easy viewing."""
    result = []
    current = head

    while current:
        result.append(current.val)
        current = current.next

    return result


def print_linked_list(head: ListNode) -> str:
    """Print linked list in readable format."""
    values = linked_list_to_list(head)
    return " -> ".join(map(str, values)) + " -> NULL"


# =============================================================================
# TEST CASES
# =============================================================================

def test_reverse():
    """Test all reversal approaches."""
    print("=" * 60)
    print("REVERSE LINKED LIST - TEST CASES")
    print("=" * 60)

    # Test Case 1: Normal list
    print("\n--- Test Case 1: Normal List [1, 2, 3, 4, 5] ---")
    values = [1, 2, 3, 4, 5]

    # Test iterative
    head1 = create_linked_list(values)
    print(f"Original:  {print_linked_list(head1)}")
    reversed1 = reverse_iterative(head1)
    print(f"Iterative: {print_linked_list(reversed1)}")

    # Test recursive
    head2 = create_linked_list(values)
    reversed2 = reverse_recursive(head2)
    print(f"Recursive: {print_linked_list(reversed2)}")

    # Test tail recursive
    head3 = create_linked_list(values)
    reversed3 = reverse_recursive_tail(head3)
    print(f"Tail Rec:  {print_linked_list(reversed3)}")

    # Verify
    expected = [5, 4, 3, 2, 1]
    assert linked_list_to_list(reversed1) == expected
    assert linked_list_to_list(reversed2) == expected
    assert linked_list_to_list(reversed3) == expected
    print("All assertions passed!")

    # Test Case 2: Two nodes
    print("\n--- Test Case 2: Two Nodes [1, 2] ---")
    values = [1, 2]
    head = create_linked_list(values)
    print(f"Original: {print_linked_list(head)}")
    reversed_head = reverse_iterative(head)
    print(f"Reversed: {print_linked_list(reversed_head)}")
    assert linked_list_to_list(reversed_head) == [2, 1]
    print("Assertion passed!")

    # Test Case 3: Single node
    print("\n--- Test Case 3: Single Node [1] ---")
    values = [1]
    head = create_linked_list(values)
    print(f"Original: {print_linked_list(head)}")
    reversed_head = reverse_iterative(head)
    print(f"Reversed: {print_linked_list(reversed_head)}")
    assert linked_list_to_list(reversed_head) == [1]
    print("Assertion passed!")

    # Test Case 4: Empty list
    print("\n--- Test Case 4: Empty List ---")
    head = None
    reversed_head = reverse_iterative(head)
    print(f"Original: NULL")
    print(f"Reversed: NULL")
    assert reversed_head is None
    print("Assertion passed!")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)


def demonstrate_step_by_step():
    """Show step-by-step execution of iterative reversal."""
    print("\n" + "=" * 60)
    print("STEP-BY-STEP DEMONSTRATION (ITERATIVE)")
    print("=" * 60)

    # Create list: 1 -> 2 -> 3 -> NULL
    head = create_linked_list([1, 2, 3])
    print(f"\nOriginal list: {print_linked_list(head)}\n")

    prev = None
    curr = head
    step = 0

    print("Initial state:")
    print(f"  prev = NULL")
    print(f"  curr = {curr.val if curr else 'NULL'}")
    print("-" * 40)

    while curr:
        step += 1
        print(f"\nStep {step}: Processing node {curr.val}")

        # Step 1: Save next
        next_node = curr.next
        print(f"  1. Save next_node = {next_node.val if next_node else 'NULL'}")

        # Step 2: Reverse
        curr.next = prev
        print(f"  2. Reverse: {curr.val}.next = {prev.val if prev else 'NULL'}")

        # Step 3: Move prev
        prev = curr
        print(f"  3. Move prev to {prev.val}")

        # Step 4: Move curr
        curr = next_node
        print(f"  4. Move curr to {curr.val if curr else 'NULL'}")

        print("-" * 40)

    print(f"\nFinal: prev = {prev.val} (new head)")
    print(f"Reversed list: {print_linked_list(prev)}")


if __name__ == "__main__":
    test_reverse()
    demonstrate_step_by_step()
