"""
Problem: Find Shortest Unique Prefix for Every Word
====================================================

Given an array of words, find the shortest unique prefix for each word
such that no two prefixes are the same.

Example:
    Input: ["zebra", "dog", "duck", "dove"]
    Output: ["z", "dog", "du", "dov"]

Approach:
    1. Build a Trie with prefix counts (how many words pass through each node)
    2. For each word, traverse until prefix_count becomes 1

Time Complexity: O(n * m) where n = number of words, m = average word length
Space Complexity: O(ALPHABET_SIZE * total_characters)
"""

from typing import List, Dict, Tuple


class TrieNode:
    """
    Trie node with prefix count.

    Attributes:
        children: Dictionary mapping characters to child nodes
        prefix_count: Number of words passing through this node
        is_end: Whether this node marks end of a word
    """

    def __init__(self):
        self.children: Dict[str, 'TrieNode'] = {}
        self.prefix_count: int = 0  # KEY: counts words passing through
        self.is_end: bool = False


class Trie:
    """Trie with prefix counting for finding unique prefixes."""

    def __init__(self):
        self.root = TrieNode()

    def insert(self, word: str) -> None:
        """
        Insert word and increment prefix counts along the path.

        Visualization for insert("dog"):

        Before:           After:
        root              root
                           |
                          d (count=1)
                           |
                          o (count=1)
                           |
                          g* (count=1)
        """
        node = self.root

        for char in word:
            if char not in node.children:
                node.children[char] = TrieNode()

            node = node.children[char]
            node.prefix_count += 1  # Increment count for every word passing through

        node.is_end = True

    def find_shortest_unique_prefix(self, word: str) -> str:
        """
        Find the shortest prefix that uniquely identifies this word.

        Algorithm:
        - Traverse the word character by character
        - Stop when prefix_count becomes 1 (unique path)
        - Return the prefix up to that point

        Dry Run for "duck" in trie with ["dog", "duck", "dove"]:

            d (count=3) -> not unique, continue
            u (count=1) -> UNIQUE! Return "du"
        """
        node = self.root
        prefix = []

        for char in word:
            node = node.children[char]
            prefix.append(char)

            # If only one word passes through this node, prefix is unique
            if node.prefix_count == 1:
                return ''.join(prefix)

        # If we reach end of word without finding unique prefix,
        # return the entire word (word itself is the unique prefix)
        return word

    def get_prefix_count_path(self, word: str) -> List[Tuple[str, int]]:
        """Get the prefix count at each character (for visualization)."""
        node = self.root
        path = []

        for char in word:
            node = node.children[char]
            path.append((char, node.prefix_count))

        return path


def find_shortest_unique_prefixes(words: List[str]) -> List[str]:
    """
    Find shortest unique prefix for each word.

    Args:
        words: List of words

    Returns:
        List of shortest unique prefixes

    Example:
        >>> find_shortest_unique_prefixes(["zebra", "dog", "duck", "dove"])
        ['z', 'dog', 'du', 'dov']
    """
    if not words:
        return []

    # Step 1: Build trie with prefix counts
    trie = Trie()
    for word in words:
        trie.insert(word)

    # Step 2: Find unique prefix for each word
    result = []
    for word in words:
        prefix = trie.find_shortest_unique_prefix(word)
        result.append(prefix)

    return result


def find_shortest_unique_prefixes_with_trace(words: List[str]) -> List[Tuple[str, str, List[Tuple[str, int]]]]:
    """
    Find shortest unique prefixes with detailed trace for visualization.

    Returns:
        List of tuples: (word, unique_prefix, prefix_count_path)
    """
    if not words:
        return []

    trie = Trie()
    for word in words:
        trie.insert(word)

    result = []
    for word in words:
        prefix = trie.find_shortest_unique_prefix(word)
        path = trie.get_prefix_count_path(word)
        result.append((word, prefix, path))

    return result


# ============================================================
# Alternative: Concise Solution
# ============================================================

def shortest_unique_prefix_concise(words: List[str]) -> List[str]:
    """
    Concise implementation using dictionary-based trie.
    """
    # Build trie with counts
    trie = {}

    for word in words:
        node = trie
        for char in word:
            if char not in node:
                node[char] = {'count': 0}
            node = node[char]
            node['count'] += 1
        node['end'] = True

    # Find prefixes
    result = []
    for word in words:
        node = trie
        prefix = ''
        for char in word:
            node = node[char]
            prefix += char
            if node['count'] == 1:
                break
        result.append(prefix)

    return result


# ============================================================
# Visualization Helper
# ============================================================

def visualize_trie_with_counts(words: List[str]) -> str:
    """
    Create a text visualization of trie with prefix counts.
    """
    trie = Trie()
    for word in words:
        trie.insert(word)

    lines = [f"Words: {words}", "", "Trie with prefix counts:", "root"]

    def dfs(node: TrieNode, prefix: str, indent: str):
        children = sorted(node.children.items())
        for i, (char, child) in enumerate(children):
            is_last = i == len(children) - 1
            connector = "\\-- " if is_last else "|-- "
            end_marker = "*" if child.is_end else ""
            lines.append(f"{indent}{connector}{char}{end_marker} (count={child.prefix_count})")

            next_indent = indent + ("    " if is_last else "|   ")
            dfs(child, prefix + char, next_indent)

    dfs(trie.root, "", "")
    return '\n'.join(lines)


# ============================================================
# Test Cases
# ============================================================

def test_shortest_unique_prefix():
    """Comprehensive tests for shortest unique prefix."""

    print("=" * 60)
    print("TEST: Shortest Unique Prefix")
    print("=" * 60)

    # Test 1: Basic example
    print("\nTest 1: Basic Example")
    words1 = ["zebra", "dog", "duck", "dove"]
    result1 = find_shortest_unique_prefixes(words1)
    print(f"  Input:  {words1}")
    print(f"  Output: {result1}")
    print(f"  Expected: ['z', 'dog', 'du', 'dov']")
    assert result1 == ['z', 'dog', 'du', 'dov'], f"Failed: {result1}"
    print("  PASSED")

    # Test 2: Words sharing longer prefixes
    print("\nTest 2: Words sharing longer prefixes")
    words2 = ["apple", "app", "application"]
    result2 = find_shortest_unique_prefixes(words2)
    print(f"  Input:  {words2}")
    print(f"  Output: {result2}")
    # "apple" needs "apple" (full), "app" needs "app" (full, it's prefix of others),
    # "application" needs "appli" (first unique char)
    print("  PASSED")

    # Test 3: All unique first letters
    print("\nTest 3: All unique first letters")
    words3 = ["apple", "banana", "cherry"]
    result3 = find_shortest_unique_prefixes(words3)
    print(f"  Input:  {words3}")
    print(f"  Output: {result3}")
    assert result3 == ['a', 'b', 'c'], f"Failed: {result3}"
    print("  PASSED")

    # Test 4: Single word
    print("\nTest 4: Single word")
    words4 = ["hello"]
    result4 = find_shortest_unique_prefixes(words4)
    print(f"  Input:  {words4}")
    print(f"  Output: {result4}")
    assert result4 == ['h'], f"Failed: {result4}"
    print("  PASSED")

    # Test 5: Similar words
    print("\nTest 5: Similar words")
    words5 = ["cat", "car", "card"]
    result5 = find_shortest_unique_prefixes(words5)
    print(f"  Input:  {words5}")
    print(f"  Output: {result5}")
    print("  PASSED")

    # Test 6: Empty list
    print("\nTest 6: Empty list")
    words6 = []
    result6 = find_shortest_unique_prefixes(words6)
    print(f"  Input:  {words6}")
    print(f"  Output: {result6}")
    assert result6 == [], f"Failed: {result6}"
    print("  PASSED")


def demonstrate_with_visualization():
    """
    Detailed demonstration with step-by-step visualization.
    """
    print("\n" + "=" * 60)
    print("DEMONSTRATION: Step-by-step visualization")
    print("=" * 60)

    words = ["dog", "duck", "dove"]

    print(f"\nWords: {words}")
    print("\n--- Building Trie ---")

    # Show trie structure
    print(visualize_trie_with_counts(words))

    print("\n--- Finding Unique Prefixes ---")

    results = find_shortest_unique_prefixes_with_trace(words)

    for word, prefix, path in results:
        print(f"\nWord: '{word}'")
        print(f"  Traversal:")
        for i, (char, count) in enumerate(path):
            unique_marker = " <- UNIQUE!" if count == 1 else ""
            print(f"    Step {i+1}: '{char}' -> prefix_count = {count}{unique_marker}")
            if count == 1:
                break
        print(f"  Result: Unique prefix = '{prefix}'")


def demonstrate_edge_cases():
    """
    Demonstrate handling of edge cases.
    """
    print("\n" + "=" * 60)
    print("EDGE CASES")
    print("=" * 60)

    # Case 1: Word is prefix of another
    print("\nCase 1: Word is prefix of another")
    words = ["app", "apple"]
    print(f"  Words: {words}")
    print(visualize_trie_with_counts(words))
    result = find_shortest_unique_prefixes(words)
    print(f"  Unique prefixes: {result}")
    print("  Note: 'app' returns 'app' because it's the full word")

    # Case 2: Same first letter, different second
    print("\nCase 2: Same first letter, different second")
    words = ["ant", "art"]
    print(f"  Words: {words}")
    result = find_shortest_unique_prefixes(words)
    print(f"  Unique prefixes: {result}")

    # Case 3: Completely different words
    print("\nCase 3: Completely different words")
    words = ["xyz", "abc", "mno"]
    print(f"  Words: {words}")
    result = find_shortest_unique_prefixes(words)
    print(f"  Unique prefixes: {result}")


if __name__ == "__main__":
    test_shortest_unique_prefix()
    demonstrate_with_visualization()
    demonstrate_edge_cases()
