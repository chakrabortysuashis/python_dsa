# Find Shortest Unique Prefix for Every Word

## Problem Statement

Given an array of words, find the shortest unique prefix for each word such that no two prefixes are the same. If a word itself is a prefix of another word, return the entire word.

**Example 1:**
```
Input: words = ["zebra", "dog", "duck", "dove"]
Output: ["z", "dog", "du", "dov"]

Explanation:
- "zebra" -> "z" (unique, no other word starts with 'z')
- "dog" -> "dog" (can't use "d" or "do" as "duck"/"dove" also start with them)
- "duck" -> "du" (unique prefix)
- "dove" -> "dov" (unique prefix, can't use "do" as "dog" also has it)
```

**Example 2:**
```
Input: words = ["apple", "app", "application"]
Output: ["apple", "app", "appli"]

Explanation:
- "apple" -> "apple" (need full word to distinguish from "application")
- "app" -> "app" (it's a prefix of others, return full word)
- "application" -> "appli" (first unique character)
```

---

## Why Trie is Useful Here

**Naive Approach:**
- For each word, compare with all other words to find shortest unique prefix
- Time: O(n^2 * m) where n = words, m = avg length

**Trie Approach:**
- Build trie with prefix counts
- Each node knows how many words pass through it
- Prefix is unique when count becomes 1
- Time: O(n * m)

**Key Insight:** A prefix is unique when only ONE word passes through that node!

---

## Trie Construction with Prefix Count

### Build Trie for ["dog", "duck", "dove"]

**After all insertions:**
```
        root
         |
         d (prefix_count=3)  <-- 3 words have 'd' prefix
        /|\
       o u
       |  \
       g*  c    v   (prefix_count varies)
           |    |
           k*   e*

Node breakdown:
- 'd': count=3 (dog, duck, dove all pass through)
- 'o': count=1 (only "dog")
- 'g': count=1 (only "dog")
- 'u': count=2 (duck, dove) -- wait, that's wrong!

Let me fix this:

        root
         |
         d (count=3)
        /
       o-----u (count=1, only duck)
       |      \
       g*(count=1) c----> Wait, dove starts do-v-e
       only "dog"   |
                    k* (count=1)

Actually correct tree:

        root
         |
         d (count=3)
         |
        [o: count=2]----[u: count=1]
        /     \              \
      [g*]   [v: count=1]   [c: count=1]
     count=1     |               |
                [e*]           [k*]
               count=1        count=1

Hmm, let me redo more carefully:

Words: dog, duck, dove

d -> o -> g*     (dog)
d -> u -> c -> k*  (duck)
d -> o -> v -> e*  (dove)

        root
         |
         d (count=3, all words have 'd')
        / \
       o   u
    (cnt=2) (cnt=1)
      / \      \
     g*  v      c
  (cnt=1)(cnt=1)(cnt=1)
           |      |
          e*     k*
```

**Correct Trie with counts:**
```
              root
               |
           d (count=3)
          / \
         /   \
      o(2)   u(1) ---> Only duck passes through 'u'
      / \       \      So "du" is unique for duck
   g*(1) v(1)   c(1)
          |       |
        e*(1)   k*(1)

Prefix counts:
- d: 3 (dog, duck, dove)
- do: 2 (dog, dove)
- dog: 1 -> unique prefix for "dog" is "dog"
- dov: 1 -> unique prefix for "dove" is "dov"
- du: 1 -> unique prefix for "duck" is "du"
```

---

## Step-by-Step Algorithm

### Algorithm:
1. **Build Trie with prefix counts**: Count how many words pass through each node
2. **Find shortest unique prefix**: Traverse until prefix_count becomes 1

### Character-by-Character Dry Run

**Words:** ["zebra", "dog", "duck", "dove"]

**Step 1: Build Trie**

Insert "zebra":
```
root -> z(1) -> e(1) -> b(1) -> r(1) -> a*(1)
```

Insert "dog":
```
root -> z(1) -> e(1) -> b(1) -> r(1) -> a*(1)
     -> d(1) -> o(1) -> g*(1)
```

Insert "duck":
```
root -> z(1) -> e(1) -> b(1) -> r(1) -> a*(1)
     -> d(2) -> o(1) -> g*(1)
             -> u(1) -> c(1) -> k*(1)
```

Insert "dove":
```
root -> z(1) -> e(1) -> b(1) -> r(1) -> a*(1)
     -> d(3) -> o(2) -> g*(1)
             |      -> v(1) -> e*(1)
             -> u(1) -> c(1) -> k*(1)
```

**Step 2: Find Unique Prefixes**

| Word | Path | Count at each node | Unique Prefix |
|------|------|-------------------|---------------|
| zebra | z(1)->e(1)->... | 1 at 'z' | "z" |
| dog | d(3)->o(2)->g(1) | 1 at 'g' | "dog" |
| duck | d(3)->u(1)->... | 1 at 'u' | "du" |
| dove | d(3)->o(2)->v(1) | 1 at 'v' | "dov" |

**Result:** ["z", "dog", "du", "dov"]

---

## Visual Trace: Finding Unique Prefix for "duck"

```
Start at root, traverse "duck":

     d        count=3, not unique
     |
     u        count=1, UNIQUE! Stop here
     |
     c        (don't need to go further)
     |
     k*

Unique prefix for "duck" = "du"
```

---

## Edge Cases

### Case 1: Word is prefix of another
```
Words: ["app", "apple"]

Trie:
root -> a(2) -> p(2) -> p*(2) -> l(1) -> e*(1)

Finding prefix for "app":
- a: count=2
- ap: count=2
- app: count=2 (marked as end, but "apple" also passes through)

Since count never becomes 1 before end of word,
return the entire word "app"
```

### Case 2: All unique first letters
```
Words: ["apple", "banana", "cherry"]

Trie:
root -> a(1) -> ...
     -> b(1) -> ...
     -> c(1) -> ...

Result: ["a", "b", "c"]
```

### Case 3: Similar words
```
Words: ["cat", "car", "card"]

Trie:
root -> c(3) -> a(3) -> t*(1)
                     -> r*(2) -> d*(1)

Result:
- "cat" -> "cat" (count=1 at 't')
- "car" -> "car" (count=2 at 'r', need full word as end marker)
- "card" -> "card" (count=1 at 'd')
```

---

## Time and Space Complexity

### Time Complexity
- **Build Trie:** O(n * m)
  - n = number of words
  - m = average word length
- **Find Prefixes:** O(n * m)
- **Total:** O(n * m)

### Space Complexity
- **Trie Storage:** O(ALPHABET_SIZE * total_characters)
- In worst case (no shared prefixes): O(26 * n * m)
- In practice: Much less due to shared prefixes

---

## Common Mistakes

1. **Not handling word that is prefix of another**
   - "app" in ["app", "apple"] should return "app" (full word)

2. **Off-by-one in prefix length**
   - Count should include current character

3. **Not initializing prefix count during insert**
   - Must increment count at EVERY node along the path

4. **Confusing prefix_count with word_count**
   - prefix_count = words passing through (including this node)
   - word_count = words ending at this node

---

## Alternative: Using Frequency Array

Instead of prefix_count in each node, you can:
1. Insert all words
2. For each word, traverse and count children at each level
3. Stop when only one path remains

But prefix_count approach is cleaner and more efficient.
