"""
Trie (Prefix Tree) - Complete Implementation
=============================================

A Trie is a tree-like data structure for efficient string storage and retrieval.
Each node represents a character, and paths from root to nodes form strings.

Key Properties:
- Root node is empty (represents empty string prefix)
- Each path from root represents a string prefix
- End-of-word markers indicate complete words
- Common prefixes share the same path (memory efficient)

Time Complexity: O(m) for all operations where m = word length
Space Complexity: O(ALPHABET_SIZE * m * n) where n = number of words
"""

from typing import List, Optional, Dict, Tuple
from collections import defaultdict


class TrieNode:
    """
    A node in the Trie structure.

    Attributes:
        children: Dictionary mapping characters to child nodes
        is_end_of_word: Boolean indicating if this node marks end of a word
        word_count: Number of words ending at this node
        prefix_count: Number of words passing through this node
    """

    def __init__(self):
        self.children: Dict[str, 'TrieNode'] = {}
        self.is_end_of_word: bool = False
        self.word_count: int = 0      # For counting duplicate words
        self.prefix_count: int = 0    # For counting words with this prefix

    def __repr__(self):
        return f"TrieNode(children={list(self.children.keys())}, is_end={self.is_end_of_word})"


class Trie:
    """
    Trie (Prefix Tree) implementation with full operations.

    Example Usage:
        trie = Trie()
        trie.insert("apple")
        trie.insert("app")
        print(trie.search("apple"))      # True
        print(trie.search("app"))        # True
        print(trie.search("ap"))         # False
        print(trie.starts_with("app"))   # True
        print(trie.get_all_words())      # ['app', 'apple']
    """

    def __init__(self):
        """Initialize the Trie with an empty root node."""
        self.root = TrieNode()

    # ==================== Core Operations ====================

    def insert(self, word: str) -> None:
        """
        Insert a word into the Trie.

        Time Complexity: O(m) where m = len(word)
        Space Complexity: O(m) in worst case

        Visualization for inserting "cat":

        Step 1: Start at root
            root
             |
            (empty)

        Step 2: Insert 'c'
            root
             |
             c  (prefix_count=1)

        Step 3: Insert 'a'
            root
             |
             c
             |
             a  (prefix_count=1)

        Step 4: Insert 't' and mark as end
            root
             |
             c
             |
             a
             |
             t* (is_end_of_word=True, word_count=1)
        """
        node = self.root

        for char in word:
            # Create new node if character doesn't exist
            if char not in node.children:
                node.children[char] = TrieNode()

            # Move to the child node
            node = node.children[char]
            node.prefix_count += 1  # Increment prefix count

        # Mark the end of the word
        node.is_end_of_word = True
        node.word_count += 1

    def search(self, word: str) -> bool:
        """
        Search for a complete word in the Trie.

        Time Complexity: O(m) where m = len(word)

        Returns True only if:
        1. All characters exist in path from root
        2. Final node is marked as end of word

        Visualization for searching "cat" in Trie with ["cat", "car"]:

            root
             |
             c ----> Found 'c', move down
             |
             a ----> Found 'a', move down
            / \
           t*  r* -> Found 't', is_end_of_word=True

        Return True (word exists)
        """
        node = self._find_node(word)
        return node is not None and node.is_end_of_word

    def starts_with(self, prefix: str) -> bool:
        """
        Check if any word in the Trie starts with the given prefix.

        Time Complexity: O(m) where m = len(prefix)

        Unlike search(), doesn't require is_end_of_word to be True.

        Visualization for prefix "ca" in Trie with ["cat", "car"]:

            root
             |
             c ----> Found 'c'
             |
             a ----> Found 'a' - PREFIX EXISTS!
            / \
           t*  r*
        """
        return self._find_node(prefix) is not None

    def delete(self, word: str) -> bool:
        """
        Delete a word from the Trie.

        Time Complexity: O(m) where m = len(word)

        Algorithm:
        1. Find the word (return False if not found)
        2. Unmark is_end_of_word
        3. Remove nodes that are no longer needed

        Visualization - Delete "cat" from ["cat", "car"]:

        Before:              After:
            root               root
             |                  |
             c                  c
             |                  |
             a                  a
            / \                  \
           t*  r*     ->          r*

        Node 't' is removed (no children, no longer end of word)
        """
        if not self.search(word):
            return False

        self._delete_helper(self.root, word, 0)
        return True

    def _delete_helper(self, node: TrieNode, word: str, depth: int) -> bool:
        """
        Recursive helper for deletion.
        Returns True if current node should be deleted.
        """
        if depth == len(word):
            # Reached end of word
            node.is_end_of_word = False
            node.word_count -= 1
            # Delete node if it has no children
            return len(node.children) == 0

        char = word[depth]
        child = node.children[char]
        child.prefix_count -= 1

        should_delete_child = self._delete_helper(child, word, depth + 1)

        if should_delete_child:
            del node.children[char]
            # Delete current node if no children and not end of another word
            return len(node.children) == 0 and not node.is_end_of_word

        return False

    # ==================== Helper Methods ====================

    def _find_node(self, prefix: str) -> Optional[TrieNode]:
        """
        Find the node corresponding to the end of prefix.
        Returns None if prefix doesn't exist.
        """
        node = self.root
        for char in prefix:
            if char not in node.children:
                return None
            node = node.children[char]
        return node

    # ==================== Advanced Operations ====================

    def get_all_words(self) -> List[str]:
        """
        Get all words stored in the Trie.

        Time Complexity: O(n) where n = total characters in all words
        """
        words = []
        self._collect_words(self.root, "", words)
        return words

    def _collect_words(self, node: TrieNode, prefix: str, words: List[str]) -> None:
        """DFS to collect all words."""
        if node.is_end_of_word:
            words.append(prefix)

        for char, child in sorted(node.children.items()):
            self._collect_words(child, prefix + char, words)

    def get_words_with_prefix(self, prefix: str) -> List[str]:
        """
        Get all words that start with the given prefix.

        Time Complexity: O(p + n) where p = prefix length, n = matching chars

        Example:
            Trie: ["apple", "app", "application", "bat"]
            get_words_with_prefix("app") -> ["app", "apple", "application"]
        """
        node = self._find_node(prefix)
        if not node:
            return []

        words = []
        self._collect_words(node, prefix, words)
        return words

    def count_words_with_prefix(self, prefix: str) -> int:
        """
        Count how many words start with the given prefix.

        Time Complexity: O(m) where m = prefix length
        """
        node = self._find_node(prefix)
        return node.prefix_count if node else 0

    def longest_common_prefix(self) -> str:
        """
        Find the longest common prefix of all words in the Trie.

        Time Complexity: O(m) where m = length of LCP

        Example:
            Words: ["flower", "flow", "flight"]
            LCP: "fl"
        """
        prefix = []
        node = self.root

        # Continue while there's exactly one child and we're not at end of word
        while node and len(node.children) == 1 and not node.is_end_of_word:
            char = list(node.children.keys())[0]
            prefix.append(char)
            node = node.children[char]

        return ''.join(prefix)

    def search_with_wildcard(self, pattern: str, wildcard: str = '.') -> List[str]:
        """
        Search for words matching pattern with wildcard support.

        Time Complexity: O(26^w * m) where w = wildcards, m = pattern length

        Example:
            Trie: ["cat", "car", "bat"]
            search_with_wildcard("c.t") -> ["cat"]
            search_with_wildcard("..t") -> ["bat", "cat"]
        """
        results = []

        def dfs(node: TrieNode, index: int, path: List[str]):
            if index == len(pattern):
                if node.is_end_of_word:
                    results.append(''.join(path))
                return

            char = pattern[index]

            if char == wildcard:
                # Try all children
                for c, child in node.children.items():
                    path.append(c)
                    dfs(child, index + 1, path)
                    path.pop()
            else:
                if char in node.children:
                    path.append(char)
                    dfs(node.children[char], index + 1, path)
                    path.pop()

        dfs(self.root, 0, [])
        return results

    def autocomplete(self, prefix: str, limit: int = 10) -> List[str]:
        """
        Get autocomplete suggestions for a prefix.

        Time Complexity: O(p + k) where p = prefix length, k = suggestions
        """
        return self.get_words_with_prefix(prefix)[:limit]

    # ==================== Utility Methods ====================

    def is_empty(self) -> bool:
        """Check if the Trie is empty."""
        return len(self.root.children) == 0

    def size(self) -> int:
        """Return the number of words in the Trie."""
        return self._count_words(self.root)

    def _count_words(self, node: TrieNode) -> int:
        """Count total words in subtree."""
        count = node.word_count
        for child in node.children.values():
            count += self._count_words(child)
        return count

    def visualize(self) -> str:
        """
        Create a text visualization of the Trie.

        Example output:
        root
        ├── a
        │   └── p
        │       └── p* (app)
        │           └── l
        │               └── e* (apple)
        └── b
            └── a
                └── t* (bat)
        """
        lines = ["root"]
        self._visualize_helper(self.root, "", lines, "", True)
        return '\n'.join(lines)

    def _visualize_helper(self, node: TrieNode, prefix: str, lines: List[str],
                          word_so_far: str, is_last: bool) -> None:
        """Recursive helper for visualization."""
        children = sorted(node.children.items())

        for i, (char, child) in enumerate(children):
            is_last_child = (i == len(children) - 1)
            connector = "└── " if is_last_child else "├── "
            extension = "    " if is_last_child else "│   "

            word = word_so_far + char
            end_marker = f"* ({word})" if child.is_end_of_word else ""
            lines.append(f"{prefix}{connector}{char}{end_marker}")

            self._visualize_helper(child, prefix + extension, lines, word, is_last_child)


class TrieWithArray:
    """
    Trie implementation using fixed-size array for children.
    More memory efficient for lowercase English letters only.

    Uses array index: char_index = ord(char) - ord('a')
    """

    class Node:
        def __init__(self):
            self.children = [None] * 26  # Fixed size for a-z
            self.is_end = False

        def _index(self, char: str) -> int:
            return ord(char) - ord('a')

        def get(self, char: str) -> Optional['TrieWithArray.Node']:
            return self.children[self._index(char)]

        def set(self, char: str, node: 'TrieWithArray.Node') -> None:
            self.children[self._index(char)] = node

    def __init__(self):
        self.root = self.Node()

    def insert(self, word: str) -> None:
        node = self.root
        for char in word.lower():
            if node.get(char) is None:
                node.set(char, self.Node())
            node = node.get(char)
        node.is_end = True

    def search(self, word: str) -> bool:
        node = self.root
        for char in word.lower():
            node = node.get(char)
            if node is None:
                return False
        return node.is_end


# ==================== Demo and Tests ====================

def demonstrate_trie():
    """Comprehensive demonstration of Trie operations."""

    print("=" * 60)
    print("TRIE (PREFIX TREE) DEMONSTRATION")
    print("=" * 60)

    trie = Trie()

    # Insert words
    print("\n1. INSERTING WORDS")
    print("-" * 40)
    words = ["apple", "app", "application", "apt", "bat", "ball", "cat", "car", "card"]

    for word in words:
        trie.insert(word)
        print(f"   Inserted: '{word}'")

    # Visualize
    print("\n2. TRIE VISUALIZATION")
    print("-" * 40)
    print(trie.visualize())

    # Search
    print("\n3. SEARCH OPERATIONS")
    print("-" * 40)
    test_words = ["apple", "app", "ap", "application", "bat", "bath", "car", "care"]

    for word in test_words:
        found = trie.search(word)
        status = "FOUND" if found else "NOT FOUND"
        print(f"   search('{word}'): {status}")

    # Prefix search
    print("\n4. PREFIX SEARCH")
    print("-" * 40)
    prefixes = ["app", "ba", "ca", "z"]

    for prefix in prefixes:
        exists = trie.starts_with(prefix)
        count = trie.count_words_with_prefix(prefix)
        words_list = trie.get_words_with_prefix(prefix)
        print(f"   prefix '{prefix}':")
        print(f"      exists: {exists}")
        print(f"      count: {count}")
        print(f"      words: {words_list}")

    # Wildcard search
    print("\n5. WILDCARD SEARCH")
    print("-" * 40)
    patterns = ["c.t", "b..l", "app.."]

    for pattern in patterns:
        matches = trie.search_with_wildcard(pattern)
        print(f"   pattern '{pattern}': {matches}")

    # Autocomplete
    print("\n6. AUTOCOMPLETE")
    print("-" * 40)
    for prefix in ["app", "ca", "b"]:
        suggestions = trie.autocomplete(prefix, limit=5)
        print(f"   '{prefix}' -> {suggestions}")

    # Delete
    print("\n7. DELETE OPERATION")
    print("-" * 40)
    delete_words = ["app", "cat"]

    for word in delete_words:
        print(f"   Before delete '{word}':")
        print(f"      search('{word}'): {trie.search(word)}")
        trie.delete(word)
        print(f"   After delete '{word}':")
        print(f"      search('{word}'): {trie.search(word)}")
        print()

    # Final state
    print("\n8. FINAL STATE")
    print("-" * 40)
    print(f"   Total words: {trie.size()}")
    print(f"   All words: {trie.get_all_words()}")
    print("\n   Visualization:")
    print(trie.visualize())

    # Longest common prefix
    print("\n9. LONGEST COMMON PREFIX")
    print("-" * 40)

    lcp_trie = Trie()
    lcp_words = ["flower", "flow", "flight"]
    for w in lcp_words:
        lcp_trie.insert(w)

    print(f"   Words: {lcp_words}")
    print(f"   LCP: '{lcp_trie.longest_common_prefix()}'")


def test_trie():
    """Unit tests for Trie implementation."""

    print("\n" + "=" * 60)
    print("RUNNING TESTS")
    print("=" * 60)

    trie = Trie()

    # Test 1: Empty trie
    assert trie.is_empty() == True
    assert trie.search("any") == False
    assert trie.starts_with("a") == False
    print("   Test 1 (Empty trie): PASSED")

    # Test 2: Insert and search
    trie.insert("hello")
    assert trie.search("hello") == True
    assert trie.search("hell") == False
    assert trie.search("helloo") == False
    print("   Test 2 (Insert/Search): PASSED")

    # Test 3: Prefix search
    assert trie.starts_with("hel") == True
    assert trie.starts_with("hello") == True
    assert trie.starts_with("hellox") == False
    print("   Test 3 (Prefix search): PASSED")

    # Test 4: Multiple words
    trie.insert("help")
    trie.insert("world")
    assert trie.search("help") == True
    assert trie.search("world") == True
    assert trie.size() == 3
    print("   Test 4 (Multiple words): PASSED")

    # Test 5: Get words with prefix
    words = trie.get_words_with_prefix("hel")
    assert "hello" in words
    assert "help" in words
    assert len(words) == 2
    print("   Test 5 (Words with prefix): PASSED")

    # Test 6: Delete
    assert trie.delete("help") == True
    assert trie.search("help") == False
    assert trie.search("hello") == True  # Other word still exists
    print("   Test 6 (Delete): PASSED")

    # Test 7: Wildcard search
    trie2 = Trie()
    trie2.insert("cat")
    trie2.insert("car")
    trie2.insert("bat")
    matches = trie2.search_with_wildcard("c.t")
    assert "cat" in matches
    assert len(matches) == 1
    print("   Test 7 (Wildcard search): PASSED")

    # Test 8: Duplicate insert
    trie3 = Trie()
    trie3.insert("test")
    trie3.insert("test")
    assert trie3.size() == 2  # word_count tracks duplicates
    print("   Test 8 (Duplicate insert): PASSED")

    print("\n   ALL TESTS PASSED!")


if __name__ == "__main__":
    demonstrate_trie()
    test_trie()
