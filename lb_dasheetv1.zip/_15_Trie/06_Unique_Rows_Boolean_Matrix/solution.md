# Print Unique Rows in a Given Boolean Matrix

## Problem Statement

Given a boolean matrix of 0s and 1s, find and print all unique rows. Rows are considered duplicates if they have the same sequence of values.

**Example:**
```
Input Matrix:
[1, 1, 0, 1]
[1, 0, 0, 1]
[1, 1, 0, 1]    <- Duplicate of row 0
[0, 1, 0, 0]
[1, 1, 0, 1]    <- Duplicate of row 0

Output (Unique Rows):
[1, 1, 0, 1]    <- Row 0
[1, 0, 0, 1]    <- Row 1
[0, 1, 0, 0]    <- Row 3
```

---

## Why Trie is Useful Here

### Approach Comparison

| Approach | Time | Space | Notes |
|----------|------|-------|-------|
| Nested Loops | O(R^2 * C) | O(1) | Compare each row with all others |
| HashSet with String | O(R * C) | O(R * C) | Convert row to string, use set |
| HashSet with Tuple | O(R * C) | O(R * C) | Use tuple as key |
| **Trie** | O(R * C) | O(R * C) | Insert row as path, detect duplicates |

Where R = rows, C = columns

**Trie Advantage:**
- Natural representation of binary sequences
- Each path = one row
- Duplicate detection is automatic (path already exists)
- Memory efficient for rows with common prefixes

---

## Trie Construction for Boolean Matrix

### Example Matrix:
```
Row 0: [1, 1, 0, 1]
Row 1: [1, 0, 0, 1]
Row 2: [1, 1, 0, 1]  <- Duplicate
```

### Building the Trie:

**Insert Row 0: [1, 1, 0, 1]**
```
root
 |
 1
 |
 1
 |
 0
 |
 1* (is_end=True, row_index=0)
```

**Insert Row 1: [1, 0, 0, 1]**
```
       root
        |
        1
       / \
      1   0     <- Branch at second element
      |   |
      0   0
      |   |
      1*  1*
    (row0) (row1)
```

**Try to Insert Row 2: [1, 1, 0, 1]**
```
Path 1 -> 1 -> 0 -> 1 already exists!
Node at end already has is_end=True
=> DUPLICATE DETECTED! Skip this row.
```

---

## Step-by-Step Algorithm

### Algorithm:
```
1. Create empty Trie with children for '0' and '1'
2. For each row in matrix:
   a. Try to insert row as path in Trie
   b. If path already exists and ends at is_end=True: DUPLICATE
   c. Otherwise: Mark as unique, set is_end=True
3. Return all unique rows
```

### Character-by-Character Dry Run

**Matrix:**
```
Row 0: [1, 1, 0, 1]
Row 1: [1, 0, 0, 1]
Row 2: [1, 1, 0, 1]
Row 3: [0, 1, 0, 0]
```

**Process Row 0: [1, 1, 0, 1]**
```
Step 1: root.children['1'] = None, create node
        root -> 1

Step 2: node.children['1'] = None, create node
        root -> 1 -> 1

Step 3: node.children['0'] = None, create node
        root -> 1 -> 1 -> 0

Step 4: node.children['1'] = None, create node
        root -> 1 -> 1 -> 0 -> 1

Mark is_end = True, store row_index = 0
Result: UNIQUE (first occurrence)
```

**Process Row 1: [1, 0, 0, 1]**
```
Step 1: root.children['1'] exists, move to it
Step 2: node.children['0'] = None, create new branch!
        root -> 1 -> 1 -> 0 -> 1* (row 0)
                  \
                   0 (new branch for row 1)

Step 3: node.children['0'] = None, create
Step 4: node.children['1'] = None, create

Mark is_end = True, row_index = 1
Result: UNIQUE
```

**Process Row 2: [1, 1, 0, 1]**
```
Step 1: root.children['1'] exists
Step 2: node.children['1'] exists
Step 3: node.children['0'] exists
Step 4: node.children['1'] exists, AND is_end = True!

Path already exists as complete row!
Result: DUPLICATE (skip)
```

**Process Row 3: [0, 1, 0, 0]**
```
Step 1: root.children['0'] = None, create new branch!
        (starts with 0, completely different from others)

Result: UNIQUE
```

**Final Trie:**
```
           root
          /    \
         0      1
         |     / \
         1    0   1
         |    |   |
         0    0   0
         |    |   |
         0*   1*  1*
      (row3) (row1) (row0)
```

**Unique Rows:** [0, 1, 3] -> [[1,1,0,1], [1,0,0,1], [0,1,0,0]]

---

## Visual: Duplicate Detection

```
Inserting Row 2 [1, 1, 0, 1]:

       root
        |
        1 -----> Found! Move down
        |
        1 -----> Found! Move down
        |
        0 -----> Found! Move down
        |
        1* ----> Found AND is_end=True!
      (row 0)
        
        At this point:
        - We reached end of row
        - Node already marked as is_end
        - This means exact same row exists!
        
        => DUPLICATE!
```

---

## Handling Edge Cases

### Case 1: All rows identical
```
Matrix:
[1, 0, 1]
[1, 0, 1]
[1, 0, 1]

Trie: root -> 1 -> 0 -> 1* (only row 0 marked)

Unique rows: [[1, 0, 1]] (just the first occurrence)
```

### Case 2: All rows different
```
Matrix:
[0, 0]
[0, 1]
[1, 0]
[1, 1]

Trie:
       root
      /    \
     0      1
    / \    / \
   0*  1* 0*  1*

All paths unique, all rows returned.
```

### Case 3: Single row
```
Matrix: [[1, 0, 1]]

Result: [[1, 0, 1]] (trivially unique)
```

### Case 4: Single column
```
Matrix:
[0]
[1]
[0]  <- Duplicate
[1]  <- Duplicate

Trie:
  root
 /    \
0*    1*

Unique: [[0], [1]]
```

---

## Time and Space Complexity

### Time Complexity: O(R * C)
- R = number of rows
- C = number of columns
- Each cell visited exactly once during insertion

### Space Complexity: O(R * C)
- Worst case: All rows unique, store entire matrix in Trie
- Best case: All rows identical, only store one path

### Comparison with HashSet:
- Both are O(R * C) time and space
- Trie may be more memory efficient when rows share prefixes
- HashSet is simpler to implement

---

## Why Not Just Use a Set?

**HashSet approach:**
```python
seen = set()
for row in matrix:
    key = tuple(row)  # or ''.join(map(str, row))
    if key not in seen:
        seen.add(key)
        unique_rows.append(row)
```

**When Trie is better:**
1. When rows have many common prefixes (saves space)
2. When you need partial matching
3. Educational purposes to understand Trie

**When HashSet is better:**
1. Simpler implementation
2. No prefix matching needed
3. Random access to check existence

---

## Pattern: Using Trie for Uniqueness

This problem demonstrates a general pattern:
**Use Trie to detect duplicate sequences**

Other applications:
1. **Unique DNA sequences**: 4-ary Trie (A, C, G, T)
2. **Unique IP prefixes**: Binary Trie
3. **Unique file paths**: Trie with path components
4. **Unique phone numbers**: 10-ary Trie (digits 0-9)

The key insight: Trie naturally handles sequence comparison and prefix sharing!
