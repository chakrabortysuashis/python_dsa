"""
Problem: Print Unique Rows in a Given Boolean Matrix
=====================================================

Given a boolean matrix of 0s and 1s, find and print all unique rows.
Rows are considered duplicates if they have the same sequence of values.

Example:
    Input:
    [1, 1, 0, 1]
    [1, 0, 0, 1]
    [1, 1, 0, 1]  <- Duplicate
    [0, 1, 0, 0]

    Output:
    [1, 1, 0, 1]
    [1, 0, 0, 1]
    [0, 1, 0, 0]

Approach:
    Use Binary Trie where each path represents a row.
    - Insert each row as a binary path
    - If path already exists with is_end=True, it's a duplicate
    - Otherwise, mark as unique

Time Complexity: O(R * C) where R = rows, C = columns
Space Complexity: O(R * C) in worst case
"""

from typing import List, Tuple, Optional, Dict


class BinaryTrieNode:
    """
    A node in the binary Trie.

    Each node has at most 2 children: '0' and '1'
    """

    def __init__(self):
        self.children: Dict[str, 'BinaryTrieNode'] = {}  # '0' or '1' -> node
        self.is_end: bool = False
        self.row_index: int = -1  # Index of first row with this path


class BinaryTrie:
    """
    Binary Trie for detecting duplicate rows.

    Each row becomes a path from root to a leaf.
    Duplicate rows follow the same path.
    """

    def __init__(self):
        self.root = BinaryTrieNode()

    def insert(self, row: List[int], row_index: int) -> Tuple[bool, int]:
        """
        Insert a row into the Trie.

        Returns:
            Tuple of (is_unique, existing_row_index)
            - is_unique: True if this row is new
            - existing_row_index: Index of first occurrence (if duplicate)

        Visualization for insert([1, 1, 0, 1]):

        Step 1: Start at root
        Step 2: Insert '1'
            root -> 1

        Step 3: Insert '1'
            root -> 1 -> 1

        Step 4: Insert '0'
            root -> 1 -> 1 -> 0

        Step 5: Insert '1', mark is_end=True
            root -> 1 -> 1 -> 0 -> 1*

        If path already exists with is_end=True: DUPLICATE
        """
        node = self.root

        for bit in row:
            key = str(bit)

            if key not in node.children:
                node.children[key] = BinaryTrieNode()

            node = node.children[key]

        # Check if this exact row already exists
        if node.is_end:
            return False, node.row_index  # Duplicate!

        # Mark as new unique row
        node.is_end = True
        node.row_index = row_index
        return True, row_index

    def get_path(self, row: List[int]) -> List[BinaryTrieNode]:
        """Get the path of nodes for a row (for visualization)."""
        path = [self.root]
        node = self.root

        for bit in row:
            key = str(bit)
            if key in node.children:
                node = node.children[key]
                path.append(node)
            else:
                break

        return path


def find_unique_rows_trie(matrix: List[List[int]]) -> List[List[int]]:
    """
    Find unique rows in boolean matrix using Binary Trie.

    Algorithm:
    1. Create Binary Trie (children are '0' and '1')
    2. For each row:
       - Insert as path in Trie
       - If path exists with is_end=True -> duplicate
       - Otherwise -> unique, mark is_end=True
    3. Return all unique rows

    Dry Run for:
    [1, 1, 0, 1]
    [1, 0, 0, 1]
    [1, 1, 0, 1]  <- Duplicate

    Row 0 [1,1,0,1]:
        Path: root -> 1 -> 1 -> 0 -> 1
        New path, mark is_end=True
        -> UNIQUE

    Row 1 [1,0,0,1]:
        Path: root -> 1 -> 0 -> 0 -> 1
        Branches at second element (0 instead of 1)
        New path, mark is_end=True
        -> UNIQUE

    Row 2 [1,1,0,1]:
        Path: root -> 1 -> 1 -> 0 -> 1
        Path exists! is_end already True!
        -> DUPLICATE (skip)

    Result: [[1,1,0,1], [1,0,0,1]]
    """
    if not matrix or not matrix[0]:
        return []

    trie = BinaryTrie()
    unique_rows = []

    for row_idx, row in enumerate(matrix):
        is_unique, _ = trie.insert(row, row_idx)

        if is_unique:
            unique_rows.append(row)

    return unique_rows


def find_unique_rows_with_indices(matrix: List[List[int]]) -> List[Tuple[int, List[int]]]:
    """
    Find unique rows and return with their original indices.

    Returns:
        List of tuples: (original_index, row)
    """
    if not matrix or not matrix[0]:
        return []

    trie = BinaryTrie()
    unique_rows = []

    for row_idx, row in enumerate(matrix):
        is_unique, first_index = trie.insert(row, row_idx)

        if is_unique:
            unique_rows.append((row_idx, row))

    return unique_rows


def find_unique_rows_with_trace(matrix: List[List[int]]) -> Tuple[List[List[int]], List[Tuple[int, str, int]]]:
    """
    Find unique rows with detailed trace for visualization.

    Returns:
        Tuple of (unique_rows, trace)
        trace = list of (row_index, status, duplicate_of)
    """
    if not matrix or not matrix[0]:
        return [], []

    trie = BinaryTrie()
    unique_rows = []
    trace = []

    for row_idx, row in enumerate(matrix):
        is_unique, first_index = trie.insert(row, row_idx)

        if is_unique:
            unique_rows.append(row)
            trace.append((row_idx, "unique", -1))
        else:
            trace.append((row_idx, "duplicate", first_index))

    return unique_rows, trace


# ============================================================
# Alternative: HashSet approach (for comparison)
# ============================================================

def find_unique_rows_hashset(matrix: List[List[int]]) -> List[List[int]]:
    """
    Find unique rows using HashSet (simpler alternative).

    Time: O(R * C)
    Space: O(R * C)
    """
    seen = set()
    unique_rows = []

    for row in matrix:
        key = tuple(row)  # Convert to tuple for hashing

        if key not in seen:
            seen.add(key)
            unique_rows.append(row)

    return unique_rows


# ============================================================
# Visualization Helper
# ============================================================

def visualize_binary_trie(matrix: List[List[int]]) -> str:
    """Create text visualization of the Binary Trie."""
    trie = BinaryTrie()

    for row_idx, row in enumerate(matrix):
        trie.insert(row, row_idx)

    lines = ["Binary Trie:", "root"]

    def build_viz(node: BinaryTrieNode, indent: str):
        children = sorted(node.children.items())
        for i, (bit, child) in enumerate(children):
            is_last = i == len(children) - 1
            connector = "\\-- " if is_last else "|-- "
            next_indent = indent + ("    " if is_last else "|   ")

            end_marker = ""
            if child.is_end:
                end_marker = f" (row {child.row_index})"

            lines.append(f"{indent}{connector}{bit}{end_marker}")
            build_viz(child, next_indent)

    build_viz(trie.root, "")
    return '\n'.join(lines)


# ============================================================
# Test Cases
# ============================================================

def test_unique_rows():
    """Test unique rows implementations."""

    print("=" * 60)
    print("TEST: Print Unique Rows in Boolean Matrix")
    print("=" * 60)

    # Test 1: Matrix with duplicates
    print("\nTest 1: Matrix with duplicates")
    matrix1 = [
        [1, 1, 0, 1],
        [1, 0, 0, 1],
        [1, 1, 0, 1],  # Duplicate of row 0
        [0, 1, 0, 0],
        [1, 1, 0, 1]   # Duplicate of row 0
    ]
    print("  Input matrix:")
    for i, row in enumerate(matrix1):
        print(f"    Row {i}: {row}")

    result1 = find_unique_rows_trie(matrix1)
    print(f"  Unique rows: {result1}")
    assert len(result1) == 3
    print("  PASSED")

    # Test 2: All unique
    print("\nTest 2: All unique rows")
    matrix2 = [
        [0, 0],
        [0, 1],
        [1, 0],
        [1, 1]
    ]
    result2 = find_unique_rows_trie(matrix2)
    print(f"  Input: {matrix2}")
    print(f"  Output: {result2}")
    assert len(result2) == 4
    print("  PASSED")

    # Test 3: All duplicates
    print("\nTest 3: All duplicate rows")
    matrix3 = [
        [1, 0, 1],
        [1, 0, 1],
        [1, 0, 1]
    ]
    result3 = find_unique_rows_trie(matrix3)
    print(f"  Input: {matrix3}")
    print(f"  Output: {result3}")
    assert len(result3) == 1
    print("  PASSED")

    # Test 4: Single row
    print("\nTest 4: Single row")
    matrix4 = [[1, 0, 1, 0]]
    result4 = find_unique_rows_trie(matrix4)
    print(f"  Input: {matrix4}")
    print(f"  Output: {result4}")
    assert result4 == matrix4
    print("  PASSED")

    # Test 5: Empty matrix
    print("\nTest 5: Empty matrix")
    matrix5 = []
    result5 = find_unique_rows_trie(matrix5)
    print(f"  Input: {matrix5}")
    print(f"  Output: {result5}")
    assert result5 == []
    print("  PASSED")

    # Test 6: Compare with HashSet
    print("\nTest 6: Compare Trie vs HashSet")
    result_trie = find_unique_rows_trie(matrix1)
    result_hash = find_unique_rows_hashset(matrix1)
    print(f"  Trie result: {result_trie}")
    print(f"  HashSet result: {result_hash}")
    assert result_trie == result_hash
    print("  PASSED")


def demonstrate_step_by_step():
    """Show detailed step-by-step execution."""

    print("\n" + "=" * 60)
    print("STEP-BY-STEP DEMONSTRATION")
    print("=" * 60)

    matrix = [
        [1, 1, 0, 1],
        [1, 0, 0, 1],
        [1, 1, 0, 1],
        [0, 1, 0, 0]
    ]

    print("\nInput Matrix:")
    for i, row in enumerate(matrix):
        print(f"  Row {i}: {row}")

    print("\n--- Processing Each Row ---")

    unique_rows, trace = find_unique_rows_with_trace(matrix)

    for row_idx, status, dup_of in trace:
        row = matrix[row_idx]
        if status == "unique":
            print(f"\nRow {row_idx}: {row}")
            print(f"  -> Path created in Trie")
            print(f"  -> Status: UNIQUE")
        else:
            print(f"\nRow {row_idx}: {row}")
            print(f"  -> Path already exists (from Row {dup_of})")
            print(f"  -> Status: DUPLICATE (skipped)")

    print("\n--- Trie Visualization ---")
    print(visualize_binary_trie(matrix))

    print("\n--- Final Result ---")
    print(f"Unique rows: {unique_rows}")


def demonstrate_binary_paths():
    """Show how rows become binary paths."""

    print("\n" + "=" * 60)
    print("DEMONSTRATION: Rows as Binary Paths")
    print("=" * 60)

    matrix = [
        [1, 0, 1],
        [1, 1, 0],
        [1, 0, 1]
    ]

    print("\nMatrix:")
    for i, row in enumerate(matrix):
        print(f"  Row {i}: {row}")

    print("\nAs Binary Trie Paths:")
    print("  Row 0: root -> 1 -> 0 -> 1 (path 101)")
    print("  Row 1: root -> 1 -> 1 -> 0 (path 110)")
    print("  Row 2: root -> 1 -> 0 -> 1 (same as Row 0!)")

    print("\n" + visualize_binary_trie(matrix))

    unique = find_unique_rows_trie(matrix)
    print(f"\nUnique rows: {unique}")


if __name__ == "__main__":
    test_unique_rows()
    demonstrate_step_by_step()
    demonstrate_binary_paths()
