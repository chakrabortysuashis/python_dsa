# Trie (Prefix Tree) - Complete Guide

## What is a Trie?

A **Trie** (pronounced "try") is a tree-like data structure used for storing strings in a way that allows for efficient retrieval. The name comes from "re**TRIE**val". It's also called a **Prefix Tree** because it excels at prefix-based operations.

```
                    root
                   / | \
                  a  b  c
                 /   |   \
                p    a    a
               /     |     \
              p      t      r
             /        \
            l          s
           /
          e
          
Words: "apple", "bat", "bats", "car"
```

### Key Characteristics
- Each node represents a character
- Root node is empty (represents empty string)
- Each path from root to a marked node represents a word
- Common prefixes share the same path (memory efficient)

---

## TrieNode Structure

Each node in a Trie contains:
1. **Children**: Links to child nodes (typically 26 for lowercase letters)
2. **End Marker**: Boolean flag indicating if this node marks end of a word
3. **Optional**: Word count, prefix count, or stored word itself

```python
class TrieNode:
    def __init__(self):
        # Dictionary to store children (char -> TrieNode)
        self.children = {}
        # Marks end of a complete word
        self.is_end_of_word = False
        # Optional: count words ending here
        self.word_count = 0
        # Optional: count words with this prefix
        self.prefix_count = 0
```

### Two Common Implementations

**1. Dictionary/HashMap Based (Flexible)**
```python
self.children = {}  # char -> TrieNode
# Access: self.children.get('a') or self.children['a']
```

**2. Fixed Array Based (Faster for known alphabet)**
```python
self.children = [None] * 26  # Index 0='a', 1='b', ...
# Access: self.children[ord(char) - ord('a')]
```

---

## Insert Operation

**Algorithm:**
1. Start at root node
2. For each character in the word:
   - If child for character doesn't exist, create it
   - Move to that child
3. Mark the final node as end of word

```
Insert "cat" into empty Trie:

Step 1: Insert 'c'           Step 2: Insert 'a'           Step 3: Insert 't'
    root                         root                         root
     |                            |                            |
     c                            c                            c
                                  |                            |
                                  a                            a
                                                               |
                                                               t*
                                                        (* = end of word)
```

**Code:**
```python
def insert(self, word: str) -> None:
    node = self.root
    for char in word:
        if char not in node.children:
            node.children[char] = TrieNode()
        node = node.children[char]
    node.is_end_of_word = True
```

**Time Complexity:** O(m) where m = length of word
**Space Complexity:** O(m) in worst case (no shared prefix)

---

## Search Operation

**Algorithm:**
1. Start at root node
2. For each character in the word:
   - If child for character doesn't exist, return False
   - Move to that child
3. Return True only if final node is marked as end of word

```
Search "cat" in Trie containing ["cat", "car", "card"]:

    root
     |
     c
     |
     a -----> Found 'a'
    / \
   t*  r*    -> Move to 't', is_end_of_word = True
       |       FOUND!
       d*

Search "ca" -> traverse c->a, but 'a' is NOT end of word -> NOT FOUND
```

**Code:**
```python
def search(self, word: str) -> bool:
    node = self.root
    for char in word:
        if char not in node.children:
            return False
        node = node.children[char]
    return node.is_end_of_word
```

**Time Complexity:** O(m) where m = length of word

---

## Prefix Search (startsWith)

**Algorithm:**
Same as search, but don't check is_end_of_word at the end.

```
Check prefix "ca" in Trie with ["cat", "car"]:

    root
     |
     c ----> Found 'c'
     |
     a ----> Found 'a'
    / \
   t*  r*
   
Reached end of prefix "ca" -> PREFIX EXISTS!
```

**Code:**
```python
def starts_with(self, prefix: str) -> bool:
    node = self.root
    for char in prefix:
        if char not in node.children:
            return False
        node = node.children[char]
    return True  # Don't check is_end_of_word
```

**Time Complexity:** O(m) where m = length of prefix

---

## Delete Operation

**Algorithm:**
1. Search for the word, keeping track of path
2. If word exists, unmark is_end_of_word
3. Remove nodes that are no longer needed (no children, not end of another word)

```
Delete "cat" from ["cat", "car"]:

Before:                    After:
    root                     root
     |                        |
     c                        c
     |                        |
     a                        a
    / \                        \
   t*  r*      ->               r*
   
Node 't' removed (no children, no longer end of word)
Node 'a' and 'c' kept (part of "car")
```

**Code:**
```python
def delete(self, word: str) -> bool:
    def _delete(node: TrieNode, word: str, depth: int) -> bool:
        if depth == len(word):
            if not node.is_end_of_word:
                return False  # Word doesn't exist
            node.is_end_of_word = False
            return len(node.children) == 0  # Can delete if no children
        
        char = word[depth]
        if char not in node.children:
            return False  # Word doesn't exist
        
        child = node.children[char]
        should_delete_child = _delete(child, word, depth + 1)
        
        if should_delete_child:
            del node.children[char]
            return len(node.children) == 0 and not node.is_end_of_word
        
        return False
    
    _delete(self.root, word, 0)
```

**Time Complexity:** O(m) where m = length of word

---

## Space Optimization Techniques

### 1. Compressed Trie (Radix Tree / Patricia Trie)

Combine chains of single-child nodes into one node.

```
Standard Trie:          Compressed Trie:
    root                    root
     |                       |
     c                      car
     |                     /   \
     a                   d*     t*
     |
     r*
    / \
   d*  t*

Words: "card", "cart"
```

### 2. Ternary Search Trie

Each node has three children: less than, equal to, greater than.
- Saves space when alphabet is large
- Slightly slower operations

### 3. DAWG (Directed Acyclic Word Graph)

Share suffixes as well as prefixes.
- Most space efficient
- Complex to implement

### 4. Bit-level Optimization

Use bit manipulation for character indexing:
```python
# Instead of dictionary
children = [None] * 26
index = ord(char) - ord('a')
```

---

## Time Complexity Summary

| Operation | Time Complexity | Notes |
|-----------|-----------------|-------|
| Insert    | O(m)           | m = word length |
| Search    | O(m)           | m = word length |
| Prefix Search | O(m)       | m = prefix length |
| Delete    | O(m)           | m = word length |
| Find all with prefix | O(m + n) | n = number of matching words |

**Comparison with Other Data Structures:**

| Structure | Insert | Search | Prefix Search |
|-----------|--------|--------|---------------|
| Trie      | O(m)   | O(m)   | O(m)          |
| HashSet   | O(m)   | O(m)   | O(n*m)        |
| BST       | O(m log n) | O(m log n) | O(n*m) |

Where m = word length, n = number of words

---

## Applications

### 1. Autocomplete System
```
User types: "app"

Trie traversal:
    root -> a -> p -> p
                      |
                   [apple, application, apply, ...]
                   
Return all words starting with "app"
```

### 2. Spell Checker
- Store dictionary in Trie
- For misspelled word, find words within edit distance
- Use prefix matching for suggestions

### 3. IP Routing (Longest Prefix Match)
- Store IP prefixes in Trie
- Find longest matching prefix for routing decisions

### 4. Word Games (Boggle, Scrabble)
- Efficiently check if a string is a valid word
- Check if a prefix can lead to valid words

### 5. Search Engine Indexing
- Store keywords with document references
- Efficient prefix-based search

### 6. DNA Sequence Analysis
- Alphabet: {A, C, G, T}
- Find patterns in genetic sequences

### 7. Phone Directory
- Store contacts by name
- Autocomplete as user types

---

## When to Use Trie vs Other Structures

**Use Trie When:**
- Need prefix-based searches
- Building autocomplete systems
- Dictionary with many common prefixes
- Need to find all words with a prefix
- Lexicographic ordering is needed

**Use HashMap When:**
- Only need exact match lookups
- Memory is a concern
- No prefix operations needed

**Use Balanced BST When:**
- Need sorted order traversal
- Memory efficiency is important
- Fewer prefix operations

---

## Common Patterns in Trie Problems

### Pattern 1: Word Search with Wildcard
```python
def search_with_wildcard(self, word: str) -> bool:
    def dfs(node, index):
        if index == len(word):
            return node.is_end_of_word
        
        char = word[index]
        if char == '.':  # Wildcard
            for child in node.children.values():
                if dfs(child, index + 1):
                    return True
            return False
        else:
            if char not in node.children:
                return False
            return dfs(node.children[char], index + 1)
    
    return dfs(self.root, 0)
```

### Pattern 2: Count Words with Prefix
```python
def count_words_with_prefix(self, prefix: str) -> int:
    node = self._find_node(prefix)
    if not node:
        return 0
    return self._count_words(node)

def _count_words(self, node):
    count = 1 if node.is_end_of_word else 0
    for child in node.children.values():
        count += self._count_words(child)
    return count
```

### Pattern 3: Longest Common Prefix
```python
def longest_common_prefix(self) -> str:
    prefix = []
    node = self.root
    while node and len(node.children) == 1 and not node.is_end_of_word:
        char = list(node.children.keys())[0]
        prefix.append(char)
        node = node.children[char]
    return ''.join(prefix)
```

---

## Practice Problems (In Order)

1. **Construct a Trie from Scratch** - Basic implementation
2. **Find Shortest Unique Prefix** - Prefix counting
3. **Word Break Problem** - DP with Trie
4. **Print All Anagrams Together** - Trie with sorted keys
5. **Implement Phone Directory** - Autocomplete
6. **Unique Rows in Boolean Matrix** - Trie for uniqueness

---

## Key Takeaways

1. **Trie = Prefix Tree** - Optimized for prefix operations
2. **Time Complexity** - O(m) for all operations, independent of dictionary size
3. **Space Trade-off** - Uses more memory than hash for few words, less for many with common prefixes
4. **Children Storage** - Dictionary (flexible) vs Array (faster for fixed alphabet)
5. **Applications** - Autocomplete, spell check, IP routing, search engines
