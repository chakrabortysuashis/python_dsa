# Print All Anagrams Together

## Problem Statement

Given an array of words, group all anagrams together. Anagrams are words that contain the same characters in different orders.

**Example 1:**
```
Input: ["cat", "dog", "tac", "god", "act", "ogd"]
Output: [["cat", "tac", "act"], ["dog", "god", "ogd"]]

Explanation:
- "cat", "tac", "act" are anagrams (all contain 'a', 'c', 't')
- "dog", "god", "ogd" are anagrams (all contain 'd', 'g', 'o')
```

**Example 2:**
```
Input: ["listen", "silent", "enlist", "hello"]
Output: [["listen", "silent", "enlist"], ["hello"]]
```

---

## Why Trie is Useful Here

### Approach Comparison

| Approach | Time | Space | Notes |
|----------|------|-------|-------|
| Sorting + HashMap | O(n * m * log m) | O(n * m) | Sort each word |
| Character Count + HashMap | O(n * m) | O(n * m) | Count chars |
| **Trie with Sorted Key** | O(n * m * log m) | O(n * m) | Insert sorted word |

**Trie Approach:**
1. Sort characters of each word
2. Insert sorted word into Trie
3. Store original word at the end node
4. All anagrams have the same sorted form = same path in Trie!

**Key Insight:** Anagrams, when sorted, become identical strings!
- "cat" sorted = "act"
- "tac" sorted = "act"
- "act" sorted = "act"
- All three follow the same Trie path: a -> c -> t

---

## Trie Construction for Anagrams

### Building Trie for ["cat", "dog", "tac", "god", "act"]

**Step 1: Sort and Insert**

| Word | Sorted Form | Trie Path |
|------|-------------|-----------|
| "cat" | "act" | a -> c -> t |
| "dog" | "dgo" | d -> g -> o |
| "tac" | "act" | a -> c -> t (same path!) |
| "god" | "dgo" | d -> g -> o (same path!) |
| "act" | "act" | a -> c -> t (same path!) |

**Resulting Trie:**
```
            root
           /    \
          a      d
          |      |
          c      g
          |      |
          t*     o*
     (cat,tac,act)  (dog,god)
```

**Node Storage:**
- At 't': words = ["cat", "tac", "act"]
- At 'o': words = ["dog", "god"]

---

## Step-by-Step Algorithm

### Algorithm:
```
1. For each word in input:
   a. Sort characters to get key
   b. Insert sorted key into Trie
   c. At end node, append original word to list

2. DFS traverse Trie
   a. At each end node, collect the word list
   b. Each list is a group of anagrams
```

### Character-by-Character Dry Run

**Input:** ["cat", "dog", "tac"]

**Process "cat":**
```
1. Sort "cat" -> "act"
2. Insert "act" into Trie:
   
   root          root          root          root
    |             |             |             |
    a     ->      a     ->      a     ->      a
                  |             |             |
                  c             c             c
                                |             |
                                t             t*
                                          words=["cat"]
```

**Process "dog":**
```
1. Sort "dog" -> "dgo"
2. Insert "dgo" into Trie:

        root                    
       /    \                   
      a      d                  
      |      |                  
      c      g                  
      |      |                  
      t*     o*                 
  ["cat"]  ["dog"]              
```

**Process "tac":**
```
1. Sort "tac" -> "act"
2. Path "act" already exists! Append to word list:

        root                    
       /    \                   
      a      d                  
      |      |                  
      c      g                  
      |      |                  
      t*     o*                 
["cat","tac"] ["dog"]           
```

---

## Visual: Why Sorted Keys Work

```
Original Words:
    "cat"  ->  c, a, t
    "tac"  ->  t, a, c
    "act"  ->  a, c, t

After Sorting Characters:
    "cat"  ->  a, c, t  ->  "act"
    "tac"  ->  a, c, t  ->  "act"
    "act"  ->  a, c, t  ->  "act"
    
All map to same key "act" = Same Trie path!

Trie Path for all three:
    root -> a -> c -> t* (store ["cat", "tac", "act"])
```

---

## Collecting Results via DFS

```
DFS Traversal:

Visit root
  |
  +--> Visit 'a'
  |      |
  |      +--> Visit 'c'
  |             |
  |             +--> Visit 't' (is_end=True)
  |                    |
  |                    Collect: ["cat", "tac", "act"]
  |
  +--> Visit 'd'
         |
         +--> Visit 'g'
                |
                +--> Visit 'o' (is_end=True)
                       |
                       Collect: ["dog", "god"]

Result: [["cat", "tac", "act"], ["dog", "god"]]
```

---

## Time and Space Complexity

### Time Complexity: O(n * m * log m)
- n = number of words
- m = average word length
- Sorting each word: O(m * log m)
- Inserting into Trie: O(m)
- Total: O(n * (m * log m + m)) = O(n * m * log m)

### Space Complexity: O(n * m)
- Trie storage: O(26 * m) for unique sorted forms
- Storing original words: O(n * m)

---

## Edge Cases

1. **Single word**: Return [[word]]
2. **All same word**: Return [[word, word, ...]]
3. **No anagrams**: Each word in its own group
4. **Empty string**: Group with other empty strings
5. **Different lengths**: Words of different lengths can't be anagrams

---

## Alternative: Character Frequency as Key

Instead of sorting, use character count tuple as key:

```python
def get_key(word):
    """Create frequency-based key."""
    count = [0] * 26
    for c in word:
        count[ord(c) - ord('a')] += 1
    return tuple(count)

# "cat" -> (1,0,1,0,...,1,...0)  # a=1, c=1, t=1
# "tac" -> (1,0,1,0,...,1,...0)  # Same!
```

This is O(m) instead of O(m log m) for key generation, but uses more space for the key.

---

## Trie vs HashMap Comparison

### HashMap Approach:
```python
def group_anagrams_hashmap(words):
    groups = defaultdict(list)
    for word in words:
        key = ''.join(sorted(word))
        groups[key].append(word)
    return list(groups.values())
```

### Trie Approach:
```python
def group_anagrams_trie(words):
    trie = Trie()
    for word in words:
        sorted_word = ''.join(sorted(word))
        trie.insert(sorted_word, word)
    return trie.collect_groups()
```

**When to use Trie:**
- When you need prefix-based grouping
- When words share many common sorted prefixes
- Educational purposes to understand Trie applications

**When to use HashMap:**
- Simpler implementation
- When memory for hash table is acceptable
- No prefix operations needed

---

## Pattern Recognition

This problem demonstrates a key pattern:
**Transform-and-Group using Trie**

1. **Transform**: Convert each input to a canonical form
2. **Group**: Items with same canonical form go together
3. **Trie**: Use Trie to efficiently group by canonical form

Other problems using this pattern:
- Group words by length
- Group numbers by digit sum
- Group strings by first character
