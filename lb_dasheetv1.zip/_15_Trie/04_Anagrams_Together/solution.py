"""
Problem: Print All Anagrams Together
====================================

Given an array of words, group all anagrams together.
Anagrams are words that contain the same characters in different orders.

Example:
    Input: ["cat", "dog", "tac", "god", "act"]
    Output: [["cat", "tac", "act"], ["dog", "god"]]

Approach:
    1. Sort characters of each word to get a canonical form
    2. Insert sorted form into Trie, storing original word at end node
    3. All anagrams have same sorted form = same Trie path
    4. Collect groups by traversing Trie

Time Complexity: O(n * m * log m) where n = words, m = avg length
Space Complexity: O(n * m) for storing words
"""

from typing import List, Dict, Tuple
from collections import defaultdict


class TrieNode:
    """
    Trie node for grouping anagrams.

    Each node stores:
    - children: map to child nodes
    - words: list of original words that share this sorted form
    """

    def __init__(self):
        self.children: Dict[str, 'TrieNode'] = {}
        self.words: List[str] = []  # Store original words at end nodes


class Trie:
    """Trie for grouping anagrams by sorted character key."""

    def __init__(self):
        self.root = TrieNode()

    def insert(self, sorted_word: str, original_word: str) -> None:
        """
        Insert a word using its sorted form as the key.

        Args:
            sorted_word: Characters sorted alphabetically (the key)
            original_word: The original word to store

        Example:
            insert("act", "cat")  # "cat" sorted is "act"
            insert("act", "tac")  # "tac" sorted is also "act"

        Both words end up at the same node!
        """
        node = self.root

        for char in sorted_word:
            if char not in node.children:
                node.children[char] = TrieNode()
            node = node.children[char]

        # Store original word at the end node
        node.words.append(original_word)

    def collect_groups(self) -> List[List[str]]:
        """
        Collect all anagram groups from the Trie.

        Returns:
            List of groups, where each group contains anagrams
        """
        groups = []

        def dfs(node: TrieNode):
            # If this node has words, it's an anagram group
            if node.words:
                groups.append(node.words.copy())

            # Traverse children
            for child in node.children.values():
                dfs(child)

        dfs(self.root)
        return groups


def group_anagrams_trie(words: List[str]) -> List[List[str]]:
    """
    Group anagrams using Trie with sorted character keys.

    Algorithm:
    1. For each word, sort its characters to get a key
    2. Insert into Trie using sorted key, store original word
    3. All anagrams follow same path in Trie
    4. Collect groups by DFS traversal

    Visualization for ["cat", "dog", "tac"]:

    Process "cat":
        sorted("cat") = "act"
        Trie: root -> a -> c -> t (words=["cat"])

    Process "dog":
        sorted("dog") = "dgo"
        Trie: root -> a -> c -> t (words=["cat"])
                   -> d -> g -> o (words=["dog"])

    Process "tac":
        sorted("tac") = "act"
        Path "act" already exists!
        Trie: root -> a -> c -> t (words=["cat", "tac"])
                   -> d -> g -> o (words=["dog"])

    Result: [["cat", "tac"], ["dog"]]
    """
    if not words:
        return []

    trie = Trie()

    for word in words:
        # Sort characters to get canonical form
        sorted_word = ''.join(sorted(word))

        # Insert with sorted key, store original word
        trie.insert(sorted_word, word)

    # Collect all groups
    return trie.collect_groups()


def group_anagrams_trie_with_trace(words: List[str]) -> Tuple[List[List[str]], List[Tuple[str, str]]]:
    """
    Group anagrams with detailed trace for visualization.

    Returns:
        Tuple of (groups, trace) where trace shows word -> sorted transformation
    """
    if not words:
        return [], []

    trie = Trie()
    trace = []

    for word in words:
        sorted_word = ''.join(sorted(word))
        trace.append((word, sorted_word))
        trie.insert(sorted_word, word)

    groups = trie.collect_groups()
    return groups, trace


# ============================================================
# Alternative: HashMap approach (for comparison)
# ============================================================

def group_anagrams_hashmap(words: List[str]) -> List[List[str]]:
    """
    Group anagrams using HashMap (simpler alternative).

    Time: O(n * m * log m)
    Space: O(n * m)
    """
    groups = defaultdict(list)

    for word in words:
        # Use sorted string as key
        key = ''.join(sorted(word))
        groups[key].append(word)

    return list(groups.values())


def group_anagrams_count_key(words: List[str]) -> List[List[str]]:
    """
    Group anagrams using character count as key (no sorting needed).

    Time: O(n * m) - no sorting!
    Space: O(n * m)
    """
    groups = defaultdict(list)

    for word in words:
        # Create character count tuple as key
        count = [0] * 26
        for char in word:
            count[ord(char) - ord('a')] += 1
        key = tuple(count)
        groups[key].append(word)

    return list(groups.values())


# ============================================================
# Visualization Helper
# ============================================================

def visualize_trie_for_anagrams(words: List[str]) -> str:
    """Create text visualization of the Trie structure."""

    trie = Trie()
    for word in words:
        sorted_word = ''.join(sorted(word))
        trie.insert(sorted_word, word)

    lines = [f"Words: {words}", "", "Trie Structure:"]

    def build_viz(node: TrieNode, prefix: str, indent: str):
        children = sorted(node.children.items())
        for i, (char, child) in enumerate(children):
            is_last = i == len(children) - 1
            connector = "\\-- " if is_last else "|-- "
            next_indent = indent + ("    " if is_last else "|   ")

            word_info = ""
            if child.words:
                word_info = f" -> {child.words}"

            lines.append(f"{indent}{connector}{char}{word_info}")
            build_viz(child, prefix + char, next_indent)

    lines.append("root")
    build_viz(trie.root, "", "")

    return '\n'.join(lines)


# ============================================================
# Test Cases
# ============================================================

def test_group_anagrams():
    """Test anagram grouping implementations."""

    print("=" * 60)
    print("TEST: Group Anagrams Together")
    print("=" * 60)

    # Test 1: Basic example
    print("\nTest 1: Basic example")
    words1 = ["cat", "dog", "tac", "god", "act", "ogd"]
    result1 = group_anagrams_trie(words1)
    print(f"  Input: {words1}")
    print(f"  Output: {result1}")

    # Verify all anagrams are grouped
    sorted_groups = [sorted(group) for group in result1]
    assert sorted(["cat", "tac", "act"]) in sorted_groups
    assert sorted(["dog", "god", "ogd"]) in sorted_groups
    print("  PASSED")

    # Test 2: No anagrams
    print("\nTest 2: No anagrams")
    words2 = ["apple", "banana", "cherry"]
    result2 = group_anagrams_trie(words2)
    print(f"  Input: {words2}")
    print(f"  Output: {result2}")
    assert len(result2) == 3  # Each word in its own group
    print("  PASSED")

    # Test 3: All same word
    print("\nTest 3: All same word")
    words3 = ["aaa", "aaa", "aaa"]
    result3 = group_anagrams_trie(words3)
    print(f"  Input: {words3}")
    print(f"  Output: {result3}")
    assert len(result3) == 1
    assert len(result3[0]) == 3
    print("  PASSED")

    # Test 4: Single word
    print("\nTest 4: Single word")
    words4 = ["hello"]
    result4 = group_anagrams_trie(words4)
    print(f"  Input: {words4}")
    print(f"  Output: {result4}")
    assert result4 == [["hello"]]
    print("  PASSED")

    # Test 5: Empty list
    print("\nTest 5: Empty list")
    words5 = []
    result5 = group_anagrams_trie(words5)
    print(f"  Input: {words5}")
    print(f"  Output: {result5}")
    assert result5 == []
    print("  PASSED")

    # Test 6: Compare with HashMap approach
    print("\nTest 6: Compare Trie vs HashMap")
    words6 = ["listen", "silent", "enlist", "hello"]
    result_trie = group_anagrams_trie(words6)
    result_hash = group_anagrams_hashmap(words6)
    print(f"  Input: {words6}")
    print(f"  Trie result: {result_trie}")
    print(f"  HashMap result: {result_hash}")
    print("  PASSED")


def demonstrate_step_by_step():
    """Show detailed step-by-step execution."""

    print("\n" + "=" * 60)
    print("STEP-BY-STEP DEMONSTRATION")
    print("=" * 60)

    words = ["cat", "dog", "tac", "god", "act"]

    print(f"\nInput words: {words}")
    print("\n--- Processing Each Word ---")

    for word in words:
        sorted_word = ''.join(sorted(word))
        print(f"  '{word}' -> sorted -> '{sorted_word}'")

    print("\n--- Trie Visualization ---")
    print(visualize_trie_for_anagrams(words))

    groups, trace = group_anagrams_trie_with_trace(words)
    print("\n--- Final Groups ---")
    for i, group in enumerate(groups):
        sorted_key = ''.join(sorted(group[0]))
        print(f"  Group {i + 1} (key='{sorted_key}'): {group}")


def demonstrate_character_count_key():
    """Show alternative approach using character count."""

    print("\n" + "=" * 60)
    print("ALTERNATIVE: Character Count Key")
    print("=" * 60)

    words = ["cat", "tac"]

    print(f"\nWords: {words}")
    print("\nUsing sorted key:")
    for word in words:
        print(f"  '{word}' -> '{sorted(word)}'")

    print("\nUsing character count key:")
    for word in words:
        count = [0] * 26
        for char in word:
            count[ord(char) - ord('a')] += 1
        # Show only non-zero counts
        non_zero = [(chr(ord('a') + i), c) for i, c in enumerate(count) if c > 0]
        print(f"  '{word}' -> {non_zero}")

    print("\nBoth approaches identify 'cat' and 'tac' as anagrams!")


if __name__ == "__main__":
    test_group_anagrams()
    demonstrate_step_by_step()
    demonstrate_character_count_key()
