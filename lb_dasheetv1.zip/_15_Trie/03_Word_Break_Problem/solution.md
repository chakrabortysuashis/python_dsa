# Word Break Problem (Trie Solution)

## Problem Statement

Given a string `s` and a dictionary of words, determine if `s` can be segmented into a space-separated sequence of one or more dictionary words.

**Example 1:**
```
Input: s = "leetcode", wordDict = ["leet", "code"]
Output: True
Explanation: "leetcode" can be segmented as "leet code"
```

**Example 2:**
```
Input: s = "applepenapple", wordDict = ["apple", "pen"]
Output: True
Explanation: "applepenapple" = "apple" + "pen" + "apple"
```

**Example 3:**
```
Input: s = "catsandog", wordDict = ["cats", "dog", "sand", "and", "cat"]
Output: False
Explanation: No valid segmentation exists
```

---

## Why Trie is Useful Here

### Comparison of Approaches

| Approach | Dictionary Lookup | Time Complexity |
|----------|-------------------|-----------------|
| HashSet + DP | O(m) per lookup | O(n^2 * m) |
| **Trie + DP** | O(m) with early termination | O(n^2) amortized |

**Trie Advantages:**
1. **Early termination**: If prefix doesn't exist, stop immediately
2. **Character-by-character matching**: Natural fit for checking all possible splits
3. **Prefix sharing**: Efficient when dictionary has common prefixes

---

## Algorithm: Trie + Dynamic Programming

### Overview
1. Build a Trie from dictionary words
2. Use DP where `dp[i]` = True if `s[0:i]` can be segmented
3. For each position, use Trie to efficiently find all matching words

### Detailed Steps

```
s = "leetcode"
dict = ["leet", "code"]

Trie:
    root
    / \
   l   c
   |   |
   e   o
   |   |
   e   d
   |   |
   t*  e*

DP array: dp[0] = True (empty string is valid)

For i = 0 (start at position 0):
    Check words starting at position 0 using Trie:
    - "l" -> not a word, continue
    - "le" -> not a word, continue
    - "lee" -> not a word, continue
    - "leet" -> IS a word! Set dp[4] = dp[0] = True

For i = 4 (dp[4] is True):
    Check words starting at position 4:
    - "c" -> not a word, continue
    - "co" -> not a word, continue
    - "cod" -> not a word, continue
    - "code" -> IS a word! Set dp[8] = dp[4] = True

dp[8] = True -> "leetcode" CAN be segmented!
```

---

## Character-by-Character Dry Run

### Example: s = "applepenapple", dict = ["apple", "pen"]

**Step 1: Build Trie**
```
        root
       /    \
      a      p
      |      |
      p      e
      |      |
      p      n*
      |
      l
      |
      e*
```

**Step 2: Initialize DP**
```
s =     a  p  p  l  e  p  e  n  a  p  p  l  e
index   0  1  2  3  4  5  6  7  8  9  10 11 12 13
dp =   [T, F, F, F, F, F, F, F, F, F, F,  F, F, F]
        ^
     empty prefix is valid
```

**Step 3: Fill DP using Trie**

| i | dp[i] | Trie Traversal | Words Found | DP Updates |
|---|-------|----------------|-------------|------------|
| 0 | T | a->p->p->l->e* | "apple" ends at 5 | dp[5] = T |
| 1 | F | p->? | - | - |
| 2 | F | p->? | - | - |
| 3 | F | l->? | - | - |
| 4 | F | e->? | - | - |
| 5 | T | p->e->n* | "pen" ends at 8 | dp[8] = T |
| 6 | F | e->? | - | - |
| 7 | F | n->? | - | - |
| 8 | T | a->p->p->l->e* | "apple" ends at 13 | dp[13] = T |

**Final DP:**
```
dp = [T, F, F, F, F, T, F, F, T, F, F, F, F, T]
                     ^        ^              ^
                  "apple"   "pen"        "apple"
```

**Result:** dp[13] = True -> String can be segmented!

---

## Visual Trace: Trie Traversal at Position 0

```
String: "applepenapple"
         ^
         |
         Start here

Trie Traversal:
Step 1: 'a' - root.children['a'] exists, move down
        root
         |
        [a] <-- current
         |
         p

Step 2: 'p' - current.children['p'] exists
        root
         |
         a
         |
        [p] <-- current
         |
         p

Step 3: 'p' - continue
        root -> a -> p -> [p] <-- current

Step 4: 'l' - continue
        root -> a -> p -> p -> [l] <-- current

Step 5: 'e' - current.is_end = True! Word "apple" found!
        root -> a -> p -> p -> l -> [e*] <-- current
                                     ^
                                  is_end = True!

Action: dp[5] = dp[0] = True
```

---

## Handling Failed Case

### Example: s = "catsandog", dict = ["cats", "dog", "sand", "and", "cat"]

**Trie Structure:**
```
        root
       / |  \
      c  s   d
      |  |   |
      a  a   o
      |  |   |
      t  n   g*
     /|  |
    s* d*
```

**DP Trace:**
```
Position 0: "cat" found -> dp[3] = T
            "cats" found -> dp[4] = T
Position 3: "sand" found -> dp[7] = T
            "and" found -> dp[6] = T
Position 4: "and" found -> dp[7] = T (already T)
Position 6: "dog" found? No, remaining is "dog" at pos 6
            Check: d-o-g* -> dp[9] = dp[6]? dp[6] = T
            But wait, let's trace more carefully...
```

Actually:
```
s = "catsandog"
     012345678
     
dp = [T, F, F, T, T, F, F, T, F, F]
          cat^  ^cats  ^sand or and at pos 3

At position 7, remaining string is "og" - no match in dictionary
At position 4, remaining is "andog" - "and" matches to position 7
At position 7, remaining is "og" - no match!

Final: dp[9] = False
```

---

## Time and Space Complexity

### Time Complexity: O(n^2)
- Outer loop: O(n) positions
- Inner loop (Trie traversal): O(n) in worst case
- Total: O(n^2)

Note: With HashSet, each lookup is O(m) making it O(n^2 * m)
With Trie, we traverse character-by-character, so it's O(n^2) amortized.

### Space Complexity: O(m * k + n)
- Trie: O(m * k) where m = avg word length, k = dictionary size
- DP array: O(n)

---

## Edge Cases

1. **Empty string**: Return True (can be segmented into zero words)
2. **Empty dictionary**: Return False (unless s is empty)
3. **Single character**: Check if it's in dictionary
4. **Repeated words**: "aaa" with dict ["a", "aa"] -> True
5. **No possible segmentation**: Return False

---

## Optimization: Early Termination

Using Trie allows early termination when no word can start with current prefix:

```python
# During Trie traversal
if char not in current_node.children:
    break  # No words with this prefix, stop searching
```

This is especially powerful when:
- Dictionary has few words starting with certain letters
- String has characters not in any dictionary word

---

## Alternative: Finding All Segmentations

To find ALL possible segmentations (not just check if possible):

```python
def word_break_all(s, word_dict):
    """Return all possible segmentations."""
    trie = build_trie(word_dict)
    memo = {}
    
    def backtrack(start):
        if start == len(s):
            return [[]]
        
        if start in memo:
            return memo[start]
        
        results = []
        node = trie.root
        
        for end in range(start, len(s)):
            char = s[end]
            if char not in node.children:
                break
            
            node = node.children[char]
            if node.is_end:
                word = s[start:end+1]
                for rest in backtrack(end + 1):
                    results.append([word] + rest)
        
        memo[start] = results
        return results
    
    return backtrack(0)
```

Example:
```
s = "catsanddog"
dict = ["cat", "cats", "and", "sand", "dog"]

Output: [
    ["cat", "sand", "dog"],
    ["cats", "and", "dog"]
]
```
