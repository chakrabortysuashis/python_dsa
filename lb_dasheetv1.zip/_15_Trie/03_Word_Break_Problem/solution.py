"""
Problem: Word Break (Trie + DP Solution)
========================================

Given a string s and a dictionary of words, determine if s can be
segmented into a space-separated sequence of dictionary words.

Example:
    Input: s = "leetcode", wordDict = ["leet", "code"]
    Output: True (can be segmented as "leet code")

Approach:
    1. Build a Trie from dictionary words
    2. Use DP where dp[i] = True if s[0:i] can be segmented
    3. For each valid position, use Trie to find all matching words

Time Complexity: O(n^2) where n = length of string
Space Complexity: O(m*k + n) where m = avg word length, k = dict size
"""

from typing import List, Optional, Set, Dict, Tuple


class TrieNode:
    """Node in the Trie."""

    def __init__(self):
        self.children: Dict[str, 'TrieNode'] = {}
        self.is_end: bool = False
        self.word: str = ""  # Store the word at end node (for reconstruction)


class Trie:
    """Trie for efficient word lookup."""

    def __init__(self):
        self.root = TrieNode()

    def insert(self, word: str) -> None:
        """Insert a word into the trie."""
        node = self.root
        for char in word:
            if char not in node.children:
                node.children[char] = TrieNode()
            node = node.children[char]
        node.is_end = True
        node.word = word


def word_break_trie(s: str, word_dict: List[str]) -> bool:
    """
    Check if string can be segmented using Trie + DP.

    Algorithm:
    1. Build Trie from dictionary
    2. dp[i] = True means s[0:i] can be segmented
    3. For each position i where dp[i]=True, use Trie to find words
    4. If word found ending at j, set dp[j+1] = True

    Dry Run for s = "leetcode", dict = ["leet", "code"]:

    Initial: dp = [T, F, F, F, F, F, F, F, F]
                   0  1  2  3  4  5  6  7  8

    i=0, dp[0]=True:
        Traverse Trie with "leetcode"
        l-e-e-t -> is_end=True! Word "leet" found
        dp[4] = True

    dp = [T, F, F, F, T, F, F, F, F]
                      ^

    i=4, dp[4]=True:
        Traverse Trie with "code"
        c-o-d-e -> is_end=True! Word "code" found
        dp[8] = True

    dp = [T, F, F, F, T, F, F, F, T]
                                  ^
    Return dp[8] = True
    """
    if not s:
        return True
    if not word_dict:
        return False

    # Build Trie
    trie = Trie()
    for word in word_dict:
        trie.insert(word)

    n = len(s)
    dp = [False] * (n + 1)
    dp[0] = True  # Empty string can be segmented

    for i in range(n):
        if not dp[i]:
            continue  # Can't start from invalid position

        # Use Trie to find all words starting at position i
        node = trie.root
        for j in range(i, n):
            char = s[j]

            if char not in node.children:
                break  # No words with this prefix - early termination!

            node = node.children[char]

            if node.is_end:
                # Found a word from position i to j
                dp[j + 1] = True

    return dp[n]


def word_break_with_segmentation(s: str, word_dict: List[str]) -> Tuple[bool, List[str]]:
    """
    Return whether string can be segmented AND the segmentation itself.

    Returns:
        Tuple of (can_segment, list_of_words)
    """
    if not s:
        return True, []
    if not word_dict:
        return False, []

    trie = Trie()
    for word in word_dict:
        trie.insert(word)

    n = len(s)
    dp = [False] * (n + 1)
    dp[0] = True
    parent = [-1] * (n + 1)  # Track where each segment starts

    for i in range(n):
        if not dp[i]:
            continue

        node = trie.root
        for j in range(i, n):
            char = s[j]

            if char not in node.children:
                break

            node = node.children[char]

            if node.is_end:
                dp[j + 1] = True
                parent[j + 1] = i  # Remember the split point

    if not dp[n]:
        return False, []

    # Reconstruct the segmentation
    words = []
    idx = n
    while idx > 0:
        start = parent[idx]
        words.append(s[start:idx])
        idx = start

    words.reverse()
    return True, words


def word_break_all_segmentations(s: str, word_dict: List[str]) -> List[List[str]]:
    """
    Find ALL possible segmentations (not just one).

    Example:
        s = "catsanddog"
        dict = ["cat", "cats", "and", "sand", "dog"]
        Output: [["cat", "sand", "dog"], ["cats", "and", "dog"]]
    """
    if not s:
        return [[]]
    if not word_dict:
        return []

    trie = Trie()
    for word in word_dict:
        trie.insert(word)

    memo: Dict[int, List[List[str]]] = {}

    def backtrack(start: int) -> List[List[str]]:
        if start == len(s):
            return [[]]

        if start in memo:
            return memo[start]

        results = []
        node = trie.root

        for end in range(start, len(s)):
            char = s[end]

            if char not in node.children:
                break

            node = node.children[char]

            if node.is_end:
                word = s[start:end + 1]
                # Recursively get all segmentations for the rest
                for rest in backtrack(end + 1):
                    results.append([word] + rest)

        memo[start] = results
        return results

    return backtrack(0)


# ============================================================
# Alternative: HashSet approach (for comparison)
# ============================================================

def word_break_hashset(s: str, word_dict: List[str]) -> bool:
    """
    Word break using HashSet (simpler but less efficient for prefix checking).

    Time: O(n^2 * m) where m is max word length (for substring hashing)
    """
    word_set = set(word_dict)
    n = len(s)
    dp = [False] * (n + 1)
    dp[0] = True

    for i in range(1, n + 1):
        for j in range(i):
            if dp[j] and s[j:i] in word_set:
                dp[i] = True
                break

    return dp[n]


# ============================================================
# Visualization Helper
# ============================================================

def visualize_word_break(s: str, word_dict: List[str]) -> None:
    """
    Print step-by-step visualization of the algorithm.
    """
    print(f"\nWord Break Visualization")
    print(f"String: \"{s}\"")
    print(f"Dictionary: {word_dict}")
    print("=" * 50)

    trie = Trie()
    for word in word_dict:
        trie.insert(word)

    n = len(s)
    dp = [False] * (n + 1)
    dp[0] = True

    print(f"\nInitial DP: {['T' if x else 'F' for x in dp]}")
    print(f"Indices:    {list(range(n + 1))}")

    for i in range(n):
        if not dp[i]:
            continue

        print(f"\n--- Position {i} (dp[{i}] = True) ---")
        print(f"Checking words starting at index {i}...")

        node = trie.root
        for j in range(i, n):
            char = s[j]
            prefix = s[i:j + 1]

            if char not in node.children:
                print(f"  '{prefix}' - No match possible (early termination)")
                break

            node = node.children[char]

            if node.is_end:
                dp[j + 1] = True
                print(f"  '{prefix}' - WORD FOUND! Setting dp[{j + 1}] = True")
            else:
                print(f"  '{prefix}' - Not a complete word, continuing...")

    print(f"\nFinal DP: {['T' if x else 'F' for x in dp]}")
    print(f"Indices:  {list(range(n + 1))}")

    result = "CAN" if dp[n] else "CANNOT"
    print(f"\nResult: String {result} be segmented!")

    if dp[n]:
        _, words = word_break_with_segmentation(s, word_dict)
        print(f"Segmentation: {' + '.join(words)}")


# ============================================================
# Test Cases
# ============================================================

def test_word_break():
    """Test word break implementations."""

    print("=" * 60)
    print("TEST: Word Break Problem")
    print("=" * 60)

    # Test 1: Basic case
    print("\nTest 1: Basic case")
    s1 = "leetcode"
    dict1 = ["leet", "code"]
    result1 = word_break_trie(s1, dict1)
    print(f"  s = '{s1}', dict = {dict1}")
    print(f"  Result: {result1}")
    assert result1 == True
    print("  PASSED")

    # Test 2: Multiple words used
    print("\nTest 2: Multiple words used")
    s2 = "applepenapple"
    dict2 = ["apple", "pen"]
    result2 = word_break_trie(s2, dict2)
    can, words = word_break_with_segmentation(s2, dict2)
    print(f"  s = '{s2}', dict = {dict2}")
    print(f"  Result: {result2}, Segmentation: {words}")
    assert result2 == True
    print("  PASSED")

    # Test 3: Cannot segment
    print("\nTest 3: Cannot segment")
    s3 = "catsandog"
    dict3 = ["cats", "dog", "sand", "and", "cat"]
    result3 = word_break_trie(s3, dict3)
    print(f"  s = '{s3}', dict = {dict3}")
    print(f"  Result: {result3}")
    assert result3 == False
    print("  PASSED")

    # Test 4: All segmentations
    print("\nTest 4: All segmentations")
    s4 = "catsanddog"
    dict4 = ["cat", "cats", "and", "sand", "dog"]
    all_segs = word_break_all_segmentations(s4, dict4)
    print(f"  s = '{s4}', dict = {dict4}")
    print(f"  All segmentations: {all_segs}")
    print("  PASSED")

    # Test 5: Empty string
    print("\nTest 5: Empty string")
    result5 = word_break_trie("", ["word"])
    print(f"  s = '', dict = ['word']")
    print(f"  Result: {result5}")
    assert result5 == True
    print("  PASSED")

    # Test 6: Single character
    print("\nTest 6: Single character")
    s6 = "a"
    dict6 = ["a"]
    result6 = word_break_trie(s6, dict6)
    print(f"  s = '{s6}', dict = {dict6}")
    print(f"  Result: {result6}")
    assert result6 == True
    print("  PASSED")


def demonstrate_step_by_step():
    """Show detailed step-by-step execution."""

    print("\n" + "=" * 60)
    print("STEP-BY-STEP DEMONSTRATION")
    print("=" * 60)

    # Example 1
    visualize_word_break("leetcode", ["leet", "code"])

    # Example 2
    visualize_word_break("applepenapple", ["apple", "pen"])

    # Example 3 (failure case)
    visualize_word_break("catsandog", ["cats", "dog", "sand", "and", "cat"])


if __name__ == "__main__":
    test_word_break()
    demonstrate_step_by_step()
