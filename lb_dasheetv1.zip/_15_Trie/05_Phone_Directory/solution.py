"""
Problem: Implement a Phone Directory
====================================

Design a phone directory that supports:
1. add(name) - Add a contact
2. search(prefix) - Return all contacts starting with prefix (autocomplete)

Example:
    directory.add("alice")
    directory.add("alex")
    directory.add("bob")

    directory.search("al")  # Returns ["alex", "alice"]
    directory.search("b")   # Returns ["bob"]

Approach:
    Use Trie for efficient prefix-based search.
    - Insert: O(m) where m = name length
    - Search: O(p + k*m) where p = prefix length, k = matches

"""

from typing import List, Dict, Optional, Tuple


class TrieNode:
    """A node in the Phone Directory Trie."""

    def __init__(self):
        self.children: Dict[str, 'TrieNode'] = {}
        self.is_end: bool = False
        self.frequency: int = 0  # For ranked suggestions


class PhoneDirectory:
    """
    Phone Directory implementation using Trie.

    Supports:
    - Adding contacts
    - Searching by prefix (autocomplete)
    - Real-time suggestions as user types
    - Deleting contacts
    """

    def __init__(self):
        self.root = TrieNode()
        self.contacts: List[str] = []

    def add(self, name: str) -> None:
        """
        Add a contact to the directory.

        Time: O(m) where m = len(name)

        Visualization for add("alice"):

        Initial:    After:
        root        root
                     |
                     a
                     |
                     l
                     |
                     i
                     |
                     c
                     |
                     e* (is_end=True)
        """
        name = name.lower()
        if name in self.contacts:
            return

        node = self.root
        for char in name:
            if char not in node.children:
                node.children[char] = TrieNode()
            node = node.children[char]

        node.is_end = True
        self.contacts.append(name)

    def search(self, prefix: str) -> List[str]:
        """
        Find all contacts that start with the given prefix.

        Time: O(p + k*m) where p = prefix length, k = matches, m = avg name length

        Dry Run for search("al") with contacts ["alice", "alex", "bob"]:

        Step 1: Navigate to prefix node
            root -> a -> l (found!)

        Step 2: DFS from 'l' node
            l -> i -> c -> e* (found "alice")
            l -> e -> x* (found "alex")

        Result: ["alex", "alice"] (sorted)
        """
        prefix = prefix.lower()
        node = self.root

        # Navigate to prefix node
        for char in prefix:
            if char not in node.children:
                return []  # Prefix doesn't exist
            node = node.children[char]

        # Collect all words from this node
        results = []
        self._collect_words(node, prefix, results)
        return sorted(results)

    def _collect_words(self, node: TrieNode, prefix: str, results: List[str]) -> None:
        """DFS to collect all words from a node."""
        if node.is_end:
            results.append(prefix)

        for char in sorted(node.children.keys()):
            self._collect_words(node.children[char], prefix + char, results)

    def search_with_path(self, prefix: str) -> Tuple[List[str], List[str]]:
        """
        Search and return the traversal path (for visualization).

        Returns:
            Tuple of (suggestions, path_characters)
        """
        prefix = prefix.lower()
        node = self.root
        path = ['root']

        for char in prefix:
            if char not in node.children:
                return [], path
            node = node.children[char]
            path.append(char)

        results = []
        self._collect_words(node, prefix, results)
        return sorted(results), path

    def autocomplete(self, prefix: str, limit: int = 10) -> List[str]:
        """
        Get autocomplete suggestions with a limit.

        Args:
            prefix: The prefix to search for
            limit: Maximum number of suggestions

        Returns:
            Up to 'limit' suggestions sorted alphabetically
        """
        suggestions = self.search(prefix)
        return suggestions[:limit]

    def suggestions_as_typed(self, text: str) -> List[Tuple[str, List[str]]]:
        """
        Get suggestions at each character typed.

        Example:
            text = "ali"
            Returns:
            [
                ("a", ["alex", "alice", "alicia"]),
                ("al", ["alex", "alice", "alicia"]),
                ("ali", ["alice", "alicia"])
            ]
        """
        results = []
        current = ""

        for char in text:
            current += char
            suggestions = self.search(current)
            results.append((current, suggestions))

        return results

    def delete(self, name: str) -> bool:
        """
        Delete a contact from the directory.

        Time: O(m) where m = len(name)
        """
        name = name.lower()
        if name not in self.contacts:
            return False

        self.contacts.remove(name)
        self._delete_helper(self.root, name, 0)
        return True

    def _delete_helper(self, node: TrieNode, name: str, depth: int) -> bool:
        """Recursive helper for deletion."""
        if depth == len(name):
            node.is_end = False
            return len(node.children) == 0

        char = name[depth]
        if char not in node.children:
            return False

        should_delete = self._delete_helper(node.children[char], name, depth + 1)

        if should_delete:
            del node.children[char]
            return len(node.children) == 0 and not node.is_end

        return False

    def get_all_contacts(self) -> List[str]:
        """Get all contacts in sorted order."""
        return sorted(self.contacts)


class RankedPhoneDirectory(PhoneDirectory):
    """
    Extended phone directory with frequency-based ranking.
    More frequently searched contacts appear first.
    """

    def __init__(self):
        super().__init__()
        self.search_counts: Dict[str, int] = {}

    def search(self, prefix: str) -> List[str]:
        """Search and track frequency for ranking."""
        suggestions = super().search(prefix)

        # Track search counts for ranking
        for suggestion in suggestions:
            self.search_counts[suggestion] = self.search_counts.get(suggestion, 0) + 1

        return suggestions

    def search_ranked(self, prefix: str) -> List[str]:
        """Return suggestions ranked by search frequency."""
        suggestions = super().search(prefix)

        # Sort by frequency (descending), then alphabetically
        return sorted(suggestions,
                     key=lambda x: (-self.search_counts.get(x, 0), x))


# ============================================================
# Visualization Helper
# ============================================================

def visualize_trie(directory: PhoneDirectory) -> str:
    """Create text visualization of the Trie."""
    lines = ["Phone Directory Trie:", "root"]

    def build_viz(node: TrieNode, indent: str):
        children = sorted(node.children.items())
        for i, (char, child) in enumerate(children):
            is_last = i == len(children) - 1
            connector = "\\-- " if is_last else "|-- "
            next_indent = indent + ("    " if is_last else "|   ")

            end_marker = "*" if child.is_end else ""
            lines.append(f"{indent}{connector}{char}{end_marker}")
            build_viz(child, next_indent)

    build_viz(directory.root, "")
    return '\n'.join(lines)


# ============================================================
# Test Cases
# ============================================================

def test_phone_directory():
    """Test phone directory operations."""

    print("=" * 60)
    print("TEST: Phone Directory")
    print("=" * 60)

    directory = PhoneDirectory()

    # Test 1: Add contacts
    print("\nTest 1: Adding contacts")
    contacts = ["alice", "alex", "alicia", "bob", "bobby", "carol"]
    for contact in contacts:
        directory.add(contact)
        print(f"  Added: {contact}")

    print(f"\n  All contacts: {directory.get_all_contacts()}")

    # Test 2: Basic search
    print("\nTest 2: Basic search")
    print(f"  search('al'): {directory.search('al')}")
    print(f"  search('b'): {directory.search('b')}")
    print(f"  search('c'): {directory.search('c')}")
    print(f"  search('xyz'): {directory.search('xyz')}")

    # Test 3: Autocomplete with limit
    print("\nTest 3: Autocomplete with limit")
    print(f"  autocomplete('a', limit=2): {directory.autocomplete('a', 2)}")

    # Test 4: Real-time suggestions
    print("\nTest 4: Suggestions as typed")
    for prefix, suggestions in directory.suggestions_as_typed("ali"):
        print(f"  After '{prefix}': {suggestions}")

    # Test 5: Delete
    print("\nTest 5: Delete contact")
    print(f"  Before delete: search('al') = {directory.search('al')}")
    directory.delete("alice")
    print(f"  After delete 'alice': search('al') = {directory.search('al')}")

    # Test 6: Search with path
    print("\nTest 6: Search with path (for visualization)")
    suggestions, path = directory.search_with_path("al")
    print(f"  Prefix: 'al'")
    print(f"  Path: {' -> '.join(path)}")
    print(f"  Suggestions: {suggestions}")


def demonstrate_autocomplete():
    """Interactive-style demonstration of autocomplete."""

    print("\n" + "=" * 60)
    print("DEMONSTRATION: Autocomplete Feature")
    print("=" * 60)

    directory = PhoneDirectory()

    # Add contacts
    contacts = ["alice", "alex", "alicia", "amanda", "bob"]
    for c in contacts:
        directory.add(c)

    print(f"\nContacts: {contacts}")
    print("\n--- Simulating user typing 'ali' ---")

    user_input = "ali"
    for i in range(1, len(user_input) + 1):
        prefix = user_input[:i]
        suggestions, path = directory.search_with_path(prefix)

        print(f"\nUser types: '{prefix}'")
        print(f"  Trie path: {' -> '.join(path)}")
        print(f"  Suggestions: {suggestions}")

    print("\n" + visualize_trie(directory))


def demonstrate_ranked_search():
    """Demonstrate frequency-based ranking."""

    print("\n" + "=" * 60)
    print("DEMONSTRATION: Ranked Search")
    print("=" * 60)

    directory = RankedPhoneDirectory()

    contacts = ["alice", "alex", "alicia"]
    for c in contacts:
        directory.add(c)

    print(f"\nContacts: {contacts}")

    # Simulate searching
    print("\nSimulating searches:")
    for _ in range(5):
        directory.search("alice")  # Search alice 5 times
    for _ in range(2):
        directory.search("alex")   # Search alex 2 times

    print(f"  Searched 'alice' 5 times")
    print(f"  Searched 'alex' 2 times")

    print(f"\nRegular search('al'): {directory.search('al')}")
    print(f"Ranked search('al'): {directory.search_ranked('al')}")
    print("  (alice appears first due to higher search frequency)")


if __name__ == "__main__":
    test_phone_directory()
    demonstrate_autocomplete()
    demonstrate_ranked_search()
