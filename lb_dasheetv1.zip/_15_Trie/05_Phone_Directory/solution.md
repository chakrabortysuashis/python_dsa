# Implement a Phone Directory

## Problem Statement

Design a phone directory that supports the following operations:

1. **add(name)**: Add a contact name to the directory
2. **search(prefix)**: Return all contacts that start with the given prefix

The search should display suggestions after each character typed (autocomplete feature).

**Example:**
```
Directory: ["alice", "alex", "bob", "alicia"]

User types: "a"
Suggestions: ["alex", "alice", "alicia"]

User types: "al"
Suggestions: ["alex", "alice", "alicia"]

User types: "ali"
Suggestions: ["alice", "alicia"]

User types: "alic"
Suggestions: ["alice", "alicia"]

User types: "alice"
Suggestions: ["alice"]
```

---

## Why Trie is Perfect Here

### Comparison with Other Approaches

| Approach | Add | Search for prefix | Get all matches |
|----------|-----|-------------------|-----------------|
| List + Linear Search | O(1) | O(n * m) | O(n * m) |
| Sorted List + Binary | O(n) | O(log n + k) | O(k * m) |
| HashMap | O(1) | O(n * m) | O(n * m) |
| **Trie** | O(m) | **O(p)** | O(p + k * m) |

Where n = contacts, m = avg name length, p = prefix length, k = matches

**Trie Wins Because:**
1. **Prefix search is native** - just traverse the prefix path
2. **Autocomplete is efficient** - collect all words below a node
3. **Dynamic updates** - add/remove contacts easily

---

## Trie Construction for Phone Directory

### Building Trie with ["alice", "alex", "alicia", "bob"]

```
               root
              /    \
             a      b
             |      |
             l      o
             |      |
             e----- b*
            / \
           x*  i (alex, alice branch)
               |
               c
               |
               e*----i
                     |
                     a*

Legend:
* = end of name (valid contact)

Structure:
- "alex": root -> a -> l -> e -> x*
- "alice": root -> a -> l -> i -> c -> e*
- "alicia": root -> a -> l -> i -> c -> i -> a*
- "bob": root -> b -> o -> b*
```

---

## Search/Autocomplete Visualization

### User types "ali" - Find all suggestions

```
Step 1: Navigate to prefix node

root
 |
 a    <- 'a' found
 |
 l    <- 'l' found
 |
 e----i    <- 'i' found! Current node = 'i'
      |
      c
      |
      e*---i
           |
           a*

Step 2: DFS from 'i' node to collect all names

DFS from 'i':
  -> 'c'
     -> 'e' (is_end=True) => "alice"
     -> 'i'
        -> 'a' (is_end=True) => "alicia"

Suggestions: ["alice", "alicia"]
```

---

## Character-by-Character Dry Run

### Autocomplete for "ali" in directory ["alice", "alex", "alicia"]

**Initial Trie:**
```
        root
         |
         a
         |
         l
        / \
       e   i
       |   |
       x*  c
           |
           e*--i
               |
               a*
```

**Step 1: Process 'a'**
```
Current: root.children['a'] = 'a' node
Status: 'a' exists, continue
Suggestions at 'a': DFS finds ["alex", "alice", "alicia"]
```

**Step 2: Process 'l'**
```
Current: 'a'.children['l'] = 'l' node
Status: 'l' exists, continue
Suggestions at 'l': DFS finds ["alex", "alice", "alicia"]
```

**Step 3: Process 'i'**
```
Current: 'l'.children['i'] = 'i' node
Status: 'i' exists, continue
Suggestions at 'i': DFS finds ["alice", "alicia"]
                    (not "alex" - different branch!)
```

**Result:** ["alice", "alicia"]

---

## Handling Edge Cases

### Case 1: Prefix doesn't exist
```
Search "xyz" in ["alice", "bob"]

Step 1: root.children['x'] = None
Result: No suggestions (empty list)
```

### Case 2: Prefix is a complete name
```
Search "bob" in ["bob", "bobby"]

Trie:
root -> b -> o -> b* -> b -> y*

Navigate to b-o-b:
- "bob" is_end = True (bob exists)
- Continue DFS: finds "bobby"

Result: ["bob", "bobby"]
```

### Case 3: Empty prefix
```
Search "" in ["alice", "bob"]

Stay at root, DFS from root
Result: ["alice", "bob"] (all contacts)
```

---

## Real-time Suggestions

For each character typed, show suggestions:

```
User input: "a" "l" "i" "c" "e"

After 'a':    ["alex", "alice", "alicia"]
After 'al':   ["alex", "alice", "alicia"]
After 'ali':  ["alice", "alicia"]
After 'alic': ["alice", "alicia"]
After 'alice': ["alice"]

Implementation:
def get_suggestions_as_typed(prefix):
    suggestions_at_each_step = []
    current_prefix = ""
    
    for char in prefix:
        current_prefix += char
        suggestions = trie.search(current_prefix)
        suggestions_at_each_step.append(suggestions)
    
    return suggestions_at_each_step
```

---

## Time and Space Complexity

### Time Complexity

| Operation | Complexity | Explanation |
|-----------|------------|-------------|
| add(name) | O(m) | Traverse m characters |
| search(prefix) | O(p + k*m) | p=prefix length, k=matches, m=avg name length |
| delete(name) | O(m) | Traverse and potentially remove nodes |

### Space Complexity
- **Trie Storage:** O(ALPHABET_SIZE * total_chars)
- For phone directory with names: O(26 * sum of all name lengths)
- Shared prefixes reduce actual space usage

---

## Advanced Features

### 1. Ranked Suggestions (by frequency)

```python
class TrieNode:
    def __init__(self):
        self.children = {}
        self.is_end = False
        self.frequency = 0  # Track usage frequency

def search_ranked(prefix):
    """Return suggestions sorted by frequency."""
    suggestions = get_all_words_from_prefix(prefix)
    return sorted(suggestions, key=lambda x: -x.frequency)
```

### 2. Fuzzy Search (allowing typos)

```python
def fuzzy_search(word, max_edits=1):
    """Find contacts within edit distance."""
    results = []
    
    def dfs(node, remaining, current_word, edits):
        if edits > max_edits:
            return
        
        if not remaining and node.is_end:
            results.append(current_word)
            return
        
        # Try exact match
        if remaining and remaining[0] in node.children:
            dfs(node.children[remaining[0]], remaining[1:],
                current_word + remaining[0], edits)
        
        # Try substitution, insertion, deletion
        for char in node.children:
            if remaining and char != remaining[0]:
                dfs(node.children[char], remaining[1:],
                    current_word + char, edits + 1)
    
    dfs(root, word, "", 0)
    return results
```

### 3. T9/Predictive Text (phone keypad)

```
Keypad mapping:
2: abc, 3: def, 4: ghi, 5: jkl, 6: mno, 7: pqrs, 8: tuv, 9: wxyz

User presses: 2-5-4-2-3 (alice)

Build Trie with number sequences:
"alice" -> "25423"
"bob" -> "262"

Search by number sequence!
```

---

## Comparison: Trie vs Database

| Feature | Trie | Database (B-tree) |
|---------|------|-------------------|
| Prefix search | Excellent | Good (LIKE 'prefix%') |
| Fuzzy search | Manual impl | Built-in |
| Memory | In-memory | Disk-based |
| Persistence | Manual | Built-in |
| Scalability | Limited by RAM | Can handle TB |

**Use Trie when:**
- Dataset fits in memory
- Need very fast prefix operations
- Building autocomplete feature
- Real-time suggestions needed

**Use Database when:**
- Large dataset (millions of contacts)
- Need persistence
- Complex queries needed
- Multiple applications access data
