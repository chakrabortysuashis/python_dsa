"""
Problem: Construct a Trie from Scratch
======================================

Implement a Trie (Prefix Tree) data structure with the following operations:
1. insert(word) - Insert a word into the trie
2. search(word) - Return True if word exists in trie
3. startsWith(prefix) - Return True if any word starts with prefix

Time Complexity: O(m) for all operations where m = word length
Space Complexity: O(ALPHABET_SIZE * m * n) where n = number of words
"""

from typing import List, Optional


class TrieNode:
    """
    A single node in the Trie.

    Attributes:
        children: Dictionary mapping characters to child TrieNodes
        is_end_of_word: Boolean flag indicating if this node marks end of a word
    """

    def __init__(self):
        self.children = {}  # char -> TrieNode
        self.is_end_of_word = False


class Trie:
    """
    Trie (Prefix Tree) implementation.

    A Trie is a tree-like data structure for efficient string operations.
    Each path from root to a marked node represents a word.

    Example:
        trie = Trie()
        trie.insert("apple")
        trie.insert("app")
        trie.search("apple")      # True
        trie.search("app")        # True
        trie.search("ap")         # False (not complete word)
        trie.startsWith("app")    # True
    """

    def __init__(self):
        """Initialize the Trie with an empty root node."""
        self.root = TrieNode()

    def insert(self, word: str) -> None:
        """
        Insert a word into the Trie.

        Algorithm:
        1. Start at root
        2. For each character:
           - If child doesn't exist, create new node
           - Move to child node
        3. Mark final node as end of word

        Time: O(m) where m = len(word)
        Space: O(m) in worst case (no shared prefix)

        Visualization for insert("cat"):

        Step 1: Start at root
            root

        Step 2: Insert 'c' (create new node)
            root
             |
             c

        Step 3: Insert 'a' (create new node)
            root
             |
             c
             |
             a

        Step 4: Insert 't' and mark as end
            root
             |
             c
             |
             a
             |
             t*  (* = is_end_of_word = True)
        """
        node = self.root

        for char in word:
            # Create child node if it doesn't exist
            if char not in node.children:
                node.children[char] = TrieNode()

            # Move to child node
            node = node.children[char]

        # Mark the end of the word
        node.is_end_of_word = True

    def search(self, word: str) -> bool:
        """
        Search for a complete word in the Trie.

        Returns True only if:
        1. All characters in word exist as a path from root
        2. The final node is marked as end of word

        Time: O(m) where m = len(word)

        Dry Run - search("cat") in Trie with ["cat"]:

            root           Start at root
             |
             c    ------>  char='c', found in children, move down
             |
             a    ------>  char='a', found in children, move down
             |
             t*   ------>  char='t', found in children, move down
                           End of word? Yes! Return True

        Dry Run - search("ca") in Trie with ["cat"]:

            root           Start at root
             |
             c    ------>  char='c', found, move down
             |
             a    ------>  char='a', found, move down
             |
             t*            End of "ca" - but is_end_of_word = False!
                           Return False (prefix exists but not complete word)
        """
        node = self.root

        for char in word:
            # Character not found - word doesn't exist
            if char not in node.children:
                return False

            # Move to child node
            node = node.children[char]

        # Only return True if we're at end of a complete word
        return node.is_end_of_word

    def startsWith(self, prefix: str) -> bool:
        """
        Check if any word in the Trie starts with the given prefix.

        Unlike search(), we don't need to check is_end_of_word.
        We only need to verify that the path exists.

        Time: O(m) where m = len(prefix)

        Dry Run - startsWith("ca") in Trie with ["cat", "car"]:

            root           Start at root
             |
             c    ------>  char='c', found, move down
             |
             a    ------>  char='a', found, move down
            / \
           t*  r*          Reached end of prefix - path exists!
                           Return True

        Dry Run - startsWith("cb") in Trie with ["cat"]:

            root           Start at root
             |
             c    ------>  char='c', found, move down
             |
             a             char='b', NOT found in children!
             |             Return False
             t*
        """
        node = self.root

        for char in prefix:
            # Character not found - prefix doesn't exist
            if char not in node.children:
                return False

            # Move to child node
            node = node.children[char]

        # Path exists - prefix is valid (don't check is_end_of_word!)
        return True


# ============================================================
# Alternative Implementation: Array-based children
# ============================================================

class TrieNodeArray:
    """TrieNode using fixed-size array for lowercase letters only."""

    def __init__(self):
        # Fixed array of size 26 for 'a' to 'z'
        self.children = [None] * 26
        self.is_end_of_word = False

    def _char_to_index(self, char: str) -> int:
        """Convert character to array index (a=0, b=1, ..., z=25)."""
        return ord(char) - ord('a')

    def get_child(self, char: str) -> Optional['TrieNodeArray']:
        """Get child node for character."""
        return self.children[self._char_to_index(char)]

    def set_child(self, char: str, node: 'TrieNodeArray') -> None:
        """Set child node for character."""
        self.children[self._char_to_index(char)] = node


class TrieArray:
    """Trie implementation using array-based nodes (faster but fixed alphabet)."""

    def __init__(self):
        self.root = TrieNodeArray()

    def insert(self, word: str) -> None:
        """Insert word into trie."""
        node = self.root

        for char in word.lower():
            if node.get_child(char) is None:
                node.set_child(char, TrieNodeArray())
            node = node.get_child(char)

        node.is_end_of_word = True

    def search(self, word: str) -> bool:
        """Search for complete word."""
        node = self.root

        for char in word.lower():
            child = node.get_child(char)
            if child is None:
                return False
            node = child

        return node.is_end_of_word

    def startsWith(self, prefix: str) -> bool:
        """Check if prefix exists."""
        node = self.root

        for char in prefix.lower():
            child = node.get_child(char)
            if child is None:
                return False
            node = child

        return True


# ============================================================
# Extended Trie with additional operations
# ============================================================

class ExtendedTrie:
    """Extended Trie with additional utility methods."""

    def __init__(self):
        self.root = TrieNode()
        self.word_count = 0

    def insert(self, word: str) -> None:
        """Insert word into trie."""
        node = self.root

        for char in word:
            if char not in node.children:
                node.children[char] = TrieNode()
            node = node.children[char]

        if not node.is_end_of_word:
            node.is_end_of_word = True
            self.word_count += 1

    def search(self, word: str) -> bool:
        """Search for complete word."""
        node = self._find_node(word)
        return node is not None and node.is_end_of_word

    def startsWith(self, prefix: str) -> bool:
        """Check if prefix exists."""
        return self._find_node(prefix) is not None

    def _find_node(self, prefix: str) -> Optional[TrieNode]:
        """Find node at end of prefix path."""
        node = self.root
        for char in prefix:
            if char not in node.children:
                return None
            node = node.children[char]
        return node

    def get_all_words(self) -> List[str]:
        """Get all words stored in the trie."""
        words = []
        self._collect_words(self.root, "", words)
        return words

    def _collect_words(self, node: TrieNode, prefix: str, words: List[str]) -> None:
        """Recursively collect all words."""
        if node.is_end_of_word:
            words.append(prefix)

        for char, child in sorted(node.children.items()):
            self._collect_words(child, prefix + char, words)

    def get_words_with_prefix(self, prefix: str) -> List[str]:
        """Get all words that start with the given prefix."""
        node = self._find_node(prefix)
        if node is None:
            return []

        words = []
        self._collect_words(node, prefix, words)
        return words

    def delete(self, word: str) -> bool:
        """Delete a word from the trie. Returns True if word was deleted."""
        if not self.search(word):
            return False

        self._delete_helper(self.root, word, 0)
        self.word_count -= 1
        return True

    def _delete_helper(self, node: TrieNode, word: str, depth: int) -> bool:
        """Recursive helper for deletion. Returns True if node should be deleted."""
        if depth == len(word):
            node.is_end_of_word = False
            return len(node.children) == 0

        char = word[depth]
        child = node.children[char]

        should_delete = self._delete_helper(child, word, depth + 1)

        if should_delete:
            del node.children[char]
            return len(node.children) == 0 and not node.is_end_of_word

        return False


# ============================================================
# Test Cases
# ============================================================

def test_basic_trie():
    """Test basic Trie operations."""
    print("=" * 50)
    print("TEST: Basic Trie Operations")
    print("=" * 50)

    trie = Trie()

    # Test 1: Insert and search
    print("\nTest 1: Insert and Search")
    trie.insert("apple")
    print(f"  insert('apple')")
    print(f"  search('apple'): {trie.search('apple')}")  # True
    print(f"  search('app'): {trie.search('app')}")      # False
    print(f"  search('ap'): {trie.search('ap')}")        # False

    # Test 2: Prefix check
    print("\nTest 2: Prefix Check")
    print(f"  startsWith('app'): {trie.startsWith('app')}")   # True
    print(f"  startsWith('apple'): {trie.startsWith('apple')}")  # True
    print(f"  startsWith('appl'): {trie.startsWith('appl')}")    # True
    print(f"  startsWith('apl'): {trie.startsWith('apl')}")      # False

    # Test 3: Add more words
    print("\nTest 3: Add more words")
    trie.insert("app")
    print(f"  insert('app')")
    print(f"  search('app'): {trie.search('app')}")  # Now True

    # Test 4: Multiple words
    print("\nTest 4: Multiple words")
    words = ["cat", "car", "card", "care", "careful"]
    for word in words:
        trie.insert(word)
        print(f"  insert('{word}')")

    print(f"\n  search('car'): {trie.search('car')}")      # True
    print(f"  search('card'): {trie.search('card')}")      # True
    print(f"  search('care'): {trie.search('care')}")      # True
    print(f"  search('careful'): {trie.search('careful')}")  # True
    print(f"  search('ca'): {trie.search('ca')}")          # False
    print(f"  search('cars'): {trie.search('cars')}")      # False

    print(f"\n  startsWith('ca'): {trie.startsWith('ca')}")  # True
    print(f"  startsWith('car'): {trie.startsWith('car')}")  # True
    print(f"  startsWith('carz'): {trie.startsWith('carz')}")  # False


def test_extended_trie():
    """Test extended Trie operations."""
    print("\n" + "=" * 50)
    print("TEST: Extended Trie Operations")
    print("=" * 50)

    trie = ExtendedTrie()

    words = ["apple", "app", "application", "apply", "bat", "ball", "cat"]
    for word in words:
        trie.insert(word)

    print(f"\nInserted words: {words}")
    print(f"Word count: {trie.word_count}")

    # Get all words
    print(f"\nAll words in trie: {trie.get_all_words()}")

    # Get words with prefix
    print(f"\nWords starting with 'app': {trie.get_words_with_prefix('app')}")
    print(f"Words starting with 'ba': {trie.get_words_with_prefix('ba')}")
    print(f"Words starting with 'z': {trie.get_words_with_prefix('z')}")

    # Delete
    print(f"\nDeleting 'app':")
    print(f"  Before: search('app') = {trie.search('app')}")
    trie.delete('app')
    print(f"  After: search('app') = {trie.search('app')}")
    print(f"  search('apple') still = {trie.search('apple')}")


def test_array_trie():
    """Test array-based Trie."""
    print("\n" + "=" * 50)
    print("TEST: Array-based Trie")
    print("=" * 50)

    trie = TrieArray()

    words = ["hello", "help", "world"]
    for word in words:
        trie.insert(word)
        print(f"  insert('{word}')")

    print(f"\n  search('hello'): {trie.search('hello')}")  # True
    print(f"  search('help'): {trie.search('help')}")      # True
    print(f"  search('hel'): {trie.search('hel')}")        # False
    print(f"  startsWith('hel'): {trie.startsWith('hel')}")  # True


def demonstrate_dry_run():
    """
    Detailed dry run demonstrating character-by-character operations.
    """
    print("\n" + "=" * 50)
    print("DRY RUN: Character-by-character visualization")
    print("=" * 50)

    trie = Trie()

    # Insert "cat"
    print("\n--- INSERT 'cat' ---")
    word = "cat"
    node = trie.root
    print("Starting at root")

    for i, char in enumerate(word):
        if char not in node.children:
            print(f"  Step {i+1}: '{char}' not found, creating new node")
            node.children[char] = TrieNode()
        else:
            print(f"  Step {i+1}: '{char}' found, moving to child")
        node = node.children[char]

    node.is_end_of_word = True
    print(f"  Marked '{word[-1]}' as end of word")

    # Insert "car"
    print("\n--- INSERT 'car' ---")
    word = "car"
    node = trie.root
    print("Starting at root")

    for i, char in enumerate(word):
        if char not in node.children:
            print(f"  Step {i+1}: '{char}' not found, creating new node")
            node.children[char] = TrieNode()
        else:
            print(f"  Step {i+1}: '{char}' found (shared prefix), moving to child")
        node = node.children[char]

    node.is_end_of_word = True
    print(f"  Marked '{word[-1]}' as end of word")

    # Search "ca"
    print("\n--- SEARCH 'ca' ---")
    word = "ca"
    node = trie.root
    found = True

    for i, char in enumerate(word):
        if char not in node.children:
            print(f"  Step {i+1}: '{char}' NOT FOUND!")
            found = False
            break
        else:
            print(f"  Step {i+1}: '{char}' found, moving to child")
        node = node.children[char]

    if found:
        result = node.is_end_of_word
        print(f"  Reached end of '{word}', is_end_of_word = {result}")
        print(f"  Result: {'FOUND' if result else 'NOT FOUND (prefix only)'}")


if __name__ == "__main__":
    test_basic_trie()
    test_extended_trie()
    test_array_trie()
    demonstrate_dry_run()
