# Construct a Trie from Scratch

## Problem Statement

Implement a Trie (Prefix Tree) data structure that supports the following operations:

1. **insert(word)**: Insert a word into the trie
2. **search(word)**: Return true if the word exists in the trie
3. **startsWith(prefix)**: Return true if any word starts with the given prefix

**Example:**
```
Input operations:
insert("apple")
insert("app")
search("apple")   -> true
search("app")     -> true
search("ap")      -> false (not a complete word)
startsWith("app") -> true
startsWith("apl") -> false
```

---

## Why Trie is Useful Here

| Approach | Insert | Search | Prefix Check | Space |
|----------|--------|--------|--------------|-------|
| Array/List | O(1) | O(n*m) | O(n*m) | O(n*m) |
| HashSet | O(m) | O(m) | O(n*m) | O(n*m) |
| **Trie** | **O(m)** | **O(m)** | **O(m)** | O(ALPHABET*m*n) |

Where n = number of words, m = average word length

**Why Trie Wins:**
1. **O(m) for ALL operations** - independent of dictionary size
2. **Prefix operations are native** - no need to scan all words
3. **Shared prefixes save space** - words like "app", "apple", "application" share "app"

---

## Trie Construction Visualization

### Building Trie with words: ["cat", "car", "card"]

**Initial State:**
```
root (empty)
```

**After insert("cat"):**
```
       root
        |
        c (prefix_count=1)
        |
        a (prefix_count=1)
        |
        t* (is_end=True)
```

**After insert("car"):**
```
       root
        |
        c (prefix_count=2)
        |
        a (prefix_count=2)
       / \
      t*  r* (both is_end=True)
```

**After insert("card"):**
```
       root
        |
        c (prefix_count=3)
        |
        a (prefix_count=3)
       / \
      t*  r (prefix_count=2)
          |
          d* (is_end=True)

(* = end of word)
```

---

## Step-by-Step Insert Operation

### Insert "apple" into empty Trie

```
Algorithm:
1. Start at root
2. For each character:
   - If child doesn't exist, create it
   - Move to child
3. Mark final node as end of word
```

**Character-by-Character Dry Run:**

| Step | Char | Action | Current Node | Trie State |
|------|------|--------|--------------|------------|
| 0 | - | Start at root | root | root |
| 1 | 'a' | Create child 'a' | a | root->a |
| 2 | 'p' | Create child 'p' | p | root->a->p |
| 3 | 'p' | Create child 'p' | p | root->a->p->p |
| 4 | 'l' | Create child 'l' | l | root->a->p->p->l |
| 5 | 'e' | Create child 'e', mark end | e* | root->a->p->p->l->e* |

**Visual Progression:**
```
Step 1:     Step 2:     Step 3:     Step 4:     Step 5:
root        root        root        root        root
 |           |           |           |           |
 a           a           a           a           a
             |           |           |           |
             p           p           p           p
                         |           |           |
                         p           p           p
                                     |           |
                                     l           l
                                                 |
                                                 e*
```

---

## Step-by-Step Search Operation

### Search "app" in Trie containing ["apple"]

```
       root
        |
        a
        |
        p
        |
        p
        |
        l
        |
        e*
```

**Character-by-Character Dry Run:**

| Step | Char | Action | Found? | Current Node |
|------|------|--------|--------|--------------|
| 1 | 'a' | Look for child 'a' | Yes | a |
| 2 | 'p' | Look for child 'p' | Yes | p |
| 3 | 'p' | Look for child 'p' | Yes | p |
| 4 | - | Check is_end_of_word | **False** | - |

**Result:** `False` - "app" is a prefix but not a complete word

### Search "apple" in same Trie

| Step | Char | Action | Found? | Current Node |
|------|------|--------|--------|--------------|
| 1 | 'a' | Look for child 'a' | Yes | a |
| 2 | 'p' | Look for child 'p' | Yes | p |
| 3 | 'p' | Look for child 'p' | Yes | p |
| 4 | 'l' | Look for child 'l' | Yes | l |
| 5 | 'e' | Look for child 'e' | Yes | e |
| 6 | - | Check is_end_of_word | **True** | - |

**Result:** `True` - "apple" exists as a complete word

---

## Step-by-Step Prefix Search

### Check prefix "app" in Trie with ["apple", "application"]

```
       root
        |
        a
        |
        p
        |
        p -------- Prefix "app" ends here
       / \
      l   l
      |   |
      e*  i
          |
          c...
```

**Dry Run:**

| Step | Char | Action | Found? |
|------|------|--------|--------|
| 1 | 'a' | Look for child 'a' | Yes |
| 2 | 'p' | Look for child 'p' | Yes |
| 3 | 'p' | Look for child 'p' | Yes |
| 4 | - | Reached end of prefix | **Exists!** |

**Result:** `True` - The path exists (don't need to check is_end_of_word)

---

## Time and Space Complexity

### Time Complexity

| Operation | Time | Reason |
|-----------|------|--------|
| insert(word) | O(m) | Traverse m characters |
| search(word) | O(m) | Traverse m characters |
| startsWith(prefix) | O(m) | Traverse m characters |
| delete(word) | O(m) | Traverse m characters |

Where m = length of word/prefix

**Key Insight:** Operations are O(m), NOT O(n). Adding more words doesn't slow down searches!

### Space Complexity

**Worst Case:** O(ALPHABET_SIZE * m * n)
- ALPHABET_SIZE = 26 for lowercase English
- m = average word length
- n = number of words

**Best Case (many shared prefixes):** O(m * k)
- k = number of unique prefixes

**Example:**
```
Words: ["a", "ab", "abc", "abcd", "abcde"]
All share common prefix - very space efficient!

Storage: Only 5 nodes (one per unique character position)
```

---

## Edge Cases to Handle

1. **Empty string**: Handle gracefully (don't insert, return appropriate value)
2. **Duplicate words**: Decide whether to allow (use word_count)
3. **Case sensitivity**: Convert to lowercase if case-insensitive
4. **Non-alphabetic characters**: Extend children to handle or validate input
5. **Very long words**: May cause stack overflow with recursive approaches

---

## TrieNode Design Choices

### Dictionary-based (Flexible)
```python
class TrieNode:
    def __init__(self):
        self.children = {}  # char -> TrieNode
        self.is_end = False
```
- **Pros:** Space efficient for sparse tries, handles any character
- **Cons:** Slightly slower lookup than array

### Array-based (Fast)
```python
class TrieNode:
    def __init__(self):
        self.children = [None] * 26  # Index 0='a', 1='b', ...
        self.is_end = False
```
- **Pros:** Faster O(1) child access
- **Cons:** Wastes space if most children are empty

---

## Common Mistakes to Avoid

1. **Not marking is_end_of_word after insert**
   - Results in words not being found

2. **Checking is_end in startsWith**
   - startsWith should return True for any existing path

3. **Forgetting to handle empty input**
   - Check for empty string before processing

4. **Off-by-one in character indexing**
   - For array-based: `index = ord(char) - ord('a')`

---

## Practice Variations

1. **Count words with given prefix**
2. **Find all words with given prefix**
3. **Implement delete operation**
4. **Support wildcard '.' matching any character**
5. **Find longest word in trie**
6. **Find shortest unique prefix**
