"""
Maximum Size Rectangle in Binary Matrix
=======================================

Problem: Find largest rectangle containing only 1s in a binary matrix.

Approach: Convert to histogram problem for each row, use monotonic stack.
Time: O(m * n), Space: O(n)
"""

from typing import List


def largest_histogram(heights: List[int]) -> int:
    """
    Find largest rectangle area in histogram using monotonic stack.
    Time: O(n), Space: O(n)
    """
    stack = []  # Store indices
    max_area = 0
    heights = heights + [0]  # Add sentinel

    for i, h in enumerate(heights):
        while stack and heights[stack[-1]] > h:
            height = heights[stack.pop()]
            width = i if not stack else i - stack[-1] - 1
            max_area = max(max_area, height * width)
        stack.append(i)

    return max_area


def maximal_rectangle(matrix: List[List[int]]) -> int:
    """
    Find maximum rectangle of 1s in binary matrix.

    Algorithm:
    1. Build cumulative height array for each row
    2. For each row, find largest rectangle in histogram
    3. Track maximum across all rows

    Example:
        >>> maximal_rectangle([[1,0,1,0,0],[1,0,1,1,1],[1,1,1,1,1],[1,0,0,1,0]])
        6
    """
    if not matrix or not matrix[0]:
        return 0

    rows = len(matrix)
    cols = len(matrix[0])
    heights = [0] * cols
    max_area = 0

    for i in range(rows):
        # Update heights for current row
        for j in range(cols):
            if matrix[i][j] == 1:
                heights[j] += 1
            else:
                heights[j] = 0

        # Find max rectangle in current histogram
        area = largest_histogram(heights[:])
        max_area = max(max_area, area)

    return max_area


def maximal_rectangle_with_trace(matrix: List[List[int]]) -> int:
    """Educational version with trace."""
    if not matrix or not matrix[0]:
        return 0

    rows, cols = len(matrix), len(matrix[0])
    heights = [0] * cols
    max_area = 0

    print("Matrix to Histogram conversion:")
    for i in range(rows):
        for j in range(cols):
            heights[j] = heights[j] + 1 if matrix[i][j] == 1 else 0

        area = largest_histogram(heights[:])
        max_area = max(max_area, area)
        print(f"Row {i}: heights={heights}, histogram_area={area}, max_so_far={max_area}")

    return max_area


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 50)
    print("MAXIMUM RECTANGLE IN BINARY MATRIX")
    print("=" * 50)

    matrix = [
        [1, 0, 1, 0, 0],
        [1, 0, 1, 1, 1],
        [1, 1, 1, 1, 1],
        [1, 0, 0, 1, 0]
    ]

    print("\nMatrix:")
    for row in matrix:
        print(row)

    result = maximal_rectangle(matrix)
    print(f"\nMaximum rectangle area: {result}")
    assert result == 6, "Test Failed"
    print("PASSED!")

    # Detailed trace
    print("\n" + "-" * 40)
    print("DETAILED TRACE:")
    maximal_rectangle_with_trace(matrix)

    # More tests
    print("\n" + "-" * 40)
    print("Additional Tests:")

    # All 1s
    all_ones = [[1,1,1], [1,1,1]]
    print(f"All 1s (2x3): {maximal_rectangle(all_ones)}")
    assert maximal_rectangle(all_ones) == 6

    # Single element
    print(f"Single 1: {maximal_rectangle([[1]])}")
    print(f"Single 0: {maximal_rectangle([[0]])}")

    print("\nAll tests passed!")
