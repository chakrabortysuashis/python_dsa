# Maximum Size Rectangle in a Binary Matrix

## Problem Statement

Given a binary matrix (containing only 0s and 1s), find the largest rectangle containing only 1s and return its area.

### Example

```
Matrix:
[1, 0, 1, 0, 0]
[1, 0, 1, 1, 1]
[1, 1, 1, 1, 1]
[1, 0, 0, 1, 0]

Maximum Rectangle Area = 6 (rows 1-2, cols 2-4)
```

---

## Key Insight

This problem builds on **Largest Rectangle in Histogram**!

For each row, treat the accumulated heights as a histogram and find the largest rectangle in that histogram.

---

## Algorithm

1. **Build height array**: For each cell, calculate height of consecutive 1s above (including current)
2. **Apply histogram algorithm**: For each row, find largest rectangle in histogram
3. **Track maximum** across all rows

### Building Heights

```
Matrix:              Heights at each row:
[1, 0, 1, 0, 0]     Row 0: [1, 0, 1, 0, 0]
[1, 0, 1, 1, 1]     Row 1: [2, 0, 2, 1, 1]
[1, 1, 1, 1, 1]     Row 2: [3, 1, 3, 2, 2]
[1, 0, 0, 1, 0]     Row 3: [4, 0, 0, 3, 0]
```

For row 2, histogram [3,1,3,2,2] gives max area = 6.

---

## Largest Rectangle in Histogram (Using Stack)

For a histogram, use a monotonic stack:
- Stack stores indices of bars in increasing order
- When a shorter bar comes, pop and calculate areas

```python
def largest_histogram(heights):
    stack = []  # indices
    max_area = 0
    heights.append(0)  # Sentinel
    
    for i, h in enumerate(heights):
        while stack and heights[stack[-1]] > h:
            height = heights[stack.pop()]
            width = i if not stack else i - stack[-1] - 1
            max_area = max(max_area, height * width)
        stack.append(i)
    
    heights.pop()
    return max_area
```

---

## Complete Solution

```python
def maximal_rectangle(matrix):
    if not matrix or not matrix[0]:
        return 0
    
    rows, cols = len(matrix), len(matrix[0])
    heights = [0] * cols
    max_area = 0
    
    for i in range(rows):
        # Update heights
        for j in range(cols):
            heights[j] = heights[j] + 1 if matrix[i][j] == 1 else 0
        
        # Find max rectangle in histogram
        max_area = max(max_area, largest_histogram(heights[:]))
    
    return max_area
```

---

## Step-by-Step Dry Run

```
Row 0: heights = [1, 0, 1, 0, 0]
       Max histogram area = 1

Row 1: heights = [2, 0, 2, 1, 1]
       Max histogram area = 3 (width 3, height 1)

Row 2: heights = [3, 1, 3, 2, 2]
       Max histogram area = 6 (width 3, height 2 at cols 2-4)

Row 3: heights = [4, 0, 0, 3, 0]
       Max histogram area = 4 (single bar)

Overall Maximum = 6
```

---

## Complexity

- **Time**: O(m * n) - process each cell once, histogram takes O(n) per row
- **Space**: O(n) - heights array and stack

---

## Key Takeaways

1. **Reduce to known problem**: 2D rectangle -> 1D histogram
2. **Monotonic stack** efficiently finds nearest smaller elements
3. This pattern applies to: maximal square, maximal plus sign, etc.
