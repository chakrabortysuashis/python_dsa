"""
Spiral Traversal on a Matrix
============================

Problem: Given an m x n matrix, return all elements in spiral (clockwise) order.

Key Insight: Use boundary pointers (top, bottom, left, right) and traverse in
the pattern: RIGHT -> DOWN -> LEFT -> UP, shrinking boundaries after each pass.

Time Complexity: O(m * n) - visit each element once
Space Complexity: O(1) - only using pointers (excluding result array)
"""

from typing import List


def spiral_order_brute(matrix: List[List[int]]) -> List[int]:
    """
    Brute Force Approach: Use a visited matrix to track visited cells.

    Algorithm:
    1. Start at (0, 0), direction = right
    2. Move in current direction until boundary or visited cell
    3. Turn clockwise and continue
    4. Repeat until all cells visited

    Time Complexity: O(m * n)
    Space Complexity: O(m * n) - for visited matrix

    Args:
        matrix: Input 2D matrix

    Returns:
        List of elements in spiral order

    Example:
        >>> spiral_order_brute([[1,2,3], [4,5,6], [7,8,9]])
        [1, 2, 3, 6, 9, 8, 7, 4, 5]
    """
    if not matrix or not matrix[0]:
        return []

    rows, cols = len(matrix), len(matrix[0])
    visited = [[False] * cols for _ in range(rows)]

    # Direction vectors: right, down, left, up (clockwise order)
    directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]
    dir_names = ['RIGHT', 'DOWN', 'LEFT', 'UP']
    dir_idx = 0  # Start going right

    result = []
    i, j = 0, 0  # Starting position

    for _ in range(rows * cols):
        # Visit current cell
        result.append(matrix[i][j])
        visited[i][j] = True

        # Calculate next position in current direction
        di, dj = directions[dir_idx]
        ni, nj = i + di, j + dj

        # Check if we need to turn (boundary or already visited)
        if (ni < 0 or ni >= rows or nj < 0 or nj >= cols or visited[ni][nj]):
            # Turn clockwise
            dir_idx = (dir_idx + 1) % 4
            di, dj = directions[dir_idx]
            ni, nj = i + di, j + dj

        # Move to next position
        i, j = ni, nj

    return result


def spiral_order(matrix: List[List[int]]) -> List[int]:
    """
    Optimal Approach: Use boundary pointers to track the traversable region.

    Algorithm:
    1. Initialize boundaries: top=0, bottom=m-1, left=0, right=n-1
    2. While boundaries are valid (top <= bottom AND left <= right):
       a. Traverse RIGHT: top row from left to right, then top++
       b. Traverse DOWN: right column from top to bottom, then right--
       c. Traverse LEFT: bottom row from right to left (if top <= bottom), then bottom--
       d. Traverse UP: left column from bottom to top (if left <= right), then left++

    Key Insight: After each direction, shrink the corresponding boundary.
    The checks (top <= bottom) and (left <= right) prevent duplicate visits.

    Time Complexity: O(m * n) - visit each element exactly once
    Space Complexity: O(1) - only using four pointers

    Args:
        matrix: Input 2D matrix

    Returns:
        List of elements in spiral order

    Example:
        >>> spiral_order([[1,2,3,4], [5,6,7,8], [9,10,11,12]])
        [1, 2, 3, 4, 8, 12, 11, 10, 9, 5, 6, 7]
    """
    if not matrix or not matrix[0]:
        return []

    result = []

    # Initialize boundary pointers
    top = 0                    # Topmost row to traverse
    bottom = len(matrix) - 1   # Bottommost row to traverse
    left = 0                   # Leftmost column to traverse
    right = len(matrix[0]) - 1 # Rightmost column to traverse

    while top <= bottom and left <= right:
        # Step 1: Traverse RIGHT along the top row
        # Visit all columns from left to right in the top row
        for col in range(left, right + 1):
            result.append(matrix[top][col])
        top += 1  # Shrink top boundary (this row is done)

        # Step 2: Traverse DOWN along the right column
        # Visit all rows from top to bottom in the right column
        for row in range(top, bottom + 1):
            result.append(matrix[row][right])
        right -= 1  # Shrink right boundary (this column is done)

        # Step 3: Traverse LEFT along the bottom row
        # Only if there are still rows remaining (top <= bottom)
        if top <= bottom:
            for col in range(right, left - 1, -1):
                result.append(matrix[bottom][col])
            bottom -= 1  # Shrink bottom boundary

        # Step 4: Traverse UP along the left column
        # Only if there are still columns remaining (left <= right)
        if left <= right:
            for row in range(bottom, top - 1, -1):
                result.append(matrix[row][left])
            left += 1  # Shrink left boundary

    return result


def spiral_order_with_trace(matrix: List[List[int]]) -> List[int]:
    """
    Same as optimal approach but with detailed trace output for learning.

    This function prints each step of the algorithm for educational purposes.
    """
    if not matrix or not matrix[0]:
        return []

    result = []
    top, bottom = 0, len(matrix) - 1
    left, right = 0, len(matrix[0]) - 1
    layer = 1

    print("=" * 50)
    print("SPIRAL TRAVERSAL - STEP BY STEP")
    print("=" * 50)
    print(f"Matrix dimensions: {len(matrix)} x {len(matrix[0])}")
    print(f"Initial boundaries: top={top}, bottom={bottom}, left={left}, right={right}")
    print()

    while top <= bottom and left <= right:
        print(f"--- Layer {layer} ---")

        # RIGHT
        print(f"  RIGHT: row={top}, cols={left} to {right}")
        for col in range(left, right + 1):
            result.append(matrix[top][col])
            print(f"    Visit ({top},{col}) = {matrix[top][col]}")
        top += 1
        print(f"    top++ -> {top}")

        # DOWN
        if top <= bottom:
            print(f"  DOWN: col={right}, rows={top} to {bottom}")
            for row in range(top, bottom + 1):
                result.append(matrix[row][right])
                print(f"    Visit ({row},{right}) = {matrix[row][right]}")
        right -= 1
        print(f"    right-- -> {right}")

        # LEFT
        if top <= bottom and left <= right:
            print(f"  LEFT: row={bottom}, cols={right} to {left}")
            for col in range(right, left - 1, -1):
                result.append(matrix[bottom][col])
                print(f"    Visit ({bottom},{col}) = {matrix[bottom][col]}")
            bottom -= 1
            print(f"    bottom-- -> {bottom}")

        # UP
        if left <= right and top <= bottom:
            print(f"  UP: col={left}, rows={bottom} to {top}")
            for row in range(bottom, top - 1, -1):
                result.append(matrix[row][left])
                print(f"    Visit ({row},{left}) = {matrix[row][left]}")
            left += 1
            print(f"    left++ -> {left}")

        print(f"  Current result: {result}")
        print(f"  Boundaries now: top={top}, bottom={bottom}, left={left}, right={right}")
        print()
        layer += 1

    print(f"Final result: {result}")
    print("=" * 50)
    return result


def generate_spiral_matrix(n: int) -> List[List[int]]:
    """
    Bonus: Generate an n x n matrix filled with numbers 1 to n^2 in spiral order.

    This is the reverse of spiral traversal.

    Time Complexity: O(n^2)
    Space Complexity: O(n^2)

    Example:
        >>> generate_spiral_matrix(3)
        [[1, 2, 3], [8, 9, 4], [7, 6, 5]]
    """
    matrix = [[0] * n for _ in range(n)]

    top, bottom = 0, n - 1
    left, right = 0, n - 1
    num = 1

    while top <= bottom and left <= right:
        # Right
        for col in range(left, right + 1):
            matrix[top][col] = num
            num += 1
        top += 1

        # Down
        for row in range(top, bottom + 1):
            matrix[row][right] = num
            num += 1
        right -= 1

        # Left
        if top <= bottom:
            for col in range(right, left - 1, -1):
                matrix[bottom][col] = num
                num += 1
            bottom -= 1

        # Up
        if left <= right:
            for row in range(bottom, top - 1, -1):
                matrix[row][left] = num
                num += 1
            left += 1

    return matrix


def print_matrix(matrix: List[List[int]], title: str = "") -> None:
    """Helper function to print matrix nicely."""
    if title:
        print(f"\n{title}:")
    max_width = max(len(str(cell)) for row in matrix for cell in row)
    for row in matrix:
        print("[" + ", ".join(f"{cell:>{max_width}}" for cell in row) + "]")
    print()


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("SPIRAL MATRIX TRAVERSAL - TEST CASES")
    print("=" * 60)

    # Test Case 1: Standard 3x4 matrix
    print("\n" + "-" * 40)
    print("Test Case 1: 3x4 Matrix")
    print("-" * 40)
    matrix1 = [
        [1, 2, 3, 4],
        [5, 6, 7, 8],
        [9, 10, 11, 12]
    ]
    print_matrix(matrix1, "Input")
    result1 = spiral_order(matrix1)
    print(f"Spiral order: {result1}")
    print(f"Expected:     [1, 2, 3, 4, 8, 12, 11, 10, 9, 5, 6, 7]")
    assert result1 == [1, 2, 3, 4, 8, 12, 11, 10, 9, 5, 6, 7], "Test 1 Failed"
    print("PASSED!")

    # Test Case 2: Square 3x3 matrix
    print("\n" + "-" * 40)
    print("Test Case 2: 3x3 Square Matrix")
    print("-" * 40)
    matrix2 = [
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9]
    ]
    print_matrix(matrix2, "Input")
    result2 = spiral_order(matrix2)
    print(f"Spiral order: {result2}")
    print(f"Expected:     [1, 2, 3, 6, 9, 8, 7, 4, 5]")
    assert result2 == [1, 2, 3, 6, 9, 8, 7, 4, 5], "Test 2 Failed"
    print("PASSED!")

    # Test Case 3: Single row
    print("\n" + "-" * 40)
    print("Test Case 3: Single Row Matrix")
    print("-" * 40)
    matrix3 = [[1, 2, 3, 4]]
    print_matrix(matrix3, "Input")
    result3 = spiral_order(matrix3)
    print(f"Spiral order: {result3}")
    print(f"Expected:     [1, 2, 3, 4]")
    assert result3 == [1, 2, 3, 4], "Test 3 Failed"
    print("PASSED!")

    # Test Case 4: Single column
    print("\n" + "-" * 40)
    print("Test Case 4: Single Column Matrix")
    print("-" * 40)
    matrix4 = [[1], [2], [3], [4]]
    print_matrix(matrix4, "Input")
    result4 = spiral_order(matrix4)
    print(f"Spiral order: {result4}")
    print(f"Expected:     [1, 2, 3, 4]")
    assert result4 == [1, 2, 3, 4], "Test 4 Failed"
    print("PASSED!")

    # Test Case 5: Single element
    print("\n" + "-" * 40)
    print("Test Case 5: Single Element Matrix")
    print("-" * 40)
    matrix5 = [[42]]
    print_matrix(matrix5, "Input")
    result5 = spiral_order(matrix5)
    print(f"Spiral order: {result5}")
    print(f"Expected:     [42]")
    assert result5 == [42], "Test 5 Failed"
    print("PASSED!")

    # Test Case 6: Empty matrix
    print("\n" + "-" * 40)
    print("Test Case 6: Empty Matrix")
    print("-" * 40)
    matrix6 = []
    result6 = spiral_order(matrix6)
    print(f"Spiral order: {result6}")
    print(f"Expected:     []")
    assert result6 == [], "Test 6 Failed"
    print("PASSED!")

    # Test Case 7: 4x4 matrix (multiple layers)
    print("\n" + "-" * 40)
    print("Test Case 7: 4x4 Matrix (Multiple Layers)")
    print("-" * 40)
    matrix7 = [
        [1, 2, 3, 4],
        [5, 6, 7, 8],
        [9, 10, 11, 12],
        [13, 14, 15, 16]
    ]
    print_matrix(matrix7, "Input")
    result7 = spiral_order(matrix7)
    print(f"Spiral order: {result7}")
    expected7 = [1, 2, 3, 4, 8, 12, 16, 15, 14, 13, 9, 5, 6, 7, 11, 10]
    print(f"Expected:     {expected7}")
    assert result7 == expected7, "Test 7 Failed"
    print("PASSED!")

    # Compare brute force vs optimal
    print("\n" + "-" * 40)
    print("Verification: Brute Force vs Optimal")
    print("-" * 40)
    brute_result = spiral_order_brute(matrix7)
    optimal_result = spiral_order(matrix7)
    print(f"Brute force: {brute_result}")
    print(f"Optimal:     {optimal_result}")
    assert brute_result == optimal_result, "Brute force and optimal should match"
    print("Both approaches produce the same result!")

    # Detailed trace for learning
    print("\n" + "-" * 40)
    print("Detailed Trace (Educational)")
    print("-" * 40)
    trace_matrix = [
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9]
    ]
    spiral_order_with_trace(trace_matrix)

    # Generate spiral matrix
    print("\n" + "-" * 40)
    print("Bonus: Generate Spiral Matrix")
    print("-" * 40)
    generated = generate_spiral_matrix(4)
    print_matrix(generated, "4x4 Spiral Matrix (1 to 16)")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)
