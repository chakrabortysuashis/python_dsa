# Spiral Traversal on a Matrix

## Problem Statement

Given an `m x n` matrix, return all elements of the matrix in **spiral order** (clockwise, starting from the top-left corner).

### Example

```
Input:
[ 1,  2,  3,  4]
[ 5,  6,  7,  8]
[ 9, 10, 11, 12]

Output: [1, 2, 3, 4, 8, 12, 11, 10, 9, 5, 6, 7]
```

**Visual representation of traversal:**
```
START
  |
  v
[ 1] -> [ 2] -> [ 3] -> [ 4]
                          |
                          v
[ 5]    [ 6] -> [ 7]    [ 8]
  ^       ^              |
  |       |              v
[ 9] <- [10] <- [11] <- [12]

Order: 1 -> 2 -> 3 -> 4 -> 8 -> 12 -> 11 -> 10 -> 9 -> 5 -> 6 -> 7
```

---

## Intuition and Approach

### Key Insight

Spiral traversal involves visiting elements in a specific pattern:
1. **Right** - traverse the top row
2. **Down** - traverse the right column
3. **Left** - traverse the bottom row
4. **Up** - traverse the left column

After completing one full "ring" of the matrix, we move inward and repeat.

### Boundary Pointer Technique

We maintain four boundary pointers:
- `top` - the topmost row yet to be traversed
- `bottom` - the bottommost row yet to be traversed
- `left` - the leftmost column yet to be traversed
- `right` - the rightmost column yet to be traversed

After traversing each direction, we shrink the corresponding boundary.

---

## Brute Force Approach

### Idea
Use a visited matrix to track which cells have been visited. Move in the current direction until we hit a boundary or visited cell, then turn clockwise.

### Implementation
```python
def spiral_order_brute(matrix):
    if not matrix:
        return []
    
    rows, cols = len(matrix), len(matrix[0])
    visited = [[False] * cols for _ in range(rows)]
    
    # Direction vectors: right, down, left, up
    directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]
    dir_idx = 0  # Start going right
    
    result = []
    i, j = 0, 0
    
    for _ in range(rows * cols):
        result.append(matrix[i][j])
        visited[i][j] = True
        
        # Calculate next position
        ni, nj = i + directions[dir_idx][0], j + directions[dir_idx][1]
        
        # Check if we need to turn
        if (ni < 0 or ni >= rows or nj < 0 or nj >= cols or visited[ni][nj]):
            dir_idx = (dir_idx + 1) % 4  # Turn clockwise
            ni, nj = i + directions[dir_idx][0], j + directions[dir_idx][1]
        
        i, j = ni, nj
    
    return result
```

### Complexity
- **Time**: O(m * n) - visit each cell once
- **Space**: O(m * n) - for the visited matrix

---

## Optimal Approach (Boundary Pointers)

### Algorithm

1. Initialize boundaries: `top = 0`, `bottom = m-1`, `left = 0`, `right = n-1`
2. While `top <= bottom` AND `left <= right`:
   - Traverse **right**: `top` row from `left` to `right`, then `top++`
   - Traverse **down**: `right` column from `top` to `bottom`, then `right--`
   - Traverse **left**: `bottom` row from `right` to `left` (if `top <= bottom`), then `bottom--`
   - Traverse **up**: `left` column from `bottom` to `top` (if `left <= right`), then `left++`

### Boundary Pointer Visualization

```
Initial State:
            left=0         right=3
              |               |
              v               v
top=0   ->  [ 1,  2,  3,  4]
            [ 5,  6,  7,  8]
bottom=2 -> [ 9, 10, 11, 12]


After Right + Down + Left + Up:
            left=1     right=2
              |           |
              v           v
top=1   ->  [ X,  X,  X,  X]
            [ X,  6,  7,  X]
bottom=1 -> [ X,  X,  X,  X]

Continue with inner elements...
```

### Implementation

```python
def spiral_order(matrix):
    if not matrix or not matrix[0]:
        return []
    
    result = []
    top, bottom = 0, len(matrix) - 1
    left, right = 0, len(matrix[0]) - 1
    
    while top <= bottom and left <= right:
        # Traverse RIGHT along top row
        for col in range(left, right + 1):
            result.append(matrix[top][col])
        top += 1
        
        # Traverse DOWN along right column
        for row in range(top, bottom + 1):
            result.append(matrix[row][right])
        right -= 1
        
        # Traverse LEFT along bottom row (if rows remain)
        if top <= bottom:
            for col in range(right, left - 1, -1):
                result.append(matrix[bottom][col])
            bottom -= 1
        
        # Traverse UP along left column (if columns remain)
        if left <= right:
            for row in range(bottom, top - 1, -1):
                result.append(matrix[row][left])
            left += 1
    
    return result
```

### Complexity
- **Time**: O(m * n) - visit each cell exactly once
- **Space**: O(1) - only using pointers (excluding output array)

---

## Step-by-Step Dry Run

### Input Matrix
```
[ 1,  2,  3,  4]
[ 5,  6,  7,  8]
[ 9, 10, 11, 12]
```

### Execution Trace

| Step | Direction | Boundaries (T,B,L,R) | Cells Visited | Result So Far |
|------|-----------|---------------------|---------------|---------------|
| 0 | Initial | (0, 2, 0, 3) | - | [] |
| 1 | Right | (0, 2, 0, 3) | 1, 2, 3, 4 | [1, 2, 3, 4] |
| 2 | Update | (1, 2, 0, 3) | top++ | - |
| 3 | Down | (1, 2, 0, 3) | 8, 12 | [1, 2, 3, 4, 8, 12] |
| 4 | Update | (1, 2, 0, 2) | right-- | - |
| 5 | Left | (1, 2, 0, 2) | 11, 10, 9 | [1, 2, 3, 4, 8, 12, 11, 10, 9] |
| 6 | Update | (1, 1, 0, 2) | bottom-- | - |
| 7 | Up | (1, 1, 0, 2) | 5 | [1, 2, 3, 4, 8, 12, 11, 10, 9, 5] |
| 8 | Update | (1, 1, 1, 2) | left++ | - |
| 9 | Right | (1, 1, 1, 2) | 6, 7 | [1, 2, 3, 4, 8, 12, 11, 10, 9, 5, 6, 7] |
| 10 | Update | (2, 1, 1, 2) | top++ | Loop ends: top > bottom |

### Visual Step-by-Step

**Step 1: Traverse Right (top row)**
```
[>1, >2, >3, >4]     top: 0 -> 1
[ 5,  6,  7,  8]
[ 9, 10, 11, 12]
Result: [1, 2, 3, 4]
```

**Step 2: Traverse Down (right column)**
```
[ X,  X,  X,  X]
[ 5,  6,  7, >8]     right: 3 -> 2
[ 9, 10, 11,>12]
Result: [1, 2, 3, 4, 8, 12]
```

**Step 3: Traverse Left (bottom row)**
```
[ X,  X,  X,  X]
[ 5,  6,  7,  X]     bottom: 2 -> 1
[>9,>10,>11,  X]
Result: [1, 2, 3, 4, 8, 12, 11, 10, 9]
```

**Step 4: Traverse Up (left column)**
```
[ X,  X,  X,  X]
[>5,  6,  7,  X]     left: 0 -> 1
[ X,  X,  X,  X]
Result: [1, 2, 3, 4, 8, 12, 11, 10, 9, 5]
```

**Step 5: Traverse Right (inner row)**
```
[ X,  X,  X,  X]
[ X, >6, >7,  X]     top: 1 -> 2
[ X,  X,  X,  X]
Result: [1, 2, 3, 4, 8, 12, 11, 10, 9, 5, 6, 7]
```

**Loop terminates: top (2) > bottom (1)**

---

## Edge Cases

1. **Empty matrix**: Return `[]`
2. **Single element**: Return `[matrix[0][0]]`
3. **Single row**: Return the row as-is
4. **Single column**: Return elements top to bottom
5. **Square matrix**: Works with all four directions
6. **Non-square matrix**: May skip some directions in inner layers

---

## Time & Space Complexity Summary

| Approach | Time | Space |
|----------|------|-------|
| Brute Force (visited matrix) | O(m * n) | O(m * n) |
| **Optimal (boundary pointers)** | **O(m * n)** | **O(1)** |

The optimal approach is preferred because:
- Same time complexity
- Constant space complexity
- Cleaner code without direction switching logic

---

## Key Takeaways

1. **Boundary pointers** are a powerful technique for layer-by-layer matrix processing
2. Always check if boundaries are still valid before traversing left/up
3. The pattern (right, down, left, up) and shrinking boundaries handle all matrix sizes
4. This technique also applies to: filling matrix spirally, rotating matrix layers, etc.
