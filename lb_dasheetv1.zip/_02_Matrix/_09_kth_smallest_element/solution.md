# Kth Smallest Element in a Row-Column Wise Sorted Matrix

## Problem Statement

Given an `n x n` matrix where each row and column is sorted in ascending order, find the kth smallest element.

### Example

```
Matrix:
[1,  5,  9]
[10, 11, 13]
[12, 13, 15]

k = 8 -> Answer: 13 (8th smallest element)
Sorted: [1, 5, 9, 10, 11, 12, 13, 13, 15]
                                 ^
```

---

## Key Insight

This is similar to "merge k sorted lists" - use a **min-heap** to efficiently find the kth smallest.

---

## Approach 1: Flatten and Sort (Brute Force)

```python
def kth_smallest_brute(matrix, k):
    flat = sorted([x for row in matrix for x in row])
    return flat[k - 1]
```

- **Time**: O(n^2 log n^2) = O(n^2 log n)
- **Space**: O(n^2)

---

## Approach 2: Min-Heap (Better)

### Algorithm
1. Push first element of each row into min-heap
2. Pop minimum k times
3. Each pop: push next element from same row

```python
import heapq

def kth_smallest_heap(matrix, k):
    n = len(matrix)
    # (value, row, col)
    heap = [(matrix[i][0], i, 0) for i in range(min(n, k))]
    heapq.heapify(heap)

    result = 0
    for _ in range(k):
        result, row, col = heapq.heappop(heap)
        if col + 1 < n:
            heapq.heappush(heap, (matrix[row][col + 1], row, col + 1))

    return result
```

- **Time**: O(k log n)
- **Space**: O(n)

---

## Approach 3: Binary Search on Value (Optimal)

### Key Insight
Binary search for the value `x` such that exactly `k` elements are <= x.

### Algorithm
1. Search space: `[matrix[0][0], matrix[n-1][n-1]]`
2. For each `mid`, count elements <= mid
3. Adjust search based on count vs k

### Counting Elements <= x
Use staircase method from top-right: O(n)

```python
def count_less_equal(matrix, x, n):
    count = 0
    row, col = n - 1, 0  # Bottom-left
    while row >= 0 and col < n:
        if matrix[row][col] <= x:
            count += row + 1  # All elements in this column above are <= x
            col += 1
        else:
            row -= 1
    return count
```

### Complete Solution

```python
def kth_smallest(matrix, k):
    n = len(matrix)
    low, high = matrix[0][0], matrix[n-1][n-1]

    while low < high:
        mid = (low + high) // 2
        count = count_less_equal(matrix, mid, n)

        if count < k:
            low = mid + 1
        else:
            high = mid

    return low
```

- **Time**: O(n * log(max - min))
- **Space**: O(1)

---

## Step-by-Step Dry Run (Binary Search)

```
Matrix:
[1,  5,  9]
[10, 11, 13]
[12, 13, 15]

k = 8

Search space: [1, 15]

Iteration 1: mid = 8
  Count <= 8: 2 (only 1, 5)
  2 < 8, so low = 9

Iteration 2: low=9, high=15, mid = 12
  Count <= 12: 6 (1,5,9,10,11,12)
  6 < 8, so low = 13

Iteration 3: low=13, high=15, mid = 14
  Count <= 14: 8 (1,5,9,10,11,12,13,13)
  8 >= 8, so high = 14

Iteration 4: low=13, high=14, mid = 13
  Count <= 13: 8
  8 >= 8, so high = 13

low == high == 13
Answer: 13
```

---

## Complexity Comparison

| Approach | Time | Space |
|----------|------|-------|
| Brute Force | O(n^2 log n) | O(n^2) |
| Min-Heap | O(k log n) | O(n) |
| **Binary Search** | **O(n log(range))** | **O(1)** |

Binary search is optimal when k is large (close to n^2).
Min-heap is better when k is small.

---

## Key Takeaways

1. **Binary search on answer** when counting is efficient
2. **Staircase counting** leverages row-col sorted property
3. This pattern appears in: median of matrix, kth largest, etc.
