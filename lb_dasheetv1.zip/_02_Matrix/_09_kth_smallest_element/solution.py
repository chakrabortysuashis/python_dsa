"""
Kth Smallest Element in Row-Column Wise Sorted Matrix
=====================================================

Problem: Find kth smallest element in matrix where rows and columns are sorted.

Approaches:
1. Brute Force: Flatten and sort - O(n^2 log n)
2. Min-Heap: Pop k times - O(k log n)
3. Binary Search on value: O(n log(range))
"""

from typing import List
import heapq


def kth_smallest_brute(matrix: List[List[int]], k: int) -> int:
    """Brute Force: Flatten, sort, return k-1 index."""
    flat = sorted([x for row in matrix for x in row])
    return flat[k - 1]


def kth_smallest_heap(matrix: List[List[int]], k: int) -> int:
    """
    Min-Heap: Pop minimum k times.

    Time: O(k log n), Space: O(n)
    """
    n = len(matrix)
    # (value, row, col)
    heap = [(matrix[i][0], i, 0) for i in range(min(n, k))]
    heapq.heapify(heap)

    result = 0
    for _ in range(k):
        result, row, col = heapq.heappop(heap)
        if col + 1 < n:
            heapq.heappush(heap, (matrix[row][col + 1], row, col + 1))

    return result


def count_less_equal(matrix: List[List[int]], x: int, n: int) -> int:
    """Count elements <= x using staircase from bottom-left."""
    count = 0
    row, col = n - 1, 0

    while row >= 0 and col < n:
        if matrix[row][col] <= x:
            count += row + 1  # All elements above in this column
            col += 1
        else:
            row -= 1

    return count


def kth_smallest(matrix: List[List[int]], k: int) -> int:
    """
    Binary Search on Value: Find value with exactly k elements <= it.

    Time: O(n * log(max - min)), Space: O(1)

    Example:
        >>> kth_smallest([[1,5,9],[10,11,13],[12,13,15]], 8)
        13
    """
    n = len(matrix)
    low, high = matrix[0][0], matrix[n-1][n-1]

    while low < high:
        mid = (low + high) // 2
        count = count_less_equal(matrix, mid, n)

        if count < k:
            low = mid + 1
        else:
            high = mid

    return low


def kth_smallest_trace(matrix: List[List[int]], k: int) -> int:
    """Educational version with trace."""
    n = len(matrix)
    low, high = matrix[0][0], matrix[n-1][n-1]
    print(f"Finding {k}th smallest in range [{low}, {high}]")

    iteration = 1
    while low < high:
        mid = (low + high) // 2
        count = count_less_equal(matrix, mid, n)
        print(f"Iter {iteration}: low={low}, high={high}, mid={mid}, count<={mid}: {count}")

        if count < k:
            print(f"  {count} < {k}, search right: low = {mid + 1}")
            low = mid + 1
        else:
            print(f"  {count} >= {k}, search left: high = {mid}")
            high = mid
        iteration += 1

    print(f"Result: {low}")
    return low


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 50)
    print("KTH SMALLEST IN ROW-COL SORTED MATRIX")
    print("=" * 50)

    matrix = [
        [1, 5, 9],
        [10, 11, 13],
        [12, 13, 15]
    ]

    print("\nMatrix:")
    for row in matrix:
        print(row)

    print(f"\nSorted: {sorted([x for row in matrix for x in row])}")

    for k in [1, 5, 8, 9]:
        result = kth_smallest(matrix, k)
        expected = sorted([x for row in matrix for x in row])[k-1]
        print(f"k={k}: result={result}, expected={expected}")
        assert result == expected

    print("\nAll tests passed!")

    # Compare methods
    print("\n" + "-" * 40)
    print("Comparing methods for k=8:")
    brute = kth_smallest_brute(matrix, 8)
    heap = kth_smallest_heap(matrix, 8)
    binary = kth_smallest(matrix, 8)
    print(f"Brute: {brute}, Heap: {heap}, Binary: {binary}")
    assert brute == heap == binary

    # Detailed trace
    print("\n" + "-" * 40)
    print("DETAILED TRACE:")
    kth_smallest_trace(matrix, 8)
