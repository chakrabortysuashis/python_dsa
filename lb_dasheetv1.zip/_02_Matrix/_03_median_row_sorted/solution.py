"""
Find Median in a Row-wise Sorted Matrix
=======================================

Problem: Given an m x n matrix where each row is sorted in ascending order,
find the median of the matrix. m and n are always odd.

Optimal Approach: Binary search on the value space
- Instead of sorting all elements, binary search for the value that has
  exactly (m*n)/2 elements smaller than it

Time Complexity: O(m * log(n) * log(max-min))
Space Complexity: O(1)
"""

from typing import List
from bisect import bisect_right, bisect_left
import heapq


def find_median_brute(matrix: List[List[int]]) -> int:
    """
    Brute Force: Flatten matrix, sort, and return middle element.

    Time Complexity: O(m*n * log(m*n))
    Space Complexity: O(m*n)

    Example:
        >>> find_median_brute([[1,3,5], [2,6,9], [3,6,9]])
        5
    """
    if not matrix or not matrix[0]:
        return 0

    # Flatten the matrix
    flat = []
    for row in matrix:
        flat.extend(row)

    # Sort and return middle
    flat.sort()
    return flat[len(flat) // 2]


def find_median(matrix: List[List[int]]) -> int:
    """
    Optimal: Binary Search on Value Space.

    Key Insight:
    - The median is the element where exactly (m*n)/2 elements are smaller
    - Binary search for this value by counting elements <= mid

    Algorithm:
    1. Search space: [min element, max element]
    2. For each mid value, count elements <= mid in entire matrix
    3. Use binary search on each row (since rows are sorted)
    4. Adjust search based on count vs required position

    Time Complexity: O(m * log(n) * log(max-min))
    Space Complexity: O(1)

    Args:
        matrix: Row-wise sorted matrix (m x n, both odd)

    Returns:
        Median value of the matrix

    Example:
        >>> find_median([[1,3,5], [2,6,9], [3,6,9]])
        5
    """
    if not matrix or not matrix[0]:
        return 0

    m = len(matrix)
    n = len(matrix[0])

    # Define search space
    low = min(row[0] for row in matrix)    # Minimum element (first column min)
    high = max(row[-1] for row in matrix)  # Maximum element (last column max)

    # Required position for median (1-indexed)
    # For 9 elements: (9+1)//2 = 5th smallest
    required = (m * n + 1) // 2

    while low < high:
        mid = (low + high) // 2

        # Count elements <= mid in entire matrix
        count = 0
        for row in matrix:
            # bisect_right gives count of elements <= mid
            count += bisect_right(row, mid)

        if count < required:
            # Not enough elements <= mid, median is larger
            low = mid + 1
        else:
            # Enough elements, median could be mid or smaller
            high = mid

    return low


def find_median_detailed(matrix: List[List[int]]) -> int:
    """
    Same as find_median but with detailed counting (without bisect).

    This version shows the counting logic explicitly.
    """
    if not matrix or not matrix[0]:
        return 0

    m = len(matrix)
    n = len(matrix[0])

    low = min(row[0] for row in matrix)
    high = max(row[-1] for row in matrix)
    required = (m * n + 1) // 2

    def count_less_equal(val: int) -> int:
        """Count elements <= val in entire matrix."""
        count = 0
        for row in matrix:
            # Binary search for rightmost position where element <= val
            left, right = 0, n
            while left < right:
                mid = (left + right) // 2
                if row[mid] <= val:
                    left = mid + 1
                else:
                    right = mid
            count += left
        return count

    while low < high:
        mid = (low + high) // 2
        count = count_less_equal(mid)

        if count < required:
            low = mid + 1
        else:
            high = mid

    return low


def find_median_heap(matrix: List[List[int]]) -> int:
    """
    Alternative: Min-Heap approach to find kth smallest.

    Uses a min-heap to efficiently find the (m*n+1)/2 smallest element.

    Time Complexity: O(k * log(m)) where k = (m*n)/2
    Space Complexity: O(m)

    Example:
        >>> find_median_heap([[1,3,5], [2,6,9], [3,6,9]])
        5
    """
    if not matrix or not matrix[0]:
        return 0

    m = len(matrix)
    n = len(matrix[0])
    k = (m * n + 1) // 2  # Position of median

    # Min heap: (value, row_index, col_index)
    # Start with first element of each row
    heap = [(matrix[i][0], i, 0) for i in range(m)]
    heapq.heapify(heap)

    result = 0
    for _ in range(k):
        result, row, col = heapq.heappop(heap)

        # Push next element from same row if exists
        if col + 1 < n:
            heapq.heappush(heap, (matrix[row][col + 1], row, col + 1))

    return result


def find_median_with_trace(matrix: List[List[int]]) -> int:
    """
    Educational version with detailed trace output.
    """
    if not matrix or not matrix[0]:
        return 0

    m = len(matrix)
    n = len(matrix[0])

    print("=" * 60)
    print("FIND MEDIAN IN ROW-SORTED MATRIX")
    print("=" * 60)
    print(f"Matrix size: {m} x {n}")
    print(f"Total elements: {m * n}")

    low = min(row[0] for row in matrix)
    high = max(row[-1] for row in matrix)
    required = (m * n + 1) // 2

    print(f"Search range: [{low}, {high}]")
    print(f"Required position: {required} (median position)")
    print()

    iteration = 1
    while low < high:
        mid = (low + high) // 2
        print(f"Iteration {iteration}: low={low}, high={high}, mid={mid}")

        count = 0
        for i, row in enumerate(matrix):
            row_count = bisect_right(row, mid)
            count += row_count
            print(f"  Row {i} {row}: elements <= {mid} = {row_count}")

        print(f"  Total count = {count}")

        if count < required:
            print(f"  {count} < {required}, search RIGHT (low = {mid + 1})")
            low = mid + 1
        else:
            print(f"  {count} >= {required}, search LEFT (high = {mid})")
            high = mid

        print()
        iteration += 1

    print(f"Median found: {low}")
    print("=" * 60)
    return low


def print_matrix(matrix: List[List[int]], title: str = "") -> None:
    """Helper to print matrix."""
    if title:
        print(f"\n{title}:")
    for row in matrix:
        print(row)


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("FIND MEDIAN IN ROW-SORTED MATRIX - TEST CASES")
    print("=" * 60)

    # Test Case 1: Standard 3x3 matrix
    print("\n" + "-" * 40)
    print("Test 1: 3x3 Matrix")
    print("-" * 40)
    matrix1 = [
        [1, 3, 5],
        [2, 6, 9],
        [3, 6, 9]
    ]
    print_matrix(matrix1, "Input")
    print(f"Sorted: {sorted([x for row in matrix1 for x in row])}")
    result = find_median(matrix1)
    print(f"Median: {result}")
    print(f"Expected: 5")
    assert result == 5, "Test 1 Failed"
    print("PASSED!")

    # Test Case 2: Different values
    print("\n" + "-" * 40)
    print("Test 2: 3x3 Matrix with different values")
    print("-" * 40)
    matrix2 = [
        [1, 3, 8],
        [2, 3, 5],
        [4, 6, 7]
    ]
    print_matrix(matrix2, "Input")
    print(f"Sorted: {sorted([x for row in matrix2 for x in row])}")
    result = find_median(matrix2)
    expected = sorted([x for row in matrix2 for x in row])[4]
    print(f"Median: {result}")
    print(f"Expected: {expected}")
    assert result == expected, "Test 2 Failed"
    print("PASSED!")

    # Test Case 3: 5x5 matrix
    print("\n" + "-" * 40)
    print("Test 3: 5x5 Matrix")
    print("-" * 40)
    matrix3 = [
        [1, 5, 9, 13, 17],
        [2, 6, 10, 14, 18],
        [3, 7, 11, 15, 19],
        [4, 8, 12, 16, 20],
        [21, 22, 23, 24, 25]
    ]
    print_matrix(matrix3, "Input")
    result = find_median(matrix3)
    expected = sorted([x for row in matrix3 for x in row])[12]
    print(f"Median: {result}")
    print(f"Expected: {expected}")
    assert result == expected, "Test 3 Failed"
    print("PASSED!")

    # Test Case 4: Single element
    print("\n" + "-" * 40)
    print("Test 4: Single Element")
    print("-" * 40)
    matrix4 = [[42]]
    result = find_median(matrix4)
    print(f"Median of [[42]]: {result}")
    assert result == 42, "Test 4 Failed"
    print("PASSED!")

    # Test Case 5: Single row
    print("\n" + "-" * 40)
    print("Test 5: Single Row")
    print("-" * 40)
    matrix5 = [[1, 2, 3, 4, 5]]
    result = find_median(matrix5)
    print(f"Median of {matrix5}: {result}")
    assert result == 3, "Test 5 Failed"
    print("PASSED!")

    # Test Case 6: Single column
    print("\n" + "-" * 40)
    print("Test 6: Single Column")
    print("-" * 40)
    matrix6 = [[1], [2], [3], [4], [5]]
    result = find_median(matrix6)
    print(f"Median: {result}")
    assert result == 3, "Test 6 Failed"
    print("PASSED!")

    # Compare all methods
    print("\n" + "-" * 40)
    print("Comparing All Methods")
    print("-" * 40)
    test_matrix = [
        [1, 3, 5],
        [2, 6, 9],
        [3, 6, 9]
    ]
    brute = find_median_brute(test_matrix)
    optimal = find_median(test_matrix)
    heap = find_median_heap(test_matrix)
    print(f"Brute Force: {brute}")
    print(f"Binary Search: {optimal}")
    print(f"Heap: {heap}")
    assert brute == optimal == heap, "Methods produce different results"
    print("All methods produce same result!")

    # Detailed trace
    print("\n" + "-" * 40)
    print("DETAILED TRACE")
    print("-" * 40)
    find_median_with_trace(matrix2)

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)
