# Find Median in a Row-wise Sorted Matrix

## Problem Statement

Given an `m x n` matrix where each row is sorted in ascending order, find the **median** of the matrix.

**Constraints:**
- m and n are always odd (guarantees a unique median)
- All elements are distinct

### Example

```
Matrix (3x3):
[1, 3, 5]
[2, 6, 9]
[3, 6, 9]

Total elements = 9 (odd)
Median position = (9 + 1) / 2 = 5th element
Sorted: [1, 2, 3, 3, 5, 6, 6, 9, 9]
Median = 5
```

---

## Intuition

### Key Insight

Instead of sorting all elements (expensive!), we can use **binary search on the answer space**.

The median has a special property:
- Exactly `(m*n)/2` elements are **smaller** than or equal to it
- If we can count elements <= x efficiently, we can binary search for the median

### Why Binary Search Works

1. Define search space: `[min_element, max_element]`
2. For any value `mid`, count how many elements are <= mid
3. If count < (m*n+1)/2: median is larger, search right half
4. Otherwise: median could be mid or smaller, search left half

---

## Approach 1: Brute Force (Flatten and Sort)

### Algorithm
1. Copy all elements to a 1D array
2. Sort the array
3. Return middle element

```python
def find_median_brute(matrix):
    flat = []
    for row in matrix:
        flat.extend(row)
    flat.sort()
    return flat[len(flat) // 2]
```

### Complexity
- **Time**: O(m*n * log(m*n)) - sorting all elements
- **Space**: O(m*n) - storing all elements

---

## Approach 2: Binary Search on Value Space (Optimal)

### Algorithm

1. Find the range: `low = min(first column)`, `high = max(last column)`
2. Binary search on value space `[low, high]`:
   - For each `mid`, count elements <= mid in entire matrix
   - Use binary search on each row (rows are sorted!)
3. Adjust search based on count vs required position

### Counting Elements <= x in a Row

Since each row is sorted, use `bisect_right` (upper bound):
```python
count_in_row = bisect_right(row, x)
```

### Visual Example

```
Matrix:
[1, 3, 5]
[2, 6, 9]
[3, 6, 9]

Search space: [1, 9]
Required position: (9+1)/2 = 5

Iteration 1: mid = 5
  Row 0: elements <= 5 = 3 (all of [1,3,5])
  Row 1: elements <= 5 = 1 (only 2)
  Row 2: elements <= 5 = 1 (only 3)
  Total count = 5 >= 5
  -> high = 5

Iteration 2: mid = 3
  Row 0: elements <= 3 = 2 ([1,3])
  Row 1: elements <= 3 = 1 ([2])
  Row 2: elements <= 3 = 1 ([3])
  Total count = 4 < 5
  -> low = 4

Iteration 3: mid = 4
  Row 0: elements <= 4 = 2 ([1,3])
  Row 1: elements <= 4 = 1 ([2])
  Row 2: elements <= 4 = 1 ([3])
  Total count = 4 < 5
  -> low = 5

low == high == 5
Median = 5
```

### Implementation

```python
from bisect import bisect_right

def find_median(matrix):
    m, n = len(matrix), len(matrix[0])
    
    # Search space: min to max element
    low = min(row[0] for row in matrix)   # min of first column
    high = max(row[-1] for row in matrix) # max of last column
    
    required = (m * n + 1) // 2  # Position of median
    
    while low < high:
        mid = (low + high) // 2
        
        # Count elements <= mid
        count = sum(bisect_right(row, mid) for row in matrix)
        
        if count < required:
            low = mid + 1
        else:
            high = mid
    
    return low
```

### Complexity
- **Time**: O(m * log(n) * log(max-min))
  - Binary search on value range: O(log(max-min))
  - For each mid: count in all rows: O(m * log(n))
- **Space**: O(1)

---

## Step-by-Step Dry Run

### Input
```
Matrix:
[1, 3, 8]
[2, 3, 5]
[4, 6, 7]

m = 3, n = 3
Total elements = 9
Required position = 5 (5th smallest)
```

### Execution

| Step | low | high | mid | Count <= mid | Action |
|------|-----|------|-----|--------------|--------|
| Init | 1 | 8 | - | - | min=1, max=8 |
| 1 | 1 | 8 | 4 | 5 | count >= 5, high=4 |
| 2 | 1 | 4 | 2 | 2 | count < 5, low=3 |
| 3 | 3 | 4 | 3 | 4 | count < 5, low=4 |
| 4 | 4 | 4 | - | - | low=high, return 4 |

**Count details for mid=4:**
- Row 0 [1,3,8]: elements <= 4 = 2 (1,3)
- Row 1 [2,3,5]: elements <= 4 = 2 (2,3)
- Row 2 [4,6,7]: elements <= 4 = 1 (4)
- Total = 5

**Median = 4**

---

## Alternative: Min-Heap Approach

### Idea
Use a min-heap to find the kth smallest element (k = (m*n+1)/2).

```python
import heapq

def find_median_heap(matrix):
    m, n = len(matrix), len(matrix[0])
    k = (m * n + 1) // 2
    
    # Min heap: (value, row, col)
    heap = [(matrix[i][0], i, 0) for i in range(m)]
    heapq.heapify(heap)
    
    result = 0
    for _ in range(k):
        result, row, col = heapq.heappop(heap)
        if col + 1 < n:
            heapq.heappush(heap, (matrix[row][col + 1], row, col + 1))
    
    return result
```

### Complexity
- **Time**: O(k * log(m)) where k = (m*n)/2
- **Space**: O(m) for heap

---

## Comparison of Approaches

| Approach | Time | Space | Notes |
|----------|------|-------|-------|
| Brute Force | O(m*n log(m*n)) | O(m*n) | Simple but slow |
| **Binary Search** | **O(m log n log(range))** | **O(1)** | **Optimal** |
| Min-Heap | O(k log m) | O(m) | Good for streaming |

---

## Edge Cases

1. **Single element**: Return that element
2. **Single row**: Return middle element
3. **Single column**: Sort and return middle
4. **All same elements**: Return that element
5. **Large range, few elements**: Binary search still efficient

---

## Key Takeaways

1. **Binary search on answer space** is powerful when:
   - You can efficiently check if a value is too small/large
   - The answer exists within a bounded range

2. **Counting elements <= x** in sorted row: O(log n) using binary search

3. This technique also applies to:
   - Kth smallest in sorted matrix
   - Median of two sorted arrays
   - Finding threshold values

---

## Time Complexity Analysis

```
Binary search iterations: log(max - min)
  - For 32-bit integers: at most 32 iterations
  
Each iteration:
  - Count in m rows
  - Each row: binary search in n elements -> O(log n)
  - Total: O(m * log n)

Overall: O(log(range) * m * log n)
```

For typical inputs where range ~ 10^9 and matrix size ~ 10^5:
- log(10^9) ~ 30
- m * log(n) ~ reasonable

Much better than O(m*n log(m*n)) brute force!
