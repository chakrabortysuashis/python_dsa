"""
Print Elements in Sorted Order - Row-Column Sorted Matrix
=========================================================

Problem: Given a matrix where each row and column is sorted,
print all elements in sorted order.

Optimal: Min-Heap approach - O(n^2 log n) time, O(n) space
"""

from typing import List
import heapq


def sorted_matrix_brute(matrix: List[List[int]]) -> List[int]:
    """Brute Force: Flatten and sort. O(n^2 log n) time, O(n^2) space."""
    if not matrix:
        return []
    return sorted([x for row in matrix for x in row])


def sorted_matrix(matrix: List[List[int]]) -> List[int]:
    """
    Min-Heap: Merge n sorted rows using a min-heap.

    Algorithm:
    1. Initialize heap with first element of each row
    2. Pop minimum, push next element from same row
    3. Repeat until heap is empty

    Time: O(n^2 log n) - n^2 elements, log n per heap operation
    Space: O(n) - heap has at most n elements

    Example:
        >>> sorted_matrix([[10,20,30], [15,25,35], [27,29,37]])
        [10, 15, 20, 25, 27, 29, 30, 35, 37]
    """
    if not matrix or not matrix[0]:
        return []

    n = len(matrix)
    m = len(matrix[0])
    result = []

    # Min heap: (value, row, col)
    heap = [(matrix[i][0], i, 0) for i in range(n)]
    heapq.heapify(heap)

    while heap:
        val, row, col = heapq.heappop(heap)
        result.append(val)

        # Push next element from same row
        if col + 1 < m:
            heapq.heappush(heap, (matrix[row][col + 1], row, col + 1))

    return result


def sorted_matrix_young(matrix: List[List[int]]) -> List[int]:
    """
    Young Tableau extraction: Extract min and heapify down.
    Modifies matrix. O(n^2 log n) time, O(1) extra space.
    """
    import copy
    mat = copy.deepcopy(matrix)
    if not mat:
        return []

    n, m = len(mat), len(mat[0])
    result = []

    for _ in range(n * m):
        # Extract minimum (top-left)
        result.append(mat[0][0])
        mat[0][0] = float('inf')

        # Heapify down
        i, j = 0, 0
        while True:
            min_i, min_j = i, j

            if i + 1 < n and mat[i+1][j] < mat[min_i][min_j]:
                min_i, min_j = i + 1, j
            if j + 1 < m and mat[i][j+1] < mat[min_i][min_j]:
                min_i, min_j = i, j + 1

            if (min_i, min_j) == (i, j):
                break

            mat[i][j], mat[min_i][min_j] = mat[min_i][min_j], mat[i][j]
            i, j = min_i, min_j

    return result


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 50)
    print("SORTED ORDER FROM ROW-COL SORTED MATRIX")
    print("=" * 50)

    matrix = [
        [10, 20, 30, 40],
        [15, 25, 35, 45],
        [27, 29, 37, 48],
        [32, 33, 39, 50]
    ]

    print("\nMatrix:")
    for row in matrix:
        print(row)

    result = sorted_matrix(matrix)
    expected = sorted([x for row in matrix for x in row])

    print(f"\nSorted: {result}")
    print(f"Expected: {expected}")
    assert result == expected, "Test Failed"
    print("PASSED!")

    # Compare methods
    print("\n" + "-" * 40)
    brute = sorted_matrix_brute(matrix)
    heap = sorted_matrix(matrix)
    young = sorted_matrix_young(matrix)
    print(f"Brute: {brute[:5]}...")
    print(f"Heap:  {heap[:5]}...")
    print(f"Young: {young[:5]}...")
    assert brute == heap == young
    print("All methods match!")
