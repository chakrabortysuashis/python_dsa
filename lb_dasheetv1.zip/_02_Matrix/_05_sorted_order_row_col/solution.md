# Print Elements in Sorted Order Using Row-Column Wise Sorted Matrix

## Problem Statement

Given an `n x n` matrix where each row and each column is sorted in increasing order, print all elements in sorted order.

### Example

```
Input:
[10, 20, 30, 40]
[15, 25, 35, 45]
[27, 29, 37, 48]
[32, 33, 39, 50]

Output: 10, 15, 20, 25, 27, 29, 30, 32, 33, 35, 37, 39, 40, 45, 48, 50
```

---

## Key Insight

The smallest element is always at `matrix[0][0]`. After extracting it, the next smallest is either:
- `matrix[0][1]` (right neighbor) or
- `matrix[1][0]` (bottom neighbor)

This is a classic **min-heap** problem!

---

## Approach 1: Flatten and Sort (Brute Force)

```python
def sorted_matrix_brute(matrix):
    flat = [x for row in matrix for x in row]
    return sorted(flat)
```

- **Time**: O(n^2 * log(n^2)) = O(n^2 * log n)
- **Space**: O(n^2)

---

## Approach 2: Min-Heap (Optimal)

### Algorithm
1. Start with the first element of each row in a min-heap
2. Extract minimum from heap
3. Push the next element from the same row (if exists)
4. Repeat until heap is empty

### Why First Column?
Starting with first elements of each row ensures we have at least one candidate from each row in the heap.

### Implementation

```python
import heapq

def sorted_matrix(matrix):
    if not matrix:
        return []
    
    n = len(matrix)
    result = []
    
    # Min heap: (value, row, col)
    heap = [(matrix[i][0], i, 0) for i in range(n)]
    heapq.heapify(heap)
    
    while heap:
        val, row, col = heapq.heappop(heap)
        result.append(val)
        
        # Push next element from same row
        if col + 1 < n:
            heapq.heappush(heap, (matrix[row][col + 1], row, col + 1))
    
    return result
```

### Complexity
- **Time**: O(n^2 * log n) - n^2 elements, each heap operation O(log n)
- **Space**: O(n) - heap contains at most n elements

---

## Visual Walkthrough

```
Initial heap (first column):
Heap: [(10,0,0), (15,1,0), (27,2,0), (32,3,0)]

Step 1: Pop (10,0,0), push (20,0,1)
        Result: [10]
        Heap: [(15,1,0), (20,0,1), (27,2,0), (32,3,0)]

Step 2: Pop (15,1,0), push (25,1,1)
        Result: [10, 15]
        Heap: [(20,0,1), (25,1,1), (27,2,0), (32,3,0)]

Step 3: Pop (20,0,1), push (30,0,2)
        Result: [10, 15, 20]
        ...
```

---

## Alternative: Young Tableau Extraction

Extract minimum repeatedly from top-left and "heapify down":

```python
def extract_min(matrix, n):
    result = matrix[0][0]
    matrix[0][0] = float('inf')
    
    # Heapify down
    i, j = 0, 0
    while True:
        min_i, min_j = i, j
        
        if i + 1 < n and matrix[i+1][j] < matrix[min_i][min_j]:
            min_i, min_j = i + 1, j
        if j + 1 < n and matrix[i][j+1] < matrix[min_i][min_j]:
            min_i, min_j = i, j + 1
        
        if (min_i, min_j) == (i, j):
            break
            
        matrix[i][j], matrix[min_i][min_j] = matrix[min_i][min_j], matrix[i][j]
        i, j = min_i, min_j
    
    return result
```

This approach modifies the matrix but uses O(1) extra space.

---

## Key Takeaways

1. **Min-heap** is ideal when merging k sorted sequences
2. Starting with one element per row ensures balanced heap
3. The heap size never exceeds n (number of rows)
4. Similar technique works for "merge k sorted lists"
