# Search an Element in a Matrix

## Problem Statement

Given an `m x n` matrix with the following properties:
- Each row is sorted in ascending order from left to right
- Each column is sorted in ascending order from top to bottom

Search for a target value and return its position, or indicate if it doesn't exist.

### Variant 1: Row-Column Sorted Matrix
Each row and each column is sorted independently.
```
Matrix:
[1,   4,  7, 11]
[2,   5,  8, 12]
[3,   6,  9, 16]
[10, 13, 14, 17]

Search for 5 -> Found at (1, 1)
Search for 20 -> Not found
```

### Variant 2: Fully Sorted Matrix
The first element of each row is greater than the last element of the previous row.
```
Matrix:
[1,   3,  5,  7]
[10, 11, 16, 20]
[23, 30, 34, 60]

Search for 3 -> Found at (0, 1)
```

---

## Intuition and Approach

### Key Insight for Row-Column Sorted Matrix

The matrix has a special property: if you stand at the **top-right corner**:
- All elements to the **left** are **smaller**
- All elements **below** are **larger**

This gives us a clear decision at each step - either go left or down!

```
Standing at position (0, 3) with value 11:
    [1,   4,  7, (11)]   <- Current position
    [2,   5,  8,  12 ]
    [3,   6,  9,  16 ]
    [10, 13, 14,  17 ]

    If target < 11: Go LEFT (smaller values)
    If target > 11: Go DOWN (larger values)
    If target == 11: FOUND!
```

This is called the **Staircase Search** or **Z-Search**.

---

## Approach 1: Brute Force (Linear Search)

### Algorithm
Scan every element in the matrix until found.

```python
def search_brute(matrix, target):
    for i in range(len(matrix)):
        for j in range(len(matrix[0])):
            if matrix[i][j] == target:
                return (i, j)
    return None
```

### Complexity
- **Time**: O(m * n) - check every element
- **Space**: O(1)

---

## Approach 2: Binary Search per Row

### Algorithm
Since each row is sorted, apply binary search to each row.

```python
def search_row_binary(matrix, target):
    for i in range(len(matrix)):
        # Binary search in row i
        left, right = 0, len(matrix[0]) - 1
        while left <= right:
            mid = (left + right) // 2
            if matrix[i][mid] == target:
                return (i, mid)
            elif matrix[i][mid] < target:
                left = mid + 1
            else:
                right = mid - 1
    return None
```

### Complexity
- **Time**: O(m * log n) - binary search for each row
- **Space**: O(1)

---

## Approach 3: Staircase Search (Optimal for Row-Col Sorted)

### Algorithm (Starting from Top-Right)

1. Start at position `(0, n-1)` - top-right corner
2. Compare `matrix[i][j]` with `target`:
   - If equal: **Found!** Return position
   - If `matrix[i][j] > target`: Move **left** (j--)
   - If `matrix[i][j] < target`: Move **down** (i++)
3. If out of bounds: Target not found

### Visual Walkthrough

**Search for 6:**
```
Step 1: Start at (0, 3) = 11
        11 > 6, go LEFT
        
        [1, 4, 7, 11] <- started here
                  ^
                  
Step 2: At (0, 2) = 7
        7 > 6, go LEFT
        
        [1, 4, 7, 11]
             ^
             
Step 3: At (0, 1) = 4
        4 < 6, go DOWN
        
        [1, 4, 7, 11]
            |
            v
        [2, 5, 8, 12]
            ^
            
Step 4: At (1, 1) = 5
        5 < 6, go DOWN
        
        [3, 6, 9, 16]
            ^
            
Step 5: At (2, 1) = 6
        6 == 6, FOUND at (2, 1)!
```

### Implementation

```python
def search_staircase(matrix, target):
    if not matrix or not matrix[0]:
        return None
    
    rows, cols = len(matrix), len(matrix[0])
    
    # Start from top-right corner
    i, j = 0, cols - 1
    
    while i < rows and j >= 0:
        if matrix[i][j] == target:
            return (i, j)
        elif matrix[i][j] > target:
            j -= 1  # Go left (smaller values)
        else:
            i += 1  # Go down (larger values)
    
    return None
```

### Why Top-Right (or Bottom-Left)?

Starting from top-right:
- Left = smaller, Down = larger (clear direction)

Starting from bottom-left:
- Right = larger, Up = smaller (also works!)

Starting from top-left or bottom-right:
- Both directions increase or both decrease
- No clear decision possible!

### Complexity
- **Time**: O(m + n) - at most m + n moves
- **Space**: O(1)

---

## Approach 4: Binary Search (Fully Sorted Matrix)

For matrices where each row continues from the previous:
```
[1,  3,  5,  7]
[10, 11, 16, 20]  <- 10 > 7 (last of prev row)
[23, 30, 34, 60]  <- 23 > 20
```

Treat the matrix as a 1D sorted array and use binary search.

### Index Conversion
- 1D index to 2D: `row = index // cols`, `col = index % cols`
- 2D to 1D: `index = row * cols + col`

### Implementation

```python
def search_binary_2d(matrix, target):
    if not matrix or not matrix[0]:
        return None
    
    rows, cols = len(matrix), len(matrix[0])
    left, right = 0, rows * cols - 1
    
    while left <= right:
        mid = (left + right) // 2
        row = mid // cols
        col = mid % cols
        
        if matrix[row][col] == target:
            return (row, col)
        elif matrix[row][col] < target:
            left = mid + 1
        else:
            right = mid - 1
    
    return None
```

### Complexity
- **Time**: O(log(m * n)) = O(log m + log n)
- **Space**: O(1)

---

## Step-by-Step Dry Run (Staircase Search)

### Input
```
Matrix:
[1,   4,  7, 11]
[2,   5,  8, 12]
[3,   6,  9, 16]
[10, 13, 14, 17]

Target: 9
```

### Execution Trace

| Step | Position (i,j) | Value | Comparison | Action |
|------|---------------|-------|------------|--------|
| 1 | (0, 3) | 11 | 11 > 9 | j-- (go left) |
| 2 | (0, 2) | 7 | 7 < 9 | i++ (go down) |
| 3 | (1, 2) | 8 | 8 < 9 | i++ (go down) |
| 4 | (2, 2) | 9 | 9 == 9 | **FOUND!** |

**Path visualization:**
```
[1,   4,   7, [11]]  Step 1: Start here
               |
[2,   5,   8, 12 ]  Step 2 & 3
         \
[3,   6, [9], 16 ]  Step 4: Found!

[10, 13, 14,  17 ]
```

---

## Comparison of Approaches

| Approach | Time | Space | When to Use |
|----------|------|-------|-------------|
| Brute Force | O(m*n) | O(1) | Small matrices |
| Binary per Row | O(m log n) | O(1) | Only rows sorted |
| **Staircase** | **O(m+n)** | **O(1)** | **Row-col sorted** |
| Binary 2D | O(log(m*n)) | O(1) | Fully sorted |

---

## Edge Cases

1. **Empty matrix**: Return None immediately
2. **Single element**: Check if it equals target
3. **Target smaller than all**: j goes to -1
4. **Target larger than all**: i exceeds rows
5. **Target not in matrix**: Loop exits without finding

---

## Key Takeaways

1. **Staircase search** exploits the sorted property in both directions
2. Starting corner matters: top-right or bottom-left gives clear decisions
3. For fully sorted matrices, treat as 1D array for O(log n) search
4. Always check which sorting property the matrix has before choosing approach

---

## Related Problems

- Search in Rotated Sorted Array
- Find Peak Element in 2D Matrix
- Kth Smallest Element in Sorted Matrix
- Binary Search variations
