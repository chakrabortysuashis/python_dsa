"""
Search an Element in a Matrix
=============================

Problem: Given an m x n matrix where each row and column is sorted in ascending order,
find if a target value exists in the matrix.

Approaches:
1. Brute Force - O(m*n)
2. Binary Search per Row - O(m * log n)
3. Staircase Search - O(m + n) [OPTIMAL for row-col sorted]
4. Binary Search 2D - O(log(m*n)) [For fully sorted matrix]
"""

from typing import List, Optional, Tuple


def search_brute_force(matrix: List[List[int]], target: int) -> Optional[Tuple[int, int]]:
    """
    Brute Force: Check every element in the matrix.

    Time Complexity: O(m * n)
    Space Complexity: O(1)

    Args:
        matrix: 2D matrix (not necessarily sorted)
        target: Value to search for

    Returns:
        (row, col) if found, None otherwise
    """
    if not matrix or not matrix[0]:
        return None

    for i in range(len(matrix)):
        for j in range(len(matrix[0])):
            if matrix[i][j] == target:
                return (i, j)

    return None


def search_binary_per_row(matrix: List[List[int]], target: int) -> Optional[Tuple[int, int]]:
    """
    Binary Search per Row: Apply binary search to each row.

    Works for matrices where each row is sorted independently.

    Time Complexity: O(m * log n)
    Space Complexity: O(1)

    Args:
        matrix: 2D matrix with sorted rows
        target: Value to search for

    Returns:
        (row, col) if found, None otherwise
    """
    if not matrix or not matrix[0]:
        return None

    for i in range(len(matrix)):
        # Binary search in row i
        left, right = 0, len(matrix[0]) - 1

        while left <= right:
            mid = (left + right) // 2

            if matrix[i][mid] == target:
                return (i, mid)
            elif matrix[i][mid] < target:
                left = mid + 1
            else:
                right = mid - 1

    return None


def search_staircase(matrix: List[List[int]], target: int) -> Optional[Tuple[int, int]]:
    """
    Staircase Search (Z-Search): Start from top-right corner.

    This is the OPTIMAL approach for matrices sorted both row-wise and column-wise.

    Key Insight:
    - At top-right corner (0, n-1):
      - All elements to the LEFT are SMALLER
      - All elements BELOW are LARGER
    - This gives us a clear decision at each step!

    Algorithm:
    1. Start at (0, cols-1) - top-right corner
    2. If current == target: Found!
    3. If current > target: Move LEFT (smaller values)
    4. If current < target: Move DOWN (larger values)
    5. Repeat until found or out of bounds

    Time Complexity: O(m + n) - at most m down moves + n left moves
    Space Complexity: O(1)

    Args:
        matrix: 2D matrix with sorted rows AND sorted columns
        target: Value to search for

    Returns:
        (row, col) if found, None otherwise

    Example:
        Matrix:
        [1,   4,  7, 11]
        [2,   5,  8, 12]
        [3,   6,  9, 16]
        [10, 13, 14, 17]

        >>> search_staircase(matrix, 5)
        (1, 1)

        >>> search_staircase(matrix, 20)
        None
    """
    if not matrix or not matrix[0]:
        return None

    rows = len(matrix)
    cols = len(matrix[0])

    # Start from TOP-RIGHT corner
    i = 0           # Start at first row
    j = cols - 1    # Start at last column

    while i < rows and j >= 0:
        current = matrix[i][j]

        if current == target:
            return (i, j)   # Found!

        elif current > target:
            j -= 1          # Move LEFT (smaller values)

        else:  # current < target
            i += 1          # Move DOWN (larger values)

    return None  # Not found


def search_staircase_bottom_left(matrix: List[List[int]], target: int) -> Optional[Tuple[int, int]]:
    """
    Alternative Staircase: Start from bottom-left corner.

    At bottom-left corner (m-1, 0):
    - All elements to the RIGHT are LARGER
    - All elements ABOVE are SMALLER

    Time Complexity: O(m + n)
    Space Complexity: O(1)
    """
    if not matrix or not matrix[0]:
        return None

    rows = len(matrix)
    cols = len(matrix[0])

    # Start from BOTTOM-LEFT corner
    i = rows - 1    # Start at last row
    j = 0           # Start at first column

    while i >= 0 and j < cols:
        current = matrix[i][j]

        if current == target:
            return (i, j)   # Found!

        elif current > target:
            i -= 1          # Move UP (smaller values)

        else:  # current < target
            j += 1          # Move RIGHT (larger values)

    return None


def search_binary_2d(matrix: List[List[int]], target: int) -> Optional[Tuple[int, int]]:
    """
    Binary Search treating matrix as 1D sorted array.

    Works ONLY for matrices where:
    - Each row is sorted
    - First element of each row > last element of previous row

    Example valid matrix:
    [1,   3,  5,  7]
    [10, 11, 16, 20]   <- 10 > 7
    [23, 30, 34, 60]   <- 23 > 20

    Index conversion:
    - 1D index to 2D: row = index // cols, col = index % cols
    - 2D to 1D: index = row * cols + col

    Time Complexity: O(log(m * n))
    Space Complexity: O(1)

    Args:
        matrix: Fully sorted 2D matrix
        target: Value to search for

    Returns:
        (row, col) if found, None otherwise
    """
    if not matrix or not matrix[0]:
        return None

    rows = len(matrix)
    cols = len(matrix[0])

    # Treat as 1D sorted array of size rows * cols
    left = 0
    right = rows * cols - 1

    while left <= right:
        mid = (left + right) // 2

        # Convert 1D index to 2D
        row = mid // cols
        col = mid % cols

        current = matrix[row][col]

        if current == target:
            return (row, col)

        elif current < target:
            left = mid + 1

        else:
            right = mid - 1

    return None


def search_with_trace(matrix: List[List[int]], target: int) -> Optional[Tuple[int, int]]:
    """
    Staircase search with detailed trace for educational purposes.
    """
    if not matrix or not matrix[0]:
        print("Empty matrix!")
        return None

    rows = len(matrix)
    cols = len(matrix[0])

    print("=" * 50)
    print(f"SEARCHING FOR: {target}")
    print("=" * 50)
    print(f"Matrix: {rows} x {cols}")
    print(f"Starting at TOP-RIGHT corner: (0, {cols-1})")
    print()

    i, j = 0, cols - 1
    step = 1

    while i < rows and j >= 0:
        current = matrix[i][j]
        print(f"Step {step}: Position ({i}, {j}) = {current}")

        if current == target:
            print(f"  {current} == {target} -> FOUND!")
            print(f"\nResult: Found at ({i}, {j})")
            return (i, j)

        elif current > target:
            print(f"  {current} > {target} -> Move LEFT (j--)")
            j -= 1

        else:
            print(f"  {current} < {target} -> Move DOWN (i++)")
            i += 1

        step += 1
        print()

    print(f"Out of bounds: i={i}, j={j}")
    print(f"\nResult: {target} NOT FOUND")
    return None


def print_matrix(matrix: List[List[int]], title: str = "") -> None:
    """Helper function to print matrix."""
    if title:
        print(f"\n{title}:")
    max_width = max(len(str(cell)) for row in matrix for cell in row)
    for row in matrix:
        print("[" + ", ".join(f"{cell:>{max_width}}" for cell in row) + "]")


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("SEARCH ELEMENT IN MATRIX - TEST CASES")
    print("=" * 60)

    # Row-Column Sorted Matrix
    row_col_sorted = [
        [1, 4, 7, 11],
        [2, 5, 8, 12],
        [3, 6, 9, 16],
        [10, 13, 14, 17]
    ]

    print_matrix(row_col_sorted, "Row-Column Sorted Matrix")

    # Test Case 1: Element exists
    print("\n" + "-" * 40)
    print("Test 1: Search for 5 (exists)")
    print("-" * 40)
    result = search_staircase(row_col_sorted, 5)
    print(f"Result: {result}")
    print(f"Expected: (1, 1)")
    assert result == (1, 1), "Test 1 Failed"
    print("PASSED!")

    # Test Case 2: Element exists at corner
    print("\n" + "-" * 40)
    print("Test 2: Search for 17 (bottom-right corner)")
    print("-" * 40)
    result = search_staircase(row_col_sorted, 17)
    print(f"Result: {result}")
    print(f"Expected: (3, 3)")
    assert result == (3, 3), "Test 2 Failed"
    print("PASSED!")

    # Test Case 3: Element does not exist
    print("\n" + "-" * 40)
    print("Test 3: Search for 20 (does not exist)")
    print("-" * 40)
    result = search_staircase(row_col_sorted, 20)
    print(f"Result: {result}")
    print(f"Expected: None")
    assert result is None, "Test 3 Failed"
    print("PASSED!")

    # Test Case 4: Element smaller than all
    print("\n" + "-" * 40)
    print("Test 4: Search for 0 (smaller than all)")
    print("-" * 40)
    result = search_staircase(row_col_sorted, 0)
    print(f"Result: {result}")
    print(f"Expected: None")
    assert result is None, "Test 4 Failed"
    print("PASSED!")

    # Test Case 5: Compare both staircase variants
    print("\n" + "-" * 40)
    print("Test 5: Compare top-right vs bottom-left start")
    print("-" * 40)
    for target in [1, 9, 14, 100]:
        result_tr = search_staircase(row_col_sorted, target)
        result_bl = search_staircase_bottom_left(row_col_sorted, target)
        print(f"Target {target}: top-right={result_tr}, bottom-left={result_bl}")
        assert result_tr == result_bl, f"Results differ for target {target}"
    print("Both variants produce same results!")

    # Fully Sorted Matrix
    fully_sorted = [
        [1, 3, 5, 7],
        [10, 11, 16, 20],
        [23, 30, 34, 60]
    ]

    print_matrix(fully_sorted, "\nFully Sorted Matrix")

    # Test Case 6: Binary search on fully sorted
    print("\n" + "-" * 40)
    print("Test 6: Binary Search on Fully Sorted Matrix")
    print("-" * 40)
    result = search_binary_2d(fully_sorted, 16)
    print(f"Search for 16: {result}")
    print(f"Expected: (1, 2)")
    assert result == (1, 2), "Test 6 Failed"
    print("PASSED!")

    # Test Case 7: Compare all methods
    print("\n" + "-" * 40)
    print("Test 7: Compare All Methods")
    print("-" * 40)
    test_matrix = [
        [1, 4, 7, 11],
        [2, 5, 8, 12],
        [3, 6, 9, 16],
        [10, 13, 14, 17]
    ]

    targets = [1, 5, 9, 14, 17, 100, 0, 15]
    for target in targets:
        brute = search_brute_force(test_matrix, target)
        binary_row = search_binary_per_row(test_matrix, target)
        staircase = search_staircase(test_matrix, target)
        print(f"Target {target:3d}: brute={brute}, binary_row={binary_row}, staircase={staircase}")
        assert brute == staircase, f"Results differ for {target}"
    print("\nAll methods produce consistent results!")

    # Detailed trace
    print("\n" + "-" * 40)
    print("DETAILED TRACE")
    print("-" * 40)
    search_with_trace(row_col_sorted, 9)

    # Edge cases
    print("\n" + "-" * 40)
    print("Edge Cases")
    print("-" * 40)

    # Single element
    single = [[42]]
    print(f"Single element matrix, search 42: {search_staircase(single, 42)}")
    print(f"Single element matrix, search 1: {search_staircase(single, 1)}")

    # Single row
    single_row = [[1, 2, 3, 4, 5]]
    print(f"Single row, search 3: {search_staircase(single_row, 3)}")

    # Single column
    single_col = [[1], [2], [3], [4]]
    print(f"Single column, search 3: {search_staircase(single_col, 3)}")

    # Empty
    print(f"Empty matrix: {search_staircase([], 5)}")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)
