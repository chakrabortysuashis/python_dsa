# Find a Specific Pair in Matrix

## Problem Statement

Given an `n x n` matrix where every row and column is sorted in increasing order, find the maximum value of `matrix[c][d] - matrix[a][b]` over all choices of indices such that both `c > a` and `d > b`.

### Example

```
Matrix:
[1,  2,  -1, -4, -20]
[-8, -3, 4,  2,  1]
[3,  8,  6,  1,  3]
[-4, -1, 1,  7,  -6]
[0,  -4, 10, -5, 1]

Maximum difference = 18
(matrix[4][2] - matrix[1][0] = 10 - (-8) = 18)
```

---

## Key Insight

For each cell (c, d), we need the **minimum value** among all cells (a, b) where a < c and b < d.

We can precompute this using DP!

---

## Approach 1: Brute Force

Check all pairs where c > a and d > b.

```python
def max_diff_brute(matrix):
    n = len(matrix)
    max_diff = float('-inf')

    for a in range(n):
        for b in range(n):
            for c in range(a + 1, n):
                for d in range(b + 1, n):
                    diff = matrix[c][d] - matrix[a][b]
                    max_diff = max(max_diff, diff)

    return max_diff
```

- **Time**: O(n^4)
- **Space**: O(1)

---

## Approach 2: Precompute Minimum (Optimal)

### Algorithm

1. Create a `min_val` matrix where `min_val[i][j]` = minimum of all elements at positions (a, b) where a <= i and b <= j
2. Process from bottom-right to top-left
3. For each cell, compute max_diff using precomputed minimums

### Building min_val Matrix

```
For cell (i, j), we need min of:
- matrix[i][j] itself
- min_val[i+1][j] (below)
- min_val[i][j+1] (right)

Process bottom-right to top-left!
```

### Implementation

```python
def max_diff(matrix):
    n = len(matrix)
    if n < 2:
        return 0

    # min_val[i][j] = min value from (i,j) to (n-1, n-1)
    min_val = [[0] * n for _ in range(n)]
    max_diff = float('-inf')

    # Initialize last cell
    min_val[n-1][n-1] = matrix[n-1][n-1]

    # Fill last row (right to left)
    for j in range(n-2, -1, -1):
        min_val[n-1][j] = min(matrix[n-1][j], min_val[n-1][j+1])

    # Fill last column (bottom to top)
    for i in range(n-2, -1, -1):
        min_val[i][n-1] = min(matrix[i][n-1], min_val[i+1][n-1])

    # Fill rest and compute max_diff
    for i in range(n-2, -1, -1):
        for j in range(n-2, -1, -1):
            # For position (i,j), the valid "second" cells are at (i+1, j+1) onwards
            # Compute difference: matrix[c][d] - matrix[i][j] where c > i, d > j
            max_diff = max(max_diff, min_val[i+1][j+1] - matrix[i][j])

            # Update min_val for this cell
            min_val[i][j] = min(matrix[i][j],
                              min(min_val[i+1][j], min_val[i][j+1]))

    return max_diff
```

Wait, we need **maximum** difference, so we need to maximize `matrix[c][d] - matrix[a][b]`.

Actually, we should precompute the **maximum** from bottom-right for the subtrahend!

### Corrected Approach

```python
def max_diff(matrix):
    n = len(matrix)
    if n < 2:
        return 0

    # max_val[i][j] = max value at positions (c,d) where c >= i, d >= j
    max_val = [[0] * n for _ in range(n)]
    result = float('-inf')

    # Initialize
    max_val[n-1][n-1] = matrix[n-1][n-1]

    # Last row
    for j in range(n-2, -1, -1):
        max_val[n-1][j] = max(matrix[n-1][j], max_val[n-1][j+1])

    # Last column
    for i in range(n-2, -1, -1):
        max_val[i][n-1] = max(matrix[i][n-1], max_val[i+1][n-1])

    # Fill rest
    for i in range(n-2, -1, -1):
        for j in range(n-2, -1, -1):
            # max_diff using (i,j) as (a,b) and some (c,d) where c>i, d>j
            result = max(result, max_val[i+1][j+1] - matrix[i][j])

            # Update max_val
            max_val[i][j] = max(matrix[i][j],
                              max(max_val[i+1][j], max_val[i][j+1]))

    return result
```

---

## Complexity

- **Time**: O(n^2)
- **Space**: O(n^2) for max_val matrix

---

## Key Takeaways

1. **Precomputation** converts O(n^4) to O(n^2)
2. Process in reverse order (bottom-right to top-left) for correct DP transitions
3. This pattern applies to many "find pair with constraints" problems
