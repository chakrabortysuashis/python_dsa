"""
Find a Specific Pair in Matrix
==============================

Problem: Find max(matrix[c][d] - matrix[a][b]) where c > a and d > b.

Optimal: Precompute max values from bottom-right - O(n^2)
"""

from typing import List


def max_diff_brute(matrix: List[List[int]]) -> int:
    """Brute Force: Check all valid pairs. O(n^4) time."""
    n = len(matrix)
    max_diff = float('-inf')

    for a in range(n):
        for b in range(n):
            for c in range(a + 1, n):
                for d in range(b + 1, n):
                    diff = matrix[c][d] - matrix[a][b]
                    max_diff = max(max_diff, diff)

    return max_diff if max_diff != float('-inf') else 0


def max_diff(matrix: List[List[int]]) -> int:
    """
    Optimal: Precompute max values using DP.

    For each (a,b), we need max(matrix[c][d]) where c > a, d > b.
    Precompute this from bottom-right to top-left.

    Time: O(n^2), Space: O(n^2)

    Example:
        >>> max_diff([[1,2,-1,-4,-20],[-8,-3,4,2,1],[3,8,6,1,3],[-4,-1,1,7,-6],[0,-4,10,-5,1]])
        18
    """
    n = len(matrix)
    if n < 2:
        return 0

    # max_val[i][j] = max at positions (c,d) where c >= i, d >= j
    max_val = [[0] * n for _ in range(n)]
    result = float('-inf')

    # Initialize bottom-right
    max_val[n-1][n-1] = matrix[n-1][n-1]

    # Last row (right to left)
    for j in range(n-2, -1, -1):
        max_val[n-1][j] = max(matrix[n-1][j], max_val[n-1][j+1])

    # Last column (bottom to top)
    for i in range(n-2, -1, -1):
        max_val[i][n-1] = max(matrix[i][n-1], max_val[i+1][n-1])

    # Fill rest (bottom-right to top-left)
    for i in range(n-2, -1, -1):
        for j in range(n-2, -1, -1):
            # Compute max_diff using (i,j) as (a,b)
            # Need max at positions strictly greater in both dimensions
            result = max(result, max_val[i+1][j+1] - matrix[i][j])

            # Update max_val for this cell
            max_val[i][j] = max(matrix[i][j],
                              max(max_val[i+1][j], max_val[i][j+1]))

    return result if result != float('-inf') else 0


def max_diff_with_trace(matrix: List[List[int]]) -> int:
    """Educational version with trace."""
    n = len(matrix)
    if n < 2:
        return 0

    max_val = [[0] * n for _ in range(n)]
    result = float('-inf')
    best_pair = None

    max_val[n-1][n-1] = matrix[n-1][n-1]

    for j in range(n-2, -1, -1):
        max_val[n-1][j] = max(matrix[n-1][j], max_val[n-1][j+1])

    for i in range(n-2, -1, -1):
        max_val[i][n-1] = max(matrix[i][n-1], max_val[i+1][n-1])

    for i in range(n-2, -1, -1):
        for j in range(n-2, -1, -1):
            diff = max_val[i+1][j+1] - matrix[i][j]
            if diff > result:
                result = diff
                best_pair = ((i, j), max_val[i+1][j+1])
            max_val[i][j] = max(matrix[i][j],
                              max(max_val[i+1][j], max_val[i][j+1]))

    print(f"Best pair: matrix[?][?] - matrix{best_pair[0]} = {result}")
    return result


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 50)
    print("FIND SPECIFIC PAIR IN MATRIX")
    print("=" * 50)

    matrix = [
        [1, 2, -1, -4, -20],
        [-8, -3, 4, 2, 1],
        [3, 8, 6, 1, 3],
        [-4, -1, 1, 7, -6],
        [0, -4, 10, -5, 1]
    ]

    print("\nMatrix:")
    for row in matrix:
        print(row)

    result = max_diff(matrix)
    print(f"\nMaximum difference: {result}")
    print("Expected: 18 (10 - (-8))")
    assert result == 18, "Test Failed"
    print("PASSED!")

    # Compare methods
    print("\n" + "-" * 40)
    brute = max_diff_brute(matrix)
    optimal = max_diff(matrix)
    print(f"Brute: {brute}, Optimal: {optimal}")
    assert brute == optimal

    # Trace
    print("\nDetailed trace:")
    max_diff_with_trace(matrix)
