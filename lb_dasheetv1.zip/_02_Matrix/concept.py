"""
Matrix (2D Array) - Complete Implementation Guide
=================================================

This module covers:
1. Matrix creation and initialization
2. All traversal patterns
3. Common matrix operations
4. Direction vectors for navigation
5. Utility functions

Author: DSA Learning Course
"""

from typing import List, Tuple, Optional
import copy


# =============================================================================
# SECTION 1: MATRIX CREATION AND INITIALIZATION
# =============================================================================

def create_matrix(rows: int, cols: int, default_value: int = 0) -> List[List[int]]:
    """
    Create a matrix with given dimensions filled with default value.

    Time Complexity: O(rows * cols)
    Space Complexity: O(rows * cols)

    Args:
        rows: Number of rows
        cols: Number of columns
        default_value: Initial value for all cells

    Returns:
        2D list representing the matrix

    Example:
        >>> create_matrix(2, 3, 0)
        [[0, 0, 0], [0, 0, 0]]
    """
    return [[default_value for _ in range(cols)] for _ in range(rows)]


def create_matrix_from_values(values: List[int], rows: int, cols: int) -> List[List[int]]:
    """
    Create a matrix from a flat list of values (row-major order).

    Example:
        >>> create_matrix_from_values([1,2,3,4,5,6], 2, 3)
        [[1, 2, 3], [4, 5, 6]]
    """
    if len(values) != rows * cols:
        raise ValueError(f"Expected {rows * cols} values, got {len(values)}")

    matrix = []
    for i in range(rows):
        row = values[i * cols : (i + 1) * cols]
        matrix.append(row)
    return matrix


def print_matrix(matrix: List[List[int]], title: str = "") -> None:
    """
    Pretty print a matrix with aligned columns.

    Example output:
        Matrix A:
        [  1,   2,   3 ]
        [  4,   5,   6 ]
        [  7,   8,   9 ]
    """
    if not matrix:
        print("Empty matrix")
        return

    if title:
        print(f"{title}:")

    # Find max width for alignment
    max_width = max(len(str(cell)) for row in matrix for cell in row)

    for row in matrix:
        formatted = ", ".join(f"{cell:>{max_width}}" for cell in row)
        print(f"[ {formatted} ]")
    print()


# =============================================================================
# SECTION 2: MATRIX INDEXING
# =============================================================================

def get_dimensions(matrix: List[List[int]]) -> Tuple[int, int]:
    """
    Get matrix dimensions (rows, cols).

    Returns:
        Tuple of (number_of_rows, number_of_columns)
    """
    if not matrix:
        return (0, 0)
    return (len(matrix), len(matrix[0]))


def is_valid_position(matrix: List[List[int]], row: int, col: int) -> bool:
    """
    Check if (row, col) is a valid position in the matrix.

    Time Complexity: O(1)
    """
    rows, cols = get_dimensions(matrix)
    return 0 <= row < rows and 0 <= col < cols


def get_corners(matrix: List[List[int]]) -> dict:
    """
    Get all four corner positions and values.

    Returns:
        Dictionary with corner names as keys
    """
    if not matrix:
        return {}

    rows, cols = get_dimensions(matrix)
    return {
        'top_left': ((0, 0), matrix[0][0]),
        'top_right': ((0, cols - 1), matrix[0][cols - 1]),
        'bottom_left': ((rows - 1, 0), matrix[rows - 1][0]),
        'bottom_right': ((rows - 1, cols - 1), matrix[rows - 1][cols - 1])
    }


def get_index_from_1d(linear_index: int, cols: int) -> Tuple[int, int]:
    """
    Convert 1D linear index to 2D (row, col) index.

    Formula: row = index // cols, col = index % cols

    Example:
        >>> get_index_from_1d(5, 3)  # 6th element in 3-column matrix
        (1, 2)  # Row 1, Column 2
    """
    return (linear_index // cols, linear_index % cols)


def get_index_to_1d(row: int, col: int, cols: int) -> int:
    """
    Convert 2D (row, col) to 1D linear index (row-major).

    Formula: index = row * cols + col

    Example:
        >>> get_index_to_1d(1, 2, 3)  # Row 1, Col 2 in 3-column matrix
        5
    """
    return row * cols + col


# =============================================================================
# SECTION 3: DIRECTION VECTORS
# =============================================================================

# 4 cardinal directions: Up, Right, Down, Left
DIRECTIONS_4 = [(-1, 0), (0, 1), (1, 0), (0, -1)]
DIRECTION_NAMES_4 = ['Up', 'Right', 'Down', 'Left']

# 8 directions including diagonals
DIRECTIONS_8 = [
    (-1, 0),   # Up
    (-1, 1),   # Up-Right
    (0, 1),    # Right
    (1, 1),    # Down-Right
    (1, 0),    # Down
    (1, -1),   # Down-Left
    (0, -1),   # Left
    (-1, -1)   # Up-Left
]
DIRECTION_NAMES_8 = ['Up', 'Up-Right', 'Right', 'Down-Right',
                     'Down', 'Down-Left', 'Left', 'Up-Left']


def get_neighbors_4(matrix: List[List[int]], row: int, col: int) -> List[Tuple[int, int, int]]:
    """
    Get all valid 4-directional neighbors of a cell.

    Returns:
        List of (row, col, value) tuples for valid neighbors

    Example:
        >>> matrix = [[1,2,3], [4,5,6], [7,8,9]]
        >>> get_neighbors_4(matrix, 1, 1)  # Neighbors of 5
        [(0, 1, 2), (1, 2, 6), (2, 1, 8), (1, 0, 4)]
    """
    neighbors = []
    for di, dj in DIRECTIONS_4:
        ni, nj = row + di, col + dj
        if is_valid_position(matrix, ni, nj):
            neighbors.append((ni, nj, matrix[ni][nj]))
    return neighbors


def get_neighbors_8(matrix: List[List[int]], row: int, col: int) -> List[Tuple[int, int, int]]:
    """
    Get all valid 8-directional neighbors (including diagonals).

    Returns:
        List of (row, col, value) tuples for valid neighbors
    """
    neighbors = []
    for di, dj in DIRECTIONS_8:
        ni, nj = row + di, col + dj
        if is_valid_position(matrix, ni, nj):
            neighbors.append((ni, nj, matrix[ni][nj]))
    return neighbors


# =============================================================================
# SECTION 4: TRAVERSAL PATTERNS
# =============================================================================

def traverse_row_wise(matrix: List[List[int]]) -> List[int]:
    """
    Traverse matrix row by row, left to right.

    Pattern:
        [1] -> [2] -> [3]
        [4] -> [5] -> [6]
        [7] -> [8] -> [9]

    Time Complexity: O(m * n)
    Space Complexity: O(1) for traversal, O(m * n) for result storage

    Example:
        >>> traverse_row_wise([[1,2,3], [4,5,6], [7,8,9]])
        [1, 2, 3, 4, 5, 6, 7, 8, 9]
    """
    if not matrix:
        return []

    result = []
    rows, cols = get_dimensions(matrix)

    for i in range(rows):
        for j in range(cols):
            result.append(matrix[i][j])

    return result


def traverse_column_wise(matrix: List[List[int]]) -> List[int]:
    """
    Traverse matrix column by column, top to bottom.

    Pattern:
        [1]    [2]    [3]
         |      |      |
         v      v      v
        [4]    [5]    [6]
         |      |      |
         v      v      v
        [7]    [8]    [9]

    Time Complexity: O(m * n)
    Space Complexity: O(m * n)

    Note: Less cache-friendly in Python/C (row-major languages)

    Example:
        >>> traverse_column_wise([[1,2,3], [4,5,6], [7,8,9]])
        [1, 4, 7, 2, 5, 8, 3, 6, 9]
    """
    if not matrix:
        return []

    result = []
    rows, cols = get_dimensions(matrix)

    for j in range(cols):
        for i in range(rows):
            result.append(matrix[i][j])

    return result


def traverse_primary_diagonal(matrix: List[List[int]]) -> List[int]:
    """
    Traverse primary diagonal (where row index == column index).

    Pattern for 3x3:
        [1]  .   .
         .  [5]  .
         .   .  [9]

    Time Complexity: O(min(m, n))
    Space Complexity: O(min(m, n))

    Example:
        >>> traverse_primary_diagonal([[1,2,3], [4,5,6], [7,8,9]])
        [1, 5, 9]
    """
    if not matrix:
        return []

    rows, cols = get_dimensions(matrix)
    n = min(rows, cols)

    return [matrix[i][i] for i in range(n)]


def traverse_anti_diagonal(matrix: List[List[int]]) -> List[int]:
    """
    Traverse anti-diagonal (where row + col == n - 1).

    Pattern for 3x3:
         .   .  [3]
         .  [5]  .
        [7]  .   .

    Time Complexity: O(min(m, n))
    Space Complexity: O(min(m, n))

    Example:
        >>> traverse_anti_diagonal([[1,2,3], [4,5,6], [7,8,9]])
        [3, 5, 7]
    """
    if not matrix:
        return []

    rows, cols = get_dimensions(matrix)
    n = min(rows, cols)

    return [matrix[i][cols - 1 - i] for i in range(n)]


def traverse_all_diagonals(matrix: List[List[int]]) -> List[List[int]]:
    """
    Traverse all diagonals from top-left to bottom-right.

    Example for 3x3:
        Diagonal 0: [1]
        Diagonal 1: [2, 4]
        Diagonal 2: [3, 5, 7]
        Diagonal 3: [6, 8]
        Diagonal 4: [9]

    Time Complexity: O(m * n)
    Space Complexity: O(m * n)
    """
    if not matrix:
        return []

    rows, cols = get_dimensions(matrix)
    diagonals = [[] for _ in range(rows + cols - 1)]

    for i in range(rows):
        for j in range(cols):
            diagonals[i + j].append(matrix[i][j])

    return diagonals


def traverse_spiral(matrix: List[List[int]]) -> List[int]:
    """
    Traverse matrix in clockwise spiral from outer to inner.

    Pattern:
        [1] -> [2] -> [3]
                       |
                       v
        [8] -> [9]    [4]
         ^            |
         |            v
        [7] <- [6] <- [5]

    Algorithm: Use boundary pointers (top, bottom, left, right)
    and shrink them after each direction is complete.

    Time Complexity: O(m * n)
    Space Complexity: O(1) for traversal, O(m * n) for result

    Example:
        >>> traverse_spiral([[1,2,3], [4,5,6], [7,8,9]])
        [1, 2, 3, 6, 9, 8, 7, 4, 5]
    """
    if not matrix or not matrix[0]:
        return []

    result = []
    top, bottom = 0, len(matrix) - 1
    left, right = 0, len(matrix[0]) - 1

    while top <= bottom and left <= right:
        # Traverse right along top row
        for j in range(left, right + 1):
            result.append(matrix[top][j])
        top += 1

        # Traverse down along right column
        for i in range(top, bottom + 1):
            result.append(matrix[i][right])
        right -= 1

        # Traverse left along bottom row (if rows remain)
        if top <= bottom:
            for j in range(right, left - 1, -1):
                result.append(matrix[bottom][j])
            bottom -= 1

        # Traverse up along left column (if columns remain)
        if left <= right:
            for i in range(bottom, top - 1, -1):
                result.append(matrix[i][left])
            left += 1

    return result


def traverse_zigzag(matrix: List[List[int]]) -> List[int]:
    """
    Traverse matrix in zigzag/snake pattern (alternating direction per row).

    Pattern:
        [1] -> [2] -> [3]
                      |
                      v
        [6] <- [5] <- [4]
         |
         v
        [7] -> [8] -> [9]

    Time Complexity: O(m * n)
    Space Complexity: O(m * n)

    Example:
        >>> traverse_zigzag([[1,2,3], [4,5,6], [7,8,9]])
        [1, 2, 3, 6, 5, 4, 7, 8, 9]
    """
    if not matrix:
        return []

    result = []
    for i, row in enumerate(matrix):
        if i % 2 == 0:
            result.extend(row)           # Left to right
        else:
            result.extend(row[::-1])     # Right to left

    return result


def traverse_boundary(matrix: List[List[int]]) -> List[int]:
    """
    Traverse only the boundary elements of the matrix.

    Pattern for 3x4:
        [1] -> [2] -> [3] -> [4]
         ^                    |
         |    [X]    [X]      v
         |                    |
        [9] <- [10]<- [11]<- [12]

    Time Complexity: O(m + n)
    Space Complexity: O(m + n)

    Example:
        >>> traverse_boundary([[1,2,3,4], [5,6,7,8], [9,10,11,12]])
        [1, 2, 3, 4, 8, 12, 11, 10, 9, 5]
    """
    if not matrix or not matrix[0]:
        return []

    rows, cols = get_dimensions(matrix)

    # Handle single row or single column
    if rows == 1:
        return matrix[0][:]
    if cols == 1:
        return [matrix[i][0] for i in range(rows)]

    result = []

    # Top row (left to right)
    for j in range(cols):
        result.append(matrix[0][j])

    # Right column (top+1 to bottom)
    for i in range(1, rows):
        result.append(matrix[i][cols - 1])

    # Bottom row (right-1 to left, excluding last column)
    for j in range(cols - 2, -1, -1):
        result.append(matrix[rows - 1][j])

    # Left column (bottom-1 to top+1)
    for i in range(rows - 2, 0, -1):
        result.append(matrix[i][0])

    return result


# =============================================================================
# SECTION 5: COMMON MATRIX OPERATIONS
# =============================================================================

def transpose(matrix: List[List[int]]) -> List[List[int]]:
    """
    Transpose a matrix (swap rows and columns).

    A[i][j] becomes A[j][i]

    Original (2x3):    Transposed (3x2):
    [1, 2, 3]          [1, 4]
    [4, 5, 6]          [2, 5]
                       [3, 6]

    Time Complexity: O(m * n)
    Space Complexity: O(m * n)

    Example:
        >>> transpose([[1,2,3], [4,5,6]])
        [[1, 4], [2, 5], [3, 6]]
    """
    if not matrix:
        return []

    rows, cols = get_dimensions(matrix)
    result = [[0] * rows for _ in range(cols)]

    for i in range(rows):
        for j in range(cols):
            result[j][i] = matrix[i][j]

    return result


def transpose_in_place(matrix: List[List[int]]) -> None:
    """
    Transpose a SQUARE matrix in-place.

    Time Complexity: O(n^2)
    Space Complexity: O(1)

    Note: Only works for square matrices!
    """
    n = len(matrix)
    if n != len(matrix[0]):
        raise ValueError("In-place transpose only works for square matrices")

    for i in range(n):
        for j in range(i + 1, n):
            matrix[i][j], matrix[j][i] = matrix[j][i], matrix[i][j]


def rotate_90_clockwise(matrix: List[List[int]]) -> List[List[int]]:
    """
    Rotate matrix 90 degrees clockwise.

    Method: Transpose + Reverse each row

    Original:    Transposed:   Rotated 90 CW:
    [1, 2, 3]    [1, 4, 7]     [7, 4, 1]
    [4, 5, 6]    [2, 5, 8]     [8, 5, 2]
    [7, 8, 9]    [3, 6, 9]     [9, 6, 3]

    Time Complexity: O(n^2)
    Space Complexity: O(n^2) for new matrix, O(1) if done in-place

    Example:
        >>> rotate_90_clockwise([[1,2,3], [4,5,6], [7,8,9]])
        [[7, 4, 1], [8, 5, 2], [9, 6, 3]]
    """
    if not matrix:
        return []

    # Transpose
    transposed = transpose(matrix)

    # Reverse each row
    for row in transposed:
        row.reverse()

    return transposed


def rotate_90_counterclockwise(matrix: List[List[int]]) -> List[List[int]]:
    """
    Rotate matrix 90 degrees counter-clockwise.

    Method: Transpose + Reverse each column
    OR: Reverse each row + Transpose

    Time Complexity: O(n^2)
    Space Complexity: O(n^2)

    Example:
        >>> rotate_90_counterclockwise([[1,2,3], [4,5,6], [7,8,9]])
        [[3, 6, 9], [2, 5, 8], [1, 4, 7]]
    """
    if not matrix:
        return []

    # Reverse each row first
    reversed_rows = [row[::-1] for row in matrix]

    # Then transpose
    return transpose(reversed_rows)


def rotate_180(matrix: List[List[int]]) -> List[List[int]]:
    """
    Rotate matrix 180 degrees.

    Method: Reverse rows, then reverse each row

    Time Complexity: O(n^2)
    Space Complexity: O(n^2)

    Example:
        >>> rotate_180([[1,2,3], [4,5,6], [7,8,9]])
        [[9, 8, 7], [6, 5, 4], [3, 2, 1]]
    """
    if not matrix:
        return []

    # Reverse order of rows
    result = matrix[::-1]

    # Reverse each row
    return [row[::-1] for row in result]


def flip_horizontal(matrix: List[List[int]]) -> List[List[int]]:
    """
    Flip matrix horizontally (mirror along vertical axis).

    Time Complexity: O(m * n)
    Space Complexity: O(m * n)

    Example:
        >>> flip_horizontal([[1,2,3], [4,5,6]])
        [[3, 2, 1], [6, 5, 4]]
    """
    return [row[::-1] for row in matrix]


def flip_vertical(matrix: List[List[int]]) -> List[List[int]]:
    """
    Flip matrix vertically (mirror along horizontal axis).

    Time Complexity: O(m * n)
    Space Complexity: O(m * n)

    Example:
        >>> flip_vertical([[1,2,3], [4,5,6]])
        [[4, 5, 6], [1, 2, 3]]
    """
    return matrix[::-1]


# =============================================================================
# SECTION 6: SEARCH OPERATIONS
# =============================================================================

def linear_search(matrix: List[List[int]], target: int) -> Optional[Tuple[int, int]]:
    """
    Search for target in an unsorted matrix.

    Time Complexity: O(m * n)
    Space Complexity: O(1)

    Returns:
        (row, col) if found, None otherwise
    """
    for i, row in enumerate(matrix):
        for j, val in enumerate(row):
            if val == target:
                return (i, j)
    return None


def staircase_search(matrix: List[List[int]], target: int) -> Optional[Tuple[int, int]]:
    """
    Search in a matrix where each row and column is sorted.

    Start from top-right (or bottom-left) corner:
    - If current == target: found!
    - If current > target: go left (smaller values)
    - If current < target: go down (larger values)

    Time Complexity: O(m + n)
    Space Complexity: O(1)

    Example:
        matrix = [[1, 4, 7, 11],
                  [2, 5, 8, 12],
                  [3, 6, 9, 16]]

        >>> staircase_search(matrix, 5)
        (1, 1)
    """
    if not matrix or not matrix[0]:
        return None

    rows, cols = get_dimensions(matrix)

    # Start from top-right corner
    i, j = 0, cols - 1

    while i < rows and j >= 0:
        if matrix[i][j] == target:
            return (i, j)
        elif matrix[i][j] > target:
            j -= 1  # Go left (smaller values)
        else:
            i += 1  # Go down (larger values)

    return None


def binary_search_matrix(matrix: List[List[int]], target: int) -> Optional[Tuple[int, int]]:
    """
    Search in a fully sorted matrix (each row starts after previous row ends).

    Treat matrix as a 1D sorted array and perform binary search.

    Time Complexity: O(log(m * n))
    Space Complexity: O(1)

    Example:
        matrix = [[1, 3, 5, 7],
                  [10, 11, 16, 20],
                  [23, 30, 34, 60]]

        >>> binary_search_matrix(matrix, 3)
        (0, 1)
    """
    if not matrix or not matrix[0]:
        return None

    rows, cols = get_dimensions(matrix)
    left, right = 0, rows * cols - 1

    while left <= right:
        mid = (left + right) // 2
        row, col = mid // cols, mid % cols

        if matrix[row][col] == target:
            return (row, col)
        elif matrix[row][col] < target:
            left = mid + 1
        else:
            right = mid - 1

    return None


# =============================================================================
# SECTION 7: UTILITY FUNCTIONS
# =============================================================================

def copy_matrix(matrix: List[List[int]]) -> List[List[int]]:
    """
    Create a deep copy of a matrix.

    Time Complexity: O(m * n)
    Space Complexity: O(m * n)
    """
    return copy.deepcopy(matrix)


def compare_matrices(matrix1: List[List[int]], matrix2: List[List[int]]) -> bool:
    """
    Check if two matrices are equal.

    Time Complexity: O(m * n)
    Space Complexity: O(1)
    """
    if get_dimensions(matrix1) != get_dimensions(matrix2):
        return False

    for i in range(len(matrix1)):
        for j in range(len(matrix1[0])):
            if matrix1[i][j] != matrix2[i][j]:
                return False
    return True


def flatten(matrix: List[List[int]]) -> List[int]:
    """
    Convert 2D matrix to 1D list (row-major order).

    Time Complexity: O(m * n)
    Space Complexity: O(m * n)

    Example:
        >>> flatten([[1,2,3], [4,5,6]])
        [1, 2, 3, 4, 5, 6]
    """
    return [cell for row in matrix for cell in row]


def sum_all_elements(matrix: List[List[int]]) -> int:
    """
    Calculate sum of all matrix elements.

    Time Complexity: O(m * n)
    Space Complexity: O(1)
    """
    return sum(sum(row) for row in matrix)


def max_element(matrix: List[List[int]]) -> Tuple[int, Tuple[int, int]]:
    """
    Find maximum element and its position.

    Time Complexity: O(m * n)
    Space Complexity: O(1)

    Returns:
        (max_value, (row, col))
    """
    max_val = float('-inf')
    max_pos = (0, 0)

    for i, row in enumerate(matrix):
        for j, val in enumerate(row):
            if val > max_val:
                max_val = val
                max_pos = (i, j)

    return (max_val, max_pos)


def min_element(matrix: List[List[int]]) -> Tuple[int, Tuple[int, int]]:
    """
    Find minimum element and its position.

    Time Complexity: O(m * n)
    Space Complexity: O(1)

    Returns:
        (min_value, (row, col))
    """
    min_val = float('inf')
    min_pos = (0, 0)

    for i, row in enumerate(matrix):
        for j, val in enumerate(row):
            if val < min_val:
                min_val = val
                min_pos = (i, j)

    return (min_val, min_pos)


# =============================================================================
# DEMONSTRATION
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("MATRIX CONCEPTS - DEMONSTRATION")
    print("=" * 60)

    # Create sample matrix
    matrix = [
        [1, 2, 3, 4],
        [5, 6, 7, 8],
        [9, 10, 11, 12]
    ]

    print_matrix(matrix, "Original Matrix (3x4)")

    # Traversal demonstrations
    print("-" * 40)
    print("TRAVERSAL PATTERNS:")
    print("-" * 40)

    print(f"Row-wise:    {traverse_row_wise(matrix)}")
    print(f"Column-wise: {traverse_column_wise(matrix)}")
    print(f"Spiral:      {traverse_spiral(matrix)}")
    print(f"Zigzag:      {traverse_zigzag(matrix)}")
    print(f"Boundary:    {traverse_boundary(matrix)}")

    # Square matrix for diagonal operations
    square = [
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9]
    ]

    print()
    print_matrix(square, "Square Matrix (3x3)")

    print(f"Primary diagonal: {traverse_primary_diagonal(square)}")
    print(f"Anti-diagonal:    {traverse_anti_diagonal(square)}")

    # Rotation demonstrations
    print()
    print("-" * 40)
    print("ROTATION OPERATIONS:")
    print("-" * 40)

    print_matrix(rotate_90_clockwise(square), "Rotated 90 CW")
    print_matrix(rotate_90_counterclockwise(square), "Rotated 90 CCW")
    print_matrix(transpose(square), "Transposed")

    # Search demonstrations
    print("-" * 40)
    print("SEARCH OPERATIONS:")
    print("-" * 40)

    sorted_matrix = [
        [1, 4, 7, 11],
        [2, 5, 8, 12],
        [3, 6, 9, 16],
        [10, 13, 14, 17]
    ]

    print_matrix(sorted_matrix, "Row-Column Sorted Matrix")

    target = 5
    result = staircase_search(sorted_matrix, target)
    print(f"Staircase search for {target}: {result}")

    fully_sorted = [
        [1, 3, 5, 7],
        [10, 11, 16, 20],
        [23, 30, 34, 60]
    ]

    print_matrix(fully_sorted, "Fully Sorted Matrix")

    target = 16
    result = binary_search_matrix(fully_sorted, target)
    print(f"Binary search for {target}: {result}")

    # Neighbor demonstration
    print()
    print("-" * 40)
    print("DIRECTION VECTORS:")
    print("-" * 40)

    print(f"4-directional vectors: {DIRECTIONS_4}")
    print(f"8-directional vectors: {DIRECTIONS_8}")

    print(f"\nNeighbors of center (1,1) in 3x3 matrix:")
    print(f"4-neighbors: {get_neighbors_4(square, 1, 1)}")
    print(f"8-neighbors: {get_neighbors_8(square, 1, 1)}")

    print()
    print("=" * 60)
    print("DEMONSTRATION COMPLETE")
    print("=" * 60)
