# Find Row with Maximum Number of 1's

## Problem Statement

Given a boolean matrix where each row is sorted (0s followed by 1s), find the row with the maximum number of 1s.

### Example

```
Matrix:
[0, 0, 0, 1]
[0, 1, 1, 1]   <- Maximum 1s (3)
[1, 1, 1, 1]   <- Also has 4, but first occurrence wins
[0, 0, 1, 1]

Answer: Row 2 (0-indexed) has maximum 4 ones
```

---

## Key Insight

Since each row is sorted (0s come before 1s), the **first 1 in each row** determines the count:
```
Count of 1s in row = total_columns - position_of_first_1
```

We can use **binary search** to find the first 1 efficiently!

---

## Approach 1: Brute Force

### Algorithm
Count 1s in each row linearly.

```python
def row_with_max_ones_brute(matrix):
    max_count = 0
    max_row = -1
    
    for i, row in enumerate(matrix):
        count = sum(row)  # or row.count(1)
        if count > max_count:
            max_count = count
            max_row = i
    
    return max_row
```

### Complexity
- **Time**: O(m * n)
- **Space**: O(1)

---

## Approach 2: Binary Search per Row

### Algorithm
For each row, binary search to find the first 1.

```python
def row_with_max_ones_binary(matrix):
    max_count = 0
    max_row = -1
    
    for i, row in enumerate(matrix):
        # Find first occurrence of 1 using binary search
        first_one = binary_search_first_one(row)
        
        if first_one != -1:
            count = len(row) - first_one
            if count > max_count:
                max_count = count
                max_row = i
    
    return max_row
```

### Complexity
- **Time**: O(m * log n)
- **Space**: O(1)

---

## Approach 3: Staircase Optimization (Optimal)

### Key Insight
Start from the **top-right corner**:
- If we see a 1, move **left** (might find more 1s in this row)
- If we see a 0, move **down** (this row has fewer 1s than current best)

This ensures we only visit O(m + n) cells!

### Visual Walkthrough

```
Start at top-right:
        [0, 0, 0, 1*]  <- Start here
        [0, 1, 1, 1]
        [1, 1, 1, 1]
        [0, 0, 1, 1]

Step 1: (0,3)=1, move left, best_row=0
        [0, 0, 0*, 1]
        [0, 1, 1, 1]
        ...

Step 2: (0,2)=0, move down
        [0, 0, 0, 1]
        [0, 1, 1*, 1]  <- Now here
        ...

Step 3: (1,2)=1, move left, best_row=1
Step 4: (1,1)=1, move left, best_row=1
Step 5: (1,0)=0, move down
Step 6: (2,0)=1, move left, best_row=2
... and so on
```

### Implementation

```python
def row_with_max_ones(matrix):
    if not matrix or not matrix[0]:
        return -1
    
    rows, cols = len(matrix), len(matrix[0])
    max_row = -1
    j = cols - 1  # Start from rightmost column
    
    for i in range(rows):
        # Move left while seeing 1s
        while j >= 0 and matrix[i][j] == 1:
            max_row = i  # This row has more 1s
            j -= 1
    
    return max_row
```

### Complexity
- **Time**: O(m + n) - each cell visited at most once
- **Space**: O(1)

---

## Step-by-Step Dry Run

### Input
```
Matrix:
[0, 0, 1, 1]
[0, 0, 0, 1]
[1, 1, 1, 1]
[0, 1, 1, 1]
```

### Execution

| Step | Position | Value | Action | max_row | j |
|------|----------|-------|--------|---------|---|
| 1 | (0,3) | 1 | Left, update max_row | 0 | 2 |
| 2 | (0,2) | 1 | Left, update max_row | 0 | 1 |
| 3 | (0,1) | 0 | Down | 0 | 1 |
| 4 | (1,1) | 0 | Down | 0 | 1 |
| 5 | (2,1) | 1 | Left, update max_row | 2 | 0 |
| 6 | (2,0) | 1 | Left, update max_row | 2 | -1 |
| 7 | j < 0 | - | Loop ends | 2 | -1 |

**Result: Row 2**

---

## Edge Cases

1. **All zeros**: Return -1 (no 1s found)
2. **All ones**: Return 0 (first row)
3. **Single row**: Binary search or linear scan
4. **Single column**: Check each row's single element
5. **Equal counts**: Return first row with max count

---

## Comparison

| Approach | Time | Space |
|----------|------|-------|
| Brute Force | O(m*n) | O(1) |
| Binary Search | O(m log n) | O(1) |
| **Staircase** | **O(m+n)** | **O(1)** |

---

## Key Takeaways

1. Sorted rows allow binary search for first occurrence
2. Staircase from top-right leverages the sorted property optimally
3. The column pointer only moves left (never right), ensuring O(m+n) total moves
