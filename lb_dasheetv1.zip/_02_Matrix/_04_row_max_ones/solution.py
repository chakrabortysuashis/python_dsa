"""
Find Row with Maximum Number of 1's
===================================

Problem: Given a boolean matrix where each row is sorted (0s before 1s),
find the row with the maximum number of 1s.

Optimal: Staircase traversal from top-right - O(m + n)
"""

from typing import List
from bisect import bisect_left


def row_with_max_ones_brute(matrix: List[List[int]]) -> int:
    """
    Brute Force: Count 1s in each row.
    Time: O(m * n), Space: O(1)
    """
    if not matrix or not matrix[0]:
        return -1

    max_count = 0
    max_row = -1

    for i, row in enumerate(matrix):
        count = sum(row)
        if count > max_count:
            max_count = count
            max_row = i

    return max_row


def row_with_max_ones_binary(matrix: List[List[int]]) -> int:
    """
    Binary Search: Find first 1 in each row.
    Time: O(m * log n), Space: O(1)
    """
    if not matrix or not matrix[0]:
        return -1

    max_count = 0
    max_row = -1
    cols = len(matrix[0])

    for i, row in enumerate(matrix):
        # Find first 1 using binary search
        first_one = bisect_left(row, 1)

        if first_one < cols:  # Found at least one 1
            count = cols - first_one
            if count > max_count:
                max_count = count
                max_row = i

    return max_row


def row_with_max_ones(matrix: List[List[int]]) -> int:
    """
    Optimal: Staircase from top-right corner.

    Start at top-right:
    - If 1: move left (more 1s in this row), update answer
    - If 0: move down (this row has fewer 1s than best)

    Time: O(m + n) - column pointer only moves left
    Space: O(1)

    Example:
        >>> row_with_max_ones([[0,0,1,1], [0,0,0,1], [1,1,1,1], [0,1,1,1]])
        2
    """
    if not matrix or not matrix[0]:
        return -1

    rows = len(matrix)
    cols = len(matrix[0])

    max_row = -1
    j = cols - 1  # Start from rightmost column

    for i in range(rows):
        # Move left while we see 1s
        while j >= 0 and matrix[i][j] == 1:
            max_row = i  # This row has more 1s
            j -= 1

    return max_row


def row_with_max_ones_with_count(matrix: List[List[int]]) -> tuple:
    """
    Returns both the row index and the count of 1s.
    """
    if not matrix or not matrix[0]:
        return (-1, 0)

    rows = len(matrix)
    cols = len(matrix[0])

    max_row = -1
    j = cols - 1

    for i in range(rows):
        while j >= 0 and matrix[i][j] == 1:
            max_row = i
            j -= 1

    max_count = cols - j - 1 if max_row != -1 else 0
    return (max_row, max_count)


def row_with_max_ones_trace(matrix: List[List[int]]) -> int:
    """Educational version with trace output."""
    if not matrix or not matrix[0]:
        return -1

    rows, cols = len(matrix), len(matrix[0])
    print(f"Matrix: {rows} x {cols}")
    print("Starting from top-right corner")

    max_row = -1
    j = cols - 1

    for i in range(rows):
        print(f"\nRow {i}: {matrix[i]}")
        while j >= 0 and matrix[i][j] == 1:
            print(f"  ({i},{j})=1, move left, max_row={i}")
            max_row = i
            j -= 1
        if j >= 0:
            print(f"  ({i},{j})=0, move to next row")
        else:
            print(f"  Reached leftmost column")

    print(f"\nResult: Row {max_row}")
    return max_row


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 50)
    print("ROW WITH MAXIMUM 1s - TEST CASES")
    print("=" * 50)

    # Test 1
    matrix1 = [[0, 0, 0, 1], [0, 1, 1, 1], [1, 1, 1, 1], [0, 0, 1, 1]]
    print(f"\nMatrix 1: {matrix1}")
    result = row_with_max_ones(matrix1)
    print(f"Row with max 1s: {result}")
    assert result == 2, "Test 1 Failed"
    print("PASSED!")

    # Test 2
    matrix2 = [[0, 0], [1, 1], [0, 1]]
    print(f"\nMatrix 2: {matrix2}")
    result = row_with_max_ones(matrix2)
    print(f"Row with max 1s: {result}")
    assert result == 1, "Test 2 Failed"
    print("PASSED!")

    # Test 3: All zeros
    matrix3 = [[0, 0, 0], [0, 0, 0]]
    print(f"\nMatrix 3 (all zeros): {matrix3}")
    result = row_with_max_ones(matrix3)
    print(f"Row with max 1s: {result}")
    assert result == -1, "Test 3 Failed"
    print("PASSED!")

    # Test 4: All ones
    matrix4 = [[1, 1, 1], [1, 1, 1]]
    print(f"\nMatrix 4 (all ones): {matrix4}")
    result = row_with_max_ones(matrix4)
    print(f"Row with max 1s: {result}")
    assert result == 0, "Test 4 Failed"
    print("PASSED!")

    # Compare methods
    print("\n" + "-" * 40)
    print("Comparing all methods:")
    test = [[0, 0, 1, 1], [0, 0, 0, 1], [1, 1, 1, 1], [0, 1, 1, 1]]
    brute = row_with_max_ones_brute(test)
    binary = row_with_max_ones_binary(test)
    optimal = row_with_max_ones(test)
    print(f"Brute: {brute}, Binary: {binary}, Optimal: {optimal}")
    assert brute == binary == optimal

    # Detailed trace
    print("\n" + "-" * 40)
    print("DETAILED TRACE:")
    row_with_max_ones_trace(test)

    print("\n" + "=" * 50)
    print("ALL TESTS PASSED!")
