# Matrix (2D Arrays) - Complete Concept Guide

## Table of Contents
1. [Introduction to Matrices](#introduction-to-matrices)
2. [Memory Layout](#memory-layout)
3. [Matrix Indexing](#matrix-indexing)
4. [Traversal Patterns](#traversal-patterns)
5. [Time & Space Complexity](#time--space-complexity)
6. [Common Operations](#common-operations)
7. [Key Patterns for Problem Solving](#key-patterns-for-problem-solving)

---

## Introduction to Matrices

A **matrix** (or 2D array) is a rectangular arrangement of elements in rows and columns. It's one of the most fundamental data structures used in:
- Image processing
- Graph representations
- Dynamic programming
- Game development
- Scientific computing

### Basic Terminology
```
Matrix A (3x4):
         col 0   col 1   col 2   col 3
        +-------+-------+-------+-------+
row 0   |   1   |   2   |   3   |   4   |
        +-------+-------+-------+-------+
row 1   |   5   |   6   |   7   |   8   |
        +-------+-------+-------+-------+
row 2   |   9   |  10   |  11   |  12   |
        +-------+-------+-------+-------+

- Rows (m): 3
- Columns (n): 4
- Total elements: m x n = 12
- Element at (1, 2): 7
```

---

## Memory Layout

### Row-Major Order (Used by Python, C, C++)
Elements are stored **row by row** in contiguous memory.

```
Logical View:          Memory Layout:
[1][2][3]             [1][2][3][4][5][6][7][8][9]
[4][5][6]              ^        ^        ^
[7][8][9]              |        |        |
                     row 0   row 1    row 2

Address of element [i][j] = Base + (i * num_cols + j) * element_size
```

**Example:**
```
Matrix (2x3):
[10, 20, 30]
[40, 50, 60]

Row-Major Storage: [10, 20, 30, 40, 50, 60]
                    [0] [1] [2] [3] [4] [5]

Element [1][2] = index (1 * 3 + 2) = index 5 = 60
```

### Column-Major Order (Used by Fortran, MATLAB, Julia)
Elements are stored **column by column** in contiguous memory.

```
Logical View:          Memory Layout:
[1][2][3]             [1][4][7][2][5][8][3][6][9]
[4][5][6]              ^        ^        ^
[7][8][9]             col 0   col 1   col 2

Address of element [i][j] = Base + (j * num_rows + i) * element_size
```

### Why Does Memory Layout Matter?

**Cache Efficiency:**
- Accessing elements in the order they're stored is faster (cache-friendly)
- In Python (row-major): Traverse row-by-row for best performance
- Traversing column-by-column in row-major causes cache misses

```python
# FAST (cache-friendly in Python/C)
for i in range(rows):
    for j in range(cols):
        process(matrix[i][j])

# SLOW (cache-unfriendly in Python/C)
for j in range(cols):
    for i in range(rows):
        process(matrix[i][j])
```

---

## Matrix Indexing

### Standard Indexing (0-based)
```
matrix[row][column]
matrix[i][j]

- i ranges from 0 to rows-1
- j ranges from 0 to cols-1
```

### Important Index Relationships
```
For an m x n matrix:

Corners:
- Top-left:     matrix[0][0]
- Top-right:    matrix[0][n-1]
- Bottom-left:  matrix[m-1][0]
- Bottom-right: matrix[m-1][n-1]

Diagonals:
- Primary diagonal:   i == j
- Anti-diagonal:      i + j == n - 1

Boundaries:
- First row:    i == 0
- Last row:     i == m - 1
- First column: j == 0
- Last column:  j == n - 1
```

### Direction Vectors
A powerful technique for traversal is using direction vectors:

```python
# 4 directions (up, right, down, left)
directions_4 = [(-1, 0), (0, 1), (1, 0), (0, -1)]

# 8 directions (including diagonals)
directions_8 = [
    (-1, 0), (-1, 1), (0, 1), (1, 1),
    (1, 0), (1, -1), (0, -1), (-1, -1)
]

# Usage
for di, dj in directions_4:
    new_i, new_j = i + di, j + dj
    if 0 <= new_i < rows and 0 <= new_j < cols:
        # Valid neighbor
        process(matrix[new_i][new_j])
```

---

## Traversal Patterns

### 1. Row-wise Traversal
Visit all elements row by row, left to right.

```
[1] -> [2] -> [3]
        |
[4] <- [5] <- [6]  (conceptually continuous)
        |
[7] -> [8] -> [9]

Order: 1, 2, 3, 4, 5, 6, 7, 8, 9
```

```python
def row_wise(matrix):
    result = []
    for i in range(len(matrix)):
        for j in range(len(matrix[0])):
            result.append(matrix[i][j])
    return result
```

### 2. Column-wise Traversal
Visit all elements column by column, top to bottom.

```
[1]    [2]    [3]
 |      |      |
 v      v      v
[4]    [5]    [6]
 |      |      |
 v      v      v
[7]    [8]    [9]

Order: 1, 4, 7, 2, 5, 8, 3, 6, 9
```

```python
def column_wise(matrix):
    result = []
    for j in range(len(matrix[0])):
        for i in range(len(matrix)):
            result.append(matrix[i][j])
    return result
```

### 3. Diagonal Traversal (Primary)
Elements where row index equals column index.

```
[1]  .   .
 .  [5]  .
 .   .  [9]

Order: 1, 5, 9
```

```python
def primary_diagonal(matrix):
    n = min(len(matrix), len(matrix[0]))
    return [matrix[i][i] for i in range(n)]
```

### 4. Anti-Diagonal Traversal
Elements where row + column = n - 1.

```
 .   .  [3]
 .  [5]  .
[7]  .   .

Order: 3, 5, 7
```

```python
def anti_diagonal(matrix):
    n = len(matrix)
    return [matrix[i][n-1-i] for i in range(n)]
```

### 5. Spiral Traversal
Visit elements in a clockwise spiral from outside to inside.

```
[1] -> [2] -> [3]
                |
                v
[8] -> [9]    [4]
 ^            |
 |            v
[7] <- [6] <- [5]

Order: 1, 2, 3, 4, 5, 6, 7, 8, 9
```

```python
def spiral_traversal(matrix):
    if not matrix:
        return []
    
    result = []
    top, bottom = 0, len(matrix) - 1
    left, right = 0, len(matrix[0]) - 1
    
    while top <= bottom and left <= right:
        # Traverse right
        for j in range(left, right + 1):
            result.append(matrix[top][j])
        top += 1
        
        # Traverse down
        for i in range(top, bottom + 1):
            result.append(matrix[i][right])
        right -= 1
        
        # Traverse left
        if top <= bottom:
            for j in range(right, left - 1, -1):
                result.append(matrix[bottom][j])
            bottom -= 1
        
        # Traverse up
        if left <= right:
            for i in range(bottom, top - 1, -1):
                result.append(matrix[i][left])
            left += 1
    
    return result
```

### 6. Zigzag (Snake) Traversal
Alternate direction each row.

```
[1] -> [2] -> [3]
              |
              v
[6] <- [5] <- [4]
 |
 v
[7] -> [8] -> [9]

Order: 1, 2, 3, 4, 5, 6, 7, 8, 9
```

```python
def zigzag_traversal(matrix):
    result = []
    for i in range(len(matrix)):
        if i % 2 == 0:
            result.extend(matrix[i])  # Left to right
        else:
            result.extend(matrix[i][::-1])  # Right to left
    return result
```

### 7. Boundary Traversal
Visit only the outer boundary elements.

```
[1] -> [2] -> [3]
 ^            |
 |    [X]     v
 |            |
[7] <- [6] <- [5]

Order: 1, 2, 3, 5, 6, 7 (excluding inner elements)
```

```python
def boundary_traversal(matrix):
    if not matrix:
        return []
    
    m, n = len(matrix), len(matrix[0])
    result = []
    
    # Top row
    for j in range(n):
        result.append(matrix[0][j])
    
    # Right column (excluding first element)
    for i in range(1, m):
        result.append(matrix[i][n-1])
    
    # Bottom row (excluding last element, if more than one row)
    if m > 1:
        for j in range(n-2, -1, -1):
            result.append(matrix[m-1][j])
    
    # Left column (excluding first and last elements)
    if n > 1:
        for i in range(m-2, 0, -1):
            result.append(matrix[i][0])
    
    return result
```

---

## Time & Space Complexity

### Basic Operations

| Operation | Time Complexity | Space Complexity |
|-----------|----------------|------------------|
| Access element [i][j] | O(1) | O(1) |
| Traverse entire matrix | O(m * n) | O(1) |
| Search (unsorted) | O(m * n) | O(1) |
| Search (sorted row+col) | O(m + n) | O(1) |
| Search (fully sorted) | O(log(m * n)) | O(1) |
| Transpose | O(m * n) | O(m * n) or O(1) in-place for square |
| Rotate 90 degrees | O(m * n) | O(m * n) or O(1) in-place for square |
| Matrix multiplication | O(n^3) | O(n^2) |

### Space Analysis for Common Approaches

```
Creating a copy:     O(m * n)
In-place operations: O(1)
Visited matrix:      O(m * n)
Using recursion:     O(m * n) stack space in worst case
```

---

## Common Operations

### 1. Matrix Transpose
Swap rows and columns: A[i][j] becomes A[j][i]

```
Original:        Transposed:
[1, 2, 3]       [1, 4]
[4, 5, 6]       [2, 5]
                [3, 6]
```

```python
def transpose(matrix):
    m, n = len(matrix), len(matrix[0])
    result = [[0] * m for _ in range(n)]
    for i in range(m):
        for j in range(n):
            result[j][i] = matrix[i][j]
    return result
```

### 2. Rotate 90 Degrees Clockwise
Method: Transpose + Reverse each row

```
Original:    Transpose:   Rotate 90:
[1, 2, 3]    [1, 4, 7]    [7, 4, 1]
[4, 5, 6]    [2, 5, 8]    [8, 5, 2]
[7, 8, 9]    [3, 6, 9]    [9, 6, 3]
```

```python
def rotate_90_clockwise(matrix):
    n = len(matrix)
    # Transpose
    for i in range(n):
        for j in range(i, n):
            matrix[i][j], matrix[j][i] = matrix[j][i], matrix[i][j]
    # Reverse each row
    for i in range(n):
        matrix[i].reverse()
```

### 3. Matrix Multiplication
```python
def multiply(A, B):
    m, n, p = len(A), len(A[0]), len(B[0])
    result = [[0] * p for _ in range(m)]
    for i in range(m):
        for j in range(p):
            for k in range(n):
                result[i][j] += A[i][k] * B[k][j]
    return result
```

---

## Key Patterns for Problem Solving

### Pattern 1: Boundary Pointers
Used for spiral traversal, rotating layers, etc.

```python
top, bottom = 0, m - 1
left, right = 0, n - 1

while top <= bottom and left <= right:
    # Process boundary
    # Shrink boundaries
    top += 1
    bottom -= 1
    left += 1
    right -= 1
```

### Pattern 2: Staircase Search (Sorted Matrix)
Start from top-right or bottom-left corner.

```python
def search_sorted_matrix(matrix, target):
    i, j = 0, len(matrix[0]) - 1  # Top-right
    while i < len(matrix) and j >= 0:
        if matrix[i][j] == target:
            return (i, j)
        elif matrix[i][j] > target:
            j -= 1  # Go left
        else:
            i += 1  # Go down
    return None
```

### Pattern 3: Binary Search Variants
For fully sorted or row-sorted matrices.

```python
# Treat as 1D array
def binary_search_matrix(matrix, target):
    m, n = len(matrix), len(matrix[0])
    left, right = 0, m * n - 1
    
    while left <= right:
        mid = (left + right) // 2
        row, col = mid // n, mid % n
        if matrix[row][col] == target:
            return (row, col)
        elif matrix[row][col] < target:
            left = mid + 1
        else:
            right = mid - 1
    return None
```

### Pattern 4: DFS/BFS for Connected Components
```python
def dfs(matrix, i, j, visited):
    if i < 0 or i >= len(matrix) or j < 0 or j >= len(matrix[0]):
        return
    if visited[i][j] or matrix[i][j] == 0:
        return
    
    visited[i][j] = True
    for di, dj in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
        dfs(matrix, i + di, j + dj, visited)
```

### Pattern 5: Dynamic Programming on Matrix
```python
# Example: Minimum path sum
def min_path_sum(matrix):
    m, n = len(matrix), len(matrix[0])
    dp = [[0] * n for _ in range(m)]
    dp[0][0] = matrix[0][0]
    
    # Fill first row and column
    for j in range(1, n):
        dp[0][j] = dp[0][j-1] + matrix[0][j]
    for i in range(1, m):
        dp[i][0] = dp[i-1][0] + matrix[i][0]
    
    # Fill rest
    for i in range(1, m):
        for j in range(1, n):
            dp[i][j] = matrix[i][j] + min(dp[i-1][j], dp[i][j-1])
    
    return dp[m-1][n-1]
```

---

## Summary Cheat Sheet

| Task | Technique | Time | Space |
|------|-----------|------|-------|
| Traverse all | Nested loops | O(mn) | O(1) |
| Spiral | Boundary pointers | O(mn) | O(1) |
| Search (row-col sorted) | Staircase | O(m+n) | O(1) |
| Search (fully sorted) | Binary search | O(log mn) | O(1) |
| Rotate 90 | Transpose + Reverse | O(n^2) | O(1) |
| Find islands | DFS/BFS | O(mn) | O(mn) |
| Shortest path | BFS | O(mn) | O(mn) |
| DP problems | Fill table | O(mn) | O(mn) or O(n) |

---

## Practice Tips

1. **Always clarify:** Is the matrix sorted? Square? What are the constraints?
2. **Draw it out:** Visualize the matrix and trace through your algorithm
3. **Watch boundaries:** Off-by-one errors are common in matrix problems
4. **Consider in-place:** Can you solve it without extra space?
5. **Think about cache:** Row-major access is usually faster in Python/C

Happy coding!
