"""
Common Elements in All Rows of a Given Matrix
==============================================

Problem: Find elements that appear in every row of a sorted matrix.

Approaches:
1. Hash Map: Count occurrences - O(m*n) time, O(m*n) space
2. Multi-Pointer: Merge-like traversal - O(m*n) time, O(m) space
3. Binary Search: Search each element - O(m*n*log n) time, O(1) space
"""

from typing import List
from bisect import bisect_left


def common_elements_hash(matrix: List[List[int]]) -> List[int]:
    """
    Hash Map approach: Count unique occurrences across rows.
    Time: O(m * n), Space: O(m * n)
    """
    if not matrix:
        return []

    m = len(matrix)
    count = {}

    for row in matrix:
        seen = set()
        for val in row:
            if val not in seen:
                seen.add(val)
                count[val] = count.get(val, 0) + 1

    return sorted([k for k, v in count.items() if v == m])


def common_elements(matrix: List[List[int]]) -> List[int]:
    """
    Multi-Pointer approach: Merge-like traversal.

    Algorithm:
    1. Maintain one pointer per row
    2. Find max among current positions
    3. Move all pointers behind max forward
    4. When all point to same value -> common element!

    Time: O(m * n), Space: O(m)

    Example:
        >>> common_elements([[1,2,3,4,5],[2,4,5,8,10],[3,5,7,9,11],[1,3,5,7,9]])
        [5]
    """
    if not matrix or not matrix[0]:
        return []

    m = len(matrix)
    n = len(matrix[0])
    pointers = [0] * m
    result = []

    while True:
        # Get current values at each pointer
        current_vals = []
        for i in range(m):
            if pointers[i] >= len(matrix[i]):
                return result
            current_vals.append(matrix[i][pointers[i]])

        max_val = max(current_vals)
        min_val = min(current_vals)

        if max_val == min_val:
            # All pointers at same value - found common!
            result.append(max_val)
            # Move all pointers forward
            for i in range(m):
                pointers[i] += 1
        else:
            # Move pointers that are behind max_val
            for i in range(m):
                while pointers[i] < len(matrix[i]) and matrix[i][pointers[i]] < max_val:
                    pointers[i] += 1

        # Check if any pointer exceeded bounds
        for i in range(m):
            if pointers[i] >= len(matrix[i]):
                return result

    return result


def common_elements_binary(matrix: List[List[int]]) -> List[int]:
    """
    Binary Search: For each element in first row, search in other rows.
    Time: O(m * n * log n), Space: O(1)
    """
    if not matrix or not matrix[0]:
        return []

    result = []
    first_row = matrix[0]

    for val in first_row:
        is_common = True
        for i in range(1, len(matrix)):
            idx = bisect_left(matrix[i], val)
            if idx >= len(matrix[i]) or matrix[i][idx] != val:
                is_common = False
                break
        if is_common:
            result.append(val)

    return result


def common_elements_trace(matrix: List[List[int]]) -> List[int]:
    """Educational version with trace."""
    if not matrix or not matrix[0]:
        return []

    m = len(matrix)
    pointers = [0] * m
    result = []
    step = 1

    print("Finding common elements using multi-pointer:")
    print(f"Matrix has {m} rows")

    while True:
        current_vals = []
        for i in range(m):
            if pointers[i] >= len(matrix[i]):
                print(f"\nRow {i} exhausted. Done!")
                return result
            current_vals.append(matrix[i][pointers[i]])

        print(f"\nStep {step}: pointers={pointers}, values={current_vals}")

        max_val = max(current_vals)
        min_val = min(current_vals)

        if max_val == min_val:
            print(f"  All same! Found common: {max_val}")
            result.append(max_val)
            for i in range(m):
                pointers[i] += 1
        else:
            print(f"  max={max_val}, min={min_val}, advancing pointers < max")
            for i in range(m):
                while pointers[i] < len(matrix[i]) and matrix[i][pointers[i]] < max_val:
                    pointers[i] += 1

        for i in range(m):
            if pointers[i] >= len(matrix[i]):
                print(f"\nRow {i} exhausted. Done!")
                return result

        step += 1

    return result


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 50)
    print("COMMON ELEMENTS IN ALL ROWS")
    print("=" * 50)

    matrix = [
        [1, 2, 3, 4, 5],
        [2, 4, 5, 8, 10],
        [3, 5, 7, 9, 11],
        [1, 3, 5, 7, 9]
    ]

    print("\nMatrix:")
    for row in matrix:
        print(row)

    result = common_elements(matrix)
    print(f"\nCommon elements: {result}")
    assert result == [5], f"Expected [5], got {result}"
    print("PASSED!")

    # Compare methods
    print("\n" + "-" * 40)
    print("Comparing methods:")
    hash_result = common_elements_hash(matrix)
    pointer_result = common_elements(matrix)
    binary_result = common_elements_binary(matrix)
    print(f"Hash Map: {hash_result}")
    print(f"Multi-Pointer: {pointer_result}")
    print(f"Binary Search: {binary_result}")
    assert hash_result == pointer_result == binary_result

    # Test 2: Multiple common elements
    print("\n" + "-" * 40)
    matrix2 = [
        [1, 2, 3, 4],
        [1, 2, 3, 5],
        [1, 2, 7, 9]
    ]
    print(f"Matrix 2: {matrix2}")
    result2 = common_elements(matrix2)
    print(f"Common: {result2}")
    assert result2 == [1, 2]

    # Test 3: No common elements
    print("\n" + "-" * 40)
    matrix3 = [
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9]
    ]
    print(f"Matrix 3: {matrix3}")
    result3 = common_elements(matrix3)
    print(f"Common: {result3}")
    assert result3 == []

    # Detailed trace
    print("\n" + "-" * 40)
    print("DETAILED TRACE:")
    common_elements_trace(matrix)

    print("\n" + "=" * 50)
    print("ALL TESTS PASSED!")
