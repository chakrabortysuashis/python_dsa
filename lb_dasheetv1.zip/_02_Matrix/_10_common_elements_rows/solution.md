# Common Elements in All Rows of a Given Matrix

## Problem Statement

Given an `m x n` matrix where each row is sorted in ascending order, find all elements that appear in **every row**.

### Example

```
Matrix:
[1, 2, 3, 4, 5]
[2, 4, 5, 8, 10]
[3, 5, 7, 9, 11]
[1, 3, 5, 7, 9]

Common elements: [5]
(5 appears in all 4 rows)
```

---

## Key Insight

Since rows are sorted, we can use a **multi-pointer** technique or **hash map counting**.

---

## Approach 1: Hash Map (Simple)

### Algorithm
1. Count frequency of each element across all rows (count unique per row)
2. Elements with count == number of rows are common to all

```python
def common_elements_hash(matrix):
    m = len(matrix)
    count = {}

    for row in matrix:
        seen = set()  # Track unique elements in this row
        for val in row:
            if val not in seen:
                seen.add(val)
                count[val] = count.get(val, 0) + 1

    return [k for k, v in count.items() if v == m]
```

- **Time**: O(m * n)
- **Space**: O(m * n) worst case

---

## Approach 2: Multi-Pointer (Optimal for Sorted)

### Algorithm
Use one pointer per row, similar to merging sorted arrays:
1. Start all pointers at index 0
2. Find max value among current positions
3. Move all pointers that point to smaller values
4. If all point to same value, it's common!

```python
def common_elements(matrix):
    m, n = len(matrix), len(matrix[0])
    pointers = [0] * m  # One pointer per row
    result = []

    while True:
        # Find current values at each pointer
        current_vals = [matrix[i][pointers[i]] for i in range(m)]
        max_val = max(current_vals)
        min_val = min(current_vals)

        if max_val == min_val:
            # All same - found common element!
            result.append(max_val)
            # Move all pointers forward
            for i in range(m):
                pointers[i] += 1
                if pointers[i] >= n:
                    return result
        else:
            # Move pointers that are behind
            for i in range(m):
                while pointers[i] < n and matrix[i][pointers[i]] < max_val:
                    pointers[i] += 1
                if pointers[i] >= n:
                    return result

    return result
```

- **Time**: O(m * n) - each element visited at most once
- **Space**: O(m) - for pointers

---

## Visual Walkthrough

```
Matrix:
[1, 2, 3, 4, 5]
[2, 4, 5, 8, 10]
[3, 5, 7, 9, 11]
[1, 3, 5, 7, 9]

Pointers: [0, 0, 0, 0]

Step 1: vals = [1, 2, 3, 1], max=3
        Move pointers behind 3
        Pointers: [2, 1, 0, 1]

Step 2: vals = [3, 4, 3, 3], max=4
        Move pointers behind 4
        Pointers: [3, 1, 1, 2]

Step 3: vals = [4, 4, 5, 5], max=5
        Move pointers behind 5
        Pointers: [4, 2, 1, 2]

Step 4: vals = [5, 5, 5, 5], max=min=5
        FOUND! Common element: 5
        Move all forward
        Pointers: [5, 3, 2, 3]

Pointer 0 out of bounds -> Done
Result: [5]
```

---

## Approach 3: Binary Search per Row

For each element in first row, binary search in other rows:

```python
from bisect import bisect_left

def common_elements_binary(matrix):
    result = []
    first_row = matrix[0]

    for val in first_row:
        is_common = True
        for i in range(1, len(matrix)):
            idx = bisect_left(matrix[i], val)
            if idx >= len(matrix[i]) or matrix[i][idx] != val:
                is_common = False
                break
        if is_common:
            result.append(val)

    return result
```

- **Time**: O(n * m * log n)
- **Space**: O(1)

---

## Complexity Comparison

| Approach | Time | Space |
|----------|------|-------|
| Hash Map | O(m * n) | O(m * n) |
| **Multi-Pointer** | **O(m * n)** | **O(m)** |
| Binary Search | O(m * n * log n) | O(1) |

---

## Key Takeaways

1. **Multi-pointer** leverages sorted property efficiently
2. Hash map is simpler but uses more space
3. Binary search good when first row is small
4. Pattern applies to: intersection of sorted arrays, merge k sorted lists
