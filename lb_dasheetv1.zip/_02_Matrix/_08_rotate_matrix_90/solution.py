"""
Rotate Matrix by 90 Degrees
===========================

Problem: Rotate an n x n matrix by 90 degrees clockwise in-place.

Key: 90 CW = Transpose + Reverse each row
Time: O(n^2), Space: O(1)
"""

from typing import List
import copy


def rotate_90_clockwise(matrix: List[List[int]]) -> None:
    """
    Rotate matrix 90 degrees clockwise in-place.

    Algorithm: Transpose + Reverse each row

    Example:
        >>> m = [[1,2,3],[4,5,6],[7,8,9]]
        >>> rotate_90_clockwise(m)
        >>> m
        [[7, 4, 1], [8, 5, 2], [9, 6, 3]]
    """
    n = len(matrix)

    # Step 1: Transpose (swap across diagonal)
    for i in range(n):
        for j in range(i + 1, n):
            matrix[i][j], matrix[j][i] = matrix[j][i], matrix[i][j]

    # Step 2: Reverse each row
    for row in matrix:
        row.reverse()


def rotate_90_counterclockwise(matrix: List[List[int]]) -> None:
    """Rotate 90 degrees counter-clockwise: Reverse rows + Transpose."""
    n = len(matrix)

    # Reverse each row first
    for row in matrix:
        row.reverse()

    # Transpose
    for i in range(n):
        for j in range(i + 1, n):
            matrix[i][j], matrix[j][i] = matrix[j][i], matrix[i][j]


def rotate_180(matrix: List[List[int]]) -> None:
    """Rotate 180 degrees: Reverse row order + Reverse each row."""
    matrix.reverse()
    for row in matrix:
        row.reverse()


def rotate_layer_by_layer(matrix: List[List[int]]) -> None:
    """
    Alternative: Rotate by moving 4 elements at a time.
    Process concentric layers from outside to inside.
    """
    n = len(matrix)

    for layer in range(n // 2):
        first = layer
        last = n - 1 - layer

        for i in range(first, last):
            offset = i - first

            # Save top element
            top = matrix[first][i]

            # Left -> Top
            matrix[first][i] = matrix[last - offset][first]

            # Bottom -> Left
            matrix[last - offset][first] = matrix[last][last - offset]

            # Right -> Bottom
            matrix[last][last - offset] = matrix[i][last]

            # Top -> Right
            matrix[i][last] = top


def rotate_with_trace(matrix: List[List[int]]) -> None:
    """Educational version with trace."""
    n = len(matrix)
    print("Original:")
    print_matrix(matrix)

    # Transpose
    print("\nStep 1: Transpose")
    for i in range(n):
        for j in range(i + 1, n):
            print(f"  Swap ({i},{j}) <-> ({j},{i}): {matrix[i][j]} <-> {matrix[j][i]}")
            matrix[i][j], matrix[j][i] = matrix[j][i], matrix[i][j]
    print_matrix(matrix)

    # Reverse rows
    print("\nStep 2: Reverse each row")
    for row in matrix:
        row.reverse()
    print_matrix(matrix)


def print_matrix(matrix):
    for row in matrix:
        print(row)


# =============================================================================
# TEST CASES
# =============================================================================

if __name__ == "__main__":
    print("=" * 50)
    print("ROTATE MATRIX BY 90 DEGREES")
    print("=" * 50)

    # Test 1: 3x3 matrix
    m1 = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    print("\nOriginal 3x3:")
    print_matrix(m1)
    rotate_90_clockwise(m1)
    print("\nAfter 90 CW rotation:")
    print_matrix(m1)
    assert m1 == [[7, 4, 1], [8, 5, 2], [9, 6, 3]]
    print("PASSED!")

    # Test 2: 4x4 matrix
    m2 = [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]]
    print("\nOriginal 4x4:")
    print_matrix(m2)
    rotate_90_clockwise(m2)
    print("\nAfter 90 CW rotation:")
    print_matrix(m2)
    print("PASSED!")

    # Compare methods
    print("\n" + "-" * 40)
    print("Comparing transpose+reverse vs layer-by-layer:")
    m3 = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    m4 = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    rotate_90_clockwise(m3)
    rotate_layer_by_layer(m4)
    print(f"Transpose+Reverse: {m3}")
    print(f"Layer-by-layer:    {m4}")
    assert m3 == m4
    print("Both methods match!")

    # Detailed trace
    print("\n" + "-" * 40)
    print("DETAILED TRACE:")
    m5 = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    rotate_with_trace(m5)
