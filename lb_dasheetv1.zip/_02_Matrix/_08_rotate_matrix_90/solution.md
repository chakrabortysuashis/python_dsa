# Rotate Matrix by 90 Degrees

## Problem Statement

Given an `n x n` square matrix, rotate it by 90 degrees clockwise **in-place**.

### Example

```
Input:                  Output (90 CW):
[1, 2, 3]              [7, 4, 1]
[4, 5, 6]      ->      [8, 5, 2]
[7, 8, 9]              [9, 6, 3]
```

---

## Key Insight

90-degree clockwise rotation = **Transpose + Reverse each row**

```
Original:     Transpose:    Reverse rows:
[1, 2, 3]    [1, 4, 7]     [7, 4, 1]
[4, 5, 6] -> [2, 5, 8] ->  [8, 5, 2]
[7, 8, 9]    [3, 6, 9]     [9, 6, 3]
```

---

## Understanding the Transformations

### Transpose
Swap elements across the main diagonal: `matrix[i][j] <-> matrix[j][i]`

```
Before:       After:
[1, 2, 3]    [1, 4, 7]
[4, 5, 6] -> [2, 5, 8]
[7, 8, 9]    [3, 6, 9]

Element at (0,1) moves to (1,0): 2
Element at (0,2) moves to (2,0): 3
... and so on
```

### Reverse Each Row
```
[1, 4, 7] -> [7, 4, 1]
[2, 5, 8] -> [8, 5, 2]
[3, 6, 9] -> [9, 6, 3]
```

---

## Implementation

```python
def rotate_90_clockwise(matrix):
    n = len(matrix)

    # Step 1: Transpose
    for i in range(n):
        for j in range(i + 1, n):  # Only upper triangle
            matrix[i][j], matrix[j][i] = matrix[j][i], matrix[i][j]

    # Step 2: Reverse each row
    for row in matrix:
        row.reverse()
```

---

## Other Rotations

### 90 Counter-Clockwise
= **Transpose + Reverse each column**
OR = **Reverse each row + Transpose**

```python
def rotate_90_ccw(matrix):
    n = len(matrix)
    # Reverse each row first
    for row in matrix:
        row.reverse()
    # Then transpose
    for i in range(n):
        for j in range(i + 1, n):
            matrix[i][j], matrix[j][i] = matrix[j][i], matrix[i][j]
```

### 180 Degrees
= **Reverse rows order + Reverse each row**
OR = **Rotate 90 twice**

```python
def rotate_180(matrix):
    matrix.reverse()  # Reverse order of rows
    for row in matrix:
        row.reverse()  # Reverse each row
```

---

## Layer-by-Layer Rotation (Alternative)

Rotate elements in groups of 4 (corners of concentric squares).

```python
def rotate_layer_by_layer(matrix):
    n = len(matrix)

    for layer in range(n // 2):
        first, last = layer, n - 1 - layer

        for i in range(first, last):
            offset = i - first

            # Save top
            top = matrix[first][i]

            # Left -> Top
            matrix[first][i] = matrix[last - offset][first]

            # Bottom -> Left
            matrix[last - offset][first] = matrix[last][last - offset]

            # Right -> Bottom
            matrix[last][last - offset] = matrix[i][last]

            # Top -> Right
            matrix[i][last] = top
```

---

## Complexity

Both approaches:
- **Time**: O(n^2) - visit each element once
- **Space**: O(1) - in-place rotation

---

## Visual Dry Run (Transpose + Reverse)

```
Original:
[1, 2, 3]
[4, 5, 6]
[7, 8, 9]

Step 1 - Transpose (swap across diagonal):
  Swap (0,1)-(1,0): 2 <-> 4
  Swap (0,2)-(2,0): 3 <-> 7
  Swap (1,2)-(2,1): 6 <-> 8

Result:
[1, 4, 7]
[2, 5, 8]
[3, 6, 9]

Step 2 - Reverse each row:
  [1, 4, 7] -> [7, 4, 1]
  [2, 5, 8] -> [8, 5, 2]
  [3, 6, 9] -> [9, 6, 3]

Final:
[7, 4, 1]
[8, 5, 2]
[9, 6, 3]
```

---

## Key Takeaways

1. **Transpose + Reverse** is the simplest approach to understand
2. Matrix rotations can be decomposed into simpler operations
3. For non-square matrices, rotation requires new matrix allocation
4. Same pattern applies to image rotation algorithms
