# Longest Palindromic Substring

## Problem Statement
Given a string `s`, return the longest palindromic substring in `s`.

**Example 1:**
```
Input: s = "babad"
Output: "bab" or "aba"
Explanation: Both are valid longest palindromic substrings
```

**Example 2:**
```
Input: s = "cbbd"
Output: "bb"
```

---

## Intuition and Thought Process

A palindrome has a center from which it expands symmetrically. The center can be:
- **Single character** (odd length palindrome): "aba" has center 'b'
- **Between two characters** (even length palindrome): "abba" has center between 'b's

```
"racecar"
    ^
  center

Expand outward: r-r, a-a, c-c, e (center)
```

---

## Approach 1: Brute Force

### Idea
Check every possible substring and verify if it's a palindrome.

### Algorithm
1. Generate all substrings
2. For each substring, check if palindrome
3. Track the longest

### Complexity
- **Time**: O(n^3) - O(n^2) substrings, O(n) to check each
- **Space**: O(1)

---

## Approach 2: Dynamic Programming

### Idea
Build a 2D DP table where dp[i][j] = true if s[i:j+1] is palindrome.

### Recurrence
```
dp[i][j] = true if:
    1. s[i] == s[j] AND
    2. (j - i < 3 OR dp[i+1][j-1])
```

### Visual Dry Run
```
s = "babad"

DP Table (diagonal = single chars, all true):
    b  a  b  a  d
b   T  F  T  F  F
a      T  F  T  F
b         T  F  F
a            T  F
d               T

Fill order: diagonals of increasing length
- Length 1: All true
- Length 2: Check s[i]==s[j]
- Length 3+: Check s[i]==s[j] AND dp[i+1][j-1]

Longest palindrome: "bab" or "aba" (length 3)
```

### Complexity
- **Time**: O(n^2)
- **Space**: O(n^2)

---

## Approach 3: Expand Around Center (Optimal)

### Idea
For each position, expand outward while characters match.

### Why This Works
Every palindrome has a center. Try each position as center and expand.

### Algorithm
1. For each index i (0 to n-1):
   - Expand around i (odd length)
   - Expand around i and i+1 (even length)
2. Track the longest palindrome found

### Visual Dry Run
```
s = "babad"

i=0: Center at 'b'
     Odd:  "b" -> expand -> "b" (length 1)
     Even: "ba" -> not palindrome

i=1: Center at 'a'
     Odd:  "a" -> "bab" (expand works!) -> length 3
     Even: "ab" -> not palindrome

i=2: Center at 'b'
     Odd:  "b" -> "aba" (expand works!) -> length 3
     Even: "ba" -> not palindrome

i=3: Center at 'a'
     Odd:  "a" -> expand -> "a" (length 1)
     Even: "ad" -> not palindrome

Longest: "bab" or "aba" (length 3)
```

### Pseudocode
```
function longestPalindrome(s):
    start = 0
    maxLen = 1

    function expandAroundCenter(left, right):
        while left >= 0 AND right < n AND s[left] == s[right]:
            left -= 1
            right += 1
        return right - left - 1  // Length of palindrome

    for i from 0 to n-1:
        len1 = expandAroundCenter(i, i)      // Odd length
        len2 = expandAroundCenter(i, i + 1)  // Even length
        len = max(len1, len2)

        if len > maxLen:
            maxLen = len
            start = i - (len - 1) / 2

    return s[start : start + maxLen]
```

### Complexity
- **Time**: O(n^2) - n centers, O(n) expansion each
- **Space**: O(1)

---

## Approach 4: Manacher's Algorithm (Advanced)

### Idea
Linear time algorithm using clever preprocessing and center/radius tracking.

### Key Concepts
1. Transform string: "babad" -> "#b#a#b#a#d#"
2. Use previously computed palindrome info to skip redundant checks
3. Track center and right boundary of rightmost palindrome

### Complexity
- **Time**: O(n)
- **Space**: O(n)

---

## Comparison Table

| Approach | Time | Space | Notes |
|----------|------|-------|-------|
| Brute Force | O(n^3) | O(1) | Check all substrings |
| DP | O(n^2) | O(n^2) | Build table |
| Expand Center | O(n^2) | O(1) | Optimal for interviews |
| Manacher's | O(n) | O(n) | Advanced, rarely asked |

---

## Edge Cases

| Input | Output | Notes |
|-------|--------|-------|
| "a" | "a" | Single character |
| "aa" | "aa" | All same |
| "ab" | "a" or "b" | No palindrome > 1 |
| "cbbd" | "bb" | Even length |
| "babad" | "bab" or "aba" | Multiple answers |

---

## Key Takeaways

1. **Expand from center** is the recommended approach for interviews
2. Consider both **odd and even** length palindromes
3. **DP approach** is good for understanding but uses more space
4. **Manacher's algorithm** is O(n) but complex - know it exists
5. A single character is always a palindrome

---

## Related Problems
- Palindromic Substrings (count all)
- Longest Palindromic Subsequence
- Valid Palindrome II
- Shortest Palindrome
