"""
Longest Palindromic Substring
==============================

Problem: Given a string s, return the longest palindromic substring.

Approaches:
1. Brute Force - O(n^3)
2. Dynamic Programming - O(n^2) time, O(n^2) space
3. Expand Around Center - O(n^2) time, O(1) space (Recommended)
4. Manacher's Algorithm - O(n) time (Advanced)
"""

from typing import Tuple


# =============================================================================
# APPROACH 1: BRUTE FORCE
# =============================================================================

def longest_palindrome_brute(s: str) -> str:
    """
    Find longest palindrome by checking all substrings.

    Time Complexity: O(n^3) - O(n^2) substrings, O(n) to check each
    Space Complexity: O(1)
    """
    def is_palindrome(string: str) -> bool:
        return string == string[::-1]

    n = len(s)
    if n < 2:
        return s

    longest = s[0]

    for i in range(n):
        for j in range(i + 1, n + 1):
            substring = s[i:j]
            if len(substring) > len(longest) and is_palindrome(substring):
                longest = substring

    return longest


# =============================================================================
# APPROACH 2: DYNAMIC PROGRAMMING
# =============================================================================

def longest_palindrome_dp(s: str) -> str:
    """
    Find longest palindrome using 2D DP.

    INTUITION:
    dp[i][j] = True if s[i:j+1] is a palindrome

    RECURRENCE:
    dp[i][j] = (s[i] == s[j]) AND (j - i < 3 OR dp[i+1][j-1])

    Explanation:
    - s[i] must equal s[j]
    - If length <= 3, inner part is automatically palindrome
    - Otherwise, check if inner part (i+1 to j-1) is palindrome

    DP TABLE for "babad":
            0   1   2   3   4
            b   a   b   a   d
    0   b   T   F   T   F   F
    1   a       T   F   T   F
    2   b           T   F   F
    3   a               T   F
    4   d                   T

    Time Complexity: O(n^2)
    Space Complexity: O(n^2)
    """
    n = len(s)
    if n < 2:
        return s

    # dp[i][j] = True if s[i:j+1] is palindrome
    dp = [[False] * n for _ in range(n)]

    # Single characters are palindromes
    for i in range(n):
        dp[i][i] = True

    start = 0
    max_len = 1

    # Fill DP table for increasing lengths
    for length in range(2, n + 1):
        for i in range(n - length + 1):
            j = i + length - 1

            if s[i] == s[j]:
                if length <= 3:
                    dp[i][j] = True
                else:
                    dp[i][j] = dp[i + 1][j - 1]

                if dp[i][j] and length > max_len:
                    max_len = length
                    start = i

    return s[start:start + max_len]


# =============================================================================
# APPROACH 3: EXPAND AROUND CENTER (Optimal for Interviews)
# =============================================================================

def longest_palindrome_expand(s: str) -> str:
    """
    Find longest palindrome by expanding around each center.

    INTUITION:
    - Every palindrome has a center
    - Center can be single char (odd length) or between two chars (even)
    - Expand outward while characters match

    VISUAL for "babad":

    Center at index 1 ('a'):
        Odd expansion:  a -> bab (matches b==b)
        Can't expand further (index out of bounds)
        Length = 3

    Center between 2-3 ('ba'):
        Even expansion: ba (b != a, stop immediately)
        Length = 0

    Time Complexity: O(n^2) - n centers, O(n) expansion each
    Space Complexity: O(1)
    """
    n = len(s)
    if n < 2:
        return s

    def expand_around_center(left: int, right: int) -> Tuple[int, int]:
        """
        Expand outward while characters match.
        Returns the start and end indices of the palindrome.
        """
        while left >= 0 and right < n and s[left] == s[right]:
            left -= 1
            right += 1
        # After loop, left and right are one step beyond palindrome bounds
        return left + 1, right - 1

    start = 0
    end = 0

    for i in range(n):
        # Odd length palindrome (single center)
        left1, right1 = expand_around_center(i, i)

        # Even length palindrome (center between i and i+1)
        left2, right2 = expand_around_center(i, i + 1)

        # Update if we found a longer palindrome
        if right1 - left1 > end - start:
            start, end = left1, right1

        if right2 - left2 > end - start:
            start, end = left2, right2

    return s[start:end + 1]


def longest_palindrome_expand_verbose(s: str) -> str:
    """
    Same as above but with verbose output for learning.
    """
    n = len(s)
    if n < 2:
        return s

    def expand(left: int, right: int) -> Tuple[int, int]:
        while left >= 0 and right < n and s[left] == s[right]:
            left -= 1
            right += 1
        return left + 1, right - 1

    start, end = 0, 0

    print(f"\nFinding longest palindrome in '{s}':")

    for i in range(n):
        print(f"\nCenter at index {i} ('{s[i]}'):")

        # Odd length
        l1, r1 = expand(i, i)
        odd_palindrome = s[l1:r1+1]
        print(f"  Odd expansion:  '{odd_palindrome}' (length {r1-l1+1})")

        # Even length
        l2, r2 = expand(i, i + 1)
        even_palindrome = s[l2:r2+1] if r2 >= l2 else ""
        print(f"  Even expansion: '{even_palindrome}' (length {max(0, r2-l2+1)})")

        if r1 - l1 > end - start:
            start, end = l1, r1
            print(f"  -> New best (odd): '{s[start:end+1]}'")

        if r2 - l2 > end - start:
            start, end = l2, r2
            print(f"  -> New best (even): '{s[start:end+1]}'")

    result = s[start:end + 1]
    print(f"\nLongest palindrome: '{result}'")
    return result


# =============================================================================
# APPROACH 4: MANACHER'S ALGORITHM (Advanced)
# =============================================================================

def longest_palindrome_manacher(s: str) -> str:
    """
    Find longest palindrome using Manacher's algorithm.

    INTUITION:
    - Transform string to handle odd/even uniformly: "abc" -> "#a#b#c#"
    - Use previously computed info to skip redundant checks
    - Track center and right boundary of rightmost palindrome

    Time Complexity: O(n)
    Space Complexity: O(n)
    """
    if not s:
        return ""

    # Transform string
    t = '#' + '#'.join(s) + '#'
    n = len(t)

    # p[i] = radius of palindrome centered at i
    p = [0] * n

    # center and right boundary of rightmost palindrome
    center = 0
    right = 0

    for i in range(n):
        # Use mirror property if within right boundary
        if i < right:
            mirror = 2 * center - i
            p[i] = min(right - i, p[mirror])

        # Try to expand
        left_idx = i - p[i] - 1
        right_idx = i + p[i] + 1

        while left_idx >= 0 and right_idx < n and t[left_idx] == t[right_idx]:
            p[i] += 1
            left_idx -= 1
            right_idx += 1

        # Update center and right if expanded past right boundary
        if i + p[i] > right:
            center = i
            right = i + p[i]

    # Find the maximum palindrome
    max_len = max(p)
    center_idx = p.index(max_len)

    # Convert back to original string indices
    start = (center_idx - max_len) // 2
    return s[start:start + max_len]


# =============================================================================
# UTILITY: COUNT ALL PALINDROMIC SUBSTRINGS
# =============================================================================

def count_palindromic_substrings(s: str) -> int:
    """
    Count total number of palindromic substrings.

    Uses expand around center approach.

    Time Complexity: O(n^2)
    Space Complexity: O(1)
    """
    n = len(s)
    count = 0

    def expand_and_count(left: int, right: int) -> int:
        cnt = 0
        while left >= 0 and right < n and s[left] == s[right]:
            cnt += 1
            left -= 1
            right += 1
        return cnt

    for i in range(n):
        count += expand_and_count(i, i)      # Odd
        count += expand_and_count(i, i + 1)  # Even

    return count


def get_all_palindromic_substrings(s: str) -> list:
    """
    Get all palindromic substrings (including duplicates).
    """
    n = len(s)
    palindromes = []

    def expand_and_collect(left: int, right: int):
        while left >= 0 and right < n and s[left] == s[right]:
            palindromes.append(s[left:right + 1])
            left -= 1
            right += 1

    for i in range(n):
        expand_and_collect(i, i)
        expand_and_collect(i, i + 1)

    return sorted(palindromes, key=lambda x: (len(x), x))


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Run comprehensive test cases."""

    test_cases = [
        ("babad", ["bab", "aba"]),
        ("cbbd", ["bb"]),
        ("a", ["a"]),
        ("ac", ["a", "c"]),
        ("bb", ["bb"]),
        ("racecar", ["racecar"]),
        ("aacabdkacaa", ["aca"]),
        ("", [""]),
    ]

    print("=" * 60)
    print("LONGEST PALINDROMIC SUBSTRING - TEST RESULTS")
    print("=" * 60)

    approaches = [
        ("Brute Force", longest_palindrome_brute),
        ("DP", longest_palindrome_dp),
        ("Expand Center", longest_palindrome_expand),
        ("Manacher's", longest_palindrome_manacher),
    ]

    for name, func in approaches:
        print(f"\n--- {name} ---")
        all_passed = True

        for s, expected_list in test_cases:
            result = func(s)
            if result not in expected_list:
                all_passed = False
                print(f"  FAIL: '{s}' -> '{result}' (expected one of {expected_list})")

        if all_passed:
            print(f"  All {len(test_cases)} test cases PASSED!")


def demonstrate():
    """Demonstrate the algorithm step by step."""

    print("\n" + "=" * 60)
    print("STEP-BY-STEP DEMONSTRATION")
    print("=" * 60)

    # Verbose demonstration
    longest_palindrome_expand_verbose("babad")

    # Count all palindromic substrings
    print("\n" + "-" * 40)
    s = "aaa"
    print(f"Counting palindromic substrings in '{s}':")
    count = count_palindromic_substrings(s)
    all_pals = get_all_palindromic_substrings(s)
    print(f"  Count: {count}")
    print(f"  All palindromes: {all_pals}")


if __name__ == "__main__":
    run_tests()
    demonstrate()
