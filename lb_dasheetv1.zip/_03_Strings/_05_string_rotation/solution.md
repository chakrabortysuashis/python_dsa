# Check Whether One String is a Rotation of Another

## Problem Statement
Given two strings `s1` and `s2`, check if `s2` is a rotation of `s1`.

A rotation is obtained by moving characters from the beginning to the end (or vice versa).

**Example 1:**
```
Input: s1 = "ABCD", s2 = "CDAB"
Output: true
Explanation: ABCD -> BCDA -> CDAB (rotated left 2 times)
```

**Example 2:**
```
Input: s1 = "ABCD", s2 = "ACBD"
Output: false
```

---

## Intuition and Thought Process

### Understanding Rotation
A rotation shifts characters from one end to the other:
```
"ABCDE" rotated:
- 1 left:  "BCDEA"
- 2 left:  "CDEAB"
- 3 left:  "DEABC"
- 4 left:  "EABCD"
- 5 left:  "ABCDE" (back to original)
```

### Key Insight
If s2 is a rotation of s1, then s2 must appear as a substring in s1+s1!

```
s1 = "ABCD"
s1 + s1 = "ABCDABCD"
             ^^^^
All rotations appear in s1+s1:
- ABCD at index 0
- BCDA at index 1
- CDAB at index 2
- DABC at index 3
```

---

## Approach 1: Brute Force (Check All Rotations)

### Idea
Generate all rotations of s1 and check if any matches s2.

### Algorithm
1. For each possible rotation (0 to n-1)
2. Generate the rotated string
3. Compare with s2
4. Return true if match found

### Code
```python
def is_rotation_brute(s1: str, s2: str) -> bool:
    if len(s1) != len(s2):
        return False

    n = len(s1)
    for i in range(n):
        rotated = s1[i:] + s1[:i]
        if rotated == s2:
            return True
    return False
```

### Complexity
- **Time**: O(n^2) - n rotations, each comparison O(n)
- **Space**: O(n) - rotated string storage

---

## Approach 2: Concatenation (Optimal)

### Idea
Check if s2 is a substring of s1 + s1.

### Visual Explanation
```
s1 = "ABCD"
s2 = "CDAB" (rotation we're checking)

s1 + s1 = "ABCDABCD"
           ||||||
           ABCDABCD
             ^^^^
             CDAB appears at index 2!

Therefore, CDAB IS a rotation of ABCD.
```

### Why This Works
When you concatenate s1 with itself, you create a string that contains ALL possible rotations of s1 as substrings.

```
s1 + s1 for "ABCD":
"A B C D A B C D"
 ^-------^        ABCD (rotation 0)
   ^-------^      BCDA (rotation 1)
     ^-------^    CDAB (rotation 2)
       ^-------^  DABC (rotation 3)
```

### Pseudocode
```
function isRotation(s1, s2):
    if length(s1) != length(s2):
        return false

    concatenated = s1 + s1
    return s2 is substring of concatenated
```

### Complexity
- **Time**: O(n) - String concatenation + substring search
- **Space**: O(n) - Concatenated string

---

## Approach 3: Using KMP (For Substring Search)

### Idea
Use KMP algorithm for efficient substring search in s1+s1.

### Code
```python
def is_rotation_kmp(s1: str, s2: str) -> bool:
    if len(s1) != len(s2):
        return False

    # Build LPS array for s2
    def build_lps(pattern):
        lps = [0] * len(pattern)
        length = 0
        i = 1
        while i < len(pattern):
            if pattern[i] == pattern[length]:
                length += 1
                lps[i] = length
                i += 1
            elif length != 0:
                length = lps[length - 1]
            else:
                lps[i] = 0
                i += 1
        return lps

    # Search s2 in s1+s1
    text = s1 + s1
    lps = build_lps(s2)

    i = j = 0
    while i < len(text):
        if text[i] == s2[j]:
            i += 1
            j += 1
            if j == len(s2):
                return True
        elif j != 0:
            j = lps[j - 1]
        else:
            i += 1

    return False
```

### Complexity
- **Time**: O(n)
- **Space**: O(n)

---

## Dry Run Example

```
s1 = "WATERBOTTLE"
s2 = "ERBOTTLEWAT"

Step 1: Check lengths
        len(s1) = 11, len(s2) = 11 -> Equal, continue

Step 2: Concatenate
        s1 + s1 = "WATERBOTTLEWATERBOTTLE"

Step 3: Search for s2
        "WATERBOTTLEWATERBOTTLE"
                   ^^^^^^^^^^^
        "ERBOTTLEWAT" found at index 3!

Result: TRUE - s2 is a rotation of s1
```

---

## Edge Cases

| s1 | s2 | Output | Reason |
|----|----|----|--------|
| "" | "" | true | Empty strings are rotations of each other |
| "a" | "a" | true | Single char rotation |
| "ab" | "ba" | true | Simple rotation |
| "ab" | "ab" | true | 0-rotation is valid |
| "abc" | "ab" | false | Different lengths |

---

## Comparison Table

| Approach | Time | Space | Notes |
|----------|------|-------|-------|
| Brute Force | O(n^2) | O(n) | Check all rotations |
| Concatenation | O(n) | O(n) | Optimal - simple |
| KMP | O(n) | O(n) | Explicit pattern matching |

---

## Key Takeaways

1. **Concatenation trick** is the key insight for rotation problems
2. s2 is rotation of s1 iff s2 is substring of s1+s1
3. Always check **lengths first** - different lengths can't be rotations
4. **Empty strings** are valid rotations of each other
5. This pattern applies to arrays too (circular array problems)

---

## Related Problems
- Rotate String (LeetCode 796)
- Rotate Array
- Circular Array Loop
- Check if strings are rotations of each other using queues
