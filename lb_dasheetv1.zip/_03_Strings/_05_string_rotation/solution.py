"""
Check Whether One String is a Rotation of Another
==================================================

Problem: Given two strings s1 and s2, check if s2 is a rotation of s1.

Key Insight: s2 is a rotation of s1 if and only if s2 is a substring of s1+s1.

Approaches:
1. Brute Force (Check all rotations)
2. Concatenation (Optimal)
3. KMP Pattern Matching
"""

from typing import List


# =============================================================================
# APPROACH 1: BRUTE FORCE (Check All Rotations)
# =============================================================================

def is_rotation_brute(s1: str, s2: str) -> bool:
    """
    Check rotation by generating all rotations and comparing.

    INTUITION:
    - Try all n possible rotations of s1
    - If any matches s2, return True

    Time Complexity: O(n^2) - n rotations, each comparison O(n)
    Space Complexity: O(n) - for rotated string
    """
    if len(s1) != len(s2):
        return False

    if not s1:  # Both empty
        return True

    n = len(s1)

    for i in range(n):
        # Generate rotation by splitting at index i
        rotated = s1[i:] + s1[:i]
        if rotated == s2:
            return True

    return False


def generate_all_rotations(s: str) -> List[str]:
    """
    Generate all rotations of a string.

    Example: "ABC" -> ["ABC", "BCA", "CAB"]
    """
    if not s:
        return [""]

    n = len(s)
    rotations = []

    for i in range(n):
        rotations.append(s[i:] + s[:i])

    return rotations


# =============================================================================
# APPROACH 2: CONCATENATION (Optimal)
# =============================================================================

def is_rotation_concat(s1: str, s2: str) -> bool:
    """
    Check rotation using the concatenation trick.

    KEY INSIGHT:
    If s2 is a rotation of s1, s2 MUST appear as a substring in s1+s1.

    VISUAL EXPLANATION for s1="ABCD", s2="CDAB":

    s1 + s1 = "ABCDABCD"
               ||||||||
               ABCDABCD
                 ^^^^
               CDAB appears at index 2!

    All rotations of "ABCD" in "ABCDABCD":
    Index 0: ABCD
    Index 1: BCDA
    Index 2: CDAB  <- Our s2!
    Index 3: DABC

    Time Complexity: O(n) - concat O(n) + substring search O(n) average
    Space Complexity: O(n) - concatenated string
    """
    # Different lengths can never be rotations
    if len(s1) != len(s2):
        return False

    # Empty strings are rotations of each other
    if not s1:
        return True

    # The magic: check if s2 is substring of s1+s1
    concatenated = s1 + s1
    return s2 in concatenated


def is_rotation_concat_verbose(s1: str, s2: str) -> bool:
    """
    Same as above but with verbose output for learning.
    """
    print(f"\nChecking if '{s2}' is a rotation of '{s1}':")

    if len(s1) != len(s2):
        print(f"  Different lengths: {len(s1)} vs {len(s2)} -> NOT a rotation")
        return False

    if not s1:
        print("  Both empty -> IS a rotation")
        return True

    concatenated = s1 + s1
    print(f"  s1 + s1 = '{concatenated}'")
    print(f"  Looking for '{s2}' in '{concatenated}'...")

    if s2 in concatenated:
        idx = concatenated.find(s2)
        print(f"  Found at index {idx}!")
        print(f"  '{concatenated}'")
        print(f"  {' ' * (idx + 1)}{'^' * len(s2)}")
        print(f"  -> IS a rotation!")
        return True
    else:
        print(f"  Not found -> NOT a rotation")
        return False


# =============================================================================
# APPROACH 3: KMP PATTERN MATCHING
# =============================================================================

def is_rotation_kmp(s1: str, s2: str) -> bool:
    """
    Check rotation using KMP algorithm for substring search.

    Uses KMP for O(n) guaranteed substring search.

    Time Complexity: O(n)
    Space Complexity: O(n) for LPS array
    """
    if len(s1) != len(s2):
        return False

    if not s1:
        return True

    # Build LPS (Longest Proper Prefix Suffix) array
    def build_lps(pattern: str) -> List[int]:
        m = len(pattern)
        lps = [0] * m
        length = 0
        i = 1

        while i < m:
            if pattern[i] == pattern[length]:
                length += 1
                lps[i] = length
                i += 1
            elif length != 0:
                length = lps[length - 1]
            else:
                lps[i] = 0
                i += 1

        return lps

    # Search s2 in s1+s1 using KMP
    text = s1 + s1
    pattern = s2
    lps = build_lps(pattern)

    i = 0  # Index for text
    j = 0  # Index for pattern

    while i < len(text):
        if text[i] == pattern[j]:
            i += 1
            j += 1

            if j == len(pattern):
                return True  # Pattern found!
        elif j != 0:
            j = lps[j - 1]
        else:
            i += 1

    return False


# =============================================================================
# APPROACH 4: USING DEQUE (Queue-based)
# =============================================================================

from collections import deque

def is_rotation_deque(s1: str, s2: str) -> bool:
    """
    Check rotation using deque operations.

    INTUITION:
    - Rotate s1 by moving front to back
    - Check if any rotation matches s2

    Time Complexity: O(n^2)
    Space Complexity: O(n)
    """
    if len(s1) != len(s2):
        return False

    if not s1:
        return True

    dq = deque(s1)

    for _ in range(len(s1)):
        if ''.join(dq) == s2:
            return True
        # Rotate: move first element to end
        dq.append(dq.popleft())

    return False


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def find_rotation_index(s1: str, s2: str) -> int:
    """
    Find the rotation index (how many positions s1 was rotated to get s2).

    Returns -1 if s2 is not a rotation of s1.

    Example: s1="ABCD", s2="CDAB" -> returns 2
    """
    if len(s1) != len(s2):
        return -1

    if not s1:
        return 0

    concatenated = s1 + s1
    idx = concatenated.find(s2)

    return idx if idx != -1 and idx < len(s1) else -1


def rotate_string(s: str, k: int) -> str:
    """
    Rotate string left by k positions.

    Example: rotate_string("ABCDE", 2) -> "CDEAB"
    """
    if not s:
        return s

    k = k % len(s)  # Handle k > len(s)
    return s[k:] + s[:k]


def rotate_string_right(s: str, k: int) -> str:
    """
    Rotate string right by k positions.

    Example: rotate_string_right("ABCDE", 2) -> "DEABC"
    """
    if not s:
        return s

    k = k % len(s)
    return s[-k:] + s[:-k] if k else s


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Run comprehensive test cases."""

    test_cases = [
        ("ABCD", "CDAB", True),
        ("ABCD", "ACBD", False),
        ("WATERBOTTLE", "ERBOTTLEWAT", True),
        ("", "", True),
        ("a", "a", True),
        ("ab", "ba", True),
        ("ab", "ab", True),
        ("abc", "bca", True),
        ("abc", "cab", True),
        ("abc", "acb", False),
        ("hello", "lohel", True),
        ("hello", "llohe", True),
        ("hello", "world", False),
        ("abc", "abcd", False),  # Different lengths
    ]

    print("=" * 60)
    print("STRING ROTATION - TEST RESULTS")
    print("=" * 60)

    approaches = [
        ("Brute Force", is_rotation_brute),
        ("Concatenation", is_rotation_concat),
        ("KMP", is_rotation_kmp),
        ("Deque", is_rotation_deque),
    ]

    for name, func in approaches:
        print(f"\n--- {name} ---")
        all_passed = True
        for s1, s2, expected in test_cases:
            result = func(s1, s2)
            if result != expected:
                all_passed = False
                print(f"  FAIL: '{s1}', '{s2}' -> {result} (expected {expected})")
        if all_passed:
            print(f"  All {len(test_cases)} test cases PASSED!")


def demonstrate():
    """Demonstrate the algorithm step by step."""

    print("\n" + "=" * 60)
    print("STEP-BY-STEP DEMONSTRATION")
    print("=" * 60)

    # Test case 1
    is_rotation_concat_verbose("ABCD", "CDAB")

    # Test case 2
    is_rotation_concat_verbose("HELLO", "LOHEL")

    # Test case 3
    is_rotation_concat_verbose("ABCD", "ACBD")

    # Show all rotations
    print("\n--- All Rotations of 'HELLO' ---")
    rotations = generate_all_rotations("HELLO")
    for i, rot in enumerate(rotations):
        print(f"  Rotation {i}: {rot}")

    # Show rotation index
    print("\n--- Finding Rotation Index ---")
    s1, s2 = "ABCDE", "CDEAB"
    idx = find_rotation_index(s1, s2)
    print(f"  '{s2}' is rotation of '{s1}' by {idx} positions")


if __name__ == "__main__":
    run_tests()
    demonstrate()
