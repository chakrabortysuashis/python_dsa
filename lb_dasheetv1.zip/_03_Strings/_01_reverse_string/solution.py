"""
Reverse a String
================

Problem: Given a string s, reverse it and return the reversed string.

Multiple approaches demonstrated:
1. Brute Force (string concatenation)
2. Using List
3. Two Pointer (optimal for in-place)
4. Python Slicing
5. Recursion
"""

from typing import List


# =============================================================================
# APPROACH 1: BRUTE FORCE (String Concatenation)
# =============================================================================

def reverse_brute_force(s: str) -> str:
    """
    Reverse string by iterating backwards and concatenating.

    INTUITION:
    - Start from the last character
    - Keep adding characters to a new string

    Time Complexity: O(n^2) - Each concatenation creates new string
    Space Complexity: O(n) - New string created

    WARNING: This is inefficient due to string immutability!
    Each += creates a new string object.
    """
    result = ""

    # Iterate from last index to first
    for i in range(len(s) - 1, -1, -1):
        result += s[i]  # O(n) operation each time!

    return result


# =============================================================================
# APPROACH 2: USING LIST (Better Brute Force)
# =============================================================================

def reverse_using_list(s: str) -> str:
    """
    Reverse string by appending to list, then joining.

    INTUITION:
    - Lists have O(1) amortized append
    - Build reversed list, then join once

    Time Complexity: O(n) - Single pass + join
    Space Complexity: O(n) - List storage

    This is much better than string concatenation!
    """
    chars = []

    # Iterate from last index to first
    for i in range(len(s) - 1, -1, -1):
        chars.append(s[i])  # O(1) amortized

    return ''.join(chars)  # O(n) join operation


# =============================================================================
# APPROACH 3: TWO POINTER (Optimal for In-Place)
# =============================================================================

def reverse_two_pointer(s: str) -> str:
    """
    Reverse string using two pointers swapping from ends.

    INTUITION:
    - Use two pointers: left at start, right at end
    - Swap characters and move pointers toward center
    - Stop when pointers meet or cross

    VISUAL DRY RUN for "HELLO":

    Initial: ['H', 'E', 'L', 'L', 'O']
              ^                   ^
              L=0                 R=4

    Step 1:  Swap s[0] and s[4]
             ['O', 'E', 'L', 'L', 'H']
                   ^         ^
                   L=1       R=3

    Step 2:  Swap s[1] and s[3]
             ['O', 'L', 'L', 'E', 'H']
                        ^
                       L=R=2

    Step 3:  L >= R, STOP

    Result: "OLLEH"

    Time Complexity: O(n) - Each element visited once
    Space Complexity: O(n) for list, O(1) if truly in-place
    """
    # Convert to list for mutability
    chars = list(s)

    # Initialize two pointers
    left = 0
    right = len(chars) - 1

    # Swap until pointers meet
    while left < right:
        # Swap characters at left and right
        chars[left], chars[right] = chars[right], chars[left]

        # Move pointers toward center
        left += 1
        right -= 1

    return ''.join(chars)


def reverse_in_place(chars: List[str]) -> None:
    """
    Reverse character array IN-PLACE (LeetCode 344 style).

    Modifies the input list directly.

    Time Complexity: O(n)
    Space Complexity: O(1) - No extra space!
    """
    left = 0
    right = len(chars) - 1

    while left < right:
        chars[left], chars[right] = chars[right], chars[left]
        left += 1
        right -= 1


# =============================================================================
# APPROACH 4: PYTHON SLICING (Pythonic)
# =============================================================================

def reverse_slicing(s: str) -> str:
    """
    Reverse string using Python's slice notation.

    INTUITION:
    - s[start:stop:step] with step=-1 reverses
    - s[::-1] means "all elements, step backwards by 1"

    Time Complexity: O(n) - Creates new string
    Space Complexity: O(n) - New string created

    This is the most Pythonic way!
    """
    return s[::-1]


# =============================================================================
# APPROACH 5: RECURSION
# =============================================================================

def reverse_recursive(s: str) -> str:
    """
    Reverse string using recursion.

    INTUITION:
    - Base case: empty or single char string is already reversed
    - Recursive case: last char + reverse(rest)

    RECURSION TREE for "ABC":

    reverse("ABC")
    = "C" + reverse("AB")
         = "B" + reverse("A")
              = "A" (base case)
         = "B" + "A" = "BA"
    = "C" + "BA" = "CBA"

    Time Complexity: O(n^2) - String slicing and concatenation
    Space Complexity: O(n) - Recursion stack

    Note: Not efficient, but good for understanding recursion.
    """
    # Base case: empty or single character
    if len(s) <= 1:
        return s

    # Recursive case: last char + reverse of rest
    return s[-1] + reverse_recursive(s[:-1])


def reverse_recursive_optimized(s: str, left: int = None, right: int = None) -> str:
    """
    Optimized recursive approach using indices.

    Avoids creating substring copies by using indices.
    """
    if left is None:
        left = 0
        right = len(s) - 1

    if left >= right:
        return s

    # Convert to list for swapping
    chars = list(s)
    chars[left], chars[right] = chars[right], chars[left]

    return reverse_recursive_optimized(''.join(chars), left + 1, right - 1)


# =============================================================================
# APPROACH 6: USING STACK
# =============================================================================

def reverse_using_stack(s: str) -> str:
    """
    Reverse string using a stack (LIFO).

    INTUITION:
    - Push all characters onto stack
    - Pop all characters to get reversed order

    Time Complexity: O(n)
    Space Complexity: O(n)
    """
    stack = list(s)  # Push all characters
    result = []

    while stack:
        result.append(stack.pop())  # Pop in reverse order

    return ''.join(result)


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def reverse_words(s: str) -> str:
    """
    Reverse the order of words in a string.

    Example: "Hello World" -> "World Hello"

    Time Complexity: O(n)
    Space Complexity: O(n)
    """
    words = s.split()
    return ' '.join(reversed(words))


def reverse_each_word(s: str) -> str:
    """
    Reverse each word individually while keeping word order.

    Example: "Hello World" -> "olleH dlroW"

    Time Complexity: O(n)
    Space Complexity: O(n)
    """
    return ' '.join(word[::-1] for word in s.split())


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Run comprehensive test cases for all approaches."""

    test_cases = [
        ("hello", "olleh"),
        ("Hannah", "hannaH"),
        ("A", "A"),
        ("", ""),
        ("ab", "ba"),
        ("racecar", "racecar"),  # Palindrome
        ("12345", "54321"),
        ("Hello World", "dlroW olleH"),
    ]

    approaches = [
        ("Brute Force", reverse_brute_force),
        ("Using List", reverse_using_list),
        ("Two Pointer", reverse_two_pointer),
        ("Slicing", reverse_slicing),
        ("Recursive", reverse_recursive),
        ("Using Stack", reverse_using_stack),
    ]

    print("=" * 70)
    print("REVERSE STRING - TEST RESULTS")
    print("=" * 70)

    for name, func in approaches:
        print(f"\n{name}:")
        all_passed = True
        for s, expected in test_cases:
            result = func(s)
            status = "PASS" if result == expected else "FAIL"
            if result != expected:
                all_passed = False
                print(f"  {status}: '{s}' -> '{result}' (expected '{expected}')")
        if all_passed:
            print(f"  All {len(test_cases)} test cases PASSED!")

    # Test in-place reversal
    print("\nIn-Place Reversal:")
    chars = list("hello")
    reverse_in_place(chars)
    result = ''.join(chars)
    print(f"  Input: 'hello' -> Output: '{result}' - {'PASS' if result == 'olleh' else 'FAIL'}")

    # Test word reversal functions
    print("\nWord Reversal Functions:")
    s = "Hello World"
    print(f"  reverse_words('{s}'): '{reverse_words(s)}'")
    print(f"  reverse_each_word('{s}'): '{reverse_each_word(s)}'")


def demonstrate_complexity():
    """Demonstrate time complexity differences."""
    import time

    sizes = [1000, 5000, 10000]

    print("\n" + "=" * 70)
    print("TIME COMPLEXITY DEMONSTRATION")
    print("=" * 70)

    for size in sizes:
        s = "a" * size

        # Measure brute force (skip for large sizes)
        if size <= 5000:
            start = time.time()
            reverse_brute_force(s)
            brute_time = time.time() - start
        else:
            brute_time = float('inf')

        # Measure two pointer
        start = time.time()
        reverse_two_pointer(s)
        two_ptr_time = time.time() - start

        # Measure slicing
        start = time.time()
        reverse_slicing(s)
        slice_time = time.time() - start

        print(f"\nSize: {size}")
        if brute_time != float('inf'):
            print(f"  Brute Force: {brute_time:.6f}s")
        else:
            print(f"  Brute Force: (skipped - too slow)")
        print(f"  Two Pointer: {two_ptr_time:.6f}s")
        print(f"  Slicing:     {slice_time:.6f}s")


if __name__ == "__main__":
    run_tests()
    demonstrate_complexity()
