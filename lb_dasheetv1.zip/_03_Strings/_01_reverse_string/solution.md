# Reverse a String

## Problem Statement
Given a string `s`, reverse it and return the reversed string.

**Example 1:**
```
Input: s = "hello"
Output: "olleh"
```

**Example 2:**
```
Input: s = "Hannah"
Output: "hannaH"
```

**Constraints:**
- 1 <= s.length <= 10^5
- s consists of printable ASCII characters

---

## Intuition and Thought Process

Reversing a string is one of the most fundamental string operations. The key insight is that:
- The first character should become the last
- The last character should become the first
- Characters mirror around the center

```
Original:  H E L L O
Index:     0 1 2 3 4

Reversed:  O L L E H
Index:     0 1 2 3 4

Mapping: position i -> position (n-1-i)
```

### Why Two Pointers?
Instead of creating a new string by iterating backwards, we can swap characters in-place using two pointers:
- One pointer starts from the beginning (left)
- One pointer starts from the end (right)
- Swap characters at both pointers and move them toward center

---

## Approach 1: Brute Force (Create New String)

### Idea
Iterate through the string from end to beginning and build a new string.

### Algorithm
1. Initialize an empty result string
2. Iterate from the last index to 0
3. Append each character to result
4. Return result

### Code
```python
def reverse_brute(s: str) -> str:
    result = ""
    for i in range(len(s) - 1, -1, -1):
        result += s[i]
    return result
```

### Complexity
- **Time**: O(n^2) - String concatenation creates new string each time
- **Space**: O(n) - New string created

---

## Approach 2: Using List (Better Brute Force)

### Idea
Use a list to avoid quadratic time from string concatenation.

### Algorithm
1. Create an empty list
2. Iterate backwards and append to list
3. Join list into string

### Code
```python
def reverse_list(s: str) -> str:
    chars = []
    for i in range(len(s) - 1, -1, -1):
        chars.append(s[i])
    return ''.join(chars)
```

### Complexity
- **Time**: O(n)
- **Space**: O(n)

---

## Approach 3: Two Pointer (Optimal for In-Place)

### Idea
Use two pointers to swap characters from opposite ends, meeting in the middle.

### Algorithm
1. Convert string to list (for mutability)
2. Initialize `left = 0`, `right = n - 1`
3. While `left < right`:
   - Swap characters at left and right
   - Increment left, decrement right
4. Join and return

### Visual Dry Run

```
Input: "HELLO"
Convert to list: ['H', 'E', 'L', 'L', 'O']

Step 1: left=0, right=4
        ['H', 'E', 'L', 'L', 'O']
         ^                   ^
         L                   R
        Swap H and O:
        ['O', 'E', 'L', 'L', 'H']

Step 2: left=1, right=3
        ['O', 'E', 'L', 'L', 'H']
              ^         ^
              L         R
        Swap E and L:
        ['O', 'L', 'L', 'E', 'H']

Step 3: left=2, right=2
        ['O', 'L', 'L', 'E', 'H']
                   ^
                  L=R
        left >= right, STOP

Output: "OLLEH"
```

### Pseudocode
```
function reverse(s):
    chars = list(s)
    left = 0
    right = length(chars) - 1

    while left < right:
        swap(chars[left], chars[right])
        left = left + 1
        right = right - 1

    return join(chars)
```

### Code
```python
def reverse_two_pointer(s: str) -> str:
    chars = list(s)
    left, right = 0, len(chars) - 1

    while left < right:
        chars[left], chars[right] = chars[right], chars[left]
        left += 1
        right -= 1

    return ''.join(chars)
```

### Complexity
- **Time**: O(n) - Each character visited once
- **Space**: O(n) - List created (O(1) if truly in-place like in C/C++)

---

## Approach 4: Python Slicing (Pythonic)

### Idea
Python's slicing with step -1 reverses the string.

### Code
```python
def reverse_slice(s: str) -> str:
    return s[::-1]
```

### Complexity
- **Time**: O(n)
- **Space**: O(n)

---

## Approach 5: Recursion

### Idea
Reverse = last character + reverse(rest of string)

### Code
```python
def reverse_recursive(s: str) -> str:
    if len(s) <= 1:
        return s
    return s[-1] + reverse_recursive(s[:-1])
```

### Complexity
- **Time**: O(n^2) - Due to string slicing and concatenation
- **Space**: O(n) - Recursion stack

---

## Comparison Table

| Approach | Time | Space | In-Place | Notes |
|----------|------|-------|----------|-------|
| Brute Force | O(n^2) | O(n) | No | String concat is expensive |
| List Method | O(n) | O(n) | No | Better than brute force |
| Two Pointer | O(n) | O(1)* | Yes | Optimal for mutable |
| Python Slice | O(n) | O(n) | No | Most Pythonic |
| Recursion | O(n^2) | O(n) | No | Not recommended |

*O(1) extra space if working with mutable character array

---

## Key Takeaways

1. **Two-pointer technique** is the go-to approach for array/string reversal
2. **In-place operations** save space but require mutable data structures
3. **String immutability** in Python means we often need to convert to list first
4. **Slicing** is the most Pythonic but understand the underlying mechanics
5. **Avoid string concatenation in loops** - it's O(n) per operation

---

## Related Problems
- Reverse Words in a String
- Reverse Only Letters
- Valid Palindrome
- Reverse Integer
