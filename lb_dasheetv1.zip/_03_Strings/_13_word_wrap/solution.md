# Word Wrap Problem

## Problem Statement
Given an array of word lengths and a line width, arrange words into lines to **minimize the total cost** of extra spaces at the end of lines.

The cost function is typically: **(extra spaces)^3** or **(extra spaces)^2** to penalize uneven distribution.

**Example 1:**
```
Words: ["aaa", "bb", "cc", "ddddd"]
Word lengths: [3, 2, 2, 5]
Line width: 6

Option 1: "aaa bb" | "cc" | "ddddd"
          Cost: 1^3 + 4^3 + 1^3 = 1 + 64 + 1 = 66

Option 2: "aaa" | "bb cc" | "ddddd"
          Cost: 3^3 + 1^3 + 1^3 = 27 + 1 + 1 = 29  (Better!)

Optimal: Option 2 with total cost 29
```

**Example 2:**
```
Words: [3, 2, 2, 2, 3]
Line width: 6

Greedy: "3 2" | "2 2" | "3"
        Extra: 1, 0, 3 -> Cost: 1 + 0 + 27 = 28

DP:     "3" | "2 2 2" | "3"
        Extra: 3, 0, 3 -> Cost: 27 + 0 + 27 = 54

Greedy actually wins here! But not always...
```

---

## Intuition and Thought Process

### Why Not Just Greedy?
Greedy approach: Put as many words as fit on each line.

**Problem**: Greedy can create very uneven lines.

```
Line width = 10
Words: ["The", "quick", "brown", "fox"]
       Lengths: [3, 5, 5, 3]

Greedy: "The quick" (1 space left) | "brown fox" (0 spaces)
        Cost: 1 + 0 = 1

But consider: "The" | "quick fox"... wait, "quick" (5) + space (1) + "fox" (3) = 9, fits!
Actually greedy might be: "The quick" | "brown" | "fox"
        Cost: 1 + 5^3 + 7^3 = 1 + 125 + 343 = 469!
```

### DP Insight
We need to consider **all possible break points** and pick the combination that minimizes total cost.

**State**: `dp[i]` = minimum cost to arrange words `i` to `n-1`

**Transition**: Try putting words `i` to `j` on one line (if they fit), then add cost of remaining words.

---

## Cost Function Variants

### Variant 1: Sum of Extra Spaces (Linear)
```
cost = sum of (extra spaces on each line)
```
*Simple but doesn't penalize uneven distribution*

### Variant 2: Sum of Squares
```
cost = sum of (extra spaces)^2
```
*Moderately penalizes unevenness*

### Variant 3: Sum of Cubes (Knuth's)
```
cost = sum of (extra spaces)^3
```
*Strongly penalizes very uneven lines - used in TeX*

### Variant 4: Badness (Infinity for overflow)
```
cost = infinity if words don't fit
     = (extra spaces)^3 otherwise
Last line often has 0 cost (no penalty)
```

---

## Approach 1: Greedy (Not Optimal)

### Algorithm
1. Start with first word on current line
2. Keep adding words while they fit (with space)
3. When next word doesn't fit, start new line
4. Repeat until all words placed

### Why It Fails
```
Width = 6, Words = [3, 3, 1]

Greedy: "3 3" (0 extra) | "1" (5 extra)
        Cost: 0 + 125 = 125

Optimal: "3" (3 extra) | "3 1" (2 extra)
         Cost: 27 + 8 = 35
```

**Time**: O(n)
**Space**: O(1)

---

## Approach 2: Dynamic Programming (Optimal)

### State Definition
`dp[i]` = minimum cost to arrange words from index `i` to end

### Recurrence Relation
```
dp[i] = min over all j where words[i..j] fit on one line:
        cost(i, j) + dp[j + 1]

where cost(i, j) = (extra spaces when words i to j on one line)^3
```

### Base Case
`dp[n] = 0` (no words left = no cost)

### Visual Dry Run
```
Words: [3, 2, 2, 5], Width: 6

Step 1: Calculate line costs (extra_spaces^3)
        Line [0]:    width - 3 = 3 -> cost = 27
        Line [0,1]:  width - (3+1+2) = 0 -> cost = 0
        Line [0,1,2]: 3+1+2+1+2 = 9 > 6, doesn't fit
        Line [1]:    6 - 2 = 4 -> cost = 64
        Line [1,2]:  6 - (2+1+2) = 1 -> cost = 1
        Line [2]:    6 - 2 = 4 -> cost = 64
        Line [2,3]:  2+1+5 = 8 > 6, doesn't fit
        Line [3]:    6 - 5 = 1 -> cost = 1

Step 2: DP from right to left
        dp[4] = 0 (base case)

        dp[3] = cost(3,3) + dp[4]
              = 1 + 0 = 1

        dp[2] = min(
                  cost(2,2) + dp[3] = 64 + 1 = 65,
                  cost(2,3) = doesn't fit
                ) = 65

        dp[1] = min(
                  cost(1,1) + dp[2] = 64 + 65 = 129,
                  cost(1,2) + dp[3] = 1 + 1 = 2
                ) = 2

        dp[0] = min(
                  cost(0,0) + dp[1] = 27 + 2 = 29,
                  cost(0,1) + dp[2] = 0 + 65 = 65
                ) = 29

Answer: dp[0] = 29
Arrangement: "3" | "2 2" | "5" -> [aaa] [bb cc] [ddddd]
```

### Pseudocode
```
function wordWrap(lengths, width):
    n = length of lengths
    dp = array of size n+1, initialized to infinity
    dp[n] = 0

    // DP from right to left
    for i from n-1 down to 0:
        currentLength = 0

        for j from i to n-1:
            // Add word j to current line
            if j == i:
                currentLength = lengths[j]
            else:
                currentLength += 1 + lengths[j]  // +1 for space

            // Check if fits
            if currentLength > width:
                break

            // Calculate cost
            extraSpaces = width - currentLength
            cost = extraSpaces * extraSpaces * extraSpaces

            // Skip cost for last line (optional variant)
            if j == n-1:
                cost = 0

            dp[i] = min(dp[i], cost + dp[j+1])

    return dp[0]
```

### Complexity
- **Time**: O(n^2) - for each position, try all valid endpoints
- **Space**: O(n) - for DP array

---

## Approach 3: DP with Path Reconstruction

### Extension
Store which `j` gave the minimum for each `i` to reconstruct the actual line breaks.

```
parent[i] = j means words i to j go on one line
```

### Trace Back
```
i = 0
while i < n:
    j = parent[i]
    print words[i] to words[j] on one line
    i = j + 1
```

---

## Space Optimization

The DP only needs `dp[j+1]` values, but since `j` can be any value from `i` to `n-1`, we can't easily reduce to O(1) space.

However, we can use O(n) space efficiently with bottom-up DP.

---

## Comparison Table

| Approach | Time | Space | Optimal? | Notes |
|----------|------|-------|----------|-------|
| Greedy | O(n) | O(1) | No | Fast but suboptimal |
| DP | O(n^2) | O(n) | Yes | Standard solution |
| DP with SMAWK | O(n) | O(n) | Yes | Advanced, uses matrix optimization |

---

## Edge Cases

| Input | Handling |
|-------|----------|
| Single word wider than line | Impossible - return infinity or handle specially |
| All words fit on one line | Cost = 0 (or extra^3 if not last line) |
| Each word needs own line | Sum of individual costs |
| Empty input | Cost = 0 |
| Last line special | Often cost = 0 for last line |

---

## Variations

### 1. Justify Text (No Last Line Penalty)
Last line doesn't get extra space penalty (like LaTeX/Word).

### 2. Minimum Lines (Different Objective)
Instead of cost, minimize number of lines used.

### 3. Different Cost Functions
- Linear: less aggressive balancing
- Quadratic: moderate balancing
- Cubic: strong balancing (Knuth)

### 4. With Hyphenation
Words can be broken with hyphens - much more complex.

---

## Key Takeaways

1. **Greedy is not optimal** for minimizing space penalties
2. **DP explores all valid break points** to find minimum cost
3. **Cost function matters**: cubic penalizes unevenness more
4. **Last line exception**: often treated specially (no penalty)
5. **O(n^2) is acceptable** for reasonable document sizes
6. **Knuth-Plass algorithm** is the production-grade version in TeX

---

## Related Problems
- Text Justification (LeetCode 68)
- Partition Array for Maximum Sum
- Minimum Cost to Cut a Stick
- Matrix Chain Multiplication (similar DP structure)
