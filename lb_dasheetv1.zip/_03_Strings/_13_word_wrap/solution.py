"""
Word Wrap Problem
=================

Problem: Given word lengths and line width, arrange words into lines
to minimize the total cost of extra spaces.

Cost function: (extra_spaces)^3 (Knuth's approach)

Approaches:
1. Greedy - O(n) but not optimal
2. Dynamic Programming - O(n^2), optimal
3. DP with path reconstruction

Time: O(n^2)
Space: O(n)
"""

from typing import List, Tuple
import math


# =============================================================================
# APPROACH 1: GREEDY (Not Optimal, but fast)
# =============================================================================

def word_wrap_greedy(lengths: List[int], width: int) -> Tuple[int, List[List[int]]]:
    """
    Greedy approach: Pack as many words as possible on each line.

    NOT OPTIMAL! Can produce very uneven lines.

    ALGORITHM:
    1. Add words to current line while they fit
    2. When next word doesn't fit, start new line
    3. Calculate cost based on extra spaces

    Example where greedy fails:
    lengths = [3, 3, 1], width = 6
    Greedy: [3,3] (0 extra) | [1] (5 extra) -> cost = 0 + 125 = 125
    Optimal: [3] (3 extra) | [3,1] (1 extra) -> cost = 27 + 1 = 28

    Time Complexity: O(n)
    Space Complexity: O(n) for storing lines
    """
    if not lengths:
        return 0, []

    n = len(lengths)
    lines = []
    current_line = []
    current_length = 0

    for i, word_len in enumerate(lengths):
        # Check if word fits on current line
        # Need +1 for space if not first word on line
        space_needed = word_len if not current_line else word_len + 1

        if current_length + space_needed <= width:
            # Word fits - add to current line
            current_line.append(i)
            current_length += space_needed
        else:
            # Word doesn't fit - start new line
            lines.append(current_line)
            current_line = [i]
            current_length = word_len

    # Don't forget the last line
    if current_line:
        lines.append(current_line)

    # Calculate total cost
    total_cost = 0
    for i, line in enumerate(lines):
        line_length = sum(lengths[idx] for idx in line) + len(line) - 1
        extra_spaces = width - line_length

        # Last line typically has no penalty
        if i < len(lines) - 1:
            total_cost += extra_spaces ** 3

    return total_cost, lines


# =============================================================================
# APPROACH 2: DYNAMIC PROGRAMMING (Optimal)
# =============================================================================

def word_wrap_dp(lengths: List[int], width: int) -> int:
    """
    DP approach: Find minimum cost arrangement.

    STATE:
    dp[i] = minimum cost to arrange words from index i to end

    RECURRENCE:
    dp[i] = min over all j where words[i..j] fit on one line:
            cost(i, j) + dp[j + 1]

    BASE CASE:
    dp[n] = 0 (no words = no cost)

    VISUAL for lengths=[3,2,2,5], width=6:

    dp[4] = 0 (base case)

    dp[3]: only word 5 fits alone
           extra = 6-5 = 1, cost = 1
           dp[3] = 1 + dp[4] = 1

    dp[2]: word 2 alone: extra=4, cost=64, total = 64 + dp[3] = 65
           words 2,5 together: 2+1+5=8 > 6, doesn't fit
           dp[2] = 65

    dp[1]: word 2 alone: extra=4, cost=64, total = 64 + dp[2] = 129
           words 2,2 together: 2+1+2=5, extra=1, cost=1, total = 1 + dp[3] = 2
           dp[1] = 2

    dp[0]: word 3 alone: extra=3, cost=27, total = 27 + dp[1] = 29
           words 3,2 together: 3+1+2=6, extra=0, cost=0, total = 0 + dp[2] = 65
           dp[0] = 29

    Answer: 29

    Time Complexity: O(n^2)
    Space Complexity: O(n)
    """
    if not lengths:
        return 0

    n = len(lengths)

    # Check if any word is too long
    for word_len in lengths:
        if word_len > width:
            return float('inf')  # Impossible

    # dp[i] = min cost to arrange words[i:] on lines
    dp = [float('inf')] * (n + 1)
    dp[n] = 0  # Base case: no words left

    # Fill DP from right to left
    for i in range(n - 1, -1, -1):
        current_length = 0

        for j in range(i, n):
            # Calculate length if words i to j are on same line
            if j == i:
                current_length = lengths[j]
            else:
                current_length += 1 + lengths[j]  # +1 for space between words

            # If doesn't fit, no point checking further
            if current_length > width:
                break

            # Calculate extra spaces and cost
            extra_spaces = width - current_length

            # Cost is cube of extra spaces (Knuth's approach)
            # Last line (j == n-1) typically has no penalty
            if j == n - 1:
                cost = 0  # No penalty for last line
            else:
                cost = extra_spaces ** 3

            # Update DP
            dp[i] = min(dp[i], cost + dp[j + 1])

    return dp[0]


# =============================================================================
# APPROACH 3: DP WITH PATH RECONSTRUCTION
# =============================================================================

def word_wrap_dp_with_path(lengths: List[int], width: int) -> Tuple[int, List[List[int]]]:
    """
    DP with path reconstruction to get actual line breaks.

    Returns: (total_cost, list_of_lines)
    where each line is a list of word indices.

    Example:
    >>> word_wrap_dp_with_path([3, 2, 2, 5], 6)
    (29, [[0], [1, 2], [3]])
    # Means: word 0 alone, words 1-2 together, word 3 alone
    """
    if not lengths:
        return 0, []

    n = len(lengths)

    # Check if any word is too long
    for word_len in lengths:
        if word_len > width:
            return float('inf'), []

    # dp[i] = min cost to arrange words[i:]
    dp = [float('inf')] * (n + 1)
    dp[n] = 0

    # parent[i] = j means words i to j go on one line
    parent = [-1] * n

    # Fill DP from right to left
    for i in range(n - 1, -1, -1):
        current_length = 0

        for j in range(i, n):
            if j == i:
                current_length = lengths[j]
            else:
                current_length += 1 + lengths[j]

            if current_length > width:
                break

            extra_spaces = width - current_length

            if j == n - 1:
                cost = 0
            else:
                cost = extra_spaces ** 3

            if cost + dp[j + 1] < dp[i]:
                dp[i] = cost + dp[j + 1]
                parent[i] = j  # Remember which j gave minimum

    # Reconstruct path
    lines = []
    i = 0
    while i < n:
        j = parent[i]
        lines.append(list(range(i, j + 1)))
        i = j + 1

    return dp[0], lines


# =============================================================================
# APPROACH 4: DP WITH DIFFERENT COST FUNCTIONS
# =============================================================================

def word_wrap_linear_cost(lengths: List[int], width: int) -> int:
    """
    Word wrap with LINEAR cost (extra spaces, not cubed).

    Less aggressive balancing - just sums extra spaces.
    """
    if not lengths:
        return 0

    n = len(lengths)
    dp = [float('inf')] * (n + 1)
    dp[n] = 0

    for i in range(n - 1, -1, -1):
        current_length = 0

        for j in range(i, n):
            if j == i:
                current_length = lengths[j]
            else:
                current_length += 1 + lengths[j]

            if current_length > width:
                break

            extra_spaces = width - current_length
            cost = 0 if j == n - 1 else extra_spaces  # Linear cost

            dp[i] = min(dp[i], cost + dp[j + 1])

    return dp[0]


def word_wrap_quadratic_cost(lengths: List[int], width: int) -> int:
    """
    Word wrap with QUADRATIC cost (extra spaces squared).

    Moderate balancing - middle ground between linear and cubic.
    """
    if not lengths:
        return 0

    n = len(lengths)
    dp = [float('inf')] * (n + 1)
    dp[n] = 0

    for i in range(n - 1, -1, -1):
        current_length = 0

        for j in range(i, n):
            if j == i:
                current_length = lengths[j]
            else:
                current_length += 1 + lengths[j]

            if current_length > width:
                break

            extra_spaces = width - current_length
            cost = 0 if j == n - 1 else extra_spaces ** 2  # Quadratic

            dp[i] = min(dp[i], cost + dp[j + 1])

    return dp[0]


# =============================================================================
# UTILITY: PRINT WRAPPED TEXT
# =============================================================================

def print_wrapped_text(words: List[str], width: int):
    """
    Print text wrapped according to optimal DP solution.
    """
    lengths = [len(word) for word in words]
    cost, lines = word_wrap_dp_with_path(lengths, width)

    print(f"Line width: {width}")
    print(f"Total cost: {cost}")
    print("-" * width)

    for line_indices in lines:
        line_words = [words[i] for i in line_indices]
        line_text = ' '.join(line_words)
        extra = width - len(line_text)
        print(f"'{line_text}'" + " " * extra + f" ({extra} extra)")

    print("-" * width)


def format_justified_text(words: List[str], width: int) -> List[str]:
    """
    Format text with full justification (distribute extra spaces).

    Returns list of lines with proper spacing.
    """
    lengths = [len(word) for word in words]
    _, lines = word_wrap_dp_with_path(lengths, width)

    result = []
    for i, line_indices in enumerate(lines):
        line_words = [words[idx] for idx in line_indices]

        if i == len(lines) - 1 or len(line_words) == 1:
            # Last line or single word - left justify
            result.append(' '.join(line_words).ljust(width))
        else:
            # Full justification - distribute spaces evenly
            total_spaces = width - sum(len(w) for w in line_words)
            gaps = len(line_words) - 1
            space_per_gap = total_spaces // gaps
            extra_spaces = total_spaces % gaps

            justified_line = line_words[0]
            for j, word in enumerate(line_words[1:]):
                spaces = space_per_gap + (1 if j < extra_spaces else 0)
                justified_line += ' ' * spaces + word

            result.append(justified_line)

    return result


# =============================================================================
# VERBOSE VERSION FOR LEARNING
# =============================================================================

def word_wrap_verbose(lengths: List[int], width: int) -> int:
    """
    Verbose version showing DP computation step by step.
    """
    print(f"\nWord Wrap DP Visualization")
    print(f"Lengths: {lengths}, Width: {width}")
    print("=" * 50)

    if not lengths:
        print("Empty input - cost = 0")
        return 0

    n = len(lengths)
    dp = [float('inf')] * (n + 1)
    dp[n] = 0

    print(f"Base case: dp[{n}] = 0")

    for i in range(n - 1, -1, -1):
        print(f"\nComputing dp[{i}]:")
        current_length = 0
        best_j = -1
        best_cost = float('inf')

        for j in range(i, n):
            if j == i:
                current_length = lengths[j]
            else:
                current_length += 1 + lengths[j]

            if current_length > width:
                print(f"  j={j}: length={current_length} > {width}, doesn't fit")
                break

            extra_spaces = width - current_length
            if j == n - 1:
                cost = 0
            else:
                cost = extra_spaces ** 3

            total = cost + dp[j + 1]

            status = ""
            if total < best_cost:
                best_cost = total
                best_j = j
                status = " <-- best so far"

            print(f"  j={j}: line_len={current_length}, extra={extra_spaces}, "
                  f"cost={cost}, total={total}{status}")

        dp[i] = best_cost
        print(f"  => dp[{i}] = {best_cost} (break after word {best_j})")

    print(f"\n{'='*50}")
    print(f"Final answer: dp[0] = {dp[0]}")

    return dp[0]


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Run comprehensive test cases."""

    test_cases = [
        # (lengths, width, expected_cost)
        ([3, 2, 2, 5], 6, 29),     # Example from problem
        ([3, 2, 2], 6, 1),         # Three short words
        ([3, 3, 1], 6, 28),        # Greedy would give 125
        ([1, 1, 1, 1], 6, 0),      # All fit on one line
        ([6], 6, 0),               # Single word, exact fit
        ([5], 6, 0),               # Single word, last line
        ([], 6, 0),                # Empty
        ([2, 3, 2, 3, 2], 6, 29),  # Multiple lines
    ]

    print("=" * 60)
    print("WORD WRAP - TEST RESULTS")
    print("=" * 60)

    all_passed = True

    for lengths, width, expected in test_cases:
        dp_result = word_wrap_dp(lengths, width)
        greedy_result, _ = word_wrap_greedy(lengths, width)

        status = "PASS" if dp_result == expected else "FAIL"
        if dp_result != expected:
            all_passed = False

        print(f"{status}: lengths={lengths}, width={width}")
        print(f"       DP cost={dp_result}, Greedy cost={greedy_result}, expected={expected}")

    print("-" * 60)
    print(f"{'All tests passed!' if all_passed else 'Some tests failed!'}")


def demonstrate():
    """Demonstrate the algorithm step by step."""

    print("\n" + "=" * 60)
    print("STEP-BY-STEP DEMONSTRATION")
    print("=" * 60)

    # Verbose demonstration
    word_wrap_verbose([3, 2, 2, 5], 6)

    # Show greedy vs DP difference
    print("\n" + "-" * 40)
    print("GREEDY VS DP COMPARISON")
    print("-" * 40)

    lengths = [3, 3, 1]
    width = 6
    greedy_cost, greedy_lines = word_wrap_greedy(lengths, width)
    dp_cost, dp_lines = word_wrap_dp_with_path(lengths, width)

    print(f"lengths={lengths}, width={width}")
    print(f"Greedy: cost={greedy_cost}, lines={greedy_lines}")
    print(f"DP:     cost={dp_cost}, lines={dp_lines}")

    # Print wrapped text example
    print("\n" + "-" * 40)
    print("TEXT WRAPPING EXAMPLE")
    print("-" * 40)

    words = ["The", "quick", "brown", "fox", "jumps", "over", "the", "lazy", "dog"]
    print_wrapped_text(words, 15)

    # Justified text
    print("\n" + "-" * 40)
    print("JUSTIFIED TEXT")
    print("-" * 40)

    justified = format_justified_text(words, 15)
    for line in justified:
        print(f"|{line}|")


if __name__ == "__main__":
    run_tests()
    demonstrate()
