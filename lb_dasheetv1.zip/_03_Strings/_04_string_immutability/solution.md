# Why Strings are Immutable in Java?

## Problem Statement
Explain why strings are immutable in Java and other languages. Discuss the design decisions, advantages, and implications.

---

## What is Immutability?

An object is **immutable** if its state cannot be modified after it is created. For strings, this means:
- Once a String object is created, its content cannot be changed
- Any "modification" creates a new String object
- The original string remains unchanged in memory

```java
// Java Example
String s = "Hello";
s = s + " World";  // Creates NEW string, doesn't modify original

// In memory:
// Address 1000: "Hello"      <- Original (now orphaned)
// Address 2000: "Hello World" <- New string, s points here
```

---

## Why Strings are Immutable in Java

### 1. Security
Strings are used extensively in security-sensitive operations:
- Class loading (class names)
- Network connections (host names)
- File operations (file paths)
- Database connections (connection strings)

```java
// If strings were mutable:
String path = "/safe/directory/file.txt";
validatePath(path);  // Validation passes
// Malicious code modifies path
path.setValue("/etc/passwd");  // If possible!
openFile(path);  // Disaster!

// With immutability, path cannot be changed after validation
```

### 2. Thread Safety
Immutable objects are inherently thread-safe:
- Multiple threads can share the same String object
- No synchronization needed
- No race conditions possible

```java
// Safe to share across threads
String constant = "SHARED_VALUE";

Thread t1 = new Thread(() -> process(constant));
Thread t2 = new Thread(() -> process(constant));
// Both threads can safely use 'constant'
```

### 3. String Pool (String Interning)
Java maintains a pool of string literals for memory optimization:

```
String Pool:
+------------------+
|  "Hello"    1000 |  <- s1, s3 point here
|  "World"    1004 |  <- s2 points here
+------------------+

String s1 = "Hello";    // From pool
String s2 = "World";    // From pool
String s3 = "Hello";    // Reuses s1's object!

s1 == s3  // true (same object)
```

**Why this needs immutability:**
- If s1 could modify "Hello", s3 would see unexpected changes
- Pool reuse would be unsafe without immutability

### 4. Caching Hash Codes
Strings cache their hash code for performance:

```java
public final class String {
    private int hash;  // Cached hash code

    public int hashCode() {
        int h = hash;
        if (h == 0 && value.length > 0) {
            // Calculate and cache
            hash = h = calculateHash();
        }
        return h;
    }
}
```

- Hash is computed once and cached
- Safe because string content never changes
- Critical for HashMap/HashSet performance

### 5. Preventing Subclass Modification
String class is `final`:
- Cannot be subclassed
- Prevents malicious subclass from overriding methods
- Guarantees consistent behavior

---

## Memory Implications

### The Problem with String Concatenation

```java
String result = "";
for (int i = 0; i < 1000; i++) {
    result = result + i;  // Creates 1000 string objects!
}

// Memory created:
// "0"
// "01"
// "012"
// ... 1000 objects total!
```

### The Solution: StringBuilder

```java
StringBuilder sb = new StringBuilder();
for (int i = 0; i < 1000; i++) {
    sb.append(i);  // Modifies same object
}
String result = sb.toString();  // One final String

// Only 2 objects: StringBuilder + final String
```

---

## Comparison Across Languages

| Language | String Mutable? | Alternative for Mutation |
|----------|----------------|--------------------------|
| Java | No (final class) | StringBuilder, StringBuffer |
| Python | No | list, io.StringIO |
| C# | No | StringBuilder |
| JavaScript | No | Array.join(), template literals |
| C++ | Yes | std::string is mutable |
| C | Yes | char arrays are mutable |
| Go | No | []byte slice |
| Rust | No | String (owned, growable) |

---

## Demonstrating Immutability

### Python Example
```python
s = "hello"
print(id(s))  # e.g., 140234567890

s = s + " world"
print(id(s))  # e.g., 140234567950 (different!)

# Original "hello" still exists (until garbage collected)
```

### Java Example
```java
String s = "Hello";
System.out.println(System.identityHashCode(s));  // e.g., 12345

s = s.concat(" World");
System.out.println(System.identityHashCode(s));  // Different!
```

---

## Interview Questions & Answers

### Q1: Why doesn't Java have mutable strings?
**A:** For security (strings in class loading, network), thread safety (no synchronization needed), string pool optimization, and hash code caching.

### Q2: How does String Pool work?
**A:** JVM maintains a pool of unique string literals. When you create a literal, JVM checks the pool first. If found, returns existing reference; otherwise, creates new entry.

### Q3: What's the difference between String, StringBuilder, and StringBuffer?
**A:**
- **String**: Immutable, thread-safe
- **StringBuilder**: Mutable, NOT thread-safe, faster
- **StringBuffer**: Mutable, thread-safe (synchronized), slower

### Q4: When should you use StringBuilder?
**A:** When performing multiple string modifications, especially in loops. Concatenation in loops with + creates many temporary objects.

### Q5: Does string immutability waste memory?
**A:** Can if not careful (e.g., concatenation in loops). But benefits (security, caching, thread safety) outweigh costs. Use StringBuilder for heavy modifications.

---

## Best Practices

1. **Use StringBuilder** for concatenation in loops
2. **Use String Pool** via literals when possible
3. **Avoid unnecessary String objects** - be mindful of implicit string creation
4. **Use String.intern()** carefully - can cause memory issues
5. **Prefer StringBuilder over StringBuffer** unless thread safety is needed

---

## Key Takeaways

1. **Immutability** means the state cannot change after creation
2. **Security** - prevents tampering with sensitive string data
3. **Thread Safety** - multiple threads can safely share strings
4. **String Pool** - enables memory optimization through interning
5. **Hash Caching** - improves HashMap/HashSet performance
6. **StringBuilder** - use for efficient string modifications

---

## Code Example: Demonstrating All Concepts

```java
public class StringImmutabilityDemo {
    public static void main(String[] args) {
        // 1. Immutability demonstration
        String s1 = "Hello";
        String s2 = s1;
        s1 = s1 + " World";

        System.out.println(s1);  // "Hello World"
        System.out.println(s2);  // "Hello" (unchanged!)

        // 2. String Pool
        String a = "Java";
        String b = "Java";
        String c = new String("Java");

        System.out.println(a == b);  // true (same pool object)
        System.out.println(a == c);  // false (c is new object)
        System.out.println(a.equals(c));  // true (same content)

        // 3. StringBuilder for efficiency
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 100; i++) {
            sb.append(i).append(",");
        }
        String result = sb.toString();

        // 4. Intern demonstration
        String d = c.intern();
        System.out.println(a == d);  // true (d now from pool)
    }
}
```
