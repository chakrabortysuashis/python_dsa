"""
Why Strings are Immutable - Demonstration in Python
====================================================

This module demonstrates string immutability concepts in Python,
explaining why strings are designed to be immutable and showing
the implications for performance and memory.
"""

import sys
import time
from io import StringIO


# =============================================================================
# DEMONSTRATING IMMUTABILITY
# =============================================================================

def demonstrate_immutability():
    """
    Demonstrate that strings are immutable in Python.

    Every "modification" creates a new string object.
    """
    print("=" * 60)
    print("DEMONSTRATING STRING IMMUTABILITY")
    print("=" * 60)

    # Show that string operations create new objects
    s1 = "Hello"
    print(f"\n1. Original string: '{s1}'")
    print(f"   Memory address: {id(s1)}")

    s2 = s1 + " World"
    print(f"\n2. After s2 = s1 + ' World':")
    print(f"   s1 = '{s1}' at address {id(s1)} (unchanged!)")
    print(f"   s2 = '{s2}' at address {id(s2)} (new object!)")

    # String methods also return new objects
    s3 = s1.upper()
    print(f"\n3. After s3 = s1.upper():")
    print(f"   s1 = '{s1}' at address {id(s1)} (still unchanged!)")
    print(f"   s3 = '{s3}' at address {id(s3)} (new object!)")

    # Trying to modify directly raises error
    print("\n4. Attempting direct modification:")
    print("   s1[0] = 'J'  # This raises TypeError!")
    try:
        s1[0] = 'J'
    except TypeError as e:
        print(f"   Error: {e}")


def demonstrate_string_interning():
    """
    Demonstrate Python's string interning (similar to Java's String Pool).

    Python automatically interns some strings for memory optimization.
    """
    print("\n" + "=" * 60)
    print("STRING INTERNING (Python's String Pool)")
    print("=" * 60)

    # Simple strings are interned
    a = "hello"
    b = "hello"
    print(f"\n1. String literals:")
    print(f"   a = 'hello' -> id: {id(a)}")
    print(f"   b = 'hello' -> id: {id(b)}")
    print(f"   a is b: {a is b}  (Same object - interned!)")

    # Strings with special chars may not be interned
    c = "hello world"
    d = "hello world"
    print(f"\n2. Strings with spaces:")
    print(f"   c = 'hello world' -> id: {id(c)}")
    print(f"   d = 'hello world' -> id: {id(d)}")
    print(f"   c is d: {c is d}  (May or may not be same)")

    # Dynamically created strings are not interned
    e = "hello"
    f = "hel" + "lo"  # Compile-time concatenation - interned
    g = "hel"
    g = g + "lo"  # Runtime concatenation - NOT interned
    print(f"\n3. Dynamic vs static strings:")
    print(f"   e = 'hello' -> id: {id(e)}")
    print(f"   f = 'hel' + 'lo' (compile-time) -> id: {id(f)}")
    print(f"   g = runtime concat -> id: {id(g)}")
    print(f"   e is f: {e is f}")
    print(f"   e is g: {e is g}")

    # Forcing interning
    h = sys.intern(g)
    print(f"\n4. After sys.intern(g):")
    print(f"   h = sys.intern(g) -> id: {id(h)}")
    print(f"   e is h: {e is h}  (Now interned!)")


# =============================================================================
# PERFORMANCE IMPLICATIONS
# =============================================================================

def demonstrate_concatenation_performance():
    """
    Show why string concatenation in loops is inefficient.
    """
    print("\n" + "=" * 60)
    print("PERFORMANCE: CONCATENATION IN LOOPS")
    print("=" * 60)

    n = 10000

    # Bad: String concatenation (O(n^2))
    print(f"\n1. String concatenation (n={n}):")
    start = time.time()
    result = ""
    for i in range(n):
        result += str(i)
    bad_time = time.time() - start
    print(f"   Time: {bad_time:.4f} seconds")

    # Good: List join (O(n))
    print(f"\n2. List join method (n={n}):")
    start = time.time()
    parts = []
    for i in range(n):
        parts.append(str(i))
    result = ''.join(parts)
    good_time = time.time() - start
    print(f"   Time: {good_time:.4f} seconds")

    # Better: Generator expression
    print(f"\n3. Generator expression (n={n}):")
    start = time.time()
    result = ''.join(str(i) for i in range(n))
    best_time = time.time() - start
    print(f"   Time: {best_time:.4f} seconds")

    print(f"\n   Speedup (list vs concat): {bad_time/good_time:.1f}x")


def demonstrate_memory_usage():
    """
    Show memory implications of string immutability.
    """
    print("\n" + "=" * 60)
    print("MEMORY IMPLICATIONS")
    print("=" * 60)

    # Small strings
    s = "Hello"
    print(f"\n1. Small string '{s}':")
    print(f"   Size: {sys.getsizeof(s)} bytes")

    # Each "modification" creates new object
    print("\n2. Memory objects created during concatenation:")
    s = ""
    print(f"   Initial: '' -> id {id(s)}")

    s = s + "A"
    print(f"   After +A: '{s}' -> id {id(s)}")

    s = s + "B"
    print(f"   After +B: '{s}' -> id {id(s)}")

    s = s + "C"
    print(f"   After +C: '{s}' -> id {id(s)}")

    print("   (4 different string objects created!)")


# =============================================================================
# ALTERNATIVES TO STRINGS FOR MUTABILITY
# =============================================================================

def demonstrate_mutable_alternatives():
    """
    Show alternatives when you need mutable string-like behavior.
    """
    print("\n" + "=" * 60)
    print("MUTABLE ALTERNATIVES")
    print("=" * 60)

    # 1. Using list of characters
    print("\n1. List of characters:")
    s = "Hello"
    chars = list(s)
    print(f"   Original: {chars}")

    chars[0] = 'J'  # Can modify!
    print(f"   After chars[0] = 'J': {chars}")

    result = ''.join(chars)
    print(f"   Back to string: '{result}'")

    # 2. Using bytearray
    print("\n2. Bytearray (for ASCII/bytes):")
    ba = bytearray(b"Hello")
    print(f"   Original: {ba}")

    ba[0] = ord('J')
    print(f"   After ba[0] = ord('J'): {ba}")
    print(f"   As string: '{ba.decode()}'")

    # 3. Using StringIO
    print("\n3. StringIO (for building strings):")
    sio = StringIO()
    sio.write("Hello")
    sio.write(" ")
    sio.write("World")
    result = sio.getvalue()
    print(f"   Result: '{result}'")


class MutableString:
    """
    Custom mutable string class for demonstration.
    """

    def __init__(self, value=""):
        self._chars = list(value)

    def __str__(self):
        return ''.join(self._chars)

    def __repr__(self):
        return f"MutableString('{self}')"

    def __getitem__(self, index):
        return self._chars[index]

    def __setitem__(self, index, value):
        self._chars[index] = value

    def append(self, s):
        self._chars.extend(s)

    def insert(self, index, s):
        for i, c in enumerate(s):
            self._chars.insert(index + i, c)


def demonstrate_custom_mutable_string():
    """
    Demonstrate a custom mutable string implementation.
    """
    print("\n4. Custom MutableString class:")
    ms = MutableString("Hello")
    print(f"   Created: {ms}")

    ms[0] = 'J'
    print(f"   After ms[0] = 'J': {ms}")

    ms.append(" World")
    print(f"   After append(' World'): {ms}")


# =============================================================================
# WHY IMMUTABILITY IS BENEFICIAL
# =============================================================================

def demonstrate_benefits():
    """
    Demonstrate benefits of string immutability.
    """
    print("\n" + "=" * 60)
    print("BENEFITS OF IMMUTABILITY")
    print("=" * 60)

    # 1. Safe to use as dictionary keys
    print("\n1. Strings as dictionary keys:")
    d = {"hello": 1, "world": 2}
    print(f"   Dictionary: {d}")
    print("   Strings can be keys because they're hashable (immutable)")

    # 2. Safe to share references
    print("\n2. Safe reference sharing:")
    original = "Important Data"
    copy = original  # Just copies reference, not data
    print(f"   original: '{original}' at {id(original)}")
    print(f"   copy: '{copy}' at {id(copy)}")
    print(f"   Same object: {original is copy}")
    print("   Modifying one cannot affect the other!")

    # 3. Thread safety
    print("\n3. Thread safety:")
    print("   Immutable strings can be shared between threads safely")
    print("   No locks or synchronization needed")

    # 4. Caching/Memoization friendly
    print("\n4. Caching friendly:")
    print("   Hash values can be cached since content never changes")


# =============================================================================
# COMPARISON: EFFICIENT STRING BUILDING METHODS
# =============================================================================

def compare_string_building_methods():
    """
    Compare different methods for building strings.
    """
    print("\n" + "=" * 60)
    print("COMPARISON: STRING BUILDING METHODS")
    print("=" * 60)

    n = 1000
    iterations = 5

    methods = {
        "Concatenation (+)": lambda: build_with_concat(n),
        "List + join": lambda: build_with_list(n),
        "StringIO": lambda: build_with_stringio(n),
        "Generator + join": lambda: build_with_generator(n),
        "f-string in list": lambda: build_with_fstring(n),
    }

    print(f"\nBuilding string with {n} numbers, averaged over {iterations} runs:\n")

    for name, method in methods.items():
        times = []
        for _ in range(iterations):
            start = time.time()
            method()
            times.append(time.time() - start)
        avg_time = sum(times) / len(times)
        print(f"   {name:20}: {avg_time*1000:.3f} ms")


def build_with_concat(n):
    s = ""
    for i in range(n):
        s += str(i)
    return s


def build_with_list(n):
    parts = []
    for i in range(n):
        parts.append(str(i))
    return ''.join(parts)


def build_with_stringio(n):
    sio = StringIO()
    for i in range(n):
        sio.write(str(i))
    return sio.getvalue()


def build_with_generator(n):
    return ''.join(str(i) for i in range(n))


def build_with_fstring(n):
    return ''.join([f"{i}" for i in range(n)])


# =============================================================================
# MAIN DEMONSTRATION
# =============================================================================

def run_all_demos():
    """Run all demonstrations."""
    demonstrate_immutability()
    demonstrate_string_interning()
    demonstrate_concatenation_performance()
    demonstrate_memory_usage()
    demonstrate_mutable_alternatives()
    demonstrate_custom_mutable_string()
    demonstrate_benefits()
    compare_string_building_methods()

    print("\n" + "=" * 60)
    print("KEY TAKEAWAYS")
    print("=" * 60)
    print("""
    1. Strings in Python (and Java) are IMMUTABLE
    2. Every "modification" creates a NEW string object
    3. String interning optimizes memory for common strings
    4. Use list + join for efficient string building in loops
    5. Immutability enables: hashing, thread safety, caching
    6. Use bytearray or list for truly mutable sequences
    """)


if __name__ == "__main__":
    run_all_demos()
