"""
Check Whether a String is Valid Shuffle of Two Strings
=======================================================

Problem: Given strings s1, s2, and result, check if result is a valid
interleaving (shuffle) of s1 and s2.

A valid shuffle preserves the relative order of characters from both strings.

Approaches:
1. Two Pointers (Greedy) - May fail for ambiguous cases
2. Recursion with Memoization
3. Dynamic Programming
4. Space-Optimized DP
"""

from functools import lru_cache
from typing import List


# =============================================================================
# APPROACH 1: TWO POINTERS (Greedy) - Limited
# =============================================================================

def is_valid_shuffle_greedy(s1: str, s2: str, result: str) -> bool:
    """
    Check shuffle using greedy two-pointer approach.

    LIMITATION: This approach may fail when a character appears in both
    s1 and s2 at the current positions (ambiguous choice).

    Example of failure:
    s1 = "aa", s2 = "ab", result = "aaba"
    Greedy takes s1's 'a' first, but correct path might need s2's 'a'.

    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    if len(result) != len(s1) + len(s2):
        return False

    i = 0  # Pointer for s1
    j = 0  # Pointer for s2

    for char in result:
        if i < len(s1) and char == s1[i]:
            i += 1
        elif j < len(s2) and char == s2[j]:
            j += 1
        else:
            return False

    return i == len(s1) and j == len(s2)


# =============================================================================
# APPROACH 2: RECURSION WITH MEMOIZATION
# =============================================================================

def is_valid_shuffle_memo(s1: str, s2: str, result: str) -> bool:
    """
    Check shuffle using recursion with memoization.

    INTUITION:
    - At each position k in result, try matching with s1[i] or s2[j]
    - If match found, recurse with updated indices
    - Memoize to avoid recomputation

    VISUAL for s1="AB", s2="12", result="A1B2":

    (i=0, j=0, k=0): result[0]='A'
        -> Matches s1[0]='A', recurse (1, 0, 1)

    (i=1, j=0, k=1): result[1]='1'
        -> Doesn't match s1[1]='B'
        -> Matches s2[0]='1', recurse (1, 1, 2)

    (i=1, j=1, k=2): result[2]='B'
        -> Matches s1[1]='B', recurse (2, 1, 3)

    (i=2, j=1, k=3): result[3]='2'
        -> i >= len(s1), try s2
        -> Matches s2[1]='2', recurse (2, 2, 4)

    (i=2, j=2, k=4): All consumed, return True

    Time Complexity: O(m * n)
    Space Complexity: O(m * n) for memoization + recursion stack
    """
    if len(result) != len(s1) + len(s2):
        return False

    memo = {}

    def helper(i: int, j: int) -> bool:
        """Check if s1[i:] and s2[j:] can form result[i+j:]."""

        if (i, j) in memo:
            return memo[(i, j)]

        k = i + j  # Current position in result

        # Base case: reached end of result
        if k == len(result):
            result_valid = i == len(s1) and j == len(s2)
            memo[(i, j)] = result_valid
            return result_valid

        valid = False

        # Try taking from s1
        if i < len(s1) and result[k] == s1[i]:
            valid = helper(i + 1, j)

        # Try taking from s2 (if s1 path didn't work)
        if not valid and j < len(s2) and result[k] == s2[j]:
            valid = helper(i, j + 1)

        memo[(i, j)] = valid
        return valid

    return helper(0, 0)


def is_valid_shuffle_lru_cache(s1: str, s2: str, result: str) -> bool:
    """
    Same approach using Python's lru_cache decorator.
    """
    if len(result) != len(s1) + len(s2):
        return False

    @lru_cache(maxsize=None)
    def helper(i: int, j: int) -> bool:
        k = i + j

        if k == len(result):
            return i == len(s1) and j == len(s2)

        valid = False

        if i < len(s1) and result[k] == s1[i]:
            valid = helper(i + 1, j)

        if not valid and j < len(s2) and result[k] == s2[j]:
            valid = helper(i, j + 1)

        return valid

    return helper(0, 0)


# =============================================================================
# APPROACH 3: DYNAMIC PROGRAMMING
# =============================================================================

def is_valid_shuffle_dp(s1: str, s2: str, result: str) -> bool:
    """
    Check shuffle using 2D dynamic programming.

    INTUITION:
    dp[i][j] = True if result[0:i+j] is a valid shuffle of s1[0:i] and s2[0:j]

    RECURRENCE:
    dp[i][j] = (dp[i-1][j] and s1[i-1] == result[i+j-1]) OR
               (dp[i][j-1] and s2[j-1] == result[i+j-1])

    Translation: result[i+j-1] must match either:
    - The last char of s1[0:i] if dp[i-1][j] was valid, OR
    - The last char of s2[0:j] if dp[i][j-1] was valid

    DP TABLE for s1="AB", s2="12", result="A1B2":

              ""      "1"     "12"
        ""    T       F       F
        "A"   T       T       F
        "AB"  T       T       T

    Final answer: dp[2][2] = T

    Time Complexity: O(m * n)
    Space Complexity: O(m * n)
    """
    m, n = len(s1), len(s2)

    if len(result) != m + n:
        return False

    # dp[i][j] = can s1[0:i] and s2[0:j] form result[0:i+j]?
    dp = [[False] * (n + 1) for _ in range(m + 1)]

    # Base case: empty strings form empty result
    dp[0][0] = True

    # Fill first column (using only s1)
    for i in range(1, m + 1):
        dp[i][0] = dp[i - 1][0] and s1[i - 1] == result[i - 1]

    # Fill first row (using only s2)
    for j in range(1, n + 1):
        dp[0][j] = dp[0][j - 1] and s2[j - 1] == result[j - 1]

    # Fill rest of the table
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            k = i + j - 1  # Current index in result

            # Can we form result[0:k+1] by:
            # 1. Taking s1[i-1] if result[k] matches and dp[i-1][j] was valid
            from_s1 = dp[i - 1][j] and s1[i - 1] == result[k]

            # 2. Taking s2[j-1] if result[k] matches and dp[i][j-1] was valid
            from_s2 = dp[i][j - 1] and s2[j - 1] == result[k]

            dp[i][j] = from_s1 or from_s2

    return dp[m][n]


def is_valid_shuffle_dp_verbose(s1: str, s2: str, result: str) -> bool:
    """
    DP approach with verbose output for learning.
    """
    m, n = len(s1), len(s2)

    if len(result) != m + n:
        print(f"Length mismatch: {len(result)} != {m} + {n}")
        return False

    dp = [[False] * (n + 1) for _ in range(m + 1)]
    dp[0][0] = True

    # Fill first column
    for i in range(1, m + 1):
        dp[i][0] = dp[i - 1][0] and s1[i - 1] == result[i - 1]

    # Fill first row
    for j in range(1, n + 1):
        dp[0][j] = dp[0][j - 1] and s2[j - 1] == result[j - 1]

    # Fill rest
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            k = i + j - 1
            dp[i][j] = ((dp[i - 1][j] and s1[i - 1] == result[k]) or
                        (dp[i][j - 1] and s2[j - 1] == result[k]))

    # Print DP table
    print(f"\nDP Table for s1='{s1}', s2='{s2}', result='{result}':")
    print("     ", end="")
    print("  ''  ", end="")
    for j in range(1, n + 1):
        print(f" {s2[:j]:^4}", end="")
    print()

    for i in range(m + 1):
        prefix = "''" if i == 0 else s1[:i]
        print(f" {prefix:>3} ", end="")
        for j in range(n + 1):
            val = "T" if dp[i][j] else "F"
            print(f"  {val}   ", end="")
        print()

    print(f"\nResult: {dp[m][n]}")
    return dp[m][n]


# =============================================================================
# APPROACH 4: SPACE-OPTIMIZED DP
# =============================================================================

def is_valid_shuffle_optimized(s1: str, s2: str, result: str) -> bool:
    """
    Space-optimized DP using only O(n) space.

    INTUITION:
    Since each row only depends on the previous row and current row's
    previous column, we can use a 1D array.

    Time Complexity: O(m * n)
    Space Complexity: O(n)
    """
    m, n = len(s1), len(s2)

    if len(result) != m + n:
        return False

    # dp[j] = can s1[0:current_i] and s2[0:j] form result[0:current_i+j]?
    dp = [False] * (n + 1)
    dp[0] = True

    # Fill first row (using only s2)
    for j in range(1, n + 1):
        dp[j] = dp[j - 1] and s2[j - 1] == result[j - 1]

    # Process each character of s1
    for i in range(1, m + 1):
        # Update first column
        dp[0] = dp[0] and s1[i - 1] == result[i - 1]

        for j in range(1, n + 1):
            k = i + j - 1  # Index in result

            # dp[j] currently holds dp[i-1][j] (from previous i)
            from_s1 = dp[j] and s1[i - 1] == result[k]

            # dp[j-1] holds dp[i][j-1] (already updated this row)
            from_s2 = dp[j - 1] and s2[j - 1] == result[k]

            dp[j] = from_s1 or from_s2

    return dp[n]


# =============================================================================
# UTILITY: Generate All Valid Shuffles
# =============================================================================

def generate_all_shuffles(s1: str, s2: str) -> List[str]:
    """
    Generate all possible valid shuffles of two strings.

    Uses backtracking to enumerate all interleavings.

    Time Complexity: O(C(m+n, m)) - number of ways to choose positions
    Space Complexity: O(m + n) for recursion stack
    """
    results = []

    def backtrack(i: int, j: int, current: List[str]):
        # Base case: both strings exhausted
        if i == len(s1) and j == len(s2):
            results.append(''.join(current))
            return

        # Take from s1
        if i < len(s1):
            current.append(s1[i])
            backtrack(i + 1, j, current)
            current.pop()

        # Take from s2
        if j < len(s2):
            current.append(s2[j])
            backtrack(i, j + 1, current)
            current.pop()

    backtrack(0, 0, [])
    return results


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Run comprehensive test cases."""

    test_cases = [
        ("xy", "12", "x1y2", True),
        ("xy", "12", "xy12", True),
        ("xy", "12", "1xy2", True),
        ("xy", "12", "y1x2", False),  # Order violation
        ("", "", "", True),
        ("a", "", "a", True),
        ("", "b", "b", True),
        ("ab", "cd", "abcd", True),
        ("ab", "cd", "acbd", True),
        ("ab", "cd", "cadb", True),
        ("ab", "cd", "adbc", False),  # d before c
        ("abc", "def", "adbecf", True),
        ("abc", "def", "abdecf", True),
        ("aa", "ab", "aaba", True),  # Greedy might fail here
        ("aab", "aac", "aaaacb", False),
    ]

    print("=" * 70)
    print("VALID SHUFFLE - TEST RESULTS")
    print("=" * 70)

    approaches = [
        ("Greedy (Limited)", is_valid_shuffle_greedy),
        ("Memoization", is_valid_shuffle_memo),
        ("DP", is_valid_shuffle_dp),
        ("Optimized DP", is_valid_shuffle_optimized),
    ]

    for name, func in approaches:
        print(f"\n--- {name} ---")
        passed = 0
        for s1, s2, result, expected in test_cases:
            actual = func(s1, s2, result)
            if actual == expected:
                passed += 1
            else:
                print(f"  FAIL: s1='{s1}', s2='{s2}', result='{result}'")
                print(f"        Expected {expected}, got {actual}")

        print(f"  Passed: {passed}/{len(test_cases)}")


def demonstrate():
    """Demonstrate the algorithm step by step."""

    print("\n" + "=" * 70)
    print("STEP-BY-STEP DEMONSTRATION")
    print("=" * 70)

    # Demonstrate DP
    is_valid_shuffle_dp_verbose("AB", "12", "A1B2")
    is_valid_shuffle_dp_verbose("AB", "12", "1A2B")
    is_valid_shuffle_dp_verbose("AB", "12", "B1A2")

    # Generate all shuffles
    print("\n--- All Valid Shuffles of 'AB' and '12' ---")
    all_shuffles = generate_all_shuffles("AB", "12")
    for i, shuffle in enumerate(all_shuffles, 1):
        print(f"  {i}. {shuffle}")


if __name__ == "__main__":
    run_tests()
    demonstrate()
