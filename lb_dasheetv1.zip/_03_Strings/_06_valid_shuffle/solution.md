# Check Whether a String is Valid Shuffle of Two Strings

## Problem Statement
Given three strings `s1`, `s2`, and `result`, check if `result` is a valid shuffle (interleaving) of `s1` and `s2`.

A valid shuffle contains all characters of both strings with their relative order preserved.

**Example 1:**
```
Input: s1 = "xy", s2 = "12", result = "x1y2"
Output: true
Explanation: Characters maintain relative order from both strings
```

**Example 2:**
```
Input: s1 = "xy", s2 = "12", result = "y1x2"
Output: false
Explanation: 'y' comes before 'x', violating s1's order
```

---

## Intuition and Thought Process

A valid shuffle must:
1. Contain ALL characters from both s1 and s2
2. Preserve the relative order of characters in s1
3. Preserve the relative order of characters in s2

```
s1 = "AB"    s2 = "12"

Valid shuffles:
- AB12: A before B (ok), 1 before 2 (ok)
- A1B2: A before B (ok), 1 before 2 (ok)
- A12B: A before B (ok), 1 before 2 (ok)
- 1AB2: A before B (ok), 1 before 2 (ok)
- 1A2B: A before B (ok), 1 before 2 (ok)
- 12AB: A before B (ok), 1 before 2 (ok)

Invalid:
- BA12: B before A (violates s1's order)
- A21B: 2 before 1 (violates s2's order)
```

---

## Approach 1: Two Pointers (Greedy)

### Idea
Use two pointers to track positions in s1 and s2. For each character in result, check if it matches the current character from s1 or s2.

### Algorithm
1. Check if lengths match: len(result) == len(s1) + len(s2)
2. Initialize pointers i=0 (for s1), j=0 (for s2)
3. For each character in result:
   - If it matches s1[i], increment i
   - Else if it matches s2[j], increment j
   - Else return false
4. Return true if both pointers reached end

### Limitation
This greedy approach fails when a character appears in both strings at current positions.

```
s1 = "aa", s2 = "ab", result = "aaba"

Greedy would choose s1's 'a' first, then fail.
But valid shuffle exists: a(s1) a(s2) b(s2) a(s1)
```

### Code
```python
def is_valid_shuffle_greedy(s1: str, s2: str, result: str) -> bool:
    if len(result) != len(s1) + len(s2):
        return False

    i = j = 0

    for char in result:
        if i < len(s1) and char == s1[i]:
            i += 1
        elif j < len(s2) and char == s2[j]:
            j += 1
        else:
            return False

    return i == len(s1) and j == len(s2)
```

---

## Approach 2: Recursion with Memoization (Correct)

### Idea
At each position in result, try taking from s1 or s2. Use memoization to avoid recomputation.

### Algorithm
1. Define recursive function with indices (i, j) for s1 and s2
2. Position in result = i + j
3. Try matching with s1[i] or s2[j]
4. Memoize results

### Code
```python
def is_valid_shuffle_memo(s1: str, s2: str, result: str) -> bool:
    if len(result) != len(s1) + len(s2):
        return False

    memo = {}

    def helper(i, j):
        if (i, j) in memo:
            return memo[(i, j)]

        k = i + j

        if k == len(result):
            return i == len(s1) and j == len(s2)

        valid = False

        if i < len(s1) and result[k] == s1[i]:
            valid = helper(i + 1, j)

        if not valid and j < len(s2) and result[k] == s2[j]:
            valid = helper(i, j + 1)

        memo[(i, j)] = valid
        return valid

    return helper(0, 0)
```

### Complexity
- **Time**: O(m * n) where m = len(s1), n = len(s2)
- **Space**: O(m * n) for memoization

---

## Approach 3: Dynamic Programming

### Idea
Build a 2D DP table where dp[i][j] indicates if result[0:i+j] is a valid shuffle of s1[0:i] and s2[0:j].

### Recurrence
```
dp[i][j] = True if:
    (dp[i-1][j] and s1[i-1] == result[i+j-1]) OR
    (dp[i][j-1] and s2[j-1] == result[i+j-1])
```

### Visual Dry Run
```
s1 = "AB", s2 = "12", result = "A1B2"

DP Table (True=T, False=F):
        ""   1    12
    ""   T   F    F
    A    T   T    F
    AB   T   T    T

dp[0][0] = True (empty matches empty)
dp[1][0] = True (A matches result[0]='A')
dp[2][0] = True (B doesn't match result[1]='1', but check s1)
...
```

### Code
```python
def is_valid_shuffle_dp(s1: str, s2: str, result: str) -> bool:
    m, n = len(s1), len(s2)

    if len(result) != m + n:
        return False

    dp = [[False] * (n + 1) for _ in range(m + 1)]
    dp[0][0] = True

    # Fill first column
    for i in range(1, m + 1):
        dp[i][0] = dp[i-1][0] and s1[i-1] == result[i-1]

    # Fill first row
    for j in range(1, n + 1):
        dp[0][j] = dp[0][j-1] and s2[j-1] == result[j-1]

    # Fill rest
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            k = i + j - 1  # Index in result
            dp[i][j] = (
                (dp[i-1][j] and s1[i-1] == result[k]) or
                (dp[i][j-1] and s2[j-1] == result[k])
            )

    return dp[m][n]
```

### Complexity
- **Time**: O(m * n)
- **Space**: O(m * n)

---

## Approach 4: Space-Optimized DP

### Idea
Since we only need the previous row, optimize to O(n) space.

### Code
```python
def is_valid_shuffle_optimized(s1: str, s2: str, result: str) -> bool:
    m, n = len(s1), len(s2)

    if len(result) != m + n:
        return False

    dp = [False] * (n + 1)
    dp[0] = True

    # Fill first row
    for j in range(1, n + 1):
        dp[j] = dp[j-1] and s2[j-1] == result[j-1]

    for i in range(1, m + 1):
        dp[0] = dp[0] and s1[i-1] == result[i-1]

        for j in range(1, n + 1):
            k = i + j - 1
            dp[j] = (
                (dp[j] and s1[i-1] == result[k]) or
                (dp[j-1] and s2[j-1] == result[k])
            )

    return dp[n]
```

### Complexity
- **Time**: O(m * n)
- **Space**: O(n)

---

## Edge Cases

| s1 | s2 | result | Output | Reason |
|----|----|--------|--------|--------|
| "" | "" | "" | true | Empty shuffle |
| "a" | "" | "a" | true | Single string |
| "" | "b" | "b" | true | Single string |
| "ab" | "cd" | "abcd" | true | Non-interleaved |
| "ab" | "cd" | "acbd" | true | Interleaved |
| "ab" | "cd" | "acdb" | true | Valid order |
| "ab" | "cd" | "adbc" | false | 'd' before 'c' |

---

## Key Takeaways

1. **Greedy fails** when same character appears in both strings
2. **DP** is the reliable approach for interleaving problems
3. **Order preservation** is the key constraint
4. Length check is a quick early termination
5. Similar to LCS but checking interleaving property

---

## Related Problems
- Interleaving String (LeetCode 97)
- Edit Distance
- Longest Common Subsequence
- Distinct Subsequences
