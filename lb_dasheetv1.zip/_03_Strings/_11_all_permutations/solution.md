# Print All Permutations of a String

## Problem Statement
Given a string `s`, print all possible permutations.

A permutation is a rearrangement of all characters where order matters.

**Example:**
```
Input: s = "ABC"
Output: ["ABC", "ACB", "BAC", "BCA", "CAB", "CBA"]
Explanation: Total 3! = 6 permutations
```

---

## Intuition and Thought Process

For permutations:
- First position can have any of n characters
- Second position can have any of (n-1) remaining characters
- And so on...

Total permutations = n! = n * (n-1) * (n-2) * ... * 1

### Backtracking Approach
At each position, try placing each unused character, then recurse.

```
For "ABC":
Position 0: Try A, B, C
Position 1: Try remaining 2 characters
Position 2: Place the last remaining character
```

---

## Recursion Tree

```
                           permute("ABC", 0)
                         /        |        \
                    swap(0,0)  swap(0,1)  swap(0,2)
                       |          |          |
                     "ABC"      "BAC"      "CBA"
                    /    \      /    \      /    \
               swap    swap  swap   swap  swap   swap
               (1,1)  (1,2)  (1,1) (1,2) (1,1) (1,2)
                 |      |      |      |      |      |
               "ABC"  "ACB"  "BAC"  "BCA"  "CBA"  "CAB"
                 |      |      |      |      |      |
               LEAF   LEAF   LEAF   LEAF   LEAF   LEAF

Results: ABC, ACB, BAC, BCA, CBA, CAB
```

---

## Approach 1: Backtracking with Swap

### Algorithm
1. Start from index 0
2. For each position, swap current char with all chars from current to end
3. Recurse for next position
4. Backtrack by swapping back

### Pseudocode
```
function permute(s, index, result):
    if index == length(s):
        result.add(s)
        return

    for i from index to length(s) - 1:
        swap(s, index, i)        // Make choice
        permute(s, index + 1)    // Recurse
        swap(s, index, i)        // Undo choice (backtrack)
```

### Visual Dry Run
```
permute("ABC", 0):
  i=0: swap(0,0) -> "ABC"
       permute("ABC", 1):
         i=1: swap(1,1) -> "ABC"
              permute("ABC", 2):
                Add "ABC" to result
              swap(1,1) -> "ABC"
         i=2: swap(1,2) -> "ACB"
              permute("ACB", 2):
                Add "ACB" to result
              swap(1,2) -> "ABC"
       swap(0,0) -> "ABC"

  i=1: swap(0,1) -> "BAC"
       permute("BAC", 1):
         ... (generates "BAC", "BCA")
       swap(0,1) -> "ABC"

  i=2: swap(0,2) -> "CBA"
       permute("CBA", 1):
         ... (generates "CBA", "CAB")
       swap(0,2) -> "ABC"
```

### Complexity
- **Time**: O(n! * n) - n! permutations, each takes O(n) to copy
- **Space**: O(n) - Recursion stack

---

## Approach 2: Using Fixed Array + Visited

### Algorithm
1. Use boolean array to track used characters
2. Build permutation character by character
3. Backtrack by unmarking used characters

### Code Sketch
```python
def permute(s):
    result = []
    used = [False] * len(s)
    current = []

    def backtrack():
        if len(current) == len(s):
            result.append(''.join(current))
            return

        for i in range(len(s)):
            if used[i]:
                continue
            used[i] = True
            current.append(s[i])
            backtrack()
            current.pop()
            used[i] = False

    backtrack()
    return result
```

---

## Handling Duplicates

For strings with duplicate characters, avoid duplicate permutations:

```python
def permute_unique(s):
    result = []
    s = sorted(s)  # Sort to group duplicates

    def backtrack(chars, current):
        if not chars:
            result.append(''.join(current))
            return

        for i in range(len(chars)):
            # Skip duplicate characters
            if i > 0 and chars[i] == chars[i-1]:
                continue
            backtrack(chars[:i] + chars[i+1:], current + [chars[i]])

    backtrack(list(s), [])
    return result
```

---

## Comparison: Permutation vs Subsequence vs Combination

| Type | n=3 Count | Key Property |
|------|-----------|--------------|
| Permutation | n! = 6 | Order matters, use all |
| Subsequence | 2^n = 8 | Order preserved, subset |
| Combination | C(n,k) | Order doesn't matter |

---

## Edge Cases

| Input | Output | Count |
|-------|--------|-------|
| "" | [""] | 1 |
| "a" | ["a"] | 1 |
| "ab" | ["ab", "ba"] | 2 |
| "aab" | ["aab", "aba", "baa"] | 3 (with dedup) |

---

## Key Takeaways

1. **Backtracking** is essential for permutation problems
2. **Swap technique** is elegant and efficient
3. **n! complexity** - permutations grow rapidly
4. Handle **duplicates** by sorting and skipping
5. Recursion tree helps visualize the decision process

---

## Related Problems
- Permutations (LeetCode 46)
- Permutations II (with duplicates)
- Next Permutation
- Permutation Sequence
