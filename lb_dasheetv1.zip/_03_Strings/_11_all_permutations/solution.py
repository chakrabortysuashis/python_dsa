"""
Print All Permutations of a String
===================================

A permutation is a rearrangement of all characters where order matters.
Total permutations: n!

Approaches:
1. Backtracking with Swap
2. Using Visited Array
3. Handling Duplicates
"""

from typing import List
from itertools import permutations as itertools_permutations


# =============================================================================
# APPROACH 1: BACKTRACKING WITH SWAP
# =============================================================================

def permutations_swap(s: str) -> List[str]:
    """
    Generate all permutations using swap-based backtracking.

    RECURSION TREE for "ABC":

                        permute(0)
                      /     |     \
                 swap(0,0) swap(0,1) swap(0,2)
                    |         |         |
                  "ABC"     "BAC"     "CBA"
                  /   \     /   \     /   \
             swap   swap  swap  swap  swap  swap
             (1,1) (1,2) (1,1) (1,2) (1,1) (1,2)
               |     |     |     |     |     |
             ABC   ACB   BAC   BCA   CBA   CAB

    Time Complexity: O(n! * n)
    Space Complexity: O(n) recursion stack
    """
    result = []
    chars = list(s)
    n = len(chars)

    def backtrack(index: int):
        # Base case: all positions filled
        if index == n:
            result.append(''.join(chars))
            return

        # Try each character at current position
        for i in range(index, n):
            # Swap to place chars[i] at position index
            chars[index], chars[i] = chars[i], chars[index]

            # Recurse for next position
            backtrack(index + 1)

            # Backtrack: restore original order
            chars[index], chars[i] = chars[i], chars[index]

    backtrack(0)
    return result


def permutations_swap_verbose(s: str) -> List[str]:
    """
    Verbose version showing the recursion tree.
    """
    result = []
    chars = list(s)
    n = len(chars)
    indent = [0]

    def backtrack(index: int):
        prefix = "  " * indent[0]

        if index == n:
            perm = ''.join(chars)
            print(f"{prefix}LEAF: Found permutation '{perm}'")
            result.append(perm)
            return

        print(f"{prefix}At index {index}, chars = {''.join(chars)}")

        for i in range(index, n):
            print(f"{prefix}  Swap({index}, {i}): {chars[index]} <-> {chars[i]}")
            chars[index], chars[i] = chars[i], chars[index]

            indent[0] += 1
            backtrack(index + 1)
            indent[0] -= 1

            print(f"{prefix}  Backtrack: Swap({index}, {i})")
            chars[index], chars[i] = chars[i], chars[index]

    print(f"\nGenerating permutations of '{s}':")
    print("=" * 50)
    backtrack(0)
    return result


# =============================================================================
# APPROACH 2: USING VISITED ARRAY
# =============================================================================

def permutations_visited(s: str) -> List[str]:
    """
    Generate permutations using a visited array.

    Build permutation by selecting unused characters one by one.

    Time Complexity: O(n! * n)
    Space Complexity: O(n)
    """
    result = []
    n = len(s)
    used = [False] * n
    current = []

    def backtrack():
        if len(current) == n:
            result.append(''.join(current))
            return

        for i in range(n):
            if used[i]:
                continue

            # Choose
            used[i] = True
            current.append(s[i])

            # Explore
            backtrack()

            # Unchoose (backtrack)
            current.pop()
            used[i] = False

    backtrack()
    return result


# =============================================================================
# APPROACH 3: HANDLING DUPLICATES
# =============================================================================

def permutations_unique(s: str) -> List[str]:
    """
    Generate unique permutations (handles duplicate characters).

    EXAMPLE: "aab" -> ["aab", "aba", "baa"] (not 6 permutations)

    Key: Sort first, then skip duplicates at same level.

    Time Complexity: O(n! * n)
    Space Complexity: O(n)
    """
    result = []
    chars = sorted(s)  # Sort to group duplicates
    n = len(chars)
    used = [False] * n
    current = []

    def backtrack():
        if len(current) == n:
            result.append(''.join(current))
            return

        for i in range(n):
            # Skip if already used
            if used[i]:
                continue

            # Skip duplicates: if same as previous AND previous not used
            # This means we already explored this branch
            if i > 0 and chars[i] == chars[i - 1] and not used[i - 1]:
                continue

            used[i] = True
            current.append(chars[i])

            backtrack()

            current.pop()
            used[i] = False

    backtrack()
    return result


# =============================================================================
# APPROACH 4: ITERATIVE (USING INSERTION)
# =============================================================================

def permutations_iterative(s: str) -> List[str]:
    """
    Generate permutations iteratively by inserting each char at all positions.

    EXAMPLE for "abc":
    Start: [""]
    Add 'a': ["a"]
    Add 'b': ["ba", "ab"]
    Add 'c': ["cba", "bca", "bac", "cab", "acb", "abc"]

    Time Complexity: O(n! * n)
    Space Complexity: O(n!)
    """
    if not s:
        return [""]

    result = [s[0]]

    for i in range(1, len(s)):
        char = s[i]
        new_result = []

        for perm in result:
            # Insert char at every position
            for j in range(len(perm) + 1):
                new_perm = perm[:j] + char + perm[j:]
                new_result.append(new_perm)

        result = new_result

    return result


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def count_permutations(n: int) -> int:
    """Calculate n! (factorial)."""
    if n <= 1:
        return 1
    return n * count_permutations(n - 1)


def print_recursion_tree(s: str):
    """
    Print ASCII recursion tree.
    """
    print(f"\nRecursion Tree for permutations of '{s}':")
    print("=" * 60)

    def print_tree(chars: List[str], index: int, prefix: str, is_last: bool):
        connector = "--- " if is_last else "|-- "

        if index == len(chars):
            print(f"{prefix}{connector}LEAF: \"{''.join(chars)}\"")
            return

        print(f"{prefix}{connector}index={index}, chars=\"{''.join(chars)}\"")

        new_prefix = prefix + ("    " if is_last else "|   ")

        for i in range(index, len(chars)):
            is_last_child = (i == len(chars) - 1)

            # Swap
            chars[index], chars[i] = chars[i], chars[index]
            swap_info = f"swap({index},{i})"

            print(f"{new_prefix}|")
            print(f"{new_prefix}{swap_info}")

            print_tree(chars.copy(), index + 1, new_prefix, is_last_child)

            # Swap back
            chars[index], chars[i] = chars[i], chars[index]

    print_tree(list(s), 0, "", True)


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Run comprehensive test cases."""

    test_cases = [
        ("", [""]),
        ("a", ["a"]),
        ("ab", ["ab", "ba"]),
        ("abc", ["abc", "acb", "bac", "bca", "cab", "cba"]),
    ]

    print("=" * 60)
    print("ALL PERMUTATIONS - TEST RESULTS")
    print("=" * 60)

    approaches = [
        ("Swap", permutations_swap),
        ("Visited", permutations_visited),
        ("Iterative", permutations_iterative),
    ]

    for name, func in approaches:
        print(f"\n--- {name} ---")
        all_passed = True

        for s, expected in test_cases:
            result = sorted(func(s))
            expected_sorted = sorted(expected)
            if result != expected_sorted:
                all_passed = False
                print(f"  FAIL: '{s}' -> {result}")

        if all_passed:
            print(f"  All {len(test_cases)} test cases PASSED!")

    # Test with duplicates
    print("\n--- Handling Duplicates ---")
    s = "aab"
    result = permutations_unique(s)
    expected = ["aab", "aba", "baa"]
    print(f"  '{s}' -> {sorted(result)}")
    print(f"  Expected: {sorted(expected)}")
    print(f"  {'PASS' if sorted(result) == sorted(expected) else 'FAIL'}")

    # Verify counts
    print("\n--- Count Verification ---")
    for s, _ in test_cases:
        count = len(permutations_swap(s))
        expected_count = count_permutations(len(s)) if s else 1
        status = "PASS" if count == expected_count else "FAIL"
        print(f"  {status}: '{s}' has {count} perms (expected {len(s)}! = {expected_count})")


def demonstrate():
    """Demonstrate algorithms."""

    print("\n" + "=" * 60)
    print("STEP-BY-STEP DEMONSTRATION")
    print("=" * 60)

    # Verbose swap demonstration
    permutations_swap_verbose("AB")

    # Show iterative building
    print("\n--- Iterative Building ---")
    s = "abc"
    print(f"Building permutations of '{s}':")
    result = [s[0]]
    print(f"  Start with '{s[0]}': {result}")

    for i in range(1, len(s)):
        char = s[i]
        new_result = []
        for perm in result:
            for j in range(len(perm) + 1):
                new_perm = perm[:j] + char + perm[j:]
                new_result.append(new_perm)
        result = new_result
        print(f"  Add '{char}': {result}")


if __name__ == "__main__":
    run_tests()
    demonstrate()
