"""
Edit Distance (Levenshtein Distance)
=====================================

Problem: Given two strings word1 and word2, return the minimum number of
operations required to convert word1 to word2.

Operations: Insert, Delete, Replace

Approaches:
1. Recursive - O(3^(m+n)) - exponential
2. Memoization - O(m*n) time, O(m*n) space
3. DP Bottom-Up - O(m*n) time, O(m*n) space
4. Space-Optimized DP - O(m*n) time, O(n) space
"""

from typing import List, Tuple
from functools import lru_cache


# =============================================================================
# APPROACH 1: RECURSIVE (Exponential - For Understanding)
# =============================================================================

def edit_distance_recursive(word1: str, word2: str) -> int:
    """
    Pure recursive solution - exponential time complexity.

    Good for understanding, NOT for production.

    Time Complexity: O(3^(m+n))
    Space Complexity: O(m+n) for recursion stack
    """

    def solve(i: int, j: int) -> int:
        """
        Returns min operations to convert word1[0:i] to word2[0:j]

        i = number of characters considered from word1
        j = number of characters considered from word2
        """
        # Base cases
        if i == 0:
            return j  # Insert all j characters
        if j == 0:
            return i  # Delete all i characters

        # If last characters match
        if word1[i - 1] == word2[j - 1]:
            return solve(i - 1, j - 1)  # No operation needed

        # Characters don't match - try all three operations
        insert_op = solve(i, j - 1)      # Insert word2[j-1]
        delete_op = solve(i - 1, j)      # Delete word1[i-1]
        replace_op = solve(i - 1, j - 1) # Replace word1[i-1] with word2[j-1]

        return 1 + min(insert_op, delete_op, replace_op)

    return solve(len(word1), len(word2))


# =============================================================================
# APPROACH 2: RECURSION WITH MEMOIZATION
# =============================================================================

def edit_distance_memo(word1: str, word2: str) -> int:
    """
    Top-down DP with memoization using @lru_cache.

    Time Complexity: O(m * n)
    Space Complexity: O(m * n) for memo + recursion stack
    """
    m, n = len(word1), len(word2)

    @lru_cache(maxsize=None)
    def solve(i: int, j: int) -> int:
        """
        Returns min operations to convert word1[0:i] to word2[0:j]
        """
        # Base cases
        if i == 0:
            return j
        if j == 0:
            return i

        # If characters match
        if word1[i - 1] == word2[j - 1]:
            return solve(i - 1, j - 1)

        # Try all operations
        return 1 + min(
            solve(i, j - 1),      # Insert
            solve(i - 1, j),      # Delete
            solve(i - 1, j - 1)   # Replace
        )

    return solve(m, n)


# =============================================================================
# APPROACH 3: DYNAMIC PROGRAMMING (Bottom-Up)
# =============================================================================

def edit_distance_dp(word1: str, word2: str) -> int:
    """
    Bottom-up DP solution.

    STATE:
    dp[i][j] = minimum operations to convert word1[0:i] to word2[0:j]

    RECURRENCE:
    If word1[i-1] == word2[j-1]:
        dp[i][j] = dp[i-1][j-1]  (no operation needed)
    Else:
        dp[i][j] = 1 + min(
            dp[i][j-1],    # Insert
            dp[i-1][j],    # Delete
            dp[i-1][j-1]   # Replace
        )

    BASE CASES:
    dp[i][0] = i  (delete all i characters)
    dp[0][j] = j  (insert all j characters)

    EXAMPLE: word1="horse", word2="ros"

    DP Table:
            ""  r   o   s
        ""   0   1   2   3
        h    1   1   2   3
        o    2   2   1   2
        r    3   2   2   2
        s    4   3   3   2
        e    5   4   4   3

    Answer: dp[5][3] = 3

    Time Complexity: O(m * n)
    Space Complexity: O(m * n)
    """
    m, n = len(word1), len(word2)

    # Create DP table with extra row and column for empty string
    dp = [[0] * (n + 1) for _ in range(m + 1)]

    # Base case: converting to/from empty string
    for i in range(m + 1):
        dp[i][0] = i  # Delete all characters from word1
    for j in range(n + 1):
        dp[0][j] = j  # Insert all characters into empty word1

    # Fill the DP table
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if word1[i - 1] == word2[j - 1]:
                # Characters match - no operation needed
                dp[i][j] = dp[i - 1][j - 1]
            else:
                # Characters differ - take minimum of three operations
                dp[i][j] = 1 + min(
                    dp[i][j - 1],      # Insert: convert word1[0:i] to word2[0:j-1], then insert
                    dp[i - 1][j],      # Delete: convert word1[0:i-1] to word2[0:j], then delete
                    dp[i - 1][j - 1]   # Replace: convert word1[0:i-1] to word2[0:j-1], then replace
                )

    return dp[m][n]


# =============================================================================
# APPROACH 4: SPACE-OPTIMIZED DP
# =============================================================================

def edit_distance_optimized(word1: str, word2: str) -> int:
    """
    Space-optimized DP - only keep two rows.

    OBSERVATION:
    Each cell dp[i][j] only depends on:
    - dp[i-1][j]   (cell above)
    - dp[i][j-1]   (cell to the left)
    - dp[i-1][j-1] (diagonal cell)

    So we only need the previous row and current row.

    Time Complexity: O(m * n)
    Space Complexity: O(min(m, n)) - use shorter string for columns
    """
    m, n = len(word1), len(word2)

    # Ensure word2 is the shorter one (for space optimization)
    if m < n:
        word1, word2 = word2, word1
        m, n = n, m

    # Previous and current row
    prev = list(range(n + 1))  # [0, 1, 2, ..., n]
    curr = [0] * (n + 1)

    for i in range(1, m + 1):
        curr[0] = i  # Base case: delete all characters from word1[0:i]

        for j in range(1, n + 1):
            if word1[i - 1] == word2[j - 1]:
                curr[j] = prev[j - 1]
            else:
                curr[j] = 1 + min(
                    prev[j],      # Delete
                    curr[j - 1],  # Insert
                    prev[j - 1]   # Replace
                )

        # Swap rows
        prev, curr = curr, prev

    return prev[n]


# =============================================================================
# APPROACH 5: DP WITH PATH RECONSTRUCTION
# =============================================================================

def edit_distance_with_operations(word1: str, word2: str) -> Tuple[int, List[str]]:
    """
    DP solution that also returns the sequence of operations.

    Returns: (edit_distance, list_of_operations)

    Operations format: "REPLACE i 'a' -> 'b'" etc.
    """
    m, n = len(word1), len(word2)

    # DP table
    dp = [[0] * (n + 1) for _ in range(m + 1)]

    # Initialize base cases
    for i in range(m + 1):
        dp[i][0] = i
    for j in range(n + 1):
        dp[0][j] = j

    # Fill DP table
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if word1[i - 1] == word2[j - 1]:
                dp[i][j] = dp[i - 1][j - 1]
            else:
                dp[i][j] = 1 + min(dp[i][j - 1], dp[i - 1][j], dp[i - 1][j - 1])

    # Backtrack to find operations
    operations = []
    i, j = m, n

    while i > 0 or j > 0:
        if i > 0 and j > 0 and word1[i - 1] == word2[j - 1]:
            # Characters match - no operation
            i -= 1
            j -= 1
        elif i > 0 and j > 0 and dp[i][j] == dp[i - 1][j - 1] + 1:
            # Replace operation
            operations.append(f"REPLACE pos {i-1}: '{word1[i-1]}' -> '{word2[j-1]}'")
            i -= 1
            j -= 1
        elif j > 0 and dp[i][j] == dp[i][j - 1] + 1:
            # Insert operation
            operations.append(f"INSERT pos {i}: '{word2[j-1]}'")
            j -= 1
        elif i > 0 and dp[i][j] == dp[i - 1][j] + 1:
            # Delete operation
            operations.append(f"DELETE pos {i-1}: '{word1[i-1]}'")
            i -= 1
        else:
            # Handle edge cases
            if j > 0:
                operations.append(f"INSERT pos {i}: '{word2[j-1]}'")
                j -= 1
            elif i > 0:
                operations.append(f"DELETE pos {i-1}: '{word1[i-1]}'")
                i -= 1

    operations.reverse()
    return dp[m][n], operations


# =============================================================================
# VERBOSE VERSION FOR LEARNING
# =============================================================================

def edit_distance_verbose(word1: str, word2: str) -> int:
    """
    Verbose version that prints the DP table and explains each step.
    """
    m, n = len(word1), len(word2)

    print(f"\nEdit Distance: '{word1}' -> '{word2}'")
    print("=" * 50)

    dp = [[0] * (n + 1) for _ in range(m + 1)]

    # Base cases
    for i in range(m + 1):
        dp[i][0] = i
    for j in range(n + 1):
        dp[0][j] = j

    # Fill table
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if word1[i - 1] == word2[j - 1]:
                dp[i][j] = dp[i - 1][j - 1]
            else:
                dp[i][j] = 1 + min(dp[i][j - 1], dp[i - 1][j], dp[i - 1][j - 1])

    # Print table
    print("\nDP Table:")
    header = "     |  '' |"
    for j, c in enumerate(word2):
        header += f"  {c}  |"
    print(header)
    print("-" * len(header))

    for i in range(m + 1):
        row_char = word1[i - 1] if i > 0 else "''"
        row = f"  {row_char:2} |"
        for j in range(n + 1):
            row += f"  {dp[i][j]:2} |"
        print(row)

    print("-" * len(header))
    print(f"\nMinimum edit distance: {dp[m][n]}")

    # Get operations
    dist, ops = edit_distance_with_operations(word1, word2)
    print("\nOperations:")
    for op in ops:
        print(f"  {op}")

    return dp[m][n]


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def print_dp_table(word1: str, word2: str, dp: List[List[int]]):
    """Pretty print the DP table."""
    m, n = len(word1), len(word2)

    # Header
    print("    ", end="")
    print(f"{'':>4}", end="")
    for c in word2:
        print(f"{c:>4}", end="")
    print()

    for i in range(m + 1):
        if i == 0:
            print(f"{'':>4}", end="")
        else:
            print(f"{word1[i-1]:>4}", end="")

        for j in range(n + 1):
            print(f"{dp[i][j]:>4}", end="")
        print()


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Run comprehensive test cases."""

    test_cases = [
        # (word1, word2, expected)
        ("horse", "ros", 3),
        ("intention", "execution", 5),
        ("", "", 0),
        ("a", "", 1),
        ("", "a", 1),
        ("abc", "abc", 0),
        ("abc", "def", 3),
        ("kitten", "sitting", 3),
        ("saturday", "sunday", 3),
        ("abc", "yabd", 2),
        ("abc", "ab", 1),
        ("ab", "abc", 1),
    ]

    print("=" * 60)
    print("EDIT DISTANCE - TEST RESULTS")
    print("=" * 60)

    approaches = [
        ("Memoization", edit_distance_memo),
        ("DP", edit_distance_dp),
        ("Optimized", edit_distance_optimized),
    ]

    for name, func in approaches:
        print(f"\n--- {name} ---")
        all_passed = True

        for word1, word2, expected in test_cases:
            result = func(word1, word2)
            if result != expected:
                all_passed = False
                print(f"  FAIL: '{word1}' -> '{word2}': got {result}, expected {expected}")

        if all_passed:
            print(f"  All {len(test_cases)} test cases PASSED!")


def demonstrate():
    """Demonstrate the algorithm step by step."""

    print("\n" + "=" * 60)
    print("STEP-BY-STEP DEMONSTRATION")
    print("=" * 60)

    # Verbose demonstration
    edit_distance_verbose("horse", "ros")

    # Show operations for another example
    print("\n" + "-" * 40)
    print("ANOTHER EXAMPLE WITH OPERATIONS")
    print("-" * 40)

    dist, ops = edit_distance_with_operations("kitten", "sitting")
    print(f"'kitten' -> 'sitting': {dist} operations")
    for op in ops:
        print(f"  {op}")

    # Compare approaches
    print("\n" + "-" * 40)
    print("PERFORMANCE COMPARISON")
    print("-" * 40)

    import time

    word1 = "abcdefghij"
    word2 = "jihgfedcba"

    for name, func in [("Memo", edit_distance_memo), ("DP", edit_distance_dp), ("Optimized", edit_distance_optimized)]:
        start = time.perf_counter()
        result = func(word1, word2)
        elapsed = (time.perf_counter() - start) * 1000
        print(f"{name:12}: result={result}, time={elapsed:.3f}ms")


if __name__ == "__main__":
    run_tests()
    demonstrate()
