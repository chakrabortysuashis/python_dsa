# Edit Distance (Levenshtein Distance)

## Problem Statement
Given two strings `word1` and `word2`, return the **minimum number of operations** required to convert `word1` to `word2`.

You have the following three operations permitted on a word:
1. **Insert** a character
2. **Delete** a character
3. **Replace** a character

**Example 1:**
```
Input: word1 = "horse", word2 = "ros"
Output: 3
Explanation:
horse -> rorse (replace 'h' with 'r')
rorse -> rose (delete 'r')
rose -> ros (delete 'e')
```

**Example 2:**
```
Input: word1 = "intention", word2 = "execution"
Output: 5
Explanation:
intention -> inention (remove 't')
inention -> enention (replace 'i' with 'e')
enention -> exention (replace 'n' with 'x')
exention -> exection (replace 'n' with 'c')
exection -> execution (insert 'u')
```

---

## Intuition and Thought Process

### Key Insight
At each position, we make a choice:
- If characters match: **no operation needed**, move to next
- If characters differ: try all three operations, take minimum

### Recursive Structure
To convert `word1[0..i]` to `word2[0..j]`:

```
If word1[i] == word2[j]:
    Same as converting word1[0..i-1] to word2[0..j-1]
    (no extra cost)

Else:
    Take minimum of:
    1. Insert: convert word1[0..i] to word2[0..j-1], then insert word2[j]
    2. Delete: convert word1[0..i-1] to word2[0..j], then delete word1[i]
    3. Replace: convert word1[0..i-1] to word2[0..j-1], then replace word1[i] with word2[j]
```

### Visual Understanding
```
word1 = "horse"
word2 = "ros"

Think of it as aligning strings:

h o r s e
    r o s

Options at each mismatch:
- Insert: add a character to word1
- Delete: skip a character in word1
- Replace: change character in word1
```

---

## Approach 1: Recursive (Exponential)

### Algorithm
```
function minDistance(i, j):
    // Base cases
    if i == 0: return j  // Insert all remaining
    if j == 0: return i  // Delete all remaining

    // If characters match
    if word1[i-1] == word2[j-1]:
        return minDistance(i-1, j-1)

    // Try all operations
    return 1 + min(
        minDistance(i, j-1),    // Insert
        minDistance(i-1, j),    // Delete
        minDistance(i-1, j-1)   // Replace
    )
```

### Complexity
- **Time**: O(3^(m+n)) - branching factor 3, depth m+n
- **Space**: O(m+n) - recursion stack

*Too slow! Many overlapping subproblems.*

---

## Approach 2: Recursion with Memoization

### Idea
Cache results to avoid recomputation.

### Complexity
- **Time**: O(m * n) - each subproblem computed once
- **Space**: O(m * n) - memo table + recursion stack

---

## Approach 3: Dynamic Programming (Bottom-Up)

### State Definition
`dp[i][j]` = minimum operations to convert `word1[0..i-1]` to `word2[0..j-1]`

### Base Cases
- `dp[0][j] = j` (insert j characters)
- `dp[i][0] = i` (delete i characters)

### Recurrence
```
if word1[i-1] == word2[j-1]:
    dp[i][j] = dp[i-1][j-1]
else:
    dp[i][j] = 1 + min(
        dp[i][j-1],    // Insert
        dp[i-1][j],    // Delete
        dp[i-1][j-1]   // Replace
    )
```

### Visual Dry Run
```
word1 = "horse" (m=5)
word2 = "ros" (r=3)

DP Table:
        ""  r   o   s
    ""   0   1   2   3
    h    1   1   2   3
    o    2   2   1   2
    r    3   2   2   2
    s    4   3   3   2
    e    5   4   4   3

Let's trace a few cells:

dp[1][1]: 'h' vs 'r'
    - Different, so: 1 + min(dp[0][1], dp[1][0], dp[0][0])
    - = 1 + min(1, 1, 0) = 1 (replace 'h' with 'r')

dp[2][2]: 'o' vs 'o'
    - Same! dp[2][2] = dp[1][1] = 1

dp[3][1]: 'r' vs 'r'
    - Same! dp[3][1] = dp[2][0] = 2

dp[5][3]: Final answer = 3
```

### Backtracking to Find Operations
Starting from dp[m][n], trace back:
1. If dp[i][j] came from dp[i-1][j-1] with same chars: no op, move diagonal
2. If dp[i][j] = dp[i-1][j-1] + 1: REPLACE
3. If dp[i][j] = dp[i-1][j] + 1: DELETE
4. If dp[i][j] = dp[i][j-1] + 1: INSERT

### Pseudocode
```
function minDistance(word1, word2):
    m, n = len(word1), len(word2)

    // Create DP table
    dp = 2D array of (m+1) x (n+1)

    // Base cases
    for i from 0 to m: dp[i][0] = i
    for j from 0 to n: dp[0][j] = j

    // Fill table
    for i from 1 to m:
        for j from 1 to n:
            if word1[i-1] == word2[j-1]:
                dp[i][j] = dp[i-1][j-1]
            else:
                dp[i][j] = 1 + min(
                    dp[i-1][j],      // Delete
                    dp[i][j-1],      // Insert
                    dp[i-1][j-1]     // Replace
                )

    return dp[m][n]
```

### Complexity
- **Time**: O(m * n)
- **Space**: O(m * n)

---

## Approach 4: Space-Optimized DP

### Observation
Each row only depends on the previous row.

### Algorithm
Use two 1D arrays of size n+1, alternating between them.

```
function minDistance(word1, word2):
    m, n = len(word1), len(word2)

    // Two rows
    prev = [0, 1, 2, ..., n]
    curr = array of n+1

    for i from 1 to m:
        curr[0] = i  // Base case for this row

        for j from 1 to n:
            if word1[i-1] == word2[j-1]:
                curr[j] = prev[j-1]
            else:
                curr[j] = 1 + min(prev[j], curr[j-1], prev[j-1])

        prev, curr = curr, prev  // Swap

    return prev[n]
```

### Complexity
- **Time**: O(m * n)
- **Space**: O(n) - only two rows

---

## Operation Visualization

### Insert Operation
```
word1 = "ab"     dp[i][j-1] + 1
word2 = "abc"

"ab" -> "abc"
       ^
   Insert 'c'
```

### Delete Operation
```
word1 = "abc"    dp[i-1][j] + 1
word2 = "ab"

"abc" -> "ab"
  ^
  Delete 'c'
```

### Replace Operation
```
word1 = "abc"    dp[i-1][j-1] + 1
word2 = "adc"

"abc" -> "adc"
  ^       ^
  Replace 'b' with 'd'
```

---

## Comparison Table

| Approach | Time | Space | Notes |
|----------|------|-------|-------|
| Recursive | O(3^(m+n)) | O(m+n) | Exponential, impractical |
| Memo | O(m*n) | O(m*n) | Top-down, good for sparse |
| DP | O(m*n) | O(m*n) | Bottom-up, clean |
| DP Optimized | O(m*n) | O(min(m,n)) | Best space |

---

## Edge Cases

| Input | Output | Notes |
|-------|--------|-------|
| "", "" | 0 | Both empty |
| "a", "" | 1 | Delete all |
| "", "a" | 1 | Insert all |
| "abc", "abc" | 0 | Identical |
| "abc", "def" | 3 | All replace |
| "a", "ab" | 1 | One insert |

---

## Key Takeaways

1. **Three operations** map to three directions in DP table
2. **Match = diagonal** with no cost increment
3. **Space optimization** possible since only prev row needed
4. **Backtracking** through DP table reveals actual operations
5. Classic **string comparison** interview problem
6. Used in **spell checkers**, **DNA sequence alignment**, **diff tools**

---

## Variants

### 1. Different Operation Costs
Each operation has different cost:
```
insertCost, deleteCost, replaceCost
```

### 2. Only Insert and Delete (LCS-based)
No replacement allowed:
```
editDistance = m + n - 2 * LCS(word1, word2)
```

### 3. Damerau-Levenshtein Distance
Adds **transposition** (swap adjacent characters).

### 4. Hamming Distance
Only counts positions where characters differ (same length strings, no insert/delete).

---

## Related Problems
- Longest Common Subsequence
- One Edit Distance
- Delete Operation for Two Strings
- Minimum ASCII Delete Sum
- Distinct Subsequences
