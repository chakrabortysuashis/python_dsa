# Find Duplicate Characters in a String

## Problem Statement
Given a string `s`, find all characters that appear more than once and print them with their count.

**Example 1:**
```
Input: s = "programming"
Output: {'r': 2, 'g': 2, 'm': 2}
```

**Example 2:**
```
Input: s = "hello world"
Output: {'l': 3, 'o': 2}
```

---

## Intuition and Thought Process

To find duplicates, we need to count how many times each character appears. This is a classic use case for:
1. **Hash Map** (Dictionary) - Store character frequencies
2. **Frequency Array** - For limited character set (a-z or ASCII)

```
String: "programming"

Character Counting:
p: 1
r: 2 <-- duplicate
o: 1
g: 2 <-- duplicate
a: 1
m: 2 <-- duplicate
i: 1
n: 1
```

---

## Approach 1: Brute Force (Nested Loops)

### Idea
For each character, count its occurrences by traversing the entire string.

### Algorithm
1. For each character at index i
2. Count occurrences by checking all characters
3. If count > 1 and not already reported, add to result

### Code
```python
def find_duplicates_brute(s: str) -> dict:
    duplicates = {}
    seen = set()

    for i, char in enumerate(s):
        if char in seen:
            continue
        count = s.count(char)
        if count > 1:
            duplicates[char] = count
        seen.add(char)

    return duplicates
```

### Complexity
- **Time**: O(n^2) - count() is O(n) called n times
- **Space**: O(k) - k unique characters

---

## Approach 2: Hash Map (Optimal)

### Idea
Use a dictionary to count character frequencies in single pass.

### Algorithm
1. Initialize empty dictionary
2. Iterate through string once
3. For each character, increment its count
4. Filter characters with count > 1

### Visual Dry Run

```
Input: "programming"

Step-by-step frequency building:
Index 0: 'p' -> freq = {'p': 1}
Index 1: 'r' -> freq = {'p': 1, 'r': 1}
Index 2: 'o' -> freq = {'p': 1, 'r': 1, 'o': 1}
Index 3: 'g' -> freq = {'p': 1, 'r': 1, 'o': 1, 'g': 1}
Index 4: 'r' -> freq = {'p': 1, 'r': 2, 'o': 1, 'g': 1}  <-- r becomes duplicate
Index 5: 'a' -> freq = {..., 'a': 1}
Index 6: 'm' -> freq = {..., 'm': 1}
Index 7: 'm' -> freq = {..., 'm': 2}  <-- m becomes duplicate
Index 8: 'i' -> freq = {..., 'i': 1}
Index 9: 'n' -> freq = {..., 'n': 1}
Index 10: 'g' -> freq = {..., 'g': 2}  <-- g becomes duplicate

Filter count > 1: {'r': 2, 'g': 2, 'm': 2}
```

### Pseudocode
```
function findDuplicates(s):
    freq = empty dictionary

    for each char in s:
        if char in freq:
            freq[char] = freq[char] + 1
        else:
            freq[char] = 1

    duplicates = {}
    for char, count in freq:
        if count > 1:
            duplicates[char] = count

    return duplicates
```

### Complexity
- **Time**: O(n) - Single pass through string
- **Space**: O(k) - k unique characters

---

## Approach 3: Using Counter (Pythonic)

### Idea
Python's `collections.Counter` provides built-in frequency counting.

### Code
```python
from collections import Counter

def find_duplicates_counter(s: str) -> dict:
    freq = Counter(s)
    return {char: count for char, count in freq.items() if count > 1}
```

### Complexity
- **Time**: O(n)
- **Space**: O(k)

---

## Approach 4: Frequency Array (For Limited Charset)

### Idea
Use an array of fixed size for counting when character set is limited.

### Code
```python
def find_duplicates_array(s: str) -> dict:
    # For ASCII characters (256 possible)
    freq = [0] * 256

    for char in s:
        freq[ord(char)] += 1

    duplicates = {}
    for i, count in enumerate(freq):
        if count > 1:
            duplicates[chr(i)] = count

    return duplicates
```

### Complexity
- **Time**: O(n)
- **Space**: O(1) - Fixed 256 array (constant)

---

## Approach 5: Using Sorting

### Idea
Sort the string so duplicates become adjacent, then count consecutive characters.

### Code
```python
def find_duplicates_sorting(s: str) -> dict:
    if not s:
        return {}

    sorted_s = sorted(s)
    duplicates = {}
    count = 1

    for i in range(1, len(sorted_s)):
        if sorted_s[i] == sorted_s[i-1]:
            count += 1
        else:
            if count > 1:
                duplicates[sorted_s[i-1]] = count
            count = 1

    # Don't forget last character group
    if count > 1:
        duplicates[sorted_s[-1]] = count

    return duplicates
```

### Complexity
- **Time**: O(n log n) - Due to sorting
- **Space**: O(n) - Sorted string storage

---

## Comparison Table

| Approach | Time | Space | Notes |
|----------|------|-------|-------|
| Brute Force | O(n^2) | O(k) | Not recommended |
| Hash Map | O(n) | O(k) | Optimal - recommended |
| Counter | O(n) | O(k) | Most Pythonic |
| Frequency Array | O(n) | O(1) | Best for ASCII |
| Sorting | O(n log n) | O(n) | Not optimal |

---

## Variations

### 1. Find First Non-Repeating Character
```python
def first_non_repeating(s: str) -> str:
    freq = Counter(s)
    for char in s:
        if freq[char] == 1:
            return char
    return None
```

### 2. Remove All Duplicates
```python
def remove_duplicates(s: str) -> str:
    seen = set()
    result = []
    for char in s:
        if char not in seen:
            seen.add(char)
            result.append(char)
    return ''.join(result)
```

### 3. Find All Unique Characters
```python
def find_unique(s: str) -> list:
    freq = Counter(s)
    return [char for char, count in freq.items() if count == 1]
```

---

## Key Takeaways

1. **Hash Map** is the go-to data structure for counting problems
2. **Counter** from collections simplifies frequency counting in Python
3. **Frequency Array** is optimal when character set is limited and known
4. Always consider if case-sensitivity matters
5. Consider whether to count spaces/special characters

---

## Related Problems
- First Unique Character in String
- Valid Anagram
- Group Anagrams
- Longest Substring Without Repeating Characters
