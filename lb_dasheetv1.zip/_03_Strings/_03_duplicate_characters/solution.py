"""
Find Duplicate Characters in a String
======================================

Problem: Given a string s, find all characters that appear more than once.

Approaches:
1. Brute Force (Nested Loops)
2. Hash Map (Optimal)
3. Using Counter (Pythonic)
4. Frequency Array (For Limited Charset)
5. Using Sorting
"""

from collections import Counter, defaultdict
from typing import Dict, List, Optional


# =============================================================================
# APPROACH 1: BRUTE FORCE (Nested Loops)
# =============================================================================

def find_duplicates_brute(s: str) -> Dict[str, int]:
    """
    Find duplicates using brute force - count each character.

    INTUITION:
    - For each character, count how many times it appears
    - If count > 1, it's a duplicate

    Time Complexity: O(n^2) - count() is O(n), called for each unique char
    Space Complexity: O(k) where k = unique characters
    """
    duplicates = {}
    seen = set()  # To avoid counting same char multiple times

    for char in s:
        if char in seen:
            continue
        count = s.count(char)  # O(n) operation
        if count > 1:
            duplicates[char] = count
        seen.add(char)

    return duplicates


# =============================================================================
# APPROACH 2: HASH MAP (Optimal)
# =============================================================================

def find_duplicates_hashmap(s: str) -> Dict[str, int]:
    """
    Find duplicates using hash map for frequency counting.

    INTUITION:
    - Count frequency of each character in single pass
    - Filter characters with count > 1

    VISUAL DRY RUN for "programming":

    Building frequency map:
    'p' -> 1
    'r' -> 1 -> 2 (duplicate!)
    'o' -> 1
    'g' -> 1 -> 2 (duplicate!)
    'a' -> 1
    'm' -> 1 -> 2 (duplicate!)
    'i' -> 1
    'n' -> 1

    Result: {'r': 2, 'g': 2, 'm': 2}

    Time Complexity: O(n) - Single pass through string
    Space Complexity: O(k) where k = unique characters
    """
    # Count frequencies
    freq = {}
    for char in s:
        freq[char] = freq.get(char, 0) + 1

    # Filter duplicates (count > 1)
    duplicates = {char: count for char, count in freq.items() if count > 1}

    return duplicates


def find_duplicates_defaultdict(s: str) -> Dict[str, int]:
    """
    Same approach using defaultdict for cleaner code.
    """
    freq = defaultdict(int)
    for char in s:
        freq[char] += 1

    return {char: count for char, count in freq.items() if count > 1}


# =============================================================================
# APPROACH 3: USING COUNTER (Pythonic)
# =============================================================================

def find_duplicates_counter(s: str) -> Dict[str, int]:
    """
    Find duplicates using Python's Counter.

    INTUITION:
    - Counter automatically builds frequency map
    - Just filter for count > 1

    Time Complexity: O(n)
    Space Complexity: O(k)

    This is the most Pythonic approach!
    """
    freq = Counter(s)
    return {char: count for char, count in freq.items() if count > 1}


# =============================================================================
# APPROACH 4: FREQUENCY ARRAY (For Limited Charset)
# =============================================================================

def find_duplicates_array(s: str) -> Dict[str, int]:
    """
    Find duplicates using frequency array for ASCII characters.

    INTUITION:
    - Use array of size 256 (ASCII)
    - Index = character's ASCII value
    - Value = frequency count

    Time Complexity: O(n)
    Space Complexity: O(1) - Fixed size 256 array

    Best for ASCII strings when space is truly constant!
    """
    # Frequency array for all ASCII characters
    freq = [0] * 256

    # Count frequencies
    for char in s:
        freq[ord(char)] += 1

    # Build result dictionary
    duplicates = {}
    for i, count in enumerate(freq):
        if count > 1:
            duplicates[chr(i)] = count

    return duplicates


def find_duplicates_lowercase_only(s: str) -> Dict[str, int]:
    """
    Optimized for lowercase letters only (a-z).

    Space: O(26) = O(1)
    """
    freq = [0] * 26

    for char in s.lower():
        if 'a' <= char <= 'z':
            freq[ord(char) - ord('a')] += 1

    duplicates = {}
    for i, count in enumerate(freq):
        if count > 1:
            duplicates[chr(i + ord('a'))] = count

    return duplicates


# =============================================================================
# APPROACH 5: USING SORTING
# =============================================================================

def find_duplicates_sorting(s: str) -> Dict[str, int]:
    """
    Find duplicates by sorting (duplicates become adjacent).

    INTUITION:
    - Sort the string so identical chars are consecutive
    - Count consecutive identical characters
    - If count > 1, it's a duplicate

    EXAMPLE for "programming":
    Sorted: "aggimmnoprr"

    Count consecutive:
    a:1, g:2(dup!), i:1, m:2(dup!), n:1, o:1, p:1, r:2(dup!)

    Time Complexity: O(n log n) due to sorting
    Space Complexity: O(n) for sorted string
    """
    if not s:
        return {}

    sorted_s = sorted(s)
    duplicates = {}
    count = 1

    for i in range(1, len(sorted_s)):
        if sorted_s[i] == sorted_s[i - 1]:
            count += 1
        else:
            if count > 1:
                duplicates[sorted_s[i - 1]] = count
            count = 1

    # Handle last character group
    if count > 1:
        duplicates[sorted_s[-1]] = count

    return duplicates


# =============================================================================
# VARIATIONS AND RELATED PROBLEMS
# =============================================================================

def find_first_duplicate(s: str) -> Optional[str]:
    """
    Find the first character that appears more than once.

    Time Complexity: O(n)
    Space Complexity: O(k)
    """
    seen = set()
    for char in s:
        if char in seen:
            return char
        seen.add(char)
    return None


def find_first_non_repeating(s: str) -> Optional[str]:
    """
    Find the first character that appears exactly once.

    Time Complexity: O(n)
    Space Complexity: O(k)
    """
    freq = Counter(s)

    # Find first character with count 1
    for char in s:
        if freq[char] == 1:
            return char

    return None


def find_all_unique(s: str) -> List[str]:
    """
    Find all characters that appear exactly once.
    """
    freq = Counter(s)
    return [char for char, count in freq.items() if count == 1]


def remove_duplicates_keep_first(s: str) -> str:
    """
    Remove duplicate characters, keeping first occurrence only.

    Example: "programming" -> "progamin"
    """
    seen = set()
    result = []

    for char in s:
        if char not in seen:
            seen.add(char)
            result.append(char)

    return ''.join(result)


def remove_all_duplicates(s: str) -> str:
    """
    Remove all characters that appear more than once.

    Example: "programming" -> "poanin"
    """
    freq = Counter(s)
    return ''.join(char for char in s if freq[char] == 1)


def count_duplicate_characters(s: str) -> int:
    """
    Count how many characters have duplicates.

    Example: "programming" -> 3 (r, g, m have duplicates)
    """
    freq = Counter(s)
    return sum(1 for count in freq.values() if count > 1)


def find_most_frequent(s: str) -> tuple:
    """
    Find the most frequent character and its count.

    Returns: (character, count)
    """
    if not s:
        return (None, 0)

    freq = Counter(s)
    return freq.most_common(1)[0]


# =============================================================================
# CASE-INSENSITIVE VARIANTS
# =============================================================================

def find_duplicates_case_insensitive(s: str) -> Dict[str, int]:
    """
    Find duplicates treating uppercase and lowercase as same.

    Example: "AaBbCc" -> {'a': 2, 'b': 2, 'c': 2}
    """
    freq = Counter(s.lower())
    return {char: count for char, count in freq.items() if count > 1}


def find_duplicates_ignore_spaces(s: str) -> Dict[str, int]:
    """
    Find duplicates ignoring whitespace characters.
    """
    cleaned = ''.join(s.split())
    return find_duplicates_counter(cleaned)


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Run comprehensive test cases."""

    test_cases = [
        ("programming", {'r': 2, 'g': 2, 'm': 2}),
        ("hello world", {'l': 3, 'o': 2}),
        ("abcdef", {}),  # No duplicates
        ("aabbcc", {'a': 2, 'b': 2, 'c': 2}),
        ("", {}),  # Empty string
        ("a", {}),  # Single character
        ("aa", {'a': 2}),  # All same
        ("aAaA", {'a': 2, 'A': 2}),  # Case sensitive
    ]

    print("=" * 60)
    print("FIND DUPLICATE CHARACTERS - TEST RESULTS")
    print("=" * 60)

    approaches = [
        ("Brute Force", find_duplicates_brute),
        ("Hash Map", find_duplicates_hashmap),
        ("Counter", find_duplicates_counter),
        ("Array", find_duplicates_array),
        ("Sorting", find_duplicates_sorting),
    ]

    for name, func in approaches:
        print(f"\n--- {name} ---")
        all_passed = True
        for s, expected in test_cases:
            result = func(s)
            passed = result == expected
            if not passed:
                all_passed = False
                print(f"  FAIL: '{s}' -> {result} (expected {expected})")
        if all_passed:
            print(f"  All {len(test_cases)} test cases PASSED!")

    # Test variations
    print("\n--- Variations ---")
    s = "programming"
    print(f"Input: '{s}'")
    print(f"  First duplicate: {find_first_duplicate(s)}")
    print(f"  First non-repeating: {find_first_non_repeating(s)}")
    print(f"  All unique chars: {find_all_unique(s)}")
    print(f"  Remove duplicates (keep first): '{remove_duplicates_keep_first(s)}'")
    print(f"  Most frequent: {find_most_frequent(s)}")
    print(f"  Count of duplicates: {count_duplicate_characters(s)}")


def demonstrate_verbose():
    """Demonstrate the counting process step by step."""
    s = "mississippi"

    print("\n" + "=" * 60)
    print("STEP-BY-STEP DEMONSTRATION")
    print("=" * 60)
    print(f"\nInput: '{s}'")
    print("\nBuilding frequency map:")

    freq = {}
    for i, char in enumerate(s):
        old_count = freq.get(char, 0)
        freq[char] = old_count + 1
        print(f"  Index {i:2d}: '{char}' -> count: {old_count} -> {freq[char]}")

    print(f"\nFinal frequency map: {freq}")
    print(f"Duplicates (count > 1): {find_duplicates_counter(s)}")


if __name__ == "__main__":
    run_tests()
    demonstrate_verbose()
