# Strings - Fundamental Concepts

## Table of Contents
1. [Introduction](#introduction)
2. [String Representation in Memory](#string-representation-in-memory)
3. [String Immutability](#string-immutability)
4. [Common String Operations](#common-string-operations)
5. [Pattern Matching Introduction](#pattern-matching-introduction)
6. [Time Complexity Analysis](#time-complexity-analysis)
7. [Key Techniques for String Problems](#key-techniques-for-string-problems)

---

## Introduction

A **string** is a sequence of characters. In most programming languages, strings are one of the most fundamental data types used to represent text data.

### Key Properties:
- **Ordered**: Characters maintain their position
- **Indexed**: Each character can be accessed by its index (0-based in most languages)
- **Iterable**: Can be traversed character by character

```
String: "HELLO"
Index:   0 1 2 3 4
Chars:   H E L L O
```

---

## String Representation in Memory

### 1. Array of Characters
Strings are internally stored as arrays of characters in contiguous memory locations.

```
Memory Address:  1000  1001  1002  1003  1004  1005
Character:         H     E     L     L     O    \0
```

### 2. ASCII/Unicode Encoding
- **ASCII**: Each character = 1 byte (0-127 for standard ASCII)
- **Unicode (UTF-8)**: Variable length encoding (1-4 bytes per character)
- **Unicode (UTF-16)**: 2 or 4 bytes per character

```python
# ASCII values
ord('A')  # 65
ord('a')  # 97
ord('0')  # 48

# Character from ASCII
chr(65)   # 'A'
chr(97)   # 'a'
```

### 3. String Termination
- **C-style strings**: Null-terminated (`\0`)
- **Python/Java**: Length-prefixed (stores length separately)

---

## String Immutability

### What is Immutability?
A string is **immutable** if its contents cannot be changed after creation. Any "modification" creates a new string object.

### Why Strings are Immutable (in Java/Python):

1. **Security**: Strings used in network connections, file paths, etc. cannot be tampered with
2. **Thread Safety**: Multiple threads can share string references safely
3. **Caching/Hashing**: String hash codes can be cached since content never changes
4. **String Pool**: Enables string interning for memory optimization

### Immutability in Different Languages:

| Language | Mutable? | Alternative for Mutation |
|----------|----------|-------------------------|
| Python   | No       | `list` of chars, `io.StringIO` |
| Java     | No       | `StringBuilder`, `StringBuffer` |
| C++      | Yes      | `std::string` is mutable |
| C        | Yes      | Character arrays are mutable |
| JavaScript | No     | Arrays, template literals |

### Example: Immutability Impact

```python
# Python - Each operation creates NEW string
s = "hello"
s = s + " world"  # New string created, old "hello" eligible for GC

# Memory Impact:
# Operation          | Strings in Memory
# s = "hello"        | "hello"
# s = s + " world"   | "hello", "hello world"
```

### Efficient String Building

```python
# INEFFICIENT - O(n^2) due to immutability
result = ""
for char in "hello":
    result += char  # Creates new string each time

# EFFICIENT - O(n) using list
chars = []
for char in "hello":
    chars.append(char)
result = "".join(chars)
```

---

## Common String Operations

### 1. Basic Operations

| Operation | Python | Time Complexity |
|-----------|--------|-----------------|
| Length | `len(s)` | O(1) |
| Access char | `s[i]` | O(1) |
| Slice | `s[i:j]` | O(j-i) |
| Concatenate | `s1 + s2` | O(n+m) |
| Search | `s.find(sub)` | O(n*m) |
| Replace | `s.replace(old, new)` | O(n) |

### 2. Character-Level Operations

```python
# Check character type
char.isalpha()    # Is letter?
char.isdigit()    # Is digit?
char.isalnum()    # Is alphanumeric?
char.isspace()    # Is whitespace?
char.isupper()    # Is uppercase?
char.islower()    # Is lowercase?

# Convert case
char.upper()      # To uppercase
char.lower()      # To lowercase
```

### 3. String Comparison

```python
# Lexicographic comparison
"apple" < "banana"   # True (a < b)
"apple" < "apricot"  # True (p < r at index 2)
"abc" == "abc"       # True

# Comparison is character by character using ASCII values
```

### 4. Common Methods

```python
# Searching
s.find(sub)         # Returns index or -1
s.index(sub)        # Returns index or raises ValueError
s.count(sub)        # Count occurrences
s.startswith(pre)   # Check prefix
s.endswith(suf)     # Check suffix

# Splitting and Joining
s.split(delimiter)  # Split into list
delimiter.join(lst) # Join list into string

# Trimming
s.strip()           # Remove leading/trailing whitespace
s.lstrip()          # Remove leading whitespace
s.rstrip()          # Remove trailing whitespace

# Formatting
f"Value: {x}"       # f-string
"Value: {}".format(x)  # format method
```

---

## Pattern Matching Introduction

### 1. Naive Pattern Matching
Check for pattern at every position in text.

```
Text:    "ABABDABACDABABCABAB"
Pattern: "ABABC"

Check at each position:
Position 0: ABABD != ABABC (mismatch at 4)
Position 1: BABDA != ABABC (mismatch at 0)
...
Position 10: ABABC == ABABC (MATCH!)
```

**Time Complexity**: O(n * m) where n = text length, m = pattern length

### 2. KMP (Knuth-Morris-Pratt) Algorithm
Uses a failure function to skip unnecessary comparisons.

**Key Idea**: When a mismatch occurs, use information about previously matched characters to avoid re-checking them.

**Time Complexity**: O(n + m)

### 3. Rabin-Karp Algorithm
Uses hashing to find pattern matches.

**Key Idea**: 
- Compute hash of pattern
- Compute rolling hash of text windows
- Compare hashes; if match, verify characters

**Time Complexity**: O(n + m) average, O(n * m) worst case

### 4. Z-Algorithm
Computes Z-array where Z[i] = length of longest substring starting at i that matches prefix.

**Time Complexity**: O(n + m)

---

## Time Complexity Analysis

### String Operations Complexity

| Operation | Time Complexity | Space Complexity |
|-----------|-----------------|------------------|
| Access by index | O(1) | O(1) |
| Search substring | O(n*m) naive | O(1) |
| Search substring (KMP) | O(n+m) | O(m) |
| Concatenation | O(n+m) | O(n+m) |
| Slice s[i:j] | O(j-i) | O(j-i) |
| Compare two strings | O(min(n,m)) | O(1) |
| Reverse | O(n) | O(n) immutable, O(1) mutable |
| Find all occurrences | O(n*m) | O(k) for k matches |

### Common Pitfalls

```python
# PITFALL 1: String concatenation in loop - O(n^2)
s = ""
for i in range(n):
    s += str(i)  # Each += creates new string

# BETTER: Use join - O(n)
s = "".join(str(i) for i in range(n))

# PITFALL 2: Checking substring at every position - O(n*m)
# Use KMP or built-in optimized methods

# PITFALL 3: Creating many temporary strings
# Use StringBuilder equivalent or list of chars
```

---

## Key Techniques for String Problems

### 1. Two Pointer Technique
Used for: Palindrome check, reverse, two-sum in sorted array

```
String: "RACECAR"
Left:    ^
Right:         ^

Move pointers inward while comparing
```

### 2. Sliding Window
Used for: Substring problems, anagrams, longest substring with conditions

```
String: "ADOBECODEBANC"
Window: [----]
        ^    ^
        L    R

Expand/contract window based on conditions
```

### 3. Hashing/Frequency Count
Used for: Anagrams, character counting, duplicate detection

```python
from collections import Counter
freq = Counter("hello")  # {'h':1, 'e':1, 'l':2, 'o':1}
```

### 4. Dynamic Programming
Used for: Edit distance, longest common subsequence, palindromic substrings

```
For strings s1, s2:
dp[i][j] = solution for s1[0:i] and s2[0:j]
```

### 5. Recursion with Backtracking
Used for: Permutations, subsequences, pattern matching with wildcards

```
Generate all possibilities by:
1. Make a choice
2. Recurse
3. Undo the choice (backtrack)
```

### 6. Trie (Prefix Tree)
Used for: Autocomplete, spell check, prefix matching

```
       root
      / | \
     a  b  c
    /
   p
  / \
 p   e (apple, ape)
```

---

## Practice Problem Categories

### Easy
1. Reverse a String
2. Check Palindrome
3. Find Duplicate Characters
4. Valid Anagram

### Medium
5. Longest Palindromic Substring
6. String Rotation Check
7. Count and Say
8. Group Anagrams

### Hard
9. Edit Distance
10. Longest Recurring Subsequence
11. Word Wrap Problem
12. Regular Expression Matching

---

## Quick Reference Card

```
+------------------+------------------+------------------+
|    Technique     |   Use When...    |   Complexity     |
+------------------+------------------+------------------+
| Two Pointers     | Compare from     | O(n) time        |
|                  | both ends        | O(1) space       |
+------------------+------------------+------------------+
| Sliding Window   | Contiguous       | O(n) time        |
|                  | substring        | O(k) space       |
+------------------+------------------+------------------+
| Frequency Map    | Count chars,     | O(n) time        |
|                  | anagrams         | O(k) space       |
+------------------+------------------+------------------+
| DP               | Optimal          | O(n*m) time      |
|                  | substructure     | O(n*m) space     |
+------------------+------------------+------------------+
| KMP              | Pattern          | O(n+m) time      |
|                  | matching         | O(m) space       |
+------------------+------------------+------------------+
| Recursion        | All perms/       | O(n!) or O(2^n)  |
|                  | subsequences     | O(n) space       |
+------------------+------------------+------------------+
```

---

## Summary

Strings are fundamental data structures with unique characteristics:
- **Immutability** in many languages affects how we build and modify strings
- **Two-pointer** and **sliding window** are go-to techniques for many string problems
- **Pattern matching** algorithms (KMP, Rabin-Karp) optimize substring search
- **Dynamic programming** solves complex string comparison problems
- Always consider **time complexity** of string operations, especially in loops

Master these concepts and you'll be well-equipped to tackle any string problem!
