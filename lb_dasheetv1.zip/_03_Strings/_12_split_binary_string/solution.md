# Split Binary String into Parts with Equal 0s and 1s

## Problem Statement
Given a binary string `s` (containing only '0's and '1's), split it into the **maximum** number of non-empty substrings such that each substring contains an **equal number of 0s and 1s**.

Return the maximum number of such splits possible. If the string cannot be split, return -1.

**Example 1:**
```
Input: s = "0100110101"
Output: 4
Explanation: Split into "01", "0011", "01", "01"
Each part has equal 0s and 1s.
```

**Example 2:**
```
Input: s = "0110"
Output: 2
Explanation: Split into "01", "10"
```

**Example 3:**
```
Input: s = "0101"
Output: 2
Explanation: Split into "01", "01"
```

**Example 4:**
```
Input: s = "000"
Output: -1
Explanation: Cannot split - total 0s != total 1s
```

---

## Intuition and Thought Process

### Key Observation
For a valid split at any position:
1. The substring from start to current position must have equal 0s and 1s
2. The remaining string must also be splittable (or empty)

### Greedy Insight
**Make the earliest possible split!**

Why? If we can split at position i (equal 0s and 1s), splitting here gives us more remaining string to potentially split further.

```
s = "0100110101"

Track balance: +1 for '1', -1 for '0'
When balance = 0, we can make a split!

Position: 0  1  2  3  4  5  6  7  8  9
Char:     0  1  0  0  1  1  0  1  0  1
Balance: -1  0 -1 -2 -1  0 -1  0 -1  0
Split:       ^              ^     ^     ^

Splits at positions: 1, 5, 7, 9 (4 splits)
```

---

## Approach: Greedy with Balance Counter

### Idea
- Use a balance counter: +1 for '1', -1 for '0'
- Every time balance reaches 0, we can make a split
- Count total splits

### Why Greedy Works
1. **Optimal substructure**: If we split at position i, remaining problem is independent
2. **Greedy choice**: Early split never hurts - it maximizes opportunities for more splits

### Visual Dry Run

```
s = "0100110101"

Step 1: char='0', balance = -1 (no split)
        Current: "0"

Step 2: char='1', balance = 0 --> SPLIT!
        Split #1: "01"
        Start new segment

Step 3: char='0', balance = -1 (no split)
        Current: "0"

Step 4: char='0', balance = -2 (no split)
        Current: "00"

Step 5: char='1', balance = -1 (no split)
        Current: "001"

Step 6: char='1', balance = 0 --> SPLIT!
        Split #2: "0011"
        Start new segment

Step 7: char='0', balance = -1 (no split)
        Current: "0"

Step 8: char='1', balance = 0 --> SPLIT!
        Split #3: "01"
        Start new segment

Step 9: char='0', balance = -1 (no split)
        Current: "0"

Step 10: char='1', balance = 0 --> SPLIT!
         Split #4: "01"

Result: 4 splits
```

### Algorithm
1. Initialize balance = 0, count = 0
2. For each character:
   - If '1': balance += 1
   - If '0': balance -= 1
   - If balance == 0: count += 1 (valid split point)
3. If final balance != 0: return -1 (unequal total 0s and 1s)
4. Return count

### Pseudocode
```
function maxSplits(s):
    balance = 0
    count = 0
    
    for char in s:
        if char == '1':
            balance += 1
        else:
            balance -= 1
        
        if balance == 0:
            count += 1
    
    if balance != 0:
        return -1  // Impossible to split
    
    return count
```

### Complexity Analysis
- **Time**: O(n) - single pass through string
- **Space**: O(1) - only two variables

---

## Alternative View: Prefix Sum

Think of it as finding indices where prefix sum of transformed string equals 0.

```
Transform: '1' -> +1, '0' -> -1
s = "0100110101"
transformed = [-1, +1, -1, -1, +1, +1, -1, +1, -1, +1]

Prefix sums: -1, 0, -1, -2, -1, 0, -1, 0, -1, 0
              ^     ^             ^      ^      ^
              1     2             3      4      (indices where sum = 0)
```

Each time prefix sum reaches 0, we've seen equal +1s and -1s (equal 1s and 0s).

---

## Edge Cases

| Input | Output | Reason |
|-------|--------|--------|
| "0" | -1 | Cannot have equal 0s and 1s |
| "01" | 1 | Single valid split |
| "10" | 1 | Order doesn't matter |
| "0011" | 1 | Only one way to split entire string |
| "0101" | 2 | "01" + "01" |
| "1100" | 1 | "1100" as whole |
| "111000" | 1 | Only one valid split |
| "010101" | 3 | Maximum granular splits |
| "" | 0 | Empty string - 0 splits |

---

## Proof of Correctness

**Claim**: Greedy splitting gives maximum number of parts.

**Proof by Exchange Argument**:
1. Let OPT be an optimal solution
2. Let GREEDY be our greedy solution
3. If GREEDY makes a split at position i, and OPT doesn't:
   - OPT must include position i in a larger segment
   - We can split OPT's segment at position i without violating constraints
   - This gives equal or more splits
4. Therefore, GREEDY is optimal

---

## Key Takeaways

1. **Balance tracking** is powerful for equal-count problems
2. **Greedy works** when early decisions don't hurt future choices
3. **Single pass** O(n) solution is possible
4. The problem is similar to **valid parentheses** balancing
5. **Check feasibility** first: total 0s must equal total 1s

---

## Related Problems
- Valid Parentheses (balance tracking)
- Partition Equal Subset Sum
- Split Array into Consecutive Subsequences
- Maximum Score from Performing Multiplication Operations
