"""
Split Binary String into Parts with Equal 0s and 1s
====================================================

Problem: Given a binary string, split it into maximum number of substrings
where each substring has equal number of 0s and 1s.

Approach: Greedy with balance counter
- Track balance: +1 for '1', -1 for '0'
- When balance hits 0, we can split
- Count total splits

Time: O(n)
Space: O(1)
"""

from typing import List, Tuple


# =============================================================================
# APPROACH 1: GREEDY WITH BALANCE COUNTER (Optimal)
# =============================================================================

def max_splits_greedy(s: str) -> int:
    """
    Find maximum number of splits where each part has equal 0s and 1s.

    INTUITION:
    - Use balance: +1 for '1', -1 for '0'
    - When balance = 0, we have equal counts - can split here
    - Greedy: split as early as possible to maximize opportunities

    EXAMPLE:
    s = "0100110101"

    Index:   0   1   2   3   4   5   6   7   8   9
    Char:    0   1   0   0   1   1   0   1   0   1
    Balance: -1  0  -1  -2  -1   0  -1   0  -1   0
    Split?   No  Yes No  No  No  Yes No  Yes No  Yes

    Splits: 4 (at indices 1, 5, 7, 9)

    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    if not s:
        return 0

    balance = 0  # Tracks difference between count of 1s and 0s
    count = 0    # Number of valid splits

    for char in s:
        # Update balance based on character
        if char == '1':
            balance += 1  # One more '1' than '0'
        else:
            balance -= 1  # One more '0' than '1'

        # When balance is 0, we have equal 0s and 1s
        # This is a valid split point!
        if balance == 0:
            count += 1

    # If final balance is not 0, string has unequal total 0s and 1s
    # Cannot be split into valid parts
    if balance != 0:
        return -1

    return count


# =============================================================================
# APPROACH 2: WITH SPLIT POSITIONS (For Debugging/Visualization)
# =============================================================================

def max_splits_with_positions(s: str) -> Tuple[int, List[str]]:
    """
    Same as above but also returns the actual split substrings.

    Returns: (count, list of substrings)

    Example:
    >>> max_splits_with_positions("0100110101")
    (4, ['01', '0011', '01', '01'])
    """
    if not s:
        return 0, []

    balance = 0
    splits = []
    start = 0  # Start index of current segment

    for i, char in enumerate(s):
        if char == '1':
            balance += 1
        else:
            balance -= 1

        if balance == 0:
            # Extract the current segment
            splits.append(s[start:i+1])
            start = i + 1  # Next segment starts after current position

    # Check if valid split
    if balance != 0:
        return -1, []

    return len(splits), splits


# =============================================================================
# APPROACH 3: VERBOSE VERSION WITH STEP-BY-STEP OUTPUT
# =============================================================================

def max_splits_verbose(s: str) -> int:
    """
    Verbose version that prints each step for learning.
    """
    print(f"\nFinding max splits for: '{s}'")
    print("=" * 50)

    if not s:
        print("Empty string - 0 splits")
        return 0

    balance = 0
    count = 0
    segment_start = 0

    print(f"{'Index':<6} {'Char':<6} {'Balance':<8} {'Action'}")
    print("-" * 50)

    for i, char in enumerate(s):
        if char == '1':
            balance += 1
        else:
            balance -= 1

        if balance == 0:
            segment = s[segment_start:i+1]
            count += 1
            print(f"{i:<6} '{char}'    {balance:<8} SPLIT! Segment: '{segment}'")
            segment_start = i + 1
        else:
            print(f"{i:<6} '{char}'    {balance:<8} Continue...")

    print("-" * 50)

    if balance != 0:
        print(f"Final balance = {balance} != 0")
        print("Cannot split - unequal total 0s and 1s")
        return -1

    print(f"Total splits: {count}")
    return count


# =============================================================================
# APPROACH 4: ALTERNATIVE - COUNT BASED
# =============================================================================

def max_splits_count_based(s: str) -> int:
    """
    Alternative implementation using explicit counts.

    Same logic, different implementation style.
    """
    if not s:
        return 0

    zeros = 0
    ones = 0
    splits = 0

    for char in s:
        if char == '0':
            zeros += 1
        else:
            ones += 1

        # Equal counts means we can split here
        if zeros == ones:
            splits += 1

    # Verify total counts are equal
    if zeros != ones:
        return -1

    return splits


# =============================================================================
# HELPER: VALIDATE A SPLIT
# =============================================================================

def is_valid_split(parts: List[str]) -> bool:
    """
    Check if all parts have equal 0s and 1s.
    """
    for part in parts:
        if part.count('0') != part.count('1'):
            return False
    return True


def verify_solution(s: str, expected_count: int):
    """
    Verify that the solution gives a valid split with expected count.
    """
    count, parts = max_splits_with_positions(s)

    if count == -1:
        return expected_count == -1

    if count != expected_count:
        return False

    return is_valid_split(parts)


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Run comprehensive test cases."""

    test_cases = [
        # (input, expected_output)
        ("0100110101", 4),   # "01" + "0011" + "01" + "01"
        ("0110", 2),        # "01" + "10"
        ("0101", 2),        # "01" + "01"
        ("10", 1),          # "10"
        ("01", 1),          # "01"
        ("0011", 1),        # "0011"
        ("1100", 1),        # "1100"
        ("010101", 3),      # "01" + "01" + "01"
        ("110100", 2),      # "1101" + "00"... wait, let's verify
        ("", 0),            # Empty string
        ("0", -1),          # Single 0, can't split
        ("1", -1),          # Single 1, can't split
        ("000", -1),        # All 0s, can't split
        ("111", -1),        # All 1s, can't split
        ("00110011", 2),    # "0011" + "0011"
        ("0110100110", 3),  # Multiple valid splits
    ]

    print("=" * 60)
    print("SPLIT BINARY STRING - TEST RESULTS")
    print("=" * 60)

    all_passed = True

    for s, expected in test_cases:
        result = max_splits_greedy(s)
        status = "PASS" if result == expected else "FAIL"

        if result != expected:
            all_passed = False

        # Also verify the split is valid
        count, parts = max_splits_with_positions(s)
        valid = "Valid" if (count == -1 or is_valid_split(parts)) else "Invalid"

        print(f"{status}: '{s}' -> {result} (expected {expected}) [{valid}]")
        if result == expected and result != -1:
            print(f"       Parts: {parts}")

    print("-" * 60)
    print(f"{'All tests passed!' if all_passed else 'Some tests failed!'}")


def demonstrate():
    """Demonstrate the algorithm step by step."""

    print("\n" + "=" * 60)
    print("STEP-BY-STEP DEMONSTRATION")
    print("=" * 60)

    # Example 1: Multiple splits
    max_splits_verbose("0100110101")

    # Example 2: Cannot split
    max_splits_verbose("000")

    # Example 3: Single character splits
    max_splits_verbose("010101")

    # Show alternative count-based approach
    print("\n" + "-" * 40)
    print("ALTERNATIVE COUNT-BASED APPROACH")
    print("-" * 40)
    s = "0110"
    result = max_splits_count_based(s)
    print(f"max_splits_count_based('{s}') = {result}")


# =============================================================================
# PRACTICE VARIATIONS
# =============================================================================

def min_splits(s: str) -> int:
    """
    VARIATION: Find MINIMUM number of splits (always 1 if possible).

    If the total 0s equal total 1s, minimum is 1 (don't split at all).
    """
    if s.count('0') == s.count('1'):
        return 1
    return -1


def all_split_ways(s: str) -> List[List[str]]:
    """
    VARIATION: Find ALL possible ways to split.

    Uses backtracking to find all valid split combinations.

    Note: This is exponential in complexity - O(2^n) in worst case.
    """
    if not s:
        return [[]]

    if s.count('0') != s.count('1'):
        return []

    result = []

    def backtrack(start: int, current: List[str]):
        if start == len(s):
            result.append(current[:])
            return

        zeros = ones = 0
        for end in range(start, len(s)):
            if s[end] == '0':
                zeros += 1
            else:
                ones += 1

            if zeros == ones:
                current.append(s[start:end+1])
                backtrack(end + 1, current)
                current.pop()

    backtrack(0, [])
    return result


if __name__ == "__main__":
    run_tests()
    demonstrate()

    # Show all possible split ways
    print("\n" + "=" * 60)
    print("ALL POSSIBLE SPLIT WAYS")
    print("=" * 60)

    for s in ["0101", "01100110", "0110"]:
        ways = all_split_ways(s)
        print(f"\n'{s}' can be split in {len(ways)} ways:")
        for way in ways:
            print(f"  {way}")
