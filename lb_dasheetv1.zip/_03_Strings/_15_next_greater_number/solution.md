# Next Greater Number with Same Digits

## Problem Statement
Given a number represented as a string (or array of digits), find the **smallest number greater than the given number** that can be formed using the same digits.

If no such number exists (when the number is already the largest permutation), return -1 or the input itself.

**Example 1:**
```
Input: "1234"
Output: "1243"
Explanation: 1243 is the smallest number > 1234 with same digits
```

**Example 2:**
```
Input: "4321"
Output: -1
Explanation: 4321 is already the largest permutation
```

**Example 3:**
```
Input: "218765"
Output: "251678"
Explanation: 
- Find pivot: 1 (first digit smaller than its right)
- Find successor: 5 (smallest digit on right that's > 1)
- Swap: 258761
- Reverse suffix: 251678
```

---

## Intuition and Thought Process

### Key Insight
To get the **next greater permutation**, we need to:
1. Find the **rightmost place** where we can make an increase
2. Make the **smallest possible increase** at that place
3. Arrange remaining digits in **ascending order** (smallest possible)

### Visual Understanding
```
Number: 1 5 8 4 7 6 5 3 1
                  ^
                  pivot (4 < 7)

Suffix after pivot: 7 6 5 3 1 (already descending!)

Find smallest digit in suffix that's > 4: it's 5

After swap: 1 5 8 5 7 6 4 3 1
                  ^--------^
                  reverse this part

Result: 1 5 8 5 1 3 4 6 7
```

---

## Algorithm Steps

### Step 1: Find the Pivot
Scan from right to left. Find the first digit that is **smaller than its right neighbor**.

```
1 5 8 4 7 6 5 3 1
      ^ 
      pivot (4 < 7)

If no pivot found -> number is already largest (like 4321)
```

### Step 2: Find the Successor
In the suffix (right of pivot), find the **smallest digit greater than pivot**.

```
Suffix: 7 6 5 3 1
Pivot: 4
Successor: 5 (smallest > 4)
```

### Step 3: Swap Pivot and Successor
```
Before: 1 5 8 4 7 6 5 3 1
After:  1 5 8 5 7 6 4 3 1
            ^       ^
            swapped
```

### Step 4: Reverse the Suffix
The suffix was in descending order. Reversing makes it ascending (smallest).

```
Before: 1 5 8 5 | 7 6 4 3 1
After:  1 5 8 5 | 1 3 4 6 7
                  ^^^^^^^^^
                  reversed to ascending
```

**Final Result: 158513467**

---

## Visual Dry Run

### Example: "218765"

```
Step 1: Find pivot (scan right to left)
        2 1 8 7 6 5
          ^ 
        1 < 8, so pivot = 1 at index 1

Step 2: Find successor in suffix [8,7,6,5]
        Smallest > 1 is 5 (at index 5)

Step 3: Swap pivot (1) with successor (5)
        2 5 8 7 6 1
          ^       ^

Step 4: Reverse suffix after pivot position
        2 5 | 8 7 6 1  ->  2 5 | 1 6 7 8
              ^^^^^            ^^^^^^^
              reverse

Result: "251678"
```

### Example: "4321" (No solution)

```
Step 1: Find pivot
        4 3 2 1
        Scan: 1 < nothing, 2 < nothing, 3 < nothing
        No pivot found!

Result: -1 (already largest permutation)
```

### Example: "11111" (All same)

```
Step 1: Find pivot
        1 1 1 1 1
        No digit is smaller than its right neighbor
        No pivot found!

Result: -1
```

---

## Pseudocode

```
function nextGreaterNumber(digits):
    n = length of digits

    // Step 1: Find pivot
    pivot = -1
    for i from n-2 down to 0:
        if digits[i] < digits[i+1]:
            pivot = i
            break

    // If no pivot, number is already largest
    if pivot == -1:
        return -1

    // Step 2: Find successor
    for i from n-1 down to pivot+1:
        if digits[i] > digits[pivot]:
            successor = i
            break

    // Step 3: Swap
    swap(digits[pivot], digits[successor])

    // Step 4: Reverse suffix
    reverse(digits[pivot+1 : n])

    return digits
```

---

## Complexity Analysis

- **Time**: O(n) - at most 3 passes through the array
  - Find pivot: O(n)
  - Find successor: O(n)
  - Reverse: O(n)
- **Space**: O(1) - in-place modification (or O(n) if creating new string)

---

## Why This Algorithm Works

### Correctness Proof

1. **Pivot is the rightmost increase point**
   - Everything to the right of pivot is in descending order
   - We can't make a larger number by rearranging only the suffix

2. **Swapping with successor gives minimal increase**
   - Successor is the smallest digit larger than pivot
   - This ensures the smallest possible increase at pivot position

3. **Reversing suffix gives smallest arrangement**
   - After swap, suffix is still descending
   - Reversing makes it ascending (smallest possible)

---

## Edge Cases

| Input | Output | Reason |
|-------|--------|--------|
| "1" | -1 | Single digit |
| "11" | -1 | All same |
| "12" | "21" | Simple swap |
| "21" | -1 | Already largest |
| "4321" | -1 | Strictly descending |
| "1234" | "1243" | Standard case |
| "1243" | "1324" | Standard case |
| "199999999" | "919999999" | Large numbers |
| "230241" | "230412" | Multiple valid swaps |

---

## Comparison with Related Algorithms

| Algorithm | Purpose | Time | Space |
|-----------|---------|------|-------|
| Next Permutation | Next greater permutation | O(n) | O(1) |
| Previous Permutation | Previous smaller permutation | O(n) | O(1) |
| Kth Permutation | Find kth permutation | O(n^2) | O(n) |
| All Permutations | Generate all | O(n! * n) | O(n!) |

---

## Variation: Previous Smaller Number

To find the **previous smaller permutation**:
1. Find pivot where `digits[i] > digits[i+1]` (first decrease from right)
2. Find predecessor (largest digit in suffix < pivot)
3. Swap
4. Reverse suffix (to make it descending = largest)

---

## Variation: Circular Next Permutation

If no next permutation exists, return the smallest permutation (first in sorted order).

```
Input: "4321"
Regular: -1
Circular: "1234"
```

---

## Key Takeaways

1. **Two-pointer pattern**: Scan from right to find pivot
2. **In-place modification**: O(1) space possible
3. **Descending suffix property**: Right of pivot is always descending
4. **Reversal trick**: Convert descending to ascending in O(n)
5. **Common interview problem**: Tests understanding of permutations
6. Used in **STL's next_permutation** function

---

## Related Problems
- Previous Permutation
- Permutation Sequence (Kth permutation)
- Next Greater Element III (LeetCode 556)
- Permutations I and II
- Next Palindrome Using Same Digits
