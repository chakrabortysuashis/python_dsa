"""
Next Greater Number with Same Digits (Next Permutation)
========================================================

Problem: Given a number as string/array of digits, find the smallest number
greater than the given number using the same digits.

Algorithm:
1. Find pivot: rightmost digit smaller than its right neighbor
2. Find successor: smallest digit in suffix greater than pivot
3. Swap pivot and successor
4. Reverse the suffix (to get smallest arrangement)

Time: O(n)
Space: O(1) for in-place, O(n) for string operations
"""

from typing import List, Optional, Tuple


# =============================================================================
# APPROACH 1: MAIN ALGORITHM (In-Place on List)
# =============================================================================

def next_permutation(nums: List[int]) -> bool:
    """
    Modify nums in-place to its next permutation.
    Returns True if next permutation exists, False if it's the last permutation.

    ALGORITHM:
    1. Find pivot: rightmost index where nums[i] < nums[i+1]
    2. Find successor: rightmost index where nums[j] > nums[pivot]
    3. Swap nums[pivot] and nums[successor]
    4. Reverse the suffix after pivot

    VISUAL EXAMPLE: [1, 5, 8, 4, 7, 6, 5, 3, 1]

    Step 1: pivot = 3 (value 4, since 4 < 7)
    Step 2: successor = 6 (value 5, smallest > 4 in suffix)
    Step 3: swap -> [1, 5, 8, 5, 7, 6, 4, 3, 1]
    Step 4: reverse suffix -> [1, 5, 8, 5, 1, 3, 4, 6, 7]

    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    n = len(nums)
    if n <= 1:
        return False

    # Step 1: Find the pivot
    # Scan from right to left, find first decrease
    pivot = -1
    for i in range(n - 2, -1, -1):
        if nums[i] < nums[i + 1]:
            pivot = i
            break

    # If no pivot found, array is in descending order (last permutation)
    if pivot == -1:
        return False

    # Step 2: Find the successor
    # Find the smallest element greater than nums[pivot] in the suffix
    for j in range(n - 1, pivot, -1):
        if nums[j] > nums[pivot]:
            successor = j
            break

    # Step 3: Swap pivot and successor
    nums[pivot], nums[successor] = nums[successor], nums[pivot]

    # Step 4: Reverse the suffix (after pivot)
    left, right = pivot + 1, n - 1
    while left < right:
        nums[left], nums[right] = nums[right], nums[left]
        left += 1
        right -= 1

    return True


# =============================================================================
# APPROACH 2: STRING VERSION
# =============================================================================

def next_greater_number(num: str) -> str:
    """
    Given a number as string, return the next greater number with same digits.
    Returns "-1" if no such number exists.

    Example:
    >>> next_greater_number("218765")
    "251678"
    >>> next_greater_number("4321")
    "-1"
    """
    if not num or len(num) <= 1:
        return "-1"

    # Convert to list for easier manipulation
    digits = list(num)
    n = len(digits)

    # Step 1: Find pivot
    pivot = -1
    for i in range(n - 2, -1, -1):
        if digits[i] < digits[i + 1]:
            pivot = i
            break

    if pivot == -1:
        return "-1"

    # Step 2: Find successor
    for j in range(n - 1, pivot, -1):
        if digits[j] > digits[pivot]:
            successor = j
            break

    # Step 3: Swap
    digits[pivot], digits[successor] = digits[successor], digits[pivot]

    # Step 4: Reverse suffix
    digits[pivot + 1:] = reversed(digits[pivot + 1:])

    return ''.join(digits)


# =============================================================================
# APPROACH 3: VERBOSE VERSION FOR LEARNING
# =============================================================================

def next_greater_number_verbose(num: str) -> str:
    """
    Verbose version that prints each step for learning.
    """
    print(f"\nFinding next greater number for: {num}")
    print("=" * 50)

    if not num or len(num) <= 1:
        print("Input too short, returning -1")
        return "-1"

    digits = list(num)
    n = len(digits)

    # Step 1: Find pivot
    print("\nStep 1: Find pivot (rightmost digit < its right neighbor)")
    pivot = -1
    for i in range(n - 2, -1, -1):
        print(f"  Comparing digits[{i}]='{digits[i]}' with digits[{i+1}]='{digits[i+1]}'", end="")
        if digits[i] < digits[i + 1]:
            pivot = i
            print(f" -> FOUND PIVOT at index {i}")
            break
        else:
            print(" -> No (descending)")

    if pivot == -1:
        print("  No pivot found - number is already largest permutation!")
        return "-1"

    print(f"  Pivot: digits[{pivot}] = '{digits[pivot]}'")

    # Step 2: Find successor
    print(f"\nStep 2: Find successor (smallest in suffix > '{digits[pivot]}')")
    suffix = digits[pivot + 1:]
    print(f"  Suffix: {suffix}")

    for j in range(n - 1, pivot, -1):
        print(f"  Checking digits[{j}]='{digits[j]}'", end="")
        if digits[j] > digits[pivot]:
            successor = j
            print(f" -> FOUND SUCCESSOR at index {j}")
            break
        else:
            print(f" -> Not greater than '{digits[pivot]}'")

    print(f"  Successor: digits[{successor}] = '{digits[successor]}'")

    # Step 3: Swap
    print(f"\nStep 3: Swap pivot and successor")
    print(f"  Before: {''.join(digits)}")
    digits[pivot], digits[successor] = digits[successor], digits[pivot]
    print(f"  After:  {''.join(digits)}")

    # Step 4: Reverse suffix
    print(f"\nStep 4: Reverse suffix after pivot (index {pivot + 1} onwards)")
    print(f"  Suffix before: {digits[pivot+1:]}")
    digits[pivot + 1:] = reversed(digits[pivot + 1:])
    print(f"  Suffix after:  {digits[pivot+1:]}")

    result = ''.join(digits)
    print(f"\nResult: {result}")
    return result


# =============================================================================
# APPROACH 4: WITH STEPS TRACKING
# =============================================================================

def next_greater_number_with_steps(num: str) -> Tuple[str, dict]:
    """
    Returns the next greater number along with the steps taken.

    Returns: (result, steps_dict)
    """
    steps = {
        'input': num,
        'pivot_index': -1,
        'pivot_value': None,
        'successor_index': -1,
        'successor_value': None,
        'after_swap': None,
        'result': None
    }

    if not num or len(num) <= 1:
        steps['result'] = "-1"
        return "-1", steps

    digits = list(num)
    n = len(digits)

    # Find pivot
    pivot = -1
    for i in range(n - 2, -1, -1):
        if digits[i] < digits[i + 1]:
            pivot = i
            break

    if pivot == -1:
        steps['result'] = "-1"
        return "-1", steps

    steps['pivot_index'] = pivot
    steps['pivot_value'] = digits[pivot]

    # Find successor
    for j in range(n - 1, pivot, -1):
        if digits[j] > digits[pivot]:
            successor = j
            break

    steps['successor_index'] = successor
    steps['successor_value'] = digits[successor]

    # Swap
    digits[pivot], digits[successor] = digits[successor], digits[pivot]
    steps['after_swap'] = ''.join(digits)

    # Reverse
    digits[pivot + 1:] = reversed(digits[pivot + 1:])
    result = ''.join(digits)
    steps['result'] = result

    return result, steps


# =============================================================================
# VARIATION: PREVIOUS PERMUTATION
# =============================================================================

def prev_permutation(nums: List[int]) -> bool:
    """
    Modify nums in-place to its previous permutation.

    Similar to next permutation but:
    1. Find pivot where nums[i] > nums[i+1] (first increase from right)
    2. Find predecessor (largest element in suffix < pivot)
    3. Swap
    4. Reverse suffix

    Time: O(n), Space: O(1)
    """
    n = len(nums)
    if n <= 1:
        return False

    # Find pivot (first increase from right)
    pivot = -1
    for i in range(n - 2, -1, -1):
        if nums[i] > nums[i + 1]:
            pivot = i
            break

    if pivot == -1:
        return False

    # Find predecessor (largest element in suffix < pivot)
    for j in range(n - 1, pivot, -1):
        if nums[j] < nums[pivot]:
            predecessor = j
            break

    # Swap
    nums[pivot], nums[predecessor] = nums[predecessor], nums[pivot]

    # Reverse suffix
    left, right = pivot + 1, n - 1
    while left < right:
        nums[left], nums[right] = nums[right], nums[left]
        left += 1
        right -= 1

    return True


# =============================================================================
# VARIATION: CIRCULAR NEXT PERMUTATION
# =============================================================================

def next_permutation_circular(nums: List[int]) -> None:
    """
    If no next permutation exists, wrap around to the smallest permutation.
    """
    if not next_permutation(nums):
        # No next exists, reverse entire array to get smallest
        nums.reverse()


# =============================================================================
# UTILITY: GENERATE ALL PERMUTATIONS IN ORDER
# =============================================================================

def all_permutations_in_order(num: str) -> List[str]:
    """
    Generate all permutations of digits in lexicographic order.

    Note: This is O(n! * n) - exponential, for demonstration only.
    """
    # Start with smallest permutation
    digits = sorted(num)
    result = [''.join(digits)]

    while next_permutation(digits):
        result.append(''.join(digits))

    return result


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Run comprehensive test cases."""

    test_cases = [
        # (input, expected_output)
        ("1234", "1243"),
        ("4321", "-1"),
        ("218765", "251678"),
        ("12", "21"),
        ("21", "-1"),
        ("1", "-1"),
        ("11", "-1"),
        ("111", "-1"),
        ("121", "211"),
        ("1243", "1324"),
        ("230241", "230412"),
        ("534976", "536479"),
        ("1999999999", "9199999999"),
    ]

    print("=" * 60)
    print("NEXT GREATER NUMBER - TEST RESULTS")
    print("=" * 60)

    all_passed = True

    for num, expected in test_cases:
        result = next_greater_number(num)
        status = "PASS" if result == expected else "FAIL"

        if result != expected:
            all_passed = False

        print(f"{status}: '{num}' -> '{result}' (expected '{expected}')")

    print("-" * 60)
    print(f"{'All tests passed!' if all_passed else 'Some tests failed!'}")


def demonstrate():
    """Demonstrate the algorithm step by step."""

    print("\n" + "=" * 60)
    print("STEP-BY-STEP DEMONSTRATION")
    print("=" * 60)

    # Verbose demonstration
    next_greater_number_verbose("218765")

    next_greater_number_verbose("4321")

    next_greater_number_verbose("1234")

    # Show all permutations for a small number
    print("\n" + "-" * 40)
    print("ALL PERMUTATIONS OF '123'")
    print("-" * 40)

    perms = all_permutations_in_order("123")
    for i, p in enumerate(perms):
        print(f"  {i+1}. {p}")

    # Show steps tracking
    print("\n" + "-" * 40)
    print("STEPS TRACKING")
    print("-" * 40)

    result, steps = next_greater_number_with_steps("218765")
    print(f"Input: {steps['input']}")
    print(f"Pivot: index={steps['pivot_index']}, value='{steps['pivot_value']}'")
    print(f"Successor: index={steps['successor_index']}, value='{steps['successor_value']}'")
    print(f"After swap: {steps['after_swap']}")
    print(f"Result: {steps['result']}")


def benchmark():
    """Benchmark the algorithm with large inputs."""

    print("\n" + "=" * 60)
    print("PERFORMANCE BENCHMARK")
    print("=" * 60)

    import time

    sizes = [100, 1000, 10000, 100000]

    for size in sizes:
        # Create a number like "123456789..." (ascending digits repeated)
        num = ''.join(str(i % 10) for i in range(size))

        start = time.perf_counter()
        result = next_greater_number(num)
        elapsed = (time.perf_counter() - start) * 1000

        print(f"Size {size:6}: {elapsed:.3f}ms")


if __name__ == "__main__":
    run_tests()
    demonstrate()
    benchmark()
