# Check Whether a String is Palindrome or Not

## Problem Statement
Given a string `s`, determine if it is a palindrome. A palindrome is a string that reads the same forward and backward.

**Example 1:**
```
Input: s = "RACECAR"
Output: true
Explanation: "RACECAR" reads same forwards and backwards
```

**Example 2:**
```
Input: s = "hello"
Output: false
```

**Example 3:**
```
Input: s = "A man, a plan, a canal: Panama"
Output: true (ignoring spaces and punctuation, case-insensitive)
```

---

## Intuition and Thought Process

A palindrome has a mirror property - characters equidistant from the center are identical.

```
String:   R  A  C  E  C  A  R
Index:    0  1  2  3  4  5  6
          |  |  |  |  |  |  |
Mirror:   R  A  C  E  C  A  R

Compare: s[0]==s[6], s[1]==s[5], s[2]==s[4], s[3] is center
```

### Key Insight
We only need to compare characters from both ends moving towards the center. If all corresponding pairs match, it's a palindrome.

---

## Approach 1: Brute Force (Reverse and Compare)

### Idea
Reverse the string and check if it equals the original.

### Algorithm
1. Reverse the string
2. Compare with original
3. Return true if equal

### Code
```python
def is_palindrome_brute(s: str) -> bool:
    return s == s[::-1]
```

### Complexity
- **Time**: O(n) - Reversing and comparing
- **Space**: O(n) - Reversed string storage

---

## Approach 2: Two Pointer (Optimal)

### Idea
Use two pointers starting from opposite ends, moving towards center.

### Algorithm
1. Initialize `left = 0`, `right = n - 1`
2. While `left < right`:
   - If `s[left] != s[right]`, return False
   - Increment left, decrement right
3. Return True

### Visual Dry Run

```
Input: "RACECAR"

Step 1: left=0, right=6
        R A C E C A R
        ^           ^
        L           R
        'R' == 'R' -> Match! Move pointers.

Step 2: left=1, right=5
        R A C E C A R
          ^       ^
          L       R
        'A' == 'A' -> Match! Move pointers.

Step 3: left=2, right=4
        R A C E C A R
            ^   ^
            L   R
        'C' == 'C' -> Match! Move pointers.

Step 4: left=3, right=3
        R A C E C A R
              ^
             L=R
        Left >= Right. STOP.

Result: TRUE (Palindrome)
```

```
Input: "HELLO"

Step 1: left=0, right=4
        H E L L O
        ^       ^
        L       R
        'H' != 'O' -> Mismatch!

Result: FALSE (Not a Palindrome)
```

### Pseudocode
```
function isPalindrome(s):
    left = 0
    right = length(s) - 1

    while left < right:
        if s[left] != s[right]:
            return FALSE
        left = left + 1
        right = right - 1

    return TRUE
```

### Complexity
- **Time**: O(n) - Each character compared at most once
- **Space**: O(1) - Only two pointers used

---

## Approach 3: Recursive

### Idea
Base case: Empty or single character is palindrome.
Recursive case: First and last match AND middle is palindrome.

### Code
```python
def is_palindrome_recursive(s: str) -> bool:
    if len(s) <= 1:
        return True
    if s[0] != s[-1]:
        return False
    return is_palindrome_recursive(s[1:-1])
```

### Complexity
- **Time**: O(n^2) - Due to string slicing
- **Space**: O(n) - Recursion stack

---

## Approach 4: Alphanumeric Only (Real-world variant)

### Problem Variant
Consider only alphanumeric characters and ignore cases.

### Algorithm
1. Initialize two pointers
2. Skip non-alphanumeric characters
3. Compare lowercase versions

### Visual Dry Run

```
Input: "A man, a plan, a canal: Panama"

Clean comparison (alphanumeric only, lowercase):
"amanaplanacanalpanama"

Step by step:
left=0  'a' | right=20 'a' -> Match
left=1  'm' | right=19 'm' -> Match
left=2  'a' | right=18 'a' -> Match
...continues...

Result: TRUE
```

### Code
```python
def is_palindrome_alphanumeric(s: str) -> bool:
    left, right = 0, len(s) - 1

    while left < right:
        # Skip non-alphanumeric from left
        while left < right and not s[left].isalnum():
            left += 1
        # Skip non-alphanumeric from right
        while left < right and not s[right].isalnum():
            right -= 1

        # Compare (case-insensitive)
        if s[left].lower() != s[right].lower():
            return False

        left += 1
        right -= 1

    return True
```

### Complexity
- **Time**: O(n)
- **Space**: O(1)

---

## Edge Cases

| Input | Output | Reason |
|-------|--------|--------|
| "" | true | Empty string is palindrome |
| "a" | true | Single character is palindrome |
| "aa" | true | Two same characters |
| "ab" | false | Two different characters |
| "aba" | true | Odd length palindrome |
| "abba" | true | Even length palindrome |

---

## Comparison Table

| Approach | Time | Space | Notes |
|----------|------|-------|-------|
| Reverse & Compare | O(n) | O(n) | Simple but uses extra space |
| Two Pointer | O(n) | O(1) | Optimal - recommended |
| Recursive | O(n^2) | O(n) | String slicing overhead |
| Half Iteration | O(n/2) | O(n/2) | Build half and compare |

---

## Key Takeaways

1. **Two-pointer** is the optimal approach for palindrome checking
2. Always clarify if comparison should be **case-sensitive**
3. Ask about handling **spaces and punctuation**
4. **Early termination** on first mismatch saves time
5. For **odd-length** strings, the middle character doesn't need comparison

---

## Related Problems
- Valid Palindrome II (can delete one character)
- Longest Palindromic Substring
- Palindrome Pairs
- Palindrome Partitioning
