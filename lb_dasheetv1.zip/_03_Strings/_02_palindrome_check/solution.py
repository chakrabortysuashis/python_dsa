"""
Check Whether a String is Palindrome or Not
============================================

Problem: Given a string s, determine if it is a palindrome.
A palindrome reads the same forward and backward.

Approaches:
1. Reverse and Compare
2. Two Pointer (Optimal)
3. Recursive
4. Alphanumeric Only (Real-world variant)
"""


# =============================================================================
# APPROACH 1: REVERSE AND COMPARE
# =============================================================================

def is_palindrome_reverse(s: str) -> bool:
    """
    Check palindrome by reversing and comparing.

    INTUITION:
    - A palindrome reads same forwards and backwards
    - So reversed string should equal original

    Time Complexity: O(n) - Reverse + Compare
    Space Complexity: O(n) - Stores reversed string
    """
    return s == s[::-1]


# =============================================================================
# APPROACH 2: TWO POINTER (Optimal)
# =============================================================================

def is_palindrome_two_pointer(s: str) -> bool:
    """
    Check palindrome using two pointers from opposite ends.

    INTUITION:
    - Characters equidistant from center must match
    - Compare s[i] with s[n-1-i] for all valid i
    - Use two pointers to do this efficiently

    VISUAL DRY RUN for "RACECAR":

    Initial State:
        R  A  C  E  C  A  R
        ^                 ^
        L=0               R=6

    Step 1: s[0]='R' == s[6]='R' -> Match
        R  A  C  E  C  A  R
           ^           ^
           L=1         R=5

    Step 2: s[1]='A' == s[5]='A' -> Match
        R  A  C  E  C  A  R
              ^     ^
              L=2   R=4

    Step 3: s[2]='C' == s[4]='C' -> Match
        R  A  C  E  C  A  R
                 ^
                L=R=3

    Step 4: L >= R, loop ends -> PALINDROME!

    Time Complexity: O(n) - Each element visited once
    Space Complexity: O(1) - Only two integer pointers
    """
    left = 0
    right = len(s) - 1

    while left < right:
        if s[left] != s[right]:
            return False  # Mismatch found
        left += 1
        right -= 1

    return True  # All characters matched


def is_palindrome_two_pointer_verbose(s: str) -> bool:
    """
    Same as above but with verbose output for learning.
    """
    left = 0
    right = len(s) - 1
    step = 1

    print(f"\nChecking if '{s}' is palindrome:")
    print(f"String: {' '.join(s)}")
    print(f"Index:  {' '.join(str(i) for i in range(len(s)))}")
    print()

    while left < right:
        print(f"Step {step}: Comparing s[{left}]='{s[left]}' with s[{right}]='{s[right]}'", end=" -> ")

        if s[left] != s[right]:
            print("MISMATCH! Not a palindrome.")
            return False

        print("Match!")
        left += 1
        right -= 1
        step += 1

    print(f"\nAll pairs matched! '{s}' IS a palindrome.")
    return True


# =============================================================================
# APPROACH 3: RECURSIVE
# =============================================================================

def is_palindrome_recursive(s: str) -> bool:
    """
    Check palindrome using recursion.

    INTUITION:
    - Base case: Empty or single char is palindrome
    - Recursive case: First and last must match,
      AND the middle portion must also be palindrome

    RECURSION TREE for "ABCBA":

    isPalin("ABCBA")
    -> A == A? Yes
    -> isPalin("BCB")
       -> B == B? Yes
       -> isPalin("C")
          -> len <= 1, return True
       -> return True
    -> return True

    Time Complexity: O(n^2) - String slicing creates copies
    Space Complexity: O(n) - Recursion stack depth
    """
    # Base case: empty or single character
    if len(s) <= 1:
        return True

    # Check first and last characters
    if s[0] != s[-1]:
        return False

    # Recursively check middle portion
    return is_palindrome_recursive(s[1:-1])


def is_palindrome_recursive_optimized(s: str, left: int = 0, right: int = None) -> bool:
    """
    Optimized recursive approach using indices (avoids string slicing).

    Time Complexity: O(n)
    Space Complexity: O(n) - Still has recursion stack
    """
    if right is None:
        right = len(s) - 1

    # Base case: pointers have met or crossed
    if left >= right:
        return True

    # Check current characters
    if s[left] != s[right]:
        return False

    # Recurse on inner portion
    return is_palindrome_recursive_optimized(s, left + 1, right - 1)


# =============================================================================
# APPROACH 4: ALPHANUMERIC ONLY (Real-world variant)
# =============================================================================

def is_palindrome_alphanumeric(s: str) -> bool:
    """
    Check palindrome considering only alphanumeric characters (case-insensitive).

    This is the LeetCode 125 "Valid Palindrome" problem.

    INTUITION:
    - Skip non-alphanumeric characters
    - Compare in lowercase for case-insensitivity
    - Use two pointers

    EXAMPLE: "A man, a plan, a canal: Panama"
    - Filtered: "amanaplanacanalpanama"
    - This IS a palindrome

    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    left = 0
    right = len(s) - 1

    while left < right:
        # Skip non-alphanumeric from left
        while left < right and not s[left].isalnum():
            left += 1

        # Skip non-alphanumeric from right
        while left < right and not s[right].isalnum():
            right -= 1

        # Compare characters (case-insensitive)
        if s[left].lower() != s[right].lower():
            return False

        left += 1
        right -= 1

    return True


def is_palindrome_alphanumeric_clean(s: str) -> bool:
    """
    Alternative: Clean string first, then check.

    Time Complexity: O(n)
    Space Complexity: O(n) - Cleaned string storage
    """
    # Filter and lowercase
    cleaned = ''.join(c.lower() for c in s if c.isalnum())

    # Check palindrome
    return cleaned == cleaned[::-1]


# =============================================================================
# APPROACH 5: VALID PALINDROME II (Can delete one character)
# =============================================================================

def is_palindrome_with_one_deletion(s: str) -> bool:
    """
    Check if string can become palindrome by deleting at most one character.

    LeetCode 680 - Valid Palindrome II

    INTUITION:
    - Use two pointers as usual
    - On mismatch, try skipping either left OR right character
    - If either results in palindrome, return True

    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    def check_palindrome(s: str, left: int, right: int) -> bool:
        """Helper to check palindrome in range."""
        while left < right:
            if s[left] != s[right]:
                return False
            left += 1
            right -= 1
        return True

    left = 0
    right = len(s) - 1

    while left < right:
        if s[left] != s[right]:
            # Try skipping left OR right character
            return (check_palindrome(s, left + 1, right) or
                    check_palindrome(s, left, right - 1))
        left += 1
        right -= 1

    return True


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def find_palindrome_substrings(s: str) -> list:
    """
    Find all palindromic substrings in a string.

    Time Complexity: O(n^3) - Can be optimized with Manacher's algorithm
    Space Complexity: O(n^2) - Storing all palindromes
    """
    result = set()
    n = len(s)

    for i in range(n):
        for j in range(i, n):
            substring = s[i:j+1]
            if is_palindrome_two_pointer(substring):
                result.add(substring)

    return sorted(result, key=lambda x: (len(x), x))


def make_palindrome(s: str) -> str:
    """
    Make a string palindrome by appending minimum characters at end.

    Example: "abc" -> "abcba"

    Time Complexity: O(n^2)
    Space Complexity: O(n)
    """
    if is_palindrome_two_pointer(s):
        return s

    # Find longest suffix that is also a prefix of reverse
    for i in range(len(s)):
        suffix = s[i:]
        if is_palindrome_two_pointer(s[:i] + suffix):
            # Prepend needed characters
            return s[:i][::-1] + s if i > 0 else s

    # Worst case: append reverse of s[:-1]
    return s + s[:-1][::-1]


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Run comprehensive test cases."""

    # Test cases: (input, expected_for_strict, expected_for_alphanumeric)
    test_cases = [
        # Strict palindromes
        ("", True),
        ("a", True),
        ("aa", True),
        ("ab", False),
        ("aba", True),
        ("abba", True),
        ("RACECAR", True),
        ("racecar", True),
        ("hello", False),
        ("MADAM", True),
        ("12321", True),
        ("12345", False),
    ]

    alphanumeric_cases = [
        ("A man, a plan, a canal: Panama", True),
        ("race a car", False),
        ("Was it a car or a cat I saw?", True),
        (" ", True),
        (".,", True),
    ]

    print("=" * 60)
    print("PALINDROME CHECK - TEST RESULTS")
    print("=" * 60)

    # Test strict palindrome
    print("\n--- Strict Palindrome Tests ---")
    for s, expected in test_cases:
        result = is_palindrome_two_pointer(s)
        status = "PASS" if result == expected else "FAIL"
        print(f"  {status}: '{s}' -> {result}")

    # Test alphanumeric palindrome
    print("\n--- Alphanumeric Palindrome Tests ---")
    for s, expected in alphanumeric_cases:
        result = is_palindrome_alphanumeric(s)
        status = "PASS" if result == expected else "FAIL"
        print(f"  {status}: '{s}' -> {result}")

    # Test palindrome with one deletion
    print("\n--- Palindrome with One Deletion ---")
    deletion_cases = [
        ("aba", True),
        ("abca", True),  # Remove 'c' -> "aba"
        ("abc", False),
    ]
    for s, expected in deletion_cases:
        result = is_palindrome_with_one_deletion(s)
        status = "PASS" if result == expected else "FAIL"
        print(f"  {status}: '{s}' -> {result}")

    # Demonstrate verbose version
    print("\n--- Verbose Demonstration ---")
    is_palindrome_two_pointer_verbose("RACECAR")
    is_palindrome_two_pointer_verbose("HELLO")


def demonstrate_approaches():
    """Compare all approaches."""

    test_string = "AMANAPLANACANALPANAMA"

    print("\n" + "=" * 60)
    print("APPROACH COMPARISON")
    print("=" * 60)

    approaches = [
        ("Reverse and Compare", is_palindrome_reverse),
        ("Two Pointer", is_palindrome_two_pointer),
        ("Recursive", is_palindrome_recursive),
        ("Recursive Optimized", is_palindrome_recursive_optimized),
    ]

    for name, func in approaches:
        result = func(test_string)
        print(f"{name}: '{test_string}' -> {result}")


if __name__ == "__main__":
    run_tests()
    demonstrate_approaches()
