"""
Find Longest Recurring Subsequence in String
=============================================

Problem: Find the length of the longest subsequence that appears at least
twice in the string, using characters at different positions.

This is a variation of LCS where we find LCS of string with itself,
but characters at the same index cannot be used (i != j constraint).
"""

from typing import List, Tuple


def longest_recurring_subsequence(s: str) -> int:
    """
    Find length of longest recurring subsequence using DP.

    INTUITION:
    - This is LCS of s with itself
    - But we add constraint: s[i] == s[j] AND i != j
    - This ensures same position is not used in both subsequences

    RECURRENCE:
    dp[i][j] = LRS length for s[0:i] and s[0:j]

    If s[i-1] == s[j-1] AND i != j:
        dp[i][j] = 1 + dp[i-1][j-1]  (include this char)
    Else:
        dp[i][j] = max(dp[i-1][j], dp[i][j-1])  (skip one)

    Time Complexity: O(n^2)
    Space Complexity: O(n^2)
    """
    n = len(s)
    if n == 0:
        return 0

    # dp[i][j] = LRS length for s[0:i] and s[0:j]
    dp = [[0] * (n + 1) for _ in range(n + 1)]

    for i in range(1, n + 1):
        for j in range(1, n + 1):
            # Characters match AND at different positions
            if s[i - 1] == s[j - 1] and i != j:
                dp[i][j] = 1 + dp[i - 1][j - 1]
            else:
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1])

    return dp[n][n]


def longest_recurring_subsequence_with_string(s: str) -> Tuple[int, str]:
    """
    Find LRS length and the actual subsequence.

    Returns:
        Tuple of (length, subsequence string)
    """
    n = len(s)
    if n == 0:
        return 0, ""

    # Build DP table
    dp = [[0] * (n + 1) for _ in range(n + 1)]

    for i in range(1, n + 1):
        for j in range(1, n + 1):
            if s[i - 1] == s[j - 1] and i != j:
                dp[i][j] = 1 + dp[i - 1][j - 1]
            else:
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1])

    # Backtrack to find the subsequence
    i, j = n, n
    result = []

    while i > 0 and j > 0:
        if s[i - 1] == s[j - 1] and i != j and dp[i][j] == dp[i - 1][j - 1] + 1:
            result.append(s[i - 1])
            i -= 1
            j -= 1
        elif dp[i - 1][j] > dp[i][j - 1]:
            i -= 1
        else:
            j -= 1

    return dp[n][n], ''.join(reversed(result))


def longest_recurring_subsequence_verbose(s: str) -> int:
    """
    Verbose version showing DP table construction.
    """
    n = len(s)
    if n == 0:
        return 0

    dp = [[0] * (n + 1) for _ in range(n + 1)]

    print(f"\nFinding LRS for '{s}':")
    print("=" * 50)

    for i in range(1, n + 1):
        for j in range(1, n + 1):
            if s[i - 1] == s[j - 1] and i != j:
                dp[i][j] = 1 + dp[i - 1][j - 1]
                print(f"dp[{i}][{j}]: '{s[i-1]}' == '{s[j-1]}' and {i} != {j}")
                print(f"         -> 1 + dp[{i-1}][{j-1}] = 1 + {dp[i-1][j-1]} = {dp[i][j]}")
            else:
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1])

    # Print DP table
    print("\nDP Table:")
    print("    ", end="")
    print("  '' ", end="")
    for c in s:
        print(f"  {c} ", end="")
    print()

    for i in range(n + 1):
        if i == 0:
            print(" '' ", end="")
        else:
            print(f"  {s[i-1]} ", end="")
        for j in range(n + 1):
            print(f" {dp[i][j]:2d} ", end="")
        print()

    print(f"\nLRS Length: {dp[n][n]}")
    return dp[n][n]


def lrs_space_optimized(s: str) -> int:
    """
    Space-optimized version using O(n) space.
    """
    n = len(s)
    if n == 0:
        return 0

    # Use two rows instead of full table
    prev = [0] * (n + 1)
    curr = [0] * (n + 1)

    for i in range(1, n + 1):
        for j in range(1, n + 1):
            if s[i - 1] == s[j - 1] and i != j:
                curr[j] = 1 + prev[j - 1]
            else:
                curr[j] = max(prev[j], curr[j - 1])
        prev, curr = curr, [0] * (n + 1)

    return prev[n]


def find_all_recurring_subsequences(s: str) -> List[str]:
    """
    Find all recurring subsequences of maximum length.

    Note: This can be exponential in worst case.
    """
    n = len(s)
    if n == 0:
        return []

    # Build DP table
    dp = [[0] * (n + 1) for _ in range(n + 1)]

    for i in range(1, n + 1):
        for j in range(1, n + 1):
            if s[i - 1] == s[j - 1] and i != j:
                dp[i][j] = 1 + dp[i - 1][j - 1]
            else:
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1])

    lrs_len = dp[n][n]
    result = set()

    def backtrack(i: int, j: int, current: List[str]):
        if len(current) == lrs_len:
            result.add(''.join(reversed(current)))
            return

        if i <= 0 or j <= 0:
            return

        if s[i - 1] == s[j - 1] and i != j and dp[i][j] == dp[i - 1][j - 1] + 1:
            current.append(s[i - 1])
            backtrack(i - 1, j - 1, current)
            current.pop()

        if dp[i - 1][j] >= dp[i][j - 1]:
            backtrack(i - 1, j, current)
        if dp[i][j - 1] >= dp[i - 1][j]:
            backtrack(i, j - 1, current)

    backtrack(n, n, [])
    return list(result)


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Run comprehensive test cases."""

    test_cases = [
        ("AABEBCDD", 3),   # "ABD"
        ("aab", 1),        # "a"
        ("aabb", 2),       # "ab"
        ("abc", 0),        # No recurring
        ("", 0),           # Empty
        ("a", 0),          # Single char
        ("aa", 1),         # Two same
        ("aaa", 1),        # Three same (only 1 because we need different positions)
        ("AABEBCDD", 3),   # "ABD"
        ("abab", 2),       # "ab"
    ]

    print("=" * 60)
    print("LONGEST RECURRING SUBSEQUENCE - TEST RESULTS")
    print("=" * 60)

    all_passed = True
    for s, expected in test_cases:
        result = longest_recurring_subsequence(s)
        status = "PASS" if result == expected else "FAIL"
        if result != expected:
            all_passed = False
        print(f"  {status}: '{s}' -> {result} (expected {expected})")

    print(f"\n{'All tests PASSED!' if all_passed else 'Some tests FAILED!'}")


def demonstrate():
    """Demonstrate the algorithm step by step."""

    print("\n" + "=" * 60)
    print("STEP-BY-STEP DEMONSTRATION")
    print("=" * 60)

    # Verbose demonstration
    s = "AABEBCDD"
    longest_recurring_subsequence_verbose(s)

    # Get actual subsequence
    length, subseq = longest_recurring_subsequence_with_string(s)
    print(f"\nActual recurring subsequence: '{subseq}' (length {length})")

    # Find all LRS
    all_lrs = find_all_recurring_subsequences(s)
    print(f"All LRS of max length: {all_lrs}")


if __name__ == "__main__":
    run_tests()
    demonstrate()
