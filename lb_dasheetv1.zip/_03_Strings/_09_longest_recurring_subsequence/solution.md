# Find Longest Recurring Subsequence in String

## Problem Statement
Given a string `s`, find the length of the longest subsequence that appears at least twice in the string. The two subsequences must use characters at different positions.

**Example 1:**
```
Input: s = "AABEBCDD"
Output: 3
Explanation: "ABD" appears twice as a subsequence using different positions
```

**Example 2:**
```
Input: s = "aab"
Output: 1
Explanation: "a" appears at positions 0 and 1
```

---

## Intuition and Thought Process

This is a variation of **Longest Common Subsequence (LCS)**, where we find LCS of string with itself, but with a constraint: **characters at the same index cannot be used**.

```
s = "AABEBCDD"

Finding LCS of s with s, where s[i] == s[j] AND i != j

This ensures we use characters at different positions.
```

### Key Insight
- Standard LCS finds common subsequence between two strings
- Here, both strings are same, but we add constraint: i != j
- This ensures the same position is not used in both subsequences

---

## Approach: Dynamic Programming

### Recurrence Relation
```
dp[i][j] = longest recurring subsequence in s[0..i-1] and s[0..j-1]

If s[i-1] == s[j-1] AND i != j:
    dp[i][j] = 1 + dp[i-1][j-1]
Else:
    dp[i][j] = max(dp[i-1][j], dp[i][j-1])
```

### Visual Dry Run
```
s = "AABEBCDD"

DP Table:
        ""  A   A   B   E   B   C   D   D
    ""   0   0   0   0   0   0   0   0   0
    A    0   0   1   1   1   1   1   1   1
    A    0   1   1   1   1   1   1   1   1
    B    0   1   1   1   1   2   2   2   2
    E    0   1   1   1   1   2   2   2   2
    B    0   1   1   2   2   2   2   2   2
    C    0   1   1   2   2   2   2   2   2
    D    0   1   1   2   2   2   2   2   3
    D    0   1   1   2   2   2   2   3   3

Answer: dp[8][8] = 3

The recurring subsequence is "ABD"
```

### Why i != j Constraint?
Without this constraint, every character would match with itself:
```
s = "ABC"
Without i != j: dp[1][1] = 1 (A matches A at same position)
This gives wrong answer as it's the same occurrence.

With i != j: dp[1][1] = 0 (A at position 0 can't match A at position 0)
```

---

## Pseudocode
```
function longestRecurringSubsequence(s):
    n = length(s)
    dp = array[n+1][n+1] filled with 0

    for i from 1 to n:
        for j from 1 to n:
            if s[i-1] == s[j-1] AND i != j:
                dp[i][j] = 1 + dp[i-1][j-1]
            else:
                dp[i][j] = max(dp[i-1][j], dp[i][j-1])

    return dp[n][n]
```

---

## Reconstructing the Subsequence

To find the actual subsequence (not just length):
```python
def find_lrs_string(s):
    n = len(s)
    dp = [[0] * (n + 1) for _ in range(n + 1)]

    # Fill DP table
    for i in range(1, n + 1):
        for j in range(1, n + 1):
            if s[i-1] == s[j-1] and i != j:
                dp[i][j] = 1 + dp[i-1][j-1]
            else:
                dp[i][j] = max(dp[i-1][j], dp[i][j-1])

    # Backtrack to find the subsequence
    i, j = n, n
    result = []

    while i > 0 and j > 0:
        if dp[i][j] == dp[i-1][j-1] + 1 and s[i-1] == s[j-1] and i != j:
            result.append(s[i-1])
            i -= 1
            j -= 1
        elif dp[i-1][j] > dp[i][j-1]:
            i -= 1
        else:
            j -= 1

    return ''.join(reversed(result))
```

---

## Complexity Analysis

- **Time Complexity**: O(n^2) - Fill n x n DP table
- **Space Complexity**: O(n^2) - DP table

### Space Optimization
Can be reduced to O(n) using rolling array technique.

---

## Edge Cases

| Input | Output | Notes |
|-------|--------|-------|
| "" | 0 | Empty string |
| "a" | 0 | Single character |
| "aa" | 1 | Two same chars |
| "abc" | 0 | No recurring subsequence |
| "aab" | 1 | "a" recurs |

---

## Key Takeaways

1. This is **modified LCS** with string compared to itself
2. The constraint **i != j** prevents using same position
3. DP state: longest recurring subsequence ending at (i, j)
4. Can backtrack to find actual subsequence

---

## Related Problems
- Longest Common Subsequence
- Longest Repeated Substring
- Longest Palindromic Subsequence
- Distinct Subsequences
