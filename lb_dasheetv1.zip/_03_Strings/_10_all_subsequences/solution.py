"""
Print All Subsequences of a String
===================================

A subsequence is derived by deleting some (or no) elements without
changing the order of remaining elements.

Total subsequences: 2^n (each char either included or excluded)

Approaches:
1. Recursion (Include/Exclude)
2. Iterative with Bitmask
"""

from typing import List


# =============================================================================
# APPROACH 1: RECURSION (Include/Exclude)
# =============================================================================

def generate_subsequences_recursive(s: str) -> List[str]:
    """
    Generate all subsequences using recursion.

    RECURSION TREE for "ab":

                    f(0, "")
                   /        \
             Inc 'a'      Exc 'a'
               /              \
          f(1, "a")        f(1, "")
          /      \         /      \
      Inc 'b'  Exc 'b'  Inc 'b'  Exc 'b'
        /         \        /         \
    f(2,"ab")  f(2,"a")  f(2,"b")  f(2,"")
       |          |         |         |
     "ab"        "a"       "b"       ""

    Time Complexity: O(2^n * n) - 2^n calls, each builds string of up to n
    Space Complexity: O(n) - recursion stack depth
    """
    result = []

    def helper(index: int, current: str):
        # Base case: processed all characters
        if index == len(s):
            result.append(current)
            return

        # Choice 1: Include current character
        helper(index + 1, current + s[index])

        # Choice 2: Exclude current character
        helper(index + 1, current)

    helper(0, "")
    return result


def generate_subsequences_with_list(s: str) -> List[str]:
    """
    Same approach but using list for efficiency (avoid string concat).
    """
    result = []

    def helper(index: int, current: List[str]):
        if index == len(s):
            result.append(''.join(current))
            return

        # Include
        current.append(s[index])
        helper(index + 1, current)
        current.pop()  # Backtrack

        # Exclude
        helper(index + 1, current)

    helper(0, [])
    return result


def generate_subsequences_verbose(s: str) -> List[str]:
    """
    Verbose version showing recursion tree.
    """
    result = []
    indent = [0]

    def helper(index: int, current: str):
        prefix = "  " * indent[0]

        if index == len(s):
            print(f"{prefix}Base case: Add '{current}' to result")
            result.append(current)
            return

        char = s[index]
        print(f"{prefix}At index {index}, char='{char}', current='{current}'")

        # Include
        print(f"{prefix}  -> Include '{char}'")
        indent[0] += 1
        helper(index + 1, current + char)
        indent[0] -= 1

        # Exclude
        print(f"{prefix}  -> Exclude '{char}'")
        indent[0] += 1
        helper(index + 1, current)
        indent[0] -= 1

    print(f"\nGenerating subsequences of '{s}':")
    print("=" * 50)
    helper(0, "")
    return result


# =============================================================================
# APPROACH 2: ITERATIVE WITH BITMASK
# =============================================================================

def generate_subsequences_bitmask(s: str) -> List[str]:
    """
    Generate subsequences using bit manipulation.

    INTUITION:
    - Each subsequence corresponds to a binary number
    - Bit i = 1 means include character at index i
    - Total numbers: 0 to 2^n - 1

    EXAMPLE for "abc":
    Binary | Decimal | Subsequence
    000    | 0       | ""
    001    | 1       | "c"
    010    | 2       | "b"
    011    | 3       | "bc"
    100    | 4       | "a"
    101    | 5       | "ac"
    110    | 6       | "ab"
    111    | 7       | "abc"

    Time Complexity: O(2^n * n)
    Space Complexity: O(1) extra
    """
    n = len(s)
    result = []

    # Iterate through all possible masks (0 to 2^n - 1)
    for mask in range(1 << n):  # 1 << n is 2^n
        subsequence = []

        for i in range(n):
            # Check if i-th bit is set
            if mask & (1 << i):
                subsequence.append(s[i])

        result.append(''.join(subsequence))

    return result


def generate_subsequences_bitmask_verbose(s: str) -> List[str]:
    """
    Verbose bitmask version showing binary representation.
    """
    n = len(s)
    result = []

    print(f"\nBitmask approach for '{s}':")
    print("=" * 50)
    print(f"{'Mask':<6} {'Binary':<{n+2}} {'Subsequence':<10}")
    print("-" * 30)

    for mask in range(1 << n):
        subsequence = []
        binary = format(mask, f'0{n}b')

        for i in range(n):
            if mask & (1 << i):
                subsequence.append(s[i])

        subseq_str = ''.join(subsequence)
        result.append(subseq_str)
        print(f"{mask:<6} {binary:<{n+2}} \"{subseq_str}\"")

    return result


# =============================================================================
# APPROACH 3: ITERATIVE (Building up)
# =============================================================================

def generate_subsequences_iterative(s: str) -> List[str]:
    """
    Iterative approach by building up subsequences.

    For each new character, add it to all existing subsequences.

    EXAMPLE for "abc":
    Start: [""]
    Add 'a': ["", "a"]
    Add 'b': ["", "a", "b", "ab"]
    Add 'c': ["", "a", "b", "ab", "c", "ac", "bc", "abc"]

    Time Complexity: O(2^n * n)
    Space Complexity: O(2^n) for result
    """
    result = [""]  # Start with empty subsequence

    for char in s:
        # Add current char to all existing subsequences
        new_subsequences = [subseq + char for subseq in result]
        result.extend(new_subsequences)

    return result


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def count_subsequences(s: str) -> int:
    """Return count of subsequences (2^n)."""
    return 1 << len(s)


def print_recursion_tree(s: str):
    """
    Print ASCII recursion tree for visualization.
    """
    print(f"\nRecursion Tree for '{s}':")
    print("=" * 60)

    def print_tree(index: int, current: str, prefix: str, is_last: bool):
        connector = "└── " if is_last else "├── "
        action = f"current='{current}'"

        if index == len(s):
            print(f"{prefix}{connector}LEAF: Add '{current}'")
            return

        char = s[index]
        print(f"{prefix}{connector}index={index}, {action}")

        new_prefix = prefix + ("    " if is_last else "│   ")

        # Include branch
        print_tree(index + 1, current + char, new_prefix, False)
        # Exclude branch
        print_tree(index + 1, current, new_prefix, True)

    print_tree(0, "", "", True)


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Run comprehensive test cases."""

    test_cases = [
        ("", [""]),
        ("a", ["a", ""]),
        ("ab", ["ab", "a", "b", ""]),
        ("abc", ["abc", "ab", "ac", "a", "bc", "b", "c", ""]),
    ]

    print("=" * 60)
    print("ALL SUBSEQUENCES - TEST RESULTS")
    print("=" * 60)

    approaches = [
        ("Recursive", generate_subsequences_recursive),
        ("Recursive (List)", generate_subsequences_with_list),
        ("Bitmask", generate_subsequences_bitmask),
        ("Iterative", generate_subsequences_iterative),
    ]

    for name, func in approaches:
        print(f"\n--- {name} ---")
        all_passed = True

        for s, expected in test_cases:
            result = sorted(func(s))
            expected_sorted = sorted(expected)
            if result != expected_sorted:
                all_passed = False
                print(f"  FAIL: '{s}' -> {result}")

        if all_passed:
            print(f"  All {len(test_cases)} test cases PASSED!")

    # Verify counts
    print("\n--- Count Verification ---")
    for s, _ in test_cases:
        count = len(generate_subsequences_recursive(s))
        expected_count = 1 << len(s)  # 2^n
        status = "PASS" if count == expected_count else "FAIL"
        print(f"  {status}: '{s}' has {count} subsequences (expected 2^{len(s)} = {expected_count})")


def demonstrate():
    """Demonstrate algorithms step by step."""

    print("\n" + "=" * 60)
    print("STEP-BY-STEP DEMONSTRATION")
    print("=" * 60)

    # Print recursion tree
    print_recursion_tree("ab")

    # Verbose recursive
    generate_subsequences_verbose("ab")

    # Verbose bitmask
    generate_subsequences_bitmask_verbose("abc")


if __name__ == "__main__":
    run_tests()
    demonstrate()
