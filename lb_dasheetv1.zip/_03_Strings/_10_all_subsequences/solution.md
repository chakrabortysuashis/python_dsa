# Print All Subsequences of a String

## Problem Statement
Given a string `s`, print all possible subsequences of the string.

A subsequence is a sequence that can be derived by deleting some or no elements without changing the order of remaining elements.

**Example:**
```
Input: s = "abc"
Output: ["", "a", "b", "c", "ab", "ac", "bc", "abc"]
Explanation: Total 2^3 = 8 subsequences
```

---

## Intuition and Thought Process

For each character, we have **two choices**:
1. **Include** the character in the subsequence
2. **Exclude** the character from the subsequence

This gives us 2^n total subsequences for a string of length n.

```
String: "abc"

For 'a': Include or Exclude
For 'b': Include or Exclude
For 'c': Include or Exclude

Total combinations: 2 * 2 * 2 = 8
```

---

## Recursion Tree

```
                          f("abc", 0, "")
                         /              \
                    Include 'a'      Exclude 'a'
                       /                  \
               f("abc", 1, "a")     f("abc", 1, "")
                /        \            /        \
           Inc 'b'    Exc 'b'    Inc 'b'    Exc 'b'
             /           \          /           \
      f(2,"ab")     f(2,"a")   f(2,"b")    f(2,"")
        /   \        /   \      /   \       /   \
     Inc   Exc    Inc   Exc  Inc   Exc   Inc   Exc
     'c'   'c'    'c'   'c'  'c'   'c'   'c'   'c'
      |     |      |     |    |     |     |     |
    "abc" "ab"   "ac"  "a"  "bc"  "b"   "c"   ""

Result: ["abc", "ab", "ac", "a", "bc", "b", "c", ""]
```

---

## Approach 1: Recursion (Include/Exclude)

### Algorithm
1. Start with empty current string and index 0
2. At each index, make two recursive calls:
   - Include current character
   - Exclude current character
3. When index reaches end, add current string to result

### Pseudocode
```
function generateSubsequences(s, index, current, result):
    if index == length(s):
        result.add(current)
        return

    // Include current character
    generateSubsequences(s, index + 1, current + s[index], result)

    // Exclude current character
    generateSubsequences(s, index + 1, current, result)
```

### Complexity
- **Time**: O(2^n * n) - 2^n subsequences, each up to n length
- **Space**: O(n) - Recursion stack depth

---

## Approach 2: Iterative with Bitmask

### Idea
Each subsequence corresponds to a binary number from 0 to 2^n - 1.
Bit i = 1 means include character at position i.

### Example
```
s = "abc"

Binary | Decimal | Subsequence
000    | 0       | ""
001    | 1       | "c"
010    | 2       | "b"
011    | 3       | "bc"
100    | 4       | "a"
101    | 5       | "ac"
110    | 6       | "ab"
111    | 7       | "abc"
```

### Pseudocode
```
function generateSubsequences(s):
    n = length(s)
    result = []

    for mask from 0 to 2^n - 1:
        subsequence = ""
        for i from 0 to n - 1:
            if (mask & (1 << i)) != 0:
                subsequence += s[i]
        result.add(subsequence)

    return result
```

### Complexity
- **Time**: O(2^n * n)
- **Space**: O(1) extra (excluding result storage)

---

## Dry Run: Recursive Approach

```
s = "ab", index = 0, current = ""

Call Stack:
f(0, "")
├── f(1, "a")      [Include 'a']
│   ├── f(2, "ab") [Include 'b'] -> Add "ab" to result
│   └── f(2, "a")  [Exclude 'b'] -> Add "a" to result
└── f(1, "")       [Exclude 'a']
    ├── f(2, "b")  [Include 'b'] -> Add "b" to result
    └── f(2, "")   [Exclude 'b'] -> Add "" to result

Result: ["ab", "a", "b", ""]
```

---

## Properties of Subsequences

1. **Total count**: 2^n for string of length n
2. **Empty subsequence**: Always included
3. **Order preserved**: Characters maintain relative order
4. **Different from substrings**: Subsequences can skip characters
5. **Different from permutations**: Order cannot change

---

## Comparison: Subsequence vs Substring vs Permutation

| Type | "abc" examples | Count |
|------|----------------|-------|
| Subsequence | "", "a", "ac", "abc" | 2^n |
| Substring | "a", "ab", "abc", "b", "bc", "c" | n(n+1)/2 |
| Permutation | "abc", "acb", "bac", "bca", "cab", "cba" | n! |

---

## Key Takeaways

1. **Include/Exclude pattern** is fundamental for subset problems
2. **Bitmask approach** provides iterative alternative
3. **2^n subsequences** for string of length n
4. Recursion tree helps visualize the decision process
5. Subsequences preserve order, unlike permutations

---

## Related Problems
- Subsets (LeetCode 78)
- Subsets II (with duplicates)
- Longest Common Subsequence
- Distinct Subsequences
