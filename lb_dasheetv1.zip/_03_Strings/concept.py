"""
String Concepts - Utility Functions and Pattern Matching Templates
==================================================================

This module provides fundamental string operations, pattern matching algorithms,
and utility functions commonly used in DSA problems.

Topics Covered:
- Basic string operations and their complexities
- Character frequency counting
- Two-pointer techniques
- Sliding window templates
- Pattern matching algorithms (KMP, Rabin-Karp, Z-Algorithm)
- String transformation utilities
"""

from collections import Counter, defaultdict
from typing import List, Dict, Set, Tuple, Optional


# =============================================================================
# SECTION 1: BASIC STRING OPERATIONS
# =============================================================================

def demonstrate_string_operations():
    """
    Demonstrates common string operations and their time complexities.
    """
    s = "HELLO WORLD"

    # O(1) Operations
    length = len(s)              # Get length: O(1)
    char = s[0]                  # Index access: O(1)

    # O(n) Operations
    reversed_s = s[::-1]         # Reverse: O(n)
    lower_s = s.lower()          # Case conversion: O(n)

    # O(k) Operations where k = slice length
    substring = s[0:5]           # Slicing: O(k)

    # O(n) Operations
    count = s.count('L')         # Count occurrences: O(n)
    idx = s.find('WORLD')        # Find substring: O(n*m) worst case

    # O(n+m) Operations
    concat = s + "!"             # Concatenation: O(n+m)

    print(f"Original: {s}")
    print(f"Length: {length}")
    print(f"First char: {char}")
    print(f"Reversed: {reversed_s}")
    print(f"Lowercase: {lower_s}")
    print(f"Slice [0:5]: {substring}")
    print(f"Count of 'L': {count}")
    print(f"Index of 'WORLD': {idx}")


# =============================================================================
# SECTION 2: CHARACTER FREQUENCY UTILITIES
# =============================================================================

def get_frequency_map(s: str) -> Dict[str, int]:
    """
    Returns a frequency map of characters in the string.

    Time Complexity: O(n)
    Space Complexity: O(k) where k = unique characters

    Args:
        s: Input string

    Returns:
        Dictionary with character counts

    Example:
        >>> get_frequency_map("hello")
        {'h': 1, 'e': 1, 'l': 2, 'o': 1}
    """
    return dict(Counter(s))


def get_frequency_array(s: str) -> List[int]:
    """
    Returns frequency array for lowercase letters (a-z).

    Time Complexity: O(n)
    Space Complexity: O(26) = O(1)

    Useful for anagram problems and character counting.

    Args:
        s: Input string (assumed lowercase)

    Returns:
        List of 26 integers representing counts of a-z
    """
    freq = [0] * 26
    for char in s:
        if 'a' <= char <= 'z':
            freq[ord(char) - ord('a')] += 1
    return freq


def are_anagrams(s1: str, s2: str) -> bool:
    """
    Check if two strings are anagrams of each other.

    Time Complexity: O(n)
    Space Complexity: O(1) - only 26 possible characters

    Args:
        s1: First string
        s2: Second string

    Returns:
        True if strings are anagrams, False otherwise
    """
    if len(s1) != len(s2):
        return False
    return Counter(s1) == Counter(s2)


# =============================================================================
# SECTION 3: TWO POINTER TEMPLATES
# =============================================================================

def two_pointer_opposite_ends(s: str) -> bool:
    """
    Template: Two pointers moving from opposite ends toward center.

    Use cases:
    - Palindrome check
    - Two sum in sorted array
    - Container with most water

    Time Complexity: O(n)
    Space Complexity: O(1)

    Example: Palindrome check
    """
    left = 0
    right = len(s) - 1

    while left < right:
        # Compare elements at both pointers
        if s[left] != s[right]:
            return False  # Not a palindrome

        # Move pointers toward center
        left += 1
        right -= 1

    return True  # Is a palindrome


def two_pointer_same_direction(s: str, target: str) -> bool:
    """
    Template: Two pointers moving in same direction (fast & slow).

    Use cases:
    - Subsequence check
    - Remove duplicates
    - Linked list cycle detection

    Time Complexity: O(n + m)
    Space Complexity: O(1)

    Example: Check if target is subsequence of s
    """
    if not target:
        return True

    i = 0  # Pointer for target (slow)

    for j in range(len(s)):  # j is fast pointer
        if s[j] == target[i]:
            i += 1
            if i == len(target):
                return True

    return False


def reverse_string_two_pointer(s: List[str]) -> None:
    """
    Reverse a string in-place using two pointers.

    Time Complexity: O(n)
    Space Complexity: O(1)

    Args:
        s: List of characters to reverse in-place
    """
    left, right = 0, len(s) - 1

    while left < right:
        # Swap characters
        s[left], s[right] = s[right], s[left]
        left += 1
        right -= 1


# =============================================================================
# SECTION 4: SLIDING WINDOW TEMPLATES
# =============================================================================

def sliding_window_fixed_size(s: str, k: int) -> int:
    """
    Template: Fixed-size sliding window.

    Use cases:
    - Maximum sum of k consecutive elements
    - Average of subarrays of size k
    - Check if string contains anagram of pattern

    Time Complexity: O(n)
    Space Complexity: O(1) or O(k) depending on problem

    Example: Find max sum of k consecutive characters (ASCII values)
    """
    if len(s) < k:
        return 0

    # Calculate initial window sum
    window_sum = sum(ord(c) for c in s[:k])
    max_sum = window_sum

    # Slide the window
    for i in range(k, len(s)):
        # Add new element, remove old element
        window_sum += ord(s[i]) - ord(s[i - k])
        max_sum = max(max_sum, window_sum)

    return max_sum


def sliding_window_variable_size(s: str) -> int:
    """
    Template: Variable-size sliding window.

    Use cases:
    - Longest substring without repeating characters
    - Minimum window substring
    - Longest substring with at most k distinct characters

    Time Complexity: O(n)
    Space Complexity: O(k) where k = unique characters

    Example: Longest substring without repeating characters
    """
    char_index = {}  # Last seen index of each character
    max_length = 0
    start = 0

    for end in range(len(s)):
        char = s[end]

        # If character seen and within current window, shrink window
        if char in char_index and char_index[char] >= start:
            start = char_index[char] + 1

        # Update last seen index
        char_index[char] = end

        # Update max length
        max_length = max(max_length, end - start + 1)

    return max_length


def minimum_window_substring(s: str, t: str) -> str:
    """
    Find minimum window in s that contains all characters of t.

    Classic sliding window problem (LeetCode 76).

    Time Complexity: O(n + m)
    Space Complexity: O(k) where k = unique characters

    Args:
        s: Source string
        t: Target string containing required characters

    Returns:
        Minimum window substring, or empty string if not found
    """
    if not s or not t:
        return ""

    # Count characters needed
    need = Counter(t)
    have = defaultdict(int)

    required = len(need)  # Unique chars needed
    formed = 0            # Unique chars with correct count

    left = 0
    min_len = float('inf')
    min_window = ""

    for right in range(len(s)):
        char = s[right]
        have[char] += 1

        # Check if current char satisfies requirement
        if char in need and have[char] == need[char]:
            formed += 1

        # Try to shrink window while valid
        while formed == required:
            # Update minimum window
            if right - left + 1 < min_len:
                min_len = right - left + 1
                min_window = s[left:right + 1]

            # Remove leftmost character
            left_char = s[left]
            have[left_char] -= 1
            if left_char in need and have[left_char] < need[left_char]:
                formed -= 1
            left += 1

    return min_window


# =============================================================================
# SECTION 5: PATTERN MATCHING ALGORITHMS
# =============================================================================

def naive_pattern_search(text: str, pattern: str) -> List[int]:
    """
    Naive pattern matching algorithm.

    Time Complexity: O(n * m) where n = text length, m = pattern length
    Space Complexity: O(1)

    Args:
        text: Text to search in
        pattern: Pattern to find

    Returns:
        List of starting indices where pattern is found
    """
    n, m = len(text), len(pattern)
    result = []

    # Check pattern at each position
    for i in range(n - m + 1):
        match = True
        for j in range(m):
            if text[i + j] != pattern[j]:
                match = False
                break
        if match:
            result.append(i)

    return result


def compute_lps_array(pattern: str) -> List[int]:
    """
    Compute Longest Proper Prefix which is also Suffix (LPS) array.

    Used by KMP algorithm.

    Time Complexity: O(m)
    Space Complexity: O(m)

    Args:
        pattern: Pattern string

    Returns:
        LPS array where lps[i] = length of longest proper prefix
        of pattern[0..i] which is also a suffix
    """
    m = len(pattern)
    lps = [0] * m

    length = 0  # Length of previous longest prefix suffix
    i = 1

    while i < m:
        if pattern[i] == pattern[length]:
            length += 1
            lps[i] = length
            i += 1
        else:
            if length != 0:
                # Try shorter prefix
                length = lps[length - 1]
            else:
                lps[i] = 0
                i += 1

    return lps


def kmp_search(text: str, pattern: str) -> List[int]:
    """
    Knuth-Morris-Pratt (KMP) pattern matching algorithm.

    Key Idea: Use information from previous matches to skip comparisons.

    Time Complexity: O(n + m)
    Space Complexity: O(m)

    Args:
        text: Text to search in
        pattern: Pattern to find

    Returns:
        List of starting indices where pattern is found

    Example:
        >>> kmp_search("ABABDABACDABABCABAB", "ABABC")
        [10]
    """
    n, m = len(text), len(pattern)
    if m == 0:
        return []

    # Compute LPS array
    lps = compute_lps_array(pattern)

    result = []
    i = 0  # Index for text
    j = 0  # Index for pattern

    while i < n:
        if pattern[j] == text[i]:
            i += 1
            j += 1

        if j == m:
            # Found pattern at index i - j
            result.append(i - j)
            j = lps[j - 1]
        elif i < n and pattern[j] != text[i]:
            if j != 0:
                # Use LPS to skip comparisons
                j = lps[j - 1]
            else:
                i += 1

    return result


def rabin_karp_search(text: str, pattern: str, prime: int = 101) -> List[int]:
    """
    Rabin-Karp pattern matching using rolling hash.

    Key Idea: Use hashing to quickly filter potential matches.

    Time Complexity: O(n + m) average, O(n * m) worst case
    Space Complexity: O(1)

    Args:
        text: Text to search in
        pattern: Pattern to find
        prime: Prime number for hashing (default 101)

    Returns:
        List of starting indices where pattern is found
    """
    n, m = len(text), len(pattern)
    if m > n:
        return []

    d = 256  # Number of characters in alphabet
    result = []

    # Calculate hash value for pattern and first window
    pattern_hash = 0
    text_hash = 0
    h = pow(d, m - 1, prime)  # d^(m-1) mod prime

    # Calculate initial hashes
    for i in range(m):
        pattern_hash = (d * pattern_hash + ord(pattern[i])) % prime
        text_hash = (d * text_hash + ord(text[i])) % prime

    # Slide pattern over text
    for i in range(n - m + 1):
        # Check if hashes match
        if pattern_hash == text_hash:
            # Verify character by character (to avoid hash collisions)
            if text[i:i + m] == pattern:
                result.append(i)

        # Calculate hash for next window
        if i < n - m:
            # Remove leading digit, add trailing digit
            text_hash = (d * (text_hash - ord(text[i]) * h) + ord(text[i + m])) % prime
            # Handle negative hash
            if text_hash < 0:
                text_hash += prime

    return result


def compute_z_array(s: str) -> List[int]:
    """
    Compute Z-array for a string.

    Z[i] = length of longest substring starting from s[i]
           which is also a prefix of s.

    Time Complexity: O(n)
    Space Complexity: O(n)

    Args:
        s: Input string

    Returns:
        Z-array
    """
    n = len(s)
    z = [0] * n
    z[0] = n  # Whole string is prefix of itself

    left, right = 0, 0  # Z-box boundaries

    for i in range(1, n):
        if i > right:
            # Outside Z-box, calculate from scratch
            left, right = i, i
            while right < n and s[right - left] == s[right]:
                right += 1
            z[i] = right - left
            right -= 1
        else:
            # Inside Z-box, use previously computed values
            k = i - left
            if z[k] < right - i + 1:
                z[i] = z[k]
            else:
                # Need to check beyond Z-box
                left = i
                while right < n and s[right - left] == s[right]:
                    right += 1
                z[i] = right - left
                right -= 1

    return z


def z_algorithm_search(text: str, pattern: str) -> List[int]:
    """
    Pattern matching using Z-algorithm.

    Key Idea: Concatenate pattern + '$' + text and find Z-values equal to pattern length.

    Time Complexity: O(n + m)
    Space Complexity: O(n + m)

    Args:
        text: Text to search in
        pattern: Pattern to find

    Returns:
        List of starting indices where pattern is found
    """
    concat = pattern + "$" + text
    z = compute_z_array(concat)

    result = []
    m = len(pattern)

    for i in range(m + 1, len(concat)):
        if z[i] == m:
            result.append(i - m - 1)

    return result


# =============================================================================
# SECTION 6: STRING TRANSFORMATION UTILITIES
# =============================================================================

def is_palindrome(s: str) -> bool:
    """
    Check if string is a palindrome (ignoring case and non-alphanumeric).

    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    left, right = 0, len(s) - 1

    while left < right:
        # Skip non-alphanumeric characters
        while left < right and not s[left].isalnum():
            left += 1
        while left < right and not s[right].isalnum():
            right -= 1

        if s[left].lower() != s[right].lower():
            return False

        left += 1
        right -= 1

    return True


def is_rotation(s1: str, s2: str) -> bool:
    """
    Check if s2 is a rotation of s1.

    Key Insight: If s2 is rotation of s1, s2 must be substring of s1+s1.

    Time Complexity: O(n)
    Space Complexity: O(n)
    """
    if len(s1) != len(s2):
        return False
    return s2 in (s1 + s1)


def longest_common_prefix(strs: List[str]) -> str:
    """
    Find longest common prefix among list of strings.

    Time Complexity: O(S) where S = sum of all characters
    Space Complexity: O(1)
    """
    if not strs:
        return ""

    # Start with first string as prefix
    prefix = strs[0]

    for s in strs[1:]:
        # Reduce prefix until it matches
        while not s.startswith(prefix):
            prefix = prefix[:-1]
            if not prefix:
                return ""

    return prefix


def compress_string(s: str) -> str:
    """
    Compress string using counts of repeated characters.

    Example: "aabcccccaaa" -> "a2b1c5a3"

    Time Complexity: O(n)
    Space Complexity: O(n)
    """
    if not s:
        return s

    result = []
    count = 1

    for i in range(1, len(s)):
        if s[i] == s[i - 1]:
            count += 1
        else:
            result.append(s[i - 1] + str(count))
            count = 1

    # Don't forget last character group
    result.append(s[-1] + str(count))

    compressed = ''.join(result)

    # Return original if compressed is not shorter
    return compressed if len(compressed) < len(s) else s


# =============================================================================
# SECTION 7: STRING COMPARISON UTILITIES (DP-based)
# =============================================================================

def edit_distance(word1: str, word2: str) -> int:
    """
    Calculate minimum edit distance (Levenshtein distance) between two strings.

    Operations allowed: Insert, Delete, Replace

    Time Complexity: O(m * n)
    Space Complexity: O(m * n), can be optimized to O(min(m, n))
    """
    m, n = len(word1), len(word2)

    # dp[i][j] = edit distance between word1[0..i-1] and word2[0..j-1]
    dp = [[0] * (n + 1) for _ in range(m + 1)]

    # Base cases: converting from/to empty string
    for i in range(m + 1):
        dp[i][0] = i
    for j in range(n + 1):
        dp[0][j] = j

    # Fill DP table
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if word1[i - 1] == word2[j - 1]:
                dp[i][j] = dp[i - 1][j - 1]  # No operation needed
            else:
                dp[i][j] = 1 + min(
                    dp[i - 1][j],      # Delete from word1
                    dp[i][j - 1],      # Insert into word1
                    dp[i - 1][j - 1]   # Replace
                )

    return dp[m][n]


def longest_common_subsequence(text1: str, text2: str) -> int:
    """
    Find length of longest common subsequence.

    Time Complexity: O(m * n)
    Space Complexity: O(m * n)
    """
    m, n = len(text1), len(text2)

    # dp[i][j] = LCS length of text1[0..i-1] and text2[0..j-1]
    dp = [[0] * (n + 1) for _ in range(m + 1)]

    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if text1[i - 1] == text2[j - 1]:
                dp[i][j] = dp[i - 1][j - 1] + 1
            else:
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1])

    return dp[m][n]


# =============================================================================
# SECTION 8: DEMO AND TESTING
# =============================================================================

def demo_all_concepts():
    """
    Demonstrate all string concepts.
    """
    print("=" * 60)
    print("STRING CONCEPTS DEMONSTRATION")
    print("=" * 60)

    # Basic operations
    print("\n--- Basic String Operations ---")
    demonstrate_string_operations()

    # Frequency map
    print("\n--- Character Frequency ---")
    s = "hello"
    print(f"Frequency map of '{s}': {get_frequency_map(s)}")
    print(f"Are 'listen' and 'silent' anagrams? {are_anagrams('listen', 'silent')}")

    # Two pointers
    print("\n--- Two Pointer Technique ---")
    test_strings = ["RACECAR", "HELLO", "MADAM"]
    for s in test_strings:
        print(f"Is '{s}' a palindrome? {two_pointer_opposite_ends(s)}")

    # Sliding window
    print("\n--- Sliding Window ---")
    s = "ABCABCBB"
    print(f"Longest substring without repeating in '{s}': {sliding_window_variable_size(s)}")

    s = "ADOBECODEBANC"
    t = "ABC"
    print(f"Minimum window of '{s}' containing '{t}': {minimum_window_substring(s, t)}")

    # Pattern matching
    print("\n--- Pattern Matching ---")
    text = "ABABDABACDABABCABAB"
    pattern = "ABABC"
    print(f"Text: '{text}'")
    print(f"Pattern: '{pattern}'")
    print(f"Naive search: Found at indices {naive_pattern_search(text, pattern)}")
    print(f"KMP search: Found at indices {kmp_search(text, pattern)}")
    print(f"Rabin-Karp search: Found at indices {rabin_karp_search(text, pattern)}")
    print(f"Z-algorithm search: Found at indices {z_algorithm_search(text, pattern)}")

    # String utilities
    print("\n--- String Utilities ---")
    print(f"Is 'A man, a plan, a canal: Panama' palindrome? {is_palindrome('A man, a plan, a canal: Panama')}")
    print(f"Is 'ABCD' rotation of 'CDAB'? {is_rotation('ABCD', 'CDAB')}")
    print(f"LCP of ['flower', 'flow', 'flight']: '{longest_common_prefix(['flower', 'flow', 'flight'])}'")
    print(f"Compress 'aabcccccaaa': '{compress_string('aabcccccaaa')}'")

    # DP-based
    print("\n--- String DP ---")
    print(f"Edit distance 'horse' -> 'ros': {edit_distance('horse', 'ros')}")
    print(f"LCS of 'abcde' and 'ace': {longest_common_subsequence('abcde', 'ace')}")

    print("\n" + "=" * 60)
    print("DEMONSTRATION COMPLETE")
    print("=" * 60)


if __name__ == "__main__":
    demo_all_concepts()
