"""
Count and Say Problem
=====================

The count-and-say sequence starts with "1" and each subsequent term
describes the previous term by counting consecutive identical digits.

Sequence:
1. "1"
2. "11" (one 1)
3. "21" (two 1s)
4. "1211" (one 2, one 1)
5. "111221" (one 1, one 2, two 1s)
...

Approaches:
1. Iterative
2. Recursive
3. Using Regular Expression
"""

import re
from typing import List


# =============================================================================
# APPROACH 1: ITERATIVE
# =============================================================================

def count_and_say_iterative(n: int) -> str:
    """
    Generate the nth term of count-and-say sequence iteratively.

    INTUITION:
    - Start with "1"
    - For each subsequent term, describe the previous by counting
      consecutive identical characters
    - Build the description: count + digit for each group

    EXAMPLE for n=5:
    "1" -> "11" -> "21" -> "1211" -> "111221"

    Time Complexity: O(n * m) where m is length of longest term
    Space Complexity: O(m) for storing current term
    """
    if n <= 0:
        return ""

    result = "1"

    for _ in range(n - 1):
        next_result = []
        i = 0

        while i < len(result):
            char = result[i]
            count = 1

            # Count consecutive identical characters
            while i + count < len(result) and result[i + count] == char:
                count += 1

            # Append count and character
            next_result.append(str(count))
            next_result.append(char)

            i += count

        result = ''.join(next_result)

    return result


def count_and_say_simple(n: int) -> str:
    """
    Simpler iterative implementation using string comparison.
    """
    result = "1"

    for _ in range(n - 1):
        new_result = []
        count = 1

        for i in range(1, len(result)):
            if result[i] == result[i - 1]:
                count += 1
            else:
                new_result.append(str(count) + result[i - 1])
                count = 1

        # Don't forget the last group
        new_result.append(str(count) + result[-1])
        result = ''.join(new_result)

    return result


# =============================================================================
# APPROACH 2: RECURSIVE
# =============================================================================

def count_and_say_recursive(n: int) -> str:
    """
    Generate the nth term using recursion.

    INTUITION:
    - Base case: n=1 returns "1"
    - Recursive case: Get (n-1)th term and describe it

    Time Complexity: O(n * m)
    Space Complexity: O(n * m) due to recursion stack + strings
    """
    if n == 1:
        return "1"

    # Get previous term
    prev = count_and_say_recursive(n - 1)

    # Describe the previous term
    return describe(prev)


def describe(s: str) -> str:
    """
    Describe a string by counting consecutive identical characters.

    Example: "1211" -> "111221" (one 1, one 2, two 1s)
    """
    result = []
    i = 0

    while i < len(s):
        char = s[i]
        count = 1

        # Count consecutive identical characters
        while i + count < len(s) and s[i + count] == char:
            count += 1

        result.append(str(count) + char)
        i += count

    return ''.join(result)


# =============================================================================
# APPROACH 3: USING REGULAR EXPRESSION
# =============================================================================

def count_and_say_regex(n: int) -> str:
    """
    Generate using regex to match consecutive identical characters.

    REGEX EXPLANATION:
    - (.)\1*  matches a character followed by zero or more of the same
    - . matches any character
    - \1 is a backreference to the first capture group
    - * means zero or more

    Example:
    "1211" matches: "1", "2", "11"
    Each match is replaced with len(match) + first_char

    Time Complexity: O(n * m)
    Space Complexity: O(m)
    """
    result = "1"

    for _ in range(n - 1):
        # Replace each group of identical chars with count + char
        result = re.sub(
            r'(.)\1*',
            lambda m: str(len(m.group())) + m.group(1),
            result
        )

    return result


# =============================================================================
# APPROACH 4: USING ITERTOOLS GROUPBY
# =============================================================================

from itertools import groupby

def count_and_say_groupby(n: int) -> str:
    """
    Generate using itertools.groupby to group consecutive chars.

    groupby returns groups of consecutive identical elements.

    Example:
    list(groupby("1211")) gives:
    [('1', iterator), ('2', iterator), ('1', iterator)]
    """
    result = "1"

    for _ in range(n - 1):
        # Group consecutive identical characters
        result = ''.join(
            str(len(list(group))) + char
            for char, group in groupby(result)
        )

    return result


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def generate_sequence(n: int) -> List[str]:
    """
    Generate first n terms of the count-and-say sequence.
    """
    sequence = []
    for i in range(1, n + 1):
        sequence.append(count_and_say_iterative(i))
    return sequence


def visualize_transformation(s: str) -> str:
    """
    Show how a string is described step by step.
    """
    result = []
    i = 0

    print(f"Describing '{s}':")

    while i < len(s):
        char = s[i]
        count = 1

        while i + count < len(s) and s[i + count] == char:
            count += 1

        segment = s[i:i + count]
        description = f"{count}{char}"
        print(f"  '{segment}' -> {count} occurrence(s) of '{char}' -> '{description}'")

        result.append(description)
        i += count

    final = ''.join(result)
    print(f"Final description: '{final}'")
    return final


# =============================================================================
# TEST CASES
# =============================================================================

def run_tests():
    """Run comprehensive test cases."""

    expected = {
        1: "1",
        2: "11",
        3: "21",
        4: "1211",
        5: "111221",
        6: "312211",
        7: "13112221",
        8: "1113213211",
        9: "31131211131221",
        10: "13211311123113112211"
    }

    print("=" * 60)
    print("COUNT AND SAY - TEST RESULTS")
    print("=" * 60)

    approaches = [
        ("Iterative", count_and_say_iterative),
        ("Simple", count_and_say_simple),
        ("Recursive", count_and_say_recursive),
        ("Regex", count_and_say_regex),
        ("Groupby", count_and_say_groupby),
    ]

    for name, func in approaches:
        print(f"\n--- {name} ---")
        all_passed = True
        for n, exp in expected.items():
            result = func(n)
            if result != exp:
                all_passed = False
                print(f"  FAIL: n={n}, got '{result}', expected '{exp}'")
        if all_passed:
            print(f"  All {len(expected)} test cases PASSED!")


def demonstrate():
    """Demonstrate the sequence step by step."""

    print("\n" + "=" * 60)
    print("COUNT AND SAY - DEMONSTRATION")
    print("=" * 60)

    print("\nFirst 10 terms of the sequence:")
    sequence = generate_sequence(10)
    for i, term in enumerate(sequence, 1):
        print(f"  n={i:2d}: {term}")

    print("\n" + "-" * 40)
    print("Step-by-step transformation examples:")
    print("-" * 40)

    visualize_transformation("1")
    print()
    visualize_transformation("11")
    print()
    visualize_transformation("21")
    print()
    visualize_transformation("1211")

    # Show length growth
    print("\n" + "-" * 40)
    print("Sequence length growth:")
    print("-" * 40)
    for i in range(1, 16):
        term = count_and_say_iterative(i)
        print(f"  n={i:2d}: length = {len(term):5d}")


if __name__ == "__main__":
    run_tests()
    demonstrate()
