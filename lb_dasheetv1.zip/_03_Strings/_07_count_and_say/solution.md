# Count and Say Problem

## Problem Statement
The count-and-say sequence is a sequence of digit strings defined by the recursive formula:
- `countAndSay(1)` = "1"
- `countAndSay(n)` = describe the previous term

To "describe" a term, read off the groups of consecutive identical digits and say the count followed by the digit.

**Example:**
```
countAndSay(1) = "1"
countAndSay(2) = "11" (one 1)
countAndSay(3) = "21" (two 1s)
countAndSay(4) = "1211" (one 2, one 1)
countAndSay(5) = "111221" (one 1, one 2, two 1s)
countAndSay(6) = "312211" (three 1s, two 2s, one 1)
```

---

## Intuition and Thought Process

This is a "look-and-say" sequence where each term describes the previous term:

```
n=1: "1"
     Reading: "one 1" -> Write: "11"

n=2: "11"
     Reading: "two 1s" -> Write: "21"

n=3: "21"
     Reading: "one 2, one 1" -> Write: "1211"

n=4: "1211"
     Reading: "one 1, one 2, two 1s" -> Write: "111221"
```

### Key Insight
We need to:
1. Group consecutive identical characters
2. For each group, write (count + digit)
3. Repeat n-1 times starting from "1"

---

## Approach 1: Iterative

### Algorithm
1. Start with result = "1"
2. For each iteration from 2 to n:
   - Build next term by counting consecutive characters
   - Group identical consecutive chars
   - Write count + digit for each group

### Visual Dry Run

```
Building countAndSay(5):

Start: "1"

Iteration 2: Process "1"
  Group: '1' appears 1 time
  Result: "1" + "1" = "11"

Iteration 3: Process "11"
  Group: '1' appears 2 times
  Result: "2" + "1" = "21"

Iteration 4: Process "21"
  Group 1: '2' appears 1 time -> "12"
  Group 2: '1' appears 1 time -> "11"
  Result: "12" + "11" = "1211"

Iteration 5: Process "1211"
  Group 1: '1' appears 1 time -> "11"
  Group 2: '2' appears 1 time -> "12"
  Group 3: '1' appears 2 times -> "21"
  Result: "11" + "12" + "21" = "111221"

Final: "111221"
```

### Pseudocode
```
function countAndSay(n):
    result = "1"

    for i from 2 to n:
        next = ""
        count = 1

        for j from 1 to length(result):
            if result[j] == result[j-1]:
                count = count + 1
            else:
                next = next + str(count) + result[j-1]
                count = 1

        next = next + str(count) + result[last]
        result = next

    return result
```

### Complexity
- **Time**: O(n * m) where m is the length of the longest term
- **Space**: O(m) for storing current term

---

## Approach 2: Recursive

### Idea
Recursively get the (n-1)th term and describe it.

### Code
```python
def count_and_say_recursive(n: int) -> str:
    if n == 1:
        return "1"

    prev = count_and_say_recursive(n - 1)
    return describe(prev)

def describe(s: str) -> str:
    result = []
    i = 0

    while i < len(s):
        char = s[i]
        count = 1
        while i + count < len(s) and s[i + count] == char:
            count += 1
        result.append(str(count) + char)
        i += count

    return ''.join(result)
```

### Complexity
- **Time**: O(n * m)
- **Space**: O(n * m) due to recursion stack

---

## Approach 3: Using Regular Expression

### Idea
Use regex to find groups of consecutive identical digits.

### Code
```python
import re

def count_and_say_regex(n: int) -> str:
    result = "1"

    for _ in range(n - 1):
        # Find groups of identical consecutive chars
        result = re.sub(r'(.)\1*',
                        lambda m: str(len(m.group())) + m.group(1),
                        result)

    return result
```

### Explanation
- `(.)\1*` matches a character followed by zero or more of the same character
- `m.group()` is the entire match (e.g., "111")
- `m.group(1)` is the first capture group (the single character)
- Replace with count + character

---

## Complete Sequence (First 10 Terms)

```
n=1:  "1"
n=2:  "11"
n=3:  "21"
n=4:  "1211"
n=5:  "111221"
n=6:  "312211"
n=7:  "13112221"
n=8:  "1113213211"
n=9:  "31131211131221"
n=10: "13211311123113112211"
```

---

## Edge Cases

| n | Output | Notes |
|---|--------|-------|
| 1 | "1" | Base case |
| 2 | "11" | First description |
| 30 | Very long | Upper constraint typically |

---

## Properties of the Sequence

1. **Only digits 1, 2, 3 appear** (proven by John Conway)
2. **Growth rate**: Each term is roughly 30% longer than the previous
3. **Never contains more than three consecutive identical digits**
4. **Self-describing property**: Describes the previous term exactly

---

## Key Takeaways

1. **String building** - Use list and join for efficiency
2. **Consecutive counting** - Common pattern in string problems
3. **Iterative vs Recursive** - Both work, iterative is more space-efficient
4. **Regex alternative** - Elegant but may be slower

---

## Related Problems
- Run-Length Encoding
- String Compression
- Look and Say Sequence Variants
- Encode and Decode Strings
